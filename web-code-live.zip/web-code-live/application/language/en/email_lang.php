<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

//$lang['hm_dshbrd'] = "Dashboard";
//$lang['cmn_data'] = "Data";
$lang['email_sent'] = "Email Sent";
