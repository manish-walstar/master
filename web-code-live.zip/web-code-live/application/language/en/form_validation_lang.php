<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['hm_dshbrd'] = "Dashboard";
$lang['cmn_data'] = "Data";
$lang['sidebar_data_entry'] = "Data Entry";
