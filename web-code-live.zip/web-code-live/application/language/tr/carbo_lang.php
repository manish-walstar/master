<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['cg_ok'] = "tamam";
$lang['cg_save'] = "Kaydet";
$lang['cg_cancel'] = "İptal";
$lang['cg_yes'] = "Evet";
$lang['cg_no'] = "hayır";
$lang['cg_back'] = "sırt";
$lang['cg_add'] = "eklemek";
$lang['cg_edit'] = "Düzenleme";
$lang['cg_delete'] = "silmek";
$lang['cg_action'] = "eylem";
$lang['cg_filter'] = "filtre";
$lang['cg_no_items'] = "Bulunamadi";
$lang['cg_go'] = "Gitmek";
$lang['cg_page_first'] = "İlk sayfa";
$lang['cg_page_prev'] = "Önceki sayfa";
$lang['cg_page_next'] = "Sonraki Sayfa";
$lang['cg_page_last'] = "Son Sayfa";
$lang['cg_page_size'] = "Satır Sayısı";
$lang['cg_page_displaying'] = "Öğe %s %s %s";
$lang['cg_yes'] = "Evet";
$lang['cg_no'] = "hayır";
$lang['cg_confirm_delete_title'] = "Silmeyi onayla";
$lang['cg_confirm_delete'] = "Seçili kalem (ler) silmek istediğinizden emin misiniz?";
$lang['cg_confirm_delete_multiple'] = "tr_ Are you sure you want to delete the selected items?";
$lang['cg_loading_message'] = "Yükleniyor";
$lang['cg_columns'] = "Sütunlar";
$lang['cg_export_pdf'] = "PDF İhracat";

$lang['cg_filter_like'] = "Sevmek";
$lang['cg_filter_not_like'] = "Gibi değil";
$lang['cg_filter_in'] = "Içinde";
$lang['cg_filter_not_in'] = "Değil";
$lang['cg_filter_starts'] = "Başlıyor";
$lang['cg_filter_ends'] = "Son";
$lang['cg_filter_all'] = "Tüm";
$lang['cg_filter_true'] = "Gerçek";
$lang['cg_filter_false'] = "Sahte";

$lang['cg_select'] = "Lütfen seç";

$lang['cg_check_unique'] = "%s alan benzersiz olmalıdır.";
$lang['cg_check_date'] = "%s tarihi geçersiz.";

$lang['cg_save'] = "Kaydet";
$lang['cg_cancel'] = "İptal";
$lang['cg_done'] = "Bitti";

$lang['cg_now'] = "şimdi";
$lang['cg_time_only_title'] = "Zaman seçin";
$lang['cg_time'] = "Zaman";
$lang['cg_hour'] = "Saat";
$lang['cg_minute'] = "Dakika";
$lang['cg_second'] = "İkinci";

$lang['cg_january'] = "Ocak";
$lang['cg_february'] = "Şubat";
$lang['cg_march'] = "Mart";
$lang['cg_april'] = "Nisan";
$lang['cg_may'] = "Mayıs";
$lang['cg_june'] = "Haziran";
$lang['cg_july'] = "Temmuz";
$lang['cg_august'] = "Ağustos";
$lang['cg_september'] = "Eylül";
$lang['cg_october'] = "Ekim";
$lang['cg_november'] = "Kasım";
$lang['cg_december'] = "Aralık";

$lang['cg_january_short'] = "Ocak";
$lang['cg_february_short'] = "Şubat";
$lang['cg_march_short'] = "Mart";
$lang['cg_april_short'] = "Nisan";
$lang['cg_may_short'] = "Mayıs";
$lang['cg_june_short'] = "Haziran";
$lang['cg_july_short'] = "Temmuz";
$lang['cg_august_short'] = "Ağustos";
$lang['cg_september_short'] = "Eylül";
$lang['cg_october_short'] = "Ekim";
$lang['cg_november_short'] = "Kasım";
$lang['cg_december_short'] = "Aralık";

$lang['cg_sunday'] = "Pazar";
$lang['cg_monday'] = "Pazartesi";
$lang['cg_tuesday'] = "Salı";
$lang['cg_wednesday'] = "Çarşamba";
$lang['cg_thursday'] = "Perşembe";
$lang['cg_friday'] = "Cuma";
$lang['cg_saturday'] = "Cumartesi";

$lang['cg_sunday_short'] = "Pazar";
$lang['cg_monday_short'] = "Pazartesi";
$lang['cg_tuesday_short'] = "Salı";
$lang['cg_wednesday_short'] = "Çarşamba";
$lang['cg_thursday_short'] = "Perşembe";
$lang['cg_friday_short'] = "Cuma";
$lang['cg_saturday_short'] = "Cumartesi";

$lang['cg_sunday_min'] = "Pazar";
$lang['cg_monday_min'] = "Pazartesi";
$lang['cg_tuesday_min'] = "Salı";
$lang['cg_wednesday_min'] = "Çarşamba";
$lang['cg_thursday_min'] = "Perşembe";
$lang['cg_friday_min'] = "Cuma";
$lang['cg_saturday_min'] = "Cumartesi";