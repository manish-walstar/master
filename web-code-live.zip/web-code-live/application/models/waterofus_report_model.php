<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Waterofus_report_model extends CI_Model {
	public $data = "";
	public $trap_name = "";
	public $trap_count = "";
	public $temparr = array ();
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	public function getWaterofus($startdate = '', $enddate = '') {
		// echo $startdate." ".$enddate." ".$zone." ".$site." ".$species." ".$traptypes." ".$techs."<br>";
		// echo "thr".$species;
		// die;
		$startdate_arr = explode ( "/", $startdate );
		$startdate = $startdate_arr [2] . "-" . $startdate_arr [0] . "-" . $startdate_arr [1];
		
		$enddate_arr = explode ( "/", $enddate );
		$enddate = $enddate_arr [2] . "-" . $enddate_arr [0] . "-" . $enddate_arr [1];
		
		$data = array ();
		// DATE_FORMAT(CONCAT(at.date ,' ' , at.time) , '%m/%d/%Y %h:%i %p') AS date_of_app
		$this->db->select ( "CONCAT(DATE_FORMAT(at.date, '%m/%d/%Y'),' ' , at.time)  AS date_of_app, 
				st.sitetype, 
				pc.productcategory, 
				pu.unitproductabbrev, 
				CONCAT(u.firstname , ' ',u.middlename , ' ' , u.lastname) AS employee_name, 
				s.site AS location_name, 
				p.productname AS material_used , 
				CONCAT( FORMAT(at.totalproductapplied , 2) , ' ' , pu.unitproduct) AS amount_used, 
				pu.unitproduct, 
				CONCAT(at.applicationrate, ' ', aruom.applicationrateuom) AS applicationrates, 
				f.wetdry, 
				FORMAT(at.totalareatreated , 2) AS acres_treated , 
				s.site, s.latitude, s.longitude", TRUE );
		$this->db->from ( 'adulticidetreatments AS at' );
		$this->db->join ( 'sites AS s', 'at.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'sitetypes AS st', 's.idsitetype = st.idsitetype', 'LEFT' );
		$this->db->join ( 'products AS p', 'at.idproduct = p.idproduct', 'LEFT' );
        $this->db->join ( 'formulations AS f', 'p.idformulation = f.idformulation', 'LEFT' );
		$this->db->join ( 'productunit AS pu', 'at.iduomtotalproductapplied = pu.idproductunit', 'LEFT' );
		$this->db->join ( 'applicationrateuom AS aruom', 'at.idapplicationrateuom = aruom.idapplicationrateuom', 'LEFT' );
		$this->db->join ( 'users AS u', 'at.idapplicator = u.iduser', 'LEFT' );
		$this->db->join ( 'productcategories AS pc', 'p.idcategory = pc.idproductcategory', 'LEFT' );
		
		// $where = "(s.isdeleted = '0' AND at.isdeleted = '0' AND s.idlocation = '".$this->session->userdata('idlocation')."' AND at.idlocation = '".$this->session->userdata('idlocation')."' AND //at.date BETWEEN '".$startdate."' AND '".$enddate."' AND at.iswaterofus = '1' AND s.water_of_us = '1')";
		// $this->db->where($where);
		
		$where = "(s.isdeleted = '0' 
				AND at.isdeleted = '0' 
				AND s.idlocation = '" . $this->session->userdata ( 'idlocation' ) . "' 
						AND at.idlocation = '" . $this->session->userdata ( 'idlocation' ) . "' 
								AND at.date BETWEEN '" . $startdate . "' AND '" . $enddate . "' 
										AND at.iswaterofus = '1')";
		$this->db->or_where ( $where );
		
		$where = "(s.isdeleted = '0' 
				AND at.isdeleted = '0' 
				AND s.idlocation = '" . $this->session->userdata ( 'idlocation' ) . "' 
						AND at.idlocation = '" . $this->session->userdata ( 'idlocation' ) . "' 
								AND at.date BETWEEN '" . $startdate . "' AND '" . $enddate . "' 
										AND s.water_of_us = '1')";
		$this->db->or_where ( $where );
		
		// $this->db->where("p.idlocation" , $this->session->userdata('idlocation'));
		$this->db->order_by ( "at.date", "DESC" );
		
		$query = $this->db->get ();
		// echo $this->db->last_query()."<br>";
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				array_push ( $data, $row );
			}
		}
		
		$this->db->select ( "CONCAT(DATE_FORMAT(lt.date, '%m/%d/%Y'),' ' , lt.time) AS date_of_app, 
				st.sitetype, 
				pc.productcategory, 
				pu.unitproductabbrev, 
				CONCAT(u.firstname , ' ',u.middlename , ' ' , u.lastname) AS employee_name, 
				s.site AS location_name, 
				p.productname AS material_used , 
				CONCAT( FORMAT(lt.totalproductapplied  , 2), ' ' , pu.unitproduct) AS amount_used,
				pu.unitproduct,  
				CONCAT(lt.applicationrate, ' ', aruom.applicationrateuom) AS applicationrates, 
				f.wetdry,  
				FORMAT(lt.totalareatreated , 2) AS acres_treated , 
				s.site,
				s.latitude,
				s.longitude", TRUE );
		$this->db->from ( 'larvaltreatments AS lt' );
		$this->db->join ( 'products AS p', 'lt.idproduct = p.idproduct', 'LEFT' );
		$this->db->join ( 'formulations AS f', 'p.idformulation = f.idformulation', 'LEFT' );
		$this->db->join ( 'sites AS s', 'lt.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'sitetypes AS st', 's.idsitetype = st.idsitetype', 'LEFT' );
		$this->db->join ( 'productunit AS pu', 'lt.iduomtotalproductapplied = pu.idproductunit', 'LEFT' );
		$this->db->join ( 'applicationrateuom AS aruom', 'lt.idapplicationrateuom = aruom.idapplicationrateuom', 'LEFT' );
		$this->db->join ( 'users AS u', 'lt.idapplicator = u.iduser', 'LEFT' );
		$this->db->join ( 'productcategories AS pc', 'p.idcategory = pc.idproductcategory', 'LEFT' );
		
		// $this->db->where("p.idlocation" , $this->session->userdata('idlocation'));
		// $where = "(s.isdeleted = '0' AND lt.isdeleted = '0' AND s.idlocation = '".$this->session->userdata('idlocation')."' AND lt.idlocation = '".$this->session->userdata('idlocation')."' AND lt.date //BETWEEN '".$startdate."' AND '".$enddate."' AND lt.iswaterofus = '1' AND s.water_of_us = '1')";
		// $this->db->where($where);
		
		$where = "(s.isdeleted = '0' 
				AND lt.isdeleted = '0' 
				AND s.idlocation = '" . $this->session->userdata ( 'idlocation' ) . "' 
						AND lt.idlocation = '" . $this->session->userdata ( 'idlocation' ) . "' 
								AND lt.date BETWEEN '" . $startdate . "' 
										AND '" . $enddate . "' 
												AND lt.iswaterofus = '1')";
		$this->db->or_where ( $where );
		
		$where = "(s.isdeleted = '0' 
				AND lt.isdeleted = '0' 
				AND s.idlocation = '" . $this->session->userdata ( 'idlocation' ) . "' 
						AND lt.idlocation = '" . $this->session->userdata ( 'idlocation' ) . "' 
								AND lt.date BETWEEN '" . $startdate . "' 
										AND '" . $enddate . "' 
												AND s.water_of_us = '1')";
		$this->db->or_where ( $where );
		$this->db->order_by ( "lt.date", "DESC" );
		
		$query = $this->db->get ();
		// echo $this->db->last_query()."<br>";
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				array_push ( $data, $row );
			}
		}
		// print'<pre>';
		// print_R($data);
		// die;
		return $data;
	}
}
