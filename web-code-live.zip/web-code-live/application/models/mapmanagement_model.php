<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );

//ini_set('error_reporting', E_ALL);
//ini_set('display_errors',1);
class Mapmanagement_model extends Common_model {
	public $eventArray = array('lrvltreatment', 'adlttreatment');
	/**
	 * Constructor for the class
	 * User
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to get Zoom Level
	 */
	public function getzoom() {
		$id = $this->session->userdata ( 'idlocation' );
		$zoom = '';
		if (! empty ( $id )) {
			$this->db->select ( '*' );
			$this->db->from ( 'locations' );
			$this->db->where ( 'idlocation', $id );
			$query = $this->db->get ();
			if ($query->num_rows () > 0) {
				$zoom = $query->result_array ();
				// print'<pre>';
				// print_r($zoom);
				// die;
				$zoom = ! empty ( $zoom [0] ['GoogleZoom'] ) ? $zoom [0] ['GoogleZoom'] : '0';
			}
		}
		return $zoom;
	}
	
	/**
	 * Function to get list Map Summary
	 */
	public function listMapSummary($columns) {
        $page_size = $this->input->get ( 'page_size' );
        if(empty($page_size)){
            $page_size = 10;    
        }
		
		$page = $this->input->get ( 'page' );
		if (empty ( $page ) || $page == '' || $page == 1)
			$offset = 0;
		else
			$offset = $page * $page_size;
		
		$filter_date = $this->input->get ( 'filter_date' );
        $setfromdate = $this->input->get ( 'setfromdate' );
        $settodate = $this->input->get ( 'settodate' );
        $filter_type = $this->input->get ( 'type' );
        $orderby = $this->input->get ( 'orderby' );
        $filter_daterange = array();
        //For Testing 
        //$filter_type = 5;
        //$filter_date = 5;
        
		if ((empty($setfromdate) || empty($settodate)) && (! isset ( $filter_date ) || $filter_date == ''))
			$filter_date = 2;
		else if (!empty($setfromdate) && !empty($settodate)) {
            $filter_daterange[0] = $setfromdate;
            $filter_daterange[1] = $settodate;
		}
        $allsite = $this->input->get ( 'allsite' );
        if(!empty($allsite)){
            $filter_date = "";
            $filter_daterange = "";
        }
        $subQuery = array();
        $idlocation = $this->session->userdata ( 'idlocation' );
        $weather_date_condition = $adult_date_condition = $landing_date_condition = $larvalsurv_date_condition = $larvaltrt_date_condition = $larvaltrt_only_date_condition = $adulttrt_date_condition = $work_assgnmnts_date_condition = '';
		$weather_date_condition = " AND `sites`.`idlocation` = '" . $idlocation . "'";
		$adult_date_condition = " AND `sites`.`idlocation` = '" . $idlocation . "'";
		$landing_date_condition = " AND `sites`.`idlocation` = '" . $idlocation . "'";
		$larvalsurv_date_condition = " AND `sites`.`idlocation` = '" . $idlocation . "'";
		$larvaltrt_date_condition = " AND `sites`.`idlocation` = '" . $idlocation . "'";
		$larvaltrt_only_date_condition = " AND `sites`.`idlocation` = '" . $idlocation . "'";
        $adulttrt_date_condition = " AND `sites`.`idlocation` = '" . $idlocation . "'";
        $work_assgnmnts_date_condition = " AND `sites`.`idlocation` = '" . $idlocation . "'";
        
        if (! empty ( $filter_date ) && empty ( $filter_daterange )) {
				switch ($filter_date) {
					// date('H:i:s',strtotime('-1 day');
					case '1' :
						$weather_date_condition = "AND (`weather`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `weather`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
						$adult_date_condition = "AND (`adultsurveillance`.`pudate` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `adultsurveillance`.`pudate` <= '" . date ( 'Y-m-d' ) . "' )";
						$landing_date_condition = "AND (`landingrates`.`observeddate` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `landingrates`.`observeddate` <= '" . date ( 'Y-m-d' ) . "' )";
						$larvalsurv_date_condition = "AND (`larvalsurveillance`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `larvalsurveillance`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
						$larvaltrt_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
						$larvaltrt_only_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $adulttrt_date_condition = "AND (`adulticidetreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `adulticidetreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $work_assgnmnts_date_condition = "AND (`servicerequests`.`opendate` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `servicerequests`.`opendate` <= '" . date ( 'Y-m-d' ) . "' )";
						break;
					
					case '2' :
						$weather_date_condition = "AND (`weather`.`date` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `weather`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
						$adult_date_condition = "AND (`adultsurveillance`.`pudate` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `adultsurveillance`.`pudate` <= '" . date ( 'Y-m-d' ) . "' )";
						$landing_date_condition = "AND (`landingrates`.`observeddate` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `landingrates`.`observeddate` <= '" . date ( 'Y-m-d' ) . "' )";
						$larvalsurv_date_condition = "AND (`larvalsurveillance`.`date` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `larvalsurveillance`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
						$larvaltrt_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
						$larvaltrt_only_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $adulttrt_date_condition = "AND (`adulticidetreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `adulticidetreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $work_assgnmnts_date_condition = "AND (`servicerequests`.`opendate` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `servicerequests`.`opendate` <= '" . date ( 'Y-m-d' ) . "' )";
						
						break;
					case '3' :
						$weather_date_condition = "AND (`weather`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `weather`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
						$adult_date_condition = "AND (`adultsurveillance`.`pudate` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `adultsurveillance`.`pudate` <= '" . date ( 'Y-m-d' ) . "' )";
						$landing_date_condition = "AND (`landingrates`.`observeddate` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `landingrates`.`observeddate` <= '" . date ( 'Y-m-d' ) . "' )";
						$larvalsurv_date_condition = "AND (`larvalsurveillance`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `larvalsurveillance`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
						$larvaltrt_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
						$larvaltrt_only_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $adulttrt_date_condition = "AND (`adulticidetreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `adulticidetreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $work_assgnmnts_date_condition = "AND (`servicerequests`.`opendate` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `servicerequests`.`opendate` <= '" . date ( 'Y-m-d' ) . "' )";
						
						break;
					case '4' :
						$weather_date_condition = "AND (`weather`.`date` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `weather`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
						$adult_date_condition = "AND (`adultsurveillance`.`pudate` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `adultsurveillance`.`pudate` <= '" . date ( 'Y-m-d' ) . "' )";
						$landing_date_condition = "AND (`landingrates`.`observeddate` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `landingrates`.`observeddate` <= '" . date ( 'Y-m-d' ) . "' )";
						$larvalsurv_date_condition = "AND (`larvalsurveillance`.`date` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `larvalsurveillance`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
						$larvaltrt_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
						$larvaltrt_only_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $adulttrt_date_condition = "AND (`adulticidetreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `adulticidetreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $work_assgnmnts_date_condition = "AND (`servicerequests`.`opendate` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `servicerequests`.`opendate` <= '" . date ( 'Y-m-d' ) . "' )";
						
						break;
					case '5' :
						$weather_date_condition = "AND (`weather`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `weather`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
						$adult_date_condition = "AND (`adultsurveillance`.`pudate` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `adultsurveillance`.`pudate` <= '" . date ( 'Y-m-d' ) . "' )";
						$landing_date_condition = "AND (`landingrates`.`observeddate` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `landingrates`.`observeddate` <= '" . date ( 'Y-m-d' ) . "' )";
						$larvalsurv_date_condition = "AND (`larvalsurveillance`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `larvalsurveillance`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
						$larvaltrt_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
						$larvaltrt_only_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $adulttrt_date_condition = "AND (`adulticidetreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `adulticidetreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $work_assgnmnts_date_condition = "AND (`servicerequests`.`opendate` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `servicerequests`.`opendate` <= '" . date ( 'Y-m-d' ) . "' )";
						
						break;
				}
			}
			
			if (! empty ( $filter_daterange ) && isset($filter_daterange[0]) && !empty($filter_daterange[0])) {
				$weather_date_condition = "AND (`weather`.`date` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `weather`.`date` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
				$adult_date_condition = "AND (`adultsurveillance`.`pudate` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `adultsurveillance`.`pudate` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
				$landing_date_condition = "AND (`landingrates`.`observeddate` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `landingrates`.`observeddate` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
				$larvalsurv_date_condition = "AND (`larvalsurveillance`.`date` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `larvalsurveillance`.`date` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
				$larvaltrt_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
                $larvaltrt_only_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
                $adulttrt_date_condition = "AND (`adulticidetreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `adulticidetreatments`.`date` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
                $work_assgnmnts_date_condition = "AND (`servicerequests`.`opendate` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `servicerequests`.`opendate` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
				
			}
        
        $subQuery[0] = "(SELECT `landingrates`.`idlandingrate` AS id, 
                `landingrates`.`idlandingrate` AS `idlandingrate`, 
                `landingrates`.`observeddate` AS `eventdate`,
                `landingrates`.`latitude` AS `latitude`, 
				`landingrates`.`longitude` AS `longitude`,
                SUM(`landingratedetails`.`count`) AS `total`, 
                `lp`.`landingrateexceeds` AS `exceed`,
                'map_smmry_lndng_rte_excds_msqts' as event, 
                `sites`.`site`, 
                `landingrates`.`idsite`,
                CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`, 
                'prfrncs_lndng_rte_excds' as `type`, 
                'landingrates' as module
                FROM `landingrates` 
                LEFT JOIN `sites` ON `landingrates`.`idsite` = `sites`.`idsite`
                LEFT JOIN `landingratedetails` ON `landingratedetails`.`idlandingrate` = `landingrates`.`idlandingrate`  
                INNER JOIN `locationpreferences` AS lp ON `landingrates`.`idlocation` = `lp`.`idlocation` 
                WHERE (SELECT SUM(`landingratedetails`.`count`) FROM `landingratedetails` WHERE `landingratedetails`.`idlandingrate` = `landingrates`.`idlandingrate` GROUP BY `landingrates`.`idlandingrate`) >`lp`.`landingrateexceeds` AND 
                `landingrates`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' $landing_date_condition 
                 GROUP BY `landingrates`.`idlandingrate`)";
        
        $subQuery[1] = "(SELECT `weather`.`idweather` AS id , 
                `weather`.`idweather` AS `idweather`, 
                `weather`.`date` AS `eventdate`,
                `weathersensors`.`latitude` AS `latitude`,
                `weathersensors`.`longitude` AS `longitude`,
                SUM(`weather`.`rainfall`) AS `total`,
                `lp`.`rainfallexceeds` AS `exceed`,
                'map_smmry_rnfll_excds_inchs' as event, 
                `sites`.`site`, 
                `weathersensors`.`idsite`,
                CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`, 
                'map_smmry_rnfll_excds' as `type`, 
                'rainfall' as module
                FROM `weather`
                LEFT JOIN `weathersensors` ON `weather`.`idweathersensor` = `weathersensors`.`idweathersensor`
                LEFT JOIN `sites` ON `weathersensors`.`idsite` = `sites`.`idsite`
                INNER JOIN `locationpreferences` AS lp ON `weather`.`idlocation` = `lp`.`idlocation` 
                WHERE (SELECT SUM(`w`.`rainfall`) FROM `weather` AS `w` WHERE `w`.`idweather` = `weather`.`idweather` GROUP BY `w`.`idweather`) >`lp`.`rainfallexceeds` 
                AND `weather`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' $weather_date_condition
                GROUP BY `weather`.`idweather`)";
        
        $subQuery[2] = "(SELECT `adultsurveillance`.`idadultsurveillance` AS id, 
                `adultsurveillance`.`idadultsurveillance` AS `idadultsurveillance`, 
                `traps`.`latitude` AS `latitude`,
                `traps`.`longitude` AS `longitude`,
                SUM(`adultsurveillancedetails`.`count`) AS `total`, 
                `lp`.`trapcountmosquito` AS `exceed`, 
                `adultsurveillance`.`pudate` AS `eventdate`,
                'map_smmry_trap_cnt_excds_msqts' as event, 
                `sites`.`site`, 
                `traps`.`idsite`,
                CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`, 
                'map_smmry_trap_cnt_excds' as `type`, 
                'adultsurveillance' as module
                FROM `adultsurveillance`
                LEFT JOIN `traps` ON `adultsurveillance`.`idtrap` = `traps`.`idtrap`
                LEFT JOIN `sites` ON `traps`.`idsite` = `sites`.`idsite`
                LEFT JOIN `adultsurveillancedetails` ON `adultsurveillancedetails`.`idadultsurveillance` = `adultsurveillance`.`idadultsurveillance` 
                LEFT JOIN `locationmosquitospecies` ON `adultsurveillancedetails`.`idmosquitospecies` = `locationmosquitospecies`.`idmosquitospecies` 
                INNER JOIN `locationpreferences` AS lp ON `adultsurveillance`.`idlocation` = `lp`.`idlocation` 
                WHERE (SELECT SUM(`adultsurveillancedetails`.`count`) FROM `adultsurveillancedetails` WHERE `adultsurveillancedetails`.`idadultsurveillance` = `adultsurveillance`.`idadultsurveillance` GROUP BY `adultsurveillance`.`idadultsurveillance`) >`lp`.`trapcountmosquito`
                AND `adultsurveillance`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' $adult_date_condition
                GROUP BY `adultsurveillance`.`idadultsurveillance`)";
        
        $subQuery[3] = "(SELECT `larvalsurveillance`.`idlarvalsurveillance` AS id, 
            `larvalsurveillance`.`idlarvalsurveillance` AS `idlarvalsurveillance`, 
            `larvalsurveillance`.`date` AS `eventdate`, 
            'map_smmry_trap_cnt_excds_msqts' as event, 
            `larvalsurveillance`.`latitude` AS `latitude`, 
            `larvalsurveillance`.`longitude` AS `longitude`,
            SUM(`larvalsurveillancedetails`.`count`) AS `total`, 
            `lp`.`trapcountmosquito` AS `exceed`, 
            `sites`.`site`, 
            `larvalsurveillance`.`idsite`,
            CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`, 
            'map_smmry_trap_cnt_excds' as `type`, 
            'larvalsurveillance' as module
            FROM `larvalsurveillance`
            LEFT JOIN `sites` ON `larvalsurveillance`.`idsite` = `sites`.`idsite`
            LEFT JOIN `larvalsurveillancedetails` ON `larvalsurveillancedetails`.`idlarvalsurveillance` = `larvalsurveillance`.`idlarvalsurveillance` 
            LEFT JOIN `locationmosquitospecies` ON `larvalsurveillancedetails`.`idmosquitospecies` = `locationmosquitospecies`.`idmosquitospecies`  
            INNER JOIN `locationpreferences` AS lp ON `larvalsurveillance`.`idlocation` = `lp`.`idlocation`
            WHERE (SELECT SUM(`larvalsurveillancedetails`.`count`) FROM `larvalsurveillancedetails` WHERE `larvalsurveillancedetails`.`idlarvalsurveillance` = `larvalsurveillance`.`idlarvalsurveillance` GROUP BY `larvalsurveillance`.`idlarvalsurveillance`) >`lp`.`trapcountmosquito` 
            AND `larvalsurveillance`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' $larvalsurv_date_condition
            GROUP BY `larvalsurveillance`.`idlarvalsurveillance`)";
        
        $subQuery[4] = "(SELECT `larvaltreatments`.`idlarvaltreatment` AS id, 
            `larvaltreatments`.`idlarvaltreatment` AS `idlarvaltreatment`, 
            `sites`.`latitude` AS `latitude`, 
			`sites`.`longitude` AS `longitude`,
            SUM(`larvatreatmentdetails`.`count`) AS `total`,
            `lp`.`trapcountmosquito` AS `exceed`,
            `larvaltreatments`.`date` AS `eventdate`,
            'map_smmry_trap_cnt_excds_msqts' as event, 
            `sites`.`site`, 
            `larvaltreatments`.`idsite`,
            CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`, 
            'map_smmry_trap_cnt_excds' as `type`, 
            'lrvltrtmnt' as module
            FROM `larvaltreatments` 
            LEFT JOIN `sites` ON `larvaltreatments`.`idsite` = `sites`.`idsite`
            LEFT JOIN `larvatreatmentdetails` ON `larvatreatmentdetails`.`idlarvaltreatment` = `larvaltreatments`.`idlarvaltreatment` 
            LEFT JOIN `locationmosquitospecies` ON `larvatreatmentdetails`.`idmosquitospecies` = `locationmosquitospecies`.`idmosquitospecies` 
            INNER JOIN `locationpreferences` AS lp ON `larvaltreatments`.`idlocation` = `lp`.`idlocation` 
            WHERE (SELECT SUM(`larvatreatmentdetails`.`count`) FROM `larvatreatmentdetails` WHERE `larvatreatmentdetails`.`idlarvaltreatment` = `larvaltreatments`.`idlarvaltreatment` GROUP BY `larvaltreatments`.`idlarvaltreatment`) >`lp`.`trapcountmosquito` 
            AND `isdeleted` != '1'
            AND `larvaltreatments`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' $larvaltrt_date_condition
            GROUP BY `larvaltreatments`.`idlarvaltreatment`)";
        
        $subQuery[5] = "(SELECT `landingrates`.`idlandingrate` AS id, 
            `landingrates`.`idlandingrate` AS `idlandingrate`, 
            `landingrates`.`observeddate` AS `eventdate`, 
            'map_smmry_trap_cnt_excds_msqts' as event, 
            `sites`.`site`, 
            `landingrates`.`idsite`,
            `landingrates`.`latitude` AS `latitude`, 
			`landingrates`.`longitude` AS `longitude`,
            SUM(`landingratedetails`.`count`) AS `total`, 
            `lp`.`trapcountmosquito` AS `exceed`, 
            CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`, 
            'map_smmry_trap_cnt_excds' as `type`, 
            'landingrates' as module
            FROM `landingrates` 
            LEFT JOIN `sites` ON `landingrates`.`idsite` = `sites`.`idsite`
            LEFT JOIN `landingratedetails` ON `landingratedetails`.`idlandingrate` = `landingrates`.`idlandingrate` 
            LEFT JOIN `locationmosquitospecies` ON `landingratedetails`.`idlocationvectorspecies` = `locationmosquitospecies`.`idmosquitospecies` 
            INNER JOIN `locationpreferences` AS lp ON `landingrates`.`idlocation` = `lp`.`idlocation` 
            WHERE (SELECT SUM(`landingratedetails`.`count`) FROM `landingratedetails` WHERE `landingratedetails`.`idlandingrate` = `landingrates`.`idlandingrate` GROUP BY `landingrates`.`idlandingrate`) >`lp`.`trapcountmosquito` 
            AND `landingrates`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' $landing_date_condition
            GROUP BY `landingrates`.`observeddate` )";
        
        $subQuery[6] = "(SELECT `adultsurveillance`.`idadultsurveillance` AS id, 
                    `adultsurveillance`.`idadultsurveillance` AS `idadultsurveillance`, 
                    `adultsurveillance`.`pudate` AS `eventdate`, 
                    `traps`.`latitude` AS `latitude`,
                    `traps`.`longitude` AS `longitude`,
                    SUM(`adultsurveillancedetails`.`count`) AS `total`, 
                    `lp`.`trapcountvector` AS `exceed`, 
                    'map_smmry_trap_cnt_vctr_excds_msqts' as event, 
                    `sites`.`site`, 
                    `traps`.`idsite`,
                    CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`, 
                    'prfrncs_trap_cnt_vctr' as `type`, 
                    'adultsurveillance' as module
                    FROM `adultsurveillance`
                    LEFT JOIN `traps` ON `adultsurveillance`.`idtrap` = `traps`.`idtrap`
                    LEFT JOIN `sites` ON `traps`.`idsite` = `sites`.`idsite`
                    LEFT JOIN `adultsurveillancedetails` ON `adultsurveillancedetails`.`idadultsurveillance` = `adultsurveillance`.`idadultsurveillance` 
                    LEFT JOIN `locationvectorspecies` ON `adultsurveillancedetails`.`idmosquitospecies` = `locationvectorspecies`.`idlocationmosquitospecies` 
                    INNER JOIN `locationpreferences` AS lp ON `adultsurveillance`.`idlocation` = `lp`.`idlocation` 
                    WHERE (SELECT SUM(`adultsurveillancedetails`.`count`) FROM `adultsurveillancedetails` WHERE `adultsurveillancedetails`.`idadultsurveillance` = `adultsurveillance`.`idadultsurveillance` GROUP BY `adultsurveillance`.`idadultsurveillance`) >`lp`.`trapcountvector` 
                    AND `adultsurveillance`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' $adult_date_condition 
                    GROUP BY `adultsurveillance`.`idadultsurveillance`)";
        
        $subQuery[7] = "(SELECT `larvalsurveillance`.`idlarvalsurveillance` AS id, 
                `larvalsurveillance`.`idlarvalsurveillance` AS `idlarvalsurveillance`, 
                `larvalsurveillance`.`date` AS `eventdate`, 
                `larvalsurveillance`.`latitude` AS `latitude`, 
                `larvalsurveillance`.`longitude` AS `longitude`,
                SUM(`larvalsurveillancedetails`.`count`) AS `total`, 
                `lp`.`trapcountvector` AS `exceed`, 
                'map_smmry_trap_cnt_vctr_excds_msqts' as event, 
                `sites`.`site`, 
                `larvalsurveillance`.`idsite`,
                CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`, 
                'prfrncs_trap_cnt_vctr' as `type`, 
                'larvalsurveillance' as module
                FROM `larvalsurveillance`
                LEFT JOIN `sites` ON `larvalsurveillance`.`idsite` = `sites`.`idsite`
                LEFT JOIN `larvalsurveillancedetails` ON `larvalsurveillancedetails`.`idlarvalsurveillance` = `larvalsurveillance`.`idlarvalsurveillance` 
                LEFT JOIN `locationvectorspecies` ON `larvalsurveillancedetails`.`idmosquitospecies` = `locationvectorspecies`.`idlocationmosquitospecies`
                INNER JOIN `locationpreferences` AS lp ON `larvalsurveillance`.`idlocation` = `lp`.`idlocation` 
                WHERE (SELECT SUM(`larvalsurveillancedetails`.`count`) FROM `larvalsurveillancedetails` WHERE `larvalsurveillancedetails`.`idlarvalsurveillance` = `larvalsurveillance`.`idlarvalsurveillance` GROUP BY `larvalsurveillance`.`idlarvalsurveillance`) >`lp`.`trapcountvector` 
                AND `larvalsurveillance`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' $larvalsurv_date_condition
                GROUP BY `larvalsurveillance`.`idlarvalsurveillance` )";
        
        $subQuery[8] = "(SELECT `landingrates`.`idlandingrate` AS id, 
                `landingrates`.`idlandingrate` AS `idlandingrate`, 
                `landingrates`.`observeddate` AS `eventdate`,  
                `landingrates`.`latitude` AS `latitude`, 
				`landingrates`.`longitude` AS `longitude`,
                SUM(`landingratedetails`.`count`) AS `total`, 
                `lp`.`trapcountvector` AS `exceed`,                
                'map_smmry_trap_cnt_vctr_excds_msqts' as event, 
                `sites`.`site`, 
                `landingrates`.`idsite`,
                CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`, 
                'prfrncs_trap_cnt_vctr' as `type`, 
                'landingrates' as module
                FROM `landingrates` 
                LEFT JOIN `sites` ON `landingrates`.`idsite` = `sites`.`idsite`
                LEFT JOIN `landingratedetails` ON `landingratedetails`.`idlandingrate` = `landingrates`.`idlandingrate` 
                LEFT JOIN `locationvectorspecies` ON `landingratedetails`.`idlocationvectorspecies` = `locationvectorspecies`.`idlocationmosquitospecies` 
                INNER JOIN `locationpreferences` AS lp ON `landingrates`.`idlocation` = `lp`.`idlocation` 
                WHERE (SELECT SUM(`landingratedetails`.`count`) FROM `landingratedetails` WHERE `landingratedetails`.`idlandingrate` = `landingrates`.`idlandingrate` GROUP BY `landingrates`.`idlandingrate`) >`lp`.`trapcountvector` 
                AND `landingrates`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' $landing_date_condition
                GROUP BY `landingrates`.`idlandingrate` )";
        
        $subQuery[9] = "(SELECT `servicerequests`.`idservicerequest` AS id, 
                    `servicerequests`.`idservicerequest` AS `idservicerequest`, 
                    `servicerequests`.`opendate` AS `eventdate`,
                    `servicerequests`.`latitude` AS `latitude`, 
				    `servicerequests`.`longitude` AS `longitude`,   
                    COUNT(`servicerequests`.`idservicerequest`) AS `total`,
                    `lp`.`callsexceed` AS `exceed`,
                    'workassgnmnts' as event,
                    `sites`.`site`, 
                    `servicerequests`.`idsite`,
                    CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`, 
                    'sidebar_data_entry_wrk_asgnmnts' as `type`, 'workassgnmnts' as module
                    FROM `servicerequests`
                    LEFT JOIN `sites` ON `servicerequests`.`idsite` = `sites`.`idsite`
                    INNER JOIN `locationpreferences` AS lp ON `servicerequests`.`idlocation` = `lp`.`idlocation`
                    WHERE (SELECT COUNT(`s`.`idservicerequest`) FROM `servicerequests` AS `s` WHERE `s`.`idservicerequest` = `servicerequests`.`idservicerequest` GROUP BY `servicerequests`.`idservicerequest`) >`lp`.`callsexceed` 
                    AND `servicerequests`.`idlocation` IS NULL
                    AND `servicerequests`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' $work_assgnmnts_date_condition
                    GROUP BY `servicerequests`.`idsite`, `servicerequests`.`opendate`)";
        
        $subQuery[10] = "(SELECT `larvaltreatments`.`idlarvaltreatment` AS id, 
                `larvaltreatments`.`idlarvaltreatment` AS `idlarvaltreatment`, 
                `larvaltreatments`.`date` AS `eventdate`,
                `sites`.`latitude` AS `latitude`, 
				`sites`.`longitude` AS `longitude`,
                SUM(`larvatreatmentdetails`.`count`) AS `total`,
                `lp`.`trapcountvector` AS `exceed`, 
                'map_smmry_trap_cnt_vctr_excds_msqts' as event, 
                `sites`.`site`, 
                `larvaltreatments`.`idsite`,
                CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`, 
                'prfrncs_trap_cnt_vctr' as `type`, 
                'lrvltrtmnt' as module
                FROM `larvaltreatments` 
                LEFT JOIN `sites` ON `larvaltreatments`.`idsite` = `sites`.`idsite`
                LEFT JOIN `larvatreatmentdetails` ON `larvatreatmentdetails`.`idlarvaltreatment` = `larvaltreatments`.`idlarvaltreatment` 
                LEFT JOIN `locationvectorspecies` ON `larvatreatmentdetails`.`idmosquitospecies` = `locationvectorspecies`.`idlocationmosquitospecies`
                INNER JOIN `locationpreferences` AS lp ON `larvaltreatments`.`idlocation` = `lp`.`idlocation` 
                WHERE (SELECT SUM(`larvatreatmentdetails`.`count`) FROM `larvatreatmentdetails` WHERE `larvatreatmentdetails`.`idlarvaltreatment` = `larvaltreatments`.`idlarvaltreatment` GROUP BY `larvaltreatments`.`idlarvaltreatment`) >`lp`.`trapcountvector` 
                AND `isdeleted` != '1'
                AND `larvaltreatments`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' $larvaltrt_date_condition
                GROUP BY `larvaltreatments`.`idlarvaltreatment`)";
		
        $sql = "";
        $allFilter = array(0,1,2,3,4,5,6,7,8,9,10);
        
        foreach($allFilter as $kqry => $vqry){
            $sql .= $subQuery[$vqry] . " UNION ";
        }
		$sql = trim($sql, " UNION ");
        
        if(!empty($orderby)) {
            $order = explode('_', $orderby);
            $ord = array();
            foreach ($order as $o)
            {
                $o = explode(':', $o);
                if (!isset($o[1]) OR (strtolower($o[1]) != 'desc'))
                {
                    $ord[$o[0]] = 'ASC';
                }
                else
                {
                    $ord[$o[0]] = 'DESC';
                }
            }
            $order = $ord;
            
            $sort = '';
            if(!empty($columns)) {
                $i = 0;
                foreach ( $order as $key => $val ) {
                    foreach($columns as $fkey => $fval) {
                        if($fkey == $key) {
                            if($i == 0)
                                $sort = " ORDER BY ";
                            else
                                $sort .= ",";
                            $sort .= $fval['db_name']." ".$val;
                            $i++;
                        }
                    }
                }
            }
            $sql .= $sort;
        }
        
        if(empty($allsite)){
            if ($offset == 0)
                $sql .= " LIMIT " . $page_size;
            else
                $sql .= " LIMIT " . $page_size . "," . $offset;
				  
		}
        echo $sql;
        die;
		$query = $this->db->query ( $sql );
		if ($query->num_rows () > 0) {
            $result = $data = array();
            $result['result'] = array();
            if(!empty($filter_type)){
                $data = $query->result_array ();
                foreach($data as $key => $val) {
                    switch($filter_type){
                        case '1':
                            if($val['module'] == "adlttrtmnt")
                                array_push($result['result'], $val);
                            break;
                        case '2':
                            if($val['module'] == "lrvltrtmnt")
                                array_push($result['result'], $val);
                            break;
                        case '3':
                            if($val['module']== "landingrates")
                                array_push($result['result'], $val);
                            break;
                        case '4':
                            if($val['module'] == "workassgnmnts")
                                array_push($result['result'], $val);
                            break;
                        case '5':
                            if($val['module'] == "rainfall")
                                array_push($result['result'], $val);
                            break;
                    }
                }
            } else {
                $result['result'] = $query->result_array ();
            }
            
            $result['filter_date'] = $filter_date;
            $result['filter_daterange'] = $filter_daterange;
            $result['page'] = $page;
            $result['page_size'] = $page_size;
            return $result;
			 
		}
	}
	/**
	 * Function to get Get Map Data
	 */
	public function getMapData($result = '') {
		$data = array();
        $data['data'] = array();
        //print'<pre>';
//        print_r($result);
//        die;
        $data['filter_date'] = $result['filter_date'];
        $data['filter_daterange'] = $result['filter_daterange'];
        $data['page'] = $result['page'];
        $data['page_size'] = $result['page_size'];
        $data['orderby'] = $result['orderby'];
        
        if(!empty($result) && isset($result['result']))
		foreach ( $result['result'] as $key => $val ) {
			$last_24_hr = 0;
			$last_week = 0;
			$last_mnth = 0;
			$last_year = 0;
            
            if(in_array($val->event, $this->eventArray)) {
                continue;
            }
            $yday = date ( 'Y-m-d', strtotime ( "-1 day" ) );
			if ($val->eventdate > $yday && $val->eventdate <= date ( 'Y-m-d' )) {
				$last_24_hr += $val->total;
			}
            
			$yday = date ( 'Y-m-d', strtotime ( "-1 week" ) );
			if ($val->eventdate > $yday && $val->eventdate <= date ( 'Y-m-d' )) {
				$last_week += $val->total;
			}
			
			$yday = date ( 'Y-m-d', strtotime ( "-1 month" ) );
			if ($val->eventdate > $yday && $val->eventdate <= date ( 'Y-m-d' )) {
				$last_mnth += $val->total;
			}
			
			$yday = date ( 'Y-m-d', strtotime ( "-1 year" ) );
			if ($val->eventdate > $yday && $val->eventdate <= date ( 'Y-m-d' )) {
				$last_year += $val->total;
			}
            
			if (is_numeric ( $val->latitude ) && is_numeric ( $val->longitude )) {
				$data['data'] [$key] ['last_24_hr'] = number_format ( $last_24_hr, 2, '.', '' );
				$data['data'] [$key] ['last_week'] = number_format ( $last_week, 2, '.', '' );
				$data['data'] [$key] ['last_month'] = number_format ( $last_mnth, 2, '.', '' );
				$data['data'] [$key] ['last_year'] = number_format ( $last_year, 2, '.', '' );
				$data['data'] [$key] ['sensor_name'] = $val->event;
				$data['data'] [$key] ['latitude'] = $val->latitude;
				$data['data'] [$key] ['longitude'] = $val->longitude;
				$data['data'] [$key] ['id'] = $val->id;
                $data['data'] [$key] ['total'] = $val->total;
                $data['data'] [$key] ['eventdate'] = $val->eventdate;
                $data['data'] [$key] ['site'] = $val->site;
			}
		}
        
		return $data;
	}
	/**
	 * Function to get Get Map Data For Traps
	 */
	public function getMapDataTarp() {
		$sql = "SELECT `adultsurveillance`.`idadultsurveillance` AS id, 
				`adultsurveillance`.`idadultsurveillance` AS `idadultsurveillance`, 
				`adultsurveillance`.`pudate` AS `eventdate`,  
				SUM(`adultsurveillance`.`totalcount`) AS `total`, 
				'Max Trap Count Vector Mosquitos' as event, 
				`traps`.`latitude` AS `latitude`, 
				`traps`.`longitude` AS `longitude` , 
				`sites`.`site` , 
				`sites`.`address1` , 
				`sites`.`address2` , 
				`sites`.`city` , 
				`traps`.`trap` ,
				`tt`.`traptype` 
				FROM (`adultsurveillance`) 
				LEFT JOIN `adultsurveillancedetails` ON `adultsurveillancedetails`.`idadultsurveillance` = `adultsurveillance`.`idadultsurveillance` 
				LEFT JOIN `traps` ON `adultsurveillance`.`idtrap` = `traps`.`idtrap` 
				LEFT JOIN `traptypes` AS `tt` ON `traps`.`idtraptype` = `tt`.`idtraptype` 
				LEFT JOIN `sites` ON `traps`.`idsite`=`sites`.`idsite` 
				INNER JOIN `locations` ON `sites`.`idlocation` = `locations`.`idlocation` 
				INNER JOIN `locationpreferences` AS lp ON `locations`.`idlocation` = `lp`.`idlocation` 
				WHERE `adultsurveillance`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' 
				AND `sites`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' 
				AND `adultsurveillance`.`totalcount` >`lp`.`trapcountvector`";
		$filter_date = $this->input->get ( 'filter_date' );
		$ttl = $this->input->get ( 'ttl' );
		$page = $this->input->get ( 'page' );
		$setfromdate = $this->input->get ( 'setfromdate' );
		$settodate = $this->input->get ( 'settodate' );
		
		if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 2;
		
		if (! isset ( $ttl ) || $ttl == '')
			$ttl = 10;
		
		if (! isset ( $page ) || $page == '')
			$page = 1;
		
		if (! is_null ( $filter_date ) && empty ( $setfromdate ) && empty ( $settodate )) {
			switch ($filter_date) {
				case '1' :
					$sql .= " AND `adultsurveillance`.`pudate` >= '" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' 
							AND `adultsurveillance`.`pudate` <= '" . date ( 'Y-m-d' ) . "'";
					break;
				
				case '2' :
					$sql .= " AND `adultsurveillance`.`pudate` >= '" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' 
							AND `adultsurveillance`.`pudate` <= '" . date ( 'Y-m-d' ) . "'";
					break;
				case '3' :
					$sql .= " AND `adultsurveillance`.`pudate` >= '" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' 
							AND `adultsurveillance`.`pudate` <= '" . date ( 'Y-m-d' ) . "'";
					break;
				case '4' :
					$sql .= " AND `adultsurveillance`.`pudate` >= '" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' 
							AND `adultsurveillance`.`pudate` <= '" . date ( 'Y-m-d' ) . "'";
					break;
				case '5' :
					$sql .= " AND `adultsurveillance`.`pudate` >= '" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' 
							AND `adultsurveillance`.`pudate` <= '" . date ( 'Y-m-d' ) . "'";
					break;
			}
		} else if (! empty ( $setfromdate ) && ! empty ( $settodate )) {
			$sql .= " AND adultsurveillance.pudate" . " >= '" . $setfromdate . "'";
			$sql .= " AND adultsurveillance.pudate" . " <= '" . $settodate . "'";
		}
		
		$sql .= " GROUP BY `adultsurveillance`.`totalcount`";
		
		if (! is_null ( $ttl ) && ! is_null ( $page )) {
			if ($page == 1)
				$page = 0;
			else
				$page --;
			
			$page *= 10;
			
			if ($page == 0)
				$sql .= " LIMIT $ttl";
			else
				$sql .= " LIMIT $ttl,$page";
		} else if (! is_null ( $ttl )) {
			$sql .= " LIMIT $ttl";
		}
		// echo $sql;
		
		$query = $this->db->query ( $sql );
		if ($query->num_rows () > 0) {
			$result = $query->result_array ();
		}
		
		$i = 0;
		foreach ( $result as $key => $val ) {
			$data [$i] ['id'] = $val ['id'];
			$data [$i] ['trap'] = $val ['trap'];
			$data [$i] ['traptype'] = $val ['traptype'];
			
			if (! empty ( $val ['eventdate'] ))
				$data [$i] ['date'] = date ( 'm/d/Y', strtotime ( $val ['eventdate'] ) );
			else
				$data [$i] ['date'] = '';
			$addr = '';
			
			if (! empty ( $val ['address1'] ) && ! empty ( $val ['address2'] ))
				$addr = $val ['address1'] . ' ' . $val ['address2'];
			else if ($val ['address1'])
				$addr = $val ['address1'];
			else if ($val ['address2'])
				$addr = $val ['address2'];
			
			$data [$i] ['address'] = $addr;
			$data [$i] ['city'] = $val ['city'];
			$data [$i] ['total'] = $val ['total'];
			$data [$i] ['latitude'] = $val ['latitude'];
			$data [$i] ['longitude'] = $val ['longitude'];
			$i ++;
		}
		// print'<pre>';
		// print_r($data);
		// die;
		return $data;
	}
	function getmaparray($startdate = '',$enddate = '')
	{
		$startdate_arr = explode("/",$startdate);
        $startdate = $startdate_arr[2]."-".$startdate_arr[0]."-".$startdate_arr[1];
        $all_fields = $this->input->get_post('all_fields_1');
        
        $enddate_arr = explode("/",$enddate);
        $enddate = $enddate_arr[2]."-".$enddate_arr[0]."-".$enddate_arr[1];
		$this->db->select ( 'w.idweather,w.date AS rainfall date,w.rainfall AS rainfall total,ws.latitude,ws.longitude, lp.rainfallexceeds,w.idlocation' );
		$this->db->from ( 'weather AS w' );
		$this->db->join ( 'locationpreferences as lp', 'w.idlocation  = lp.idlocation', 'LEFT OUTER' );
		$this->db->join ( 'weathersensors as ws', 'w.idweathersensor = ws.idweathersensor', 'LEFT OUTER' );
		$this->db->where ( 'w.rainfall >= ','lp.rainfallexceeds' );
		$this->db->where ( 'w.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$query = $this->db->get();
		if ($query->num_rows () > 0) {
			$result = $query->result_array ();
		}
		
	}
}
?>