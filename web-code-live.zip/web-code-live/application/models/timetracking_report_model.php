<?php
error_reporting(0);
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class timetracking_report_model extends CI_Model {
	public $data = array();
	
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
		$this->load->database();
	}
	
	/**
	 * Function to fetch timetracking report data
	 */

	public function getTimeTrackingReport($startdate = '', $enddate = '', $siteId = '', $siteGroupId = '', $users) {
		$startdate_arr = explode ( "/", $startdate );
		$startdate = $startdate_arr [2] . "-" . $startdate_arr [0] . "-" . $startdate_arr [1];
		//log_message('debug','Skysoft Debugging -------------->>>>> Date start is ....... '.$startdate);

		$enddate_arr = explode ( "/", $enddate );
		$enddate = $enddate_arr [2] . "-" . $enddate_arr [0] . "-" . $enddate_arr [1] . " 23:59:59";
		//log_message('debug','Skysoft Debugging -------------->>>>> Date end is ....... '.$enddate);

		if(empty($siteId) && !empty($siteGroupId)) {
			//log_message('debug','Skysoft Debugging -------------->>>>> Enter in first if .................................. ');
			$this->db->select ( 'tt.idtimetracking, tt.geopromodelid,  tt.startDateAndTime, tt.idDuplicateSite,tt.isCancelled,
				tt.endDateAndTime, tt.idDuplicateGpRecord, tt.isdeleted, site.idsite, site.site, site.address1, site.city,user.username,user.firstname,user.lastname,
				site.idlocation, site.billable, ac.idactivitycode,ac.activitycode,ac.idactivitycodetype,ac.activitycode,
				ac.idlocation, act.idactivitycodetype,act.activitycodetype');
			$this->db->from ( 'timetracking AS tt' );
			$this->db->join ( 'activitycodes AS ac', "tt.acitvityid = ac.idactivitycode", 'left outer' );
			$this->db->join ( 'activitycodetypes AS act', "act.idactivitycodetype = ac.idactivitycodetype", 'left outer' );
			$this->db->join ( 'geopromodules AS gpm', "gpm.idgeopromodule = tt.geopromodelid", 'left outer' );
			$this->db->join ( 'sites AS site', "site.idsite = tt.siteId", 'left outer');
			$this->db->join ( 'users as user', "user.iduser = tt.userid", 'left outer' );
			$this->db->join( 'sitegroups as sg', "sg.idsitegroup = site.idsitegroup", 'left outer');
			$this->db->where ( 'tt.startDateAndTime >=', $startdate );
			$this->db->where ( 'tt.endDateAndTime <=', $enddate );
			$this->db->where ('tt.startDateAndTime !=', '0000-00-00 00:00:00' );
			$this->db->where( 'tt.endDateAndTime !=', '0000-00-00 00:00:00' );
			$this->db->where ( 'tt.idLocation =', $this->session->userdata ( 'idlocation' ));
			$this->db->where ( 'tt.isdeleted', '0' );
			$this->db->where('sg.idsitegroup=', $siteGroupId);
		} else {
			//log_message('debug','Skysoft Debugging -------------->>>>> Enter in second if ........................................... ');
			$this->db->select ( 'tt.idtimetracking, tt.geopromodelid,  tt.startDateAndTime, tt.idDuplicateSite,tt.isCancelled,
				tt.endDateAndTime, tt.idDuplicateGpRecord, tt.isdeleted, site.idsite, site.site, site.address1, site.city,user.username,user.firstname,user.lastname,
				site.idlocation, site.billable, ac.idactivitycode,ac.activitycode,ac.idactivitycodetype,ac.activitycode,
				ac.idlocation, act.idactivitycodetype,act.activitycodetype');
			$this->db->from ( 'timetracking AS tt' );
			$this->db->join ( 'activitycodes AS ac', "tt.acitvityid = ac.idactivitycode", 'left outer' );
			$this->db->join ( 'activitycodetypes AS act', "act.idactivitycodetype = ac.idactivitycodetype", 'left outer' );
			$this->db->join ( 'geopromodules AS gpm', "gpm.idgeopromodule = tt.geopromodelid", 'left outer' );
			$this->db->join ( 'sites AS site', "site.idsite = tt.siteId", 'left outer');
			$this->db->join ( 'users as user', "user.iduser = tt.userid", 'left outer' );
			$this->db->where ( 'tt.startDateAndTime >=', $startdate );
			$this->db->where ( 'tt.endDateAndTime <=', $enddate );
			$this->db->where ('tt.startDateAndTime !=', '0000-00-00 00:00:00' );
			$this->db->where( 'tt.endDateAndTime !=', '0000-00-00 00:00:00' );
			$this->db->where ( 'tt.isdeleted', '0' );
			$this->db->where('tt.isCancelled', '0');
			$this->db->where ( 'tt.idLocation =', $this->session->userdata ( 'idlocation' ));
			//log_message('debug','Skysoft Debugging -------------->>>>> user id location is .........Data is....... '.$this->session->userdata ( 'idlocation' ));
			if(! empty($siteId)) {
				$this->db->where('tt.siteId', $siteId);
			}
		}
		//log_message('debug','Skysoft Debugging -------------->>>>>user that are existed .................... '.print_r($users,1));
		if(sizeof($users)>=1 && $users[0]!="") {
			$this->db->where_in('tt.userid',$users);
		}

		$query = $this->db->get();
		$data = $query->result();
		$products_size = sizeof($data);
		//log_message('debug','Skysoft Debugging -------------->>>>> Data is....... '.print_r($data,1));
		 for ($i = 0; $i < $products_size; $i++ ) {
			if( !empty($data[$i]->idDuplicateGpRecord) &&  $data[$i]->geopromodelid != 9 ) {
				//log_message('debug','Skysoft Debugging -------------->>>>> App id is ....... '.$data[$i]->appid);
				$data[$i] = $this->getDetailOfModule($data[$i]);
				//log_message('debug','Skysoft Debugging -------------->>>>> Detail is ....... '.print_r($data[$i],1));
			} else {
				//log_message('debug','Skysoft Debugging -------------->>>>> id duplicate is empty ....... '.$data[$i]->geopromodelid);
				$data[$i]->comments = '';
				$data[$i]->productname = '';
				$data[$i]->mosquitoes = '';
				$data[$i]->productapplied = '';
			}
		}

		for($i = 0; $i < $products_size; $i++) {
			if($data[$i]->idDuplicateSite != '0') {
				//log_message('debug','Skysoft Debugging -------------->>>>> site duplicate check is ....... '.$data[$i]->idDuplicateSite);
				$result = $this->getSiteDetail($data[$i]->idDuplicateSite);
				if(sizeof($result)>=1) {
					$data[$i]->idsite = $result[0]->idsite;
					$data[$i]->site = $result[0]->site;
					$data[$i]->address1 = $result[0]->address1;
				}
			}
		}

		//log_message('debug','Skysoft Debugging -------------->>>>> final  Data is ....... '.print_r($data,1));
		return $data;
	}

	public function getUsersOfReport($users) {
		$this->db->select('distinct(tt.userid),user.username,user.firstname,user.lastname');
		$this->db->from('timetracking AS tt');
		$this->db->join('users AS user',"user.iduser = tt.userid",'left outer');
		$this->db->order_by('firstname' , 'ASC');
		$this->db->order_by('lastname' , 'ASC');
		$query = $this->db->get();
		$data = $query->result();
		$value="";
		if(sizeof($users)==1 && $users[0]=='')
			$this->str = "<option value='".$value."' selected='true'>All Users</options>";
		else
			$this->str = "<option value='".$value."'>All Users</options>";
	
		//log_message('debug','Skysoft Debugging -------------->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>>> size of users....... '.sizeof($users));
		if ($query->num_rows () > 0) {
			if(sizeof($users) <= 1 && $users[0]=="") {
				foreach ( $query->result_array () as $row ) {
				    $this->str .= '<option value="'.$row['userid'] . '">' . $row['firstname'] . " " . $row['lastname'] . '</option>';
				}
			} else {
				foreach ( $query->result_array () as $row ) {
					if(in_array($row['userid'],$users) == 1)
					    $this->str .= '<option value="'.$row['userid'] . '" selected="true">' . $row['firstname'] . " " . $row['lastname'] . '</option>';
					else
					    $this->str .= '<option value="'.$row['userid'] . '">' . $row['firstname'] . " " . $row['lastname'] . '</option>';
				}
			}
		}
		return $this->str;
	}
	public function getDetailOfModule($data) {
		if($data->geopromodelid == 1) {
			return $this->getAdultSurveillance($data);
		} else if($data->geopromodelid == 2) {
			return $this->getLarvalSurveillance($data);
		} else if($data->geopromodelid == 3) {
			return $this->getArbovirallabs($data);
		} else if($data->geopromodelid == 4 ) {
			return $this->getCorvidlabs($data);
		} else if($data->geopromodelid == 5) {
			return $this->getServiceRequest($data);
		} else if($data->geopromodelid == 6) {
			return $this->getLarvalTreatments($data);
		} else if($data->geopromodelid == 7) {
			return $this->getAdulticideTreatments($data);
		} else if($data->geopromodelid == 8) {
			return $this->getWeather($data);
		} else  if($data->geopromodelid == 10) {
			$result = $this->getLarvalTreatments($data);
			if(!($result->find)) {
               // log_message('debug','Skysoft Debugging -------------->>>>>data will check in adulticidetreatments ....... ');
				$result = $this->getAdulticideTreatments($data);
				return $result;
			} else {
                //log_message('debug','Skysoft Debugging -------------->>>>>data will check in laravaltreatment ....... ');
				return $result;
			}
		}
		else {
			$data->comments = '';
			$data->productname = '';
			$data->mosquitoes = '';
			$data->productapplied = '';
			return $data;
		}
	}

	public function getAdultSurveillance($data) {
		$this->db->select ('ads.idadultsurveillance,ads.comments,mos.mosquitospecies,adt.idmosquitospecies,adt.count');
		$this->db->from ( 'adultsurveillance AS ads' );
		$this->db->join ( 'adultsurveillancedetails AS adt', "adt.idadultsurveillance = ads.idadultsurveillance", 'left outer' );
		$this->db->join ( 'mosquitospecies AS mos', "mos.idmosquitospecies = adt.idmosquitospecies", 'left outer' );
		$this->db->where ( 'ads.appid =', $data->idDuplicateGpRecord);
		$query = $this->db->get();
		$dataAdultSurvelliance = $query->result();
		//log_message('debug','Skysoft Debugging -------------->>>>> $dataAdultSurvelliance is ....... '.print_r($dataAdultSurvelliance,1));
		$count = sizeof($dataAdultSurvelliance);
		$species = '';
		$comments = '';
		for($i = 0; $i < $count; $i++) {
			$species = $dataAdultSurvelliance[$i]->mosquitospecies . ', ' . $species;
			$comments = $dataAdultSurvelliance[$i]->comments;
		}
		$data->comments = $comments;
		$data->mosquitoes = $species;
		$data->productname = '';
		$data->productapplied = '';
		return $data;
	}
	
	public function getLarvalTreatments($data) {
	    $this->db->select ('lt.idlarvaltreatment,lt.comments,mos.idmosquitospecies, lt.totalproductapplied, mos.mosquitospecies, pr.idproduct, pr.productname');
	    $this->db->from ( 'larvaltreatments AS lt' );
	    $this->db->join ( 'products AS pr', "pr.idproduct = lt.idproduct", 'left outer' );
	    $this->db->join ('larvatreatmentdetails AS lsd', "lsd.idlarvaltreatment = lt.idlarvaltreatment", 'left outer');
	    $this->db->join ( 'mosquitospecies AS mos', "mos.idmosquitospecies = lsd.idmosquitospecies", 'left outer' );
	    $this->db->where ( 'lt.appid =', $data->idDuplicateGpRecord);
	    $query = $this->db->get();
	    $dataLarvalTreatments = $query->result();
	    $count = sizeof($dataLarvalTreatments);
	    $mosquitos = '';
	    $count = sizeof($dataLarvalTreatments);
	    //log_message('debug','Skysoft Debugging -------------->>>>>  $dataLarvalTreatments is ....... '.print_r($dataLarvalTreatments,1));
	    if($count >= 1 ) {
	        $data->comments = $dataLarvalTreatments[0]->comments;
	        $data->productname = $dataLarvalTreatments[0]->productname;
	        $data->productapplied = $dataLarvalTreatments[0]->totalproductapplied;
	        $data->find = true;
	        for($i = 0; $i < $count; $i++) {
	            $mosquitos = $dataLarvalTreatments[$i]->mosquitospecies . ',' . $mosquitos ;
	        }
	        $data->mosquitoes = $mosquitos;
	    } else {
	        $data->comments = '';
	        $data->productname = '';
	        $data->mosquitoes = '';
	        $data->productapplied = '';
	        $data->find = false;
	    }
	    return $data;
	}
	public function getLarvalSurveillance($data) {
	    $this->db->select ('ls.idlarvalsurveillance, ls.comments, mos.mosquitospecies, lsd.idmosquitospecies, lsd.count');
	    $this->db->from ( 'larvalsurveillance AS ls' );
	    $this->db->join ( 'larvalsurveillancedetails AS lsd', "lsd.idlarvalsurveillance = ls.idlarvalsurveillance", 'left outer' );
	    $this->db->join ( 'mosquitospecies AS mos', "mos.idmosquitospecies = lsd.idmosquitospecies", 'left outer' );
	    $this->db->where ( 'ls.appid =', $data->idDuplicateGpRecord);
	    $query = $this->db->get();
	    $dataLarvalSurveillance = $query->result();
	    $count = sizeof($dataLarvalSurveillance);
	    $mosquitos = '';
	    $count = sizeof($dataLarvalSurveillance);
	    //log_message('debug','Skysoft Debugging -------------->>>>>  $dataLarvalSurveillance is ....... '.print_r($dataLarvalSurveillance,1));
	    if($count >= 1 ) {
	        $data->comments = $dataLarvalSurveillance[0]->comments;
	        $data->productname = '';
	        $data->productapplied = '';
	        $data->find = true;
	        for($i = 0; $i < $count; $i++) {
	            $mosquitos = $dataLarvalSurveillance[$i]->mosquitospecies . ',' . $mosquitos ;
	        }
	        $data->mosquitoes = $mosquitos;
	    } else {
	        $data->comments = '';
	        $data->productname = '';
	        $data->mosquitoes = '';
	        $data->productapplied = '';
	        $data->find = false;
	    }
	    return $data;
	}
	public function getArbovirallabs($data) {
		$this->db->select ('al.comments,mos.mosquitospecies');
		$this->db->from ( 'arbovirallabs AS al' );
		$this->db->join ( 'mosquitospecies AS mos', "mos.idmosquitospecies = al.idmosquitospecies", 'left outer' );
		$this->db->where ( 'al.appid =', $data->idDuplicateGpRecord);
		$query = $this->db->get();
		$dataArbovirallabs = $query->result();
		//log_message('debug','Skysoft Debugging -------------->>>>> $dataArbovirallabs is ....... '.print_r($dataArbovirallabs,1));
		if(sizeof($dataArbovirallabs) >= 1) {
			$data->comments = $dataArbovirallabs[0]->comments;
			$data->mosquitoes = $dataArbovirallabs[0]->mosquitospecies;
		} else {
			$data->comments = '';
			$data->mosquitoes = '';
		}

		$data->productname = '';
		$data->productapplied = '';
		return $data;
	}

	public function getWeather($data) {
		$this->db->select ('*');
		$this->db->from ( 'weather AS wet' );
		$this->db->where('wet.appid =', $data->idDuplicateGpRecord);
		$query = $this->db->get();
		$dataWeather = $query->result();
		//log_message('debug','Skysoft Debugging -------------->>>>> $dataWeather is ....... '.print_r($dataWeather,1));
		$data->comments = '';
		$data->productname = '';
		$data->mosquitoes = '';
		$data->productapplied = '';
		return $data;
	}

	public function getServiceRequest($data) {
		$this->db->select ('sr.comments');
		$this->db->from ( 'servicerequests AS sr' );
		$this->db->where('sr.appid =', $data->idDuplicateGpRecord);
		$query = $this->db->get();
		$dataServiceRequest = $query->result();
		//log_message('debug','Skysoft Debugging -------------->>>>> $dataServiceRequest is ....... '.print_r($dataServiceRequest,1));
		if(sizeof($dataServiceRequest) >= 1) {
			$data->comments = $dataServiceRequest[0]->comments;
		} else {
			$data->comments = '';
		}
		$data->productname = '';
		$data->mosquitoes = '';
		$data->productapplied = '';
		return $data;
	}

	public function getCorvidlabs($data) {
		$this->db->select ('ls.comments');
		$this->db->from ( 'corvidlabs AS ls' );
		$this->db->where('ls.appid =', $data->idDuplicateGpRecord);
		$query = $this->db->get();
		$dataCorvidlabs = $query->result();
		//log_message('debug','Skysoft Debugging -------------->>>>> $dataCorvidlabs is ....... '.print_r($dataCorvidlabs,1));
		if(sizeof($dataCorvidlabs) >= 1) {
			$data->comments = $dataCorvidlabs[0]->comments;
		} else {
			$data->comments = '';
		}
		$data->productname = '';
		$data->mosquitoes = '';
		$data->productapplied = '';
		return $data;
	}

	

	public function getAdulticideTreatments($data) {
		$this->db->select ('adt.idadulticidetreatment,adt.comments,adt.totalproductapplied,pr.productname');
		$this->db->from ( 'adulticidetreatments AS adt' );
		$this->db->join ( 'products AS pr', "pr.idproduct = adt.idproduct", 'left outer' );
		$this->db->where ( 'adt.appid =', $data->idDuplicateGpRecord);
		$query = $this->db->get();
		$dataAdulticideTreatments = $query->result();
		//log_message('debug','Skysoft Debugging -------------->>>>>  $dataAdulticideTreatments is ....... '.print_r($dataAdulticideTreatments,1));
		if(sizeof($dataAdulticideTreatments) >= 1){
			$data->comments = $dataAdulticideTreatments[0]->comments;
			$data->productname = $dataAdulticideTreatments[0]->productname;
			$data->productapplied = $dataAdulticideTreatments[0]->totalproductapplied;
			$data->mosquitoes = '';
			$data->find = true;
		} else {
			$data->comments = '';
			$data->productname ='';
			$data->productapplied = '';
			$data->mosquitoes = '';
			$data->find = false;
		}

		return $data;
	}

	public function getSiteDetail($siteId) {
		$this->db->select ('site.idsite, site.site, site.address1');
		$this->db->from ( 'sites as site');
		$this->db->where ( 'site.appid =', $siteId);
		$query = $this->db->get();
		$siteDetail = $query->result();
		//log_message('debug','Skysoft Debugging -------------->>>>>>>> site detail is....... '.print_r($siteDetail,1));
		return $siteDetail;
	}
}
