<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Sentinelchicken_report_model extends CI_Model {
	public $data = "";
	
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to fetch Sentinel Chicken Labs
	 */
	public function getSentinelchicken($startdate = '', $enddate = '') {
		$startdate_arr = explode ( "/", $startdate );
		$startdate = $startdate_arr [2] . "-" . $startdate_arr [0] . "-" . $startdate_arr [1];
		
		$enddate_arr = explode ( "/", $enddate );
		$enddate = $enddate_arr [2] . "-" . $enddate_arr [0] . "-" . $enddate_arr [1];
		
		$this->db->select ( 'scl.*,
				z.zone,
				l.labresult,
				at.assaytype,
				m.mosquitospecies,
				usr.firstname,
				usr.middlename,
				usr.lastname' );
		$this->db->from ( 'sentinelchickenlabs AS scl' );
		$this->db->join ( 'traps AS t', 'scl.idtrap = t.idtrap', "LEFT" );
		$this->db->join ( 'sites AS s', 't.idsite = s.idsite', "LEFT" );
		$this->db->join ( 'zones AS z', 's.idzone = z.idzone', "LEFT" );
		$this->db->join ( 'labresults AS l', 'scl.idlabresult = l.idlabresult', "LEFT" );
		$this->db->join ( 'assaytypes AS at', 'scl.idassaytype = at.idassaytype', "LEFT" );
		$this->db->join ( 'mosquitospecies AS m', 'a.idmosquitospecies = m.idmosquitospecies', "LEFT" );
		$this->db->join ( 'users AS usr', 'scl.idlabtechnician = usr.iduser', "LEFT" );
		$this->db->join ( 'locations AS lc', "s.idlocation = lc.idlocation", 'INNER' );
		$this->db->where ( 'lc.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'testdate >=', $startdate );
		$this->db->where ( 'testdate <=', $enddate );
		$this->db->order_by ( 't.trap', 'asc' );
		$query = $this->db->get ();
		// echo $this->db->last_query();
		// die;
		$result = array ();
		if ($query->num_rows () > 0) {
			$k = - 1;
			$i = 0;
			$flag = "";
			foreach ( $query->result_array () as $key => $val ) {
				$this->db->select ( 'ad.pudate' );
				$this->db->from ( 'traps AS t' );
				$this->db->join ( '`adultsurveillance` AS ad', 't.idtrap = ad.idtrap' );
				$this->db->where ( 't.idtrap', $val ['idtrap'] );
				
				$q = $this->db->get ();
				$datecollected = "";
				if ($q->num_rows () > 0) {
					$datecollected = $q->result_array ();
					$datecollected = $datecollected [0] ['pudate'];
				}
				
				if ($flag != $val ['idtrap']) {
					$i = 0;
					$k ++;
				}
				$this->data [$k] ['trap'] [$i] = $val;
				$this->data [$k] ['trap'] [$i] ['datecollected'] = $datecollected;
				$flag = $val ['idtrap'];
				$i ++;
			}
			// print'<pre>';
			// print_r($this->data);
			// die;
			return $this->data;
		}
		
		return $result;
	}
	
	/**
	 * Function to generate XML
	 */
	public function getXML($startdate = '', $enddate = '') {
		$startdate_arr = explode ( "/", $startdate );
		$startdate = $startdate_arr [2] . "-" . $startdate_arr [0] . "-" . $startdate_arr [1];
		
		$enddate_arr = explode ( "/", $enddate );
		$enddate = $enddate_arr [2] . "-" . $enddate_arr [0] . "-" . $enddate_arr [1];
		
		$this->db->select ( 'a.*,
				t.trap,
				z.zone,
				l.labresult,
				at.assaytype,
				m.mosquitospecies,
				usr.firstname,
				usr.middlename,
				usr.lastname' );
		$this->db->from ( 'arbovirallabs AS a' );
		$this->db->join ( 'traps AS t', 'a.idtrap = t.idtrap', "LEFT" );
		$this->db->join ( 'sites AS s', 't.idsite = s.idsite', "LEFT" );
		$this->db->join ( 'zones AS z', 's.idzone = z.idzone', "LEFT" );
		$this->db->join ( 'labresults AS l', 'a.idlabresult = l.idlabresult', "LEFT" );
		$this->db->join ( 'assaytypes AS at', 'a.idassaytype = at.idassaytype', "LEFT" );
		$this->db->join ( 'mosquitospecies AS m', 'a.idmosquitospecies = m.idmosquitospecies', "LEFT" );
		$this->db->join ( 'users AS usr', 'a.idlabtechnician = usr.iduser', "LEFT" );
		$this->db->join ( 'locations AS lc', "s.idlocation = lc.idlocation", 'INNER' );
		$this->db->where ( 'lc.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$this->db->where ( 'testdate >=', $startdate );
		$this->db->where ( 'testdate <=', $enddate );
		$this->db->order_by ( 't.trap', 'asc' );
		$query = $this->db->get ();
		
		return $query;
	}
}
