<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Arbovirallab_model extends CI_Model {
	public $str = "";
	public $map = "";
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to Add a new Zone
	 */
	public function addArbovirallab($message = '') {
		$idloc = $this->session->userdata ( 'idlocation' );
		$idtrap = $this->input->post ( 'idtrap' );
		$dateselected = $this->input->post ( 'dateselected' );
		$species = $this->input->post ( 'species' );
		
        $assay_type = $this->input->post('assay_type');
        $lab_result = $this->input->post('lab_result');
        $lab_technician = $this->input->post('lab_technician');
		 
		$idadultsurveillance = $this->input->post ( 'dateselected' );
		
        $detected_virus = $this->input->post('detected_virus');
        $rampunits = $this->input->post('rampunits');
        $rtprcconfirm = $this->input->post('confirm');
        $resultscorresspond = $this->input->post('result');
        
        $testdate = $this->input->post('testdate');
		 
		$this->load->model('usermodel');
		$data ['userId'] = $this->usermodel->getUserId();
		
		$data ['idtrap'] = ! empty ( $idtrap ) ? $idtrap : 0;
		$data ['labassayid'] = $this->input->post ( 'labassayid' );
		$data ['idmosquitospecies'] = ! empty ( $species ) ? $species : 0;
		$data['testdate'] = !empty($testdate)?date('Y-m-d',strtotime($testdate)):'0000-00-00';
		// $data['timestamp'] = strtotime($data['testdate']);
		
        $data['idassaytype'] = !empty($assay_type)?$assay_type:0;
        $data['idlabresult'] = !empty($lab_result)?$lab_result:0;
        $data['idlabtechnician'] = !empty($lab_technician)?$lab_technician:0;
        $data['idvirustype'] = !empty($detected_virus)?$detected_virus:0;

		$data ['poolsize'] = $this->input->post ( 'poolsize' );
		$data ['idadultsurveillance'] = ! empty ( $idadultsurveillance ) ? $idadultsurveillance : 0;
		$data ['comments'] = $this->input->post ( 'comment' );

        $data['rampunits'] = !empty($rampunits)?$rampunits:'';
        $data['rtprcconfirm'] = !empty($rtprcconfirm)? '1' : '0' ;
        $data['resultscorresspond'] = !empty($resultscorresspond)? '1' : '0' ;

		$data ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
		
		$this->db->query ( "SET foreign_key_checks = 0" );
		$this->db->insert ( 'arbovirallabs', $data );
		$id = $this->db->insert_id ();
		$rows = $this->db->affected_rows ();
		$this->db->query ( "SET foreign_key_checks = 1" );
		
		// $rows = 1;
		if (empty ( $rows ) && empty ( $id ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to Update a new Arbovirallab
	 */
	public function updateArbovirallab() {
		$id = $this->input->post ( 'idarbovirallab' );
		
		if (empty ( $id ))
			return false;
		
		$species = $this->input->post ( 'species' );
		
        $assay_type = $this->input->post('assay_type');
        $lab_result = $this->input->post('lab_result');
        $lab_technician = $this->input->post('lab_technician');
        $detected_virus = $this->input->post('detected_virus');
        $rampunits = $this->input->post('rampunits');
        $rtprcconfirm = $this->input->post('confirm');
        $resultscorresspond = $this->input->post('result');
        $testdate = $this->input->post('testdate');
        
		$data ['labassayid'] = $this->input->post ( 'idassay' );
		$data ['idmosquitospecies'] = ! empty ( $species ) ? $species : 0;
        $data['testdate'] = !empty($testdate)?date('Y-m-d',strtotime($testdate)):'0000-00-00';
        $data['timestamp'] = strtotime($data['testdate']);
        $data['idassaytype'] = !empty($assay_type)?$assay_type:0;
        $data['idlabresult'] = !empty($lab_result)?$lab_result:0;
        $data['rampunits'] = !empty($rampunits)?$rampunits:'';
        $data['idlabtechnician'] = !empty($lab_technician)?$lab_technician:0;
        $data['rtprcconfirm'] = !empty($rtprcconfirm)? '1' : '0' ;
        $data['resultscorresspond'] = !empty($resultscorresspond)? '1' : '0' ;
        
        if(!empty($detected_virus))
            $data['idvirustype'] = $detected_virus;

		
		$data ['poolsize'] = $this->input->post ( 'poolsize' );
		$data ['comments'] = $this->input->post ( 'comment' );
		$this->db->query ( "SET foreign_key_checks = 0" );
		$this->db->where ( 'idarbovirallab', $id );
		$this->db->update ( 'arbovirallabs', $data );
		
		$rows = $this->db->affected_rows ();
		$this->db->query ( "SET foreign_key_checks = 1" );
		
		// $rows = 1;
		if (empty ( $rows ) && empty ( $id ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to delete lab
	 */
	public function deleteArbovirallab() {
		$idlab = $this->input->get ( 'id' );
		
		if (empty ( $idlab ))
			return false;
		
		$data ['isdeleted'] = '1';
		$this->db->where ( 'idarbovirallab', $idlab );
		$this->db->update ( 'arbovirallabs', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ) && empty ( $idlab ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to get all Lab Technician
	 * which are actually users
	 */
	public function getLabtechnician($Id = '') {
		$this->db->select ( 'u.iduser,u.
				firstname,
				u.middlename,
				u.lastname' );
		$this->db->from ( 'users AS u' );
		$this->db->join ( 'userlocationassignment AS ula', "u.iduser = ula.iduser", 'INNER' );
		$this->db->join ( 'locations AS lc', "ula.idlocation = lc.idlocation", 'INNER' );
		$this->db->where ( 'lc.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'u.is_active', '1' );
				$result = array ();
				$query = $this->db->get ();
				
				if ($query->num_rows () > 0) {
					$i = 0;
					foreach ( $query->result_array () as $row ) {
						$result [$i] ['iduser'] = $row ['iduser'];
						$result [$i] ['firstname'] = $row ['firstname'];
						$result [$i] ['firstname'] = $row ['middlename'];
						$result [$i] ['lastname'] = $row ['lastname'];
						$i ++;
					}
				}
				
				return $result;
	}
	
	/**
	 * Function to check for the existence of Arboviral Lab
	 */
	public function arboExist($str = '') {
		if (empty ( $str ))
			return false;
		
		$this->db->select ( '*' );
		$this->db->from ( 'arbovirallabs AS al' );
		$this->db->join ( 'traps AS t', 'al.idtrap = t.idtrap', 'INNER' );
		$this->db->join ( 'sites AS s', 't.idsite = s.idsite', 'INNER' );
		$this->db->where ( 'al.labassayid', $str );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0)
			return true;
		
		return false;
	}
	
	/**
	 * Function to Get Lati Longi
	 * for displaying on Maps
	 */
	public function getMapdata() {
		$offset = 0;
        $page_size = $this->input->get ( 'page_size' );
		$page = $this->input->get ( 'page' );
		$filter_date = $this->input->get ( 'filter_date' );
		$labresult = $this->input->get ( 'labresult' );
		$setfromdate = $this->input->get ( 'setfromdate' );
		$settodate = $this->input->get ( 'settodate' );
		
        $page_size = ($page_size == 'all') ? 'all' : (is_numeric($page_size) ? $page_size : 10);
        $limit = (is_numeric($page_size)) ? $page_size : NULL;        
        $offset = $limit * ($page - 1);
        
        if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 2;

		$this->db->select ( 'al.idarbovirallab,
				al.testdate AS testdate,
				lr.labresult as result,
				t.latitude,
				t.longitude,
				t.idtrap,
				t.trap,
				locations.GoogleZoom' );
		$this->db->from ( 'arbovirallabs AS al' );
		$this->db->join ( 'traps AS t', 'al.idtrap = t.idtrap', 'LEFT' );
		$this->db->join ( 'adultsurveillance AS a', 'al.idadultsurveillance = a.idadultsurveillance', 'LEFT' );
		$this->db->join ( 'mosquitospecies', 'al.idmosquitospecies = mosquitospecies.idmosquitospecies', 'LEFT' );
		$this->db->join ( 'genuses', 'mosquitospecies.idgenus = genuses.idgenus', 'LEFT' );
		$this->db->join ( 'assaytypes', 'al.idassaytype = assaytypes.idassaytype', 'LEFT' );
		$this->db->join ( 'labresults AS lr', 'al.idlabresult = lr.idlabresult', 'LEFT' );
		$this->db->join ( 'users', 'al.idlabtechnician = users.iduser', 'LEFT' );
		$this->db->join ( 'sites AS s', 't.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'locations', 's.idlocation = locations.idlocation', 'LEFT' );
		$this->db->where ( 'al.isdeleted', '0' );
		$this->db->where ( 'al.idlocation', $this->session->userdata ( 'idlocation' ) );
		if (! is_null ( $filter_date ) && empty ( $setfromdate ) && empty ( $settodate )) {
			switch ($filter_date) {
				case '1' :
					$this->db->where ( 'al.testdate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'al.testdate' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'al.testdate' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'al.testdate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'al.testdate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'al.testdate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'al.testdate' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'al.testdate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'al.testdate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'al.testdate' . ' <=', date ( 'Y-m-d' ) );
					break; 
			}
		} else if (! empty ( $setfromdate ) && ! empty ( $settodate )) {
			$this->db->where ( 'al.testdate' . ' >=', $setfromdate );
			$this->db->where ( 'al.testdate' . ' <=', $settodate );
		}
		
		if (! empty ( $labresult )) {
			switch ($labresult) {
				case '1' :
					$this->db->where ( 'al.idlabresult', '2' );
					break;
				
				case '2' :
					$this->db->where ( 'al.idlabresult', '-1' );
					break;
				case '3' :
					$this->db->where ( 'al.idlabresult', '1' );
					break;
			}
		}
		$this->db->order_by ( 'al.testdate', 'desc' );
		$this->db->limit ( $limit, $offset );
		
		$data_1 = array ();
		$query = $this->db->get ();
		// echo $this->db->last_query();
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
	}
	/**
	 * Function to list all Arbovirallabs mail
	 */
	public function getArbovirallabData($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( 'a.*' );
		$this->db->from ( 'arbovirallabs AS a' );
		$this->db->join ( 'traps AS t', 'a.idtrap = t.idtrap', 'LEFT' );
		$this->db->join ( 'sites AS s', 't.idsite = s.idsite', 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'a.isdeleted', '0' );
		$this->db->where ( 'a.idarbovirallab', $Id );
		
		$query = $this->db->get ();
		
		$data = array ();
		if ($query->num_rows () > 0) {
			$data = $query->result_array ();
			return $data [0];
		}
		
		return false;
	}
	
	/**
	 * Function to fetch Detected Virus
	 */
	public function getDetectedVirus($Id = '') {
		$this->db->select ( '*' );
		$this->db->order_by ( 'virustypes' );
		$this->db->from ( 'virustypes' );
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idvirustype'] = $row ['idvirustype'];
				$result [$i] ['virustypes'] = $row ['virustypes'];
				$i ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to list all Arbovirallabs mail
	 */
	public function listArbovirallabs($Ids = "", $mapSite = "", $mapFlag = "") {
		$this->db->select ( "arbovirallabs.idarbovirallab, 
				arbovirallabs.labassayid , 
				arbovirallabs.testdate , 
				genuses.genus ,
				ast.assaytype,
				traps.trap,
				users.firstname,
				users.middlename,
				users.lastname,
				lr.labresult,
                CONCAT(users.firstname,' ',users.middlename,' ',users.lastname) AS labtech" );
		$this->db->from ( 'arbovirallabs' );
		$this->db->join ( 'traps', 'arbovirallabs.idtrap = traps.idtrap', 'LEFT' );
		$this->db->join ( 'adultsurveillance AS a', 'arbovirallabs.idadultsurveillance = a.idadultsurveillance', 'LEFT' );
		$this->db->join ( 'mosquitospecies', 'arbovirallabs.idmosquitospecies = mosquitospecies.idmosquitospecies', 'LEFT' );
		$this->db->join ( 'genuses', 'mosquitospecies.idgenus = genuses.idgenus', 'LEFT' );
		$this->db->join ( 'assaytypes AS ast', 'arbovirallabs.idassaytype = ast.idassaytype', 'LEFT' );
		$this->db->join ( 'labresults AS lr', 'arbovirallabs.idlabresult = lr.idlabresult', 'LEFT' );
		$this->db->join ( 'users', 'arbovirallabs.idlabtechnician = users.iduser', 'LEFT' );
		$this->db->join ( 'sites AS s', 'traps.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'locations AS l', 's.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'arbovirallabs.isdeleted', '0' );
		
		$filter_date = $this->input->get ( 'filter_date' );
		$ttl = $this->input->get ( 'ttl' );
		$page = $this->input->get ( 'page' );
		$frmdate = $this->input->get ( 'frmdate' );
		$todate = $this->input->get ( 'todate' );
		$orderby = $this->input->get ( 'orderby' );
		$filter_by_trap = $this->input->get ( 'trap' );
		$filter_by_lab = $this->input->get ( 'lab' );
		
		if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 2;
		
		if (! isset ( $ttl ) || $ttl == '')
			$ttl = 10;
		
		if (! isset ( $page ) || $page == '')
			$page = 1;
            
        if(!empty($mapSite) || !empty($mapFlag)){
            $filter_date = "";
            $filter_daterange = "";
            $frmdate = "";
            $todate = "";
            $filter_by_lab = "";
            $orderby = "";
            $ttl = "";
            $page = "";
		}
        
        if(!empty($mapSite)) {
            $this->db->where ( 's.idsite', $mapSite );
        }
		
		if (! empty ( $frmdate ) && ! empty ( $todate )) {
			$frmdate = substr ( $frmdate, 0, 2 ) . '/' . substr ( $frmdate, 2, 2 ) . '/' . substr ( $frmdate, 4, 4 );
			$todate = substr ( $todate, 0, 2 ) . '/' . substr ( $todate, 2, 2 ) . '/' . substr ( $todate, 4, 4 );
			$this->db->where ( 'arbovirallabs.testdate' . ' >=', date ( 'Y-m-d', strtotime ( $frmdate ) ) );
			$this->db->where ( 'arbovirallabs.testdate' . ' <=', date ( 'Y-m-d', strtotime ( $todate ) ) );
		} else if (! is_null ( $filter_date )) {
			switch ($filter_date) {
				// date('H:i:s',strtotime('-1 day');
				case '1' :
					$this->db->where ( 'arbovirallabs.testdate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'arbovirallabs.testdate' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'arbovirallabs.testdate' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'arbovirallabs.testdate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'arbovirallabs.testdate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'arbovirallabs.testdate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'arbovirallabs.testdate' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'arbovirallabs.testdate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'arbovirallabs.testdate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'arbovirallabs.testdate' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		}
		
		if (! empty ( $filter_by_trap ))
			$this->db->like ( 'traps.trap', $filter_by_trap );
		
		if (! empty ( $filter_by_lab )) {
			switch ($filter_by_lab) {
				case '1' :
					$this->db->where ( 'arbovirallabs.idlabresult', '2' );
					break;
				case '2' :
					$this->db->where ( 'arbovirallabs.idlabresult', '-1' );
					break;
				case '3' :
					$this->db->where ( 'arbovirallabs.idlabresult', '1' );
					break;
			}
		}
		
		if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
			switch ($orderby) {
				case '0:asc' :
					$this->db->order_by ( "arbovirallabs.labassayid", 'ASC' );
					break;
				case '0:desc' :
					$this->db->order_by ( "arbovirallabs.labassayid", 'DESC' );
					break;
				case '1:asc' :
					$this->db->order_by ( "arbovirallabs.testdate", 'ASC' );
					break;
				case '1:desc' :
					$this->db->order_by ( "arbovirallabs.testdate", 'DESC' );
					break;
				case '2:asc' :
					$this->db->order_by ( "traps.trap", 'ASC' );
					break;
				case '2:desc' :
					$this->db->order_by ( "traps.trap", 'DESC' );
					break;
				case '3:asc' :
					$this->db->order_by ( 'genuses.genus', 'ASC' );
					break;
				case '3:desc' :
					$this->db->order_by ( 'genuses.genus', 'DESC' );
					break;
				case '4:asc' :
					$this->db->order_by ( "a.assaytype", 'ASC' );
					break;
				case '4:desc' :
					$this->db->order_by ( "a.assaytype", 'DESC' );
					break;
				case '5:asc' :
					$this->db->order_by ( "lr.labresult", 'ASC' );
					break;
				case '5:desc' :
					$this->db->order_by ( "lr.labresult", 'DESC' );
					break;
				case '6:asc' :
					$this->db->order_by ( "users.firstname", 'ASC' );
					$this->db->order_by ( "users.middlename", 'ASC' );
					$this->db->order_by ( "users.lastname", 'ASC' );
					break;
				case '6:desc' :
					$this->db->order_by ( "users.firstname", 'DESC' );
					$this->db->order_by ( "users.middlename", 'DESC' );
					$this->db->order_by ( "users.lastname", 'DESC' );
					break;
			}
		} else {
			$this->db->order_by ( "arbovirallabs.testdate", 'DESC' );
		}
		
		/**
		 * if(!is_null($ttl) && !is_null($page))
		 * {
		 * if($page == 1)
		 * $page = 0;
		 * else
		 * $page--;
		 *
		 * $page *= 10;
		 * $this->db->limit($ttl ,$page);
		 * }
		 * else if(!is_null($ttl))
		 * {
		 * $this->db->limit($ttl);
		 * }
		 */
		
		$data_1 = array ();
        if(!empty($Ids)) {
            $this->db->where_in ( 'arbovirallabs.idarbovirallab', $Ids );
        }
		$query = $this->db->get ();
		// echo $this->db->last_query()."<br>";
		// die;
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
		
		return false;
	}
	public function getLocationData() {
		$this->db->select ( 'l.location, l.contactname, l.officephone' );
		$this->db->from ( 'locations AS l' );
		$this->db->where ( 'l.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$query = $this->db->get ();
		if ($query->num_rows () > 0) {
			return $query->result_array ();
		}
		return $result;
	}
	
	/**
	 * Function to fetch pools report
	 */
	public function getPoolsReport($requestData) {
		if (empty ( $requestData ))
			return null;
		
		$this->db->select ( 's.idsite, 
				s.site, 
				ab.labassayid AS sample, 
				ab.poolsize AS sampleno, 
				ab.testdate AS testdate, 
				m.mosquitospecies' );
		$this->db->from ( 'arbovirallabs AS ab' );
		$this->db->join ( 'traps AS t', 'ab.idtrap = t.idtrap', 'LEFT' );
		$this->db->join ( 'adultsurveillance AS a', 'ab.idadultsurveillance = a.idadultsurveillance', 'LEFT' );
		$this->db->join ( 'mosquitospecies AS m', 'ab.idmosquitospecies = m.idmosquitospecies', 'LEFT' );
		$this->db->join ( 'sites AS s', 't.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'locations AS l', 's.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'ab.isdeleted', '0' );
		$this->db->where_in ( 'ab.idarbovirallab', $requestData );
		
		$query = $this->db->get ();
		if ($query->num_rows () > 0)
			return $query->result_array ();
	}
	
	/**
	 * Function to fetch pools report dats
	 */
	public function getPoolsReportData() {
		$this->db->select ( 's.idsite, 
				s.site, 
				ab.labassayid AS sample, 
				ab.poolsize AS sampleno, 
				ab.testdate AS testdate, 
				m.mosquitospecies' );
		$this->db->from ( 'arbovirallabs AS ab' );
		$this->db->join ( 'traps AS t', 'ab.idtrap = t.idtrap', 'LEFT' );
		$this->db->join ( 'adultsurveillance AS a', 'arbovirallabs.idadultsurveillance = a.idadultsurveillance', 'LEFT' );
		$this->db->join ( 'mosquitospecies AS m', 'ab.idmosquitospecies = m.idmosquitospecies', 'LEFT' );
		$this->db->join ( 'users AS u', 'ab.idlabtechnician = u.iduser', 'LEFT' );
		$this->db->join ( 'sites AS s', 't.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'locations AS l', 's.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'ab.isdeleted', '0' );
		
		$filter_date = $this->input->get ( 'filter_date' );
		$ttl = $this->input->get ( 'ttl' );
		$page = $this->input->get ( 'page' );
		$frmdate = $this->input->get ( 'frmdate' );
		$todate = $this->input->get ( 'todate' );
		$orderby = $this->input->get ( 'orderby' );
		$filter_by_trap = $this->input->get ( 'trap' );
		$filter_by_lab = $this->input->get ( 'lab' );
		
		if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 5;
		
		if (! isset ( $ttl ) || $ttl == '')
			$ttl = 10;
		
		if (! isset ( $page ) || $page == '')
			$page = 1;
		
		if (! empty ( $frmdate ) && ! empty ( $todate )) {
			$frmdate = substr ( $frmdate, 0, 2 ) . '/' . substr ( $frmdate, 2, 2 ) . '/' . substr ( $frmdate, 4, 4 );
			$todate = substr ( $todate, 0, 2 ) . '/' . substr ( $todate, 2, 2 ) . '/' . substr ( $todate, 4, 4 );
			$this->db->where ( 'ab.testdate' . ' >=', date ( 'Y-m-d', strtotime ( $frmdate ) ) );
			$this->db->where ( 'ab.testdate' . ' <=', date ( 'Y-m-d', strtotime ( $todate ) ) );
		} else if (! is_null ( $filter_date )) {
			switch ($filter_date) {
				// date('H:i:s',strtotime('-1 day');
				case '1' :
					$this->db->where ( 'ab.testdate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'ab.testdate' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'ab.testdate' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'ab.testdate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'ab.testdate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'ab.testdate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'ab.testdate' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'ab.testdate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'ab.testdate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'ab.testdate' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		}
		
		if (! empty ( $filter_by_trap ))
			$this->db->like ( 't.trap', $filter_by_trap );
		
		if (! empty ( $filter_by_lab )) {
			switch ($filter_by_lab) {
				case '1' :
					$this->db->where ( 'ab.idlabresult', '2' );
					break;
				case '2' :
					$this->db->where ( 'ab.idlabresult', '-1' );
					break;
				case '3' :
					$this->db->where ( 'ab.idlabresult', '1' );
					break;
			}
		}
		
		if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
			switch ($orderby) {
				case '0:asc' :
					$this->db->order_by ( "ab.labassayid", 'ASC' );
					break;
				case '0:desc' :
					$this->db->order_by ( "ab.labassayid", 'DESC' );
					break;
				case '1:asc' :
					$this->db->order_by ( "arbovirallabs.testdate", 'ASC' );
					break;
				case '1:desc' :
					$this->db->order_by ( "arbovirallabs.testdate", 'DESC' );
					break;
				case '2:asc' :
					$this->db->order_by ( "t.trap", 'ASC' );
					break;
				case '2:desc' :
					$this->db->order_by ( "t.trap", 'DESC' );
					break;
				case '3:asc' :
					$this->db->order_by ( 'g.genus', 'ASC' );
					break;
				case '3:desc' :
					$this->db->order_by ( 'g.genus', 'DESC' );
					break;
				case '4:asc' :
					$this->db->order_by ( "a.assaytype", 'ASC' );
					break;
				case '4:desc' :
					$this->db->order_by ( "a.assaytype", 'DESC' );
					break;
				case '5:asc' :
					$this->db->order_by ( "lr.labresult", 'ASC' );
					break;
				case '5:desc' :
					$this->db->order_by ( "lr.labresult", 'DESC' );
					break;
				case '6:asc' :
					$this->db->order_by ( "u.firstname", 'ASC' );
					$this->db->order_by ( "u.middlename", 'ASC' );
					$this->db->order_by ( "u.lastname", 'ASC' );
					break;
				case '6:desc' :
					$this->db->order_by ( "u.firstname", 'DESC' );
					$this->db->order_by ( "u.middlename", 'DESC' );
					$this->db->order_by ( "u.lastname", 'DESC' );
					break;
			}
		} else {
			$this->db->order_by ( "ab.testdate", 'DESC' );
		}
		
		$data_1 = array ();
		$query = $this->db->get ();
		// echo $this->db->last_query()."<br>";
		// die;
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
		
		return false;
	}
	
	/**
	 * Function to fetch Trap Names
	 */
	public function getTrapname($idtrap = '') {
		$this->db->select ( 't.idtrap,t.trap' );
		$this->db->from ( 'traps AS t' );
		
		// $this->db->join('arbovirallabs AS al','al.idtrap = t.idtrap','LEFT');
		// $this->db->join('sites AS s','t.idsite = s.idsite','LEFT');
		// $this->db->where('al.idlocation',$this->session->userdata('idlocation'));
		$this->db->where ( 't.isdeleted', '0' );
		$this->db->where ( 't.active', '1' );
				$result = array ();
				$query = $this->db->get ();
				
				if ($query->num_rows () > 0) {
					$i = 0;
					foreach ( $query->result_array () as $row ) {
						$result [$i] ['idtrap'] = $row ['idtrap'];
						$result [$i] ['trap'] = $row ['trap'];
						$i ++;
					}
				}
				return $result;
	}
	
	/**
	 * Function to fetch Species Name
	 */
	public function getSpecies() {
		$this->db->select ( 'm.idmosquitospecies,m.mosquitospecies,g.genus' );
		$this->db->from ( 'mosquitospecies AS m' );
		$this->db->join ( 'genuses AS g', 'm.idgenus = g.idgenus', 'LEFT' );
		$this->db->join ( 'locationmosquitospecies AS lm', 'm.idmosquitospecies = lm.idmosquitospecies', 'INNER' );
		$this->db->where ( 'lm.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->order_by ( 'g.genus' );
		$this->db->order_by ( 'm.mosquitospecies' );
		
		/* $result = array ();
		$query = $this->db->get ();
		$this->str = "";
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['idmosquitospecies'] . '">(' . $row ['genus'] . ')' . $row ['mosquitospecies'] . '</option>';
			}
		}
		
		return $this->str; */
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idmosquitospecies'] = $row ['idmosquitospecies'];
				$result [$i] ['genus'] = $row ['genus'];
				$result [$i] ['mosquitospecies'] = $row ['mosquitospecies'];
				$i ++;
			}
		}
		return $result;
	}
	
	/**
	 * Function to fetch Selected Species Name
	 */
	public function getSelectedSpecies($id = '') {
		$this->db->select ( 'm.idmosquitospecies,m.mosquitospecies,g.genus' );
		$this->db->from ( 'mosquitospecies AS m' );
		$this->db->join ( 'genuses AS g', 'm.idgenus = g.idgenus', 'LEFT' );
		$this->db->join ( 'locationmosquitospecies AS lm', 'm.idmosquitospecies = lm.idmosquitospecies', 'INNER' );
		$this->db->where ( 'lm.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->order_by ( 'g.genus' );
		$this->db->order_by ( 'm.mosquitospecies' );
				$result = array ();
				$query = $this->db->get ();
				
				if ($query->num_rows () > 0) {
					$i = 0;
					foreach ( $query->result_array () as $row ) {
						$result [$i] ['idmosquitospecies'] = $row ['idmosquitospecies'];
						$result [$i] ['genus'] = $row ['genus'];
						$result [$i] ['mosquitospecies'] = $row ['mosquitospecies'];
						$i ++;
					}
				}
				return $result;
	}
	
	/**
	 * Function to get all Assay Performed
	 */
	public function getAssay() {
		$this->db->select ( '*' );
		$this->db->order_by ( 'assaytype' );
		$this->db->from ( 'assaytypes' );
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idassaytype'] = $row ['idassaytype'];
				$result [$i] ['assaytype'] = $row ['assaytype'];
				$i ++;
			}
		}
		return $result;
	}
	
	/**
	 * Function to get Selected Assay Performed
	 */
	public function getSelectedAssay($Id = '') {
		$this->db->select ( '*' );
		$this->db->order_by ( 'assaytype' );
		$this->db->from ( 'assaytypes' );
		
				$result = array ();
				$query = $this->db->get ();
				
				if ($query->num_rows () > 0) {
					$i = 0;
					foreach ( $query->result_array () as $row ) {
						$result [$i] ['idassaytype'] = $row ['idassaytype'];
						$result [$i] ['assaytype'] = $row ['assaytype'];
						$i ++;
					}
				}
				return $result;
	}
	
	/**
	 * Function to get all Arbovirallab Results
	 */
	public function getArbovirallabResult() {
		$this->db->select ( '*' );
		$this->db->order_by ( 'labresult' );
		$this->db->from ( 'labresults' );
        $result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idlabresult'] = $row ['idlabresult'];
				$result [$i] ['labresult'] = $row ['labresult'];
				$i ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to get Selected Arbovirallab Results
	 */
	public function getSelectedArbovirallabResult($Id = '') {
		$this->db->select ( '*' );
		$this->db->order_by ( 'labresult' );
		$this->db->from ( 'labresults' );
				$result = array ();
				$query = $this->db->get ();
				
				if ($query->num_rows () > 0) {
					$i = 0;
					foreach ( $query->result_array () as $row ) {
						$result [$i] ['idlabresult'] = $row ['idlabresult'];
						$result [$i] ['labresult'] = $row ['labresult'];
						$i ++;
					}
				}
				return $result;
	}
	
	/**
	 * Function to get all Arbovirallab Technician
	 * which are actually users
	 */
	public function getArbovirallabtechnician() {
		$this->db->select ( 'u.iduser,u.firstname,u.middlename,u.lastname' );
		$this->db->order_by ( 'firstname', 'ASC' );
		$this->db->order_by ( 'lastname', 'ASC' );
		$this->db->from ( 'users AS u' );
		$this->db->join ( 'userlocationassignment AS ula', "u.iduser = ula.iduser", 'INNER' );
		$this->db->join ( 'locations AS lc', "ula.idlocation = lc.idlocation", 'INNER' );
		$this->db->where ( 'lc.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'u.is_active', '1' );
		$this->db->where ( 'u.isdeleted', '0' );
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['iduser'] = $row ['iduser'];
				$result [$i] ['firstname'] = $row ['firstname'];
				$result [$i] ['lastname'] = $row ['lastname'];
				$i ++;
			}
		}
		return $result;
	}
	
	/**
	 * Function to get Selected Arbovirallab Technician
	 * which are actually users
	 */
	public function getSelectedArbovirallabtechnician($Id = '') {
		$this->db->select ( 'u.iduser,u.firstname,u.middlename,u.lastname' );
		$this->db->order_by ( 'firstname', 'ASC' );
		$this->db->order_by ( 'lastname', 'ASC' );
		$this->db->from ( 'users AS u' );
		$this->db->join ( 'userlocationassignment AS ula', "u.iduser = ula.iduser", 'INNER' );
		$this->db->join ( 'locations AS lc', "ula.idlocation = lc.idlocation", 'INNER' );
		$this->db->where ( 'lc.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'u.is_active', '1' );
				$result = array ();
				$query = $this->db->get ();
				
				if ($query->num_rows () > 0) {
					$i = 0;
					foreach ( $query->result_array () as $row ) {
						$result [$i] ['iduser'] = $row ['iduser'];
						$result [$i] ['firstname'] = $row ['firstname'];
						$result [$i] ['middlename'] =  $row ['middlename'];
						$result [$i] ['lastname'] = $row ['lastname'];
						if($row ['iduser'] == $Id)
							$result [$i] ['isSelected'] = true;
						else
							$result [$i] ['isSelected'] = false;
						$i ++;
					}
				}
				
				return $result;
	}
	
	/**
	 * Function to get Trap Info
	 * This function fires on changing the select box
	 */
	public function getTrapInfo($idtrap = '') {
		if (empty ( $idtrap ))
			$idtrap = $this->input->post ( 'idtrap' );
		
		if (empty ( $idtrap ))
			return null;
		
		$id = "";
		$i = 0;
		$this->db->select ( 'ad.idadultsurveillance,ad.`pudate`,ad.`putime`,t.`idtrap`' );
		$this->db->from ( 'traps AS t' );
		$this->db->join ( '`adultsurveillance` AS ad', 't.idtrap = ad.idtrap' );
		$this->db->join ( 'sites AS s', 't.idsite = s.idsite', 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 't.idtrap', $idtrap );
		$this->db->where ( 't.isdeleted', '0' );
		$this->db->where ( 't.active', '1' );
		$this->db->order_by ( 'ad.pudate', 'desc' );
		
		$query = $this->db->get ();
		// echo $this->db->last_query();
		// die;
		$this->str = "";
		$result = array ();
		$count = 0;
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $k => $v ) {
				if ($i == 0) {
					$id = $v ['idadultsurveillance'];
					
					$this->db->select ( 'SUM(adst.count) AS count' );
					$this->db->from ( 'adultsurveillancedetails AS adst' );
					$this->db->where ( 'adst.idadultsurveillance', $id );
					
					$q = $this->db->get ();
					
					if ($q->num_rows () > 0) {
						foreach ( $q->result_array () as $k1 => $v1 ) {
							$count = $v1 ['count'];
						}
					}
				}
				
				$this->str .= '<option value="' . $v ['idadultsurveillance'] . '">' . (! empty ( $v ['pudate'] ) ? date ( 'm/d/Y h:i A', strtotime ( $v ['pudate'] . " " . $v ['putime'] ) ) : '') . '</option>';
				$i = 1;
			}
		}
		
		$result ['str'] = $this->str;
		$result ['count'] = $count;
		
		return $result;
	}
	
	/**
	 * Function to get Selected Trap Info
	 * This function fires on changing the select box
	 */
	public function getSelectedTrapInfo($id1 = '', $id2 = '') {
		if (empty ( $id1 ))
			return;
		
		$this->db->select ( 'ad.idadultsurveillance,ad.`pudate`,ad.`putime`' );
		$this->db->from ( 'traps AS t' );
		$this->db->join ( '`adultsurveillance` AS ad', 't.idtrap = ad.idtrap' );
		$this->db->join ( 'sites AS s', 't.idsite = s.idsite', 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 't.isdeleted', '0' );
		$this->db->where ( 't.active', '1' );
		$this->db->where ( 't.idtrap', $id1 );
		$this->db->where ( 'ad.idadultsurveillance', $id2 );
		$query = $this->db->get ();
		$result = array ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idadultsurveillance'] = $row ['idadultsurveillance'];
				$result [$i] ['pudate'] = date('m/d/Y', strtotime($row ['pudate']))." ".$row ['putime'];
				$i ++;
			}
		}
		return $result;
	}
	
	/**
	 * Function to get Total Trap Count
	 * This function fires on changing the select box
	 * for date
	 */
	public function getTrapCount() {
		$id = $this->input->post ( 'id' );
		
		if (empty ( $id ))
			return null;
		
		$this->db->select ( 'SUM(adst.count) AS count' );
		$this->db->from ( 'adultsurveillancedetails AS adst' );
		
		$this->db->where ( 'adst.idadultsurveillance', $id );

		$query = $this->db->get ();

		$this->str = "";
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $k => $v ) {
				$this->str = $v ['count'];
			}
		}

		return $this->str;
	}
	
	/**
	 * Function to get Total Trap Count
	 * This function fires on changing the select box
	 * for date
	 */
	public function getSelectedTrapCount($id1 = '') {
		if (empty ( $id1 ))
			return;
		
		$this->db->select ( 'sum(adst.count) AS count' );
		$this->db->from ( 'adultsurveillancedetails AS adst' );
		$this->db->where ( 'adst.idadultsurveillance', $id1 );
		// $this->db->where('adst.isdeleted','0');
		$this->db->group_by ( 'adst.idadultsurveillance' );
		$result = "";
		$query = $this->db->get ();
		if ($query->num_rows () > 0) {
			$data = $query->result_array ();
			$result = $data[0]['count'];
		}
		return $result;
	}
	
	/**
	 * Function to get Virus Type
	 * This comes when the Arbovirallab is Opened in Edit Mode
	 */
	public function getSelectedVirusType($Id = '') {
		$this->db->select ( '*' );
		$this->db->order_by ( 'virustypes' );
		$this->db->from ( 'virustypes' );
				$result = array ();
				$query = $this->db->get ();
				
				if ($query->num_rows () > 0) {					
					$i = 0;
					foreach ( $query->result_array () as $row ) {
						$result [$i] ['idvirustype'] = $row ['idvirustype'];
						$result [$i] ['virustypes'] = $row ['virustypes'];
						$i ++;
					}
				}
				return $result;
	}
	/**
	 * Function to fetch Selected Trap Names
	 */
	public function getSelectedTrapname($Id = '') {
		if (empty ( $Id ))
			return null;
		
		$this->db->select ( 'trap' );
		$this->db->from ( 'traps' );
		
		$this->db->join ( 'sites AS s', 'traps.idsite = s.idsite', 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		// $this->db->where('traps.isdeleted','0');
		// $this->db->where('traps.active','1');
		$this->db->where ( 'idtrap', $Id );
		$data = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$data = $query->result_array ();
			return $data [0] ['trap'];
		}
	}
	public function getLatestlabAssayId() {
		$this->db->select ( 'labassayid' );
		$this->db->from ( 'arbovirallabs' );
		$this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->order_by ( 'idarbovirallab', 'DESC' );
		
		$query = $this->db->get ();
		if ($query->num_rows () > 0) {
			$data = $query->row_array ();
			return $data ['labassayid'];
		}
		return false;
	}
    
    /**
	 * Function to get site id based on arboviral id
	 */
	public function getIdSite($id = '') {
		if (empty ( $id ))
			return false;
		
		$this->db->select ( '`traps`.`idsite`' );
		$this->db->from ( 'arbovirallabs' );
        $this->db->join ( 'traps', 'arbovirallabs.idtrap = traps.idtrap', 'INNER' );
		$this->db->where ( '`arbovirallabs`.`idarbovirallab`', $id );
		$this->db->where ( 'arbovirallabs.isdeleted', '0' );
		
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
            return $query->row()->idsite;
		}
		
		return false;
	}
}
