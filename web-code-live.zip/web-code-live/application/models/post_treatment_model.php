<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Post_treatment_model extends CI_Model {
	public $str = "";
	public $map = "";
	
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to Add a new Post_treatment
	 */
	public function addPost_treatment($id = '') {
		// print'<pre>';
		// print_r($_POST);
		// die;
		$idloc = $this->session->userdata ( 'idlocation' );
		$idsite = $this->input->post ( 'idsite' );
		$adverse_impact = $this->input->post ( 'adverseimpact_radio' );
		$unanti_death = $this->input->post ( 'unanticipated_death' );
		$disp_wildlife = $this->input->post ( 'obser_disrupt' );
		$disp_water = $this->input->post ( 'obser_disrupt_revreat' );
		$status_of_inc = $this->input->post ( 'status_incident' );
		$report = $this->input->post ( 'written_report' );
		$date = $this->input->post ( 'date' );
		$time = $this->input->post ( 'time' );
		
		$data ['idinspector'] = $this->input->post ( 'inspector' );
		$data ['date'] = ! empty ( $date ) ? date ( 'Y-m-d', strtotime ( $date ) ) : date ( 'Y-m-d' );
		$data ['time'] = ! empty ( $time ) ? date ( 'h:i:s A', strtotime ( $time ) ) : date ( 'h:i:s A' );
		$data ['inspect_type'] = $this->input->post ( 'inspect_type' );
		$data ['idsite'] = $idsite;
		$data ['adverse_impact'] = (! empty ( $adverse_impact ) && $adverse_impact == "yes") ? '1' : '0';
		$data ['unanti_death'] = (! empty ( $unanti_death ) && $unanti_death == "yes") ? '1' : '0';
		$data ['disp_wildlife'] = (! empty ( $disp_wildlife ) && $disp_wildlife == "yes") ? '1' : '0';
		$data ['disp_water'] = (! empty ( $disp_water ) && $disp_water == "yes") ? '1' : '0';
		$data ['status_of_inc'] = $status_of_inc;
		$data ['idproduct'] = $this->input->post ( 'products_applied' );
		$data ['description'] = $this->input->post ( 'description' );
		$data ['procedure'] = $this->input->post ( 'procedure' );
		$data ['report'] = ! empty ( $report ) ? 'yes' : 'no';
		$data ['rational'] = $this->input->post ( 'rational' );
		$data ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
		$data ['post_inspection_type'] = 'visual';
		
		$data ['idtreatment'] = $this->input->post ( 'idtrtmnt' );
		$data ['trtmnt_type'] = $this->input->post ( 'type' );
		
		if (! empty ( $unanti_death ) && $unanti_death == "yes")
			$data ['unanti_text'] = $this->input->post ( 'death_text' );
		else
			$data ['unanti_text'] = '';
		
		if (! empty ( $disp_wildlife ) && $disp_wildlife == "yes")
			$data ['disp_wild_txt'] = $this->input->post ( 'disruption_text' );
		else
			$data ['disp_wild_txt'] = '';
		
		if (! empty ( $disp_water ) && $disp_water == "yes")
			$data ['disp_water_txt'] = $this->input->post ( 'disruptionrec_text' );
		else
			$data ['disp_water_txt'] = '';
			
			// print'<pre>';
			// print_r($data);
			// echo $id;
			// die;
		
		if (! empty ( $id )) {
			$this->db->select ( '*' );
			$this->db->from ( 'post_treatment_inspection' );
			$this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
			$this->db->where ( 'idpost_treatment_inspect', $id );
			
			$q = $this->db->get ();
			
			if ($q->num_rows > 0) {
				$insert = "UPDATE post_treatment_inspection SET ";
				$insert_str = '';
				foreach ( $data as $key => $val ) {
					$insert_str .= "`$key` = '$val',";
				}
				$insert .= trim ( $insert_str, ',' ) . " WHERE idpost_treatment_inspect='$id'";
				$this->db->query ( $insert );
			} else {
				$insert = "INSERT INTO post_treatment_inspection SET ";
				$insert_str = '';
				foreach ( $data as $key => $val ) {
					$insert_str .= "`$key` = '$val',";
				}
				$insert .= trim ( $insert_str, ',' );
				
				$this->db->query ( $insert );
				$id = $this->db->insert_id ();
			}
		} else {
			$insert = "INSERT INTO post_treatment_inspection SET ";
			$insert_str = '';
			foreach ( $data as $key => $val ) {
				$insert_str .= "`$key` = '$val',";
			}
			$insert .= trim ( $insert_str, ',' );
			// echo $insert;
			// die;
			$this->db->query ( $insert );
			$id = $this->db->insert_id ();
		}
		
		if (empty ( $id ))
			return false;
		
		return $id;
	}
	
	/**
	 * Function to Add a new Post_treatment Water Quality
	 */
	public function addPost_treatmentWQ($id = '') {
		// print'<pre>';
		// print_r($_POST);
		// die;
		$idloc = $this->session->userdata ( 'idlocation' );
		$idsite = $this->input->post ( 'site_id' );
		$date = $this->input->post ( 'date_sample' );
		$time = $this->input->post ( 'time_sample' );
		$date_analysis = $this->input->post ( 'date_analysis' );
		
		$data ['date'] = ! empty ( $date ) ? date ( 'Y-m-d', strtotime ( $date ) ) : date ( 'Y-m-d' );
		$data ['time'] = ! empty ( $time ) ? date ( 'h:i:s A', strtotime ( $time ) ) : date ( 'h:i:s A' );
		$data ['idinspector'] = $this->input->post ( 'inspector' );
		$data ['idsite'] = $idsite;
		$data ['latitude'] = $this->input->post ( 'latitude' );
		$data ['longitude'] = $this->input->post ( 'longitude' );
		$data ['date_analysis'] = ! empty ( $date_analysis ) ? date ( 'Y-m-d', strtotime ( $date_analysis ) ) : date ( 'Y-m-d' );
		$data ['first_name'] = $this->input->post ( 'first_name' );
		$data ['last_name'] = $this->input->post ( 'last_name' );
		$data ['company_analysis'] = $this->input->post ( 'company_analysis' );
		$data ['technique_method'] = $this->input->post ( 'technique_method' );
		$data ['results_analysis'] = $this->input->post ( 'results_analysis' );
		$data ['notes'] = $this->input->post ( 'notes' );
		$data ['sample_taken'] = $this->input->post ( 'sample_taken' );
		$data ['idlocation'] = $idloc;
		$data ['post_inspection_type'] = 'water';
		$data ['idtreatment'] = $this->input->post ( 'idtrtmnt' );
		$data ['trtmnt_type'] = $this->input->post ( 'type' );
		
		// print'<pre>';
		// print_r($data);
		// echo $id;
		// die;
		//
		if (! empty ( $id )) {
			$this->db->select ( '*' );
			$this->db->from ( 'post_treatment_inspection' );
			$this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
			$this->db->where ( 'idpost_treatment_inspect', $id );
			
			$q = $this->db->get ();
			
			if ($q->num_rows > 0) {
				$insert = "UPDATE post_treatment_inspection SET ";
				$insert_str = '';
				foreach ( $data as $key => $val ) {
					$insert_str .= "`$key` = '$val',";
				}
				$insert .= trim ( $insert_str, ',' ) . " WHERE idpost_treatment_inspect='$id'";
				$this->db->query ( $insert );
			} else {
				$insert = "INSERT INTO post_treatment_inspection SET ";
				$insert_str = '';
				foreach ( $data as $key => $val ) {
					$insert_str .= "`$key` = '$val',";
				}
				$insert .= trim ( $insert_str, ',' );
				
				$this->db->query ( $insert );
				$id = $this->db->insert_id ();
			}
		} else {
			$insert = "INSERT INTO post_treatment_inspection SET ";
			$insert_str = '';
			foreach ( $data as $key => $val ) {
				$insert_str .= "`$key` = '$val',";
			}
			$insert .= trim ( $insert_str, ',' );
			
			$this->db->query ( $insert );
			$id = $this->db->insert_id ();
		}
		
		if (empty ( $id ))
			return false;
		
		return $id;
	}
	
	/**
	 * Function to list all Post_treatments
	 */
	public function deletePost_treatment() {
		$id = $this->input->get_post ( 'id' );
		
		if (empty ( $id ))
			return false;
		
		$this->db->select ( '*' );
		$this->db->from ( 'post_treatment_inspection' );
		$this->db->where ( 'idpost_treatment_inspect', $id );
		
		$q = $this->db->get ();
		if ($q->num_rows () > 0) {
			$data ['isdeleted'] = '1';
			$this->db->query ( "SET foreign_key_checks = 0" );
			$this->db->where ( 'idpost_treatment_inspect', $id );
			$this->db->update ( 'post_treatment_inspection', $data );
			$this->db->query ( "SET foreign_key_checks = 1" );
		}
		
		// delete records from larval surveilance service
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ) && empty ( $id ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to list all Post_treatments
	 */
	public function getPost_treatmentData($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( '*' );
		$this->db->from ( 'post_treatment_inspection' );
		$this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'idpost_treatment_inspect', $Id );
		$this->db->where ( 'isdeleted', '0' );
		
		$query = $this->db->get ();
		
		$data = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row )
				$data [] = $row;
			
			return $data [0];
		}
		
		return false;
	}
	
	/**
	 * Function to list all Post_treatments mail
	 */
	public function listPost_treatment() {
		$this->db->select ( 'post_treatment_inspection.idpost_treatment_inspect, 
				post_treatment_inspection.date AS `date`, 
				post_treatment_inspection.time AS `time`, 
				sites.site, 
				users.firstname, 
				users.lastname, 
				post_treatment_inspection.post_inspection_type AS `post_inspection_type`' );
		$this->db->from ( 'post_treatment_inspection' );
		$this->db->join ( 'sites', 'post_treatment_inspection.idsite = sites.idsite', 'LEFT' );
		// $this->db->join('states AS st','sites.idstate = st.idstate','LEFT');
		$this->db->join ( 'users', 'post_treatment_inspection.idinspector = users.iduser', 'LEFT' );
		$this->db->where ( 'post_treatment_inspection.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->join ( 'locations AS l', "post_treatment_inspection.idlocation = l.idlocation", 'LEFT' );
		
		$this->db->where ( 'post_treatment_inspection.isdeleted', '0' );
		$orderby = $this->input->get ( 'orderby' );
		
		if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
			switch ($orderby) {
				case '0:asc' :
					$this->db->order_by ( 'post_treatment_inspection.date', 'ASC' );
					$this->db->order_by ( 'post_treatment_inspection.time ', 'ASC' );
					break;
				case '0:desc' :
					$this->db->order_by ( 'post_treatment_inspection.date', 'DESC' );
					$this->db->order_by ( 'post_treatment_inspection.time ', 'DESC' );
					break;
				case '1:asc' :
					$this->db->order_by ( 'sites.site', 'ASC' );
					break;
				case '1:desc' :
					$this->db->order_by ( 'sites.site', 'DESC' );
					break;
				case '2:asc' :
					$this->db->order_by ( 'users.firstname', 'ASC' );
					$this->db->order_by ( 'users.lastname', 'ASC' );
					break;
				case '2:desc' :
					$this->db->order_by ( 'users.firstname', 'DESC' );
					$this->db->order_by ( 'users.lastname', 'DESC' );
					break;
				case '3:asc' :
					$this->db->order_by ( 'post_treatment_inspection.post_inspection_type', 'ASC' );
					break;
				case '3:desc' :
					$this->db->order_by ( 'post_treatment_inspection.post_inspection_type', 'DESC' );
					break;
			}
		} else {
			$this->db->order_by ( 'post_treatment_inspection.date', 'DESC' );
			$this->db->order_by ( 'post_treatment_inspection.time ', 'DESC' );
		}
		$ttl = $this->input->get ( 'ttl' );
		$page = $this->input->get ( 'page' );
		/*
		 * if(!isset($ttl) || $ttl == '')
		 * $ttl = 10;
		 *
		 * if(!isset($page) || $page == '')
		 * $page = 1;
		 *
		 * if(!is_null($ttl) && !is_null($page))
		 * {
		 * if($page == 1)
		 * $page = 0;
		 * else
		 * $page--;
		 *
		 * $page *= 10;
		 * $this->db->limit($ttl ,$page);
		 * }
		 * else if(!is_null($ttl))
		 * {
		 * $this->db->limit($ttl);
		 * }
		 */
		
		$data_1 = array ();
		$query = $this->db->get ();
		// echo $this->db->last_query()."<br>";
		// die;
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
		
		return false;
	}
}
