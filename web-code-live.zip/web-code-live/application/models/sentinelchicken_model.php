<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Sentinelchicken_model extends CI_Model {
	public $str = "";
	public $map = "";
	/**
	 * s
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to Add a new Zone
	 */
	public function addsentinelchicken($message = '') {
		$idsite = $this->input->post ( 'site_id' );
		$site = $this->input->post ( 'site' );
		$idsitetype = $this->input->post ( 'idsitetype' );
		$maplabel = $this->input->post ( 'maplabel' );
		$address1 = $this->input->post ( 'address1' );
		$address2 = $this->input->post ( 'address2' );
		$city = $this->input->post ( 'city' );
		$idstate = $this->input->post ( 'idstate' );
		$latitude = $this->input->post ( 'latitude' );
		$longitude = $this->input->post ( 'longitude' );
		$pdop = $this->input->post ( 'pdop' );
		$postalcode = $this->input->post ( 'postalcode' );
		$idloc = $this->session->userdata ( 'idlocation' );
		
		$data ['idsite'] = (! empty ( $idsite )) ? $idsite : 0;
		$data ['site'] = (! empty ( $site )) ? $site : 0;
		$data ['idsitetype'] = (! empty ( $idsitetype )) ? $idsitetype : 0;
		$data ['maplabel'] = (! empty ( $maplabel )) ? $maplabel : 0;
		$data ['address1'] = (! empty ( $address1 )) ? $address1 : 0;
		$data ['address2'] = (! empty ( $address2 )) ? $address2 : 0;
		$data ['city'] = (! empty ( $city )) ? $city : 0;
		$data ['idstate'] = (! empty ( $idstate )) ? $idstate : 0;
		$data ['latitude'] = (! empty ( $latitude )) ? $latitude : 0;
		$data ['longitude'] = (! empty ( $longitude )) ? $longitude : 0;
		$data ['pdop'] = (! empty ( $pdop )) ? $pdop : 0;
		$data ['postalcode'] = (! empty ( $postalcode )) ? $postalcode : 0;
		$data ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
		// print_r($data);
		// die;
		$site_id = "";
		$site_data = $this->check_sitename ( $data ['idsite'] );
		if (empty ( $site_data )) {
			$this->db->insert ( 'sites', $data );
			$rows = $this->db->affected_rows ();
			$site_id = $this->db->insert_id ();
		} else {
			$site_id = $this->input->post ( 'site_id' );
		}
		$idzone = $this->input->post ( 'idzone' );
		$maplabel = $this->input->post ( 'maplabel' );

		$this->load->model('usermodel');
		$data_1 ['userId'] = $this->usermodel->getUserId();

		$data_1 ['flockname'] = $this->input->post ( 'flockname' );
		$data_1 ['idsite'] = $site_id;
		$data_1 ['sitename'] = (! empty ( $site )) ? $site : 0;
		$data_1 ['idsitetype'] = (! empty ( $idsitetype )) ? $idsitetype : 0;
		$data_1 ['idzone'] = (! empty ( $idzone )) ? $idzone : 0;
		$data_1 ['maplabel'] = (! empty ( $maplabel )) ? $maplabel : 0;
		$data_1 ['latitude'] = (! empty ( $latitude )) ? $latitude : 0;
		$data_1 ['longitude'] = (! empty ( $longitude )) ? $longitude : 0;
		$data_1 ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
		// $data_1['idsitegroup'] = $this->input->post('idsitegroup');
		
		// $data_1['date'] = date("Y-m-d");
		$this->db->set ( 'date', 'NOW()', FALSE );
		
		// echo '<pre>';print_r($data_1);die;
		$this->db->query ( "SET foreign_key_checks = 0" );
		$this->db->insert ( 'sentinelchicken', $data_1 );
		$rows = $this->db->affected_rows ();
		// $rows = 1;
		
		if (empty ( $rows ))
			return false;
		
		$id = $this->db->insert_id ();
		$this->db->query ( "SET foreign_key_checks = 1" );
		
		return true;
	}
	
	/**
	 * Function to Update a new Adultsurveillance
	 */
	public function updateSentinelchicken($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$idsite = $this->input->post ( 'site_id' );
		$site = $this->input->post ( 'site' );
		$idsitetype = $this->input->post ( 'idsitetype' );
		$maplabel = $this->input->post ( 'maplabel' );
		$address1 = $this->input->post ( 'address1' );
		$address2 = $this->input->post ( 'address2' );
		$city = $this->input->post ( 'city' );
		$idstate = $this->input->post ( 'idstate' );
		$latitude = $this->input->post ( 'latitude' );
		$longitude = $this->input->post ( 'longitude' );
		$pdop = $this->input->post ( 'pdop' );
		$postalcode = $this->input->post ( 'postalcode' );
		$idloc = $this->session->userdata ( 'idlocation' );
		
		$data ['idsite'] = (! empty ( $idsite )) ? $idsite : 0;
		$data ['site'] = (! empty ( $site )) ? $site : 0;
		$data ['idsitetype'] = (! empty ( $idsitetype )) ? $idsitetype : 0;
		$data ['maplabel'] = (! empty ( $maplabel )) ? $maplabel : 0;
		$data ['address1'] = (! empty ( $address1 )) ? $address1 : 0;
		$data ['address2'] = (! empty ( $address2 )) ? $address2 : 0;
		$data ['city'] = (! empty ( $city )) ? $city : 0;
		$data ['idstate'] = (! empty ( $idstate )) ? $idstate : 0;
		$data ['latitude'] = (! empty ( $latitude )) ? $latitude : 0;
		$data ['longitude'] = (! empty ( $longitude )) ? $longitude : 0;
		$data ['pdop'] = (! empty ( $pdop )) ? $pdop : 0;
		$data ['postalcode'] = (! empty ( $postalcode )) ? $postalcode : 0;
		$data ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
		// print_r($data);
		// die;
		$site_data = $this->check_sitename ( $data ['idsite'] );
		if (empty ( $site_data )) {
			$this->db->insert ( 'sites', $data );
			$rows = $this->db->affected_rows ();
			$site_id = $this->db->insert_id ();
		} else {
			$site_id = $this->input->post ( 'site_id' );
		}
		$idzone = $this->input->post ( 'idzone' );
		$maplabel = $this->input->post ( 'maplabel' );
		$data_1 ['flockname'] = $this->input->post ( 'flockname' );
		$data_1 ['idsite'] = $site_id;
		$data_1 ['sitename'] = (! empty ( $site )) ? $site : 0;
		$data_1 ['idsitetype'] = (! empty ( $idsitetype )) ? $idsitetype : 0;
		$data_1 ['idzone'] = (! empty ( $idzone )) ? $idzone : 0;
		$data_1 ['maplabel'] = (! empty ( $maplabel )) ? $maplabel : 0;
		$data_1 ['latitude'] = (! empty ( $latitude )) ? $latitude : 0;
		$data_1 ['longitude'] = (! empty ( $longitude )) ? $longitude : 0;
		// $data_1['idsitegroup'] = $this->input->post('idsitegroup');
		
		$this->db->where ( 'idsentinelchicken', $Id );
		$this->db->update ( 'sentinelchicken', $data_1 );
		$rows = $this->db->affected_rows ();
		if (empty ( $rows ) && empty ( $Id ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to check for the existence of flock
	 */
	public function flockExist($str = '') {
		if (empty ( $str ))
			return false;
		
		$this->db->select ( 'sc.*' );
		$this->db->from ( 'sentinelchicken AS sc' );
		$this->db->where ( 'sc.flockname', $str );
		$this->db->join ( 'sites AS s', 'sc.idsite = s.idsite', 'INNER' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0)
			return true;
		
		return false;
	}
	
	/**
	 * Function to delete sentinel chicken
	 */
	public function deletesentinelchicken() {
		$idsentinelchicken = $this->input->get_post ( 'id' );
		
		if (empty ( $idsentinelchicken ))
			return false;
		
		$data ['isdeleted'] = '1';
		$this->db->where ( 'idsentinelchicken', $idsentinelchicken );
		$this->db->update ( 'sentinelchicken', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to Get Lati Longi
	 * for displaying on Maps
	 */
	public function getMapdata() {
		$page_limit = 10;
		$page = $this->input->get ( 'page' );
		if (empty ( $page ) || $page == '' || $page == 1)
			$offset = 0;
		else
			$offset = $page * $page_limit;
		$filter_date = $this->input->get ( 'filter_date' );
		
		$this->db->select ( 'ad.idadultsurveillance,
				ad.latitude,
				ad.longitude,
				s.city,
				s.address1,
				s.address2,
				tt.traptype,
				t.idtrap,
				t.trap,
				ad.pudate,
				ad.putime,
				adst.count AS count' );
		$this->db->from ( 'adultsurveillance AS ad' );
		$this->db->join ( 'traps AS t', 'ad.idtrap = t.idtrap', 'LEFT' );
		$this->db->join ( 'traptypes AS tt', 't.idtraptype = tt.idtraptype', 'LEFT' );
		$this->db->join ( 'sites AS s', 't.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'adultsurveillancedetails AS adst', 'ad.idadultsurveillance = adst.idadultsurveillance', 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		if (! is_null ( $filter_date )) {
			switch ($filter_date) {
				case '1' :
					$this->db->where ( 'ad.pudate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'ad.pudate' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'ad.pudate' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'ad.pudate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'ad.pudate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'ad.pudate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'ad.pudate' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'ad.pudate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'ad.pudate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'ad.pudate' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		}
		$this->db->limit ( $page_limit, $offset );
		// $this->db->group_by("`ad`.`idadultsurveillance`");
		
		$data_1 = array ();
		$query = $this->db->get ();
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
	}
	/**
	 * Function to list all Adultsurveillances mail
	 */
	public function getSentinelchicken($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( '`sentinelchicken`.*' );
		$this->db->from ( 'sentinelchicken' );
		$this->db->join ( 'sites AS s', "sentinelchicken.idsite = s.idsite", 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( '`sentinelchicken`.`idsentinelchicken`', $Id );
		
		$query = $this->db->get ();
		
		$data = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row )
				$data [] = $row;
			
			return $data [0];
		}
		
		return false;
	}
	/**
	 * Function to list all Adultsurveillances mail
	 */
	public function listSentinelchicken($id_location = false) {
		$idlocation = ($id_location) ? $id_location : $this->session->userdata ( 'idlocation' );
		
		$this->db->select ( 'sentinelchicken.idsentinelchicken,
				sentinelchicken.flockname,
				sentinelchicken.date,
				zones.zone' );
		$this->db->from ( 'sentinelchicken' );
		$this->db->join ( 'sites', 'sentinelchicken.idsite = sites.idsite', 'LEFT' );
		$this->db->join ( 'zones', 'sites.idzone = zones.idzone', 'LEFT' );
		$this->db->where ( 'sentinelchicken.isdeleted', '0' );
		$this->db->where ( 'sites.idlocation', $idlocation );
		// $this->db->where('sentinelchicken.active','1');
		$this->db->where ( 'sentinelchicken.isdeleted', '0' );
		$ttl = $this->input->get ( 'ttl' );
		$page = $this->input->get ( 'page' );
		/*
		 * if(!isset($ttl) || $ttl == '')
		 * $ttl = 10;
		 *
		 * if(!isset($page) || $page == '')
		 * $page = 1;
		 *
		 * if(!is_null($ttl) && !is_null($page))
		 * {
		 * if($page == 1)
		 * $page = 0;
		 * else
		 * $page--;
		 *
		 * $page *= 10;
		 * $this->db->limit($ttl ,$page);
		 * }
		 * else if(!is_null($ttl))
		 * {
		 * $this->db->limit($ttl);
		 * }
		 */
		
		$orderby = $this->input->get ( 'orderby' );
		
		if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
			switch ($orderby) {
				case '0:asc' :
					$this->db->order_by ( 'sentinelchicken.idsentinelchicken', 'ASC' );
					break;
				case '0:desc' :
					$this->db->order_by ( 'sentinelchicken.idsentinelchicken', 'DESC' );
					break;
				case '1:asc' :
					$this->db->order_by ( 'sentinelchicken.flockname', 'ASC' );
					break;
				case '1:desc' :
					$this->db->order_by ( 'sentinelchicken.flockname', 'DESC' );
					break;
				case '2:asc' :
					$this->db->order_by ( 'zones.zone', 'ASC' );
					break;
				case '2:desc' :
					$this->db->order_by ( 'zones.zone', 'DESC' );
					break;
				case '3:asc' :
					$this->db->order_by ( 'sentinelchicken.date', 'ASC' );
					break;
				case '3:desc' :
					$this->db->order_by ( 'sentinelchicken.date', 'DESC' );
					break;
			}
		}
		
		// $this->db->group_by("sentinelchicken.idsentinelchicken");
		$query = $this->db->get ();
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
		
		return false;
	}
	
	/**
	 * Function to fetch history Count
	 */
	public function getHistory($Id) {
		if (empty ( $Id ))
			return false;
		$where = "adultsurveillance.idtrap = $Id";
		$this->db->select ( '`traps`.`trap` AS `traps_trap`, 
				`traptypes`.`traptype` AS `traps_idtraptype`, 
				`adultsurveillance`.`pudate` AS `pudate`, 
				`adultsurveillance`.`putime` AS `putime`,
				adultsurveillancedetails.idadultsurveillance,
				m.idmosquitospecies,
				m.mosquitospecies,
				adultsurveillancedetails.count,(adultsurveillancedetails.count*100/(SELECT sum(`adultsurveillancedetails`.`count`) 
				FROM `adultsurveillancedetails` 
				WHERE `adultsurveillancedetails`.`idadultsurveillance` = `adultsurveillance`.`idadultsurveillance`)) 
				AS count_percent' );
		$this->db->from ( 'adultsurveillance' );
		$this->db->join ( 'traps', 'adultsurveillance.idtrap = traps.idtrap', 'LEFT' );
		$this->db->join ( 'traptypes', 'traps.idtraptype = traptypes.idtraptype', 'LEFT' );
		$this->db->join ( 'adultsurveillancedetails', 'adultsurveillance.idadultsurveillance = adultsurveillancedetails.idadultsurveillance', 'LEFT' );
		$this->db->join ( 'mosquitospecies AS m', 'adultsurveillancedetails.idmosquitospecies = m.idmosquitospecies', 'LEFT' );
		// $this->db->where($where);
		// $this->db->group_by("`adultsurveillancedetails`.`idadultsurveillance`");
		
		$this->db->join ( 'sites AS s', "adultsurveillance.idsite = s.idsite", 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$this->db->order_by ( "adultsurveillancedetails.idadultsurveillance", "ASC" );
		// $this->db->order_by("adultsurveillance.pudate","ASC");
		$data_1 = array ();
		
		$query = $this->db->get ();
		// echo $this->db->last_query();
		// die;
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
		
		return false;
	}
	
	/**
	 * Function to check site name
	 */
	public function check_sitename($Id = '') {
		$this->db->select ( 'idsite' );
		$this->db->from ( 'sites' );
		
		// $this->db->where('sites.idlocation',$this->session->userdata('idlocation'));
		
		$this->db->where ( 'idsite', $Id );
		
		$result = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$result = '1';
		}
		
		return $result;
	}
	/**
	 * Function to fetch Site Names
	 */
	public function getSitename($Id = '') {
		$this->db->select ( 'idsite,
				site' );
		$this->db->order_by ( 'site' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'sites.active', '1' );
		$this->db->where ( 'sites.isdeleted', '0' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idsite']) {
					$this->str .= '<option value="' . $row ['idsite'] . ' " selected="true">' . $row ['site'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idsite'] . '">' . $row ['site'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	/**
	 * Function to fetch Site details
	 */
	public function getSiteDetails($Id = '') {
		$this->db->select ( 'sites.*' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'sites.active', '1' );
		$this->db->where ( 'sites.isdeleted', '0' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$this->db->where ( 'idsite', $Id );
		$results = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$results = $row;
			}
		}
		
		return $results;
	}
	/**
	 * Function to fetch site type
	 */
	public function getSelectedSitetype($Id = '') {
		$this->db->select ( 'idsitetype,
				sitetype' );
		$this->db->order_by ( 'sitetype' );
		$this->db->from ( 'sitetypes' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idsitetype']) {
					$this->str .= '<option value="' . $row ['idsitetype'] . '" selected="true">' . $row ['sitetype'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idsitetype'] . '">' . $row ['sitetype'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	/**
	 * Function to fetch selected Zone name
	 */
	public function getSelectedZonename($Id = '') {
		$this->db->select ( 'idzone,
				zone' );
		$this->db->order_by ( 'zone' );
		$this->db->from ( 'zones' );
		$this->db->where ( 'zones.active', '1' );
		$this->db->where ( 'zones.isdeleted', '0' );
		$this->db->where ( 'zones.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idzone']) {
					$this->str .= '<option value="' . $row ['idzone'] . '" selected="true">' . $row ['zone'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idzone'] . '">' . $row ['zone'] . '</option>';
				}
			}
		}
		return $this->str;
	}
	
	/**
	 * Function to fetch get State name
	 */
	public function getStatename($Id = '') {
		if (empty ( $Id )) {
			$this->db->select ( 'states.idstate' );
			$this->db->from ( 'states' );
			$this->db->join ( 'locations AS lc', "states.idstate = lc.idstate", 'LEFT' );
			$this->db->where ( 'lc.idlocation', $this->session->userdata ( 'idlocation' ) );
			
			$q = $this->db->get ();
			if ($q->num_rows () > 0) {
				$Id = $q->result_array ();
				$Id = $Id [0] ['idstate'];
			}
		}
		
		$this->db->select ( 'stt.idstate,
				stt.statename' );
		$this->db->order_by ( 'statename' );
		$this->db->from ( 'states AS stt' );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idstate']) {
					$this->str .= '<option value="' . $row ['idstate'] . '" selected="true">' . $row ['statename'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idstate'] . '">' . $row ['statename'] . '</option>';
				}
			}
		}
		return $this->str;
	}
}
