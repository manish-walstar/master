<?php
error_reporting(0);
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
ini_set ( "memory_limit", "102400000000000" );
ini_set ( "max_execution_time", "864000000000000" );
class Reporting_model extends CI_Model {
	public $data = "";
	public $trap_name = "";
	public $trap_count = "";
	public $str;
	
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to fetch Adult Surveillance
	 */
	public function getReporting($startdate = '', $enddate = '', $report_type = '', $report_name = '', $allsite = '', $allzone = '', $service = '') {
		$runrprt = $this->input->post ( 'runrpt' );
		$save = $this->input->post ( 'save' );
		$type = $this->input->post ( 'type' );
		$action = $this->input->post ( 'action' );
		$columns = $this->input->post ( 'column_2' );
		$column_name = $this->input->post ( 'column_name' );
		$column_keys = $this->input->post ( 'columns' );
		$idreporttype = $this->input->post ( 'idreporttype' );
		$report_id = "";
		$startdate_arr = explode ( "/", $startdate );
		$startdate = $startdate_arr [2] . "-" . $startdate_arr [0] . "-" . $startdate_arr [1];
		$all_fields = $this->input->get_post ( 'all_fields_1' );
		$enddate_arr = explode ( "/", $enddate );
		$enddate = $enddate_arr [2] . "-" . $enddate_arr [0] . "-" . $enddate_arr [1];
		
		if (isset ( $type ) && ! empty ( $type ) && $report_type == "labs") {
			switch ($type) {
				case 'arboviral' :
					$report_type = "arboviral";
					break;
				case 'corvid' :
					$report_type = "corvid";
					break;
				case 'sentinel' :
					$report_type = "sentinel";
					break;
			}
		}
		if (isset ( $type ) && ! empty ( $type ) && $report_type == "adult") {
			switch ($type) {
				case 'landing' :
					$report_type = "landing";
					break;
			}
		}
		if (isset ( $type ) && ! empty ( $type ) && $report_type == "treatments") {
			switch ($type) {
				case 'adult_trtmnt' :
					$report_type = "adult_trtmnt";
					break;
				case 'larval_trtmnt' :
					$report_type = "larval_trtmnt";
					break;
			}
		}
		
		$status = "";
		
		if (isset ( $type ) && ! empty ( $type ) && $report_type == "service_request") {
			switch ($type) {
				case 'open' :
					$status = "open";
					break;
				case 'close' :
					$status = "close";
					break;
			}
		}
		if (isset ( $type ) && ! empty ( $type ) && $report_type == "richmond_inspection") {
			switch ($type) {
				case 'outfall_inspection' :
					$report_type = "outfall_inspection";
					break;
				case 'maintenance_inspection' :
					$report_type = "maintenance_inspection";
					break;
			}
		}
		
		if (empty ( $runrprt ) && ! empty ( $save )) {
			$report_id = '';
			$data_1 = array (
					'reporttype' => $report_type,
					'report_subtype' => $type,
					'report_name' => ! empty ( $report_name ) ? $report_name : 'Report',
					'all_fields' => $all_fields,
					'report_fields' => $columns,
					'report_fields_names' => $column_name,
					'report_keys' => json_encode ( $column_keys ),
					'startdate' => $startdate,
					'enddate' => $enddate,
					'allsites' => ! empty ( $allsite ) ? json_encode ( $allsite ) : '',
					'allzones' => ! empty ( $allzone ) ? json_encode ( $allzone ) : '',
					'action' => ! empty ( $action ) ? $action : '',
					'idlocation' => $this->session->userdata ( 'idlocation' ) 
			);
			// print'<pre>';
			// print_r($data_1);
			// die;
			$msg = '';
			if (! empty ( $idreporttype )) {
				$this->db->select ( '*' );
				$this->db->from ( 'reportypes' );
				$this->db->where ( 'idreportype', $idreporttype );
				
				$chk = $this->db->get ();
				
				if ($chk->num_rows () > 0) {
					$this->db->where ( 'idreportype', $idreporttype );
					$this->db->update ( 'reportypes', $data_1 );
					
					$msg = "updated";
				} else {
					$this->db->insert ( 'reportypes', $data_1 );
					$report_id = $this->db->insert_id ();
					$msg = "success";
				}
			} else {
				$this->db->insert ( 'reportypes', $data_1 );
				$report_id = $this->db->insert_id ();
				$msg = "success";
			}
			
			// echo $this->db->last_query()."<br>";
			// print'<pre>';
			// print_r($data_1);
			// print_r(str_replace(",","",base64_decode($data_1['report_fields'])));
			// die;
		}
		
		switch ($report_type) {
			case 'larval' :
				$this->data = $this->getLarvalData ( $startdate, $enddate, $allsite, $allzone );
				break;
			case 'adult' :
				$this->data = $this->getAdultData ( $startdate, $enddate, $allsite, $allzone );
				break;
			case 'landing' :
				$this->data = $this->getLandingData ( $startdate, $enddate, $allsite, $allzone );
				break;
			case 'arboviral' :
				$this->data = $this->getArboviralData ( $startdate, $enddate, $allsite, $allzone );
				break;
			case 'corvid' :
				$this->data = $this->getCorvidData ( $startdate, $enddate, $allsite, $allzone );
				break;
			case 'sentinel' :
				$this->data = $this->getSentinelData ( $startdate, $enddate, $allsite, $allzone );
				break;
			case 'service_request' :
				$this->data = $this->getServiceRequestData ( $startdate, $enddate, $allsite, $allzone, $status, $action );
				break;
			case 'adult_trtmnt' :
				$this->data = $this->getAdulttrtData ( $startdate, $enddate, $allsite, $allzone );
				break;
			case 'larval_trtmnt' :
				$this->data = $this->getLarvaltrtData ( $startdate, $enddate, $allsite, $allzone );
				break;
			case 'weather' :
				$this->data = $this->getWeatherData ( $startdate, $enddate, $allsite, $allzone );
				break;
			case 'maintenance_inspection':
				$this->data = $this->getMaintenanceinspectionData( $startdate, $enddate, $allsite, $allzone );
				break;
			case 'outfall_inspection':
				$this->data = $this->getOutfallinspectionData( $startdate, $enddate, $allsite, $allzone );
				break;
		}
		$this->data ['report_id'] = $report_id;
		$this->data ['msg'] = ! empty ( $msg ) ? $msg : '';
		return $this->data;
	}
	
	/**
	 * Function to delete Report
	 */
	public function deleteReportData() {
		$id = $this->input->get ( 'id' );
		
		if (empty ( $id ))
			return false;
		
		$this->db->select ( '*' );
		$this->db->from ( 'reportypes' );
		$this->db->where ( 'idreportype', $id );
		
		$q = $this->db->get ();
		$rows = "";
		if ($q->num_rows () > 0) {
			$this->db->where ( 'idreportype', $id );
			$this->db->delete ( 'reportypes' );
			$rows = $this->db->affected_rows ();
		}
		
		if (! empty ( $rows ) && ! empty ( $id ))
			return true;
		
		return false;
	}
	
	/**
	 * Function to fetch Larval Data to display
	 * Reporting Module
	 */
	public function getLarvalData($startdate = '', $enddate = '', $site = '', $zone = '') {
		$this->db->select ( 'ld.idlarvalsurveillance ,
				ld.date, 
				ld.retreatdate, 
				ld.retreatdays, 
				ld.time, 
				ld.idsite, 
				ld.maplabel, 
				ld.idsitestatus, 
				ld.idwatertemprange, 
				ld.larvaepresent, 
				ld.idinstar, 
				ld.idinspector, 
				ld.latitude, 
				ld.longitude, 
				ld.comments, 
				ld.totalcount, 
				ld.idlocation, 
				ld.locationkey, 
				ld.legalentitykey, 
				ld.isdeleted,
				s.*,
				state.statename,
				st.sitetype,
				z.zone,
				ss.sitestatus,
				wt.watertemprange,
				instar.instar,
				CONCAT(u.firstname," ",u.middlename," ",u.lastname) AS inspector,
				u.officephone,
				u.mobilephone, 
				m.mosquitospecies AS subspecies , 
				g.genus AS species , 
				g.genus AS genus', FALSE );
		$this->db->from ( 'larvalsurveillance AS ld' );
		$this->db->join ( 'sitestatuses AS ss', 'ld.idsitestatus = ss.idsitestatus', 'LEFT' );
		$this->db->join ( 'watertempranges AS wt', 'ld.idwatertemprange = wt.idwatertemprange', 'LEFT' );
		$this->db->join ( 'instar', 'ld.idinstar = instar.idinstar', 'LEFT' );
		$this->db->join ( 'users AS u', 'ld.idinspector = u.iduser', 'LEFT' );
		$this->db->join ( 'sites AS s', 'ld.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'states AS state', 's.idstate = state.idstate', 'LEFT' );
		$this->db->join ( 'sitetypes AS st', 's.idsitetype = st.idsitetype', 'LEFT' );
		$this->db->join ( 'zones AS z', 's.idzone = z.idzone', 'LEFT' );
		$this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
		$this->db->where ( "s.idlocation", $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'ld.isdeleted', '0' );
		$this->db->where ( 'ld.idsite <> 0' );
		$this->db->join ( 'larvalsurveillancedetails AS ldst', 'ld.idlarvalsurveillance = ldst.idlarvalsurveillance', 'LEFT' );
		$this->db->join ( 'mosquitospecies AS m', 'ldst.idmosquitospecies = m.idmosquitospecies', 'LEFT' );
		$this->db->join ( 'genuses AS g', 'm.idgenus = g.idgenus', 'LEFT' );
		$this->db->order_by ( 'ld.date', 'DESC' );
		$this->db->order_by ( 'ld.time', 'DESC' );
		if (! empty ( $startdate ) && ! empty ( $enddate )) {
			$this->db->where ( 'date >=', $startdate );
			$this->db->where ( 'date <=', $enddate );
		}
		
		if (! empty ( $site )) {
			$s_site = "";
			
			if ($site [0] != "on" && $site [0] != "") {
				foreach ( $site as $k_s => $v_s ) {
					$s_site .= "'" . $v_s . "',";
				}
				
				$s_site = trim ( $s_site, "," );
				$cond = " s.idsite IN (" . $s_site . ")";
				$this->db->where ( $cond );
			}
		}
		
		if (! empty ( $zone )) {
			$s_zone = "";
			
			if ($zone [0] != "on" && $zone [0] != "") {
				foreach ( $zone as $k_z => $v_z ) {
					$s_zone .= "'" . $v_z . "',";
				}
				
				$s_zone = trim ( $s_zone, "," );
				$cond = " z.idzone IN (" . $s_zone . ")";
				$this->db->where ( $cond );
			}
		}
		
		$query = $this->db->get ();
		// echo $this->db->last_query();
		$mos = array ();
		$j = 0;
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				// $this->db->select('m.mosquitospecies,g.genus');
				// $this->db->from('mosquitospecies AS m');
				// $this->db->join('larvalsurveillancedetails AS ldst','m.idmosquitospecies = ldst.idmosquitospecies','LEFT');
				// $this->db->join('genuses AS g','m.idgenus = g.idgenus','LEFT');
				// $this->db->where('ldst.idlarvalsurveillance',$row['idlarvalsurveillance']);
				//
				// $q = $this->db->get();
				// $k = 0;
				$mos [$j] = $row;
				// if($q -> num_rows() > 0)
				// {
				// foreach($q->result_array() as $k => $v)
				// {
				// $mos[$j]['species'] = $v['genus'];
				// $mos[$j]['subspecies'] = $v['mosquitospecies'];
				// $mos[$j]['genus'] = $v['genus'];
				// $k++;
				// }
				// }
				// else
				// {
				// $mos[$j]['species'] = "";
				// $mos[$j]['subspecies'] = "";
				// $mos[$j]['genus'] = "";
				// }
				
				$j ++;
			}
		}
		$this->data = $mos;
		// print'<pre>';
		// print_r($mos);
		// die;
		
		return $this->data;
	}
	
	/**
	 * Function to fetch Adult Surveillance Data to display
	 * Reporting Module
	 */
	public function getAdultData($startdate = '', $enddate = '', $site = '', $zone = '') {
		$this->db->select ( 'ad.*,
				t.*,
				s.*,
				state.statename,
				z.idzone,
				z.zone,
				tr.temprange,
				hr.humidityrange,
				ws.windspeed,
				cc.cloudcoverage,
				tt.traptype,
				b.baittype,
				u.officephone,
				u.mobilephone,
				CONCAT(u.firstname," ",u.middlename," ",u.lastname) AS inspector', FALSE );
		// $this->db->select('ad.idadultsurveillance');
		$this->db->from ( 'adultsurveillance AS ad' );
		$this->db->join ( 'traps AS t', 'ad.idtrap = t.idtrap', 'LEFT' );
		$this->db->join ( 'traptypes AS tt', 't.idtraptype = tt.idtraptype', 'LEFT' );
		$this->db->join ( 'baittypes AS b', 't.idbaittype = b.idbaittype', 'LEFT' );
		$this->db->join ( 'sites AS s', 't.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'states AS state', 's.idstate = state.idstate', 'LEFT' );
		// $this->db->join('sitezoneassignment AS sz','s.idsite = sz.idsite','LEFT');
		$this->db->join ( 'zones AS z', 's.idzone = z.idzone', 'LEFT' );
		$this->db->join ( 'tempranges AS tr', 'ad.idtemprange = tr.idtemprange', 'LEFT' );
		$this->db->join ( 'humidityranges AS hr', 'ad.idhumidityrange = hr.idhumidityrange', 'LEFT' );
		$this->db->join ( 'windspeeds AS ws', 'ad.idwindspeed = ws.idwindspeed', 'LEFT' );
		$this->db->join ( 'cloudcoverage AS cc', 'ad.idcloudcover = cc.idcloudcoverage', 'LEFT' );
		$this->db->join ( 'users AS u', 'ad.idinspector = u.iduser', 'LEFT' );
		$this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'INNER' );
		$this->db->where ( "s.idlocation", $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'ad.isdeleted', '0' );
		$this->db->where ( 't.idsite <> 0' );
		$this->db->order_by ( 'ad.pudate', 'DESC' );
		$this->db->order_by ( 'ad.putime', 'DESC' );
		if (! empty ( $startdate ) && ! empty ( $enddate )) {
			$this->db->where ( 'ad.pudate >=', $startdate );
			$this->db->where ( 'ad.pudate <=', $enddate );
		}
		
		if (! empty ( $site )) {
			$s_site = "";
			
			if ($site [0] != "on" && $site [0] != "") {
				foreach ( $site as $k_s => $v_s ) {
					$s_site .= "'" . $v_s . "',";
				}
				$s_site = trim ( $s_site, "," );
				$cond = " s.idsite IN (" . $s_site . ")";
				$this->db->where ( $cond );
				// $this->db->where_in('s.idsite',$s_site);
			}
		}
		
		if (! empty ( $zone )) {
			$s_zone = "";
			
			if ($zone [0] != "on" && $zone [0] != "") {
				foreach ( $zone as $k_z => $v_z ) {
					$s_zone .= "'" . $v_z . "',";
				}
				
				$s_zone = trim ( $s_zone, "," );
				$cond = " z.idzone IN (" . $s_zone . ")";
				$this->db->where ( $cond );
			}
		}
		
		$query = $this->db->get ();
		// echo $this->db->last_query();
		$adult = array ();
		$mos = array ();
		$j = 0;
		$i = 0;
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->db->select ( 'm.mosquitospecies,
						g.genus,
						adst.count AS count' );
				$this->db->from ( 'mosquitospecies AS m' );
				$this->db->join ( 'adultsurveillancedetails AS adst', 'm.idmosquitospecies = adst.idmosquitospecies', 'LEFT' );
				$this->db->join ( 'genuses AS g', 'm.idgenus = g.idgenus', 'INNER' );
				$this->db->where ( 'adst.idadultsurveillance', $row ['idadultsurveillance'] );
				
				$q = $this->db->get ();
				// echo $this->db->last_query()."<br>";
				$k = 0;
				$mos [$j] = $row;
				$mosstr = '';
				
				if ($q->num_rows () > 0) {
					foreach ( $q->result_array () as $k => $v ) {
						
						if (! empty ( $v ['genus'] ) && ! empty ( $v ['mosquitospecies'] ) && ! empty ( $v ['count'] ))
							$mosstr .= $v ['genus'] . " (" . $v ['mosquitospecies'] . ")" . ": " . $v ['count'];
						else if (! empty ( $v ['mosquitospecies'] ) && ! empty ( $v ['count'] ))
							$mosstr .= " (" . $v ['mosquitospecies'] . ")" . ": " . $v ['count'];
						
						$mosstr .= "<br>";
						
						$k ++;
					}
					$mos [$j] ['speciescount'] = $mosstr;
				} else {
					$mos [$j] ['speciescount'] = "";
				}
				
				$middlename = ! empty ( $row ['middlename'] ) ? " " . $row ['middlename'] . " " : " ";
				// $adult[$j] = $row;
				// $adult[$j]['inspector'] = $row['firstname'].$middlename.$row['lastname'];
				// $adult[$j]['inspectorphn'] = $row['officephone'];
				$adult [] = $mos;
				
				$j ++;
				$i ++;
			}
		}
		$this->data = $mos;
		// print'<pre>';
		// print_R($this->data);
		// die;
		return $this->data;
		// return $query->result_array();
	}
	
	/**
	 * Function to fetch Landing Data to display
	 * Reporting Module
	 */
	public function getLandingData($startdate = '', $enddate = '', $site = '', $zone = '') {
		$this->db->select ( 'l.*,
				s.*,
				state.statename,
				d.durations,
				z.idzone,
				z.zone,
				tr.temprange,
				hr.humidityrange,
				ws.windspeed,
				cc.cloudcoverage,
				u.officephone,
				u.mobilephone,
				CONCAT(u.firstname," ",u.middlename," ",u.lastname) AS inspector', FALSE );
		// $this->db->select('ad.idadultsurveillance');
		$this->db->from ( 'landingrates AS l' );
		$this->db->join ( 'sites AS s', 'l.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'states AS state', 's.idstate = state.idstate', 'LEFT' );
		$this->db->join ( 'zones AS z', 's.idzone = z.idzone', 'LEFT' );
		$this->db->join ( 'durations AS d', 'l.idduration = d.idduration', 'LEFT' );
		$this->db->join ( 'tempranges AS tr', 'l.idtemprange = tr.idtemprange', 'LEFT' );
		$this->db->join ( 'humidityranges AS hr', 'l.idhumidityrange = hr.idhumidityrange', 'LEFT' );
		$this->db->join ( 'windspeeds AS ws', 'l.idwindspeed = ws.idwindspeed', 'LEFT' );
		$this->db->join ( 'cloudcoverage AS cc', 'l.idcloudcoverage = cc.idcloudcoverage', 'LEFT' );
		$this->db->join ( 'users AS u', 'l.idinspector = u.iduser', 'LEFT' );
		$this->db->join ( 'locations AS lc', "s.idlocation = lc.idlocation", 'INNER' );
		$this->db->where ( "s.idlocation", $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'l.isdeleted', '0' );
		$this->db->where ( 'l.idsite <> 0' );
		$this->db->order_by ( 'l.observeddate', 'DESC' );
		$this->db->order_by ( 'l.observedtime', 'DESC' );
		if (! empty ( $startdate ) && ! empty ( $enddate )) {
			$this->db->where ( 'l.observeddate >=', $startdate );
			$this->db->where ( 'l.observeddate <=', $enddate );
		}
		
		if (! empty ( $site )) {
			$s_site = "";
			
			if ($site [0] != "on" && $site [0] != "") {
				foreach ( $site as $k_s => $v_s ) {
					$s_site .= "'" . $v_s . "',";
				}
				
				$s_site = trim ( $s_site, "," );
				$cond = " s.idsite IN (" . $s_site . ")";
				$this->db->where ( $cond );
			}
		}
		
		if (! empty ( $zone )) {
			$s_zone = "";
			
			if ($zone [0] != "on" && $zone [0] != "") {
				foreach ( $zone as $k_z => $v_z ) {
					$s_zone .= "'" . $v_z . "',";
				}
				
				$s_zone = trim ( $s_zone, "," );
				$cond = " z.idzone IN (" . $s_zone . ")";
				$this->db->where ( $cond );
			}
		}
		
		$query = $this->db->get ();
		
		$mos = array ();
		$j = 0;
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->db->select ( 'm.mosquitospecies,
						g.genus,
						lsdt.count AS count' );
				$this->db->from ( 'mosquitospecies AS m' );
				$this->db->join ( 'landingratedetails AS lsdt', 'm.idmosquitospecies = lsdt.idlocationvectorspecies', 'LEFT' );
				$this->db->join ( 'genuses AS g', 'm.idgenus = g.idgenus', 'INNER' );
				$this->db->where ( 'lsdt.idlandingrate ', $row ['idlandingrate'] );
				
				$q = $this->db->get ();
				$k = 0;
				
				$mos [$j] = $row;
				$mosstr = '';
				if ($q->num_rows () > 0) {
					$tstr = '';
					foreach ( $q->result_array () as $k => $v ) {
						if (! empty ( $v ['genus'] ))
							$tstr = $v ['genus'];
						
						if (! empty ( $v ['genus'] ) && ! empty ( $v ['mosquitospecies'] ))
							$tstr .= "(" . $v ['mosquitospecies'] . ")";
						else if (! empty ( $v ['mosquitospecies'] ))
							$tstr = "(" . $v ['mosquitospecies'] . ")";
						else
							$tstr = "";
						
						if (! empty ( $v ['mosquitospecies'] ) && ! empty ( $v ['count'] ))
							$tstr .= ": " . $v ['count'];
						else if (! empty ( $v ['count'] ))
							$tstr .= $v ['count'];
						
						$mosstr .= $tstr . '<br/>';
					}
				}
				$mos [$j] ['speciescount'] = $mosstr;
				
				$j ++;
			}
		}
		
		// print'<pre>';
		// print_r($mos);
		// die;
		$this->data = $mos;
		return $this->data;
	}
	
	/**
	 * Function to fetch Arboviral Data to display
	 * Reporting Module
	 */
	public function getArboviralData($startdate = '', $enddate = '', $site = '', $zone = '') {
		$this->db->select ( 'al.*,
				t.*,
				z.zone,
				s.*,
				ts.*,
				ast.assaytype,
				lr.labresult AS positiveresult,
				vt.virustypes,
				ads.*,
				bt.baittype,
				stt.statename,
				cc.cloudcoverage,
				ws.windspeed,
				hr.humidityrange,
				tr.temprange,
				CONCAT(usr.firstname," ",usr.middlename," ",usr.lastname) AS inspector,
				CONCAT(usrs.firstname," ",usrs.middlename," ",usrs.lastname) AS technician,
				usr.officephone', FALSE );
		$this->db->from ( 'arbovirallabs AS al' );
		$this->db->join ( 'traps AS t', 'al.idtrap=t.idtrap', 'LEFT' );
		$this->db->join ( 'sites AS s ', 't.idsite = s.idsite ', "LEFT" );
		$this->db->join ( 'zones AS z', ' s.idzone= z.idzone ', "LEFT" );
		$this->db->join ( 'virustypes AS vt', 'al.idvirustype = vt.idvirustype', 'LEFT' );
		$this->db->join ( 'labresults as lr', 'al.idlabresult = lr.idlabresult', 'LEFT' );
		$this->db->join ( 'traptypes AS ts ', 't.idtraptype = ts.idtraptype ', "LEFT" );
		$this->db->join ( 'baittypes AS bt', 't.idbaittype = bt.idbaittype ', "LEFT" );
		$this->db->join ( 'assaytypes as ast', 'al.idassaytype= ast.idassaytype', 'LEFT' );
		$this->db->join ( 'adultsurveillance as ads', 'al.idadultsurveillance = ads.idadultsurveillance', 'LEFT' );
		$this->db->join ( 'users AS usr', 'ads.idinspector = usr.iduser', "LEFT" );
		$this->db->join ( 'users AS usrs', 'al.idlabtechnician = usrs.iduser', "LEFT" );
		$this->db->join ( 'states AS stt', ' s.idstate= stt.idstate ', "LEFT" );
		$this->db->join ( 'cloudcoverage AS cc', 'ads.idcloudcover= cc.cloudcoverage', 'LEFT' );
		$this->db->join ( 'windspeeds as ws', 'ads.idwindspeed = ws.idwindspeed', 'LEFT' );
		$this->db->join ( 'humidityranges as hr', 'ads.idhumidityrange = hr.idhumidityrange', 'LEFT' );
		$this->db->join ( 'tempranges as tr', 'ads.idtemprange = tr.idtemprange', 'LEFT' );
		$this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'INNER' );
		$this->db->where ( "s.idlocation", $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'al.isdeleted', '0' );
		$this->db->where ( 't.idsite <> 0' );
		$this->db->order_by ( 'al.testdate', 'DESC' );
		if (! empty ( $startdate ) && ! empty ( $enddate )) {
			$this->db->where ( 'testdate >=', $startdate );
			$this->db->where ( 'testdate <=', $enddate );
		}
		
		if (! empty ( $site )) {
			$s_site = "";
			
			if ($site [0] != "on" && $site [0] != "") {
				foreach ( $site as $k_s => $v_s ) {
					$s_site .= "'" . $v_s . "',";
				}
				
				$s_site = trim ( $s_site, "," );
				$cond = " s.idsite IN (" . $s_site . ")";
				$this->db->where ( $cond );
			}
		}
		
		if (! empty ( $zone )) {
			$s_zone = "";
			
			if ($zone [0] != "on" && $zone [0] != "") {
				foreach ( $zone as $k_z => $v_z ) {
					$s_zone .= "'" . $v_z . "',";
				}
				
				$s_zone = trim ( $s_zone, "," );
				$cond = " z.idzone IN (" . $s_zone . ")";
				$this->db->where ( $cond );
			}
		}
		
		$query = $this->db->get ();
		// echo $this->db->last_query();
		$adult = array ();
		$mos = array ();
		$j = 0;
		$i = 0;
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->db->select ( 'm.mosquitospecies,
						g.genus,
						adst.count' );
				$this->db->from ( 'mosquitospecies AS m' );
				$this->db->join ( 'adultsurveillancedetails AS adst', 'm.idmosquitospecies = adst.idmosquitospecies', 'LEFT' );
				$this->db->join ( 'genuses AS g', 'm.idgenus = g.idgenus', 'INNER' );
				$this->db->where ( 'adst.idadultsurveillance', $row ['idadultsurveillance'] );
				
				$q = $this->db->get ();
				$k = 0;
				
				if ($q->num_rows () > 0) {
					foreach ( $q->result_array () as $k => $v ) {
						$mos [$j] = $row;
						$mos [$j] ['species'] = $v ['genus'];
						$mos [$j] ['subspecies'] = $v ['mosquitospecies'];
						$mos [$j] ['collectedcount'] = $v ['count'];
						$k ++;
					}
				} else {
					$mos [$j] = $row;
					$mos [$j] ['species'] = "";
					$mos [$j] ['subspecies'] = "";
					$mos [$j] ['collectedcount'] = 0;
				}
				
				$middlename = ! empty ( $row ['middlename'] ) ? " " . $row ['middlename'] . " " : " ";
				// $adult[$j] = $row;
				// $adult[$j]['inspector'] = $row['firstname'].$middlename.$row['lastname'];
				// $adult[$j]['inspectorphn'] = $row['officephone'];
				$adult [] = $mos;
				
				$j ++;
				$i ++;
			}
		}
		$this->data = $mos;
		// print'<pre>';
		// print_r($this->data);
		// die;
		return $this->data;
		// return $query->result_array();
	}
	
	/**
	 * Function to fetch Corvid Data to display
	 * Reporting Module
	 */
	public function getCorvidData($startdate = '', $enddate = '', $site = '', $zone = '') {
		$this->db->select ( 'cl.idcorvidlab,
				cl.sampleid,
				cl.datecollected,
				cl.idsite,
				cl.idsitetype,
				cl.idzone,
				cl.maplabel,
				cl.latitude,
				cl.longitude,
				cl.pdop,
				z.zone,
				s.*,
				av.avianspecies,
				ast.assaytype,
				lr.labresult AS positiveresult,
				vt.virustypes,
				stt.statename,
				CONCAT(cl.collectedbyfirst," ",cl.collectedbylast) AS collected_by,
				cl.idavianspecies,
				cl.idassaytype,
				cl.idlabresult,
				cl.idvirustype,
				cl.rampunits,
				cl.comments,
				cl.rtprcconfirm,
				cl.resultscorresspond', FALSE );
		$this->db->from ( 'corvidlabs AS cl' );
		$this->db->join ( 'sites AS s ', 'cl.idsite = s.idsite ', "LEFT" );
		$this->db->join ( 'zones AS z', ' s.idzone= z.idzone ', "LEFT" );
		$this->db->join ( 'avianspecies AS av', ' cl.idavianspecies= av.idavianspecies ', "LEFT" );
		$this->db->join ( 'states AS stt', ' s.idstate= stt.idstate ', "LEFT" );
		$this->db->join ( 'virustypes AS vt', 'cl.idvirustype = vt.idvirustype', 'LEFT' );
		$this->db->join ( 'labresults as lr', 'cl.idlabresult = lr.idlabresult', 'LEFT' );
		$this->db->join ( 'assaytypes as ast', 'cl.idassaytype= ast.idassaytype', 'LEFT' );
		$this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'INNER' );
		$this->db->where ( "s.idlocation", $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'cl.isdeleted', '0' );
		$this->db->where ( 'cl.idsite <> 0' );
		$this->db->order_by ( 'cl.datecollected', 'DESC' );
		if (! empty ( $startdate ) && ! empty ( $enddate )) {
			$this->db->where ( 'cl.datecollected >=', $startdate );
			$this->db->where ( 'cl.datecollected <=', $enddate );
		}
		
		if (! empty ( $site )) {
			$s_site = "";
			
			if ($site [0] != "on" && $site [0] != "") {
				foreach ( $site as $k_s => $v_s ) {
					$s_site .= "'" . $v_s . "',";
				}
				
				$s_site = trim ( $s_site, "," );
				$cond = " s.idsite IN (" . $s_site . ")";
				$this->db->where ( $cond );
			}
		}
		
		if (! empty ( $zone )) {
			$s_zone = "";
			
			if ($zone [0] != "on" && $zone [0] != "") {
				foreach ( $zone as $k_z => $v_z ) {
					$s_zone .= "'" . $v_z . "',";
				}
				
				$s_zone = trim ( $s_zone, "," );
				$cond = " z.idzone IN (" . $s_zone . ")";
				$this->db->where ( $cond );
			}
		}
		
		$query = $this->db->get ();
		
		$adult = array ();
		$mos = array ();
		$j = 0;
		$i = 0;
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$mos [$j] = $row;
				
				$j ++;
			}
		}
		$this->data = $mos;
		// print'<pre>';
		// print_r($this->data);
		// die;
		return $this->data;
		// return $query->result_array();
	}
	
	/**
	 * Function to fetch Sentinel Data to display
	 * Reporting Module
	 */
	public function getSentinelData($startdate = '', $enddate = '', $site = '', $zone = '') {
		$this->db->select ( 'sl.*,
				sc.*,
				scs.bandid AS samplename,
				z.zone,
				s.*,
				ast.assaytype,
				lr.labresult AS result,
				vt.virustypes,
				stt.statename' );
		$this->db->from ( 'sentinelchickenlabs AS sl' );
		$this->db->join ( 'sentinelchicken AS sc', ' sc.idsentinelchicken= sl.idsentinelchicken ', "LEFT" );
		$this->db->join ( 'sentinelchickensamples AS scs', ' sc.idsentinelchicken= scs.idsentinelchicken ', "LEFT" );
		$this->db->join ( 'sites AS s ', 'sc.idsite = s.idsite ', "LEFT" );
		$this->db->join ( 'zones AS z', ' s.idzone= z.idzone ', "LEFT" );
		$this->db->join ( 'virustypes AS vt', 'sl.idvirustype = vt.idvirustype', 'LEFT' );
		$this->db->join ( 'assaytypes as ast', 'sl.idassaytype= ast.idassaytype', 'LEFT' );
		$this->db->join ( 'labresults as lr', 'sl.idlabresult = lr.idlabresult', 'LEFT' );
		$this->db->join ( 'states AS stt', ' s.idstate= stt.idstate ', "LEFT" );
		$this->db->group_by ( 'sl.datesubmitted' );
		$this->db->where ( 'sl.isdeleted', '0' );
		$this->db->where ( 'sc.idsite <> 0' );
		$this->db->where ( "s.idlocation", $this->session->userdata ( 'idlocation' ) );
		$this->db->order_by ( 'sl.dateresults', 'DESC' );
		if (! empty ( $startdate ) && ! empty ( $enddate )) {
			$this->db->where ( 'datesubmitted >=', $startdate );
			$this->db->where ( 'datesubmitted <=', $enddate );
		}
		
		if (! empty ( $site )) {
			$s_site = "";
			
			if ($site [0] != "on" && $site [0] != "") {
				foreach ( $site as $k_s => $v_s ) {
					$s_site .= "'" . $v_s . "',";
				}
				
				$s_site = trim ( $s_site, "," );
				$cond = " s.idsite IN (" . $s_site . ")";
				$this->db->where ( $cond );
			}
		}
		
		if (! empty ( $zone )) {
			$s_zone = "";
			
			if ($zone [0] != "on" && $zone [0] != "") {
				foreach ( $zone as $k_z => $v_z ) {
					$s_zone .= "'" . $v_z . "',";
				}
				
				$s_zone = trim ( $s_zone, "," );
				$cond = " z.idzone IN (" . $s_zone . ")";
				$this->db->where ( $cond );
			}
		}
		
		$query = $this->db->get ();
		// echo $this->db->last_query();
		$adult = array ();
		$mos = array ();
		$j = 0;
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$mos [$j] = $row;
				$j ++;
			}
		}
		$this->data = $mos;
		// print'<pre>';
		// print_r($this->data);
		// die;
		return $this->data;
		// return $query->result_array();
	}
	
	/**
	 * Function to fetch Adult Tretment Data to display
	 * Reporting Module
	 */
	public function getAdulttrtData($startdate = '', $enddate = '', $site = '', $zone = '') {
		$this->db->select ( 'adt.*, 
				treatmentjustification.justification, 
				s.site, 
				s.address1, 
				s.address2, 
				s.city, 
				s.postalcode, 
				st.sitetype, 
				sg.sitegroup, 
				z.zone, 
				sr.*, 
				sty.systemtype, 
				apm.applicationmethod, 
				tr.temprange AS tempstart, 
				tre.temprange AS tempend, 
				hr.humidityrange, 
				at.unitarea, 
				adt.latitude, 
				adt.longitude, 
				fm.formulation, 
				adt.comments, 
				pu.unitproduct, 
				ws.windspeed, 
                wdd.winddirection,
				cc.cloudcoverage, 
				p.productname, 
				p.productcode, 
				p.productlink,
				p.onhand, 
				mr.mixratio, 
				ds.dilutent, 
				art.applicationratetype, 
				aru.applicationrateuom, 
				frt.flowrate AS fl, 
                ps.*, 
				pm.*, 
				pp.*, 
				pcksz.*, 
				p.*, 
				stt.statename, 
				syst.systemtype, 
				fmx.unitfinishedmix, 
				CONCAT(usr.firstname," ",usr.middlename," ",usr.lastname) AS applicator, 
				usr.officephone AS applicatorphn, 
				pti.date AS ptidate, 
				pti.time AS ptitime, 
				pti.trtmnt_type, 
				pti.idlocation AS ptilocation', FALSE );
		$this->db->from ( 'adulticidetreatments AS adt' );
		$this->db->join ( 'treatmentjustification', 'adt.trtmnt_justification = treatmentjustification.idtreatmentjustification', 'LEFT' );
		$this->db->join ( 'sites AS s', 'adt.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'sitegroups AS sg', 's.idsitegroup = sg.idsitegroup', 'LEFT' );
		$this->db->join ( 'sitetypes as st', 's.idsitetype = st.idsitetype', 'LEFT' );
		$this->db->join ( 'zones AS z', ' s.idzone= z.idzone ', "LEFT" );
		$this->db->join ( 'users AS usr', 'adt.idapplicator = usr.iduser', "LEFT" );
		$this->db->join ( 'servicerequests as sr', 'adt.idservicerequest= sr.idservicerequest', 'LEFT' );
		$this->db->join ( 'systemtypes as sty', 'adt.idsystemtype = sty.idsystemtype', 'LEFT' );
		$this->db->join ( 'applicationmethods as apm', 'adt.idapplicationmethod = apm.idapplicationmethods', 'LEFT' );
		$this->db->join ( 'tempranges as tr', 'adt.idtempatstart = tr.idtemprange', 'LEFT' );
		$this->db->join ( 'tempranges as tre', 'adt.idtempatend = tre.idtemprange', 'LEFT' );
		$this->db->join ( 'humidityranges as hr', 'adt.idhumidityrange = hr.idhumidityrange', 'LEFT' );
		$this->db->join ( 'area_treated as at', 'adt.iduomtotalareatreated = at.idareatreated', 'LEFT' );
		$this->db->join ( 'windspeeds as ws', 'adt.idwindspeed = ws.idwindspeed', 'LEFT' );
		$this->db->join ( 'winddirections AS wdd', 'adt.idwinddirection = wdd.idwinddirection ', "LEFT" );
		$this->db->join ( 'cloudcoverage as cc', 'adt.idcloudcover = cc.idcloudcoverage', 'LEFT' );
		$this->db->join ( 'productunit as pu', 'adt.iduomtotalproductapplied = pu.idproductunit', 'LEFT' );
		$this->db->join ( 'products as p', 'adt.idproduct=p.idproduct', 'LEFT' );
		$this->db->join ( 'formulations as fm', 'p.idformulation=fm.idformulation', 'LEFT' );
		$this->db->join ( 'mixratios as mr', 'adt.idmixratio=mr.idmixratio', 'LEFT' );
		$this->db->join ( 'dilutents as ds', 'adt.iddilutent=ds.iddilutent', 'LEFT' );
		$this->db->join ( 'applicationratetypes as art', 'adt.idapplicationratetype=art.idapplicationratetypes', 'LEFT' );
		$this->db->join ( 'applicationrateuom as aru', 'adt.idapplicationrateuom=aru.idapplicationrateuom', 'LEFT' );
		$this->db->join ( 'flowratetypes as frt', 'adt.idflowratetypes=frt.idflowratetype', 'LEFT' );
		$this->db->join ( 'productsizes AS ps', 'p.idproductsize= ps.idproductsize', 'LEFT' );
		$this->db->join ( 'packsizes AS pcksz', 'p.idpacksize = pcksz.idpacksize', 'LEFT' );
		$this->db->join ( 'productmanufacturers as pm', 'p.idmanufacturer=pm.idmanufacturer', 'LEFT' );
		$this->db->join ( 'productpotency as pp', 'p.idpotency=pp.idpotency', 'LEFT' );
		$this->db->join ( 'states AS stt', ' s.idstate= stt.idstate ', "LEFT" );
		$this->db->join ( 'systemtypes as syst', 'adt.idsystemtype= syst.idsystemtype', 'LEFT' );
		$this->db->join ( 'finishedmix as fmx', 'adt.iduomfinishedmix= fmx.idfinishedmix', 'LEFT' );
		$this->db->join ( 'post_treatment_inspection as pti', 'adt.idadulticidetreatment = pti.idtreatment', 'LEFT' );
		$this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'INNER' );
		$this->db->where ( "s.idlocation", $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'adt.isdeleted', '0' );
		$this->db->where ( 'adt.idsite <> 0' );
		$this->db->order_by ( 'adt.date', 'DESC' );
		$this->db->order_by ( 'adt.time', 'DESC' );
		if (! empty ( $startdate ) && ! empty ( $enddate )) {
			$this->db->where ( 'adt.date >=', $startdate );
			$this->db->where ( 'adt.date <=', $enddate );
		}
		
		if (! empty ( $site )) {
			$s_site = "";
			
			if ($site [0] != "on" && $site [0] != "") {
				foreach ( $site as $k_s => $v_s ) {
					$s_site .= "'" . $v_s . "',";
				}
				
				$s_site = trim ( $s_site, "," );
				$cond = " s.idsite IN (" . $s_site . ")";
				$this->db->where ( $cond );
			}
		}
		
		if (! empty ( $zone )) {
			$s_zone = "";
			
			if ($zone [0] != "on" || $zone [0] != "") {
				foreach ( $zone as $k_z => $v_z ) {
					$s_zone .= "'" . $v_z . "',";
				}
				
				$s_zone = trim ( $s_zone, "," );
				$cond = " z.idzone IN (" . $s_zone . ")";
				$this->db->where ( $cond );
			}
		}
		
		$query = $this->db->get ();
		// echo $this->db->last_query();
		$adult = array ();
		$mos = array ();
		$j = 0;
		$i = 0;
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$mos [$j] = $row;
				if (! empty ( $row ['ptidate'] ) && ! empty ( $row ['trtmnt_type'] ) && $row ['trtmnt_type'] == 'adult' && $row ['ptilocation'] == $this->session->userdata ['idlocation']) {
					$date = date ( 'm/d/Y', strtotime ( $row ['ptidate'] ) );
					$mos [$j] ['ptidate'] = $date . " " . $row ['ptitime'];
					$mos [$j] ['pti'] = 'Yes';
				} else {
					$mos [$j] ['ptidate'] = '';
					$mos [$j] ['pti'] = 'No';
				}
				$mos [$j] ['reporttype'] = 'adult';
				$j ++;
			}
		}
		$this->data = $mos;
		
		// print'<pre>';
		// print_r($this->data);
		// die;
		return $this->data;
		// return $query->result_array();
	}
	
	/**
	 * Function to fetch Larval Tretment Data to display
	 * Reporting Module
	 */
	public function getLarvaltrtData($startdate = '', $enddate = '', $site = '', $zone = '') {
		$this->db->select ( 'lt.*, 
				treatmentjustification.justification, 
				s.site, 
				s.address1, 
				s.address2, 
				s.city, 
				s.postalcode, 
				sg.sitegroup, 
				st.sitetype,  
				syt.systemtype, 
				z.zone, 
				ss.sitestatus, 
				ws.weathercondition, 
				ins.instar, 
				ms.mosquitospecies, 
				ams.applicationmethod, 
				p.productname, 
				p.productcode, 
				f.formulation, 
				aru.applicationrateuom, 
				art.applicationratetype, 
				tms.treatmentmethod, 
				gn.genus, 
				stt.statename, 
				syst.systemtype, 
				fmx.unitfinishedmix, 
				mxr.mixratio, 
				CONCAT(usr.firstname," ",usr.middlename," ",usr.lastname) AS applicator, 
				usr.officephone AS applicatorphn, 
				ps.productsize, 
				pcksz.packsize, 
				pm.manufacturer, 
				pp.potency, 
				p.productlink, 
				p.onhand, 
				lt.post_trtmnt_inspection, 
				wsp.windspeed, 
				wdd.winddirection, 
				lt.post_trtmnt_date, 
				areauom.unitarea, 
				pu.unitproduct' );
		$this->db->from ( 'larvaltreatments as lt' );
		$this->db->join ( 'treatmentjustification', 'lt.trtmnt_justification = treatmentjustification.idtreatmentjustification', 'LEFT' );
		$this->db->join ( 'sites AS s', 'lt.idsite=s.idsite', 'LEFT' );
		$this->db->join ( 'sitegroups AS sg', 's.idsitegroup = sg.idsitegroup', 'LEFT' );
		$this->db->join ( 'sitetypes as st', 's.idsitetype = st.idsitetype', 'LEFT' );
		$this->db->join ( 'systemtypes as syt', 'lt.idsystemtype=syt.idsystemtype ', 'LEFT' );
		$this->db->join ( 'zones AS z', ' s.idzone = z.idzone ', "LEFT" );
		$this->db->join ( 'sitestatuses as ss', 'lt.idsitestatus=ss.idsitestatus', 'LEFT' );
		$this->db->join ( 'weatherconditions ws', 'lt.idweatherconditions = ws.idweathercondition', 'LEFT' );
		// $this->db->join('larvaecountrange as lcr', 'lt.idlarvaelcountrange=lcr.idlarvaecountrange ', 'LEFT');
		$this->db->join ( 'instar as ins', 'lt.idinstar = ins.idinstar', 'LEFT' );
		$this->db->join ( 'mosquitospecies as ms', 'lt.idmosquitospecies=ms.idmosquitospecies', 'LEFT' );
		$this->db->join ( 'genuses AS gn', 'ms.idgenus = gn.idgenus ', "LEFT" );
		
		$this->db->join ( 'windspeeds AS wsp', 'lt.idwindspeed = wsp.idwindspeed ', "LEFT" );
		$this->db->join ( 'winddirections AS wdd', 'lt.idwinddirection = wdd.idwinddirection ', "LEFT" );
		
		$this->db->join ( 'users AS usr', 'lt.idapplicator = usr.iduser', "LEFT" );
		$this->db->join ( 'applicationmethods ams ', 'lt.idapplicationmethod = ams.idapplicationmethods', 'LEFT' );
		$this->db->join ( 'products as p', 'lt.idproduct=p.idproduct', 'LEFT' );
		$this->db->join ( 'formulations as f', 'p.idformulation = f.idformulation', 'LEFT' );
		$this->db->join ( 'applicationrateuom as aru', ' lt.idapplicationrateuom=aru.idapplicationrateuom', 'LEFT' );
		$this->db->join ( 'area_treated as areauom', ' lt.iduomtotalareatreated=areauom.idareatreated', 'LEFT' );
		$this->db->join ( 'productunit as pu', ' lt.iduomtotalproductapplied=pu.idproductunit', 'LEFT' );
		$this->db->join ( 'applicationratetypes as art', 'lt.idapplicationratetype= art.idapplicationratetypes', 'LEFT' );
		$this->db->join ( 'treatmentmethods as tms', ' lt.idlarvaltreatment=tms.idtreatmentmethod', 'LEFT' );
		$this->db->join ( 'states AS stt', ' s.idstate= stt.idstate ', "LEFT" );
		$this->db->join ( 'systemtypes as syst', 'lt.idsystemtype= syst.idsystemtype', 'LEFT' );
		$this->db->join ( 'finishedmix as fmx', 'lt.iduomfinishedmix= fmx.idfinishedmix', 'LEFT' );
		$this->db->join ( 'mixratios as mxr', 'lt.idmixratio= mxr.idmixratio', 'LEFT' );
		$this->db->join ( 'productsizes AS ps', 'p.idproductsize= ps.idproductsize', 'LEFT' );
		$this->db->join ( 'packsizes AS pcksz', 'p.idpacksize = pcksz.idpacksize', 'LEFT' );
		$this->db->join ( 'productmanufacturers as pm', 'p.idmanufacturer=pm.idmanufacturer', 'LEFT' );
		$this->db->join ( 'productpotency as pp', 'p.idpotency=pp.idpotency', 'LEFT' );
		$this->db->order_by ( 'lt.date', 'DESC' );
		$this->db->order_by ( 'lt.time', 'DESC' );
		$this->db->where ( "s.idlocation", $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'lt.isdeleted', '0' );
		$this->db->where ( 'lt.idsite <> 0' );
		
		if (! empty ( $startdate ) && ! empty ( $enddate )) {
			$this->db->where ( 'lt.date >=', $startdate );
			$this->db->where ( 'lt.date <=', $enddate );
		}
		
		if (! empty ( $site )) {
			$s_site = "";
			
			if ($site [0] != "on" && $site [0] != "") {
				foreach ( $site as $k_s => $v_s ) {
					$s_site .= "'" . $v_s . "',";
				}
				
				$s_site = trim ( $s_site, "," );
				$cond = " s.idsite IN (" . $s_site . ")";
				$this->db->where ( $cond );
			}
		}
		
		if (! empty ( $zone )) {
			$s_zone = "";
			
			if ($zone [0] != "on" && $zone [0] != "") {
				foreach ( $zone as $k_z => $v_z ) {
					$s_zone .= "'" . $v_z . "',";
				}
				
				$s_zone = trim ( $s_zone, "," );
				$cond = " z.idzone IN (" . $s_zone . ")";
				$this->db->where ( $cond );
			}
		}
		
		$query = $this->db->get ();
		 //echo $this->db->last_query();
		
		$adult = array ();
		$mos = array ();
		$j = 0;
		$i = 0;
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->db->select ( 'm.mosquitospecies,
						g.genus,
						ltd.count' );
				$this->db->from ( 'mosquitospecies AS m' );
				$this->db->join ( 'larvatreatmentdetails AS ltd', 'm.idmosquitospecies = ltd.idmosquitospecies', 'LEFT' );
				$this->db->join ( 'genuses AS g', 'm.idgenus = g.idgenus', 'INNER' );
				$this->db->where ( 'ltd.idlarvaltreatment', $row ['idlarvaltreatment'] );
				
				$q = $this->db->get ();
				$k = 0;
				
				if ($q->num_rows () > 0) {
					foreach ( $q->result_array () as $k => $v ) {
						$mos [$j] = $row;
						$mos [$j] ['species'] = $v ['genus'];
						$mos [$j] ['subspecies'] = $v ['mosquitospecies'];
						$mos [$j] ['collectedcount'] = $v ['count'];
						$k ++;
					}
				} else {
					$mos [$j] = $row;
					$mos [$j] ['species'] = "";
					$mos [$j] ['subspecies'] = "";
					$mos [$j] ['collectedcount'] = 0;
				}
				$mos [$j] ['reporttype'] = 'larval';
				$middlename = ! empty ( $row ['middlename'] ) ? " " . $row ['middlename'] . " " : " ";
				// $adult[$j] = $row;
				// $adult[$j]['inspector'] = $row['firstname'].$middlename.$row['lastname'];
				// $adult[$j]['inspectorphn'] = $row['officephone'];
				
				if (! empty ( $row ['ptidate'] ) && ! empty ( $row ['trtmnt_type'] ) && $row ['trtmnt_type'] == 'larval' && $row ['ptilocation'] == $this->session->userdata ['idlocation']) {
					// echo
					$date = date ( 'm/d/Y', strtotime ( $row ['ptidate'] ) );
					$mos [$j] ['ptidate'] = $date . " " . $row ['ptitime'];
					$mos [$j] ['pti'] = 'Yes';
				} else {
					$mos [$j] ['ptidate'] = '';
					$mos [$j] ['pti'] = 'No';
				}
				$adult [] = $mos;
				
				$j ++;
			}
		}
		$this->data = $mos;
		// print'<pre>';
		// print_r($this->data);
		// die;
		return $this->data;
		// return $query->result_array();
	}
	
	/**
	 * Function to fetch Service Request Data to display
	 * Reporting Module
	 */
	public function getServiceRequestData($startdate = '', $enddate = '', $site = '', $zone = '', $status = '', $action = '') {
		$data_1 = array ();
		
		$j = 0;
		// print'<pre>';
		// print_r($action);
		// die;
		$mos = array ();
		$flag = 0;
		if (! empty ( $action ) && ! is_array ( $action )) {
			$action = trim ( $action, "," );
			$action = explode ( ",", $action );
		} else
			$action = $data_1;
		
		$this->db->select ( 'ss.*,
				z.zone,
				s.*,
				stt.statename,
				CONCAT(u.firstname," ",u.middlename," ",u.lastname) AS requested_by , 
				CONCAT(ss.firstname," ",ss.lastname) AS inspector, 
				ss.firstname, 
				ss.lastname, 
				CONCAT(usr.firstname," ",usr.middlename," ",usr.lastname) AS applicator', FALSE );
		$this->db->from ( 'servicerequests AS ss' );
		$this->db->join ( 'sites AS s ', 'ss.idsite = s.idsite ', "LEFT" );
		$this->db->join ( 'zones AS z', ' s.idzone= z.idzone ', "LEFT" );
		$this->db->join ( 'states AS stt', ' s.idstate= stt.idstate ', "LEFT" );
		$this->db->join ( 'users AS u', "ss.idrequestedby = u.iduser", 'LEFT' );
		$this->db->join ( 'userlocationassignment AS ula', "u.iduser = ula.iduser", 'LEFT' );
		$this->db->join ( 'users AS usr', "ss.idapplicator = usr.iduser", 'LEFT' );
		$this->db->join ( 'userlocationassignment AS ula2', "usr.iduser = ula2.iduser", 'LEFT' );
		$this->db->order_by ( 'ss.opendate', 'DESC' );
		$this->db->order_by ( 'ss.opentime', 'DESC' );
		$this->db->where ( 'ss.isdeleted', '0' );
		$this->db->where ( 'ss.idsite <> 0' );
		// print'<pre>';
		// print_r($site);
		// print_r($zone);
		
		if (! empty ( $site )) {
			$s_site = "";
			
			if ($site [0] != "on" && $site [0] != "") {
				foreach ( $site as $k_s => $v_s ) {
					$s_site .= "'" . $v_s . "',";
				}
				$s_site = trim ( $s_site, "," );
				$cond = " s.idsite IN (" . $s_site . ")";
				$this->db->where ( $cond );
			}
		}
		
		if (! empty ( $zone )) {
			$s_zone = "";
			
			if ($zone [0] != "on" && $zone [0] != "") {
				foreach ( $zone as $k_z => $v_z ) {
					$s_zone .= "'" . $v_z . "',";
				}
				
				$s_zone = trim ( $s_zone, "," );
				$cond = " z.idzone IN (" . $s_zone . ")";
				$this->db->where ( $cond );
			}
		}
		
		if (! empty ( $status ) && $status == "open") {
			$this->db->where ( 'opendate >=', $startdate );
			$this->db->where ( 'opendate <=', $enddate );
			$where = "(ss.closedate = '' OR ss.closedate = '0000-00-00')";
			$this->db->where ( $where );
		} else if (! empty ( $status ) && $status == "close") {
			$this->db->where ( 'opendate >=', $startdate );
			$this->db->where ( 'opendate <=', $enddate );
			$where = "(ss.closedate != '' AND ss.closedate != '0000-00-00')";
			$this->db->where ( $where );
		} else {
			$this->db->where ( 'opendate >=', $startdate );
			$this->db->where ( 'opendate <=', $enddate );
		}
		
		$this->db->where ( "s.idlocation", $this->session->userdata ( 'idlocation' ) );
		$act = "";
		$query = $this->db->get ();
		
		// echo $this->db->last_query()."<br>";
		// print'</pre>';
		// die;
		$idlocation = $this->session->userdata ( 'idlocation' );
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $r ) {
				$trt = 0;
				$sur = 0;
				$ins = 0;
				$tempdisp = array ();
				$act = '';
				
				// if($r['idlocation'] != $idlocation || $r['closedate'] > $enddate || $r['opendate'] > $enddate)
				// continue;
				
				if (in_array ( 'treatment', $action )) {
					$this->db->select ( '*' );
					$this->db->from ( 'adulticidetreatmentsservice adts' );
					$this->db->join ( 'adulticidetreatments AS adt', "adts.idadulticidetreatment = adt.idadulticidetreatment", 'INNER' );
					$this->db->where ( 'adts.idservicerequest', $r ['idservicerequest'] );
					$this->db->where ( 'adt.idlocation', $this->session->userdata ( 'idlocation' ) );
					$this->db->where ( 'adt.date >=', $startdate );
					$this->db->where ( 'adt.date <=', $enddate );
					$q = $this->db->get ();
					
					if ($q->num_rows () > 0)
						$trt = 1;
					
					$this->db->select ( '*' );
					$this->db->from ( 'larvaltreatmentservice lts' );
					$this->db->join ( 'larvaltreatments AS lt', "lts.idlarvaltreatment = lt.idlarvaltreatment", 'INNER' );
					$this->db->where ( 'lts.idservicerequest', $r ['idservicerequest'] );
					$this->db->where ( 'lt.idlocation', $this->session->userdata ( 'idlocation' ) );
					$this->db->where ( 'lt.date >=', $startdate );
					$this->db->where ( 'lt.date <=', $enddate );
					$q = $this->db->get ();
					
					if ($q->num_rows () > 0)
						$trt = 1;
				}
				
				if (in_array ( 'surveillance', $action )) {
					$this->db->select ( '*' );
					$this->db->from ( 'adultsurveillanceservice adss' );
					$this->db->join ( 'adultsurveillance AS ad', "adss.idadultsurveillance = ad.idadultsurveillance", 'LEFT' );
					$this->db->where ( 'adss.idservicerequest', $r ['idservicerequest'] );
					$this->db->where ( 'ad.idlocation', $this->session->userdata ( 'idlocation' ) );
					$this->db->where ( 'ad.pudate >=', $startdate );
					$this->db->where ( 'ad.pudate <=', $enddate );
					$q = $this->db->get ();
					
					if ($q->num_rows () > 0)
						$sur = 1;
				}
				
				if (in_array ( 'inspection', $action )) {
					$this->db->select ( '*' );
					$this->db->from ( 'larvalsurveillanceservice lss' );
					$this->db->join ( 'larvalsurveillance AS ls', "lss.idlarvalsurveillance = ls.idlarvalsurveillance", 'LEFT' );
					$this->db->where ( 'lss.idservicerequest', $r ['idservicerequest'] );
					$this->db->where ( 'ls.idlocation', $this->session->userdata ( 'idlocation' ) );
					$this->db->where ( 'ls.date >=', $startdate );
					$this->db->where ( 'ls.date <=', $enddate );
					$q = $this->db->get ();
					
					if ($q->num_rows () > 0)
						$ins = 1;
				}
				
				$this->db->select ( 'd.disposition' );
				$this->db->from ( 'dispositions AS d' );
				$this->db->join ( 'servicerequestsdetail AS srd', 'd.iddispositions = srd.iddispositions', 'LEFT' );
				$this->db->join ( 'servicerequests AS sr', 'srd.idservicerequest = sr.idservicerequest', 'LEFT' );
				$this->db->where ( 'sr.idservicerequest', $r ['idservicerequest'] );
				
				$query1 = $this->db->get ();
				// echo $this->db->last_query();
				if ($query1->num_rows ()) {
					foreach ( $query1->result_array () as $r1 ) {
						if (! in_array ( $r1 ['disposition'], $tempdisp )) {
							$act .= $r1 ['disposition'] . ";";
							$tempdisp [] = $r1 ['disposition'];
						}
					}
				}
				// print'<pre>';
				// print_r($tempdisp);
				$act = ! empty ( $act ) ? trim ( $act, ';' ) : '';
				$mos [$j] = $r;
				$mos [$j] ['action'] = $act;
				
				if ($trt == 1)
					$mos [$j] ['treatment'] = "Yes";
				else
					$mos [$j] ['treatment'] = "No";
				
				if ($ins == 1)
					$mos [$j] ['inspection'] = "Yes";
				else
					$mos [$j] ['inspection'] = "No";
				
				if ($sur == 1)
					$mos [$j] ['surveillance'] = "Yes";
				else
					$mos [$j] ['surveillance'] = "No";
				
				$j ++;
			}
		}
		
		// echo $this->db->last_query();
		$this->data = $mos;
		// print'<pre>';
		// print_r($mos);
		// die;
		return $this->data;
		// return $query->result_array();
	}
	
	/**
	 * Function to fetch Weather Data to display
	 * Reporting Module
	 */
	public function getWeatherData($startdate = '', $enddate = '', $site = '', $zone = '') {
		$this->db->select ( 'w.*,
				ws.*,
				wc.weathercondition,
				wspd.windspeed,
				tr.temprange,
				hr.humidityrange,
				cc.cloudcoverage' );
		$this->db->from ( 'weather AS w' );
		$this->db->join ( 'weathersensors AS ws', ' w.idweathersensor = ws.idweathersensor ', "LEFT" );
		$this->db->join ( 'weatherconditions AS wc', ' w.idweatherconditions = wc.idweathercondition ', "LEFT" );
		$this->db->join ( 'windspeeds AS wspd', 'w.idwindspeed = wspd.idwindspeed', 'LEFT' );
		$this->db->join ( 'tempranges as tr', 'w.idtemprange = tr.idtemprange', 'LEFT' );
		$this->db->join ( 'humidityranges as hr', 'w.idhumidityrange = hr.idhumidityrange', 'LEFT' );
		$this->db->join ( 'cloudcoverage AS cc', 'w.idcloudcoverage = cc.idcloudcoverage', 'LEFT' );
		$this->db->join ( 'sites AS s', 'ws.idsite = s.idsite', 'INNER' );
		$this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'INNER' );
		$this->db->where ( 'w.isdeleted', '0' );
		$this->db->where ( "s.idlocation", $this->session->userdata ( 'idlocation' ) );
		$this->db->order_by ( 'w.date', 'DESC' );
		$this->db->where ( 'ws.idsite <> 0' );
		if (! empty ( $startdate ) && ! empty ( $enddate )) {
			$this->db->where ( 'w.date >=', $startdate );
			$this->db->where ( 'w.date <=', $enddate );
		}
		
		if (! empty ( $site )) {
			$s_site = "";
			
			if ($site [0] != "on" && $site [0] != "") {
				foreach ( $site as $k_s => $v_s ) {
					$s_site .= "'" . $v_s . "',";
				}
				
				$s_site = trim ( $s_site, "," );
				$cond = " s.idsite IN (" . $s_site . ")";
				$this->db->where ( $cond );
			}
		}
		
		if (! empty ( $zone )) {
			$s_zone = "";
			
			if ($zone [0] != "on" && $zone [0] != "") {
				foreach ( $zone as $k_z => $v_z ) {
					$s_zone .= "'" . $v_z . "',";
				}
				
				$s_zone = trim ( $s_zone, "," );
				$cond = " z.idzone IN (" . $s_zone . ")";
				$this->db->where ( $cond );
			}
		}
		
		$query = $this->db->get ();
		// echo $this->db->last_query();
		$mos = array ();
		$j = 0;
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$mos [$j] = $row;
				$j ++;
			}
		}
		$this->data = $mos;
		// print'<pre>';
		// print_r($this->data);
		// die;
		return $this->data;
		// return $query->result_array();
	}
	
	/**
	 * Function to fetch Existing Report
	 */
	public function getExistingReport() {
		$this->db->select ( 'idreportype,
				report_name' );
		$this->db->from ( 'reportypes' );
		$this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$query = $this->db->get ();
		$this->str = "";
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$selected = '';
				if (! strcmp ( $this->input->post ( 'existing_report' ), $row ['idreportype'] )) {
					$selected = 'selected';
				}
				$this->str .= '<option value="' . $row ['idreportype'] . '" ' . $selected . '>' . $row ['report_name'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Existing Report Data
	 */
	public function getExistingReportData() {
		$id = $this->input->get_post ( 'idreport' );
		
		if (empty ( $id ))
			return false;
		
		$this->db->select ( '*' );
		$this->db->from ( 'reportypes' );
		$this->db->where ( 'idreportype', $id );
		$this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
		$query = $this->db->get ();
		$result = array ();
		$all_fields = "";
		$columns = "";
		$this->str = "";
		if ($query->num_rows () > 0) {
			$result = $query->result_array ();
			$result = $result [0];
			$controllerInstance = & get_instance ();
			$columns = str_replace ( ",", "", urldecode(base64_decode ( $result ['report_fields'] )) );
			$result ['report_fields'] = $columns;
			$column_name = $result ['report_fields_names'];
			$startdate = $result ['startdate'];
			$enddate = $result ['enddate'];
			$allsite = json_decode ( $result ['allsites'] );
			$allzone = json_decode ( $result ['allzones'] );
			$status = $result ['report_subtype'];
			$action = $result ['action'];
			
			switch ($result ['reporttype']) {
				case 'larval' :
					$this->data = $this->getLarvalData ( $startdate, $enddate, $allsite, $allzone );
					$all_fields = $controllerInstance->getlarvalcolumn ( "c" );
					break;
				case 'adult' :
					$this->data = $this->getAdultData ( $startdate, $enddate, $allsite, $allzone );
					$all_fields = $controllerInstance->getadultcolumn ( "c" );
					break;
				case 'landing' :
					$this->data = $this->getLandingData ( $startdate, $enddate, $allsite, $allzone );
					$all_fields = $controllerInstance->getlandingcolumn ( "c" );
					break;
				case 'labs' :
					switch ($result ['report_subtype']) {
						case 'arboviral' :
							$this->data = $this->getArboviralData ( $startdate, $enddate, $allsite, $allzone );
							$all_fields = $controllerInstance->getarboviralcolumn ( "c" );
							break;
						case 'corvid' :
							$this->data = $this->getCorvidData ( $startdate, $enddate, $allsite, $allzone );
							$all_fields = $controllerInstance->getcorvidcolumn ( "c" );
							break;
						case 'sentinel' :
							$this->data = $this->getSentinelData ( $startdate, $enddate, $allsite, $allzone );
							$all_fields = $controllerInstance->getsentinelcolumn ( "c" );
							break;
					}
					break;
				case 'arboviral' :
					$this->data = $this->getArboviralData ( $startdate, $enddate, $allsite, $allzone );
					$all_fields = $controllerInstance->getarboviralcolumn ( "c" );
					break;
				case 'corvid' :
					$this->data = $this->getCorvidData ( $startdate, $enddate, $allsite, $allzone );
					$all_fields = $controllerInstance->getcorvidcolumn ( "c" );
					break;
				case 'sentinel' :
					$this->data = $this->getSentinelData ( $startdate, $enddate, $allsite, $allzone );
					$all_fields = $controllerInstance->getsentinelcolumn ( "c" );
					break;
				case 'service_request' :
					$this->data = $this->getServiceRequestData ( $startdate, $enddate, $allsite, $allzone, $status, $action );
					$all_fields = $controllerInstance->getservicecolumn ( "c" );
					break;
				case 'treatments' :
					switch ($result ['report_subtype']) {
						case 'adult_trtmnt' :
							$this->data = $this->getAdulttrtData ( $startdate, $enddate, $allsite, $allzone );
							$all_fields = $controllerInstance->gettrtadultcolumn ( "c" );
							break;
						case 'larval_trtmnt' :
							$this->data = $this->getLarvaltrtData ( $startdate, $enddate, $allsite, $allzone );
							$all_fields = $controllerInstance->gettrtlarvalcolumn ( "c" );
							break;
					}
					break;
				case 'adult_trtmnt' :
					$this->data = $this->getAdulttrtData ( $startdate, $enddate, $allsite, $allzone );
					$all_fields = $controllerInstance->gettrtadultcolumn ( "c" );
					break;
				case 'larval_trtmnt' :
					$this->data = $this->getLarvaltrtData ( $startdate, $enddate, $allsite, $allzone );
					$all_fields = $controllerInstance->gettrtlarvalcolumn ( "c" );
					break;
				case 'weather' :
					$this->data = $this->getWeatherData ( $startdate, $enddate, $allsite, $allzone );
					$all_fields = $controllerInstance->getweathercolumn ( "c" );
					break;
			}
		}
		
		$column_name = explode ( ",", $column_name );
		$columns_1 = json_decode ( $result ['report_keys'] );
        $all_fields = urldecode(base64_decode ( $result ['all_fields'] ));
		$all_fields = $all_fields ? $all_fields : $result ['all_fields'];
		
		$str = '<table style="width: 100%;border-spacing:0px;">
                    <tr>';
		
		if (! empty ( $column_name ) && isset ( $column_name ))
			foreach ( $column_name as $k => $v ) {
				$str .= '<td class="heading">
                        ' . $v . '
                        </td>';
			}
		
		$str .= '</tr>
                    <tr>
                        <td colspan="8">&nbsp;</td>
                    </tr>';
		if (! empty ( $this->data )) {
			foreach ( $this->data as $key => $val ) {
				$str .= '<tr>';
				
				foreach ( $columns_1 as $k => $v ) {
					switch ($v) {
						case 'habitat':
                            $str .=  "<td style='border:1px solid black;font-family: Arial; font-size: 10pt'>&nbsp;</td>";
                            break;
                        case 'requested_by_phn':
                            $str .=  "<td nowrap style='border:1px solid black;font-family: Arial; font-size: 10pt'>&nbsp;</td>";
                            break;
                        case 'trapresult':
                            $str .=  "<td nowrap style='border:1px solid black;font-family: Arial; font-size: 10pt'>&nbsp;</td>";
                            break;
                        case 'areaname':
                            $str .=  "<td nowrap style='border:1px solid black;font-family: Arial; font-size: 10pt'>&nbsp;</td>";
                            break;
                        case 'observeddate':
                            $temp = $v;
                            $temp = substr($v, 0, 8);
                            if (!empty($val[$v]) && $val[$v] != '0000-00-00' && $val[$v] != '1970-01-01' && $val[$v] != '0001-30-11')
                                $date = date('m/d/Y', strtotime($val[$v]));
        
                            if (!empty($val[$temp . "time"]) && !empty($date))
                                $time = date('h:i:s A', strtotime($val[$temp . "time"]));
                            $str .=  "<td nowrap style='border:1px solid black;padding: 3px;font-family: Arial; font-size: 10pt'>" . $date . " " . $time . "</td>";
                            break;
                        case 'date':
                            if (!empty($val["date"]) && $val["date"] != '0000-00-00' && $val["date"] != '1970-01-01' && $val["date"] != '0001-30-11')
                                $date = date('m/d/Y', strtotime($val["date"]));
                            if (!empty($val["time"]) && !empty($date))
                                $time = date('h:i:s A', strtotime($val["time"]));
                            $str .=  "<td nowrap style='border:1px solid black;padding: 3px;font-family: Arial; font-size: 10pt'>" . $date . " " . $time . "</td>";
                            break;        
                        case 'datebled':
                            if (!empty($val["datebled"]) && $val["datebled"] != '0000-00-00' && $val["datebled"] != '1970-01-01' && $val["datebled"] != '0001-30-11')
                                $date = date('m/d/Y', strtotime($val["datebled"]));
                            $str .=  "<td nowrap style='border:1px solid black;padding: 3px;font-family: Arial; font-size: 10pt'>" . $date . "</td>";
                            break;
                        case 'datesubmitted':
                            if (!empty($val["datesubmitted"]) && $val["datesubmitted"] != '0000-00-00' && $val["datesubmitted"] != '1970-01-01' && $val["datesubmitted"] != '0001-30-11')
                                $date = date('m/d/Y', strtotime($val["datesubmitted"]));
                            $str .=  "<td style='border:1px solid black;padding: 3px;font-family: Arial; font-size: 10pt'>" . $date . "</td>";
                            break;
                        case 'dateresults':
                            if (!empty($val["dateresults"]) && $val["dateresults"] != '0000-00-00' && $val["dateresults"] != '1970-01-01' && $val["dateresults"] != '0001-30-11')
                                $date = date('m/d/Y', strtotime($val["dateresults"]));
                            $str .=  "<td nowrap style='border:1px solid black;padding: 3px;font-family: Arial; font-size: 10pt'>" . $date . "</td>";
                            break;
                        case 'post_trtmnt_date':
                            if (!empty($val["post_trtmnt_date"]) && $val["post_trtmnt_date"] != '0000-00-00' && $val["post_trtmnt_date"] != '1970-01-01' && $val["post_trtmnt_date"] != '0001-30-11')
                                $date = date('m/d/Y', strtotime($val["post_trtmnt_date"]));
                            $str .=  "<td nowrap style='border:1px solid black;padding: 3px;font-family: Arial; font-size: 10pt'>" . $date . "</td>";
                            break;
                        case 'hightide_date':
                            if (!empty($val["hightide_date"]) && $val["hightide_date"] != '0000-00-00' && $val["hightide_date"] != '1970-01-01' && $val["hightide_date"] != '0001-30-11')
                                $date = date('m/d/Y', strtotime($val["hightide_date"]));
                            if (!empty($val["hightide_time"]) && !empty($date))
                                $time = date('h:i:s A', strtotime($val["hightide_time"]));
                            $str .=  "<td nowrap style='border:1px solid black;padding: 3px;font-family: Arial; font-size: 10pt'>" . $date . " " . $time . "</td>";
                            break;
                        case 'lowtide_date':
                            $time = "";
                            if (!empty($val["lowtide_date"]) && $val["lowtide_date"] != '0000-00-00' && $val["lowtide_date"] != '1970-01-01' && $val["lowtide_date"] != '0001-30-11')
                                $date = date('m/d/Y', strtotime($val["lowtide_date"]));
                            if (!empty($val["lowtide_time"]) && !empty($date))
                                $time = date('h:i:s A', strtotime($val["lowtide_time"]));
                            $str .=  "<td nowrap style='border:1px solid black;padding: 3px;font-family: Arial; font-size: 10pt'>" . $date . " " . $time . "</td>";
                            break;
                        case 'opendate':
                            if (!empty($val["opendate"]) && $val["opendate"] != '0000-00-00' && $val["opendate"] != '1970-01-01' && $val["opendate"] != '0001-30-11')
                                $date = date('m/d/Y', strtotime($val["opendate"]));
                            if (!empty($val["opentime"]) && !empty($date) && !is_null($val["opentime"]))
                                $time = date('h:i:s A', strtotime($val["opentime"]));
                            $str .=  "<td nowrap style='border:1px solid black;padding: 3px;font-family: Arial; font-size: 10pt'>" . $date . " " . $time . "</td>";
                            break;
                        case 'closedate':
                            $time = "";
                            $date = "";
                            if (!empty($val["closedate"]) && $val["closedate"] != '0000-00-00' && $val["closedate"] != '1970-01-01' && $val["closedate"] != '0001-30-11')
                                $date = date('m/d/Y', strtotime($val["closedate"]));
                            if (!empty($val["closetime"]) && !empty($date) && !is_null($val["closetime"]))
                                $time = date('h:i:s A', strtotime($val["closetime"]));
                            $str .=  "<td nowrap style='border:1px solid black;padding: 3px;font-family: Arial; font-size: 10pt'>" . $date . " " . $time . "</td>";
                            break;
                        case 'applicationstartdate':
                            $time = "";
                            if (!empty($val["applicationstartdate"]) && $val["applicationstartdate"] != '0000-00-00' && $val["applicationstartdate"] != '1970-01-01' && $val["closedate"] != '0001-30-11')
                                $date = date('m/d/Y', strtotime($val["applicationstartdate"]));
                            if (!empty($val["applicationstarttime"]) && !empty($date))
                                $time = date('h:i:s A', strtotime($val["applicationstarttime"]));
                            $str .=  "<td nowrap style='border:1px solid black;padding: 3px;font-family: Arial; font-size: 10pt'>" . $date . " " . $time . "</td>";
                            break;
                        case 'applicationenddate':
                            $time = "";
                            if (!empty($val["applicationenddate"]) && $val["applicationenddate"] != '0000-00-00' && $val["applicationenddate"] != '1970-01-01' && $val["closedate"] != '0001-30-11')
                                $date = date('m/d/Y', strtotime($val["applicationenddate"]));
                            if (!empty($val["applicationendtime"]) && !empty($date))
                                $time = date('h:i:s A', strtotime($val["applicationendtime"]));
                            $str .=  "<td nowrap style='border:1px solid black;padding: 3px;font-family: Arial; font-size: 10pt'>" . $date . " " . $time . "</td>";
                            break;
                        case 'durationsmin':
                            $temp = "";
                            $temp = intval(!empty($val["durations"]) ? $val["durations"] : '');
                            $str .=  "<td style='border:1px solid black;font-family: Arial; font-size: 10pt'>" . $temp . "</td>";
                            break;
                        case 'adult':
                            if ($val['reporttype'] == 'adult')
                                $str .=  "<td style='border:1px solid black;font-family: Arial; font-size: 10pt'>" .  $this->lang->line('cmn_lbl_yes') . "</td>";
                            else
                                $str .=  "<td style='border:1px solid black;font-family: Arial; font-size: 10pt'>" .  $this->lang->line('cmn_lbl_no') . "</td>";
                            break;
                        case 'larval':
                            if ($val['reporttype'] == 'larval')
                                $str .=  "<td style='border:1px solid black;font-family: Arial; font-size: 10pt'>" .  $this->lang->line('cmn_lbl_yes') . "</td>";
                            else
                                $str .=  "<td style='border:1px solid black;font-family: Arial; font-size: 10pt'>" .  $this->lang->line('cmn_lbl_no') . "</td>";
                            break;
                        case 'aerial':
                            if ($val['reporttype'] == 'aerial')
                                $str .=  "<td style='border:1px solid black;font-family: Arial; font-size: 10pt'>" .  $this->lang->line('cmn_lbl_yes') . "</td>";
                            else
                                $str .=  "<td style='border:1px solid black;font-family: Arial; font-size: 10pt'>" .  $this->lang->line('cmn_lbl_no') . "</td>";
                            break;
                        case 'followup':
                            $str .=  "<td style='border:1px solid black;font-family: Arial; font-size: 10pt'>&nbsp;</td>";
                            break;
                        case 'sample':
                            $str .=  "<td style='border:1px solid black;font-family: Arial; font-size: 10pt'>&nbsp;</td>";
                            break;
                        case 'larvaepresent':
                            if (!empty($val['totalcount']) && floatval($val['totalcount']) != 0.00000)
                                $str .=  "<td style='border:1px solid black;font-family: Arial; font-size: 10pt'>" .  $this->lang->line('cmn_lbl_yes') . "</td>";
                            else
                                $str .=  "<td style='border:1px solid black;font-family: Arial; font-size: 10pt'>" .  $this->lang->line('cmn_lbl_no') . "</td>";
                            break;
                        case 'rtprcconfirm':
                            if (!empty($val[$v]) && ($val[$v] == 1 || $val[$v] == '1'))
                                $str .=  "<td style='border:1px solid black;font-family: Arial; font-size: 10pt'>" .  $this->lang->line('cmn_lbl_yes') . "</td>";
                            else
                                $str .=  "<td style='border:1px solid black;font-family: Arial; font-size: 10pt'>" .  $this->lang->line('cmn_lbl_no') . "</td>";
                            break;
                        case 'resultscorresspond':
                            if (!empty($val[$v]) && ($val[$v] == 1 || $val[$v] == '1'))
                                $str .=  "<td style='border:1px solid black;font-family: Arial; font-size: 10pt'>" .  $this->lang->line('cmn_lbl_yes') . "</td>";
                            else
                                $str .=  "<td style='border:1px solid black;font-family: Arial; font-size: 10pt'>" .  $this->lang->line('cmn_lbl_no') . "</td>";
                            break;
                        case 'sourcereduction':
                            if(!empty($val[$v]) && ($val[$v] == 1 || $val[$v] == '1'))
                                $str .=  "<td style='border:1px solid black;font-family: Arial; font-size: 10pt'>" .  $this->lang->line('cmn_lbl_yes') . "</td>";
                            else
                                $str .=  "<td style='border:1px solid black;font-family: Arial; font-size: 10pt'>" .  $this->lang->line('cmn_lbl_no') . "</td>";
                            break;
                        case 'sourcereductioncomments':
                            if(!empty($val['sourcereduction']) && ($val['sourcereduction'] == 1 || $val['sourcereduction'] == '1'))
                                $str .=  "<td style='border:1px solid black;font-family: Arial; font-size: 10pt'>".$val['sourcereductioncomments']."</td>";
                            else
                                $str .=  "<td style='border:1px solid black;font-family: Arial; font-size: 10pt'> </td>";
                            break;
                        case 'notes':
                            $temp = '';
                            if (!empty($val['comments'])) {
                                $temp = explode("$", $val['comments']);
                                $str = '';
                                foreach ($temp as $k_n => $v_n) {
                                    if ($k_n == '0' && !empty($v_n))
                                        $str = $v_n . ";";
        
                                    if ($k_n != '0' && !empty($v_n))
                                        $str .= $v_n . ";";
                                }
                                $temp = $str;
                            }
        
                            $str .=  "<td nowrap style='border:1px solid black;padding: 3px;font-family: Arial; font-size: 10pt'>" . $temp . "</td>";
                            break;
                        case 'comments':
                            $temp = !empty($val['comments']) ? implode(";", explode("$", $val['comments'])) : '&nbsp;';
                            $str .=  "<td nowrap style='border:1px solid black;padding: 3px;font-family: Arial; font-size: 10pt'>" . $temp . "</td>";
                            break;
                        case 'wasource':
                            $wasource= '';
                            if(!empty($val['wasource'])){
                                switch($val['wasource']){
                                    case 'A':
                                        $wasource = ucwords( $this->lang->line('wrk_asgnmnts_app'));
                                        break;
                                    case 'W':
                                        $wasource = ucwords( $this->lang->line('wrk_asgnmnts_web'));
                                        break;
                                    case 'E':
                                        $wasource = ucwords( $this->lang->line('wrk_asgnmnts_email'));
                                        break;
                                    case 'P':
                                        $wasource = ucwords( $this->lang->line('wrk_asgnmnts_phone'));
                                        break;
                                    default:
                                        $wasource = ucwords( $this->lang->line('drpdwn_other'));
                                        break;
                                }
                            }
                            $str .=  "<td nowrap style='border:1px solid black;padding: 3px;font-family: Arial; font-size: 10pt'>" . $wasource . "</td>";
                            break;
                        case 'winddirection':
                            if(empty($val['windspeed'])){
                                $val['winddirection'] = '';
                            }
                            $str .=  "<td nowrap style='border:1px solid black;padding: 3px;font-family: Arial; font-size: 10pt'>" . $val['winddirection'] . "</td>";
                            break;
                        case 'species':
                            $str .=  "<td nowrap style='border:1px solid black;padding: 3px;font-family: Arial; font-size: 10pt'>" . (isset($val['species']) ? $this->lang->line('spcs_' . removeSpecialChars($val['species'])) : "") . "</td>";
                            break;
                        default:
                            $temp = '&nbsp;';
                            if(!empty($val[$v]))
                            {
                                $translatedVal =  $this->lang->line( 'drpdwn_' . removeSpecialChars($val[$v]) );
                                preg_match('/[0-9]*\.[0-9]+/', $val[$v], $matches);
                                if(!empty($matches[0]) && $v != "latitude" && $v != "longitude")
                                    $temp = number_format((float)$val[$v], '2', '.', '');    
                                else if(!empty($translatedVal))
                                    $temp = $translatedVal;
                                else
                                    $temp = $val[$v];
                            }
                            
                            $str .=  "<td nowrap style='border:1px solid black;padding: 3px;font-family: Arial; font-size: 10pt'>" . $temp . "</td>";
                            break;
					}
				}
				
				$str .= '</tr>';
			}
		}
		
		$str .= '</table>';
		
		$result ['all_fields'] = $all_fields;
		$result ['result'] = base64_encode ( rawurlencode($str) );
		
		return $result;
	}

	/**
	 * Function to fetch Maintainance Inspection Data to display
	 * Reporting Module
	 */
	 public function getMaintenanceinspectionData($startdate = '', $enddate = '', $site = '', $zone = '') {
		log_message('debug','Skysoft Debugging -------------->>>>> In getting maintainance inspection');
		$this->db->select ( 'maintenanceinspection.*,
				s.site AS site,
				s.idzone, 
				zones.`zone` ' );
		$this->db->from ( 'maintenanceinspection' );
		$this->db->join ( 'sites AS s', 'maintenanceinspection.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'zones', 's.idzone = zones.idzone', 'LEFT' );
		$this->db->join ( 'locations AS l', 'maintenanceinspection.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( 'maintenanceinspection.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'maintenanceinspection.isdeleted', '0' );
		if (! empty ( $startdate ) && ! empty ( $enddate )) {
			$this->db->where ( 'maintenanceinspection.observeddatetime >=', $startdate );
			$this->db->where ( 'maintenanceinspection.observeddatetime <=', $enddate );
		}
		if (! empty ( $site )) {
			$s_site = "";
			
			if ($site [0] != "on" && $site [0] != "") {
				foreach ( $site as $k_s => $v_s ) {
					$s_site .= "'" . $v_s . "',";
				}
				
				$s_site = trim ( $s_site, "," );
				$cond = " s.idsite IN (" . $s_site . ")";
				$this->db->where ( $cond );
			}
		}
		
		if (! empty ( $zone )) {
			$s_zone = "";
			
			if ($zone [0] != "on" || $zone [0] != "") {
				foreach ( $zone as $k_z => $v_z ) {
					$s_zone .= "'" . $v_z . "',";
				}
				
				$s_zone = trim ( $s_zone, "," );
				$cond = " zones.idzone IN (" . $s_zone . ")";
				$this->db->where ( $cond );
			}
		}
		
		$query = $this->db->get ();
		// echo $this->db->last_query();
		
		$mos = array ();
		$j = 0;
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$mos [$j] = $row;
				$j ++;
			}
		}
		$this->data = $mos;
		
		// print'<pre>';
		// print_r($this->data);
		// die;
		log_message('debug','Skysoft Debugging -------------->>>>> $this->data'.print_r($this->data,1));
		return $this->data;
		// return $query->result_array();
	}

	/**
	 * Function to fetch Outfall Inspection Data to display
	 * Reporting Module
	 */
	 public function getOutfallinspectionData($startdate = '', $enddate = '', $site = '', $zone = '') {
		log_message('debug','Skysoft Debugging -------------->>>>> In getting maintainance inspection');
		$this->db->select ( 'outfallinspection.*,
				s.site AS site,
				s.idzone, 
				zones.`zone` ' );
		$this->db->from ( 'outfallinspection' );
		$this->db->join ( 'sites AS s', 'outfallinspection.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'zones', 's.idzone = zones.idzone', 'LEFT' );
		$this->db->join ( 'locations AS l', 'outfallinspection.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( 'outfallinspection.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'outfallinspection.isdeleted', '0' );
		if (! empty ( $startdate ) && ! empty ( $enddate )) {
			$this->db->where ( 'outfallinspection.observeddatetime >=', $startdate );
			$this->db->where ( 'outfallinspection.observeddatetime <=', $enddate );
		}
		if (! empty ( $site )) {
			$s_site = "";
			
			if ($site [0] != "on" && $site [0] != "") {
				foreach ( $site as $k_s => $v_s ) {
					$s_site .= "'" . $v_s . "',";
				}
				
				$s_site = trim ( $s_site, "," );
				$cond = " s.idsite IN (" . $s_site . ")";
				$this->db->where ( $cond );
			}
		}
		
		if (! empty ( $zone )) {
			$s_zone = "";
			
			if ($zone [0] != "on" || $zone [0] != "") {
				foreach ( $zone as $k_z => $v_z ) {
					$s_zone .= "'" . $v_z . "',";
				}
				
				$s_zone = trim ( $s_zone, "," );
				$cond = " zones.idzone IN (" . $s_zone . ")";
				$this->db->where ( $cond );
			}
		}
		
		$query = $this->db->get ();
		// echo $this->db->last_query();
		
		$mos = array ();
		$j = 0;
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$mos [$j] = $row;
				$j ++;
			}
		}
		$this->data = $mos;
		
		// print'<pre>';
		// print_r($this->data);
		// die;
		
		return $this->data;
		// return $query->result_array();
	}
}
