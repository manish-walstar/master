<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Product_model extends CI_Model {
	
	/**
	 * Constructor for the class
	 * User
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to save Product Inventory
	 */
	public function saveAdjustInventory($userdet = '') {
		$idproduct = $this->input->post ( 'idproduct' );
		$min_amount = $this->input->post ( 'min_amount' );
		$max_amount = $this->input->post ( 'max_amount' );
		$action = $this->input->post ( 'idtype' );
		$adjustamount = $this->input->post ( 'adjustamount' );
		$qty = $this->input->post ( 'qty' );
		$id = "";
		
		$data ['idproduct'] = ! empty ( $idproduct ) ? $idproduct : '0';
		$data ['min_amount'] = ! empty ( $min_amount ) ? $min_amount : '0';
		$data ['max_amount'] = ! empty ( $max_amount ) ? $max_amount : '0';
		$notes = $this->input->post ( 'notes' );
		
		$this->db->select ( 'pi.*,
				p.*' );
		$this->db->from ( 'product_inventory AS pi' );
		$this->db->join ( 'products AS p', 'pi.idproduct = p.idproduct', 'INNER' );
		$this->db->where ( 'p.idproduct', $idproduct );
		
		$q = $this->db->get ();
		
		// print'<pre>';
		// print_r($q->result_array());
		// die;
		
		if ($q->num_rows () > 0) {
			$prdctdata = $q->result_array ();
			$prdctdata = $prdctdata [0];
			$notes = ! empty ( $notes ) ? $notes . "$" . $prdctdata ['notes'] : $prdctdata ['notes'];
			
			$data ['notes'] = $notes;
			
			$this->db->where ( 'idproduct', $idproduct );
			$this->db->update ( 'product_inventory', $data );
			
			$id = $idproduct;
		} else {
			$this->db->insert ( 'product_inventory', $data );
			$id = $this->db->insert_id ();
		}
		
		if (! empty ( $idproduct )) {
			$data = array ();
			
			$data ['idproduct'] = $idproduct;
			$data ['qty'] = $qty;
			$data ['date'] = date ( 'Y-m-d' );
			$data ['time'] = $this->input->post ( 'time' );
			
			$middlename = ! empty ( $userdet ['middlename'] ) ? " " . $userdet ['middlename'] . " " : " ";
			$data ['user_name'] = $userdet ['firstname'] . $middlename . $userdet ['lastname'];
			
			$this->db->insert ( 'product_history', $data );
			
			$data = array ();
			$data = $this->viewProduct ( $idproduct );
			// print'<pre>';
			// print_r($data);
			// die;
			if ($action == "in")
				$data ['onhand'] += $adjustamount;
			else if ($action == "de")
				$data ['onhand'] -= $adjustamount;
			
			if ($data ['onhand'] < '0')
				$data ['onhand'] = '0';
			$this->db->where ( 'idproduct', $idproduct );
			$this->db->update ( 'products', $data );
			
			if (! empty ( $idproduct ))
				return true;
		}
		
		return false;
	}
	
	/**
	 * Function to fetch the Per Cost Options
	 */
	public function getProductCost($id = '') {
		$this->db->select ( 'productunit.*' );
		$this->db->from ( 'productunit' );
		
		$query = $this->db->get ();
		$this->str = "";
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if (isset ( $id ) && $row ['idproductunit'] == $id) {
					$this->str .= '<option value="' . $row ['idproductunit'] . '" selected="true">' . $row ['unitproduct'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idproductunit'] . '">' . $row ['unitproduct'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to history of ProductInventory
	 */
	public function getProductHistory($id = '') {
		if (empty ( $id ))
			return false;
		
		$this->db->select ( '*' );
		$this->db->from ( 'product_history' );
		$this->db->where ( 'idproduct', $id );
		$this->db->order_by ( 'idprdct_histry', 'desc' );
		$getData = $this->db->get ();
		$data = array ();
		if ($getData->num_rows () > 0) {
			return $getData->result_array ();
		} else
			return null;
	}
	
	/**
	 * Function to list all products
	 */
	public function ToExcelAll() {
		$this->db->select ( '*' );
		$this->db->from ( 'products' );
		$this->db->where ( 'products.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->order_by ( 'idproduct', 'asc' );
		$getData = $this->db->get ();
		
		if ($getData->num_rows () > 0)
			return $getData->result_array ();
		else
			return null;
	}
	
	/**
	 * Function to list all products
	 */
	public function listProducts() {
		$this->db->select ( 'pr.idproduct, 
				pr.productname, 
				pp.potency , 
				pm.manufacturer , 
				ps.productsize , 
				pk.packsize , 
				pr.onhand' );
		$this->db->from ( 'products AS pr' );
		$this->db->join ( 'productpotency AS pp', 'pr.idpotency = pp.idpotency', 'LEFT' );
		$this->db->join ( 'productmanufacturers AS pm', 'pr.idmanufacturer = pm.idmanufacturer', 'LEFT' );
		$this->db->join ( 'productsizes AS ps', 'pr.idproductsize = ps.idproductsize', 'LEFT' );
		$this->db->join ( 'packsizes AS pk', 'pr.idpacksize = pk.idpacksize', 'LEFT' );
		$this->db->join ( 'locations AS lc', "pr.idlocation = lc.idlocation", 'LEFT' );
		$this->db->where ( 'pr.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		/*
		 * $ttl = $this->input->get('ttl');
		 * $page = $this->input->get('page');
		 *
		 * if(!isset($ttl) || $ttl == '')
		 * $ttl = 10;
		 *
		 * if(!isset($page) || $page == '')
		 * $page = 1;
		 *
		 * if(!is_null($ttl) && !is_null($page))
		 * {
		 * if($page == 1)
		 * $page = 0;
		 * else
		 * $page--;
		 *
		 * $page *= 10;
		 * $this->db->limit($ttl ,$page);
		 * }
		 * else if(!is_null($ttl))
		 * {
		 * $this->db->limit($ttl);
		 * }
		 */
		$orderby = $this->input->get ( 'orderby' );
		if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
			switch ($orderby) {
				case '0:asc' :
					$this->db->order_by ( 'pr.productname', 'ASC' );
					break;
				case '0:desc' :
					$this->db->order_by ( 'pr.productname', 'DESC' );
					break;
				case '1:asc' :
					$this->db->order_by ( 'pp.potency', 'ASC' );
					break;
				case '1:desc' :
					$this->db->order_by ( 'pp.potency', 'DESC' );
					break;
				case '2:asc' :
					$this->db->order_by ( 'pm.manufacturer', 'ASC' );
					break;
				case '2:desc' :
					$this->db->order_by ( 'pm.manufacturer', 'DESC' );
					break;
				case '3:asc' :
					$this->db->order_by ( 'ps.productsize', 'ASC' );
					break;
				case '3:desc' :
					$this->db->order_by ( 'ps.productsize', 'DESC' );
					break;
				case '4:asc' :
					$this->db->order_by ( 'pk.packsize', 'ASC' );
					break;
				case '4:desc' :
					$this->db->order_by ( 'pk.packsize', 'DESC' );
					break;
				case '5:asc' :
					$this->db->order_by ( 'pr.onhand', 'ASC' );
					break;
				case '5:desc' :
					$this->db->order_by ( 'pr.onhand', 'DESC' );
					break;
			}
		} else {
			$this->db->where ( 'pr.onhand > 0' );
			$this->db->order_by ( 'pr.productname', 'ASC' );
			$this->db->order_by ( 'pr.onhand', 'DESC' );
		}
		
		$query = $this->db->get ();
		// echo $this->db->last_query()."<br>";
		// die;
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
		
		return null;
	}
	
	/**
	 * Function to list all products
	 */
	public function viewProduct($Id = '') {
		$this->db->select ( 'pr.*' );
		$this->db->from ( 'products AS pr' );
		$this->db->where ( 'pr.idproduct', $Id );
		$this->db->where ( 'pr.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->order_by ( 'pr.productname' );
		$query = $this->db->get ();
		// return $this->db->last_query();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$data [] = $row;
			}
			if (! empty ( $data ))
				return $data [0];
		}
		
		return null;
	}
	
	/**
	 * Function to list get Product Category
	 */
	public function getProductCategory($id = '') {
		$this->db->select ( 'productcategories.*' );
		$this->db->from ( 'productcategories' );
		
		$query = $this->db->get ();
		$this->str = "";
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if (isset ( $id ) && $row ['idproductcategory'] == $id) {
					$this->str .= '<option value="' . $row ['idproductcategory'] . '" selected="true">' . $row ['productcategory'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idproductcategory'] . '">' . $row ['productcategory'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to list get Product Potency
	 */
	public function getProductPotency($id = '') {
		$this->db->select ( 'productpotency.*' );
		$this->db->from ( 'productpotency' );
		
		$query = $this->db->get ();
		$this->str = "";
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if (isset ( $id ) && $row ['idpotency'] == $id) {
					$this->str .= '<option value="' . $row ['idpotency'] . '" selected="true">' . $row ['potency'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idpotency'] . '">' . $row ['potency'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	/**
	 * Function to list get Product Formulation
	 */
	public function getProductFormulation($id = '') {
		$this->db->select ( 'formulations.*' );
		$this->db->from ( 'formulations' );
		$this->db->order_by ( 'formulation', 'ASC' );
		$query = $this->db->get ();
		$this->str = "";
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if (isset ( $id ) && $row ['idformulation'] == $id) {
					$this->str .= '<option value="' . $row ['idformulation'] . '" selected="true">' . $row ['formulation'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idformulation'] . '">' . $row ['formulation'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to list get Product Manufacturer
	 */
	public function getProductManufacturer($id = '') {
		$this->db->select ( 'productmanufacturers.*' );
		$this->db->from ( 'productmanufacturers' );
		
		$query = $this->db->get ();
		$this->str = "";
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if (isset ( $id ) && $row ['idmanufacturer'] == $id) {
					$this->str .= '<option value="' . $row ['idmanufacturer'] . '" selected="true">' . $row ['manufacturer'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idmanufacturer'] . '">' . $row ['manufacturer'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to list get Product Packsize
	 */
	public function getProductPacksize($id = '') {
		$this->db->select ( 'packsizes.*' );
		$this->db->from ( 'packsizes' );
		
		$query = $this->db->get ();
		$this->str = "";
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if (isset ( $id ) && $row ['idpacksize'] == $id) {
					$this->str .= '<option value="' . $row ['idpacksize'] . '" selected="true">' . $row ['packsize'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idpacksize'] . '">' . $row ['packsize'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to list get Product Productsize
	 */
	public function getProductProductsize($id = '') {
		$this->db->select ( 'productsizes.*' );
		$this->db->from ( 'productsizes' );
		
		$query = $this->db->get ();
		$this->str = "";
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if (isset ( $id ) && $row ['idproductsize'] == $id) {
					$this->str .= '<option value="' . $row ['idproductsize'] . '" selected="true">' . $row ['productsize'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idproductsize'] . '">' . $row ['productsize'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to list get Adjust inventory
	 */
	public function viewAdjustInventory($id = '') {
		if (empty ( $id ))
			return false;
		
		$this->db->select ( 'p.*,pi.*' );
		$this->db->from ( 'products AS p' );
		$this->db->join ( 'product_inventory AS pi', 'p.idproduct = pi.idproduct', 'LEFT' );
		$this->db->where ( 'p.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'pi.idproduct', $id );
		
		$query = $this->db->get ();
		
		$data = array ();
		
		if ($query->num_rows () > 0) {
			$data = $query->result_array ();
			$data = $data [0];
		}
		
		return $data;
	}
	
	/**
	 * Function to list Adjust inventory at dashboard
	 */
	public function listAdjustInventory($id = '') {
		$data = array ();
		$this->db->select ( 'pi.idproduct,
				pi.min_amount,
				pi.max_amount,
				p.productname,
				p.onhand,
				pk.packsize' );
		$this->db->from ( 'product_inventory as pi' );
		$this->db->join ( 'products AS p', 'pi.idproduct = p.idproduct', 'INNER' );
		$this->db->join ( 'packsizes AS pk', 'p.idpacksize = pk.idpacksize', 'LEFT' );
		$where = "p.idlocation = " . $this->session->userdata ( 'idlocation' ) . " AND (p.onhand < pi.min_amount OR p.onhand > pi.max_amount)";
		$this->db->order_by ( 'p.onhand', 'desc' );
		$this->db->where ( $where );
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$data = $query->result_array ();
		}
		
		return $data;
	}
	
	/**
	 * Function to save Product Preferences
	 */
	public function saveProductpref($productdata = '') {
		$productid = $this->input->post ( 'productid' );
		$ratename = $this->input->post ( 'ratename' );
		$flowvalue = $this->input->post ( 'flowvalue' );
		$idproductuom = $this->input->post ( 'idproductuom' );
		$perflowvalue = $this->input->post ( 'perflowvalue' );
		$idareatreated = $this->input->post ( 'idareatreated' );
		$idlocation = $this->session->userdata ( 'idlocation' );
		
		$id = '';
		for($i = 0; $i < count ( $ratename ); $i ++) {
			if (! empty ( $ratename [$i] ) && ! empty ( $flowvalue [$i] ) && ! empty ( $idproductuom [$i] ) && ! empty ( $idareatreated [$i] )) {
				$data ['ratename'] = ! empty ( $ratename [$i] ) ? $ratename [$i] : '0';
				$data ['flowvalue'] = ! empty ( $flowvalue [$i] ) ? $flowvalue [$i] : '0';
				$data ['idproductuom'] = ! empty ( $idproductuom [$i] ) ? $idproductuom [$i] : '0';
				$data ['perflowvalue'] = ! empty ( $perflowvalue [$i] ) ? $perflowvalue [$i] : '0';
				$data ['idareatreated'] = ! empty ( $idareatreated [$i] ) ? $idareatreated [$i] : '0';
				$data ['idproduct'] = ! empty ( $productid ) ? $productid : '0';
				$data ['idlocation'] = ! empty ( $idlocation ) ? $idlocation : '0';
				$this->db->query ( 'SET foreign_key_checks = 0' );
				$this->db->insert ( 'productpreferences', $data );
				if (empty ( $id ))
					$id = $this->db->insert_id ();
				$this->db->query ( 'SET foreign_key_checks = 1' );
			}
		}
		return $id;
	}
	
	/**
	 * Function to fetch the Product Pref
	 */
	public function getProductPref($id = '') {
        $this->db->select ( 'prpf.idproductpreference, 
				prpf.idproductuom, 
				prpf.ratename, 
				prpf.flowvalue, 
				prpf.idareatreated, 
				prpf.idproduct, 
				pr.idformulation, 
				CONCAT(prpf.ratename, " ", prpf.flowvalue, " ", pu.unitproduct, "/", art.unitarea) AS app_rate_type', TRUE );
		$this->db->from ( 'products AS pr' );
		$this->db->join ( 'productpreferences AS prpf', 'pr.idproduct = prpf.idproduct', 'INNER' );
		$this->db->join ( 'productunit AS pu', 'prpf.idproductuom = pu.idproductunit', 'INNER' );
		$this->db->join ( 'area_treated AS art', 'prpf.idareatreated = art.idareatreated', 'INNER' );
		$this->db->order_by ( 'prpf.idproductpreference', 'ASC' );
		
		if (! empty ( $id ))
			$this->db->where ( 'pr.idproduct', $id );
		
		$query = $this->db->get ();
		return $query->result_array ();
	}
	
	/**
	 * Function to update Product Preferences
	 */
	public function updateProductpref($productdata = '') {
		$idproductpreference = $this->input->post ( 'idproductpreference' );
		$productid = $this->input->post ( 'productid' );
		$ratename = $this->input->post ( 'ratename' );
		$flowvalue = $this->input->post ( 'flowvalue' );
		$idproductuom = $this->input->post ( 'idproductuom' );
		$perflowvalue = $this->input->post ( 'perflowvalue' );
		$idareatreated = $this->input->post ( 'idareatreated' );
		$idlocation = $this->session->userdata ( 'idlocation' );
		
		$this->db->select ( 'idproductpreference' );
		$this->db->from ( 'productpreferences' );
		$this->db->where ( 'idproductpreference', $idproductpreference );
		$query = $this->db->get ();
		
		// print'<pre>';
		// print_r($perflowvalue);
		// die;
		$id = '';
		if ($query->num_rows () > 0) {
			$this->db->trans_start ();
			$this->db->query ( 'SET foreign_key_checks = 0' );
			$this->db->where ( 'idproduct', $productid );
			$this->db->delete ( 'productpreferences' );
			// echo $this->db->last_query()."<br>";
			$this->db->query ( 'SET foreign_key_checks = 1' );
			for($i = 0; $i < count ( $ratename ); $i ++) {
				$data = array ();
				$data ['ratename'] = ! empty ( $ratename [$i] ) ? $ratename [$i] : '0';
				$data ['flowvalue'] = ! empty ( $flowvalue [$i] ) ? $flowvalue [$i] : '0';
				$data ['idproductuom'] = ! empty ( $idproductuom [$i] ) ? $idproductuom [$i] : '0';
				$data ['perflowvalue'] = ! empty ( $perflowvalue [$i] ) ? number_format ( $perflowvalue [$i], '2', '.', '' ) : '0';
				$data ['idareatreated'] = ! empty ( $idareatreated [$i] ) ? $idareatreated [$i] : '0';
				$data ['idproduct'] = ! empty ( $productid ) ? $productid : '0';
				$data ['idlocation'] = ! empty ( $idlocation ) ? $idlocation : '0';
				// print'<pre>';
				// print_r($data);
				$this->db->query ( 'SET foreign_key_checks = 0' );
				$this->db->insert ( 'productpreferences', $data );
				// echo $this->db->last_query()."<br>";
				if (empty ( $id ) && $this->db->insert_id ())
					$id = $this->db->insert_id ();
				else if (empty ( $id ) && $this->db->affected_rows ())
					$id = $this->db->affected_rows ();
					// die($id."hre1");
					// echo $this->db->affected_rows()."<br>";
				$this->db->query ( 'SET foreign_key_checks = 1' );
			}
			$this->db->trans_complete ();
		} else {
			for($i = 0; $i < count ( $ratename ); $i ++) {
				$data = array ();
				$data ['ratename'] = ! empty ( $ratename [$i] ) ? $ratename [$i] : '0';
				$data ['flowvalue'] = ! empty ( $flowvalue [$i] ) ? $flowvalue [$i] : '0';
				$data ['idproductuom'] = ! empty ( $idproductuom [$i] ) ? $idproductuom [$i] : '0';
				$data ['perflowvalue'] = ! empty ( $perflowvalue [$i] ) ? $perflowvalue [$i] : '0';
				$data ['idareatreated'] = ! empty ( $idareatreated [$i] ) ? $idareatreated [$i] : '0';
				$data ['idproduct'] = ! empty ( $productid ) ? $productid : '0';
				$data ['idlocation'] = ! empty ( $idlocation ) ? $idlocation : '0';
				
				$this->db->query ( 'SET foreign_key_checks = 0' );
				$this->db->insert ( 'productpreferences', $data );
				if (empty ( $id ) && $this->db->insert_id ())
					$id = $this->db->insert_id ();
				else if (empty ( $id ) && $this->db->affected_rows ())
					$id = $this->db->affected_rows ();
				$this->db->query ( 'SET foreign_key_checks = 1' );
			}
		}
		
		return $id;
	}
	
	/**
	 * Function to list all Total Area Teated
	 */
	public function getProductTAreaTreated($id = '') {
		$query = $this->db->get ( 'area_treated' );
		foreach ( $query->result_array () as $row ) {
			$return [$row ['idareatreated']] = $row ['unitarea'];
		}
		return $return;
	}
	
	/**
	 * Function to list Selected Finished Mix for Product Editor
	 */
	public function getProductFinishedMix() {
		$query = $this->db->get ( 'finishedmix' );
		foreach ( $query->result_array () as $row ) {
			$return [$row ['idfinishedmix']] = $row ['unitfinishedmix'];
		}
		return $return;
	}
	
	/**
	 * Function to fetch Product Units
	 * @idproduct
	 */
	public function getProductUnits() {
		$query = $this->db->get ( 'productunit' );
		foreach ( $query->result_array () as $row ) {
			$return [$row ['idproductunit']] = $row ['unitproduct'];
		}
		return $return;
	}
}

?>