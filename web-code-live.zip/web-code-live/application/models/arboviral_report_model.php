<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Arboviral_report_model extends CI_Model {
	public $data = "";
	
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to fetch Adult Treatment
	 */
	public function getArboviral($startdate = '', $enddate = '') {
		$startdate_arr = explode ( "/", $startdate );
		$startdate = $startdate_arr [2] . "-" . $startdate_arr [0] . "-" . $startdate_arr [1];
		
		$enddate_arr = explode ( "/", $enddate );
		$enddate = $enddate_arr [2] . "-" . $enddate_arr [0] . "-" . $enddate_arr [1];
		
		$this->db->select ( 'a.*,
				t.trap,
				z.zone,
				l.labresult,
				at.assaytype,
				m.mosquitospecies,
				usr.firstname,
				usr.middlename,
				usr.lastname' );
		$this->db->from ( 'arbovirallabs AS a' );
		$this->db->join ( 'traps AS t', 'a.idtrap = t.idtrap', "LEFT" );
		$this->db->join ( 'sites AS s', 't.idsite = s.idsite', "LEFT" );
		// $this->db->join('sitezoneassignment AS sza','s.idsite = sza.idsite',"LEFT");
		$this->db->join ( 'zones AS z', 's.idzone = z.idzone', "LEFT" );
		$this->db->join ( 'labresults AS l', 'a.idlabresult = l.idlabresult', "LEFT" );
		$this->db->join ( 'assaytypes AS at', 'a.idassaytype = at.idassaytype', "LEFT" );
		$this->db->join ( 'mosquitospecies AS m', 'a.idmosquitospecies = m.idmosquitospecies', "LEFT" );
		$this->db->join ( 'users AS usr', 'a.idlabtechnician = usr.iduser', "LEFT" );
		// $this->db->join('locations AS lc',"s.idlocation = lc.idlocation",'INNER');
		// $this->db->where("a.idlocation ='".$this->session->userdata('idlocation')."' and z.idlocation='".$this->session->userdata('idlocation')."'");
		$this->db->where ( 'a.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'a.isdeleted', '0' );
		$this->db->where ( 'testdate >=', $startdate );
		$this->db->where ( 'testdate <=', $enddate );
		$this->db->order_by ( 'a.testdate', 'desc' );
		$query = $this->db->get ();
		// echo $this->db->last_query();
		// die;
		$result = array ();
		if ($query->num_rows () > 0) {
			$k = - 1;
			$i = 0;
			$flag = "";
			foreach ( $query->result_array () as $key => $val ) {
				$this->db->select ( 'ad.pudate' );
				$this->db->from ( 'traps AS t' );
				$this->db->join ( '`adultsurveillance` AS ad', 't.idtrap = ad.idtrap' );
				$this->db->where ( 't.idtrap', $val ['idtrap'] );
				
				$q = $this->db->get ();
				$datecollected = "";
				if ($q->num_rows () > 0) {
					$datecollected = $q->result_array ();
					$datecollected = $datecollected [0] ['pudate'];
				}
				
				if ($flag != $val ['idtrap']) {
					$i = 0;
					$k ++;
				}
				$data1 [$k] ['trap'] [$i] = $val;
				$data1 [$k] ['trap'] [$i] ['datecollected'] = $datecollected;
				$flag = $val ['idtrap'];
				$i ++;
			}
			// print'<pre>';
			// print_r($data1);
			// die;
			return $data1;
		}
		
		return $result;
	}
	public function getSentinels_by_Flock($startdate = '', $enddate = '') {
	    $startdate_arr = explode ( "/", $startdate );
	    $startdate = $startdate_arr [2] . "-" . $startdate_arr [0] . "-" . $startdate_arr [1];
	    $enddate_arr = explode ( "/", $enddate );
	    $enddate = $enddate_arr [2] . "-" . $enddate_arr [0] . "-" . $enddate_arr [1];
	    $this->db->select ( 'scl.idsentinelchickenlab,
				s.idlocation,
				sc.flockname,
				z.zone,
				scs.bandid,
				scl.datebled,
				scl.datesubmitted,
				scl.dateresults,
				lr.labresult,
				at.assaytype,
				scl.confirmedrtpcr,
				scl.comments,
				vt.virustypes' );
	    $this->db->from ( 'sentinelchickenlabs AS scl' );
	    $this->db->join ( 'sentinelchickensamples AS scs', 'scl.idsample = scs.idscs', "INNER" );
	    $this->db->join ( 'sentinelchicken AS sc', 'scs.idsentinelchicken = sc.idsentinelchicken', "INNER" );
	    $this->db->join ( 'sites AS s', 'sc.idsite = s.idsite', "INNER" );
	    $this->db->join ( 'zones AS z', 's.idzone = z.idzone', "INNER" );
	    $this->db->join ( 'labresults AS lr', 'scl.idlabresult = lr.idlabresult', "INNER" );
	    $this->db->join ( 'assaytypes AS at', 'scl.idassaytype = at.idassaytype', "INNER" );
	    $this->db->join ( 'virustypes AS vt', 'scl.idvirustype = vt.idvirustype', "INNER" );
	    $this->db->where ( 'datebled >=', $startdate );
	    $this->db->where ( 'datebled <=', $enddate );
	    // $this->db->join('locations AS lc',"s.idlocation = lc.idlocation",'INNER');
	    // $this->db->where("s.idlocation ='".$this->session->userdata('idlocation')."' and z.idlocation='".$this->session->userdata('idlocation')."'");
	    $this->db->where ( 'scl.idlocation', $this->session->userdata ( 'idlocation' ) );
	    $this->db->where ( 'scl.isdeleted', '0' );
	    $this->db->order_by ( 'scl.datebled', 'desc' );
	    //$this->db->group_by ( 's.site' );
	    $query = $this->db->get ();
	    //echo $this->db->last_query();
		$result = array ();
		if ($query->num_rows () > 0) {
			$k = 0;
			$i = 0;
			$flag = "";
			foreach ( $query->result_array () as $key => $val ) {
				$this->db->select ( 'flockname' );
				$this->db->from ( 'sentinelchicken' );
				
				$q = $this->db->get ();
				$datecollected = "";
				$data2 [$k] ['flockname'] [$i] = $val;
				$data2 [$k] ['flockname'] [$i] ['datecollected'] = $datecollected;
				$i ++;
				$k ++;
			}
			return $data2;
		}
		
		return $result;
	}
	public function getWild_Bird_by_Date($startdate = '', $enddate = '') {
		$startdate_arr = explode ( "/", $startdate );
		$startdate = $startdate_arr [2] . "-" . $startdate_arr [0] . "-" . $startdate_arr [1];
		$enddate_arr = explode ( "/", $enddate );
		$enddate = $enddate_arr [2] . "-" . $enddate_arr [0] . "-" . $enddate_arr [1];
		$this->db->select ( 'cl.*,
				scl.*,
				cl.idcorvidlab,
				site,
				zone,
				avsp.avianspecies,
				lr.labresult,
				cl.idavianspecies,
				at.assaytype,
				vt.virustypes,
				cl.rtprcconfirm,
				cl.idlabresult' );
		$this->db->from ( 'corvidlabs AS cl' );
		$this->db->join ( 'sentinelchickenlabs AS scl', 'cl.sampleid = scl.idsample', "INNER" );
		$this->db->join ( 'sites AS s', 'cl.idsite = s.idsite', "INNER" );
		$this->db->join ( 'zones AS z', 's.idzone = z.idzone', "INNER" );
		// $this->db->join('avianspecies AS as','cl.idavianspecies = as.idavianspecies',"INNER");
		$this->db->join ( 'avianspecies AS avsp', 'cl.idavianspecies=avsp.idavianspecies', "INNER" );
		$this->db->join ( 'labresults AS lr', 'cl.idlabresult = lr.idlabresult', "INNER" );
		$this->db->join ( 'assaytypes AS at', 'cl.idassaytype = at.idassaytype', "INNER" );
		$this->db->join ( 'virustypes AS vt', 'cl.idvirustype = vt.idvirustype', "INNER" );
		// $this->db->join('locations AS lc',"s.idlocation = lc.idlocation",'INNER');
		// $this->db->where("s.idlocation ='".$this->session->userdata('idlocation')."' and z.idlocation='".$this->session->userdata('idlocation')."'");
		$this->db->where ( 'cl.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'cl.isdeleted', '0' );
		$this->db->where ( 'datecollected >=', $startdate );
		$this->db->where ( 'datecollected <=', $enddate );
		$this->db->order_by ( 'cl.datecollected', 'desc' );
		$this->db->group_by ( 's.site' );
		$query = $this->db->get ();
		// echo $this->db->last_query(); die;
		$result = array ();
		if ($query->num_rows () > 0) {
			$k = 0;
			$i = 0;
			$flag = "";
			foreach ( $query->result_array () as $key => $val ) {
				$this->db->select ( 'site' );
				$this->db->from ( 'sites as s' );
				$this->db->where ( 's.site', $val ['idsite'] );
				$q = $this->db->get ();
				$datecollected = "";
				$data3 [$k] ['site'] [$i] = $val;
				// $this->data[$k]['site'][$i]['datecollected'] = $datecollected;
				$i ++;
				$k ++;
			}
			return $data3;
		}
		
		return $result;
	}
	
	/**
	 * Function to generate XML
	 */
	public function getXML($startdate = '', $enddate = '') {
		$startdate_arr = explode ( "/", $startdate );
		$startdate = $startdate_arr [2] . "-" . $startdate_arr [0] . "-" . $startdate_arr [1];
		
		$enddate_arr = explode ( "/", $enddate );
		$enddate = $enddate_arr [2] . "-" . $enddate_arr [0] . "-" . $enddate_arr [1];
		
		$this->db->select ( 'a.*,
				t.trap,
				z.zone,
				l.labresult,
				at.assaytype,
				m.mosquitospecies,
				usr.firstname,
				usr.middlename,
				usr.lastname' );
		$this->db->from ( 'arbovirallabs AS a' );
		$this->db->join ( 'traps AS t', 'a.idtrap = t.idtrap', "LEFT" );
		$this->db->join ( 'sites AS s', 't.idsite = s.idsite', "LEFT" );
		$this->db->join ( 'zones AS z', 's.idzone = z.idzone', "LEFT" );
		$this->db->join ( 'labresults AS l', 'a.idlabresult = l.idlabresult', "LEFT" );
		$this->db->join ( 'assaytypes AS at', 'a.idassaytype = at.idassaytype', "LEFT" );
		$this->db->join ( 'mosquitospecies AS m', 'a.idmosquitospecies = m.idmosquitospecies', "LEFT" );
		$this->db->join ( 'users AS usr', 'a.idlabtechnician = usr.iduser', "LEFT" );
		$this->db->join ( 'locations AS lc', "s.idlocation = lc.idlocation", 'INNER' );
		$this->db->where ( 'a.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'a.isdeleted', '0' );
		$this->db->where ( 'testdate >=', $startdate );
		$this->db->where ( 'testdate <=', $enddate );
		$this->db->order_by ( 'a.testdate', 'desc' );
		$query = $this->db->get ();
		
		return $query;
	}
}
