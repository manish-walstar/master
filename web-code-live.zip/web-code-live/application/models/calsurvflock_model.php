<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class CalSurvFlock_model extends CI_Model {
	public $str = "";
	public $map = "";
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to Add a new Sentinel Chicken Lab if no id is supplied
	 * On passing Id the function updates the Table
	 */
	public function addCalSurvFlock($id = '') {
		$id = $this->input->post ( 'idcalsurvflock' );
		
		$saveandsend = $this->input->post ( 'saveandsend' );
		$saveandclose = $this->input->post ( 'saveandclose' );
		
		$flockyear = $this->input->post ( 'flockyear' );
		$idsentinelchicken = $this->input->post ( 'flockid' );
		$idsite = $this->input->post ( 'site' );
		$datebled = $this->input->post ( 'datebled' );
		$datesubmit = $this->input->post ( 'datesubmitted' );
		$dateresult = $this->input->post ( 'dateresults' );
		$idcollector = $this->input->post ( 'collector' );
		$bandid = $this->input->post ( 'bandids' );
        $bandid = $bandid ? explode(',', $bandid) : '';
		$bandcomment = $this->input->post ( 'bandcomment' );
		$idlocation = $this->session->userdata ( 'idlocation' );
		$iswholeblood = $this->input->post ( 'iswholeblood' );
		$issubmissionform = $this->input->post ( 'issubmissionform' );
		
		$data ['flockyear'] = ! empty ( $flockyear ) ? $flockyear : '';
		$data ['idsentinelchicken'] = ! empty ( $idsentinelchicken ) ? $idsentinelchicken : 0;
		$data ['idsite'] = ! empty ( $idsite ) ? $idsite : 0;
		$data ['datebled'] = date ( 'Y-m-d', strtotime ( $datebled ) );
		// $data['datesubmitted'] = date('Y-m-d',strtotime($datesubmit));
		// $data['dateresults'] = date('Y-m-d',strtotime($dateresult));
		$data ['idcollector'] = ! empty ( $idcollector ) ? $idcollector : 0;
		$data ['idsentinelchicken'] = ! empty ( $idsentinelchicken ) ? $idsentinelchicken : 0;
		$data ['comments'] = $this->input->post ( 'comment' );
		$data ['iswholeblood'] = ! empty ( $iswholeblood ) ? '1' : '0';
		$data ['issubmissionform'] = ! empty ( $issubmissionform ) ? '1' : '0';
		$data ['idlocation'] = $this->session->userdata ( 'idlocation' );
		$data ['dateadded'] = date ( 'Y-m-d' );
		
		if (empty ( $id ))
			$data ['datesent'] = '';
		
		$bandIds = array ();
		
		/* ---------------- For Tesing open the comments ----------------------- */
		// $_POST['idcalsurv'] = 21;
		// return $_POST;
		// print'<pre>';
		// print_r($data);
		// die;
		
		// if(!empty($bandid))
		// {
		// for($i=0; $i< count($bandid); $i++)
		// {
		// array_push($bandIds, $bandid[$i]);
		// }
		// }
		// $importData = $data;
		// $importData['collectedby'] = $this->getCollectorName($importData['idcollector']);
		// $importData['site'] = $this->getSite($importData['idsite']);
		// $importData['idcalsurv'] = $id;
		// $importData['bandset'] = $bandIds;
		// return $importData;
		//
		/* --------------------------------------- */
		
		$this->db->trans_start ();
		
		if (! empty ( $id )) {
			$this->db->query ( "SET foreign_key_checks = 0" );
			$this->db->where ( 'idcalsurv', $id );
			$this->db->update ( 'calsurvflock', $data );
			$this->db->query ( "SET foreign_key_checks = 1" );
			
			$this->db->query ( "SET foreign_key_checks = 0" );
			$this->db->where ( 'idcalsurvflock', $id );
			$this->db->delete ( 'calsurvband' );
			$this->db->query ( "SET foreign_key_checks = 1" );
			
			if (! empty ( $bandid )) {
				$j = 0;
				for($i = 0; $i < count ( $bandid ); $i ++) {
					$dataBands ['idcalsurvflock'] = $id;
					$dataBands ['idsentinelchickensample'] = $bandid [$i];
					$dataBands ['comments'] = $bandcomment [$i];
					if(!empty($bandid [$i])) {
                        $this->db->query ( "SET foreign_key_checks = 0" );
    					$this->db->insert ( 'calsurvband', $dataBands );
    					$this->db->query ( "SET foreign_key_checks = 1" );
                    }
					
					if (! empty ( $bandid [$i] )) {
						$this->db->select ( 'bandid' );
						$this->db->from ( 'sentinelchickensamples' );
						$this->db->where ( 'idscs', $bandid [$i] );
						$q = $this->db->get ();
						if ($q->num_rows () > 0) {
							$band = $q->result_array ();
							$bandIds [$j] ['official'] = intval ( $band [0] ['bandid'] );
							$bandIds [$j] ['comments'] = $bandcomment [$i];
							$j ++;
						}
					}
				}
			}
		} else {
			$this->db->query ( "SET foreign_key_checks = 0" );
			$this->db->insert ( 'calsurvflock', $data );
			$id = $this->db->insert_id ();
			$this->db->query ( "SET foreign_key_checks = 1" );
			// $id = 1;
			
			if (! empty ( $bandid )) {
				$j = 0;
				for($i = 0; $i < count ( $bandid ); $i ++) {
					$dataBands ['idcalsurvflock'] = $id;
					$dataBands ['idsentinelchickensample'] = $bandid [$i];
					$dataBands ['comments'] = $bandcomment [$i];
                    if(!empty($bandid [$i])) {
                        $this->db->query ( "SET foreign_key_checks = 0" );
    					$this->db->insert ( 'calsurvband', $dataBands );
    					$this->db->query ( "SET foreign_key_checks = 1" );
                    }
					
					if (! empty ( $bandid [$i] )) {
						$this->db->select ( 'bandid' );
						$this->db->from ( 'sentinelchickensamples' );
						$this->db->where ( 'idscs', $bandid [$i] );
						$q = $this->db->get ();
						if ($q->num_rows () > 0) {
							$band = $q->result_array ();
							$bandIds [$j] ['official'] = intval ( $band [0] ['bandid'] );
							$bandIds [$j] ['comments'] = $bandcomment [$i];
							$j ++;
						}
					}
				}
			}
		}
		$this->db->trans_complete ();
		
		if (! empty ( $id ) && $this->db->trans_status ()) {
			$importData = $data;
			$importData ['collectedby'] = $this->getCollectorName ( $importData ['idcollector'] );
			$importData ['site'] = $this->getSite ( $importData ['idsite'] );
			$importData ['idcalsurv'] = $id;
			$importData ['bandset'] = $bandIds;
			return $importData;
		}
		
		return false;
	}
	
	/**
	 * Function to fetch the collector first middle & lastname
	 */
	public function getCollectorName($idcollector) {
		if (empty ( $idcollector ))
			return false;
		
		$this->db->select ( 'usr.firstname, usr.middlename, usr.lastname' );
		$this->db->from ( 'users AS usr' );
		$this->db->where ( 'usr.iduser', $idcollector );
		
		$username = $this->db->get ()->row ();
		if (! empty ( $username )) {
			$lastname = ! empty ( $username->middlename ) ? $username->middlename . " " : '';
			$lastname .= ! empty ( $username->lastname ) ? $username->lastname : '';
			return array (
					! empty ( $username->firstname ) ? $username->firstname : '',
					$lastname 
			);
		}
	}
	
	/**
	 * Function to fetch the site name
	 */
	public function getSite($idsite) {
		if (empty ( $idsite ))
			return false;
		
		$this->db->select ( 'sites.site' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'sites.idsite', $idsite );
		$site = $this->db->get ()->row ();
		
		return ! empty ( $site->site ) ? $site->site : '';
	}
	
	/**
	 * Function to delete Sentinel Chicken lab
	 */
	public function deleteCalSurvFlock() {
		$id = $this->input->get_post ( 'id' );
		
		if (empty ( $id ))
			return false;
		
		$data ['isdeleted'] = '1';
		
		$this->db->query ( "SET foreign_key_checks = 0" );
		$this->db->where ( 'idcalsurv', $id );
		$this->db->update ( 'calsurvflock', $data );
		$rows = $this->db->affected_rows ();
		
		$this->db->query ( "SET foreign_key_checks = 1" );
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to Get Lati Longi
	 * for displaying on Maps
	 */
	public function getMapdata() {
        $offset = 0;
		$page_size = $this->input->get ( 'page_size' );
		$page = $this->input->get ( 'page' );
		$filter_date = $this->input->get ( 'filter_date' );
		$setfromdate = $this->input->get ( 'setfromdate' );
		$settodate = $this->input->get ( 'settodate' );
		
        $page_size = ($page_size == 'all') ? 'all' : (is_numeric($page_size) ? $page_size : 10);
        $limit = (is_numeric($page_size)) ? $page_size : NULL;        
        $offset = $limit * ($page - 1);
        
        if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 2;

		$this->db->select ( 'cl.*,st.latitude,st.longitude,l.GoogleZoom' );
		$this->db->from ( 'calsurvflock AS cl' );
		$this->db->join ( 'sentinelchicken AS st', 'cl.idsentinelchicken = st.idsentinelchicken', 'LEFT' );
		$this->db->join ( 'sites AS s', 'st.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'locations AS l', 's.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'cl.isdeleted', '0' );
		if (! is_null ( $filter_date ) && empty ( $setfromdate ) && empty ( $settodate )) {
			switch ($filter_date) {
				case '1' :
					$this->db->where ( 'cl.datebled' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'cl.datebled' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'cl.datebled' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'cl.datebled' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'cl.datebled' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'cl.datebled' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'cl.datebled' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'cl.datebled' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'cl.datebled' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'cl.datebled' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		} else if (! empty ( $setfromdate ) && ! empty ( $settodate )) {
			$this->db->where ( 'cl.datebled' . ' >=', $setfromdate );
			$this->db->where ( 'cl.datebled' . ' <=', $settodate );
		}
		
		$this->db->order_by ( 'cl.datebled', 'desc' );
		$this->db->limit ( $limit, $offset );
		// $this->db->group_by("`ad`.`idlab`");
		
		$data_1 = array ();
		$query = $this->db->get ();
		$result = array ();
		// echo $this->db->last_query();
		// die;
		if ($query->num_rows () > 0)
			return $query->result_array ();
	}
	/**
	 * Function to list particular Cal Surv Flock
	 */
	public function getCalSurvFlockData($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( '*' );
		$this->db->from ( 'calsurvflock' );
		$this->db->where ( 'idcalsurv', $Id );
		
		$query = $this->db->get ();
		
		$data = array ();
		if ($query->num_rows () > 0) {
			$data = $query->result_array ();
			return $data [0];
		}
		
		return false;
	}
	
	/**
	 * Function to list particular Cal Surv Flock
	 * Data for Printing Report
	 */
	public function getCalSurvFlockDataForPrint($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( 'cf.idcalsurv,cf.datebled,
				cf.comments AS cfcomments, 
				s.idsite,s.site,
				s.manphone AS mainphone,
				CONCAT(u.firstname," ",u.middlename," ",u.lastname) AS collector', TRUE );
		$this->db->from ( 'calsurvflock AS cf' );
		$this->db->join ( 'sites AS s', 'cf.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'users AS u', 'cf.idcollector = u.iduser', 'LEFT' );
		$this->db->where ( 'idcalsurv', $Id );
		
		$query = $this->db->get ();
		
		$data = array ();
		$result = array ();
		if ($query->num_rows () > 0) {
			$data = $query->result_array ();
			
			foreach ( $query->result_array () as $key => $val ) {
				$this->db->select ( 'scs.bandid,
						cb.comments,
						v.virustypes, 
						cb.idsentinelchickensample' );
				$this->db->from ( 'calsurvband AS cb' );
				$this->db->join ( 'sentinelchickensamples AS scs', 'cb.idsentinelchickensample = scs.idscs', 'LEFT' );
				$this->db->join ( 'sentinelchickenlabs AS scl', 'scs.idsentinelchicken = scl.idsentinelchicken', 'LEFT' );
				$this->db->join ( 'virustypes AS v', 'scl.idvirustype = v.idvirustype', 'LEFT' );
				$this->db->where ( 'cb.idcalsurvflock', $val ['idcalsurv'] );
				
				$q = $this->db->get ();
				if ($q->num_rows () > 0) {
					$result = $q->result_array ();
				}
			}
			$data [0] ['bands'] = $result;
		}
		return ! empty ( $data [0] ) ? $data [0] : $data;
	}
	
	/**
	 * Function to list particular Cal Surv Flock
	 * Data for Import Data from CA Gateway
	 */
	public function getCalSurvFlockDataForExport($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( 'cf.idcalsurv, 
				cf.idsentinelchicken, 
				cf.flockyear, 
				cf.datebled, 
				s.idsite, 
				s.site, 
				s.manphone AS mainphone' );
		$this->db->from ( 'calsurvflock AS cf' );
		$this->db->join ( 'sites AS s', 'cf.idsite = s.idsite', 'LEFT' );
		$this->db->where ( 'idcalsurv', $Id );
		
		$query = $this->db->get ();
		
		$data = array ();
		$result = array ();
		if ($query->num_rows () > 0) {
			$data = $query->result_array ();
			
			foreach ( $query->result_array () as $key => $val ) {
				$this->db->select ( 'scs.bandid, 
						cb.comments, 
						scl.datebled as testdate, 
						a.assaytype AS method, 
						v.virustypes AS target, 
						lr.labresult AS result' );
				$this->db->from ( 'calsurvband AS cb' );
				$this->db->join ( 'sentinelchickensamples AS scs', 'cb.idsentinelchickensample = scs.idscs', 'LEFT' );
				$this->db->join ( 'sentinelchickenlabs AS scl', 'scs.idsentinelchicken = scl.idsentinelchicken', 'LEFT' );
				$this->db->join ( 'assaytypes AS a', 'scl.idassaytype = a.idassaytype', 'LEFT' );
				$this->db->join ( 'labresults AS lr', 'scl.idlabresult = lr.idlabresult', 'LEFT' );
				$this->db->join ( 'virustypes AS v', 'scl.idvirustype = v.idvirustype', 'LEFT' );
				$this->db->where ( 'cb.idcalsurvflock', $val ['idcalsurv'] );
				// $this->db->where('scl.idsentinelchicken',$val['idsentinelchicken']);
				
				$q = $this->db->get ();
				
				if ($q->num_rows () > 0) {
					$i = 1;
					foreach ( $q->result_array () as $k => $v ) {
						$result [$i] ["official"] = $i;
						if (! empty ( $v ['testdate'] ) && ! empty ( $v ['method'] ) && ! empty ( $v ['result'] ) && ! empty ( $v ['target'] )) {
							$result [$i] ["testset"] = array (
									"testdate" => $v ['testdate'],
									"method" => $v ['method'],
									"targetset" => array (
											"target" => $v ['target'],
											"result" => strtolower ( $v ['result'] ) 
									) 
							);
						} else if (! empty ( $v ['testdate'] ) && ! empty ( $v ['method'] ) && ! empty ( $v ['target'] )) {
							$result [$i] ["testset"] = array (
									"testdate" => $v ['testdate'],
									"method" => $v ['method'],
									"targetset" => array (
											"target" => $v ['target'] 
									) 
							);
						} else if (! empty ( $v ['testdate'] ) && ! empty ( $v ['method'] )) {
							$result [$i] ["testset"] = array (
									"testdate" => $v ['testdate'],
									"method" => $v ['method'] 
							);
						}
						$i ++;
					}
				}
			}
			$data [0] ['bandIds'] = $result;
		}
		return ! empty ( $data [0] ) ? $data [0] : $data;
	}
	
	/**
	 * Function to list particular Cal Surv Flock
	 * BANDID Data for Import Data from CA Gateway
	 */
	public function getCalSurvFlockBand($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( 'cf.*, usr.firstname AS collctrFirstName, CONCAT(usr.middlename, \' \', usr.lastname) AS collctrLastName ', FALSE);
		$this->db->from ( 'calsurvflock AS cf' );
        $this->db->join ( 'users AS usr', 'cf.idcollector = usr.iduser', 'LEFT' );
		$this->db->where ( 'cf.idcalsurv', $Id );
        //$this->db->where ( 'cf.issent', '0' );
        $this->db->where ( 'cf.isdeleted', '0' );
		
		$query = $this->db->get ();
		
		$data = array ();
		$result = array ();
		if ($query->num_rows () > 0) {
			$data = $query->result_array ();
			
			foreach ( $query->result_array () as $key => $val ) {
				$this->db->select ( 'scs.bandid, cb.comments' );
				$this->db->from ( 'calsurvband AS cb' );
				$this->db->join ( 'sentinelchickensamples AS scs', 'cb.idsentinelchickensample = scs.idscs', 'LEFT' );
				$this->db->where ( 'cb.idcalsurvflock', $val ['idcalsurv'] );
				
				$q = $this->db->get ();
				
				if ($q->num_rows () > 0) {
					$i = 0;
					foreach ( $q->result_array () as $k => $v ) {
						if (! empty ( $v ['bandid'] )) {
							$result [$i] ["official"] = intval ( $v ['bandid'] );
							$result [$i] ["comments"] = $v ['comments'];
							$i ++;
						}
					}
				}
			}
			$data [0] ['bandset'] = $result;
		}
		// print'<pre>';
		// print_r($data);
		// die;
		return ! empty ( $data [0] ) ? $data [0] : $data;
	}
	
	/**
	 * Function to fetch History for Cal Suvr Flock
	 */
	public function getHistory($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( 'sl.idcalsurv' );
		$this->db->from ( 'calsurvflock AS sl' );
		$this->db->where ( 'idcalsurv', $Id );
		$query = $this->db->get ();
		// echo $this->db->last_query();
		$idsample = '';
		if ($query->num_rows () > 0) {
			$idsample = $query->result_array ();
			$idsample = $idsample [0] ['idcalsurv'];
		}
		
		if (empty ( $idsample ))
			return false;
		
		$this->db->select ( 'sl.* , 
				s.flockname , 
				l.labresult , 
				v.virustypes, 
				scl.idlabresult, 
				scl.idvirustype' );
		$this->db->from ( 'calsurvflock AS sl' );
		$this->db->join ( 'sentinelchicken AS s', 'sl.idsentinelchicken = s.idsentinelchicken', 'LEFT' );
		$this->db->join ( 'sentinelchickenlabs AS scl', 'sl.idsentinelchicken = scl.idsentinelchicken', 'LEFT' );
		$this->db->join ( 'labresults AS l', 'scl.idlabresult = l.idlabresult', 'LEFT' );
		$this->db->join ( 'virustypes AS v', 'scl.idvirustype = v.idvirustype', 'LEFT' );
		$this->db->where ( 'idcalsurv', $idsample );
		
		$query = $this->db->get ();
		// echo $this->db->last_query();die;
		$data = array ();
		if ($query->num_rows () > 0) {
			$data = $query->result_array ();
			return $data;
		}
		
		return false;
	}
	
	/**
	 * Function to list all Corvidlabs mail
	 */
	public function listCalSurvFlocks() {
		$this->db->select ( 'scl.idcalsurvflock, 
				sc.flockname, 
				scs.bandid, 
				scl.datebled, 
				scl.datesubmitted, 
				scl.dateresults, 
				lr.labresult, 
				v.virustypes' );
		$this->db->from ( 'calsurvflocks AS scl' );
		$this->db->join ( 'sentinelchicken AS sc', 'scl.idsentinelchicken = sc.idsentinelchicken', 'LEFT' );
		$this->db->join ( 'sentinelchickensamples AS scs', 'scl.idsample = scs.idscs', 'LEFT' );
		$this->db->join ( 'labresults AS lr', 'scl.idlabresult = lr.idlabresult', 'LEFT' );
		$this->db->join ( 'virustypes AS v', 'scl.idvirustype = v.idvirustype', 'LEFT' );
		$this->db->join ( 'sites AS s', 'sc.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'locations AS l', 's.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'scl.isdeleted', '0' );
		
		$filter_date = $this->input->get ( 'filter_date' );
		$ttl = $this->input->get ( 'ttl' );
		$page = $this->input->get ( 'page' );
		$frmdate = $this->input->get ( 'frmdate' );
		$todate = $this->input->get ( 'todate' );
		$orderby = $this->input->get ( 'orderby' );
		$filter_by_lab = $this->input->get ( 'lab' );
		
		if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 2;
		
		if (! isset ( $ttl ) || $ttl == '')
			$ttl = 10;
		
		if (! isset ( $page ) || $page == '')
			$page = 1;
		
		if (! empty ( $frmdate ) && ! empty ( $todate )) {
			$frmdate = substr ( $frmdate, 0, 2 ) . '/' . substr ( $frmdate, 2, 2 ) . '/' . substr ( $frmdate, 4, 4 );
			$todate = substr ( $todate, 0, 2 ) . '/' . substr ( $todate, 2, 2 ) . '/' . substr ( $todate, 4, 4 );
			$this->db->where ( 'scl.dateresults' . ' >=', date ( 'Y-m-d', strtotime ( $frmdate ) ) );
			$this->db->where ( 'scl.dateresults' . ' <=', date ( 'Y-m-d', strtotime ( $todate ) ) );
		} else if (! is_null ( $filter_date )) {
			switch ($filter_date) {
				// date('H:i:s',strtotime('-1 day');
				case '1' :
					$this->db->where ( 'scl.dateresults' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'scl.dateresults' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'scl.dateresults' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'scl.dateresults' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'scl.dateresults' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'scl.dateresults' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'scl.dateresults' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'scl.dateresults' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'scl.dateresults' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'scl.dateresults' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		}
		/*
		 * if(!is_null($ttl) && !is_null($page))
		 * {
		 * if($page == 1)
		 * $page = 0;
		 * else
		 * $page--;
		 *
		 * $page *= 10;
		 * $this->db->limit($ttl ,$page);
		 * }
		 * else if(!is_null($ttl))
		 * {
		 * $this->db->limit($ttl);
		 * }
		 * $this->db->order_by('scl.dateresults' , "DESC");
		 */
		
		if (! empty ( $filter_by_lab )) {
			switch ($filter_by_lab) {
				case '1' :
					$this->db->where ( 'lr.idlabresult', '2' );
					break;
				case '2' :
					$this->db->where ( 'lr.idlabresult', '-1' );
					break;
				case '3' :
					$this->db->where ( 'lr.idlabresult', '1' );
					break;
			}
		}
		
		if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
			switch ($orderby) {
				case '0:asc' :
					$this->db->order_by ( 'sc.flockname', 'ASC' );
					break;
				case '0:desc' :
					$this->db->order_by ( 'sc.flockname', 'DESC' );
					break;
				case '1:asc' :
					$this->db->order_by ( 'scs.bandid', 'ASC' );
					break;
				case '1:desc' :
					$this->db->order_by ( 'scs.bandid', 'DESC' );
					break;
				case '2:asc' :
					$this->db->order_by ( "scl.datebled", 'ASC' );
					break;
				case '2:desc' :
					$this->db->order_by ( "scl.datebled", 'DESC' );
					break;
				case '3:asc' :
					$this->db->order_by ( 'scl.datesubmitted', 'ASC' );
					break;
				case '3:desc' :
					$this->db->order_by ( 'scl.datesubmitted', 'DESC' );
					break;
				case '4:asc' :
					$this->db->order_by ( "scl.dateresults", 'ASC' );
					break;
				case '4:desc' :
					$this->db->order_by ( "scl.dateresults", 'DESC' );
					break;
				case '5:asc' :
					$this->db->order_by ( "lr.labresult", 'ASC' );
					break;
				case '5:desc' :
					$this->db->order_by ( "lr.labresult", 'DESC' );
					break;
				case '6:asc' :
					$this->db->order_by ( "v.virustypes", 'ASC' );
					break;
				case '6:desc' :
					$this->db->order_by ( "v.virustypes", 'DESC' );
					break;
			}
		} else {
			$this->db->order_by ( 'scl.dateresults', 'DESC' );
		}
		
		$data_1 = array ();
		$query = $this->db->get ();
		// echo $this->db->last_query();
		// die;
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
		
		return false;
	}
	
	/**
	 * Function to fetch the list of Flocks
	 */
	public function getFlocks($id = '') {
		$this->db->select ( 'idsentinelchicken,flockname,idsite' );
		$this->db->from ( 'sentinelchicken AS sc' );
		$this->db->where ( 'sc.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->order_by ( "sc.flockname", "ASC" );
		$query = $this->db->get ();
		
		$result = array ();
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				if (! empty ( $id ) && $row ['idsentinelchicken'] == $id) {
					$result [$i] ['selected'] = true;
					$result [$i] ['text'] = $row ['flockname'];
					$result [$i] ['value'] = $row ['idsentinelchicken'];
                    $result [$i] ['idsite'] = $row ['idsite'];
				} else {
					$result [$i] ['selected'] = false;
					$result [$i] ['text'] = $row ['flockname'];
                    $result [$i] ['value'] = $row ['idsentinelchicken'];
					$result [$i] ['idsite'] = $row ['idsite'];
				}
				$i ++;
			}
		}
		return $result;
	}
	
	/**
	 * Function to fetch the years of Flocks
	 */
	public function getFlockYear($year = '') {
		$this->db->select ( 'DISTINCT(DATE_FORMAT(sc.date,\'%Y\')) AS year' );
		$this->db->from ( 'sentinelchicken AS sc' );
		$this->db->where ( 'sc.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->order_by ( 'sc.date', 'ASC' );
		
		$query = $this->db->get ();
		$result = array ();
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				if (! empty ( $year ) && $row ['year'] == $year) {
					$result [$i] ['selected'] = true;
					$result [$i] ['value'] = $row ['year'];
					$result [$i] ['text'] = $row ['year'];
				} else {
					$result [$i] ['selected'] = false;
					$result [$i] ['value'] = $row ['year'];
					$result [$i] ['text'] = $row ['year'];
				}
				$i ++;
			}
		}
		return $result;
	}
	
	/**
	 * Function to fetch the list of Sites
	 */
	public function getSites($idsentinel = '', $siteid = '') {
		$this->db->select ( 's.idsite,s.site' );
		$this->db->from ( 'sentinelchicken AS sc' );
		$this->db->join ( 'sites AS s', 'sc.idsite = s.idsite', 'INNER' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->group_by ( "s.idsite" );
		$this->db->order_by ( "s.site", "ASC" );
		
		$query = $this->db->get ();
		
		$result = array ();
		if ($query->num_rows () > 0) {
			$i = 0;
			
			$idsite = '';
			if (! empty ( $idsentinel ) && empty ( $siteid )) {
				$this->db->select ( 'sc.idsite' );
				$this->db->from ( 'sentinelchicken AS sc' );
				$this->db->where ( "sc.idsentinelchicken", $idsentinel );
				$querySite = $this->db->get ()->row ();
				$idsite = ! empty ( $querySite ) ? $querySite->idsite : '';
			} else if (! empty ( $siteid ))
				$idsite = $siteid;
			
			foreach ( $query->result_array () as $row ) {
				if (! empty ( $idsite ) && $row ['idsite'] == $idsite) {
					$result [$i] ['selected'] = true;
					$result [$i] ['value'] = $row ['idsite'];
					$result [$i] ['text'] = $row ['site'];
				} else {
					$result [$i] ['selected'] = false;
					$result [$i] ['value'] = $row ['idsite'];
					$result [$i] ['text'] = $row ['site'];
				}
				$i ++;
			}
		}
		// print'<pre>';
		// print_r($result);
		// die;
		return $result;
	}
	
	/**
	 * Function to fetch the list of Chickens
	 */
	public function getBands($idsentinel = '', $idcalsurvflock = '') {
		if (empty ( $idsentinel ))
			return false;
		
		$this->db->select ( 'scs.idscs, scs.idsentinelchicken, scs.bandid' );
		$this->db->from ( 'sentinelchickensamples AS scs' );
		$this->db->where ( 'scs.idsentinelchicken', $idsentinel );
		$this->db->order_by ( "scs.bandid", "ASC" );
		$query = $this->db->get ();
		
		$result = array ();
		
		$calsurvbands = $this->getSelectedBands ( $idcalsurvflock );
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				if (! empty ( $row ['idscs'] ) && ! empty ( $row ['bandid'] ) && ! empty ( $row ['idsentinelchicken'] )) {
					$result [$i] ['idscs'] = $row ['idscs'];
					$result [$i] ['bandid'] = $row ['bandid'];
					$result [$i] ['idsentinelchicken'] = $row ['idsentinelchicken'];
					if (! empty ( $idcalsurvflock ) && ! empty ( $row ['idscs'] )) {
						$result [$i] ['comment'] = $this->getComments ( $idcalsurvflock, $row ['idscs'] );
						if (! empty ( $calsurvbands ) && in_array ( $row ['bandid'], $calsurvbands ))
							$result [$i] ['selected'] = true;
						else
							$result [$i] ['selected'] = false;
					}
				}
				$i ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to fetch the list of Chickens
	 */
	public function getSelectedBands($idcalsurvflock = '') {
		if (empty ( $idcalsurvflock ))
			return false;
		
		$this->db->select ( 'ss.bandid' );
		$this->db->from ( 'calsurvband AS cb' );
		$this->db->join ( 'sentinelchickensamples AS ss', 'cb.idsentinelchickensample = ss.idscs', 'INNER' );
		$this->db->where ( 'cb.idcalsurvflock', $idcalsurvflock );
		$query = $this->db->get ();
		
		$result = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				array_push ( $result, $row ['bandid'] );
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to fetch the comments for the band
	 */
	public function getComments($idcalsurvflock = '', $idscs = '') {
		if (empty ( $idcalsurvflock ) || empty ( $idscs ))
			return false;
		
		$this->db->select ( 'comments' );
		$this->db->from ( 'calsurvband' );
		$this->db->where ( 'idcalsurvflock', $idcalsurvflock );
		$this->db->where ( 'idsentinelchickensample', $idscs );
		$queryComment = $this->db->get ()->row ();
		
		return ! empty ( $queryComment->comments ) ? $queryComment->comments : '';
	}
	
	/**
	 * Function to check if cagateway = 1
	 */
	public function checkCaGateway() {
		$this->db->select ( 'cagateway' );
		$this->db->from ( 'locations' );
		$this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'cagateway', 1 );
		
		$query = $this->db->get ();
		if ($query->num_rows () > 0)
			return true;
		
		return false;
	}
}
