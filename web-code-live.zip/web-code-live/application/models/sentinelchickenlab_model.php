<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class SentinelChickenlab_model extends CI_Model {
	public $str = "";
	public $map = "";
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to Add a new Sentinel Chicken Lab if no id is supplied
	 * On passing Id the function updates the Table
	 */
	public function addSentinelChickenlab($id = '') {
		$id = $this->input->post ( 'id' );
		$idloc = $this->session->userdata ( 'idlocation' );
		$assay_type = $this->input->post ( 'assay_type' );
		$lab_result = $this->input->post ( 'lab_result' );
		$detected_virus = $this->input->post ( 'detected_virus' );
		$rampunits = $this->input->post ( 'rampunits' );
		$idsentinelchicken = $this->input->post ( 'flockid' );
		$idsample = $this->input->post ( 'sampleid' );
		$confirm = $this->input->post ( 'confirm' );
		$result = $this->input->post ( 'result' );
		$datebled = $this->input->post ( 'datebled' );
		$datesubmit = $this->input->post ( 'datesubmitted' );
		$dateresult = $this->input->post ( 'dateresults' );
		
		// echo $assay_type." ".$lab_result." ".$detected_virus." ".$rampunits;
		$data ['idsentinelchicken'] = ! empty ( $idsentinelchicken ) ? $idsentinelchicken : 0;
		$data ['idsample'] = ! empty ( $idsample ) ? $idsample : 0;
		$data ['datebled'] = date ( 'Y-m-d', strtotime ( $datebled ) );
		$data ['datesubmitted'] = date ( 'Y-m-d', strtotime ( $datesubmit ) );
		$data ['dateresults'] = date ( 'Y-m-d', strtotime ( $dateresult ) );
		$data ['idassaytype'] = ! empty ( $assay_type ) ? $assay_type : 0;
		$data ['idlabresult'] = ! empty ( $lab_result ) ? $lab_result : 0;
		$data ['idvirustype'] = ! empty ( $detected_virus ) ? $detected_virus : 0;
		$data ['rampunit'] = ! empty ( $rampunits ) ? $rampunits : '';
		$data ['confirmedrtpcr'] = (! empty ( $confirm ) && $confirm == "1") ? "1" : "0";
		$data ['resultscorrespond'] = (! empty ( $result ) && $result == "1") ? "1" : "0";
		$data ['comments'] = $this->input->post ( 'comment' );
		$data ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
		// echo $data['collectedbyfirst']." ".$data['collectedbylast'] ;
		// die;
		$this->db->query ( "SET foreign_key_checks = 0" );
		
		if (! empty ( $id )) {
			$this->db->where ( 'idsentinelchickenlab', $id );
			$this->db->update ( 'sentinelchickenlabs', $data );
			$rows = $this->db->affected_rows ();
		} else {
			$this->db->insert ( 'sentinelchickenlabs', $data );
			$id = $this->db->insert_id ();
			$rows = $this->db->affected_rows ();
		}
		
		$this->db->query ( "SET foreign_key_checks = 1" );
		
		// $rows = 1;
		if (empty ( $rows ) && empty ( $id ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to delete Sentinel Chicken lab
	 */
	public function deleteSentinelChickenlab() {
		$idlab = $this->input->get_post ( 'id' );
		
		if (empty ( $idlab ))
			return false;
		
		$data ['isdeleted'] = '1';
		$this->db->where ( 'idsentinelchickenlab', $idlab );
		$this->db->update ( 'sentinelchickenlabs', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to import saved CalSurvFlock
	 * Data into Sentinel Chicken Lab Data
	 */
	public function importFlock($rdata) {
		if (empty ( $rdata ))
			return false;
		
		$id = '';
		if (! empty ( $rdata ['bandset'] [0] )) {
			foreach ( $rdata ['bandset'] as $key => $val ) {
				$data = array ();
				$data ['idsentinelchicken'] = ! empty ( $rdata ['idsentinelchicken'] ) ? $rdata ['idsentinelchicken'] : 0;
				$data ['datebled'] = ! empty ( $rdata ['datebled'] ) ? date ( 'Y-m-d', strtotime ( $rdata ['datebled'] ) ) : '';
				$data ['datesubmitted'] = ! empty ( $rdata ['datesubmitted'] ) ? date ( 'Y-m-d', strtotime ( $rdata ['datesubmitted'] ) ) : '';
				$data ['dateresults'] = ! empty ( $rdata ['dateresults'] ) ? date ( 'Y-m-d', strtotime ( $rdata ['dateresults'] ) ) : '';
				$data ['comments'] = ! empty ( $val ['comments'] ) ? $val ['comments'] : '';
				$data ['idlocation'] = $this->session->userdata ( 'idlocation' );
				$data ['idsample'] = ! empty ( $val ['official'] ) ? $val ['official'] : '';
				
				$this->db->query ( "SET foreign_key_checks = 0" );
				$this->db->insert ( 'sentinelchickenlabs', $data );
				$this->db->query ( "SET foreign_key_checks = 1" );
				$id = $this->db->insert_id ();
			}
		}
		
		// print'<pre>';
		// print_R($rdata);
		// die;
		
		if ($id)
			return true;
		return false;
	}
	
	/**
	 * Function to Get Lati Longi
	 * for displaying on Maps
	 */
	public function getMapdata() {
		$page_size = $this->input->get ( 'page_size' );
		$page = $this->input->get ( 'page' );
		$labresult = $this->input->get ( 'labresult' );
        $filter_date = $this->input->get ( 'filter_date' );
		$setfromdate = $this->input->get ( 'setfromdate' );
		$settodate = $this->input->get ( 'settodate' );
		
        $offset = 0;
        $page_size = ($page_size == 'all') ? 'all' : (is_numeric($page_size) ? $page_size : 10);
        $limit = (is_numeric($page_size)) ? $page_size : NULL;        
        $offset = $limit * ($page - 1);
        
        if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 2;

		$this->db->select ( 'scl.*,
				st.latitude,
				st.longitude,
				l.GoogleZoom' );
		$this->db->from ( 'sentinelchickenlabs AS scl' );
		$this->db->join ( 'sentinelchicken AS st', 'scl.idsentinelchicken = st.idsentinelchicken', 'LEFT' );
		$this->db->join ( 'labresults', 'scl.idlabresult = labresults.idlabresult', 'LEFT' );
		$this->db->join ( 'virustypes', 'scl.idvirustype = virustypes.idvirustype', 'LEFT' );
		$this->db->join ( 'sites AS s', 'st.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'locations AS l', 's.idlocation = l.idlocation', 'LEFT' );
		// $this->db->join('sentinelchickensamples AS scs','scl.idsentinelchicken = scs.idsentinelchicken','LEFT');
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'scl.isdeleted', '0' );
		if (! is_null ( $filter_date ) && empty ( $setfromdate ) && empty ( $settodate )) {
			switch ($filter_date) {
				case '1' : 
					$this->db->where ( 'scl.datebled' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'scl.datebled' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'scl.datebled' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'scl.datebled' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'scl.datebled' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'scl.datebled' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'scl.datebled' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'scl.datebled' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'scl.datebled' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'scl.datebled' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		} else if (! empty ( $setfromdate ) && ! empty ( $settodate )) {
			$this->db->where ( 'scl.datebled' . ' >=', $setfromdate );
			$this->db->where ( 'scl.datebled' . ' <=', $settodate );
		}
		
		if (! empty ( $labresult )) {
			switch ($labresult) {
				case '1' :
					$this->db->where ( 'scl.idlabresult', '2' );
					break;
				
				case '2' :
					$this->db->where ( 'scl.idlabresult', '-1' );
					break;
				case '3' :
					$this->db->where ( 'scl.idlabresult', '1' );
					break;
			}
		}
		$this->db->order_by ( 'scl.datebled', 'desc' );
		$this->db->limit ( $limit, $offset );
		// $this->db->group_by("`ad`.`idlab`");
		
		$data_1 = array ();
		$query = $this->db->get ();
		$result = array ();
		// echo $this->db->last_query();
		// die;
		if ($query->num_rows () > 0)
			return $query->result_array ();
	}
	/**
	 * Function to list particular Sentinel Chicken Lab
	 */
	public function getSentinelChickenlabData($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( '*' );
		$this->db->from ( 'sentinelchickenlabs' );
		$this->db->where ( 'idsentinelchickenlab', $Id );
		
		$query = $this->db->get ();
		
		$data = array ();
		if ($query->num_rows () > 0) {
			$data = $query->result_array ();
			return $data [0];
		}
		
		return false;
	}
	
	/**
	 * Function to fetch History for Sentinel Chicken Lab
	 */
	public function getHistory($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( 'sl.idsample' );
		$this->db->from ( 'sentinelchickenlabs AS sl' );
		$this->db->where ( 'idsentinelchickenlab', $Id );
		$query = $this->db->get ();
		// echo $this->db->last_query();
		$idsample = '';
		if ($query->num_rows () > 0) {
			$idsample = $query->result_array ();
			$idsample = $idsample [0] ['idsample'];
		}
		
		if (empty ( $idsample ))
			return false;
		
		$this->db->select ( 'sl.* , 
				s.flockname , 
				l.labresult , 
				v.virustypes' );
		$this->db->from ( 'sentinelchickenlabs AS sl' );
		$this->db->join ( 'sentinelchicken AS s', 'sl.idsentinelchicken = s.idsentinelchicken', 'LEFT' );
		$this->db->join ( 'labresults AS l', 'sl.idlabresult = l.idlabresult', 'LEFT' );
		$this->db->join ( 'virustypes AS v', 'sl.idvirustype = v.idvirustype', 'LEFT' );
		
		$this->db->where ( 'idsample', $idsample );
		
		// $this->db->where('s.idsentinelchicken','sl.idsentinelchicken');
		// $this->db->group_by('s.idsentinelchicken');
		$query = $this->db->get ();
		// echo $this->db->last_query();
		$data = array ();
		if ($query->num_rows () > 0) {
			$data = $query->result_array ();
			return $data;
		}
		
		return false;
	}
	
	/**
	 * Function to list all Corvidlabs mail
	 */
	public function listSentinelChickenlabs($Ids = "", $mapSite = "", $mapFlag = "") {
		$this->db->select ( 'scl.idsentinelchickenlab,
                scl.idsample,
				sc.flockname, 
				scs.bandid, 
				scl.datebled, 
				scl.datesubmitted, 
				scl.dateresults, 
				lr.labresult, 
				v.virustypes' );
		$this->db->from ( 'sentinelchickenlabs AS scl' );
		$this->db->join ( 'sentinelchicken AS sc', 'scl.idsentinelchicken = sc.idsentinelchicken', 'LEFT' );
		$this->db->join ( 'sentinelchickensamples AS scs', 'scl.idsample = scs.idscs', 'LEFT' );
		$this->db->join ( 'labresults AS lr', 'scl.idlabresult = lr.idlabresult', 'LEFT' );
		$this->db->join ( 'virustypes AS v', 'scl.idvirustype = v.idvirustype', 'LEFT' );
		$this->db->join ( 'sites AS s', 'sc.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'locations AS l', 's.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'scl.isdeleted', '0' );
		
		$filter_date = $this->input->get ( 'filter_date' );
		$page_size = $this->input->get ( 'ttl' );
		$page = $this->input->get ( 'page' );
		$frmdate = $this->input->get ( 'frmdate' );
		$todate = $this->input->get ( 'todate' );
		$orderby = $this->input->get ( 'orderby' );
		$filter_by_lab = $this->input->get ( 'lab' );
		
		if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 2;
		
        $offset = 0;
        $page_size = ($page_size == 'all') ? 'all' : (is_numeric($page_size) ? $page_size : 10);
        $limit = (is_numeric($page_size)) ? $page_size : NULL;        
        $offset = $limit * ($page - 1);
		
        if(!empty($mapSite)){
            $this->db->where ( 's.idsite', $mapSite );
		}
        
        if(!empty($mapSite) || !empty($mapFlag)){
            $filter_date = "";
            $filter_daterange = "";
            $frmdate = "";
            $todate = "";
            $filter_by_lab = "";
            $orderby = "";
            $ttl = "";
            $page = "";
		}
        
		if (! empty ( $frmdate ) && ! empty ( $todate )) {
			$frmdate = substr ( $frmdate, 0, 2 ) . '/' . substr ( $frmdate, 2, 2 ) . '/' . substr ( $frmdate, 4, 4 );
			$todate = substr ( $todate, 0, 2 ) . '/' . substr ( $todate, 2, 2 ) . '/' . substr ( $todate, 4, 4 );
			$this->db->where ( 'scl.dateresults' . ' >=', date ( 'Y-m-d', strtotime ( $frmdate ) ) );
			$this->db->where ( 'scl.dateresults' . ' <=', date ( 'Y-m-d', strtotime ( $todate ) ) );
		} else if (! is_null ( $filter_date )) {
			switch ($filter_date) {
				// date('H:i:s',strtotime('-1 day');
				case '1' :
					$this->db->where ( 'scl.dateresults' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'scl.dateresults' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'scl.dateresults' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'scl.dateresults' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'scl.dateresults' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'scl.dateresults' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'scl.dateresults' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'scl.dateresults' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'scl.dateresults' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'scl.dateresults' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		}
		/*
		 * if(!is_null($ttl) && !is_null($page))
		 * {
		 * if($page == 1)
		 * $page = 0;
		 * else
		 * $page--;
		 *
		 * $page *= 10;
		 * $this->db->limit($ttl ,$page);
		 * }
		 * else if(!is_null($ttl))
		 * {
		 * $this->db->limit($ttl);
		 * }
		 * $this->db->order_by('scl.dateresults' , "DESC");
		 */
		
		if (! empty ( $filter_by_lab )) {
			switch ($filter_by_lab) {
				case '1' :
					$this->db->where ( 'lr.idlabresult', '2' );
					break;
				case '2' :
					$this->db->where ( 'lr.idlabresult', '-1' );
					break;
				case '3' :
					$this->db->where ( 'lr.idlabresult', '1' );
					break;
			}
		}
		
		if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
			switch ($orderby) {
				case '0:asc' :
					$this->db->order_by ( 'sc.flockname', 'ASC' );
					break;
				case '0:desc' :
					$this->db->order_by ( 'sc.flockname', 'DESC' );
					break;
				case '1:asc' :
					$this->db->order_by ( 'scs.bandid', 'ASC' );
					break;
				case '1:desc' :
					$this->db->order_by ( 'scs.bandid', 'DESC' );
					break;
				case '2:asc' :
					$this->db->order_by ( "scl.datebled", 'ASC' );
					break;
				case '2:desc' :
					$this->db->order_by ( "scl.datebled", 'DESC' );
					break;
				case '3:asc' :
					$this->db->order_by ( 'scl.datesubmitted', 'ASC' );
					break;
				case '3:desc' :
					$this->db->order_by ( 'scl.datesubmitted', 'DESC' );
					break;
				case '4:asc' :
					$this->db->order_by ( "scl.dateresults", 'ASC' );
					break;
				case '4:desc' :
					$this->db->order_by ( "scl.dateresults", 'DESC' );
					break;
				case '5:asc' :
					$this->db->order_by ( "lr.labresult", 'ASC' );
					break;
				case '5:desc' :
					$this->db->order_by ( "lr.labresult", 'DESC' );
					break;
				case '6:asc' :
					$this->db->order_by ( "v.virustypes", 'ASC' );
					break;
				case '6:desc' :
					$this->db->order_by ( "v.virustypes", 'DESC' );
					break;
			}
		} else {
			$this->db->order_by ( 'scl.dateresults', 'DESC' );
		}
		
        if(!empty($Ids)) {
            $this->db->where_in ( 'sc.idsentinelchickenlab', $Ids );
        }
        
		$data_1 = array ();
		$query = $this->db->get ();
		// echo $this->db->last_query();
		// die;
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
		
		return false;
	}
	
	/**
	 * Function to fetch the list of Flocks
	 */
	public function getFlocks($id = '') {
		$this->db->select ( 'idsentinelchicken,
				flockname' );
		$this->db->from ( 'sentinelchicken AS sc' );
		$this->db->join ( 'sites AS s', 'sc.idsite = s.idsite', 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->order_by ( "flockname", "ASC" );
				$result = array ();
				$query = $this->db->get ();
				
				if ($query->num_rows () > 0) {
					$i = 0;
					foreach ( $query->result_array () as $row ) {
						$result [$i] ['idsentinelchicken'] = $row ['idsentinelchicken'];
						$result [$i] ['flockname'] = $row ['flockname'];
						$i ++;
					}
				}
				return $result;
	}
	
	/**
	 * Function to to Display the Export Button
	 * for CA state
	 */
	public function showExportBttn() {
		$this->db->select ( '*' );
		$this->db->from ( 'states AS st' );
		$this->db->join ( 'locations AS l', 'st.idstate = l.idstate', 'INNER' );
		$this->db->where ( 'l.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'st.stateabbrev', 'CA' );
		
		$query = $this->db->get ();
		if ($query->num_rows () > 0) {
			return true;
		}
		return false;
	}
	
	/**
	 * Function to fetch the list of Samples
	 */
	public function getSamples($idsentinel = '', $id = '') {
		if (empty ( $idsentinel ))
			return false;
		
		$this->db->select ( 'idscs,
				bandid' );
		$this->db->from ( 'sentinelchickensamples' );
		$this->db->where ( 'idsentinelchicken', $idsentinel );
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idscs'] = $row ['idscs'];
				$result [$i] ['bandid'] = $row ['bandid'];
				$i ++;
			}
		}
		return $result;
	}
    
    /**
	 * Function to get site id based on sentinellab id
	 */
	public function getIdSite($id = '') {
		if (empty ( $id ))
			return false;
		
		$this->db->select ( '`sentinelchicken`.`idsite`' );
		$this->db->from ( 'sentinelchickenlabs' );
        $this->db->join ( 'sentinelchicken', 'sentinelchickenlabs.idsentinelchicken = sentinelchicken.idsentinelchicken', 'INNER' );
		$this->db->where ( '`sentinelchickenlabs`.`idsentinelchickenlab`', $id );
		$this->db->where ( 'sentinelchickenlabs.isdeleted', '0' );
		
		$query = $this->db->get ();
		
		$data = array ();
		if ($query->num_rows () > 0) {
			return $query->row()->idsite;
		}
		
		return false;
	}
}
