<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Pesticideusage_report_model extends CI_Model {
	public $data = "";
	public $trap_name = "";
	public $trap_count = "";
	public $temparr = array ();
	/**
	 * Constructor for the class r
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	public function getPesticideusage($startdate = '', $enddate = '', $zone = '') {
		// echo $startdate." ".$enddate." ".$zone." ".$site." ".$species." ".$traptypes." ".$techs."<br>";
		// echo "thr".$species;
		// die;
		$startdate_arr = explode ( "/", $startdate );
		$startdate = $startdate_arr [2] . "-" . $startdate_arr [0] . "-" . $startdate_arr [1];
		
		$enddate_arr = explode ( "/", $enddate );
		$enddate = $enddate_arr [2] . "-" . $enddate_arr [0] . "-" . $enddate_arr [1];
		
		$totalapps = 0;
		
		$data_2 = array ();
		$this->db->select ( 'p.idmanufacturer, 
				pm.manufacturer, 
				p.productname, 
				pu.unitproduct ,
				pu.unitproductabbrev,
				p.eparegistration, 
				FORMAT(SUM(at.totalproductapplied), 2) AS totalproductapplied, 
				DATE_FORMAT(at.date, \'%M %Y\') AS month_yearofuse, 
				SUM(at.totalareatreated) AS totalareatreated, 
				f.wetdry, 
				at.iduomtotalproductapplied, 
				count(at.idadulticidetreatment) as applicant_count, 
				s.idzone, 
				at.idsite, 
				z.operatorid, 
				z.licensenumber, 
				z.county, 
				z.countynumber, 
				l.location, 
				l.address1, 
				l.address2, 
				l.city, 
				l.postalcode, 
				l.officephone' );
		$this->db->from ( 'adulticidetreatments AS at' );
		$this->db->join ( 'sites AS s', 's.idsite = at.idsite', 'LEFT' );
		$this->db->join ( 'zones AS z', 'z.idzone = s.idzone', 'LEFT' );
		$this->db->join ( 'products AS p', 'at.idproduct = p.idproduct', 'LEFT' );
		$this->db->join ( 'productunit AS pu', 'at.iduomtotalproductapplied = pu.idproductunit', 'LEFT' );
		$this->db->join ( 'productmanufacturers AS pm', 'pm.idmanufacturer = p.idmanufacturer', 'LEFT' );
		$this->db->join ( 'formulations AS f', 'p.idformulation = f.idformulation', 'LEFT' );
		$this->db->join ( 'locations AS l', 'at.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( "at.date BETWEEN '" . $startdate . "' AND '" . $enddate . "'" );
		$this->db->where ( 'at.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'at.isdeleted', '0' );
		$this->db->group_by ( "at.idproduct" );
		$this->db->group_by ( "at.iduomtotalproductapplied" );
		$this->db->group_by ( "z.idzone" );
		// $this->db->order_by("pm.manufacturer" , "ASC");
		$this->db->order_by ( "p.productname", "ASC" );
		
		if (! empty ( $zone )) {
			$s_zone = "";
			
			if ($zone [0] != "on" && $zone [0] != "") {
				foreach ( $zone as $k_z => $v_z ) {
					$s_zone .= "'" . $v_z . "',";
				}
				
				$s_zone = trim ( $s_zone, "," );
				$cond = " z.idzone IN (" . $s_zone . ")";
				$this->db->where ( $cond );
			}
		}
		
		$query = $this->db->get ();
		// echo $this->db->last_query()."<br>";
		$i = 0;
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				// array_push($data_2,$row);
				if (! empty ( $row ['idzone'] )) {
					// $totalapps += $row['applicant_count'];
					$data_2 [$row ['idzone']] [$i] = $row;
					$i ++;
				}
			}
		}
		
		// print'<pre>';
		// print_R($data_2);
		// die;
		
		$data_3 = array ();
		$this->db->select ( 'p.idmanufacturer, 
        		pm.manufacturer, 
        		p.productname,  
        		pu.unitproduct,
        		pu.unitproductabbrev,
        		p.eparegistration, 
        		FORMAT(SUM(lt.totalproductapplied), 2) AS totalproductapplied, 
        		DATE_FORMAT(lt.date, \'%M %Y\') AS month_yearofuse, 
        		SUM(lt.totalareatreated) AS totalareatreated, 
        		f.wetdry, 
        		lt.iduomtotalproductapplied, 
        		count(lt.idlarvaltreatment) as applicant_count, 
        		s.idzone, 
        		z.operatorid, 
				z.licensenumber, 
				z.county, 
				z.countynumber, 
        		l.location, 
        		l.address1, 
        		l.address2, 
        		l.city, 
        		l.postalcode, 
        		l.officephone' );
		$this->db->from ( 'larvaltreatments as lt' );
		$this->db->join ( 'sites AS s', 's.idsite = lt.idsite', 'LEFT' );
		$this->db->join ( 'zones AS z', 'z.idzone = s.idzone', 'LEFT' );
		$this->db->join ( 'products AS p', 'lt.idproduct = p.idproduct', 'LEFT' );
		$this->db->join ( 'productunit AS pu', 'lt.iduomtotalproductapplied = pu.idproductunit', 'LEFT' );
		$this->db->join ( 'productmanufacturers AS pm', 'pm.idmanufacturer = p.idmanufacturer', 'LEFT' );
		$this->db->join ( 'formulations AS f', 'p.idformulation = f.idformulation', 'LEFT' );
		$this->db->join ( 'locations AS l', 'lt.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( "lt.date BETWEEN '" . $startdate . "' AND '" . $enddate . "'" );
		$this->db->where ( 'lt.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'lt.isdeleted', '0' );
		$this->db->group_by ( "lt.idproduct" );
		$this->db->group_by ( "lt.iduomtotalproductapplied" );
		$this->db->group_by ( "z.idzone" );
		// $this->db->order_by("pm.manufacturer" , "ASC");
		$this->db->order_by ( "p.productname", "ASC" );
		
		if (! empty ( $zone )) {
			$s_zone = "";
			
			if ($zone [0] != "on" && $zone [0] != "") {
				foreach ( $zone as $k_z => $v_z ) {
					$s_zone .= "'" . $v_z . "',";
				}
				
				$s_zone = trim ( $s_zone, "," );
				$cond = " z.idzone IN (" . $s_zone . ")";
				$this->db->where ( $cond );
			}
		}
		
		$query = $this->db->get ();
		// echo $this->db->last_query()."<br>";
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				// array_push($data_3,$row);
				if (! empty ( $row ['idzone'] )) {
					// $totalapps += $row['applicant_count'];
					$data_2 [$row ['idzone']] [$i] = $row;
					$i ++;
				}
			}
		}
		// print'<pre>';
		// print_R($data_2);
		// die;
		// $union = array_merge($data_2, $data_3);
		
		$treatmentData = array ();
		$i = 0;
		if (! empty ( $data_2 )) {
			foreach ( $data_2 as $kd => $vd ) {
				$j = 0;
				$treatmentData [$i] ['totalapps'] = 0;
				foreach ( $vd as $key => $val ) {
					$treatmentData [$i] ['idzone'] = $val ['idzone'];
					$treatmentData [$i] ['operatorid'] = $val ['operatorid'];
					$treatmentData [$i] ['licensenumber'] = $val ['licensenumber'];
					$treatmentData [$i] ['county'] = $val ['county'];
					$treatmentData [$i] ['countynumber'] = $val ['countynumber'];
					$treatmentData [$i] ['month_yearofuse'] = $val ['month_yearofuse'];
					$treatmentData [$i] ['location'] = $val ['location'];
					$treatmentData [$i] ['address1'] = $val ['address1'];
					$treatmentData [$i] ['address2'] = $val ['address2'];
					$treatmentData [$i] ['city'] = $val ['city'];
					$treatmentData [$i] ['postalcode'] = $val ['postalcode'];
					$treatmentData [$i] ['officephone'] = $val ['officephone'];
					$treatmentData [$i] ['totalapps'] += $val ['applicant_count'];
					$treatmentData [$i] ['treatmentData'] [$j] ['idmanufacturer'] = $val ['idmanufacturer'];
					$treatmentData [$i] ['treatmentData'] [$j] ['manufacturer'] = $val ['manufacturer'];
					$treatmentData [$i] ['treatmentData'] [$j] ['productname'] = $val ['productname'];
					$treatmentData [$i] ['treatmentData'] [$j] ['unitproduct'] = $val ['unitproduct'];
					$treatmentData [$i] ['treatmentData'] [$j] ['unitproductabbrev'] = $val ['unitproductabbrev'];
					$treatmentData [$i] ['treatmentData'] [$j] ['eparegistration'] = $val ['eparegistration'];
					$treatmentData [$i] ['treatmentData'] [$j] ['totalproductapplied'] = $val ['totalproductapplied'];
					$treatmentData [$i] ['treatmentData'] [$j] ['totalareatreated'] = $val ['totalareatreated'];
					$treatmentData [$i] ['treatmentData'] [$j] ['wetdry'] = $val ['wetdry'];
					$treatmentData [$i] ['treatmentData'] [$j] ['iduomtotalproductapplied'] = $val ['iduomtotalproductapplied'];
					$treatmentData [$i] ['treatmentData'] [$j] ['applicant_count'] = $val ['applicant_count'];
					$treatmentData [$i] ['treatmentData'] [$j] ['iduomtotalproductapplied'] = $val ['iduomtotalproductapplied'];
					$j ++;
				}
				$i ++;
			}
		}
		
		// echo"<pre>";
		// print_r($treatmentData);
		// die;
		$data = array (
				'atvalues' => $treatmentData 
		)
		// 'totalapps' => $totalapps
		;
		
		return $data;
	}
}
