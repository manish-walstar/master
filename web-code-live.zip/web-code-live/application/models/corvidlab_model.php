<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Corvidlab_model extends CI_Model {
	public $str = "";
	public $map = "";
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to Add a new Corvid Lab if no id is supplied
	 * On passing Id the function updates the Table
	 */
	public function addCorvidlab($id = '') {
		$site_id = '';
		$idloc = $this->session->userdata ( 'idlocation' );
		$site_id = $this->input->post ( 'idsite' );
		$idsitetype = $this->input->post ( 'idsitetype' );
		$idstate = $this->input->post ( 'idstate' );
		$idzone = $this->input->post ( 'idzone' );
		$idavianspecies = $this->input->post ( 'avian_species' );
		
		$data_site ['site'] = $this->input->post ( 'site' );
		$data_site ['idsitetype'] = ! empty ( $idsitetype ) ? $idsitetype : 0;
		$data_site ['maplabel'] = $this->input->post ( 'maplabel' );
		$data_site ['address1'] = $this->input->post ( 'address1' );
		$data_site ['address2'] = $this->input->post ( 'address2' );
		$data_site ['city'] = $this->input->post ( 'city' );
		$data_site ['idstate'] = ! empty ( $idstate ) ? $idstate : 0;
		$data_site ['postalcode'] = $this->input->post ( 'postalcode' );
		$data_site ['latitude'] = $this->input->post ( 'latitude' );
		$data_site ['longitude'] = $this->input->post ( 'longitude' );
		$data_site ['pdop'] = $this->input->post ( 'pdop' );
		// if add new site value is -1
		if ($site_id == '0') {
			$this->db->query ( "SET foreign_key_checks = 0" );
			$this->db->insert ( 'sites', $data_site );
			$row_site = $this->db->affected_rows ();
			
			$site_id = $this->db->insert_id ();
			$this->db->query ( "SET foreign_key_checks = 1" );
			
			if (! empty ( $site_id )) {
				$data_1 ['idsite'] = $site_id;
				$data_1 ['idzone'] = ! empty ( $idzone ) ? $idzone : 0;
				$this->db->insert ( 'sitezoneassignment', $data_1 );
			}
		}
		// echo $site_id." ".$idsitetype." ".$idstate." ".$idzone." ".$idavianspecies;
		
		$assay_type = $this->input->post ( 'assay_type' );
		$lab_result = $this->input->post ( 'lab_result' );
		$detected_virus = $this->input->post ( 'detected_virus' );
		$rampunits = $this->input->post ( 'rampunits' );
		$rtprcconfirm = $this->input->post ( 'confirm' );
		$resultscorresspond = $this->input->post ( 'result' );
		// echo $assay_type." ".$lab_result." ".$detected_virus." ".$rampunits;
		$datecollected = $this->input->post ( 'datecollected' );
		
		$this->load->model('usermodel');
		$data ['userId'] = $this->usermodel->getUserId();

		$data ['datecollected'] = ! empty ( $datecollected ) ? date ( 'Y-m-d', strtotime ( $datecollected ) ) : '';
		$data ['idsite'] = ! empty ( $site_id ) ? $site_id : 0;
		$data ['idsitetype'] = ! empty ( $idsitetype ) ? $idsitetype : 0;
		$data ['idzone'] = ! empty ( $idzone ) ? $idzone : 0;
		
		$data ['maplabel'] = $this->input->post ( 'maplabel' );
		$data ['latitude'] = $this->input->post ( 'latitude' );
		$data ['longitude'] = $this->input->post ( 'longitude' );
		$data ['pdop'] = $this->input->post ( 'pdop' );
		$data ['collectedbyfirst'] = $this->input->post ( 'collectedby_first' );
		$data ['collectedbylast'] = $this->input->post ( 'collectedby_last' );
		$data ['idavianspecies'] = ! empty ( $idavianspecies ) ? $idavianspecies : 0;
		$data ['idassaytype'] = ! empty ( $assay_type ) ? $assay_type : 0;
		$data ['idlabresult'] = ! empty ( $lab_result ) ? $lab_result : 0;
		$data ['comments'] = $this->input->post ( 'comment' );
		$data ['idvirustype'] = ! empty ( $detected_virus ) ? $detected_virus : 0;
		$data ['rampunits'] = ! empty ( $rampunits ) ? $rampunits : '';
		
		$data ['rtprcconfirm'] = ! empty ( $rtprcconfirm ) ? '1' : '0';
		$data ['resultscorresspond'] = ! empty ( $resultscorresspond ) ? '1' : '0';
		$data ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
		// echo $data['collectedbyfirst']." ".$data['collectedbylast'] ;
		// die;
		$this->db->query ( "SET foreign_key_checks = 0" );
		
		if (! empty ( $id )) {
			$this->db->where ( 'idcorvidlab', $id );
			$this->db->update ( 'corvidlabs', $data );
			$rows = $this->db->affected_rows ();
		} else {
			$this->db->insert ( 'corvidlabs', $data );
			$id = $this->db->insert_id ();
			$rows = $this->db->affected_rows ();
		}
		
		$this->db->query ( "SET foreign_key_checks = 1" );
		
		// $rows = 1;
		if (empty ( $rows ) && empty ( $id ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to delete Corvid lab
	 */
	public function deleteCorvidlab() {
		$idlab = $this->input->get_post ( 'id' );
		
		if (empty ( $idlab ))
			return false;
		
		$data ['isdeleted'] = '1';
		$this->db->where ( 'idcorvidlab', $idlab );
		$this->db->update ( 'corvidlabs', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to Get Lati Longi
	 * for displaying on Maps
	 */
	public function getMapdata() {
		$page_size = $this->input->get ( 'page_size' );
		$page = $this->input->get ( 'page' );
		$filter_date = $this->input->get ( 'filter_date' );
		$labresult = $this->input->get ( 'labresult' );
		$setfromdate = $this->input->get ( 'setfromdate' );
		$settodate = $this->input->get ( 'settodate' );
		
        $offset = 0;
        $page_size = ($page_size == 'all') ? 'all' : (is_numeric($page_size) ? $page_size : 10);
        $limit = (is_numeric($page_size)) ? $page_size : NULL;        
        $offset = $limit * ($page - 1);
        
        if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 2;

		$this->db->select ( 'c.*,
				lr.labresult as result,
				avs.*,
				z.zone,
				l.GoogleZoom' );
		$this->db->from ( 'corvidlabs AS c' );
		$this->db->join ( 'sites', 'c.idsite = sites.idsite', 'LEFT' );
		$this->db->join ( 'zones AS z', 'sites.idzone = z.idzone', 'LEFT' );
		$this->db->join ( 'states', 'sites.idstate = states.idstate', 'LEFT' );
		$this->db->join ( 'avianspecies AS avs', 'c.idavianspecies = avs.idavianspecies', 'LEFT' );
		$this->db->join ( 'assaytypes', 'c.idassaytype = assaytypes.idassaytype', 'LEFT' );
		$this->db->join ( 'labresults AS lr', 'c.idlabresult = lr.idlabresult', 'LEFT' );
		$this->db->join ( 'locations AS l', 'sites.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( 'c.isdeleted', '0' );
		$this->db->where ( 'c.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		if (! is_null ( $filter_date ) && empty ( $setfromdate ) && empty ( $settodate )) {
			switch ($filter_date) {
				case '1' :
					$this->db->where ( 'c.datecollected' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'c.datecollected' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'c.datecollected' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'c.datecollected' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'c.datecollected' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'c.datecollected' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'c.datecollected' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'c.datecollected' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'c.datecollected' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'c.datecollected' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		} else if (! empty ( $setfromdate ) && ! empty ( $settodate )) {
			$this->db->where ( 'c.datecollected' . ' >=', $setfromdate );
			$this->db->where ( 'c.datecollected' . ' <=', $settodate );
		}
		
		if (! empty ( $labresult )) {
			switch ($labresult) { 
				case '1' :
					$this->db->where ( 'c.idlabresult', '2' );
					break;
				
				case '2' :
					$this->db->where ( 'c.idlabresult', '-1' );
					break;
				case '3' :
					$this->db->where ( 'c.idlabresult', '1' );
					break;
			}
		}
		$this->db->order_by ( 'c.datecollected', 'desc' );
		$this->db->limit ( $limit, $offset );
		// $this->db->group_by("`ad`.`idlab`");
		
		$data_1 = array ();
		$query = $this->db->get ();
		// echo $this->db->last_query();
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
	}
	/**
	 * Function to list all Corvidlabs mail
	 */
	public function getCorvidlabData($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( '*' );
		$this->db->from ( 'corvidlabs' );
		$this->db->where ( 'idcorvidlab', $Id );
		
		$query = $this->db->get ();
		
		$data = array ();
		if ($query->num_rows () > 0) {
			$data = $query->result_array ();
			return $data [0];
		}
		
		return false;
	}
	
	/**
	 * Function to list all Corvidlabs mail
	 */
	public function listCorvidlabs($Ids = "", $mapSite = "", $mapFlag = "") {
		$this->db->select ( "corvidlabs.idcorvidlab, 
				corvidlabs.datecollected, 
				s.site , 
				s.address1, 
				s.address2, 
				s.city , 
				st.statename, 
				corvidlabs.collectedbyfirst , 
				corvidlabs.collectedbylast, 
				avs.avianspecies , 
				a.assaytype , 
				lr.labresult,
                CONCAT(corvidlabs.collectedbyfirst,' ',corvidlabs.collectedbylast) AS collectedby,
                CONCAT(s.address1,' ',s.address2,' ',s.city,' ',st.statename) AS addrs" );
		$this->db->from ( 'corvidlabs' );
		$this->db->join ( 'sites AS s', 'corvidlabs.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'states AS st', 's.idstate = st.idstate', 'LEFT' );
		$this->db->join ( 'assaytypes AS a', 'corvidlabs.idassaytype = a.idassaytype', 'LEFT' );
		$this->db->join ( 'avianspecies AS avs', 'corvidlabs.idavianspecies = avs.idavianspecies', 'LEFT' );
		$this->db->join ( 'labresults AS lr', 'corvidlabs.idlabresult = lr.idlabresult', 'LEFT' );
		$this->db->join ( 'locations AS l', 's.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( 'corvidlabs.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'corvidlabs.isdeleted', '0' );
		
		$filter_date = $this->input->get ( 'filter_date' );
		$ttl = $this->input->get ( 'ttl' );
		$page = $this->input->get ( 'page' );
		$frmdate = $this->input->get ( 'frmdate' );
		$todate = $this->input->get ( 'todate' );
		$orderby = $this->input->get ( 'orderby' );
		$filter_by_lab = $this->input->get ( 'lab' );
		
        if(!empty($mapSite)){
            $this->db->where ( 's.idsite', $mapSite );
		}
        
        if(!empty($mapSite) || !empty($mapFlag)){
            $filter_date = "";
            $filter_daterange = "";
            $frmdate = "";
            $todate = "";
            $filter_by_lab = "";
            $orderby = "";
            $ttl = "";
            $page = "";
		}
        
		if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 2;
		
		if (! isset ( $ttl ) || $ttl == '')
			$ttl = 10;
		
		if (! isset ( $page ) || $page == '')
			$page = 1;
		
		if (! empty ( $frmdate ) && ! empty ( $todate )) {
			$frmdate = substr ( $frmdate, 0, 2 ) . '/' . substr ( $frmdate, 2, 2 ) . '/' . substr ( $frmdate, 4, 4 );
			$todate = substr ( $todate, 0, 2 ) . '/' . substr ( $todate, 2, 2 ) . '/' . substr ( $todate, 4, 4 );
			$this->db->where ( 'corvidlabs.datecollected' . ' >=', date ( 'Y-m-d', strtotime ( $frmdate ) ) );
			$this->db->where ( 'corvidlabs.datecollected' . ' <=', date ( 'Y-m-d', strtotime ( $todate ) ) );
		} else if (! is_null ( $filter_date )) {
			switch ($filter_date) {
				// date('H:i:s',strtotime('-1 day');
				case '1' :
					$this->db->where ( 'corvidlabs.datecollected' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'corvidlabs.datecollected' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'corvidlabs.datecollected' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'corvidlabs.datecollected' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'corvidlabs.datecollected' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'corvidlabs.datecollected' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'corvidlabs.datecollected' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'corvidlabs.datecollected' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'corvidlabs.datecollected' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'corvidlabs.datecollected' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		}
		
		if (! empty ( $filter_by_lab )) {
			switch ($filter_by_lab) {
				case '1' :
					$this->db->where ( 'lr.idlabresult', '2' );
					break;
				case '2' :
					$this->db->where ( 'lr.idlabresult', '-1' );
					break;
				case '3' :
					$this->db->where ( 'lr.idlabresult', '1' );
					break;
			}
		}
		
		if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
			switch ($orderby) {
				case '0:asc' :
					$this->db->order_by ( 'corvidlabs.idcorvidlab', 'ASC' );
					break;
				case '0:desc' :
					$this->db->order_by ( 'corvidlabs.idcorvidlab', 'DESC' );
					break;
				case '1:asc' :
					$this->db->order_by ( 'corvidlabs.datecollected', 'ASC' );
					break;
				case '1:desc' :
					$this->db->order_by ( 'corvidlabs.datecollected', 'DESC' );
					break;
				case '2:asc' :
					$this->db->order_by ( "s.site", 'ASC' );
					break;
				case '2:desc' :
					$this->db->order_by ( "s.site", 'DESC' );
					break;
				case '3:asc' :
					$this->db->order_by ( 's.address1', 'ASC' );
					$this->db->order_by ( 's.address2', 'ASC' );
					break;
				case '3:desc' :
					$this->db->order_by ( 's.address1', 'DESC' );
					$this->db->order_by ( 's.address2', 'DESC' );
					break;
				case '4:asc' :
					$this->db->order_by ( "s.city", 'ASC' );
					break;
				case '4:desc' :
					$this->db->order_by ( "s.city", 'DESC' );
					break;
				case '5:asc' :
					$this->db->order_by ( "st.statename", 'ASC' );
					break;
				case '5:desc' :
					$this->db->order_by ( "st.statename", 'DESC' );
					break;
				case '6:asc' :
					$this->db->order_by ( "corvidlabs.collectedbyfirst", 'ASC' );
					break;
				case '6:desc' :
					$this->db->order_by ( "corvidlabs.collectedbylast", 'DESC' );
					break;
				case '7:asc' :
					$this->db->order_by ( "avs.avianspecies", 'ASC' );
					break;
				case '7:desc' :
					$this->db->order_by ( "avs.avianspecies", 'DESC' );
					break;
				case '8:asc' :
					$this->db->order_by ( "a.assaytype", 'ASC' );
					break;
				case '8:desc' :
					$this->db->order_by ( "a.assaytype", 'DESC' );
					break;
				case '9:asc' :
					$this->db->order_by ( "lr.labresult", 'ASC' );
					break;
				case '9:desc' :
					$this->db->order_by ( "lr.labresult", 'DESC' );
					break;
			}
		} else {
			$this->db->order_by ( 'corvidlabs.datecollected', 'DESC' );
		}
		/*
		 * if(!is_null($ttl) && !is_null($page))
		 * {
		 * if($page == 1)
		 * $page = 0;
		 * else
		 * $page--;
		 *
		 * $page *= 10;
		 * $this->db->limit($ttl ,$page);
		 * }
		 * else if(!is_null($ttl))
		 * {
		 * $this->db->limit($ttl);
		 * }
		 */
		
		$data_1 = array ();
        if(!empty($Ids)) {
            $this->db->where_in ( 'corvidlabs.idcorvidlab', $Ids );
        }
		$query = $this->db->get ();
		// echo $this->db->last_query()."<br>";
		// die;
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
		
		return false;
	}
	
	/**
	 * Function to fetch the Avian Species
	 */
	public function getAvianSpecies($id = '') {
		$this->db->select ( '*' );
		$this->db->from ( 'avianspecies' );
		
				$result = array ();
				$query = $this->db->get ();
				
				if ($query->num_rows () > 0) {
					$i = 0;
					foreach ( $query->result_array () as $row ) {
						$result [$i] ['idavianspecies'] = $row ['idavianspecies'];
						$result [$i] ['avianspecies'] = $row ['avianspecies'];
						$i ++;
					}
				}
			return $result;
	}
}
