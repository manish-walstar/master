<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Service_requestmodel extends CI_Model {
	public $data = array ();
	public $str = "";
	public $set_pwd = "";
	
	/**
	 * Constructor for the class
	 * User
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to Add a new Service_request
	 */
	public function addService_request($req = '') {
		$encid = $this->session->userdata ( 'id' );
		$encid = explode ( "_", json_encode ( base64_decode ( $encid ) ) );
		$userId = json_decode ( base64_decode ( $encid [0] ) );
		
		$site_id = '';
		$site_id = $this->input->post ( 'idsite' );
		$data_site ['site'] = $this->input->post ( 'sitename' );
		$data_site ['idsitetype'] = $this->input->post ( 'idsitetype' );
		$data_site ['maplabel'] = $this->input->post ( 'maplabel' );
		$data_site ['address1'] = $this->input->post ( 'address1' );
		$data_site ['address2'] = $this->input->post ( 'address2' );
		$data_site ['city'] = $this->input->post ( 'city' );
		$data_site ['idstate'] = $this->input->post ( 'idstate' );
		$data_site ['idlocation'] = $this->session->userdata ( 'idlocation' );
		$data_site ['latitude'] = $this->input->post ( 'latitude' );
		$data_site ['longitude'] = $this->input->post ( 'longitude' );
		$data_site ['pdop'] = $this->input->post ( 'pdop' );
		$data_site ['postalcode'] = $this->input->post ( 'postalcode' );
		if ($site_id == '0') {
			$this->db->query ( "SET foreign_key_checks = 0" );
			$this->db->insert ( 'sites', $data_site );
			$row_site = $this->db->affected_rows ();
			if (empty ( $row_site ))
				return false;
			$site_id = $this->db->insert_id ();
			$this->db->query ( "SET foreign_key_checks = 1" );
		/**
		 * end insert data into sites table*
		 */
		}
		$idsite = $site_id;
		$idsitetype = $this->input->post ( 'idsitetype' );
		$idzone = $this->input->post ( 'idzone' );
		$idstate = $this->input->post ( 'idstate' );
		$idapplicator = $this->input->post ( 'idapplicator' );
		$idusergroup = $this->input->post ( 'idusergroup' );
		$isapproved = $this->input->post ( 'isapproved' );
		$isadverse = $this->input->post ( 'idtrt' );
        $wasource = $this->input->post ( 'wasource' );
        $pastcomments = $this->input->post ( 'pastcomments' );
        $postcomments = $this->input->post ( 'comments' );
		$id = "";
		
		$id = $this->input->post ( 'service_request' );
		
		$data ['opendate'] = date ( 'Y-m-d', strtotime ( $this->input->post ( 'opendate' ) ) );
		$data ['opentime'] = date ( 'h:i:s A', strtotime ( $this->input->post ( 'opentime' ) ) );
		
		if ($this->input->post ( 'closedate' ) == NULL) {
			
			$data ['closedate'] = "NULL";
		} else {
			
			$data ['closedate'] = date ( 'Y-m-d', strtotime ( $this->input->post ( 'closedate' ) ) );
		}
		if ($this->input->post ( 'closetime' ) == NULL) {
			
			$data ['closetime'] = "NULL";
		} else {
			
			$data ['closetime'] = date ( 'h:i:s A', strtotime ( $this->input->post ( 'closetime' ) ) );
		}
		$this->load->model('usermodel');
		$data ['userId'] = $this->usermodel->getUserId();

		$data ['firstname'] = $this->input->post ( 'firstname' );
		$data ['lastname'] = $this->input->post ( 'lastname' );
		$data ['idsite'] = (! empty ( $idsite )) ? $idsite : 0;
		$data ['sitename'] = $this->input->post ( 'sitename' );
		$data ['idsitetype'] = (! empty ( $idsitetype )) ? $idsitetype : 0;
		$data ['idzone'] = (! empty ( $idzone )) ? $idzone : 0;
		$data ['idstate'] = (! empty ( $idstate )) ? $idstate : 0;
		$data ['mainphone'] = $this->input->post ( 'mainphone' );
		$data ['altphone'] = $this->input->post ( 'altphone' );
		$data ['faxphone'] = $this->input->post ( 'faxphone' );
		$data ['description'] = $this->input->post ( 'description' );
		$data ['comments'] = !empty($pastcomments) ? $pastcomments."\n".$postcomments : $postcomments;
		$data ['idlocation'] = $this->session->userdata ( 'idlocation' );
		$data ['idapplicator'] = (! empty ( $idapplicator )) ? $idapplicator : 0;
		$data ['idusergroup'] = (! empty ( $idusergroup )) ? $idusergroup : 0;
		$data ['disp_new'] = $this->input->post ( 'disp_new' );
		$data ['idrequestedby'] = $userId;
		$data ['isadverse'] = ! empty ( $isadverse ) ? $isadverse : '0';
        $data ['wasource'] = !empty($wasource)?$wasource:'';
		// $data['idusergroup']=$this->input->post('disp_new');
		
		$data ['latitude'] = $this->input->post ( 'latitude' );
		$data ['longitude'] = $this->input->post ( 'longitude' );
		$disp_new_val = $this->input->post ( 'disp_new_val' );
		// $disp_new = $this->input->post('disp_new');
		
		if (! empty ( $req ) && $req > 0) {
			$this->db->select ( '*' );
			$this->db->from ( 'servicerequests' );
			$this->db->where ( 'idservicerequest', $req );
			$comments = "";
			$q = $this->db->get ();
			if ($q->num_rows () > 0) {
				$isApproveStat = '';
				foreach ( $q->result_array () as $k => $v ) {
					if ($k == 'isapproved')
						$isApproveStat = $v ['isapproved'];
					
					if ($k == 'comments') {
						$comments = $v ['comments'];
						break;
					}
				}
				if ($isApproveStat == '0' && $isapproved == '1')
					$data ['isapproved'] = ! empty ( $isapproved ) ? '1' : '0';
				
				if (! empty ( $data ['comments'] ))
					$data ['comments'] .= "$" . $comments;
				else if(!empty($comments))
					$data ['comments'] = $comments;
					// print'<pre>';
					// print_r($data);
					// die;
				$this->db->where ( 'idservicerequest', $req );
				$this->db->update ( 'servicerequests', $data );
			}
			
			$id = $req;
		} else {
			$this->db->select ( '*' );
			$this->db->from ( 'servicerequests' );
			$this->db->where ( 'idservicerequest', $id );
			
			$q = $this->db->get ();
			if ($q->num_rows () > 0) {
				$this->db->where ( 'idservicerequest', $id );
				$this->db->update ( 'servicerequests', $data );
			} else {
				// $data['idservicerequest'] = !empty($id)?$id:0;
				$data ['isapproved'] = '2';
				$this->db->insert ( 'servicerequests', $data );
				
				$id = $this->db->insert_id ();
				$req = $id;
			}
		}
		
		$this->db->select ( '*' );
		$this->db->from ( 'servicerequestsdetail' );
		$this->db->where ( 'idservicerequest', $req );
		
		$q = $this->db->get ();
		if ($q->num_rows () > 0) {
			$this->db->where ( 'idservicerequest', $req );
			$this->db->delete ( 'servicerequestsdetail' );
		}
		
		if (! empty ( $disp_new_val )) {
			foreach ( $disp_new_val as $key => $val ) {
				$data_1 ['idservicerequest'] = $req;
				$data_1 ['iddispositions'] = $val;
				
				$this->db->insert ( 'servicerequestsdetail', $data_1 );
			}
		}
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ) && empty ( $id ) && empty ( $req ))
			return false;
		
		return $id;
	}
	
	/**
	 * Function to fetch selected Dispositions
	 */
	public function getInspectors() {
		$this->db->select ( 'u.iduser,
				u.firstname,
				u.middlename,
				u.lastname' );
		$this->db->from ( 'users AS u' );
		$this->db->join ( 'userlocationassignment AS ula', "u.iduser = ula.iduser", 'INNER' );
		$this->db->join ( 'locations AS lc', "ula.idlocation = lc.idlocation", 'INNER' );
		$this->db->where ( 'lc.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'u.is_active', '1' );
		$this->db->order_by ( 'u.firstname' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$middlename = ! empty ( $row ['middlename'] ) ? " " . $row ['middlename'] . " " : " ";
				$this->str .= '<option value="' . $row ['iduser'] . '">' . $row ['firstname'] . $middlename . $row ['lastname'] . '</option>';
			}
		}
		
		return $this->str;
	}
	public function getSelectedDispositions($id = '') {
		if (empty ( $id ))
			return false;
		
		$this->db->select ( 'd.disposition,
				d.iddispositions' );
		$this->db->from ( 'servicerequestsdetail AS srd' );
		$this->db->join ( 'dispositions AS d', 'srd.iddispositions = d.iddispositions', 'LEFT' );
		$this->db->where ( 'srd.idservicerequest', $id );
		$this->db->where ( 'd.state', '1' );
		
		$query = $this->db->get ();
		
		// $query = $this->db->get('data');
		// return $query->result();
		
		// echo $this->db->last_query();
		// die;
		$result = array ();
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['iddispositions'] = $row ['iddispositions'];
				$result [$i] ['disposition'] = $row ['disposition'];
				$i ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to delete Service Request
	 */
	public function deleteService($id = '', $del = '') {
		if (empty ( $id ))
			return null;
		
		$this->db->select ( '*' );
		$this->db->from ( 'servicerequests' );
		$this->db->where ( 'idservicerequest', $id );
		
		$q = $this->db->get ();
		if ($q->num_rows () > 0) {
			// if(!empty($del))
			// {
			$data ['isdeleted'] = '1';
			$this->db->where ( 'idservicerequest', $id );
			$this->db->update ( 'servicerequests', $data );
			// }
			// else
			// {
			// $this->db->where('idservicerequest',$id);
			// $this->db->delete('servicerequests');
			// }
		}
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return $id;
	}
	
	/**
	 * Function to close Service Request
	 */
	public function closeService() {
		$closedate = $this->input->post ( 'closedate' );
		$closetime = $this->input->post ( 'closetime' );
		$req = $this->input->post ( 'arrids' );
		
		$arrids = json_decode ( base64_decode ( $req ) );
		// print'<pre>';
		// print_r($_POST);
		// print_r($arrids);
		// die;
		// $where = "(closedate = '' OR closedate = '0000-00-00' OR closedate IS NULL) AND (closetime = '' OR closetime IS NULL)";
        if(!empty($arrids))
		foreach ( $arrids as $kr => $vr ) {
			$this->db->select ( '*' );
			$this->db->from ( 'servicerequests' );
			$this->db->where ( 'idservicerequest', $vr );
			// $this->db->where($where);
			
			$q = $this->db->get ();
			// echo $this->db->last_query()."<br>";
			if ($q->num_rows () > 0) {
				//if($q->result_array()[0]['isapproved'] == '0' && $this->session->userdata ( 'idlocation' ) == 36 && $this->session->userdata ( 'username' ) == 'collieradmin'){
				if($q->result_array()[0]['isapproved'] == '0' && $this->session->userdata ( 'idlocation' ) == 36){
					$data ['idsite'] = 3009726;
					$data ['isapproved'] = '2';
				}
				
				$data ['closedate'] = date ( 'Y-m-d', strtotime ( $closedate ) );
				$data ['closetime'] = $closetime;
				
				// print '<pre>';
				// print_r($data);
				$this->db->where ( 'idservicerequest', $vr );
				$this->db->update ( 'servicerequests', $data );
				
				// echo $this->db->last_query()."<br>";
			}
		}
		// die;
		return true;
	}
	
	/**
	 * Function to fetch All City
	 */
	public function getAllCity() {
		$this->db->select ( 's.idsite , 
				s.city' );
		$this->db->from ( 'servicerequests AS sr' );
		$this->db->join ( 'sites AS s', 'sr.idsite = s.idsite', 'LEFT' );
		$this->db->where ( 's.active', '1' );
		$this->db->where ( 's.isdeleted', '0' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$data = array ();
		
		$query = $this->db->get ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$data [$row ['idsite']] = $row ['city'];
			}
		}
		
		return $data;
	}
	
	/**
	 * Function to fetch City
	 * selected by User either through dropdown or by typing
	 */
	public function getCityList($char = '') {
		// $this->db->select('DISTINCT(s.city) , s.idsite');
		$this->db->select ( 'DISTINCT(s.city)' );
		$this->db->from ( 'servicerequests AS sr' );
		$this->db->join ( 'sites AS s', 'sr.idsite = s.idsite', 'LEFT' );
		$this->db->where ( 's.active', '1' );
		$this->db->where ( 's.isdeleted', '0' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		if (! empty ( $char ))
			$this->db->like ( 's.city', $char, 'after' );
		
		$arr = array ();
		$query = $this->db->get ();
		// echo $this->db->last_query()."<br>";
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $key => $val ) {
				$arr [] = array (
						'id' => $val ['city'],
						'data' => $val ['city'] 
				);
			}
		}
		return $arr;
	}
	
	/**
	 * Function to list all members mail
	 */
	public function ToExcelAll() {
		$this->db->select ( '*' );
		$this->db->from ( 'users' );
		$this->db->order_by ( 'iduser', 'desc' );
		$getData = $this->db->get ();
		
		if ($getData->num_rows () > 0)
			return $getData->result_array ();
		else
			return null;
	}
	
	/**
	 * Function to list all Service Request
	 */
	public function listServiceRequest($Ids = "", $mapSite = "", $mapFlag = "") {
		$this->db->select ( "servicerequests.idservicerequest AS `idservicerequest`, 
				servicerequests.sitename, 
				servicerequests.opendate AS `opendate`, 
				servicerequests.opentime AS `opentime`, 
				servicerequests.closedate AS `closedate`, 
				servicerequests.closetime AS `closetime` ,
				servicerequests.firstname AS `firstname`, 
				servicerequests.lastname AS `lastname`, 
				sites.address1, 
				sites.address2, 
				sites.city, 
				sites.site AS `sitename`,
				states.statename, 
				sites.city AS `sites_city`, 
				usr.firstname AS applctrFName ,
				usr.middlename AS applctrMName, 
				usr.lastname AS applctrLName,
                CONCAT(usr.firstname,' ',usr.middlename,' ',usr.lastname) AS assgndto,
                CONCAT(servicerequests.firstname,' ',servicerequests.lastname ) AS caller,
                CONCAT(sites.address1,' ',sites.address2 ) AS addrs,
                servicerequests.mainphone", FALSE );
		
		$this->db->from ( 'servicerequests' );
		$this->db->join ( 'sites', 'servicerequests.idsite = sites.idsite', 'LEFT' );
		$this->db->join ( 'states', 'sites.idstate = states.idstate', 'LEFT' );
		$this->db->join ( 'users AS usr', 'servicerequests.idapplicator = usr.iduser', 'LEFT' );
		
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'servicerequests.isdeleted', '0' );
		
		$futurebutton_filter_date = $this->input->get ( 'futurebutton_filter_date' );
		$city = $this->input->get ( 'city' );
		$status = $this->input->get ( 'status' );
		$filter_date = !empty($filter_date) ? $filter_date : $this->input->get ( 'filter_date' );
		$ttl = !empty($ttl) ? $ttl : $this->input->get ( 'ttl' );
		$page = !empty($page) ? $page : $this->input->get ( 'page' );
		$frmdate = !empty($filter_daterange) && isset($filter_daterange[0]) ? $filter_daterange[0] : $this->input->get ( 'frmdate' );
		$todate = !empty($filter_daterange) && isset($filter_daterange[1]) ? $filter_daterange[1] : $this->input->get ( 'todate' );
		$pending = $this->input->get ( 'pending' );
		$orderby = $this->input->get ( 'orderby' );
        $wanum = $this->input->get ( 'wanum' );
		
        if(!empty($wanum)) {
            $this->db->where ( 'servicerequests.idservicerequest', $wanum );   
        }
        
		if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 2;
		
		if (! isset ( $futurebutton_filter_date ) || $futurebutton_filter_date == '')
			$futurebutton_filter_date = '';
		
		if (! isset ( $ttl ) || $ttl == '')
			$ttl = 10;
		
		if (! isset ( $page ) || $page == '')
			$page = 1;
		
		if (! isset ( $status ) || $status == '')
			$status = 3;
		
        if(!empty($mapSite)){
            $this->db->where ( 'sites.idsite', $mapSite );
		}
        
        if(!empty($mapSite) || !empty($mapFlag)){
            $filter_date = "";
            $filter_daterange = "";
            $frmdate = "";
            $todate = "";
		}
        
		if (! empty ( $frmdate ) && ! empty ( $todate )) {
			$frmdate = substr ( $frmdate, 0, 2 ) . '/' . substr ( $frmdate, 2, 2 ) . '/' . substr ( $frmdate, 4, 4 );
			$todate = substr ( $todate, 0, 2 ) . '/' . substr ( $todate, 2, 2 ) . '/' . substr ( $todate, 4, 4 );
			if (! empty ( $status )) {
				switch ($status) {
					case '1' :
						$where = "(servicerequests.closedate = '' OR servicerequests.closedate IS NULL OR servicerequests.closedate ='0000-00-00')";
						$this->db->where ( $where );
						$this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( $frmdate ) ) );
						$this->db->where ( 'servicerequests.opendate' . ' <=', date ( 'Y-m-d', strtotime ( $todate ) ) );
						break;
					case '2' :
						$where = "(servicerequests.closedate != '' AND servicerequests.closedate IS NOT NULL AND servicerequests.closedate !='0000-00-00')";
						$this->db->where ( $where );
						$this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( $frmdate ) ) );
						$this->db->where ( 'servicerequests.opendate' . ' <=', date ( 'Y-m-d', strtotime ( $todate ) ) );
						break;
					case '3' :
						// $where = " (servicerequests.opendate >= '".date('Y-m-d' , strtotime($frmdate))."' AND servicerequests.opendate <= '".date('Y-m-d' , strtotime($todate))."') AND ((servicerequests.closedate >= '".date('Y-m-d' , strtotime($frmdate))."' AND servicerequests.closedate <= '".date('Y-m-d' , strtotime($todate))."') OR (servicerequests.closedate = '0000-00-00' OR servicerequests.closedate = '1970-01-01' OR servicerequests.closedate = ''))";
						// $this->db->where($where) ;
						$this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( $frmdate ) ) );
						$this->db->where ( 'servicerequests.opendate' . ' <=', date ( 'Y-m-d', strtotime ( $todate ) ) );
						break;
				}
			}
			// else
			// {
			// $this->db->order_by('servicerequests.opendate' , 'DESC');
			// }
		} else if (! empty ( $filter_date )) {
			if (! empty ( $status )) {
				switch ($status) {
					case '1' :
						$where = "(servicerequests.closedate = '' OR servicerequests.closedate IS NULL OR servicerequests.closedate ='0000-00-00')";
						$this->db->where ( $where );
						switch ($filter_date) {
							case '1' :
								$this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
								$this->db->where ( 'servicerequests.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							
							case '2' :
								$this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
								$this->db->where ( 'servicerequests.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							case '3' :
								$this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
								$this->db->where ( 'servicerequests.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							case '4' :
								$this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
								$this->db->where ( 'servicerequests.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							case '5' :
								$this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
								$this->db->where ( 'servicerequests.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
						}
						break;
					case '2' :
						$where = "(servicerequests.closedate != '' AND servicerequests.closedate IS NOT NULL AND servicerequests.closedate !='0000-00-00')";
						$this->db->where ( $where );
						switch ($filter_date) {
							// date('H:i:s',strtotime('-1 day');
							case '1' :
								$this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
								$this->db->where ( 'servicerequests.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							
							case '2' :
								$this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
								$this->db->where ( 'servicerequests.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							case '3' :
								$this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
								$this->db->where ( 'servicerequests.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							case '4' :
								$this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
								$this->db->where ( 'servicerequests.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							case '5' :
								$this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
								$this->db->where ( 'servicerequests.opendate' . ' <=', date ( 'Y-m-d' ) );
						}
						break;
					case '3' :
						switch ($filter_date) {
							case '1' :
								$this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
								$this->db->where ( 'servicerequests.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							
							case '2' :
								$this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
								$this->db->where ( 'servicerequests.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							case '3' :
								$this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
								$this->db->where ( 'servicerequests.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							case '4' :
								$this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
								$this->db->where ( 'servicerequests.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							case '5' :
								$this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
								$this->db->where ( 'servicerequests.opendate' . ' <=', date ( 'Y-m-d' ) );
						}
						
						break;
				}
			}
			// else
			// {
			// $this->db->order_by('servicerequests.opendate' , 'DESC');
			// }
		}
		
		if (! empty ( $pending ) && ! is_null ( $pending ))
			$this->db->where ( 'servicerequests.isapproved', '0' );
		
		if (! empty ( $city ))
			$this->db->like ( 'sites.city', $city, 'after' );
			// echo "Order ".$orderby."<br>";
		if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
			switch ($orderby) {
				case '0:asc' :
					$this->db->order_by ( 'servicerequests.idservicerequest', 'ASC' );
					break;
				case '0:desc' :
					$this->db->order_by ( 'servicerequests.idservicerequest', 'DESC' );
					break;
				case '1:asc' :
					$this->db->order_by ( 'servicerequests.sitename', 'ASC' );
					break;
				case '1:desc' :
					$this->db->order_by ( 'servicerequests.sitename', 'DESC' );
					break;
				case '2:asc' :
					$this->db->order_by ( 'servicerequests.opendate', 'ASC' );
					break;
				case '2:desc' :
					$this->db->order_by ( 'servicerequests.opendate', 'DESC' );
					break;
				case '3:asc' :
					$this->db->order_by ( 'servicerequests.closedate', 'ASC' );
					break;
				case '3:desc' :
					$this->db->order_by ( 'servicerequests.closedate', 'DESC' );
					break;
				case '4:asc' :
					$this->db->order_by ( 'servicerequests.firstname', 'ASC' );
					$this->db->order_by ( 'servicerequests.lastname', 'ASC' );
					break;
				case '4:desc' :
					$this->db->order_by ( 'servicerequests.firstname', 'DESC' );
					$this->db->order_by ( 'servicerequests.lastname', 'DESC' );
					break;
				case '5:asc' :
					$this->db->order_by ( "SUBSTRING_INDEX(sites.address1, ' ', 1) + 0", 'ASC' );
					$this->db->order_by ( 'sites.address2', 'ASC' );
					$this->db->order_by ( 'sites.city', 'ASC' );
					$this->db->order_by ( 'states.statename', 'ASC' );
					break;
				case '5:desc' :
					$this->db->order_by ( "SUBSTRING_INDEX(sites.address1, ' ', 1) + 0", 'DESC' );
					$this->db->order_by ( 'sites.address2', 'DESC' );
					$this->db->order_by ( 'sites.city', 'DESC' );
					$this->db->order_by ( 'states.statename', 'DESC' );
					break;
				case '6:asc' :
					$this->db->order_by ( 'sites.city', 'ASC' );
					break;
				case '6:desc' :
					$this->db->order_by ( 'sites.city', 'DESC' );
					break;
				case '7:asc' :
					$this->db->order_by ( 'dispositions.disposition', 'ASC' );
					break;
				case '7:desc' :
					$this->db->order_by ( 'dispositions.disposition', 'DESC' );
					break;
			}
		} else {
			$this->db->order_by ( 'servicerequests.opendate', 'DESC' );
		}
		/*
		 * if(!is_null($ttl) && !empty($ttl) && !is_null($page) && !empty($page))
		 * {
		 * if($page == 1)
		 * $page = 0;
		 * else
		 * $page--;
		 *
		 * $page *= 10;
		 * $this->db->limit($ttl ,$page);
		 * }
		 * else if(!is_null($ttl) && !empty($ttl))
		 * {
		 * $this->db->limit($ttl);
		 * }
		 */
		if(!empty($Ids)) {
            $this->db->where_in ( 'servicerequests.idservicerequest', $Ids );
        }
		$query = $this->db->get ();
		// echo $filter_date."<br>".$status."<br>".$this->db->last_query();
		// die;
		$result = array ();
		$i = 0;
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $key => $val ) {
				$this->db->select ( 'd.disposition' );
				$this->db->from ( 'dispositions AS d' );
				$this->db->join ( 'servicerequestsdetail AS srd', 'd.iddispositions = srd.iddispositions', 'LEFT' );
				$this->db->join ( 'servicerequests AS sr', 'srd.idservicerequest = sr.idservicerequest', 'LEFT' );
				$this->db->where ( 'sr.idservicerequest', $val ['idservicerequest'] );
				
				$q = $this->db->get ();
				$dispostions = "";
				$dispostions_r = array ();
				if ($q->num_rows () > 0) {
					
					foreach ( $q->result () as $row )
						$dispostions_r [] = $row->disposition;
					
					$dispostions = implode ( ';', $dispostions_r );
				}
				$result [$i] = $val;
				$result [$i] ['dispositions'] = $dispostions;
				$i ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to Get Lati Longi
	 * for displaying on Maps
	 */
	public function getMapdata() {
        $offset = 0;
		$page_size = $this->input->get ( 'page_size' );
		$page = $this->input->get ( 'page' );
		$filter_date = $this->input->get ( 'filter_date' );
		$city = $this->input->get ( 'city' );
		$status = $this->input->get ( 'status' );
		$setfromdate = $this->input->get ( 'setfromdate' );
		$settodate = $this->input->get ( 'settodate' );
		$futureassign = $this->input->get ( 'futureassign' );
		$pending = $this->input->get ( 'pending' );
        $wanum = $this->input->get ( 'wanum' );
		
        $page_size = ($page_size == 'all') ? 'all' : (is_numeric($page_size) ? $page_size : 10);
        $limit = (is_numeric($page_size)) ? $page_size : NULL;        
        $offset = $limit * ($page - 1);
        
        if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 2;
		
        
		$this->db->select ( 'sr.*, 
				sr.latitude, 
				sr.longitude, 
				s.idzone, 
				s.city, 
				s.address1, 
				s.address2, 
				states.statename' );
		$this->db->from ( 'servicerequests AS sr' );
		$this->db->join ( 'sites AS s', 'sr.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'states', 's.idstate = states.idstate', 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'sr.isdeleted', '0' );
        if(!empty($wanum)) {
            $this->db->where ( 'sr.idservicerequest', $wanum );   
        }
		
		if (empty ( $status ))
			$status = 3;
		
        if(!empty($wanum)) {
            $this->db->where ( 'sr.idservicerequest', $wanum );   
        }
        
		if (! is_null ( $city ) && ! empty ( $city ))
			$this->db->like ( 's.city', $city, 'after' );
		
		if (! empty ( $filter_date ) && empty ( $setfromdate ) && empty ( $settodate ) && empty ( $futureassign )) {
			if (! empty ( $status )) {
				switch ($status) {
					case '1' :
						$where = "(sr.closedate = '' OR sr.closedate IS NULL OR sr.closedate ='0000-00-00')";
						$this->db->where ( $where );
						switch ($filter_date) {
							case '1' :
								$this->db->where ( 'sr.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
								$this->db->where ( 'sr.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							
							case '2' :
								$this->db->where ( 'sr.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
								$this->db->where ( 'sr.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							case '3' :
								$this->db->where ( 'sr.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
								$this->db->where ( 'sr.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							case '4' :
								$this->db->where ( 'sr.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
								$this->db->where ( 'sr.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							case '5' :
								$this->db->where ( 'sr.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
								$this->db->where ( 'sr.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
						}
						break;
					case '2' :
						$where = "(sr.closedate != '' AND sr.closedate IS NOT NULL AND sr.closedate !='0000-00-00')";
						$this->db->where ( $where );
						switch ($filter_date) {
							case '1' :
								$this->db->where ( 'sr.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
								$this->db->where ( 'sr.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							
							case '2' :
								$this->db->where ( 'sr.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
								$this->db->where ( 'sr.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							case '3' :
								$this->db->where ( 'sr.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
								$this->db->where ( 'sr.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							case '4' :
								$this->db->where ( 'sr.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
								$this->db->where ( 'sr.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							case '5' :
								$this->db->where ( 'sr.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
								$this->db->where ( 'sr.opendate' . ' <=', date ( 'Y-m-d' ) );
						}
						break;
					default :
						switch ($filter_date) {
							case '1' :
								$this->db->where ( 'sr.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
								$this->db->where ( 'sr.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							
							case '2' :
								$this->db->where ( 'sr.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
								$this->db->where ( 'sr.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							case '3' :
								$this->db->where ( 'sr.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
								$this->db->where ( 'sr.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							case '4' :
								$this->db->where ( 'sr.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
								$this->db->where ( 'sr.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
							case '5' :
								$this->db->where ( 'sr.opendate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
								$this->db->where ( 'sr.opendate' . ' <=', date ( 'Y-m-d' ) );
								break;
						}
						break;
				}
			}
		} else if (! empty ( $setfromdate ) && ! empty ( $settodate ) && empty ( $futureassign )) {
			if (! empty ( $status )) {
				switch ($status) {
					case '1' :
						$where = "(sr.closedate = '' OR sr.closedate IS NULL OR sr.closedate ='0000-00-00')";
						$this->db->where ( $where );
						$this->db->where ( 'sr.opendate' . ' >=', date ( 'Y-m-d', strtotime ( $setfromdate ) ) );
						$this->db->where ( 'sr.closedate' . ' <=', date ( 'Y-m-d', strtotime ( $settodate ) ) );
						break;
					case '2' :
						$where = "(sr.closedate != '' AND sr.closedate IS NOT NULL AND sr.closedate !='0000-00-00')";
						$this->db->where ( $where );
						$this->db->where ( 'sr.opendate' . ' >=', date ( 'Y-m-d', strtotime ( $setfromdate ) ) );
						$this->db->where ( 'sr.closedate' . ' <=', date ( 'Y-m-d', strtotime ( $settodate ) ) );
						break;
					default :
						$this->db->where ( 'sr.opendate' . ' >=', date ( 'Y-m-d', strtotime ( $setfromdate ) ) );
						$this->db->where ( 'sr.closedate' . ' <=', date ( 'Y-m-d', strtotime ( $settodate ) ) );
						break;
				}
			}
		}
		
		if (! is_null ( $pending ) && ! empty ( $pending ))
			$this->db->where ( 'sr.isapproved', '0' );
		
		if (! empty ( $futureassign )) {
			switch ($filter_status) {
				case '1' :
					$where = ' (servicerequests.closedate IS NULL OR servicerequests.closedate = "" OR  servicerequests.closedate = "0000-00-00")';
					$this->db->where ( $where );
					break;
				case '2' :
					$where = '(servicerequests.closedate IS NOT NULL AND servicerequests.closedate != "" AND servicerequests.closedate != "0000-00-00")';
					$this->db->where ( $where );
					break;
				case '3' :
					break;
			}
			$where = " sr.opendate >= '" . date ( 'Y-m-d' ) . "'";
			$this->db->where ( $where );
		}
		$this->db->order_by ( 'sr.opendate', 'desc' );
		$this->db->limit ( $limit, $offset );
		
		$data_1 = array ();
		$query = $this->db->get ();
		// echo $this->db->last_query();die;
		$data = array ();
		$result = array ();
		$zonecoords = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $key => $val ) {
				// echo $val['idservicerequest']." ".$val['idsite']." ".$val['idzone']."<br>";
				$this->db->select ( '*' );
				$this->db->from ( 'zonecords' );
				$this->db->where ( 'idzone', $val ['idzone'] );
				
				$q = $this->db->get ();
				if ($q->num_rows ()) {
					foreach ( $q->result_array () as $k => $v ) {
						$zonecoords [] = $v ['zonecord'];
					}
				}
				
				$this->db->select ( 's.site_of_interest, 
						s.landingrate_site, 
						s.larval_site, 
						s.adult_site, 
						s.apiary, 
						s.contact_before_spray, 
						s.organic_farm, 
						s.nospray, 
						s.water_of_us' );
				$this->db->from ( 'sites AS s' );
				$this->db->where ( 'idsite', $val ['idsite'] );
				$result [$key] = $val;
				$temp = array ();
				$q1 = $this->db->get ();
				if ($q1->num_rows ()) {
					foreach ( $q1->result_array () as $k => $v ) {
						$temp = $v;
					}
				}
				$result [$key] ['site_of_interest'] = ! empty ( $temp ['site_of_interest'] ) ? $temp ['site_of_interest'] : '0';
				$result [$key] ['landingrate_site'] = ! empty ( $temp ['landingrate_site'] ) ? $temp ['landingrate_site'] : '0';
				$result [$key] ['larval_site'] = ! empty ( $temp ['larval_site'] ) ? $temp ['larval_site'] : '0';
				$result [$key] ['adult_site'] = ! empty ( $temp ['adult_site'] ) ? $temp ['adult_site'] : '0';
				$result [$key] ['apiary'] = ! empty ( $temp ['apiary'] ) ? $temp ['apiary'] : '0';
				$result [$key] ['contact_before_spray'] = ! empty ( $temp ['contact_before_spray'] ) ? $temp ['contact_before_spray'] : '0';
				$result [$key] ['organic_farm'] = ! empty ( $temp ['organic_farm'] ) ? $temp ['organic_farm'] : '0';
				$result [$key] ['nospray'] = ! empty ( $temp ['nospray'] ) ? $temp ['nospray'] : '0';
				$result [$key] ['water_of_us'] = ! empty ( $temp ['water_of_us'] ) ? $temp ['water_of_us'] : '0';
			}
		}
		
		$data ['result'] = $result;
		$data ['zonecords'] = $zonecoords;
		// print'<pre>';
		// print_r($data);
		// die;
		return $data;
	}
	
	/**
	 * Function to fetch all Dispositions
	 */
	public function getDispositions() {
		$this->db->select ( '*' );
		$this->db->from ( 'dispositions' );
		$this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'state', '1' );
		$this->db->order_by ( 'dispositions.disposition', 'ASC' );
		$query = $this->db->get ();
		$this->str = "";
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['iddispositions'] . '">' . $row ['disposition'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to list all Service Request
	 */
	public function getServiceRequestData($id = '') {
		if (empty ( $id ))
			return null;
		
		$this->db->select ( '*' );
		$this->db->from ( 'servicerequests' );
		$this->db->where ( 'idservicerequest', $id );
		$this->db->where ( 'servicerequests.isdeleted', '0' );
		$data_1 = array ();
		$query = $this->db->get ();
		$result = array ();
		if ($query->num_rows () > 0) {
			$recordCount = $query->num_rows ();
			foreach ( $query->result_array () as $row ) {
				$data_1 = $row;
			}
			// Return result to jTable
			
			return $data_1;
		}
	}
	
	/**
	 * Function to save data submitted from
	 * Sutter Yuba website
	 */
	public function saveServiceRequestData($id = '') {
		// print('<pre>');
		// print_r($_POST);
		// die;
		$name = $this->input->post ( 'element_0' );
		$name1 = $name;
		if (! empty ( $name )) {
			$name = explode ( " ", $name );
			$data ['firstname'] = ! empty ( $name [0] ) ? $name [0] : '';
			$data ['lastname'] = ! empty ( $name [1] ) ? $name [1] : '';
		}
		$address = $this->input->post ( 'element_1' );
		$cross_street = $this->input->post ( 'element_2' );
		$city = $this->input->post ( 'element_3' );
		$ispresent = $this->input->post ( 'element_6' );
		$comments = $this->input->post ( 'element_7' );
		$data ['address'] = ! empty ( $address ) ? $address : '';
		$data ['cross_street'] = ! empty ( $cross_street ) ? $cross_street : '';
		$data ['city'] = ! empty ( $city ) ? $city : '';
		$data ['ispresent'] = (! empty ( $ispresent [0] ) && $ispresent [0] == "Yes") ? '1' : '0';
		$data ['comments'] = ! empty ( $comments ) ? $comments : '';
		$data ['mainphone'] = $this->input->post ( 'element_4' );
		$data ['opendate'] = date ( 'Y-m-d' );
		$data ['opentime'] = date ( 'H:i:s' );
		$data ['idlocation'] = '37';
		$data ['isapproved'] = '0';
		// print'<pre>';
		// print_r($_POST);
		// print_r($data);
		// die;
		
		$this->db->query ( "SET foreign_key_checks = 0" );
		$this->db->insert ( 'servicerequests', $data );
		$this->db->query ( "SET foreign_key_checks = 1" );
		$email = $this->input->post ( 'element_5' );
		$present = $this->input->post ( 'element_6' );
		$comments = $this->input->post ( 'element_7' );
		$this->email->from ( $email, $name1 );
		$this->email->to ( 'carlos@skysoftinc.com' );
		$this->email->cc ( 'dev.amirkhan@gmail.com' );
		// $this->email->bcc('them@their-example.com');
		
		$this->email->subject ( 'Email Test' );
		$message = '<table width="100%" cellspacing="0" cellpadding="0" border="0" style="width:100.0%">
	<tbody><tr><td width="20%" style="width:20.0%;background:#e1e1e1;padding:5.25pt 6.75pt 5.25pt 6.75pt"><p class="MsoNormal"><b>Your Name<span style="color:red">*</span>:<u></u><u></u></b></p></td><td width="80%" style="width:80.0%;background:#e1e1e1;padding:5.25pt 6.75pt 5.25pt 0in"><p class="MsoNormal">' . $name1 . '<u></u><u></u></p></td></tr><tr><td width="20%" style="width:20.0%;padding:5.25pt 6.75pt 5.25pt 6.75pt"><p class="MsoNormal"><b>Your Address<span style="color:red">*</span>:<u></u><u></u></b></p></td><td width="80%" style="width:80.0%;padding:5.25pt 6.75pt 5.25pt 0in"><p class="MsoNormal">' . $address . '<u></u><u></u></p></td></tr><tr><td width="20%" style="width:20.0%;background:#e1e1e1;padding:5.25pt 6.75pt 5.25pt 6.75pt"><p class="MsoNormal"><b>Nearest Cross Street<span style="color:red">*</span>:<u></u><u></u></b></p></td><td width="80%" style="width:80.0%;background:#e1e1e1;padding:5.25pt 6.75pt 5.25pt 0in"><p class="MsoNormal">' . $cross_street . '<u></u><u></u></p></td></tr><tr><td width="20%" style="width:20.0%;padding:5.25pt 6.75pt 5.25pt 6.75pt"><p class="MsoNormal"><b>City/Town/Area<span style="color:red">*</span>:<u></u><u></u></b></p></td><td width="80%" style="width:80.0%;padding:5.25pt 6.75pt 5.25pt 0in"><p class="MsoNormal">' . $city . '<u></u><u></u></p></td></tr><tr><td width="20%" style="width:20.0%;background:#e1e1e1;padding:5.25pt 6.75pt 5.25pt 6.75pt"><p class="MsoNormal"><b>Telephone Number<span style="color:red">*</span>:<u></u><u></u></b></p></td><td width="80%" style="width:80.0%;background:#e1e1e1;padding:5.25pt 6.75pt 5.25pt 0in"><p class="MsoNormal">' . $data ['mainphone'] . '<u></u><u></u></p></td></tr><tr><td width="20%" style="width:20.0%;padding:5.25pt 6.75pt 5.25pt 6.75pt"><p class="MsoNormal"><b>Email Address<span style="color:red">*</span>:<u></u><u></u></b></p></td><td width="80%" style="width:80.0%;padding:5.25pt 6.75pt 5.25pt 0in"><p class="MsoNormal"><a target="_blank" href="mailto:carlos@skysoftinc.com">' . $email . '</a><u></u><u></u></p></td></tr><tr><td width="20%" style="width:20.0%;background:#e1e1e1;padding:5.25pt 6.75pt 5.25pt 6.75pt"><p class="MsoNormal"><b>Do You Need To Be Present?<span style="color:red">*</span>:<u></u><u></u></b></p></td><td width="80%" style="width:80.0%;background:#e1e1e1;padding:5.25pt 6.75pt 5.25pt 0in"><p class="MsoNormal">' . $data ['ispresent'] . '<u></u><u></u></p></td></tr><tr><td width="20%" style="width:20.0%;padding:5.25pt 6.75pt 5.25pt 6.75pt"><p class="MsoNormal"><b>Comments- locked gates/access issues, dogs, bring mosquitofish, specific directions, etc.:<u></u><u></u></b></p></td><td width="80%" style="width:80.0%;padding:5.25pt 6.75pt 5.25pt 0in"><p class="MsoNormal">' . $comments . '<u></u><u></u></p></td></tr></tbody></table>';
		$this->email->message ( $message );
		
		$flag = $this->email->send ();
		return $flag;
		// echo $this->email->print_debugger();
		// die;
	}
	
	/**
	 * Function to calculate total
	 * pending SRs
	 */
	public function getTotalPendingRequests($id = '') {
		$this->db->select ( 'COUNT(isapproved) AS count' );
		$this->db->from ( 'servicerequests' );
		$this->db->where ( "isapproved = '0'" );
		$this->db->where ( "isdeleted = '0'" );
		$this->db->where ( 'servicerequests.idlocation', $this->session->userdata ( 'idlocation' ) );
		$query = $this->db->get ();
		if ($query->num_rows () > 0) {
			$ttl = $query->result_array ();
			$ttl = ! empty ( $ttl [0] ['count'] ) ? $ttl [0] ['count'] : '0';
			if ($ttl > 0)
				return $ttl;
			// print('<pre>');
			// print_r($ttl);
			// die;
		}
	}
}

?>