<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );

date_default_timezone_set ( 'UTC' );
class Skytrackermission_model extends CI_Model {
	public $data = array ();
	public $str = "";
	public $set_pwd = "";
	
	/**
	 * Constructor for the class
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
		$this->load->model ( 'usermodel' );
	}
	
	/**
	 * Function to Add a new Sky Tracker Mission
	 */
	public function addSkyTrackerMission($flight_array = '', $mission_array = '') {
		
		log_message('debug',"addSkyTrackerMission");

		$mission_id = $this->addMissionInDB($mission_array, $flight_array);

		log_message('debug',"get primary key of inserted mission id : ".$mission_id );

		$this->addMissionFligtInDB($flight_array, $mission_id);

		return $mission_id;
	}

	/*
		Add Mission Data
	*/
	public function addMissionInDB($mission_array = '', $flight_array = ''){

		$sizeOfFlight = count($flight_array['values']);
		// log_message('debug','Skysoft Debugging -------------->>>>> $$flight_arrayvalues][$sizeOfFlight-1]:'.print_r(,1));
		log_message('debug','Skysoft Debugging -------------->>>>> sizeOfFlight:'.print_r($sizeOfFlight,1));
		$mission['missionsorties'] = $flight_array['values'][$sizeOfFlight-1]['P'];

		foreach($flight_array['values'] as $values){
			if(isset($values['L'])){
				$mission['treatmentStartDate'] = $this->chunk_split_date( strlen ( $values['O'] ) > 5 ? $values['O'] : "0".$values['O'] , 2) .'T'. gmdate('H:i:s', $values['N']);
				break;
			}
		}

		for ($i = $sizeOfFlight-1; $i > 0; $i--) {
			if(isset($flight_array['values'][$i]['L'])){
				$mission['treatmentEndDate'] = $this->chunk_split_date(strlen ( $flight_array['values'][$i]['O'] ) > 5 ? $flight_array['values'][$i]['O'] : "0".$flight_array['values'][$i]['O'], 2) .'T'. gmdate('H:i:s', $flight_array['values'][$i]['N']);
				break;
			}
		}
		
		$mission['startdate'] = $this->chunk_split_date( strlen ($flight_array['values'][0]['O'] ) > 5 ? $flight_array['values'][0]['O'] : "0".$flight_array['values'][0]['O'], 2) .'T'. gmdate('H:i:s', $flight_array['values'][0]['N']);
		$mission['enddate'] = $this->chunk_split_date( strlen ($flight_array['values'][$sizeOfFlight-1]['O'] ) > 5 ?$flight_array['values'][$sizeOfFlight-1]['O'] : "0".$flight_array['values'][$sizeOfFlight-1]['O'], 2) .'T'. gmdate('H:i:s', $flight_array['values'][$sizeOfFlight-1]['N']);

		$mission['treatmentTime'] = $this->format_time($flight_array['values'][$sizeOfFlight-1]['Q']);

		$mission['swathWidth'] = $flight_array['values'][0]['I'];
		// T is in miles
		// I is in feet
		// T to feet -> T * 5280
		// T(feet) * I -> area in square feet
		// area in square feet * 0.000022956841138659 -> area in acres
		$mission['treatmentArea'] = ($flight_array['values'][$sizeOfFlight-1]['T'] * 5280 * $flight_array['values'][0]['I']) * 0.000022956841138659 ;

		// U is in ML
		// U * 0.000264172 -> gallons
		// find first non zero value in U
		$mission['volumeUsed'] = "0";
		for ($i = 0; $i < $sizeOfFlight; $i++) {
			if(isset($flight_array['values'][$i]['U']) && $flight_array['values'][$i]['U'] != '0'){
				$mission['volumeUsed'] = $flight_array['values'][$i]['U'] * 0.000264172;
				log_message('debug','Skysoft Debugging -------------->>>>> volumeUsed: '.print_r($mission['volumeUsed'],1));
				break;
			}
		}
		$mission['GUID'] = trim($mission_array['siteId'],'{}');
		$mission['topAirSpeed'] = $flight_array['values'][$sizeOfFlight-1]['Y'];

		$height = 0.0;
		for ($i = 60; $i < $sizeOfFlight-60 ; $i++) {
			$height = $height + $flight_array['values'][$i]['C'];
				
		}
		$averageHeight = $height / ($sizeOfFlight-120);
		$mission['averageHeight'] = $averageHeight;

		$this->db->insert ( 'missionskytracker', $mission );

		return $this->db->insert_id ();
	}

	/*
		Add Mission Flight Data
	*/
	public function addMissionFligtInDB($flight_array = '', $mission_id = ''){
		$flights = array();

		foreach($flight_array['values'] as $values){
			array_push($flights, array(
				'id_mission_tracker'=> $mission_id,
				'gps_lati'=> $values['A'],
				'gps_logi'=> $values['B'],
				// 'gps_altitude'=> $values['C'],
				// 'gps_track'=> $values['D'],
				// 'gps_velocity'=> $values['E'],
				'io_spray_state'=> $values['F'],
				'user_spray_state'=> $values['G'],
				'user_spray_altitude'=> $values['H'],
				'user_spray_width'=> $values['I'],
				'wind_direction'=> $values['J'],
				'wind_vel'=> $values['K'],
				'gps_lat_if_spray_on'=> $values['L'],
				'gps_logi_if_spray_on'=> $values['M'],
				'gps_time'=> $values['N'],
				'gps_date'=> $values['O'],
				// 'sortie_num'=> $values['P'],
				'total_emission'=> $values['Q'],
				'is_gps_valid'=> $values['R'],
				// 'commulative_travelled_distance'=> $values['S'],
				// 'commulative_sprayed_distance'=> $values['T'],
				'commulative_volume_sprayed'=> $values['U'],
				// 'last_block_selected'=> $values['V'],
				// 'last_block_group_selected'=> $values['W'],
				// 'top_sprayed_speed'=> $values['X'],
				'top_flown_speed'=> $values['Y'],
				'gps_speed'=> $values['Z']
				// 'run_number'=> $values['AA']
				)
			);
		}
		$this->db->insert_batch('missionflightdata', $flights);
	}

	/*
		Add Mission SprayBlockGroup Data
	*/
	public function addMissionSprayBlockGroup($spray_block_group_array = '', $mission_id = '' ){
		if (empty ( $spray_block_group_array ) || empty ( $mission_id ))
			return null;
		
		$block_group['idmission'] = $mission_id;
		$block_group['idsprayblockgroupinfile'] = $spray_block_group_array['id'];
		$block_group['blockgroupname'] = $spray_block_group_array['siteId'];
		$block_group['idsprayblockgroupsite'] = $spray_block_group_array['name'];

		$this->db->insert('mission_spray_block_group', $block_group);

		return $this->db->insert_id ();
	}

	/*
		Add Mission SprayBlock Data
	*/
	public function addMissionSprayBlock($spray_block_array = '', $flight_array = '' ){
		if (empty ( $spray_block_array ) || empty ( $flight_array ) )
			return null;
		// log_message('debug','Skysoft Debugging -------------->>>>> $spray_block_array : '.print_r($spray_block_array,1));
		$sizeOfBlocks = count($spray_block_array);
		// log_message('debug','Skysoft Debugging -------------->>>>> $sizeOfBlocks : '.print_r($sizeOfBlocks,1));
		for($indexBlocks = 0; $indexBlocks < $sizeOfBlocks; $indexBlocks++){
			$blocks = $spray_block_array[$indexBlocks];
			$blockProperties = json_decode($blocks['properties']);
			$sizeOfFlight = count($flight_array['values']);
			$isBlockFound = 0;
			$firstTValue = null;
			$lastTValue = null;
			$sprayWidth = null;
			$startValumeSpray = null;
			$endValueSpray = null;
			// log_message('debug','Skysoft Debugging -------------->>>>> $blockProperties : '.print_r($blockProperties,1));
			for ($i = 0 ; $i< $sizeOfFlight; $i++) {
				if(isset($flight_array['values'][$i]['V'])  && $isBlockFound == 0  && strtolower($flight_array['values'][$i]['V']) == strtolower($blockProperties->AdapcoId)){
					// log_message('debug','Skysoft Debugging -------------->>>>> Got the first match blockfound is 1 now');
					$isBlockFound = 1;
					$firstTValue = $flight_array['values'][$i]['T'];
					$sprayWidth = $flight_array['values'][$i]['I'];
					$startValumeSpray = $flight_array['values'][$i]['U'];
				}
				if(isset($flight_array['values'][$i]['V']) && $isBlockFound == 1 && strtolower($flight_array['values'][$i]['V']) == strtolower($blockProperties->AdapcoId)){
					if($i == $sizeOfFlight -1){
						// log_message('debug','Skysoft Debugging -------------->>>>> got the matching block group id - Last item');
						$lastTValue = $flight_array['values'][$i]['T'];
						$endValueSpray = $flight_array['values'][$i]['U'];
					}
				}
				// if( !(is V empmty) || ( current block logging is completed in csv flie i.e. V != blockProperties['AdapcoId']) )
				if( (!isset($flight_array['values'][$i]['V'] ) || (strtolower($flight_array['values'][$i]['V']) != strtolower($blockProperties->AdapcoId)) ) && $isBlockFound == 1){
					// log_message('debug','Skysoft Debugging -------------->>>>> Got the first not matching value afte match sequence, braking the loop ');
					$lastTValue = $flight_array['values'][$i-1]['T'];
					$endValueSpray = $flight_array['values'][$i-1]['U'];
					break;
				}
			}
	
			if(!isset($lastTValue))
				$lastTValue = 0;
			if(!isset($firstTValue))
				$firstTValue = 0;
			if(!isset($sprayWidth))
				$sprayWidth = 0;
			if(!isset($startValumeSpray))
				$startValumeSpray = 0;
	
			// log_message('debug','Skysoft Debugging -------------->>>>> firstTValue : '.print_r($firstTValue,1));
			// log_message('debug','Skysoft Debugging -------------->>>>> lastTValue : '.print_r($lastTValue,1));
			// log_message('debug','Skysoft Debugging -------------->>>>> sprayWidth : '.print_r($sprayWidth,1));
			// log_message('debug','Skysoft Debugging -------------->>>>> startValumeSpray : '.print_r($startValumeSpray,1));
	
			$totalDistanceCoveredOfBlock = $lastTValue - $firstTValue;
	
			// T is in miles
			// I is in feet
			// T to feet -> T * 5280
			// T(feet) * I -> area in square feet
			// area in square feet * 0.000022956841138659 -> area in acres
			$spray_block_array[$indexBlocks]['blockAreaTreated'] = ($totalDistanceCoveredOfBlock * 5280 * $sprayWidth) * 0.000022956841138659 ;
			// VolumeVolSprayed from start of block - end of block - Column U
			// U is in ML
			// U * 0.000264172 -> gallons
			$spray_block_array[$indexBlocks]['productApplied'] = ($endValueSpray - $startValumeSpray) * 0.000264172;
		}
		// log_message('debug','Skysoft Debugging -------------->>>>> spray_block_array to be saving : '.print_r($spray_block_array,1));
		$this->db->insert_batch('mission_spray_block', $spray_block_array);
	}

	/*
		Add Mission Chemical Data
	*/
	public function addMissionChemical($chemical = '', $mission_id = ''){
		if (empty ( $chemical )  )
			return null;
		
		$chemical_data['idmission'] = $mission_id;
		$chemical_data['idchemicalfromftp'] = $chemical['id'];
		$chemical_data['chemicalname'] = $chemical['name'];
		$chemical_data['applicationflowrate'] = $chemical['applicationFlowRate'];
		$chemical_data['applicationflowrateunits'] = $chemical['applicationFlowRateUnits'];

		$this->db->insert('missionchemical', $chemical_data);
	}

	/*
		Add Mission Aircraft Data
	*/
	public function addMissionAircraft($aircraft = '', $mission_id = ''){
		if (empty ( $aircraft )  )
			return null;
		
		$aircraft_data['idmission'] = $mission_id;
		$aircraft_data['idaircraftfromftp'] = $aircraft['id'];
		$aircraft_data['aircraftmodelname'] = $aircraft['modelName'];

		$this->db->insert('missionaircraft', $aircraft_data);
	}

	/*
		Add Mission Pilot Data
	*/
	public function addMissionPilot($pilot = '', $mission_id = ''){
		if (empty ( $pilot )  )
			return null;
		
		$pilot_data['idmission'] = $mission_id;
		$pilot_data['idgeopro'] = $pilot['geoproId'];
		$pilot_data['idinjson'] = $pilot['id'];
		$pilot_data['name'] = $pilot['name'];
		$pilot_data['cert'] = $pilot['cert'];
		$pilot_data['location'] = $pilot['location'];

		$this->db->insert('missionpilot', $pilot_data);
	}

	/*
		Get Mission Data
	*/
	public function getMission($id = ''){
		if (empty ( $id ))
			return null;
		
		$this->db->select ( '*' );
		$this->db->from ( 'missionskytracker AS m' );
		$this->db->join ( 'missionaircraft AS ma', 'ma.idmission = m.idmissiontracker', 'INNER' );
		$this->db->join ( 'missionchemical AS mc', 'mc.idmission = m.idmissiontracker', 'INNER' );
		$this->db->join ( 'mission_spray_block_group AS msbg', "msbg.idmission = m.idmissiontracker", 'INNER' );
		$this->db->where ( 'm.idmissiontracker', $id);
		$data_1 = array ();
		$query = $this->db->get ();
		$return_obj = array();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$data_1 [] = $row;
			}
			$return_obj['mission_aircraft_chemical_sprayblock'] = $data_1;
			$this->db->select ( 'mf.* ' );
			$this->db->from ( 'missionskytracker AS m ' );
			$this->db->join ( 'missionflightdata AS mf', 'mf.id_mission_tracker = m.idmissiontracker', 'INNER' );
			$this->db->where ( 'm.idmissiontracker', $id );
			$q = $this->db->get ();
			$data_2 = array ();
			if ($q->num_rows () > 0) {
				foreach ( $q->result_array () as $row ) {
					$data_2 [] = $row;
				}
			}
			$return_obj['missionflightdata'] = $data_2;
			
			$this->db->select ( 'msb.* ' );
			$this->db->from ( 'missionskytracker AS m ' );
			$this->db->join ( 'mission_spray_block_group AS msbg', 'msbg.idmission = m.idmissiontracker', 'INNER' );
			$this->db->join ( 'mission_spray_block AS msb', 'msb.idsprayblockgroup = msbg.idsprayblockgroup', 'INNER' );
			$this->db->where ( 'm.idmissiontracker', $id );	
			$q2 = $this->db->get ();
			$data_3 = array ();
			if ($q2->num_rows () > 0) {
				foreach ( $q2->result_array () as $row2 ) {
					$data_3 [] = $row2;
				}
			}
			$return_obj['missionsprayblocks'] = $data_3;

			$this->db->select ( 'mc.* ' );
			$this->db->from ( 'missioncomments AS mc ' );
			
			$this->db->where ( 'mc.idmission', $id );
			$q4 = $this->db->get ();
			$data_4 = array ();
			if ($q4->num_rows () > 0) {
				foreach ( $q4->result_array () as $row4 ) {
					$data_4 [] = $row4;
				}
			}
			$return_obj['missioncomments'] = $data_4;

			$this->db->select ( 'mp.* ' );
			$this->db->from ( 'missionpilot AS mp ' );
			
			$this->db->where ( 'mp.idmission', $id );
			$q5 = $this->db->get ();
			$data_5 = array ();
			if ($q5->num_rows () > 0) {
				foreach ( $q5->result_array () as $row5 ) {
					$data_5 [] = $row5;
				}
			}
			$return_obj['missionpilot'] = $data_5;
			//log_message('debug','Skysoft Debugging -------------->>>>> '.print_r($return_obj,1));
			if (! empty ( $return_obj ))
				return $return_obj;
		}
		
		return $return_obj;
	}
	
	/*
		Add Mission Comment
	*/
	public function addMissionComment($mission_comment = ''){
		if (empty ( $mission_comment ))
			return null;
		
		$comment['maplng'] = $mission_comment['lng'];
		$comment['maplat'] = $mission_comment['lat'];
		$comment['idmission'] = $mission_comment['idMission'];
		$comment['comment'] = $mission_comment['comment'];
		
		$this->db->insert ( 'missioncomments', $comment );

		return $this->db->insert_id ();
	}

	public function editcomment($mission_comment = ''){
		if (empty ( $mission_comment ))
			return null;
		
		$this->db->select ( '*' );
		$this->db->from ( 'missioncomments' );
		$this->db->where ( 'id', $mission_comment['comentId'] );
		
		$q = $this->db->get ();
		if ($q->num_rows () > 0) {
			// if(!empty($del))
			// {
			$data ['comment'] =  $mission_comment['comment'];
			$this->db->where ( 'id', $mission_comment['comentId'] );
			$this->db->update ( 'missioncomments', $data );
		}
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}

	public function deletecomment($comentId = ''){
		if (empty ( $comentId ))
			return null;
		
		$this->db->select ( '*' );
		$this->db->from ( 'missioncomments' );
		$this->db->where ( 'id', $comentId );
		
		$q = $this->db->get ();
		if ($q->num_rows () > 0) {
			$this->db->where ( 'id', $comentId );
			$this->db->delete ( 'missioncomments' );
		}
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}

	public function chunk_split_date($str, $l = 76, $e = "-") {
		$tmp = array_chunk(
			preg_split("//u", $str, -1, PREG_SPLIT_NO_EMPTY), $l);
		$str = "";
		$length = count($tmp);
		for ($i = $length -1 ; $i > -1 ; $i--) {
			if($i == $length -1){
				$str .= "20" . join("", $tmp[$i]) . $e;
			}
			else if($i != 0){
				$str .= join("", $tmp[$i]) . $e;
			}
			else{
				$str .= join("", $tmp[$i]);      
			}
		}
		return $str;
	}

	function format_time($t,$f=':') // t = seconds, f = separator 
	{
	  return sprintf("%02d%s%02d%s%02d", floor($t/3600), $f, ($t/60)%60, $f, $t%60);
	}
}
?>