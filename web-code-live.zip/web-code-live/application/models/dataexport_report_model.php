<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
//error_reporting ( 0 );
date_default_timezone_set ( 'UTC' );
// ini_set('memory_limit','64M');
ini_set ( 'max_execution_time', '86400' );
class Dataexport_report_model extends CI_Model {
	public $data = "";
	
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to fetch Adult Treatment
	 */
	public function getDataexport($startdate = '', $enddate = '', $datatype = '', $option = '', $sub = '', $action = '') {
		$startdate_arr = explode ( "/", $startdate );
		$startdate = (!empty($startdate_arr) && isset($startdate_arr[0]) && isset($startdate_arr[1]) && isset($startdate_arr[2])) ? $startdate_arr [2] . "-" . $startdate_arr [0] . "-" . $startdate_arr [1] : '';
		
		$enddate_arr = explode ( "/", $enddate );
		$enddate = !empty($enddate_arr) && isset($enddate_arr[0]) && isset($enddate_arr[1]) && isset($enddate_arr[2]) ? $enddate_arr [2] . "-" . $enddate_arr [0] . "-" . $enddate_arr [1] : '';
		
		$flg = 0;
		
		switch ($datatype) {
			
			case '1' :
				switch ($option) {
					case 'landing' :
						$this->data = $this->getLandingRateData ( $startdate, $enddate);
						$flg = 1;
						break;
					default :
						$this->db->select ( 'al.setdate, 
								al.settime, 
								al.pudate, 
								al.putime, 
								al.totalcount, 
								al.eggraftcount, 
								al.comments, 
								SUM(asd.countm) AS malecount, 
								SUM(asd.countf) AS femalecount, 
								z.zone, 
								t.trap, 
								ts.traptype, 
								bt.baittype, 
								tr.temprange, 
								hr.humidityrange, 
								ws.windspeed, 
								sr.firstname, 
								sr.lastname, 
								cc.cloudcoverage, 
								usr.firstname ufn, 
								usr.middlename, 
								usr.lastname uln, 
								usr.officephone, 
								usr.mobilephone, 
								stt.statename, 
								s.address1, 
								s.address2, 
								s.city, 
								s.postalcode, 
								t.latitude, 
								t.longitude, 
								s.site, 
								SUM(asd.count) AS count, 
								ms.mosquitospecies' );
						$this->db->from ( 'adultsurveillance AS al ' );
						$this->db->join ( 'traps AS t', ' al.idtrap= t.idtrap ', "LEFT" );
						$this->db->join ( 'sites AS s ', 't.idsite = s.idsite ', "LEFT" );
						$this->db->join ( 'zones AS z', ' s.idzone= z.idzone ', "LEFT" );
						$this->db->join ( 'states AS stt', ' s.idstate= stt.idstate ', "LEFT" );
						$this->db->join ( 'traptypes AS ts ', 't.idtraptype = ts.idtraptype ', "LEFT" );
						$this->db->join ( 'baittypes AS bt', 't.idbaittype = bt.idbaittype ', "LEFT" );
						$this->db->join ( 'tempranges AS tr', 'al.idtemprange = tr.idtemprange ', "LEFT" );
						$this->db->join ( 'humidityranges AS hr', 'al.idhumidityrange = hr.idhumidityrange ', "LEFT" );
						$this->db->join ( 'windspeeds AS ws', 'al.idwindspeed = ws.idwindspeed ', "LEFT" );
						$this->db->join ( 'servicerequests AS sr', 'al.idservicerequest = sr.idservicerequest ', "LEFT" );
						$this->db->join ( 'cloudcoverage AS cc', 'al.idcloudcover = cc.idcloudcoverage ', "LEFT" );
						$this->db->join ( 'adultsurveillancedetails AS asd', 'al.idadultsurveillance = asd.idadultsurveillance ', "LEFT" );
						$this->db->join ( 'mosquitospecies AS ms', 'asd.idmosquitospecies = ms.idmosquitospecies ', "LEFT" );
						// $this->db->join('genuses AS gn','ms.idgenus = gn.idgenus ',"LEFT");
						$this->db->join ( 'users AS usr', 'al.idinspector = usr.iduser', "LEFT" );
						$this->db->join ( 'userlocationassignment AS ula', "usr.iduser = ula.iduser", 'INNER' );
						$this->db->join ( 'locations AS lc', "s.idlocation = lc.idlocation", 'INNER' );
						// $this->db->where('s.idlocation',$this->session->userdata('idlocation'));
						$this->db->where ( 'al.idlocation', $this->session->userdata ( 'idlocation' ) );
						$this->db->where ( 'al.isdeleted', '0' );
						$this->db->where ( 'al.setdate >=', $startdate );
						$this->db->where ( 'al.setdate <=', $enddate );
						$this->db->group_by ( 'asd.idadultsurveillancedetail' );
						$this->db->order_by ( 'al.pudate', 'DESC' );
						$this->db->order_by ( 'al.putime', 'DESC' );
						
						// (SELECT adst.count,m.mosquitospecies,g.genus FROM adultsurveillance AS a LEFT JOIN adultsurveillancedetails AS adst ON a.idadultsurveillance = adst.idadultsurveillance LEFT JOIN mosquitospecies AS m ON adst.idmosquitospecies = m.idmosquitospecies LEFT JOIN genuses AS g ON m.idgenus = g.idgenus)
						break;
				}
				break;
			case '2' :
				switch ($option) {
					case 'Sentinel' :
						$this->db->select ( 'sc.*,
								s.*,
								z.*,
								scl.*,
								ast.*,
								vt.*,
								stt.*,
								lr.*,
								scs.bandid' );
						$this->db->from ( 'sentinelchicken as sc' );
						$this->db->join ( 'sentinelchickenlabs scl', 'sc.idsentinelchicken= scl.idsentinelchicken', 'LEFT' );
						$this->db->join ( 'sentinelchickensamples scs', 'scs.idsentinelchicken= scl.idsentinelchicken', 'LEFT' );
						$this->db->join ( 'sites AS s ', 'sc.idsite = s.idsite ', "LEFT" );
						$this->db->join ( 'zones AS z', ' s.idzone= z.idzone ', "LEFT" );
						$this->db->join ( 'states AS stt', ' s.idstate= stt.idstate ', "LEFT" );
						$this->db->join ( 'assaytypes as ast', 'scl.idassaytype= ast.idassaytype', 'LEFT' );
						$this->db->join ( 'virustypes AS vt', 'scl.idvirustype = vt.idvirustype', 'LEFT' );
						$this->db->join ( 'labresults as lr', 'scl.idlabresult = lr.idlabresult', 'LEFT' );
						
						// $this->db->join('locations AS l',"s.idlocation = l.idlocation",'INNER');
						// $this->db->join('userlocationassignment AS ula',"l.idlocation = ula.idlocation ",'INNER');
						$this->db->where ( "sc.idlocation", $this->session->userdata ( 'idlocation' ) );
						// $this->db->where("z.idlocation", $this->session->userdata('idlocation'));
						$this->db->where ( 'scl.isdeleted', '0' );
						$this->db->where ( 'scl.datebled >=', $startdate );
						$this->db->where ( 'scl.datebled <=', $enddate );
						$this->db->group_by ( 'scl.datesubmitted' );
						$this->db->order_by ( 'scl.datebled', 'DESC' );
						
						// $this->db->join('states AS st','sc.idstate = st.idstate','LEFT');
						
						break;
					case 'Corvid' :
						$this->db->select ( 'cl.*,
								st.*,
								z.*,
								s.*,
								stt.*,
								avs.avianspecies,
								ast.assaytype,
								lr.labresult,
								vt.virustypes' );
						$this->db->from ( 'corvidlabs AS cl' );
						$this->db->join ( 'sites AS s ', 'cl.idsite = s.idsite ', "LEFT" );
						$this->db->join ( 'sitetypes as st', 'cl.idsitetype = st.idsitetype', 'LEFT' );
						$this->db->join ( 'states AS stt', ' s.idstate= stt.idstate ', "LEFT" );
						$this->db->join ( 'zones AS z', ' s.idzone= z.idzone ', "LEFT" );
						$this->db->join ( 'avianspecies AS avs', 'cl.idavianspecies = avs.idavianspecies', 'LEFT' );
						$this->db->join ( 'assaytypes as ast', 'cl.idassaytype= ast.idassaytype', 'LEFT' );
						$this->db->join ( 'labresults as lr', 'cl.idlabresult = lr.idlabresult', 'LEFT' );
						$this->db->join ( 'virustypes AS vt', 'cl.idvirustype = vt.idvirustype', 'LEFT' );
						// $this->db->join('locations AS l',"s.idlocation = l.idlocation",'INNER');
						// $this->db->join('userlocationassignment AS ula',"l.idlocation = ula.idlocation ",'INNER');
						$this->db->where ( "cl.idlocation", $this->session->userdata ( 'idlocation' ) );
						// $this->db->where("z.idlocation", $this->session->userdata('idlocation'));
						$this->db->where ( 'cl.isdeleted', '0' );
						$this->db->where ( 'cl.datecollected >=', $startdate );
						$this->db->where ( 'cl.datecollected <=', $enddate );
						break;
					default :
						$this->db->select ( 'al.*,
								t.*,
								z.*,
								s.*,
								ts.*,
								ast.*,
								ms.*,
								gn.*,
								lr.*,
								vt.*,
								ads.*,
								usr.firstname,
								al.comments,
								usr.lastname,
								ads.comments AS trapcomments,
								bt.*,
								stt.statename,
								ast.*,
								cc.*,
								ws.windspeed,
								hr.humidityrange,
								cc.cloudcoverage,
								tr.temprange,
								usrs.firstname fn, 
								usrs.lastname ln' );
						$this->db->from ( 'arbovirallabs AS al ' );
						$this->db->join ( 'traps AS t', 'al.idtrap = t.idtrap', 'LEFT' );
						$this->db->join ( 'sites AS s ', 't.idsite = s.idsite ', 'LEFT' );
						$this->db->join ( 'zones AS z', ' z.idzone= s.idzone ', 'LEFT' );
						$this->db->join ( 'mosquitospecies as ms', 'al.idmosquitospecies=ms.idmosquitospecies', 'LEFT' );
						$this->db->join ( 'genuses AS gn', 'ms.idgenus = gn.idgenus ', 'LEFT' );
						$this->db->join ( 'virustypes AS vt', 'al.idvirustype = vt.idvirustype', 'LEFT' );
						$this->db->join ( 'labresults as lr', 'al.idlabresult = lr.idlabresult', 'LEFT' );
						$this->db->join ( 'traptypes AS ts ', 't.idtraptype = ts.idtraptype ', 'LEFT' );
						$this->db->join ( 'baittypes AS bt', 't.idbaittype = bt.idbaittype ', 'LEFT' );
						$this->db->join ( 'assaytypes as ast', 'al.idassaytype= ast.idassaytype', 'LEFT' );
						$this->db->join ( 'adultsurveillance as ads', 'al.idadultsurveillance = ads.idadultsurveillance', 'LEFT' );
						$this->db->join ( 'users AS usr', 'ads.idinspector = usr.iduser', 'LEFT' );
						$this->db->join ( 'users AS usrs', 'al.idlabtechnician = usrs.iduser', "LEFT" );
						$this->db->join ( 'states AS stt', ' s.idstate= stt.idstate ', 'LEFT' );
						$this->db->join ( 'cloudcoverage AS cc', 'ads.idcloudcover= cc.idcloudcoverage', 'LEFT' );
						$this->db->join ( 'windspeeds as ws', 'ads.idwindspeed = ws.idwindspeed', 'LEFT' );
						$this->db->join ( 'humidityranges as hr', 'ads.idhumidityrange = hr.idhumidityrange', 'LEFT' );
						$this->db->join ( 'tempranges as tr', 'ads.idtemprange = tr.idtemprange', 'LEFT' );
						// $this->db->join('userlocationassignment AS ula',"usr.iduser = ula.iduser",'INNER');
						// $this->db->join('locations AS lc',"s.idlocation = lc.idlocation",'INNER');
						$this->db->where ( 'al.idlocation', $this->session->userdata ( 'idlocation' ) );
						// $this->db->where("z.idlocation", $this->session->userdata('idlocation'));
						// $this->db->where('ula.idlocation',$this->session->userdata('idlocation'));
						$this->db->where ( 'al.isdeleted', '0' );
						$this->db->where ( 'testdate >=', $startdate );
						$this->db->where ( 'testdate <=', $enddate );
						$this->db->order_by ( 'ads.pudate', 'DESC' );
						$this->db->order_by ( 'ads.putime', 'DESC' );
						
						break;
				}
				
				break;
			case '3' :
				
				$this->data = $this->getServiceRequestData ( $startdate, $enddate, '', '', $option, $sub, $action );
				$flg = 1;
				break;
			case '4' :
				
				switch ($option) {
					case 'adult' :
						$this->db->select ( 'adt.idadulticidetreatment, 
								adt.latitude, 
								adt.longitude, 
								adt.date, 
								adt.time, 
								adt.equipmentserial, 
								adt.odometerstart, 
								adt.odometerend, 
								adt.applicationstartdate, 
								adt.applicationstarttime,
								adt.applicationenddate, 
								adt.applicationendtime, 
								adt.tempatthreem, 
								adt.tempattenm, 
								adt.finishedmix, 
								adt.flowrate, 
								adt.comments, 
								adt.totalareatreated, 
								adt.totalproductapplied, 
								treatmentjustification.justification, 
								s.site, 
								s.address1, 
								s.address2, 
								s.city, 
								s.postalcode, 
								st.sitetype, 
								z.zone, 
								at.unitarea, 
								frt.flowrate AS flowratetype, 
								sty.systemtype, 
								apm.applicationmethod, 
								tr.temprange AS starttemp, 
								tre.temprange AS endtemp, 
								hr.humidityrange, 
								CONCAT(ws.windspeed, " ", wd.winddirection) AS windspeed,
								cc.cloudcoverage, 
								p.productname, 
								p.productcode,
                                p.productlink, 
								p.onhand, 
								pu.unitproduct, 
								fm.formulation, 
								mr.mixratio, 
								ds.dilutent, 
								adt.applicationrate, 
								aru.applicationrateuom, 
								aau.applicationrateuom, 
								ps.productsize, 
								pm.manufacturer, 
								pp.potency, 
								pcksz.packsize, 
								usr.firstname, 
								usr.middlename, 
								usr.lastname, 
								usr.mobilephone, 
								stt.statename, 
								fmx.unitfinishedmix, 
								CONCAT(prpf.ratename, " ", prpf.flowvalue, " ", punit.unitproduct, "/", area_trtd.unitarea) AS rate_type', TRUE );
						$this->db->from ( 'adulticidetreatments AS adt' );
						$this->db->join ( 'sites AS s', 'adt.idsite=s.idsite', 'LEFT' );
						$this->db->join ( 'treatmentjustification', 'adt.trtmnt_justification = treatmentjustification.idtreatmentjustification', 'LEFT' );
						$this->db->join ( 'sitetypes as st', 's.idsitetype = st.idsitetype', 'LEFT' );
						$this->db->join ( 'zones AS z', ' s.idzone= z.idzone ', "LEFT" );
						$this->db->join ( 'users AS usr', 'adt.idapplicator = usr.iduser', "LEFT" );
						$this->db->join ( 'servicerequests as sr', 'adt.idservicerequest= sr.idservicerequest', 'LEFT' );
						$this->db->join ( 'systemtypes as sty', 'adt.idsystemtype = sty.idsystemtype', 'LEFT' );
						$this->db->join ( 'applicationmethods as apm', 'adt.idapplicationmethod = apm.idapplicationmethods', 'LEFT' );
						$this->db->join ( 'tempranges as tr', 'adt.idtempatstart = tr.idtemprange', 'LEFT' );
						$this->db->join ( 'tempranges as tre', 'adt.idtempatend = tre.idtemprange', 'LEFT' );
						$this->db->join ( 'humidityranges as hr', 'adt.idhumidityrange = hr.idhumidityrange', 'LEFT' );
						$this->db->join ( 'windspeeds as ws', 'adt.idwindspeed = ws.idwindspeed', 'LEFT' );
                        $this->db->join ( 'winddirections as wd', 'adt.idwinddirection = wd.idwinddirection', 'LEFT' );
						$this->db->join ( 'cloudcoverage as cc', 'adt.idcloudcover = cc.idcloudcoverage', 'LEFT' );
						$this->db->join ( 'products as p', 'adt.idproduct=p.idproduct', 'LEFT' );
						$this->db->join ( 'productpreferences AS prpf', 'adt.idproductpreferences = prpf.idproductpreference', 'LEFT' );
						$this->db->join ( 'products AS prdct', 'prpf.idproduct = prdct.idproduct', 'LEFT' );
						$this->db->join ( 'productunit AS punit', 'prpf.idproductuom = punit.idproductunit', 'LEFT' );
						$this->db->join ( 'area_treated AS area_trtd', 'prpf.idareatreated = area_trtd.idareatreated', 'LEFT' );
						$this->db->join ( 'formulations as fm', 'p.idformulation=fm.idformulation', 'LEFT' );
						$this->db->join ( 'mixratios as mr', 'adt.idmixratio=mr.idmixratio', 'LEFT' );
						$this->db->join ( 'dilutents as ds', 'adt.iddilutent=ds.iddilutent', 'LEFT' );
						$this->db->join ( 'applicationratetypes as art', 'adt.idapplicationratetype=art.idapplicationratetypes', 'LEFT' );
						$this->db->join ( 'applicationrateuom as aru', 'adt.idapplicationrateuom=aru.idapplicationrateuom', 'LEFT' );
						$this->db->join ( 'flowratetypes as frt', 'adt.idflowratetypes=frt.idflowratetype', 'LEFT' );
						$this->db->join ( 'productsizes AS ps', 'p.idproductsize= ps.idproductsize', 'LEFT' );
						$this->db->join ( 'productunit AS pu', 'adt.iduomtotalproductapplied= pu.idproductunit', 'LEFT' );
						$this->db->join ( 'packsizes AS pcksz', 'p.idpacksize = pcksz.idpacksize', 'LEFT' );
						$this->db->join ( 'productmanufacturers as pm', 'p.idmanufacturer=pm.idmanufacturer', 'LEFT' );
						$this->db->join ( 'productpotency as pp', 'p.idpotency=pp.idpotency', 'LEFT' );
						$this->db->join ( 'area_treated as at', 'adt.iduomtotalareatreated=at.idareatreated', 'LEFT' );
						$this->db->join ( 'applicationrateuom as aau', 'adt.idapplicationrateuom=aau.idapplicationrateuom', 'LEFT' );
						$this->db->join ( 'states AS stt', ' s.idstate= stt.idstate ', "LEFT" );
						$this->db->join ( 'finishedmix as fmx', 'adt.iduomfinishedmix= fmx.idfinishedmix', 'LEFT' );
						$this->db->where ( 'adt.idlocation', $this->session->userdata ( 'idlocation' ) );
						$this->db->where ( 'adt.isdeleted', '0' );
						$this->db->where ( 'adt.date >=', $startdate );
						$this->db->where ( 'adt.date <=', $enddate );
						$this->db->order_by ( 'adt.date', 'DESC' );
						$this->db->order_by ( 'adt.time', 'DESC' );
						
						break;
					default :
						$this->db->select ( 'lt.idlarvaltreatment, 
								lt.latitude, 
								lt.longitude, 
								lt.date, 
								lt.time, 
								lt.larvaepresent, 
								lt.equipemtnid, 
								lt.sourcereduction, 
								lt.sourcereductioncomments, 
								lt.applicationrate, 
								lt.finishedmix, 
								lt.totalproductapplied, 
								lt.totalareatreated, 
								lt.post_trtmnt_inspection, 
								lt.post_trtmnt_date, 
								lt.comments, 
								lt.totalcount, 
								lt.iswaterofus, 
								treatmentjustification.justification, 
								lt.locationkey, 
								lt.legalentitykey, 
								s.site, 
								s.address1, 
								s.address2, 
								s.city, 
								s.postalcode, 
								st.sitetype, 
								syt.systemtype, 
								z.zone, 
								ss.sitestatus, 
								wc.weathercondition, 
								ins.instar, 
								ms.mosquitospecies, 
								CONCAT(usr.firstname, " ", usr.middlename, " ", usr.lastname) AS applicatorname, 
								usr.mobilephone, 
								ams.applicationmethod, 
                                CONCAT(ws.windspeed, " ", wd.winddirection) AS windspeed,
								p.productname, 
								p.productcode, 
								f.formulation, 
								aru.applicationrateuom, 
								punit.unitproduct, 
								art.applicationratetype, 
								gn.genus, 
								stt.statename, 
								fmx.unitfinishedmix, 
								mxr.mixratio, 
								ps.productsize, 
								p.onhand, 
								pcksz.packsize, 
								pm.manufacturer, 
								pp.potency, 
								p.productlink, 
								att.unitarea, 
								wtr.watertemprange , 
								CONCAT(prpf.ratename, " ", prpf.flowvalue, " ", pu.unitproduct, "/", area_trtd.unitarea) AS rate_type', TRUE );
						$this->db->from ( 'larvaltreatments as lt' );
						$this->db->join ( 'treatmentjustification', 'lt.trtmnt_justification = treatmentjustification.idtreatmentjustification', 'LEFT' );
						$this->db->join ( 'sites AS s', 'lt.idsite=s.idsite', 'LEFT' );
						$this->db->join ( 'sitetypes as st', 's.idsitetype = st.idsitetype', 'LEFT' );
						$this->db->join ( 'systemtypes as syt', 'lt.idsystemtype=syt.idsystemtype ', 'LEFT' );
						$this->db->join ( 'zones AS z', ' s.idzone= z.idzone ', "LEFT" );
						$this->db->join ( 'sitestatuses as ss', 'lt.idsitestatus=ss.idsitestatus', 'LEFT' );
						$this->db->join ( 'weatherconditions wc', 'lt.idweatherconditions = wc.idweathercondition', 'LEFT' );
						$this->db->join ( 'watertempranges as wtr', 'lt.idwatertemp=wtr.idwatertemprange ', 'LEFT' );
						$this->db->join ( 'instar as ins', 'lt.idinstar = ins.idinstar', 'LEFT' );
						$this->db->join ( 'larvatreatmentdetails as ldts', 'ldts.idlarvaltreatment=lt.idlarvaltreatment', 'LEFT' );
						$this->db->join ( 'mosquitospecies as ms', 'ldts.idmosquitospecies=ms.idmosquitospecies', 'LEFT' );
						$this->db->join ( 'genuses AS gn', 'ms.idgenus = gn.idgenus ', "LEFT" );
						$this->db->join ( 'users AS usr', 'lt.idapplicator = usr.iduser', "LEFT" );
						$this->db->join ( 'applicationmethods ams ', 'lt.idapplicationmethod = ams.idapplicationmethods', 'LEFT' );
						$this->db->join ( 'products as p', 'lt.idproduct=p.idproduct', 'LEFT' );
						$this->db->join ( 'productpreferences AS prpf', 'lt.idproductpreferences = prpf.idproductpreference', 'LEFT' );
						$this->db->join ( 'products AS prdct', 'prpf.idproduct = prdct.idproduct', 'LEFT' );
						$this->db->join ( 'productunit AS pu', 'prpf.idproductuom = pu.idproductunit', 'LEFT' );
						$this->db->join ( 'area_treated AS area_trtd', 'prpf.idareatreated = area_trtd.idareatreated', 'LEFT' );
						$this->db->join ( 'formulations as f', 'p.idformulation=f.idformulation', 'LEFT' );
						$this->db->join ( 'applicationrateuom as aru', ' lt.idapplicationrateuom=aru.idapplicationrateuom', 'LEFT' );
						$this->db->join ( 'applicationratetypes as art', 'lt.idapplicationratetype= art.idapplicationratetypes', 'LEFT' );
						$this->db->join ( 'states AS stt', ' s.idstate= stt.idstate ', "LEFT" );
						$this->db->join ( 'finishedmix as fmx', 'lt.iduomfinishedmix= fmx.idfinishedmix', 'LEFT' );
						$this->db->join ( 'mixratios as mxr', 'lt.idmixratio= mxr.idmixratio', 'LEFT' );
                        $this->db->join ( 'windspeeds as ws', 'lt.idwindspeed = ws.idwindspeed', 'LEFT' );
                        $this->db->join ( 'winddirections as wd', 'lt.idwinddirection = wd.idwinddirection', 'LEFT' );
						$this->db->join ( 'productsizes AS ps', 'p.idproductsize= ps.idproductsize', 'LEFT' );
						$this->db->join ( 'productunit AS punit', 'lt.iduomtotalproductapplied= punit.idproductunit', 'LEFT' );
						$this->db->join ( 'packsizes AS pcksz', 'p.idpacksize = pcksz.idpacksize', 'LEFT' );
						$this->db->join ( 'productmanufacturers as pm', 'p.idmanufacturer=pm.idmanufacturer', 'LEFT' );
						$this->db->join ( 'productpotency as pp', 'p.idpotency=pp.idpotency', 'LEFT' );
						$this->db->join ( 'area_treated AS att', 'lt.iduomtotalareatreated = att.idareatreated', 'LEFT' );
						$this->db->where ( 'lt.idlocation', $this->session->userdata ( 'idlocation' ) );
						$this->db->where ( 'lt.isdeleted', '0' );
						$this->db->where ( 'lt.date >=', $startdate );
						$this->db->where ( 'lt.date <=', $enddate );
						$this->db->order_by ( 'lt.date', 'DESC' );
						$this->db->order_by ( 'lt.time', 'DESC' );
						
						break;
				}
				
				break;
			
			case '5' :
				$this->db->select ( 'w.*,
						ws.*,
						s.*,
						sty.sensortype,
						wc.weathercondition,
						wss.windspeed,
						trs.temprange,
						hr.humidityrange,
						cc.cloudcoverage,
						stt.statename' );
				$this->db->from ( 'weather as w' );
				$this->db->join ( 'weathersensors as ws', 'w.idweathersensor= ws.idweathersensor', 'LEFT' );
				$this->db->join ( 'sites AS s', 'ws.idsite=s.idsite', 'LEFT' );
				$this->db->join ( 'sensortypes AS sty', ' ws.idsensortype= sty.idsensortype ', "LEFT" );
				$this->db->join ( 'weatherconditions AS wc', ' w.idweatherconditions= wc.idweathercondition ', "LEFT" );
				$this->db->join ( 'windspeeds AS wss', ' w.idwindspeed= wss.idwindspeed ', "LEFT" );
				$this->db->join ( 'tempranges AS trs', ' w.idtemprange= trs.idtemprange ', "LEFT" );
				$this->db->join ( 'humidityranges AS hr', ' w.idhumidityrange= hr.idhumidityrange ', "LEFT" );
				$this->db->join ( 'cloudcoverage AS cc', ' w.idcloudcoverage= cc.idcloudcoverage ', "LEFT" );
				$this->db->join ( 'states AS stt', ' s.idstate= stt.idstate ', "LEFT" );
				
				// $this->db->join('locations AS lc',"s.idlocation = lc.idlocation",'INNER');
				$this->db->where ( 'w.idlocation', $this->session->userdata ( 'idlocation' ) );
				$this->db->where ( 'w.isdeleted', '0' );
				$this->db->where ( 'w.date >=', $startdate );
				$this->db->where ( 'w.date <=', $enddate );
				$this->db->order_by ( 'w.date', 'DESC' );
				
				break;
			case '6' :
				$this->db->select ( 's.*,
						z.zone,
						st.sitetype,
						stt.statename' );
				$this->db->from ( 'sites AS s' );
				// $this->db->join('sitezoneassignment AS sz','s.idsite = sz.idsite ',"LEFT");
				$this->db->join ( 'zones AS z', 's.idzone = z.idzone', 'LEFT' );
				$this->db->join ( 'sitetypes AS st', 's.idsitetype = st.idsitetype', 'LEFT' );
				$this->db->join ( 'states AS stt', ' s.idstate = stt.idstate ', "LEFT" );
				$this->db->join ( 'locations AS lc', "s.idlocation = lc.idlocation", 'INNER' );
				$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
				$this->db->where ( "z.idlocation", $this->session->userdata ( 'idlocation' ) );
				$this->db->order_by ( 's.site', 'ASC' );
				
				break;
			case '7' :
				$this->db->select ( 'z.*' );
				$this->db->from ( 'zones as z' );
				
				// $this->db->join('locations AS lc',"z.idlocation = lc.idlocation",'INNER');
				$this->db->where ( "z.idlocation", $this->session->userdata ( 'idlocation' ) );
				$this->db->order_by ( 'z.zone' );
				
				break;
			case '8' :
				$this->db->select ( 't.*,
						ts.*,
						s.*,
						bt.*,
						z.zone,
						st.statename' );
				$this->db->from ( 'traps AS t' );
				$this->db->join ( 'traptypes AS ts ', 't.idtraptype = ts.idtraptype ', 'LEFT' );
				$this->db->join ( 'sites AS s ', 't.idsite = s.idsite ', 'LEFT' );
				$this->db->join ( 'baittypes AS bt', 't.idbaittype = bt.idbaittype ', 'LEFT' );
				$this->db->join ( 'zones AS z', ' s.idzone = z.idzone ', 'LEFT' );
				$this->db->join ( 'states AS st', ' st.idstate = s.idstate ', 'LEFT' );
				$this->db->join ( 'locations AS lc', "s.idlocation = lc.idlocation", 'INNER' );
				$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
				$this->db->where ( "z.idlocation", $this->session->userdata ( 'idlocation' ) );
				
				break;
			case '9' :
				$this->db->select ( 'p.*,
						pi.min_amount,
						pi.max_amount,
						pi.notes ,
						pp.potency,
						ps.productsize,
						pcksz.packsize,
						pm.manufacturer,
						pc.productcategory,
						fm.formulation', TRUE );
				$this->db->from ( 'products As p' );
				$this->db->join ( 'product_inventory AS pi', 'pi.idproduct= p.idproduct', 'LEFT' );
				$this->db->join ( 'productpotency AS pp', 'p.idpotency= pp.idpotency', 'LEFT' );
				$this->db->join ( 'productcategories AS pc', 'p.idcategory= pc.idproductcategory', 'LEFT' );
				$this->db->join ( 'productsizes AS ps', 'p.idproductsize= ps.idproductsize', 'LEFT' );
				$this->db->join ( 'packsizes AS pcksz', 'p.idpacksize = pcksz.idpacksize', 'LEFT' );
				$this->db->join ( 'productmanufacturers as pm', 'p.idmanufacturer=pm.idmanufacturer', 'LEFT' );
				$this->db->join ( 'formulations as fm', 'p.idformulation=fm.idformulation', 'LEFT' );
				$this->db->join ( 'locations AS lc', "p.idlocation = lc.idlocation", 'LEFT' );
				$this->db->where ( 'p.idlocation', $this->session->userdata ( 'idlocation' ) );
				$this->db->order_by ( 'p.productname', 'ASC' );
				break;
			case '10' :
				$this->db->select ( 'pi.*,
						p.*,
						usr.*' );
				$this->db->from ( 'product_inventory AS pi' );
				$this->db->join ( 'products AS p', "pi.idproduct =p.idproduct", 'LEFT' );
				$this->db->join ( 'locations AS lc', "p.idlocation = lc.idlocation", 'LEFT' );
				$this->db->join ( 'users AS usr', 'pi.changed_by = usr.iduser', 'LEFT' );
				$this->db->where ( 'p.idlocation', $this->session->userdata ( 'idlocation' ) );
				$this->db->order_by ( 'p.productname', 'ASC' );
				break;
			
			case '11' :
				$this->db->select ( 'ws.*,
						z.*,
						s.*,
						usr.*,
						st.statename,
						sty.sensortype' );
				$this->db->from ( 'weathersensors as ws' );
				// $this->db->join('weather AS w','ws.idweathersensor = w.idweathersensor','LEFT');
				$this->db->join ( 'users AS usr', 'ws.idinspector = usr.iduser', "LEFT" );
				$this->db->join ( 'sites AS s ', 'ws.idsite = s.idsite ', "LEFT" );
				$this->db->join ( 'zones AS z', 's.idzone= z.idzone ', "LEFT" );
				$this->db->join ( 'states AS st', 's.idstate= st.idstate ', "LEFT" );
				$this->db->join ( 'sensortypes AS sty', ' ws.idsensortype= sty.idsensortype ', "LEFT" );
				$this->db->join ( 'locations AS lc', "s.idlocation = lc.idlocation", 'INNER' );
				$this->db->where ( 'ws.idlocation', $this->session->userdata ( 'idlocation' ) );
				$this->db->where ( 'ws.isdeleted', '0' );
				// $this->db->where("z.idlocation", $this->session->userdata('idlocation'));
				$this->db->order_by ( 'ws.dateinstalled', 'DESC' );
				
				break;
			default :
				$this->db->select ( 'l.*,
						z.zone,
						s.*,
						st.sitetype,
						ss.sitestatus,
						state.statename,
						m.mosquitospecies,
						g.genus,
						wt.watertemprange,
						usr.firstname,
						usr.middlename,
						usr.lastname,
						usr.officephone,
						usr.mobilephone,
						i.instar,lsd.*' );
				$this->db->from ( 'larvalsurveillance AS l' );
				$this->db->join ( 'sites AS s', 'l.idsite = s.idsite', "LEFT" );
				$this->db->join ( 'zones AS z', 's.idzone = z.idzone', "LEFT" );
				$this->db->join ( 'sitestatuses AS ss', 'l.idsitestatus = ss.idsitestatus', "LEFT" );
				$this->db->join ( 'sitetypes AS st', 's.idsitetype = st.idsitetype', "LEFT" );
				$this->db->join ( 'larvalsurveillancedetails AS lsd', 'l.idlarvalsurveillance = lsd.idlarvalsurveillance', "LEFT" );
				$this->db->join ( 'mosquitospecies AS m', 'lsd.idmosquitospecies = m.idmosquitospecies', "LEFT" );
				$this->db->join ( 'genuses AS g', 'm.idgenus = g.idgenus', "LEFT" );
				$this->db->join ( 'watertempranges AS wt', 'l.idwatertemprange = wt.idwatertemprange', "LEFT" );
				$this->db->join ( 'users AS usr', 'l.idinspector = usr.iduser', "LEFT" );
				$this->db->join ( 'states AS state', 's.idstate = state.idstate', "LEFT" );
				$this->db->join ( 'instar AS i', 'l.idinstar = i.idinstar', "LEFT" );
				// $this->db->join('userlocationassignment AS ula',"usr.iduser = ula.iduser",'INNER');
				// $this->db->join('locations AS lcs',"s.idlocation = lcs.idlocation",'INNER');
				$this->db->where ( 'l.idlocation', $this->session->userdata ( 'idlocation' ) );
				$this->db->where ( 'l.isdeleted', '0' );
				$this->db->where ( 'l.idsite <> 0' );
				// $this->db->where("z.idlocation", $this->session->userdata('idlocation'));
				// $this->db->where("ula.idlocation", $this->session->userdata('idlocation'));
				$this->db->where ( 'date >=', $startdate );
				$this->db->where ( 'date <=', $enddate );
				$this->db->order_by ( 'l.date', 'DESC' );
				$this->db->order_by ( 'l.time', 'DESC' );
				
				break;
		}
		
		if ($flg == 0) {
			$query = $this->db->get ();
			//echo $this->db->last_query();			
			$this->data = $query->result_array ();
            //print'<pre>';
//            print_r($this->data);
//            die;
		}
		return $this->data;
	}
	
	/**
	 * *********************************
	 *
	 * Functionto get service request data
	 *
	 * *
	 */
	public function getServiceRequestData_I($startdate = '', $enddate = '', $zone = '', $site = '', $status = '', $action = '') {
		$data_1 = array ();
		$j = 0;
		$mos = array ();
		
		if (! empty ( $action ) && ! is_array ( $action )) {
			$action = trim ( $action, "," );
			$action = explode ( ",", $action );
		} else if (empty ( $action ) && ! is_array ( $action ))
			$action = array (
					"1" => 'default' 
			);
			
			// print'<pre>';
			// print_r($action);
			// die;
		foreach ( $action as $k => $v ) {
			switch ($v) {
				case 'Inspection' :
					
					$this->db->select ( 'ss.*,
							z.zone,
							s.*,
							stt.statename,
							lss.idlarvalsurveillance,
							stt.statename' );
					$this->db->from ( 'servicerequests AS ss' );
					$this->db->join ( 'larvalsurveillanceservice AS lss', 'ss.idservicerequest = lss.idservicerequest', 'INNER' );
					$this->db->join ( 'sites AS s ', 'ss.idsite = s.idsite ', "LEFT" );
					$this->db->join ( 'zones AS z', ' s.idzone= z.idzone ', "LEFT" );
					$this->db->join ( 'states AS stt', ' s.idstate= stt.idstate ', "LEFT" );
					// $this->db->where("z.idlocation", $this->session->userdata('idlocation'));
					$this->db->where ( 'ss.isdeleted', '0' );
					$this->db->where ( 'ss.idsite <> 0' );
					$this->db->where ( "ss.idlocation", $this->session->userdata ( 'idlocation' ) );
					
					if (! empty ( $site )) {
						$s_site = "";
						
						if ($site [0] != "on" || $site [0] != "") {
							foreach ( $site as $k_s => $v_s ) {
								$s_site .= $v_s . ",";
							}
							
							$s_site = trim ( ",", $s_site );
							$this->db->where_in ( 's.idsite', $s_site );
						}
					}
					
					if (! empty ( $zone )) {
						$s_zone = "";
						
						if ($zone [0] != "on" || $zone [0] != "") {
							foreach ( $zone as $k_z => $v_z ) {
								$s_zone .= $v_z . ",";
							}
							
							$s_zone = trim ( ",", $s_zone );
							$this->db->where_in ( 'z.idzone', $s_zone );
						}
					}
					
					if (! empty ( $status ) && $status == "open") {
						$this->db->where ( 'opendate >=', $startdate );
						$this->db->where ( 'opendate <=', $enddate );
						$where = "(ss.closedate = '' OR ss.closedate = '0000-00-00')";
						$this->db->where ( $where );
					} else if (! empty ( $status ) && $status == "closed") {
						$this->db->where ( 'closedate >=', $startdate );
						$this->db->where ( 'closedate <=', $enddate );
						$where = "(ss.closedate != '' OR ss.closedate != '0000-00-00')";
						$this->db->where ( $where );
					} else {
						$this->db->where ( 'opendate >=', $startdate );
						$this->db->where ( 'closedate <=', $enddate );
					}
					$act = "";
					$query = $this->db->get ();
					// echo $this->db->last_query()."<br>";
					if ($query->num_rows ()) {
						foreach ( $query->result_array () as $r ) {
							$mos [$j] = $r;
							if (isset ( $r ['idlarvalsurveillance'] ) && ! empty ( $r ['idlarvalsurveillance'] ))
								$mos [$j] ['inspection'] = "Yes";
							else
								$mos [$j] ['inspection'] = "No";
							
							$this->db->select ( 'd.disposition' );
							$this->db->from ( 'dispositions AS d' );
							$this->db->join ( 'servicerequestsdetail AS srd', 'd.iddispositions = srd.iddispositions', 'LEFT' );
							$this->db->join ( 'servicerequests AS sr', 'srd.idservicerequest = sr.idservicerequest', 'LEFT' );
							$this->db->where ( 'sr.idservicerequest', $r ['idservicerequest'] );
							
							$query1 = $this->db->get ();
							
							if ($query1->num_rows ()) {
								foreach ( $query1->result_array () as $r1 ) {
									$act .= $r1 ['disposition'] . "<br/>";
								}
							}
							$mos [$j] ['action'] = $act;
							$mos [$j] ['treatment'] = "No";
							$mos [$j] ['surveillance'] = "No";
							$j ++;
							$data_1 [] = $r ['idservicerequest'];
						}
					}
					break;
				case 'Surveillance' :
					$this->db->select ( 'ss.*,
							z.zone,
							s.*,
							ads.idadultsurveillance,
							stt.statename' );
					$this->db->from ( 'servicerequests AS ss' );
					$this->db->join ( 'adultsurveillanceservice AS ads', 'ss.idservicerequest = ads.idservicerequest', 'INNER' );
					$this->db->join ( 'sites AS s ', 'ss.idsite = s.idsite ', "LEFT" );
					$this->db->join ( 'zones AS z', ' s.idzone= z.idzone ', "LEFT" );
					$this->db->join ( 'states AS stt', ' s.idstate= stt.idstate ', "LEFT" );
					// $this->db->where("z.idlocation", $this->session->userdata('idlocation'));
					$this->db->where ( 'ss.isdeleted', '0' );
					$this->db->where ( "ss.idlocation", $this->session->userdata ( 'idlocation' ) );
					
					if (! empty ( $site )) {
						$s_site = "";
						
						if ($site [0] != "on" || $site [0] != "") {
							foreach ( $site as $k_s => $v_s ) {
								$s_site .= $v_s . ",";
							}
							
							$s_site = trim ( ",", $s_site );
							$this->db->where_in ( 's.idsite', $s_site );
						}
					}
					
					if (! empty ( $zone )) {
						$s_zone = "";
						
						if ($zone [0] != "on" || $zone [0] != "") {
							foreach ( $zone as $k_z => $v_z ) {
								$s_zone .= $v_z . ",";
							}
							
							$s_zone = trim ( ",", $s_zone );
							$this->db->where_in ( 'z.idzone', $s_zone );
						}
					}
					
					if (! empty ( $status ) && $status == "open") {
						$this->db->where ( 'opendate >=', $startdate );
						$this->db->where ( 'opendate <=', $enddate );
						$where = "(ss.closedate = '' OR ss.closedate = '0000-00-00')";
						$this->db->where ( $where );
					} else if (! empty ( $status ) && $status == "closed") {
						$this->db->where ( 'opendate >=', $startdate );
						$this->db->where ( 'opendate <=', $enddate );
						$where = "(ss.closedate != '' AND ss.closedate != '0000-00-00')";
						$this->db->where ( $where );
					} else {
						$where = " (ss.opendate >= '$startdate' AND ss.opendate <= '$enddate') AND ((ss.closedate >= '$startdate' AND ss.closedate <= '$enddate') OR (ss.closedate = '0000-00-00' OR ss.closedate = '1970-01-01'OR ss.closedate = ''))";
						// $this->db->where('opendate >=', $startdate);
						// $this->db->where('closedate <=', $enddate);
						$this->db->where ( $where );
					}
					$act = "";
					$query = $this->db->get ();
					// echo $this->db->last_query()."<br>";
					if ($query->num_rows ()) {
						foreach ( $query->result_array () as $r ) {
							$mos [$j] = $r;
							$mos [$j] ['inspection'] = "No";
							$mos [$j] ['treatment'] = "No";
							
							if (isset ( $r ['idadultsurveillance'] ) && ! empty ( $r ['idadultsurveillance'] ))
								$mos [$j] ['surveillance'] = "Yes";
							else
								$mos [$j] ['surveillance'] = "No";
							
							$this->db->select ( 'd.disposition' );
							$this->db->from ( 'dispositions AS d' );
							$this->db->join ( 'servicerequestsdetail AS srd', 'd.iddispositions = srd.iddispositions', 'LEFT' );
							$this->db->join ( 'servicerequests AS sr', 'srd.idservicerequest = sr.idservicerequest', 'LEFT' );
							$this->db->where ( 'sr.idservicerequest', $r ['idservicerequest'] );
							
							$query1 = $this->db->get ();
							
							if ($query1->num_rows ()) {
								foreach ( $query1->result_array () as $r1 ) {
									$act .= $r1 ['disposition'] . "<br/>";
								}
							}
							$mos [$j] ['action'] = $act;
							$j ++;
							$data_1 [] = $r ['idservicerequest'];
						}
					}
					break;
				case 'Treatment' :
					$this->db->select ( 'ss.*,
							z.zone,
							s.*,
							adts.idadulticidetreatment,
							lts.idlarvaltreatment,
							stt.statename' );
					$this->db->from ( 'servicerequests AS ss' );
					$this->db->join ( 'adulticidetreatmentsservice AS adts', 'ss.idservicerequest = adts.idservicerequest', 'INNER' );
					$this->db->join ( 'larvaltreatmentservice AS lts', 'ss.idservicerequest = lts.idservicerequest', 'INNER' );
					$this->db->join ( 'sites AS s ', 'ss.idsite = s.idsite ', "LEFT" );
					$this->db->join ( 'zones AS z', ' s.idzone= z.idzone ', "LEFT" );
					$this->db->join ( 'states AS stt', ' s.idstate= stt.idstate ', "LEFT" );
					// $this->db->where("z.idlocation", $this->session->userdata('idlocation'));
					$this->db->where ( 'ss.isdeleted', '0' );
					$this->db->where ( "ss.idlocation", $this->session->userdata ( 'idlocation' ) );
					
					if (! empty ( $site )) {
						$s_site = "";
						
						if ($site [0] != "on" || $site [0] != "") {
							foreach ( $site as $k_s => $v_s ) {
								$s_site .= $v_s . ",";
							}
							
							$s_site = trim ( ",", $s_site );
							$this->db->where_in ( 's.idsite', $s_site );
						}
					}
					
					if (! empty ( $zone )) {
						$s_zone = "";
						
						if ($zone [0] != "on" || $zone [0] != "") {
							foreach ( $zone as $k_z => $v_z ) {
								$s_zone .= $v_z . ",";
							}
							
							$s_zone = trim ( ",", $s_zone );
							$this->db->where_in ( 'z.idzone', $s_zone );
						}
					}
					
					if (! empty ( $status ) && $status == "open") {
						$this->db->where ( 'opendate >=', $startdate );
						$this->db->where ( 'opendate <=', $enddate );
						$where = "(ss.closedate = '' OR ss.closedate = '0000-00-00')";
						$this->db->where ( $where );
					} else if (! empty ( $status ) && $status == "closed") {
						$this->db->where ( 'closedate >=', $startdate );
						$this->db->where ( 'closedate <=', $enddate );
						$where = "(ss.closedate != '' OR ss.closedate != '0000-00-00')";
						$this->db->where ( $where );
					} else {
						$this->db->where ( 'closedate >=', $startdate );
						$this->db->where ( 'closedate <=', $enddate );
					}
					$act = "";
					$query = $this->db->get ();
					// echo $this->db->last_query()."<br>";
					if ($query->num_rows () > 0) {
						foreach ( $query->result_array () as $r ) {
							$mos [$j] = $r;
							$mos [$j] ['inspection'] = "No";
							$mos [$j] ['surveillance'] = "No";
							if ((isset ( $r ['idadulticidetreatment'] ) && ! empty ( $r ['idadulticidetreatment'] )) || isset ( $r ['idlarvaltreatment'] ) && ! empty ( $r ['idlarvaltreatment'] ))
								$mos [$j] ['treatment'] = "Yes";
							else
								$mos [$j] ['treatment'] = "No";
							$this->db->select ( 'd.disposition' );
							$this->db->from ( 'dispositions AS d' );
							$this->db->join ( 'servicerequestsdetail AS srd', 'd.iddispositions = srd.iddispositions', 'LEFT' );
							$this->db->join ( 'servicerequests AS sr', 'srd.idservicerequest = sr.idservicerequest', 'LEFT' );
							$this->db->where ( 'sr.idservicerequest', $r ['idservicerequest'] );
							
							$query1 = $this->db->get ();
							
							if ($query1->num_rows ()) {
								foreach ( $query1->result_array () as $r1 ) {
									$act .= $r1 ['disposition'] . "<br/>";
								}
							}
							$mos [$j] ['action'] = $act;
							$j ++;
						}
					}
					break;
				default :
					$this->db->select ( 'ss.*,
							z.zone,s.*,
							stt.statename' );
					$this->db->from ( 'servicerequests AS ss' );
					$this->db->join ( 'sites AS s ', 'ss.idsite = s.idsite ', "LEFT" );
					$this->db->join ( 'zones AS z', ' s.idzone= z.idzone ', "LEFT" );
					$this->db->join ( 'states AS stt', ' s.idstate= stt.idstate ', "LEFT" );
					$this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'INNER' );
					$this->db->where ( "ss.idlocation", $this->session->userdata ( 'idlocation' ) );
					$this->db->where ( 'ss.isdeleted', '0' );
					$this->db->order_by ( 'ss.opendate', 'DESC' );
					// $this->db->where("z.idlocation", $this->session->userdata('idlocation'));
					
					if (! empty ( $site )) {
						$s_site = "";
						
						if ($site [0] != "on" || $site [0] != "") {
							foreach ( $site as $k_s => $v_s ) {
								$s_site .= $v_s . ",";
							}
							
							$s_site = trim ( ",", $s_site );
							$this->db->where_in ( 's.idsite', $s_site );
						}
					}
					
					if (! empty ( $zone )) {
						$s_zone = "";
						
						if ($zone [0] != "on" || $zone [0] != "") {
							foreach ( $zone as $k_z => $v_z ) {
								$s_zone .= $v_z . ",";
							}
							
							$s_zone = trim ( ",", $s_zone );
							$this->db->where_in ( 'z.idzone', $s_zone );
						}
					}
					
					if (! empty ( $status ) && $status == "open") {
						$this->db->where ( 'opendate >=', $startdate );
						$this->db->where ( 'opendate <=', $enddate );
						$where = "(ss.closedate = '' OR ss.closedate = '0000-00-00')";
						$this->db->where ( $where );
					} else if (! empty ( $status ) && $status == "closed") {
						$this->db->where ( 'closedate >=', $startdate );
						$this->db->where ( 'closedate <=', $enddate );
						$where = "(ss.closedate != '' OR ss.closedate != '0000-00-00')";
						$this->db->where ( $where );
					} else {
						$this->db->where ( 'opendate >=', $startdate );
						$this->db->where ( 'closedate <=', $enddate );
					}
					$act = "";
					$query = $this->db->get ();
					// echo $this->db->last_query()."<br>";
					if ($query->num_rows () > 0) {
						foreach ( $query->result_array () as $r ) {
							$flag = "0";
							
							$this->db->select ( '*' );
							$this->db->from ( 'adulticidetreatmentsservice adts' );
							$this->db->where ( 'adts.idservicerequest', $r ['idservicerequest'] );
							
							$q = $this->db->get ();
							
							if ($q->num_rows () > 0)
								$flag = "1";
							
							$this->db->select ( '*' );
							$this->db->from ( 'adultsurveillanceservice adss' );
							$this->db->where ( 'adss.idservicerequest', $r ['idservicerequest'] );
							
							$q = $this->db->get ();
							
							if ($q->num_rows () > 0)
								$flag = "1";
							
							$this->db->select ( '*' );
							$this->db->from ( 'larvalsurveillanceservice lss' );
							$this->db->where ( 'lss.idservicerequest', $r ['idservicerequest'] );
							
							$q = $this->db->get ();
							
							if ($q->num_rows () > 0)
								$flag = "1";
							
							$this->db->select ( '*' );
							$this->db->from ( 'larvaltreatmentservice lts' );
							$this->db->where ( 'lts.idservicerequest', $r ['idservicerequest'] );
							
							$q = $this->db->get ();
							
							if ($q->num_rows () > 0)
								$flag = "1";
							
							$this->db->select ( 'd.disposition' );
							$this->db->from ( 'dispositions AS d' );
							$this->db->join ( 'servicerequestsdetail AS srd', 'd.iddispositions = srd.iddispositions', 'LEFT' );
							$this->db->join ( 'servicerequests AS sr', 'srd.idservicerequest = sr.idservicerequest', 'LEFT' );
							$this->db->where ( 'sr.idservicerequest', $r ['idservicerequest'] );
							
							$query1 = $this->db->get ();
							// echo "<br>".$this->db->last_query()."<br>";
							if ($query1->num_rows () > 0) {
								$act = '';
								foreach ( $query1->result_array () as $r1 ) {
									$act .= $r1 ['disposition'] . "<br/>";
								}
							}
							$mos [$j] = $r;
							$mos [$j] ['action'] = $act;
							$mos [$j] ['inspection'] = "No";
							$mos [$j] ['treatment'] = "No";
							$mos [$j] ['surveillance'] = "No";
							
							$j ++;
						}
					}
					break;
			}
		}
		
		// echo $this->db->last_query();
		$this->data = $mos;
		
		/// print'<pre>';
		// print_r($mos);
		// die;
		return $this->data;
		// return $query->result_array();
	}
	
	/**
	 * Function to fetch Service Request Data to display
	 * Data Export Module
	 */
	public function getServiceRequestData($startdate = '', $enddate = '', $zone = '', $site = '', $status = '', $sub = '', $action = '') {
		$data_1 = array ();
		
		$j = 0;
		
		$mos = array ();
		$flag = 0;
		
		if (! empty ( $action ) && ! is_array ( $action )) {
			$action = trim ( $action, "," );
			
			if (! empty ( $action ))
				$action = explode ( ",", $action );
			else {
				return false;
			}
			
			foreach ( $action as $ka => $va ) {
				if (empty ( $va ))
					$flag = 1;
				else
					$flag = 0;
			}
			
			if ($flag == 1)
				return $data_1;
		}
		
		// print'<pre>';
		// print_r($action);
		// die;
		
		$this->db->select ( 'ss.*,
				z.zone,
				s.*,
				stt.statename,
				CONCAT(u.firstname," ",u.middlename," ",u.lastname) AS requested_by', FALSE );
		$this->db->from ( 'servicerequests AS ss' );
		$this->db->join ( 'sites AS s ', 'ss.idsite = s.idsite ', "LEFT" );
		$this->db->join ( 'zones AS z', ' s.idzone= z.idzone ', "LEFT" );
		$this->db->join ( 'states AS stt', ' s.idstate= stt.idstate ', "LEFT" );
		$this->db->join ( 'users AS u', "ss.idrequestedby = u.iduser", 'LEFT' );
		$this->db->where ( "ss.idlocation", $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'ss.isdeleted', '0' );
		$this->db->where ( 'ss.idsite <> 0' );
		$this->db->order_by ( 'ss.opendate', 'DESC' );
		$this->db->order_by ( 'ss.opentime', 'DESC' );
		
		if (! empty ( $site )) {
			$s_site = "";
			
			if ($site [0] != "on" || $site [0] != "") {
				foreach ( $site as $k_s => $v_s ) {
					$s_site .= $v_s . ",";
				}
				
				$s_site = trim ( ",", $s_site );
				$this->db->where_in ( 's.idsite', $s_site );
			}
		}
		
		if (! empty ( $zone )) {
			$s_zone = "";
			
			if ($zone [0] != "on" || $zone [0] != "") {
				foreach ( $zone as $k_z => $v_z ) {
					$s_zone .= $v_z . ",";
				}
				
				$s_zone = trim ( ",", $s_zone );
				$this->db->where_in ( 'z.idzone', $s_zone );
			}
		}
		
		if (! empty ( $status ) && $status == "open") {
			$this->db->where ( 'opendate >=', $startdate );
			$this->db->where ( 'opendate <=', $enddate );
			$where = "(ss.closedate = '' OR ss.closedate = '0000-00-00')";
			$this->db->where ( $where );
		} else if (! empty ( $status ) && $status == "closed") {
			$this->db->where ( 'opendate >=', $startdate );
			$this->db->where ( 'opendate <=', $enddate );
			$where = "(ss.closedate != '' AND ss.closedate != '0000-00-00')";
			$this->db->where ( $where );
		} else {
			$where = " (ss.opendate >= '$startdate' AND ss.opendate <= '$enddate') AND ((ss.closedate >= '$startdate' AND ss.closedate <= '$enddate') OR (ss.closedate = '0000-00-00' OR ss.closedate = '1970-01-01'OR ss.closedate = ''))";
			$this->db->where ( $where );
		}
		$act = "";
		
		$query = $this->db->get ();
		// echo $this->db->last_query();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $r ) {
				$trt = 0;
				$sur = 0;
				$ins = 0;
				
				if (in_array ( 'treatment', $action )) {
					$this->db->select ( '*' );
					$this->db->from ( 'adulticidetreatmentsservice adts' );
					$this->db->join ( 'adulticidetreatments AS adt', "adts.idadulticidetreatment = adt.idadulticidetreatment", 'INNER' );
					$this->db->where ( 'adts.idservicerequest', $r ['idservicerequest'] );
					$this->db->where ( 'adt.idlocation', $this->session->userdata ( 'idlocation' ) );
					$this->db->where ( 'adt.isdeleted', '0' );
					$this->db->where ( 'adt.date >=', $startdate );
					$this->db->where ( 'adt.date <=', $enddate );
					$q = $this->db->get ();
					
					if ($q->num_rows () > 0)
						$trt = 1;
					
					$this->db->select ( '*' );
					$this->db->from ( 'larvaltreatmentservice lts' );
					$this->db->join ( 'larvaltreatments AS lt', "lts.idlarvaltreatment = lt.idlarvaltreatment", 'INNER' );
					$this->db->where ( 'lts.idservicerequest', $r ['idservicerequest'] );
					$this->db->where ( 'lt.idlocation', $this->session->userdata ( 'idlocation' ) );
					$this->db->where ( 'lt.isdeleted', '0' );
					$this->db->where ( 'lt.date >=', $startdate );
					$this->db->where ( 'lt.date <=', $enddate );
					$q = $this->db->get ();
					
					if ($q->num_rows () > 0)
						$trt = 1;
				}
				
				if (in_array ( 'surveillance', $action )) {
					$this->db->select ( '*' );
					$this->db->from ( 'adultsurveillanceservice adss' );
					$this->db->join ( 'adultsurveillance AS ad', "adss.idadultsurveillance = ad.idadultsurveillance", 'LEFT' );
					$this->db->where ( 'adss.idservicerequest', $r ['idservicerequest'] );
					$this->db->where ( 'ad.idlocation', $this->session->userdata ( 'idlocation' ) );
					$this->db->where ( 'ad.isdeleted', '0' );
					$this->db->where ( 'ad.pudate >=', $startdate );
					$this->db->where ( 'ad.pudate <=', $enddate );
					
					$q = $this->db->get ();
					
					if ($q->num_rows () > 0)
						$sur = 1;
				}
				
				if (in_array ( 'inspection', $action )) {
					$this->db->select ( '*' );
					$this->db->from ( 'larvalsurveillanceservice lss' );
					$this->db->join ( 'larvalsurveillance AS ls', "lss.idlarvalsurveillance = ls.idlarvalsurveillance", 'LEFT' );
					$this->db->where ( 'lss.idservicerequest', $r ['idservicerequest'] );
					$this->db->where ( 'ls.idlocation', $this->session->userdata ( 'idlocation' ) );
					$this->db->where ( 'ls.isdeleted', '0' );
					$this->db->where ( 'ls.date >=', $startdate );
					$this->db->where ( 'ls.date <=', $enddate );
					
					$q = $this->db->get ();
					
					if ($q->num_rows () > 0)
						$ins = 1;
				}
				
				$this->db->select ( 'd.disposition' );
				$this->db->from ( 'dispositions AS d' );
				$this->db->join ( 'servicerequestsdetail AS srd', 'd.iddispositions = srd.iddispositions', 'LEFT' );
				$this->db->join ( 'servicerequests AS sr', 'srd.idservicerequest = sr.idservicerequest', 'LEFT' );
				$this->db->where ( 'sr.idservicerequest', $r ['idservicerequest'] );
				$act = '';
				$query1 = $this->db->get ();
				// echo $this->db->last_query();
				if ($query1->num_rows ()) {
					foreach ( $query1->result_array () as $r1 ) {
						$act .= $r1 ['disposition'] . ";";
					}
				}
				
				$act = ! empty ( $act ) ? trim ( $act, ';' ) : '';
				$mos [$j] = $r;
				$mos [$j] ['action'] = $act;
				
				if ($trt == 1)
					$mos [$j] ['treatment'] = "Yes";
				else
					$mos [$j] ['treatment'] = "No";
				
				if ($ins == 1)
					$mos [$j] ['inspection'] = "Yes";
				else
					$mos [$j] ['inspection'] = "No";
				
				if ($sur == 1)
					$mos [$j] ['surveillance'] = "Yes";
				else
					$mos [$j] ['surveillance'] = "No";
				
				$j ++;
			}
		}
		
		$this->data = $mos;
		// print'<pre>';
		// print_r($mos);
		// die;
		return $this->data;
		// return $query->result_array();
	}
	
	/**
	 * Function to fetch Landing Data to display
	 * Data Export Module
	 */
	public function getLandingRateData($startdate = '', $enddate = '', $zone = '', $site = '') {
		$this->db->select ( 'lr.*,
				z.*,
				s.*,
				lr.*,
				hr.*,
				ws.*,
				st.*,
				usr.*,
				du.durations,
				stt.statename,
				cc.*,
				tr.*' );
		$this->db->from ( 'landingrates AS lr' );
		$this->db->join ( 'sites AS s ', 'lr.idsite = s.idsite ', "LEFT" );
		$this->db->join ( 'zones AS z', ' s.idzone= z.idzone ', "LEFT" );
		$this->db->join ( 'states AS stt', ' s.idstate= stt.idstate ', "LEFT" );
		$this->db->join ( 'tempranges AS tr', 'lr.idtemprange = tr.idtemprange ', "LEFT" );
		$this->db->join ( 'humidityranges AS hr', 'lr.idhumidityrange = hr.idhumidityrange ', "LEFT" );
		$this->db->join ( 'windspeeds AS ws', 'lr.idwindspeed = ws.idwindspeed ', "LEFT" );
		$this->db->join ( 'sitetypes as st', 's.idsitetype = st.idsitetype', 'LEFT' );
		$this->db->join ( 'users AS usr', 'lr.idinspector = usr.iduser', "LEFT" );
		$this->db->join ( 'durations AS du', 'lr.idduration = du.idduration', "LEFT" );
		$this->db->join ( 'cloudcoverage AS cc', 'lr.idcloudcoverage = cc.idcloudcoverage ', "LEFT" );
		$this->db->where ( 'lr.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'lr.isdeleted', '0' );
		$this->db->where ( 'lr.idsite <> 0' );
		// $this->db->where("z.idlocation", $this->session->userdata('idlocation'));
		// $this->db->group_by('lr.idlandingrate');
		$this->db->order_by ( 'lr.observeddate', 'DESC' );
		$this->db->order_by ( 'lr.observedtime', 'DESC' );
		
		if (! empty ( $startdate ) && ! empty ( $enddate )) {
			$this->db->where ( 'lr.observeddate >=', $startdate );
			$this->db->where ( 'lr.observeddate <=', $enddate );
		}
		
		if (! empty ( $site )) {
			$s_site = "";
			
			if ($site [0] != "on" || $site [0] != "") {
				foreach ( $site as $k_s => $v_s ) {
					$s_site .= $v_s . ",";
				}
				
				$s_site = trim ( ",", $s_site );
				$this->db->where_in ( 's.idsite', $s_site );
			}
		}
		
		if (! empty ( $zone )) {
			$s_zone = "";
			
			if ($zone [0] != "on" || $zone [0] != "") {
				foreach ( $zone as $k_z => $v_z ) {
					$s_zone .= $v_z . ",";
				}
				
				$s_zone = trim ( ",", $s_zone );
				$this->db->where_in ( 'z.idzone', $s_zone );
			}
		}
		
		$query = $this->db->get ();
		
		$mos = array ();
		$j = 0;
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->db->select ( 'm.mosquitospecies,g.genus,lsdt.count' );
				$this->db->from ( 'mosquitospecies AS m' );
				$this->db->join ( 'landingratedetails AS lsdt', 'm.idmosquitospecies = lsdt.idlocationvectorspecies', 'LEFT' );
				$this->db->join ( 'genuses AS g', 'm.idgenus = g.idgenus', 'INNER' );
				$this->db->where ( 'lsdt.idlandingrate ', $row ['idlandingrate'] );
				
				$q = $this->db->get ();
				$k = 0;
				
				$mos [$j] = $row;
				$mosstr = array();
				if ($q->num_rows () > 0) {
					$tstr = array();
					// print'<pre>';
					// print_R($q->result_array());
					foreach ( $q->result_array () as $k => $v ) {
						if (! empty ( $v ['genus'] ))
							$tstr['genus'] = $v ['genus'];
						
						if (! empty ( $v ['mosquitospecies'] ))
							$tstr['mosquitospecies'] = $v ['mosquitospecies'];
                        
                        if (! empty ( $v ['count'] ))
							$tstr['count'] = $v ['count'];
							
							// echo $tstr."<br>";
						array_push($mosstr, $tstr);
					}
				}
				$mos [$j] ['species'] = $mosstr;
				
				$j ++;
			}
		}
		
		 //print'<pre>';
//		 print_r($mos);
//		 die;
		// $this->data = $mos;
		return $mos;
	}
}
