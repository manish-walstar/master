<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Trap_model extends CI_Model {
	public $str = "";
    public $trapTypeForBait = array('2', '5');
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to Add a new Trap
	 */
	public function addTrap($message = '') {
		$status = $this->input->post ( 'active' );
		$idsite = $this->input->post ( 'existing_site' );
		$idzone = $this->input->post ( 'zone' );
		$idsitetype = $this->input->post ( 'site_type' );
		$idtraptype = $this->input->post ( 'trap_type' );
		$idloc = $this->session->userdata ( 'idlocation' );
		$idbaittype = $this->input->post ( 'idbaittype' );
		
		$site_id = "";
		$id = "";
		if (isset ( $idsite ) && $idsite == '0') {
			$idstate = $this->input->post ( 'state' );

			$data ['site'] = $this->input->post ( 'site_name' );
            $data ['idsitetype'] = ! empty ( $idsitetype ) ? $idsitetype : 0;
            $data ['idzone'] = ! empty ( $idzone ) ? $idzone : 0;
            $data ['maplabel'] = $this->input->post ( 'maplabel' );
			$data ['address1'] = $this->input->post ( 'street1' );
			$data ['address2'] = $this->input->post ( 'street2' );
			$data ['city'] = $this->input->post ( 'city' );
			$data ['idstate'] = ! empty ( $idstate ) ? $idstate : '0';
			$data ['postalcode'] = $this->input->post ( 'postal_code' );
			$data ['latitude'] = $this->input->post ( 'latitude' );
			$data ['longitude'] = $this->input->post ( 'longitude' );
			$data ['pdop'] = $this->input->post ( 'pdop' );
			$data ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
			$data ['active'] = '1';
			
			$this->db->insert ( 'sites', $data );
			
			$site_id = $this->db->insert_id ();
			
			$data = array ();
			
			$data ['idsite'] = $site_id;
			$data ['idzone'] = $this->input->post ( 'idzone' );
			
			$this->db->insert ( 'sitezoneassignment', $data );
		} else {
			$site_id = ! empty ( $idsite ) ? $idsite : 0;
		}	

		$data ['trap'] = $this->input->post ( 'trap_name' );
		$data ['idtraptype'] = ! empty ( $idtraptype ) ? $idtraptype : 0;
		$data ['idsite'] = $site_id;
		$data ['active'] = isset ( $status ) ? "1" : "0";
		$data ['latitude'] = $this->input->post ( 'latitude' );
		$data ['longitude'] = $this->input->post ( 'longitude' );
		$data ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
		if (! empty ( $idtraptype ) && in_array($idtraptype, $this->trapTypeForBait))
			$data ['idbaittype'] = ! empty ( $idbaittype ) ? $idbaittype : '0';
		else
			$data ['idbaittype'] = '0';
            
         //print'<pre>';
//         print_r($data);
//         die;
		$this->db->insert ( 'traps', $data );
		
		$id = $this->db->insert_id ();
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ) && empty ( $id ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to Update a new Trap
	 */
	public function updateTrap() {
		$idtrap = $this->input->post ( 'idtrap' );
		
		if (empty ( $idtrap ))
			return false;
		
		$status = $this->input->post ( 'active' );
		$idsite = $this->input->post ( 'existing_site' );
		$idzone = $this->input->post ( 'zone' );
		$idsitetype = $this->input->post ( 'site_type' );
		$idtraptype = $this->input->post ( 'trap_type' );
		$idloc = $this->session->userdata ( 'idlocation' );
		$idbaittype = $this->input->post ( 'idbaittype' );
		$site_id = "";
		$id = "";
		
		if (isset ( $idsite ) && $idsite == "0") {
			$idstate = $this->input->post ( 'state' );
			
			$data ['site'] = $this->input->post ( 'site_name' );
			$data ['maplabel'] = $this->input->post ( 'maplabel' );
			$data ['address1'] = $this->input->post ( 'street1' );
			$data ['address2'] = $this->input->post ( 'street2' );
			$data ['city'] = $this->input->post ( 'city' );
			$data ['idstate'] = ! empty ( $idstate ) ? $idstate : '0';
			$data ['postalcode'] = $this->input->post ( 'postal_code' );
			$data ['latitude'] = $this->input->post ( 'latitude' );
			$data ['longitude'] = $this->input->post ( 'longitude' );
			$data ['idsitetype'] = ! empty ( $idsitetype ) ? $idsitetype : '0';
			$data ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
			$data ['active'] = '1';
			
			$this->db->insert ( 'sites', $data );
			
			$site_id = $this->db->insert_id ();
			
			$data = array ();
			
			$data ['idsite'] = $site_id;
			$data ['idzone'] = $this->input->post ( 'idzone' );
			
			$this->db->insert ( 'sitezoneassignment', $data );
		} else {
			$site_id = ! empty ( $idsite ) ? $idsite : 0;
		}
		
		$data ['trap'] = $this->input->post ( 'trap_name' );
		$data ['idtraptype'] = ! empty ( $idtraptype ) ? $idtraptype : 0;
		$data ['idsite'] = $site_id;
		$data ['idsitetype'] = ! empty ( $idsitetype ) ? $idsitetype : 0;
		$data ['idzone'] = ! empty ( $idzone ) ? $idzone : 0;
		$data ['maplabel'] = $this->input->post ( 'maplabel' );
		$data ['active'] = (isset ( $status ) && $status == "1") ? "1" : "0";
		$data ['latitude'] = $this->input->post ( 'latitude' );
		$data ['longitude'] = $this->input->post ( 'longitude' );
		
		if (! empty ( $idtraptype ) && in_array($idtraptype, $this->trapTypeForBait))
			$data ['idbaittype'] = ! empty ( $idbaittype ) ? $idbaittype : '0';
		else
			$data ['idbaittype'] = '0';
		
		$this->db->where ( 'idtrap', $idtrap );
		$this->db->update ( 'traps', $data );
		// echo $this->db->_error_message();
		$rows = $this->db->affected_rows ();
		// echo $this->db->last_query();
		if (empty ( $rows ) && empty ( $idtrap ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to check for the existence of trap
	 */
	public function trapExist($str = '') {
		if (empty ( $str ))
			return false;
		
		$this->db->select ( '*' );
		$this->db->from ( 'traps AS t' );
		$this->db->join ( 'sites AS s', 't.idsite = s.idsite', 'INNER' );
		$this->db->where ( 't.trap', $str );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0)
			return true;
		
		return false;
	}
	
	/**
	 * Function to list all Traps
	 */
	public function deleteTrap() {
		$idtrap = $this->input->get_post ( 'id' );
		
		if (empty ( $idtrap ))
			return false;
		
		$data ['isdeleted'] = '1';
		$this->db->query ( "SET foreign_key_checks = 0" );
		$this->db->where ( 'idtrap', $idtrap );
		$this->db->update ( 'traps', $data );
		$this->db->query ( "SET foreign_key_checks = 1" );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ) && empty ( $idtrap ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to activate Traps
	 */
	public function activeTrap() {
		$idtrap = $this->input->get_post ( 'id' );
		
		if (empty ( $idtrap ))
			return false;
		
		$data ['active'] = '1';
		
		$this->db->where ( 'idtrap', $idtrap );
		$this->db->update ( 'traps', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to deactivate Traps
	 */
	public function deactiveTrap() {
		$idtrap = $this->input->get_post ( 'id' );
		
		if (empty ( $idtrap ))
			return false;
		
		$data ['active'] = '0';
		
		$this->db->where ( 'idtrap', $idtrap );
		$this->db->update ( 'traps', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to fetch Statuses of Traps
	 */
	public function getStatuses() {
		$this->db->select ( 't.idtrap,
				t.active,
				t.idsite' );
		$this->db->from ( 'traps AS t' );
		$this->db->join ( 'sites AS s', "t.idsite = s.idsite", 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$k = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$k] ['status'] = $row ['active'];
				$result [$k] ['idtrap'] = $row ['idtrap'];
				$k ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to fetch Bait Type
	 */
	public function getBaitType() {
		$this->db->select ( '*' );
		$this->db->from ( 'baittypes' );
		
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$result [$row ['idbaittype']] = $row ['baittype'];
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to list all Traps mail
	 */
	public function getTrapData($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( 'traps.*,
				s.idsite,
				s.site,
				s.city,
				s.maplabel,
				s.address1,
				s.address2,
				s.idstate,
				s.postalcode,
				bt.baittype,
				s.idlocation,
				states.idstate' );
		$this->db->from ( 'traps' );
		$this->db->join ( 'sites AS s', 'traps.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'locations', 's.idlocation = locations.idlocation', 'LEFT' );
		$this->db->join ( 'states', 's.idstate = states.idstate', 'LEFT' );
		$this->db->join ( 'baittypes AS bt', 'traps.idbaittype = bt.idbaittype', 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'traps.isdeleted', '0' );
		$this->db->where ( 'traps.idtrap', $Id );
		
		$query = $this->db->get ();
		
		$data = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row )
				$data [] = $row;
			
			return $data [0];
		}
		
		return false;
	}
	
	/**
	 * Function to list all Traps
	 */
	public function listTraps($id_location = false) {
		$idlocation = ($id_location) ? $id_location : $this->session->userdata ( 'idlocation' );
		
		$this->db->select ( 'traps.idtrap, 
				traps.trap AS `trap`, 
				traptypes.traptype AS `traptypes_traptype`, 
				sites.city, 
				states.statename, 
				traps.latitude AS `latitude`, 
				traps.longitude AS `longitude`, 
				sitetypes.sitetype AS `sitetypes_sitetype`, 
				zones.zone AS `zones_zone`, 
				traps.active AS `active`' );
		$this->db->from ( 'traps' );
		$this->db->join ( 'traptypes', 'traps.idtraptype = traptypes.idtraptype', 'LEFT' );
		$this->db->join ( 'sites', 'traps.idsite = sites.idsite', 'LEFT' );
		$this->db->join ( 'states', 'sites.idstate = states.idstate', 'LEFT' );
		$this->db->join ( 'sitetypes', 'sites.idsitetype = sitetypes.idsitetype', 'LEFT' );
		$this->db->join ( 'zones', 'sites.idzone = zones.idzone', 'LEFT' );
		$this->db->join ( 'locations', 'sites.idlocation = locations.idlocation', 'LEFT' );
		$this->db->where ( 'sites.idlocation', $idlocation );
		// $this->db->where('traps.active','1');
		$this->db->where ( 'traps.isdeleted', '0' );
		
		$orderby = $this->input->get ( 'orderby' );
		
		if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
			switch ($orderby) {
				case '0:asc' :
					$this->db->order_by ( 'traps.trap', 'ASC' );
					break;
				case '0:desc' :
					$this->db->order_by ( 'traps.trap', 'DESC' );
					break;
				case '1:asc' :
					$this->db->order_by ( 'traptypes.traptype', 'ASC' );
					break;
				case '1:desc' :
					$this->db->order_by ( 'traptypes.traptype', 'DESC' );
					break;
				case '2:asc' :
					$this->db->order_by ( 'sites.city', 'ASC' );
					$this->db->order_by ( 'states.statename', 'ASC' );
					break;
				case '2:desc' :
					$this->db->order_by ( 'sites.city', 'DESC' );
					$this->db->order_by ( 'states.statename', 'DESC' );
					break;
				case '3:asc' :
					$this->db->order_by ( 'sites.latitude', 'ASC' );
					break;
				case '3:desc' :
					$this->db->order_by ( 'sites.latitude', 'DESC' );
					break;
				case '4:asc' :
					$this->db->order_by ( 'sites.longitude', 'ASC' );
					break;
				case '4:desc' :
					$this->db->order_by ( 'sites.longitude', 'DESC' );
					break;
				case '5:asc' :
					$this->db->order_by ( 'sitetypes.sitetype', 'ASC' );
					break;
				case '5:desc' :
					$this->db->order_by ( 'sitetypes.sitetype', 'DESC' );
					break;
				case '6:asc' :
					$this->db->order_by ( 'zones.zone', 'ASC' );
					break;
				case '6:desc' :
					$this->db->order_by ( 'zones.zone', 'DESC' );
					break;
				case '7:asc' :
					$this->db->order_by ( 'traps.active', 'ASC' );
					break;
				case '7:desc' :
					$this->db->order_by ( 'traps.active', 'DESC' );
					break;
			}
		} else {
			$this->db->order_by ( 'traps.trap', 'DESC' );
		}
		/*
		 * $ttl = $this->input->get('ttl');
		 * $page = $this->input->get('page');
		 *
		 * if(!isset($ttl) || $ttl == '')
		 * $ttl = 10;
		 *
		 * if(!isset($page) || $page == '')
		 * $page = 1;
		 *
		 * if(!is_null($ttl) && !is_null($page))
		 * {
		 * if($page == 1)
		 * $page = 0;
		 * else
		 * $page--;
		 *
		 * $page *= 10;
		 * $this->db->limit($ttl ,$page);
		 * }
		 * else if(!is_null($ttl))
		 * {
		 * $this->db->limit($ttl);
		 * }
		 */
		$query = $this->db->get ();
		// echo $this->db->last_query()."<br>";
		// die;
		
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
		
		return false;
	}
	
	/**
	 * Function to fetch Trap Type
	 */
	public function getTraptypes() {
		$this->db->select ( '*' );
		$this->db->order_by ( 'traptype' );
		$this->db->from ( 'traptypes' );
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idtraptype'] = $row ['idtraptype'];
				$result [$i] ['traptype'] = $row ['traptype'];
				$i ++;
			}
		}
		
		return $result;
	}
	/**
	 * Function to fetch Selected Trap TYpe
	 * selected by Trap
	 */
	public function getSelectedtraptype($id) {
		$this->db->select ( 'idtraptype,
				traptype' );
		$this->db->order_by ( 'traptype' );
		$this->db->from ( 'traptypes' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($row ['idtraptype'] == $id)
					$this->str .= '<option value="' . $row ['idtraptype'] . '" selected="true">' . $row ['traptype'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idtraptype'] . '" >' . $row ['traptype'] . '</option>';
			}
			return $this->str;
		}
		
		return $this->str;
	}
	
    /**
	 * Function to fetch Selected Zones
	 * selected by Trap
	 */
	public function getSelectedZones($id) {
		$this->db->select ( 'idzone,
				zone' );
		$this->db->order_by ( 'zone' );
		$this->db->from ( 'zones' );
		$this->db->where ( 'zones.active', '1' );
		$this->db->where ( 'zones.isdeleted', '0' );
		$this->db->where ( 'zones.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				if ($row ['idzone'] == $id)
					$this->str .= '<option value="' . $row ['idzone'] . '" selected="true">' . $row ['zone'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idzone'] . '">' . $row ['zone'] . '</option>';
			}
			return $this->str;
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Zones
	 * selected by Trap
	 */
	public function getZones() {
		$this->db->select ( 'idzone,
				zone' );
		$this->db->from ( 'zones' );
		$this->db->where ( 'zones.active', '1' );
		$this->db->where ( 'zones.isdeleted', '0' );
		$this->db->where ( 'zones.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['idzone'] . '">' . $row ['zone'] . '</option>';
			}
		}
		
		return $this->str;
	}
}