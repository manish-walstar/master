<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Weather_sensor_model extends CI_Model {
	public $str = "";
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to Add a new Zone
	 */
	public function addWeather_sensor() {
		$site_id = "";
		$idsite = $this->input->post ( 'existing_site' );
		$id = $this->input->post ( 'id' );
		$idstate = $this->input->post ( 'state' );
		
		if (! empty ( $idsite ) && $idsite == "0") {
			$data ['site'] = $this->input->post ( 'site_name' );
			$data ['address1'] = $this->input->post ( 'street1' );
			$data ['address2'] = $this->input->post ( 'street2' );
			$data ['city'] = $this->input->post ( 'city' );
			$data ['state'] = ! empty ( $idstate ) ? $idstate : '';
			$data ['postalcode'] = $this->input->post ( 'postal_code' );
			$data ['latitude'] = $this->input->post ( 'latitude' );
			$data ['longitude'] = $this->input->post ( 'longitude' );
			$data ['idsitetype'] = $this->input->post ( 'idsitetype' );
			$data ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
			$data ['active'] = 1;
			$this->db->insert ( 'sites', $data );
			$site_id = $this->db->insert_id ();
		} else {
			$site_id = ! empty ( $idsite ) ? $idsite : 0;
		}
		
		$idinspector = $this->input->post ( 'idinspector' );
		$idsensortype = $this->input->post ( 'sensor_type' );
		$idsitetype = $this->input->post ( 'site_type' );
		$idzone = $this->input->post ( 'zone' );
		$date = $this->input->post ( 'dateinstalled' );
		
		$data = array ();
		$data ['weathersensor'] = $this->input->post ( 'sensor_name' );
		$data ['idsensortype'] = ! empty ( $idsensortype ) ? $idsensortype : 0;
		$data ['avgrainperyear'] = $this->input->post ( 'avgrainperyear' );
		$data ['dateinstalled'] = date ( 'Y-m-d', strtotime ( $date ) );
		$data ['idinspector'] = ! empty ( $idinspector ) ? $idinspector : 0;
		$data ['idsite'] = $site_id;
		$data ['sitename'] = $this->input->post ( 'site_name' );
		$data ['idsitetype'] = ! empty ( $idsitetype ) ? $idsitetype : 0;
		$data ['idzone'] = ! empty ( $idzone ) ? $idzone : 0;
		$data ['latitude'] = $this->input->post ( 'latitude' );
		$data ['longitude'] = $this->input->post ( 'longitude' );
		$data ['active'] = '1';
		$data ['idlocation'] = $this->session->userdata ( 'idlocation' );
		// $data['idsitegroup'] = $this->input->post('idsitegroup');
		
		if (! empty ( $id )) {
			$this->db->where ( 'idweathersensor', $id );
			$this->db->update ( 'weathersensors', $data );
		} else {
			$this->db->insert ( 'weathersensors', $data );
			
			$id = $this->db->insert_id ();
		}
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ) && empty ( $id ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to list all Weather_sensors
	 */
	public function deleteWeather_sensor() {
		$idweather_sensor = $this->input->get_post ( 'id' );
		if (empty ( $idweather_sensor ))
			return false;
		
		$data ['isdeleted'] = '1';
		$this->db->where ( 'idweathersensor', $idweather_sensor );
		$this->db->update ( 'weathersensors', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to activate Weather_sensors
	 */
	public function activeWeather_sensor() {
		$idweather_sensor = $this->input->get_post ( 'id' );
		
		if (empty ( $idweather_sensor ))
			return false;
		
		$data ['active'] = '1';
		
		$this->db->where ( 'idweathersensor', $idweather_sensor );
		$this->db->update ( 'weathersensors', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to check for the existence of Weather Sensor
	 */
	public function sensorExist($str = '') {
		if (empty ( $str ))
			return false;
		
		$this->db->select ( 'ws.*' );
		$this->db->from ( 'weathersensors AS ws' );
		$this->db->where ( 'ws.weathersensor', $str );
		$this->db->join ( 'sites AS s', 'ws.idsite = s.idsite', 'INNER' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0)
			return true;
		
		return false;
	}
	/**
	 * Function to deactivate Weather_sensors
	 */
	public function deactiveWeather_sensor() {
		$idweather_sensor = $this->input->get_post ( 'id' );
		
		if (empty ( $idweather_sensor ))
			return false;
		
		$data ['active'] = '0';
		
		$this->db->where ( 'idweathersensor', $idweather_sensor );
		$this->db->update ( 'weathersensors', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to list all Weather_sensors mail
	 */
	public function getWeather_sensorData($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( 'ws.*,
				s.idsite,
				s.city,
				s.site,
				s.maplabel,
				s.address1,
				s.address2,
				s.idstate,
				s.idsitetype,
				st.sitetype,
				s.idzone,
				z.zone,
				s.postalcode,
				s.idlocation' );
		$this->db->from ( 'weathersensors AS ws' );
		$this->db->join ( 'sites AS s', 'ws.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'sitetypes AS st', 's.idsitetype = st.idsitetype', 'LEFT' );
		$this->db->join ( 'zones AS z', 'z.idzone = s.idzone', 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'ws.idweathersensor', $Id );
		
		$query = $this->db->get ();
		
		$data = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row )
				$data [] = $row;
			
			return $data [0];
		}
		
		return false;
	}
	
	/**
	 * Function to list all Weather_sensors mail
	 */
	public function listWeather_sensors($id_location = false) {
		$idlocation = ($id_location) ? $id_location : $this->session->userdata ( 'idlocation' );
		
		$this->db->select ( 'ws.idweathersensor, 
				ws.weathersensor, 
				wst.weathersensortype, 
				s.site, 
				z.zone, 
				s.idzone,
				st.idsitetype,
				st.sitetype,
				ws.dateinstalled, 
				ws.avgrainperyear, 
				ws.active' );
		$this->db->from ( 'weathersensors AS ws' );
		$this->db->join ( 'weathersensortypes wst', 'ws.idsensortype = wst.idweathersensortype', 'LEFT' );
		$this->db->join ( 'sites AS s', 'ws.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'zones AS z', 's.idzone = z.idzone', 'LEFT' );
		$this->db->join ( 'locations AS l', 's.idlocation = l.idlocation', 'LEFT' );
		$this->db->join ( 'sitetypes AS st', 's.idsitetype = st.idsitetype', 'LEFT' );
		$this->db->where ( 's.idlocation', $idlocation );
		$this->db->where ( 'ws.isdeleted', '0' );
		$ttl = $this->input->get ( 'ttl' );
		$page = $this->input->get ( 'page' );
		$orderby = $this->input->get ( 'orderby' );
		
		if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
			switch ($orderby) {
				case '0:asc' :
					$this->db->order_by ( 'ws.weathersensor', 'ASC' );
					break;
				case '0:desc' :
					$this->db->order_by ( 'ws.weathersensor', 'DESC' );
					break;
				case '1:asc' :
					$this->db->order_by ( 'wst.weathersensortype', 'ASC' );
					break;
				case '1:desc' :
					$this->db->order_by ( 'wst.weathersensortype', 'DESC' );
					break;
				case '2:asc' :
					$this->db->order_by ( 'ws.sitename', 'ASC' );
					break;
				case '2:desc' :
					$this->db->order_by ( 'ws.sitename', 'DESC' );
					break;
				case '3:asc' :
					$this->db->order_by ( 'z.zone', 'ASC' );
					break;
				case '3:desc' :
					$this->db->order_by ( 'z.zone', 'DESC' );
					break;
				case '4:asc' :
					$this->db->order_by ( 'ws.dateinstalled', 'ASC' );
					break;
				case '4:desc' :
					$this->db->order_by ( 'ws.dateinstalled', 'DESC' );
					break;
				case '5:asc' :
					$this->db->order_by ( 'ws.avgrainperyear', 'ASC' );
					break;
				case '5:desc' :
					$this->db->order_by ( 'ws.avgrainperyear', 'DESC' );
					break;
				case '6:asc' :
					$this->db->order_by ( 'active', 'ASC' );
					break;
				case '6:desc' :
					$this->db->order_by ( 'active', 'DESC' );
					break;
			}
		} else {
			$this->db->order_by ( 'ws.weathersensor', 'ASC' );
		}
		
		if (! isset ( $ttl ) || $ttl == '')
			$ttl = 10;
		
		if (! isset ( $page ) || $page == '')
			$page = 1;
			/*
		 * if(!is_null($ttl) && !is_null($page))
		 * {
		 * if($page == 1)
		 * $page = 0;
		 * else
		 * $page--;
		 *
		 * $page *= 10;
		 * $this->db->limit($ttl ,$page);
		 * }
		 * else if(!is_null($ttl))
		 * {
		 * $this->db->limit($ttl);
		 * }
		 */
		$data_1 = array ();
		$query = $this->db->get ();
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
		
		return false;
	}
	
	/**
	 * Function to fetch Existing Weather_sensor
	 */
	public function getExisting_weather_sensor() {
		$this->db->select ( 'idweather_sensor,
				weather_sensor,idsite' );
		$this->db->from ( 'weathersensors' );
		$this->db->join ( 'sites AS s', "weathersensors.idsite = s.idsite", 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idweather_sensor'] = $row ['idweather_sensor'];
				$result [$i] ['weather_sensor'] = $row ['weather_sensor'];
				$i++;
			}
		}
		return $result;
	}
	/**
	 * Function to fetch Weather_sensor Type
	 */
	public function getWeather_sensortypes($id = '') {
		$this->db->select ( '*' );
		$this->db->order_by ( 'weathersensortype' );
		$this->db->from ( 'weathersensortypes' );
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idweathersensortype'] = $row ['idweathersensortype'];
				$result [$i] ['weathersensortype'] = $row ['weathersensortype'];
				$i ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to fetch Zones
	 * selected by Weather_sensor
	 */
	public function getZones() {
		
		$this->db->select ( 'idzone,
				zone' );
		$this->db->from ( 'zones' );
		$this->db->where ( 'zones.active', '1' );
		$this->db->where ( 'zones.isdeleted', '0' );
		$this->db->where ( 'zones.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['idzone'] . '">' . $row ['zone'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Statuses of Weather Sensors
	 */
	public function getStatuses() {
		$this->db->select ( 'ws.idweathersensor,
				ws.active,ws.idsite' );
		$this->db->from ( 'weathersensors AS ws' );
		$this->db->join ( 'sites AS s', "ws.idsite = s.idsite", 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$k = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$k] ['status'] = $row ['active'];
				$result [$k] ['idweathersensor'] = $row ['idweathersensor'];
				$k ++;
			}
		}
		
		return $result;
	}
}
