<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Monitor_model extends CI_Model {
	
	/** 
	 * Constructor for the class
	 * User
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to list all Monitor management
	 */
	public function listMonitor() {
		$this->db->select ( 'monitormgmt.*' );
		$this->db->from ( 'monitormgmt' );
		$this->db->join ( 'locations AS l', 'monitormgmt.GUID = l.GUID', 'INNER' );
		$this->db->where ( 'monitormgmt.status', '0' );
		$this->db->where ( 'l.idlocation', $this->session->userdata ( 'idlocation' ) );
		// $this->db->order_by('monitormgmt.start_time' , 'DESC');
		$ttl = $this->input->get ( 'ttl' );
		$page = $this->input->get ( 'page' );
		$orderby = $this->input->get ( 'orderby' );
		
		if (! isset ( $ttl ) || $ttl == '')
			$ttl = 10;
		
		if (! isset ( $page ) || $page == '')
			$page = 1;
			/*
		 * if(!is_null($ttl) && !is_null($page))
		 * {
		 * if($page == 1)
		 * $page = 0;
		 * else
		 * $page--;
		 *
		 * $page *= 10;
		 * $this->db->limit($ttl ,$page);
		 * }
		 * else if(!is_null($ttl))
		 * {
		 * $this->db->limit($ttl);
		 * }
		 */
		if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
			switch ($orderby) {
				case '0:asc' :
					$this->db->order_by ( 'monitormgmt.mission_type', 'ASC' );
					break;
				case '0:desc' :
					$this->db->order_by ( 'monitormgmt.mission_type', 'DESC' );
					break;
				case '1:asc' :
					$this->db->order_by ( 'monitormgmt.mission_number', 'ASC' );
					break;
				case '1:desc' :
					$this->db->order_by ( 'monitormgmt.mission_number', 'DESC' );
					break;
				case '2:asc' :
					$this->db->order_by ( 'monitormgmt.trip_number', 'ASC' );
					break;
				case '2:desc' :
					$this->db->order_by ( 'monitormgmt.trip_number', 'DESC' );
					break;
				case '3:asc' :
					$this->db->order_by ( 'monitormgmt.operator_name', 'ASC' );
					break;
				case '3:desc' :
					$this->db->order_by ( 'monitormgmt.operator_name', 'DESC' );
					break;
				case '4:asc' :
					$this->db->order_by ( 'monitormgmt.equipment_id', 'ASC' );
					break;
				case '4:desc' :
					$this->db->order_by ( 'monitormgmt.equipment_id', 'DESC' );
					break;
				case '5:asc' :
					$this->db->order_by ( 'monitormgmt.route', 'ASC' );
					break;
				case '5:desc' :
					$this->db->order_by ( 'monitormgmt.route', 'DESC' );
					break;
				case '6:asc' :
					$this->db->order_by ( 'monitormgmt.applicationstartdate', 'ASC' );
					break;
				case '6:desc' :
					$this->db->order_by ( 'monitormgmt.applicationstartdate', 'DESC' );
					break;
				case '7:asc' :
					$this->db->order_by ( 'monitormgmt.start_time', 'ASC' );
					break;
				case '7:desc' :
					$this->db->order_by ( 'monitormgmt.start_time', 'DESC' );
					break;
				case '8:asc' :
					$this->db->order_by ( 'monitormgmt.applicationenddate', 'ASC' );
					break;
				case '8:desc' :
					$this->db->order_by ( 'monitormgmt.applicationenddate', 'DESC' );
					break;
				case '9:asc' :
					$this->db->order_by ( 'monitormgmt.end_time', 'ASC' );
					break;
				case '9:desc' :
					$this->db->order_by ( 'monitormgmt.end_time', 'DESC' );
					break;
				case '10:asc' :
					$this->db->order_by ( 'monitormgmt.spray_on_time', 'ASC' );
					break;
				case '10:desc' :
					$this->db->order_by ( 'monitormgmt.spray_on_time', 'DESC' );
					break;
				case '11:asc' :
					$this->db->order_by ( 'monitormgmt.spray_off_time', 'ASC' );
					break;
				case '11:desc' :
					$this->db->order_by ( 'monitormgmt.spray_off_time', 'DESC' );
					break;
				case '12:asc' :
					$this->db->order_by ( 'monitormgmt.time_on', 'ASC' );
					break;
				case '12:desc' :
					$this->db->order_by ( 'monitormgmt.time_on', 'DESC' );
					break;
				case '13:asc' :
					$this->db->order_by ( 'monitormgmt.distance_traveled', 'ASC' );
					break;
				case '13:desc' :
					$this->db->order_by ( 'monitormgmt.distance_traveled', 'DESC' );
					break;
				case '14:asc' :
					$this->db->order_by ( 'monitormgmt.distance_sprayed', 'ASC' );
					break;
				case '14:desc' :
					$this->db->order_by ( 'monitormgmt.distance_sprayed', 'DESC' );
					break;
				case '15:asc' :
					$this->db->order_by ( 'monitormgmt.acreage_sprayed', 'ASC' );
					break;
				case '15:desc' :
					$this->db->order_by ( 'monitormgmt.acreage_sprayed', 'DESC' );
					break;
				case '16:asc' :
					$this->db->order_by ( 'monitormgmt.gallons_sprayed', 'ASC' );
					break;
				case '16:desc' :
					$this->db->order_by ( 'monitormgmt.gallons_sprayed', 'DESC' );
					break;
				case '17:asc' :
					$this->db->order_by ( 'monitormgmt.avg_spray_speed', 'ASC' );
					break;
				case '17:desc' :
					$this->db->order_by ( 'monitormgmt.avg_spray_speed', 'DESC' );
					break;
				case '18:asc' :
					$this->db->order_by ( 'monitormgmt.max_speed', 'ASC' );
					break;
				case '18:desc' :
					$this->db->order_by ( 'monitormgmt.max_speed', 'DESC' );
					break;
				case '19:asc' :
					$this->db->order_by ( 'monitormgmt.max_flow', 'ASC' );
					break;
				case '19:desc' :
					$this->db->order_by ( 'monitormgmt.max_flow', 'DESC' );
					break;
				case '20:asc' :
					$this->db->order_by ( 'monitormgmt.GUID', 'ASC' );
					break;
				case '20:desc' :
					$this->db->order_by ( 'monitormgmt.GUID', 'DESC' );
					break;
			}
		} else {
			$this->db->order_by ( 'monitormgmt.applicationstartdate ', 'DESC' );
		}
		
		$query = $this->db->get ();
		// echo $this->db->last_query()."<br>";
		// die;
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
		
		return null;
	}
	
	/**
	 * Function to fetch Monitor Management Data
	 * for the logged in user
	 */
	public function userMonitor() {
		$userid = $this->session->userdata ( 'id' );
		$userid = json_decode ( base64_decode ( $userid ) );
		$userid_arr = explode ( "_", $userid );
		$userid = json_decode ( base64_decode ( $userid_arr [0] ) );
		
		$this->db->select ( 'idmonitor' );
		$this->db->from ( 'user_monitor' );
		$this->db->where ( 'user_id', $userid );
		
		$query = $this->db->get ();
		
		$data = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $key => $val ) {
				$data [] = $val ['idmonitor'];
			}
		}
		// print_r($data);
		return $data;
	}
	
	/**
	 * Function to fetch GUID
	 * for the logged in user
	 */
	public function getGuid() {
		$this->db->select ( 'm.GUID' );
		$this->db->from ( 'monitormgmt AS m' );
		$this->db->join ( 'locations AS l', 'm.GUID = l.GUID', 'INNER' );
		$this->db->where ( 'l.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$query = $this->db->get ();
		
		$data = array ();
		if ($query->num_rows () > 0) {
			$data = $query->result_array ();
			if (isset ( $data [0] ) && ! empty ( $data [0] ['GUID'] ))
				$data = $data [0] ['GUID'];
		}
		
		return $data;
	}
	
	/**
	 * Function to insert records in User_monitor
	 * from monitor management
	 */
	public function deleteMonitor() {
		$id = $this->input->get_post ( 'id' );
		
		if (empty ( $id ))
			return false;
			
			// $data['status'] = '1';
			// $data['idmonitor'] = $id;
		$this->db->where ( 'idmonitor', $id );
		$this->db->delete ( 'monitormgmt' );
	 //$this->db->update('monitormgmt',$id);
		
		$row = $this->db->affected_rows ();
		
		if (empty ( $row ) && empty ( $id ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to fetch Monitor Management Data
	 */
	public function getMonitorData($id = '') {
		if (empty ( $id ))
			return false;
		
		$this->db->select ( '*' );
		$this->db->from ( 'monitormgmt' );
		$this->db->where ( 'idmonitor', $id );
		$this->db->order_by ( 'idmonitor', 'ASC' );
		
		$query = $this->db->get ();
		$data = array ();
		if ($query->num_rows () > 0) {
			$data = $query->result_array ();
			$data = $data [0];
		}
		
		// $this->deleteMonitor($id);
		
		return $data;
	}
	
	/**
	 * Function to fetch System Type
	 */
	public function getSystemType($val = '') {
		if (empty ( $val ))
			return false;
		
		switch ($val) {
			case 'M4' :
				$val = "Monitor 4";
				break;
			case 'M4S' :
				$val = "Monitor 4S";
				break;
			case 'M3' :
				$val = "Monitor 3";
				break;
			case 'WM3' :
				$val = "Wingman";
				break;
				case 'LT' :
				$val = "Monitor LT";
				break;
		}
		
		$this->db->select ( 'idsystemtype' );
		$this->db->from ( 'systemtypes' );
		$this->db->where ( 'systemtype', $val );
		
		$data = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$data = $query->result_array ();
			$data = $data [0] ['idsystemtype'];
		}
		
		return $data;
	}
}

?>