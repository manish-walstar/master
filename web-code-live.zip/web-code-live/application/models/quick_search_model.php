<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Quick_search_model extends CI_Model {
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to search data from DB
	 */
	public function getData($data = '') {
		$data = addcslashes ( $data, '?><. \'"()/\\#$%^&*@!' );
		$data_result = array ();
		$id_location = $this->session->userdata ( 'idlocation' );
		
		// code for adulticidetreatments
		$this->db->select ( 'act.*, 
				s.site, 
				s.address1,
				apm.applicationmethod,
				st.systemtype,
				art.applicationratetype,
				pds.productname' );
		$this->db->from ( 'adulticidetreatments act' );
		$this->db->join ( 'sites AS s', 's.idsite = act.idsite', 'INNER' );
		
		$this->db->join ( 'applicationmethods as apm', 'act.idapplicationmethod=apm.idapplicationmethods', 'INNER' );
		$this->db->join ( 'systemtypes as st', 'act.idsystemtype = st.idsystemtype', 'INNER' );
		$this->db->join ( 'applicationratetypes as art', 'act.idapplicationratetype = art.idapplicationratetypes', 'INNER' );
		$this->db->join ( 'products as pds', 'act.idproduct = pds.idproduct', 'INNER' );
		$this->db->where ( "s.`idlocation` = " . $id_location . " AND `s`.`isdeleted`='0' AND `act`.`isdeleted` = '0' AND (act.comments LIKE '%" . $data . "%')" );
		
		$adulttreat = $this->db->get ();
		
		// echo $this->db->last_query();
		if ($adulttreat->num_rows () > 0) {
			$data_result ['adulttreatment'] = $adulttreat->result_array ();
			$data_result ['adulttreatment'] ['column_name'] = "comments";
		}
		// echo "<pre>";
		// print_r($data_result);
		// die;
		// code for adulticidetreatments - sites
		$this->db->select ( 'adt.idadulticidetreatment, adt.date, s.*, ps.productname' );
		$this->db->from ( 'adulticidetreatments AS adt' );
		$this->db->join ( 'sites AS s', 'adt.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'products AS ps', 'adt.idproduct = ps.idproduct', 'LEFT' );
		
		$this->db->where ( "`s`.`idlocation` = " . $id_location . " AND `s`.`isdeleted`='0' AND `adt`.`isdeleted` = '0'
	AND (`s`.`site` LIKE '%" . $data . "%' OR `s`.`maplabel` LIKE '%" . $data . "%' OR `s`.`address1` LIKE '%" . $data . "%' OR `s`.`address2` LIKE '%" . $data . "%' OR `s`.`city` LIKE '%" . $data . "%' OR `s`.`manphone` LIKE '%" . $data . "%' OR `s`.`alternatephone` LIKE '%" . $data . "%' OR `s`.`faxnumber` LIKE '%" . $data . "%' )" );
		
		$adulttreat_site = $this->db->get ();
		
		// echo $this->db->last_query();
		// die;
		$sw = "";
		foreach ( $adulttreat_site->result_array () as $val ) {
			// $pattern = addcslashes($data,')(.\/ -');
			preg_match ( "/" . $data . "/i", $val ['site'], $matches_1 );
			preg_match ( "/" . $data . "/i", $val ['maplabel'], $matches_2 );
			preg_match ( "/" . $data . "/i", $val ['address1'], $matches_3 );
			preg_match ( "/" . $data . "/i", $val ['address2'], $matches_4 );
			preg_match ( "/" . $data . "/i", $val ['city'], $matches_5 );
			preg_match ( "/" . $data . "/i", $val ['manphone'], $matches_6 );
			preg_match ( "/" . $data . "/i", $val ['alternatephone'], $matches_7 );
			preg_match ( "/" . $data . "/i", $val ['faxnumber'], $matches_8 );
			if ($matches_1)
				$sw = "site";
			
			elseif ($matches_2)
				$sw = "maplabel";
			
			elseif ($matches_3)
				$sw = "address1";
			
			elseif ($matches_4)
				$sw = "address2";
			
			elseif ($matches_5)
				$sw = "city";
			elseif ($matches_6)
				$sw = "manphone";
			elseif ($matches_7)
				$sw = "alternatephone";
			elseif ($matches_8)
				$sw = "faxnumber";
		}
		if ($adulttreat_site->num_rows () > 0) {
			$data_result ['adulttreatment_site'] = $adulttreat_site->result_array ();
			$data_result ['adulttreatment_site'] ['column_name'] = $sw;
		}
		// echo "<pre>";
		// print_r($data_result);
		// die;
		
		// code for adulticidetreatments - sitetype
		$this->db->select ( 'sty.*, adt.*, s.*, ps.*' );
		$this->db->from ( 'sitetypes AS sty' );
		$this->db->join ( 'adulticidetreatments AS adt', 'sty.idsitetype = adt.idsitetype', 'INNER' );
		$this->db->join ( 'sites AS s', 'adt.idsite = s.idsite', 'INNER' );
		$this->db->join ( 'products AS ps', 'adt.idproduct = ps.idproduct', 'INNER' );
		
		$this->db->where ( "s.`idlocation` = " . $id_location . "  AND (sty.sitetype LIKE '%" . $data . "%' )" );
		
		$adulttreat_sitetype = $this->db->get ();
		// echo $this->db->last_query();
		
		if ($adulttreat_sitetype->num_rows () > 0) {
			$data_result ['adulttreatment_sitetype'] = $adulttreat_sitetype->result_array ();
			$data_result ['adulttreatment_sitetype'] ['column_name'] = "sitetype";
		}
		
		// code for adulticidetreatments - zone
		$this->db->select ( 'adt.idadulticidetreatment, 
        		adt.date, 
        		s.site, 
        		s.address1, 
        		ps.productname, 
        		z.zone, 
        		z.description' );
		$this->db->from ( 'adulticidetreatments AS adt' );
		$this->db->join ( 'sites AS s', 'adt.idsite = s.idsite', 'left' );
		$this->db->join ( 'zones as z', 's.idzone = z.idzone', 'left' );
		$this->db->join ( 'products AS ps', 'adt.idproduct = ps.idproduct', 'INNER' );
		
		$this->db->where ( "`z`.`idlocation` = '" . $id_location . "' AND `z`.`isdeleted` = '0' AND `adt`.`isdeleted` = '0' AND (`z`.`zone` LIKE '%" . $data . "%' OR `z`.`description` LIKE '%" . $data . "%')" );
		$adulttreat_zone = $this->db->get ();
		
		$sw = "";
		
		foreach ( $adulttreat_zone->result_array () as $val ) {
			preg_match ( "/" . $data . "/i", $val ['zone'], $matches_1 );
			preg_match ( "/" . $data . "/i", $val ['description'], $matches_2 );
			if ($matches_1)
				$sw = "zone";
			
			elseif ($matches_2)
				$sw = "description";
		}
		if ($adulttreat_zone->num_rows () > 0) {
			$data_result ['adulttreatment_zone'] = $adulttreat_zone->result_array ();
			$data_result ['adulttreatment_zone'] ['column_name'] = $sw;
		}
		
		// code for adulticidetreatments - applicationmethod
		$this->db->select ( 'am.*, adt.*, s.*' );
		$this->db->from ( 'applicationmethods AS am' );
		$this->db->join ( 'adulticidetreatments AS adt', 'am.idapplicationmethods = adt.idapplicationmethod', 'INNER' );
		$this->db->join ( 'sites AS s', 'adt.idsite = s.idsite', 'INNER' );
		
		$this->db->where ( "s.idlocation ='" . $id_location . "' AND `s`.`isdeleted`='0' AND  (am.applicationmethod LIKE '%" . $data . "%')" );
		
		$adulttreat_applicmethod = $this->db->get ();
		
		if ($adulttreat_applicmethod->num_rows () > 0) {
			$data_result ['adulttreatment_application_method'] = $adulttreat_applicmethod->result_array ();
			$data_result ['adulttreatment_application_method'] ['column_name'] = "applicationmethod";
		}
		
		// code for adulticidetreatments - applicator
		$this->db->select ( "adt.idadulticidetreatment, 
				adt.date, 
				s.site, 
				s.address1, 
				ps.productname, 
				users.username, 
				users.firstname, 
				users.lastname, 
				users.middlename,
				concat(users.firstname,' ',users.lastname) as 'full_name'", FALSE );
		$this->db->from ( 'users AS users' );
		$this->db->join ( 'adulticidetreatments AS adt', 'users.iduser = adt.idapplicator', 'LEFT' );
		$this->db->join ( 'sites AS s', 'adt.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'products AS ps', 'adt.idproduct = ps.idproduct', 'LEFT' );
		$this->db->where ( "s.idlocation = " . $id_location . " AND `s`.`isdeleted`='0' AND `users`.`isdeleted` = '0' AND (users.username LIKE '%" . $data . "%' OR users.firstname LIKE '%" . $data . "%' OR users.lastname LIKE '%" . $data . "%' OR users.middlename LIKE '%" . $data . "%' OR concat(users.firstname,' ',users.lastname) LIKE '%" . $data . "%')" );
		
		$adulttreat_applicator = $this->db->get ();
		
		$sw = "";
		// $arr = $adulttreat_applicator->result_array();
		foreach ( $adulttreat_applicator->result_array () as $val ) {
			preg_match ( "/" . $data . "/i", $val ['username'], $matches_u );
			preg_match ( "/" . $data . "/i", $val ['firstname'], $matches_f );
			preg_match ( "/" . $data . "/i", $val ['lastname'], $matches_l );
			
			if (! empty ( $val ['middlename'] ))
				preg_match ( "/" . $data . "/i", $val ['middlename'], $matches_m );
			preg_match ( "/" . $data . "/i", $val ['full_name'], $matches_fu );
			if ($matches_u)
				$sw = "username";
			
			elseif ($matches_f)
				$sw = "firstname";
			
			elseif ($matches_l)
				$sw = "lastname";
			
			elseif (! empty ( $val ['middlename'] ) && $matches_m)
				$sw = "middlename";
			
			elseif ($matches_fu)
				$sw = "full_name";
		}
		
		if ($adulttreat_applicator->num_rows () > 0) {
			$data_result ['adulttreatment_applicator'] = $adulttreat_applicator->result_array ();
			$data_result ['adulttreatment_applicator'] ['column_name'] = $sw;
		}
		
		// code for adulticidetreatments - product
		$this->db->select ( 'adt.idadulticidetreatment, 
				adt.date, 
				s.site, 
				s.latitude, 
				s.longitude, 
				ps.productname, 
				ps.description, 
				ps.productlink, ps.productcode' );
		$this->db->from ( 'products AS ps' );
		$this->db->join ( 'adulticidetreatments AS adt', 'ps.idproduct = adt.idproduct', 'INNER' );
		$this->db->join ( 'sites AS s', 'adt.idsite = s.idsite', 'INNER' );
		
		$this->db->where ( "`s`.`idlocation` = '" . $id_location . "' AND (`ps`.`productname` LIKE '%" . $data . "%' OR `ps`.`description` LIKE '" . $data . "' OR `ps`.`productlink` LIKE '" . $data . "' OR `ps`.`productcode` LIKE '" . $data . "' )" );
		
		$adulttreat_product = $this->db->get ();
		
		// echo $this->db->last_query();
		// die;
		$sw = "";
		foreach ( $adulttreat_product->result_array () as $val ) {
			preg_match ( "/" . $data . "/i", $val ['productname'], $matches_1 );
			preg_match ( "/" . $data . "/i", $val ['description'], $matches_2 );
			preg_match ( "/" . $data . "/i", $val ['productlink'], $matches_3 );
			preg_match ( "/" . $data . "/i", $val ['productcode'], $matches_4 );
			if ($matches_1)
				$sw = "productname";
			
			elseif ($matches_2)
				$sw = "description";
			
			elseif ($matches_3)
				$sw = "productlink";
			
			elseif ($matches_4)
				$sw = "productcode";
		}
		if ($adulttreat_product->num_rows () > 0) {
			$data_result ['adulttreatment_product'] = $adulttreat_product->result_array ();
			$data_result ['adulttreatment_product'] ['column_name'] = $sw;
		}
		
		// code for adulticidetreatments - formulations
		$this->db->select ( 'fr.*, adt.* ,s.site' );
		$this->db->from ( 'formulations AS fr' );
        $this->db->join ( 'products AS ps', 'fr.idformulation = ps.idformulation', 'INNER' );
        $this->db->join ( 'adulticidetreatments AS adt', 'adt.idproduct = ps.idproduct', 'INNER' );
		$this->db->join ( 'sites AS s', 'adt.idsite = s.idsite', 'INNER' );
		
		$this->db->where ( "`s`.`idlocation` = '" . $id_location . "'  AND `s`.`isdeleted`='0' AND (fr.formulation LIKE '%" . $data . "%')" );
		
		$adulttreat_formulations = $this->db->get ();
		
		if ($adulttreat_formulations->num_rows () > 0) {
			$data_result ['adulttreatment_formulations'] = $adulttreat_formulations->result_array ();
			$data_result ['adulttreatment_formulations'] ['column_name'] = "formulation";
		}
		
		// code for larvaltreatments
		$this->db->select ( 'ls.*, s.*, ps.*,am.applicationmethod,st.systemtype' );
		$this->db->from ( 'larvaltreatments as ls' );
		$this->db->join ( 'sites AS s', 'ls.idsite = s.idsite', 'INNER' );
		$this->db->join ( 'products AS ps', 'ls.idproduct = ps.idproduct', 'INNER' );
		
		$this->db->join ( 'applicationmethods as am', 'ls.idapplicationmethod=am.idapplicationmethods', 'INNER' );
		$this->db->join ( 'systemtypes as st', 'ls.idsystemtype=st.idsystemtype', 'INNER' );
		$this->db->where ( "`s`.`idlocation` = '" . $id_location . "' AND `s`.`isdeleted`='0' AND `ls`.`isdeleted` = '0' AND (ls.comments LIKE '%" . $data . "%' )" );
		
		$larvaltreatments = $this->db->get ();
		
		if ($larvaltreatments->num_rows () > 0) {
			$data_result ['larvaltreatments'] = $larvaltreatments->result_array ();
			$data_result ['larvaltreatments'] ['column_name'] = "comments";
		}
        //echo "<pre>";
//        print_r($data_result);
//        die;
		
		// code for larvaltreatments - sites
		$this->db->select ( 'lt.idlarvaltreatment, lt.date, s.*, u.firstname, lcr.larvaecountrange' );
		$this->db->from ( 'larvaltreatments AS lt' );
		$this->db->join ( 'sites AS s', 'lt.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'users AS u', 'lt.idapplicator = u.iduser', 'left' );
		$this->db->join ( 'larvaecountrange AS lcr', 'lt.idlarvaelcountrange = lcr.idlarvaecountrange', 'left' );
		
		$this->db->where ( "s.idlocation =" . $id_location . " AND `s`.`isdeleted`='0' AND `lt`.`isdeleted` = '0' AND (s.site LIKE '%" . $data . "%' OR s.maplabel LIKE '%" . $data . "%' OR s.address1 LIKE '%" . $data . "%' OR s.address2 LIKE '%" . $data . "%' OR s.city LIKE '%" . $data . "%' OR `s`.`manphone` LIKE '%" . $data . "%' OR `s`.`alternatephone` LIKE '%" . $data . "%' OR `s`.`faxnumber` LIKE '%" . $data . "%')" );
		
		$larvaltreat_site = $this->db->get ();
		
		// echo $this->db->last_query();
		// die;
		// $sw = "";
		// echo "<pre>";
		// print_r($larvaltreat_site->result_array());
		// die;
		foreach ( $larvaltreat_site->result_array () as $val ) {
			// $pattern = addcslashes($data,')(.\/ -');
			preg_match ( "/" . $data . "/i", $val ['site'], $matches_1 );
			preg_match ( "/" . $data . "/i", $val ['maplabel'], $matches_2 );
			preg_match ( "/" . $data . "/i", $val ['address1'], $matches_3 );
			preg_match ( "/" . $data . "/i", $val ['address2'], $matches_4 );
			preg_match ( "/" . $data . "/i", $val ['city'], $matches_5 );
			preg_match ( "/" . $data . "/i", $val ['manphone'], $matches_6 );
			preg_match ( "/" . $data . "/i", $val ['alternatephone'], $matches_7 );
			preg_match ( "/" . $data . "/i", $val ['faxnumber'], $matches_8 );
			if ($matches_1)
				$sw = "site";
			
			elseif ($matches_2)
				$sw = "maplabel";
			
			elseif ($matches_3)
				$sw = "address1";
			
			elseif ($matches_4)
				$sw = "address2";
			
			elseif ($matches_5)
				$sw = "city";
			elseif ($matches_6)
				$sw = "manphone";
			elseif ($matches_7)
				$sw = "alternatephone";
			elseif ($matches_8)
				$sw = "faxnumber";
		}
		// echo $sw;
		// die;
		if ($larvaltreat_site->num_rows () > 0) {
			$data_result ['larvaltreatments_site'] = $larvaltreat_site->result_array ();
			$data_result ['larvaltreatments_site'] ['column_name'] = $sw;
		}
		// echo "<pre>";
		// print_r($data_result);
		// die;
		// code for larvaltreatments - sitetype
		$this->db->select ( 'sty.*, lt.*, s.*, ps.*' );
		$this->db->from ( 'sitetypes AS sty' );
		$this->db->join ( 'larvaltreatments AS lt', 'sty.idsitetype = lt.idsitetype', 'INNER' );
		$this->db->join ( 'sites AS s', 'lt.idsite = s.idsite', 'INNER' );
		$this->db->join ( 'products AS ps', 'lt.idproduct = ps.idproduct', 'INNER' );
		
		$this->db->where ( "s.idlocation =" . $id_location . " AND (sty.sitetype LIKE '%" . $data . "%' )" );
		
		$larvaltreat_sitetype = $this->db->get ();
		
		if ($larvaltreat_sitetype->num_rows () > 0) {
			$data_result ['larvaltreatments_sitetype'] = $larvaltreat_sitetype->result_array ();
			$data_result ['larvaltreatments_sitetype'] ['column_name'] = "sitetype";
		}
		
		// code for larvaltreatments - sysytemtype
		$this->db->select ( 'ssty.*, lt.*, s.*, ps.*' );
		$this->db->from ( 'systemtypes AS ssty' );
		$this->db->join ( 'larvaltreatments AS lt', 'ssty.idsystemtype = lt.idsystemtype', 'inner' );
		$this->db->join ( 'sites AS s', 'lt.idsite = s.idsite', 'INNER' );
		$this->db->join ( 'products AS ps', 'lt.idproduct = ps.idproduct', 'INNER' );
		
		$this->db->where ( "s.idlocation =" . $id_location . " AND (ssty.systemtype LIKE '%" . $data . "%')" );
		
		$larvaltreat_sysytemtype = $this->db->get ();
		
		if ($larvaltreat_sysytemtype->num_rows () > 0) {
			$data_result ['larvaltreatments_sysytemtype'] = $larvaltreat_sysytemtype->result_array ();
			$data_result ['larvaltreatments_sysytemtype'] ['column_name'] = "systemtype";
		}
		
		// code for larvaltreatments - zone
		$this->db->select ( 'z.zone, z.description, lt.idlarvaltreatment, lt.date, s.site, s.address1, ps.productname' );
		$this->db->from ( 'larvaltreatments AS lt' );
		$this->db->join ( 'sites AS s', 'lt.idsite = s.idsite', 'INNER' );
		$this->db->join ( 'zones AS z', 'z.idzone = s.idzone', 'INNER' );
		$this->db->join ( 'products AS ps', 'lt.idproduct = ps.idproduct', 'INNER' );
		
		$this->db->where ( "`s`.`idlocation` = '" . $id_location . "' AND (`z`.`zone` LIKE '%" . $data . "%' OR `z`.`description` LIKE '%" . $data . "%' )" );
		
		$larvaltreat_zone = $this->db->get ();
		
		$sw = "";
		foreach ( $larvaltreat_zone->result_array () as $val ) {
			preg_match ( "/" . $data . "/i", $val ['zone'], $matches_1 );
			preg_match ( "/" . $data . "/i", $val ['description'], $matches_2 );
			if ($matches_1)
				$sw = "zone";
			
			elseif ($matches_2)
				$sw = "description";
		}
		if ($larvaltreat_zone->num_rows () > 0) {
			$data_result ['larvaltreatments_zone'] = $larvaltreat_zone->result_array ();
			$data_result ['larvaltreatments_zone'] ['column_name'] = $sw;
		}
		
		// code for larvaltreatments - species
		$this->db->select ( 'ms.mosquitospecies, l.idlarvaltreatment, l.date, s.site, s.address1, ps.productname' );
		$this->db->from ( 'larvatreatmentdetails AS ltd' );
		$this->db->join ( 'larvaltreatments AS l', 'ltd.idlarvaltreatment = l.idlarvaltreatment', 'INNER' );
		$this->db->from ( 'mosquitospecies AS ms', 'ltd.idmosquitospecies = ms.idmosquitospecies', 'LEFT' );
		$this->db->join ( 'sites AS s', 'l.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'products AS ps', 'l.idproduct = ps.idproduct', 'LEFT' );
		$this->db->join ( 'locationmosquitospecies AS lms', 'ltd.idmosquitospecies = lms.idmosquitospecies', 'LEFT' );
		$this->db->where ( "`lms`.`idlocation` = '" . $id_location . "' AND (`ms`.`mosquitospecies` LIKE '%" . $data . "%'  )" );
        $this->db->where ( "s.`idlocation` = " . $id_location . "" );
		$larvaltreat_species = $this->db->get ();
        //echo $this->db->last_query()."<br>";		
		if ($larvaltreat_species->num_rows () > 0) {
			$data_result ['larvaltreatments_species'] = $larvaltreat_species->result_array ();
			$data_result ['larvaltreatments_species'] ['column_name'] = "mosquitospecies";
		}
        
		//print'<pre>';
//        print_r($data_result);
//        
//        $this->db->select ( 'l.idlarvaltreatment, l.date' );
//		$this->db->from ( 'larvaltreatments AS l' );
//        $this->db->join ( 'sites AS s', 'l.idsite = s.idsite', 'LEFT' );
//        $this->db->where ( "s.`idlocation` = '" . $id_location . "'" );
//        $larvaltreat_species = $this->db->get ();
//        print_r($larvaltreat_species->result_array());
//        die;
		// code for larvaltreatments - applicator
		$this->db->select ( "users.username, users.firstname, users.lastname, users.middlename, lt.idlarvaltreatment, lt.date, s.site, s.address1, ps.productname,concat(users.`firstname`,' ',users.`lastname`) as 'full_name'", FALSE );
		$this->db->from ( 'users AS users' );
		$this->db->join ( 'larvaltreatments AS lt', 'users.iduser = lt.idapplicator', 'INNER' );
		$this->db->join ( 'sites AS s', 'lt.idsite = s.idsite', 'INNER' );
		$this->db->join ( 'products AS ps', 'lt.idproduct = ps.idproduct', 'INNER' );
		
		$this->db->where ( "`s`.`idlocation` = '" . $id_location . "' AND (`users`.`username` LIKE '%" . $data . "%' OR `users`.`firstname` LIKE '%" . $data . "%' OR `users`.`lastname` LIKE '%" . $data . "%' OR `users`.`middlename` LIKE '%" . $data . "%' OR concat(users.firstname,' ',users.lastname) LIKE '%" . $data . "%')" );
		
		$larvaltreat_applicator = $this->db->get ();
		
		$sw = "";
		foreach ( $larvaltreat_applicator->result_array () as $val ) {
			preg_match ( "/" . $data . "/i", $val ['username'], $matches_1 );
			preg_match ( "/" . $data . "/i", $val ['firstname'], $matches_2 );
			preg_match ( "/" . $data . "/i", $val ['lastname'], $matches_3 );
			if (! empty ( $val ['middlename'] ))
				preg_match ( "/" . $data . "/i", $val ['middlename'], $matches_4 );
			preg_match ( "/" . $data . "/i", $val ['full_name'], $matches_5 );
			if ($matches_1)
				$sw = "username";
			
			elseif ($matches_2)
				$sw = "firstname";
			
			elseif ($matches_3)
				$sw = "lastname";
			
			elseif (! empty ( $val ['middlename'] ) && $matches_4)
				$sw = "middlename";
			
			elseif ($matches_5)
				$sw = "full_name";
		}
		if ($larvaltreat_applicator->num_rows () > 0) {
			$data_result ['larvaltreatments_applicator'] = $larvaltreat_applicator->result_array ();
			$data_result ['larvaltreatments_applicator'] ['column_name'] = $sw;
		}
		
		// code for larvaltreatments - product
		$this->db->select ( 'ps.productname, ps.description, ps.productlink, lt.idlarvaltreatment, lt.date, s.site, s.address1' );
		$this->db->from ( 'products AS ps' );
		$this->db->join ( 'larvaltreatments AS lt', 'ps.idproduct = lt.idproduct', 'LEFT' );
		$this->db->join ( 'sites AS s', 'lt.idsite = s.idsite', 'LEFT' );
		
		$this->db->where ( "`s`.`idlocation` = '" . $id_location . "' AND (ps.productname LIKE '%" . $data . "%' OR ps.description LIKE '%" . $data . "%' OR ps.productlink LIKE '%" . $data . "%')" );
		
		$larvaltreat_product = $this->db->get ();
		// echo $this->db->last_query();
		
		// die;
		$sw = "";
		foreach ( $larvaltreat_product->result_array () as $val ) {
			preg_match ( "/" . $data . "/i", $val ['productname'], $matches_1 );
			preg_match ( "/" . $data . "/i", $val ['description'], $matches_2 );
			preg_match ( "/" . $data . "/i", $val ['productlink'], $matches_3 );
			if ($matches_1)
				$sw = "productname";
			
			elseif ($matches_2)
				$sw = "description";
			
			elseif ($matches_3)
				$sw = "productlink";
		}
		if ($larvaltreat_product->num_rows () > 0) {
			$data_result ['larvaltreatments_product'] = $larvaltreat_product->result_array ();
			$data_result ['larvaltreatments_product'] ['column_name'] = $sw;
		}
		
		// code for larvaltreatments - formulations
		$this->db->select ( 'fr.*, lt.*, s.*, ps.*' );
		$this->db->from ( 'formulations AS fr' );
        $this->db->join ( 'products AS ps', 'ps.idformulation = fr.idformulation', 'INNER' );
        $this->db->join ( 'larvaltreatments AS lt', 'lt.idproduct = ps.idproduct', 'INNER' );
		$this->db->join ( 'sites AS s', 'lt.idsite = s.idsite', 'INNER' );
		
		$this->db->where ( "`s`.`idlocation` = '" . $id_location . "' AND (fr.formulation LIKE '%" . $data . "%' )" );
		
		$larvaltreat_formulations = $this->db->get ();
		
		if ($larvaltreat_formulations->num_rows () > 0) {
			$data_result ['larvaltreatments_formulations'] = $larvaltreat_formulations->result_array ();
			$data_result ['larvaltreatments_formulations'] ['column_name'] = "formulation";
		}
		
		// code for adultsurveillance - trap
		// echo $id_location;
		// die;
		$this->db->select ( 'asr.idadultsurveillance, asr.setdate,asr.pudate,asr.eggraftcount,asr.totalcount, t.trap, t.maplabel,  s.site, s.address1,s.address2,s.city,st.statename' );
		$this->db->from ( 'adultsurveillance AS asr' );
		$this->db->join ( 'traps AS t', 'asr.idtrap = t.idtrap', 'LEFT' );
		$this->db->join ( 'sites AS s', 't.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'states AS st', 's.idstate = st.idstate', 'LEFT' );
		$this->db->where ( "asr.idlocation = " . $id_location . " AND `s`.`isdeleted`='0' AND `asr`.`isdeleted` = '0' AND ((t.trap LIKE '%" . $data . "%') OR (t.maplabel LIKE '%" . $data . "%'))" );
		$this->db->where ( 's.idlocation', $id_location );
		$adultsurve_trap = $this->db->get ();
		
		// echo $this->db->last_query();
		// die;
		$sw = "";
		foreach ( $adultsurve_trap->result_array () as $val ) {
			preg_match ( "/" . $data . "/i", $val ['trap'], $matches_1 );
			preg_match ( "/" . $data . "/i", $val ['maplabel'], $matches_2 );
			if ($matches_1)
				$sw = "trap";
			
			elseif ($matches_2)
				$sw = "maplabel";
		}
		if ($adultsurve_trap->num_rows () > 0) {
			$data_result ['adultsurveillance_trap'] = $adultsurve_trap->result_array ();
			$data_result ['adultsurveillance_trap'] ['column_name'] = $sw;
		}
		
		// code for adultsurveillance
		$this->db->select ( 'asr.*, s.*' );
		$this->db->from ( 'adultsurveillance AS asr' );
		$this->db->join ( 'traps AS tr', 'asr.idtrap = tr.idtrap', 'INNER' );
		$this->db->join ( 'sites AS s', 'tr.idsite = s.idsite', 'INNER' );
		$this->db->where ( 'asr.idlocation', $id_location );
		$this->db->like ( 'comments', $data );
		$adultsurve = $this->db->get ();
		
		if ($adultsurve->num_rows () > 0) {
			$data_result ['adultsurveillance'] = $adultsurve->result_array ();
			$data_result ['adultsurveillance'] ['column_name'] = "comments";
		}
		
		// code for larvalsurveillance - sites
		$this->db->select ( 's.*, lsr.idlarvalsurveillance, lsr.date' );
		$this->db->from ( 'sites AS s' );
		$this->db->join ( 'larvalsurveillance AS lsr', 's.idsite = lsr.idsite', 'INNER' );
		
		$this->db->where ( "`s`.`idlocation` = " . $id_location . " AND `s`.`isdeleted`='0' AND 
(`s`.`site` LIKE '%" . $data . "%' OR `s`.`maplabel` LIKE '%" . $data . "%' OR `s`.`address1` LIKE '%" . $data . "%' OR `s`.`address2` LIKE '%" . $data . "%' OR `s`.`city` LIKE '%" . $data . "%' OR `s`.`manphone` LIKE '%" . $data . "%' OR `s`.`alternatephone` LIKE '%" . $data . "%' OR `s`.`faxnumber` LIKE '%" . $data . "%')" );
		
		$larvalsurve_site = $this->db->get ();
		
		// echo $this->db->last_query();
		// die;
		$sw = "";
		foreach ( $larvalsurve_site->result_array () as $val ) {
			// $pattern = addcslashes($data,')(.\/ -');
			preg_match ( "/" . $data . "/i", $val ['site'], $matches_1 );
			preg_match ( "/" . $data . "/i", $val ['maplabel'], $matches_2 );
			preg_match ( "/" . $data . "/i", $val ['address1'], $matches_3 );
			preg_match ( "/" . $data . "/i", $val ['address2'], $matches_4 );
			preg_match ( "/" . $data . "/i", $val ['city'], $matches_5 );
			preg_match ( "/" . $data . "/i", $val ['manphone'], $matches_6 );
			preg_match ( "/" . $data . "/i", $val ['alternatephone'], $matches_7 );
			preg_match ( "/" . $data . "/i", $val ['faxnumber'], $matches_8 );
			if ($matches_1)
				$sw = "site";
			
			elseif ($matches_2)
				$sw = "maplabel";
			
			elseif ($matches_3)
				$sw = "address1";
			
			elseif ($matches_4)
				$sw = "address2";
			
			elseif ($matches_5)
				$sw = "city";
			
			elseif ($matches_6)
				$sw = "manphone";
			elseif ($matches_7)
				$sw = "alternatephone";
			elseif ($matches_8)
				$sw = "faxnumber";
		}
		
		if ($larvalsurve_site->num_rows () > 0) {
			$data_result ['larvalsurveillance_site'] = $larvalsurve_site->result_array ();
			$data_result ['larvalsurveillance_site'] ['column_name'] = $sw;
		}
		
		// code for larvalsurveillance - zone
		$this->db->select ( 'z.zone, z.description, lsr.idlarvalsurveillance, lsr.date, s.site, s.latitude, s.longitude' );
		$this->db->from ( 'zones AS z' );
		$this->db->join ( 'larvalsurveillance AS lsr', 'z.idzone = lsr.idzone', 'INNER' );
		$this->db->join ( 'sites AS s', 'lsr.idsite = s.idsite', 'INNER' );
		$this->db->where ( "`z`.`idlocation` = '" . $id_location . "' AND `z`.`isdeleted` = '0' AND (`z`.`zone` LIKE '%" . $data . "%' OR `z`.`description` LIKE '%" . $data . "%')" );
		
		$larvalsurve_zone = $this->db->get ();
		
		// echo $this->db->last_query();
		// die;
		$sw = "";
		foreach ( $larvalsurve_zone->result_array () as $val ) {
			preg_match ( "/" . $data . "/i", $val ['zone'], $matches_1 );
			preg_match ( "/" . $data . "/i", $val ['description'], $matches_2 );
			if ($matches_1)
				$sw = "zone";
			
			elseif ($matches_2)
				$sw = "description";
		}
		if ($larvalsurve_zone->num_rows () > 0) {
			$data_result ['larvalsurveillance_zone'] = $larvalsurve_zone->result_array ();
			$data_result ['larvalsurveillance_zone'] ['column_name'] = $sw;
		}
		
		// code for larvalsurveillance - sitetype
		$this->db->select ( 'sty.*, lsr.*, s.*' );
		$this->db->from ( 'sitetypes AS sty' );
		$this->db->join ( 'larvalsurveillance AS lsr', 'sty.idsitetype = lsr.idsitetype', 'INNER' );
		$this->db->join ( 'sites AS s', 'lsr.idsite = s.idsite', 'INNER' );
		$this->db->where ( 's.idlocation', $id_location );
		$this->db->like ( 'sty.sitetype', $data, 'both' );
		$larvalsurve_sitetype = $this->db->get ();
		if ($larvalsurve_sitetype->num_rows () > 0) {
			$data_result ['larvalsurveillance_sitetype'] = $larvalsurve_sitetype->result_array ();
			$data_result ['larvalsurveillance_sitetype'] ['column_name'] = "sitetype";
		}
		
		// code for larvalsurveillance - comment
		$this->db->select ( 'lsr.*, s.*' );
		$this->db->from ( 'larvalsurveillance AS lsr' );
		$this->db->join ( 'sites AS s', 'lsr.idsite = s.idsite', 'INNER' );
		$this->db->where ( 's.idlocation', $id_location );
		$this->db->like ( 'lsr.comments', $data, 'both' );
		$larvalsurve_comment = $this->db->get ();
		if ($larvalsurve_comment->num_rows () > 0) {
			$data_result ['larvalsurveillance_comment'] = $larvalsurve_comment->result_array ();
			$data_result ['larvalsurveillance_comment'] ['column_name'] = "comments";
		}
		
		// code for larvalsurveillance - inspector
		$this->db->select ( 'us.username, us.firstname, us.lastname, us.middlename, us.email, lsr.idlarvalsurveillance, lsr.date, s.site, s.address1' );
		$this->db->from ( 'users AS us' );
		$this->db->join ( 'larvalsurveillance AS lsr', 'us.iduser = lsr.idinspector', 'INNER' );
		$this->db->join ( 'sites AS s', 'lsr.idsite = s.idsite', 'INNER' );
		$this->db->where ( "`s`.`idlocation` = '" . $id_location . "' AND `s`.`isdeleted`='0' AND `us`.`isdeleted` = '0' AND (`us`.`username` LIKE '%" . $data . "%' OR `us`.`firstname` LIKE '%" . $data . "%' OR `us`.`lastname` LIKE '%" . $data . "%' OR `us`.`middlename` LIKE '%" . $data . "%' OR `us`.`email` LIKE '%" . $data . "%')" );
		$this->db->where ( 's.idlocation', $id_location );
		$larvalsurve_applicator = $this->db->get ();
		
		$sw = "";
		foreach ( $larvalsurve_applicator->result_array () as $val ) {
			preg_match ( "/" . $data . "/i", $val ['username'], $matches_1 );
			preg_match ( "/" . $data . "/i", $val ['firstname'], $matches_2 );
			preg_match ( "/" . $data . "/i", $val ['lastname'], $matches_3 );
			if (! empty ( $val ['middlename'] ))
				preg_match ( "/" . $data . "/i", $val ['middlename'], $matches_4 );
			preg_match ( "/" . $data . "/i", $val ['email'], $matches_5 );
			if ($matches_1)
				$sw = "username";
			
			elseif ($matches_2)
				$sw = "firstname";
			
			elseif ($matches_3)
				$sw = "lastname";
			
			elseif (! empty ( $val ['middlename'] ) && $matches_4)
				$sw = "middlename";
			
			elseif ($matches_5)
				$sw = "email";
		}
		if ($larvalsurve_applicator->num_rows () > 0) {
			$data_result ['larvalsurveillance_applicator'] = $larvalsurve_applicator->result_array ();
			$data_result ['larvalsurveillance_applicator'] ['column_name'] = $sw;
		}
		
		// code for Lab (Arbovirus)
		$this->db->select ( "at.assaytype,al.idarbovirallab, al.testdate AS date, al.poolsize , u.username,u.firstname,u.lastname, u.email, s.site, s.address1 , s.address1,s.address2,s.city,st.statename , t.trap , lr.labresult , m.mosquitospecies , g.genus" );
		$this->db->from ( 'arbovirallabs AS al' );
		$this->db->join ( 'users AS u', 'al.idlabtechnician = u.iduser', 'LEFT' );
		$this->db->join ( 'assaytypes AS at', 'al.idassaytype = at.idassaytype', 'LEFT' );
		$this->db->join ( 'mosquitospecies AS m', 'al.idmosquitospecies = m.idmosquitospecies', 'LEFT' );
		$this->db->join ( 'genuses AS g', 'm.idgenus = g.idgenus', 'LEFT' );
		$this->db->join ( 'labresults AS lr', 'al.idlabresult = lr.idlabresult', 'LEFT' );
		$this->db->join ( 'traps AS t', 'al.idtrap = t.idtrap', 'LEFT' );
		$this->db->join ( 'sites AS s', 't.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'states AS st', 's.idstate = st.idstate', 'LEFT' );
		$this->db->where ( "`s`.`idlocation` = '" . $id_location . "' AND `s`.`isdeleted`='0' AND `al`.`isdeleted` = '0' AND (u.username LIKE '%" . $data . "%' OR u.firstname LIKE '%" . $data . "%' OR u.lastname LIKE '%" . $data . "%' OR u.middlename LIKE '%" . $data . "%' OR u.email LIKE '%" . $data . "%' OR al.comments LIKE '%" . $data . "%' OR concat(u.firstname,' ',u.lastname) LIKE '%" . $data . "%')" );
		$this->db->where ( 's.idlocation', $id_location );
		$lab_arbovirus = $this->db->get ();
		
		$sw = "";
		foreach ( $lab_arbovirus->result_array () as $val ) {
			
			preg_match ( "/" . $data . "/i", $val ['username'], $matches_1 );
			preg_match ( "/" . $data . "/i", $val ['firstname'], $matches_2 );
			preg_match ( "/" . $data . "/i", $val ['lastname'], $matches_3 );
			
			if (! empty ( $val ['middlename'] ))
				preg_match ( "/" . $data . "/i", $val ['middlename'], $matches_4 );
			
			preg_match ( "/" . $data . "/i", $val ['email'], $matches_5 );
			preg_match ( "/" . $data . "/i", $val ['comments'], $matches_6 );
			if ($matches_1)
				$sw = "username";
			
			elseif ($matches_2)
				$sw = "firstname";
			
			elseif ($matches_3)
				$sw = "lastname";
			
			elseif (! empty ( $val ['middlename'] ) && $matches_4)
				$sw = "middlename";
			
			elseif ($matches_5)
				$sw = "email";
			
			elseif ($matches_6)
				$sw = "comments";
		}
		if ($lab_arbovirus->num_rows () > 0) {
			$data_result ['lab_arbovirus'] = $lab_arbovirus->result_array ();
			$data_result ['lab_arbovirus'] ['column_name'] = $sw;
		}
		
		// code for Lab (Corvid)
		$this->db->select ( "sl.*, s.site, s.address1 , s.address1,s.address2,s.city,st.statename ,lr.labresult,z.zone,z.description" );
		$this->db->from ( 'corvidlabs AS sl' );
		$this->db->join ( 'sites AS s', 'sl.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'states AS st', 's.idstate = st.idstate', 'LEFT' );
		$this->db->join ( 'zones AS z', 'sl.idzone = z.idzone', 'LEFT' );
		$this->db->join ( 'labresults AS lr', 'sl.idlabresult = lr.idlabresult', 'LEFT' );
		$this->db->where ( "`s`.`idlocation` = '" . $id_location . "' AND `z`.`idlocation` = '" . $id_location . "' AND `s`.`isdeleted`='0' AND `z`.`isdeleted` = '0' AND `sl`.`isdeleted` = '0' AND (z.zone LIKE '%" . $data . "%' OR z.description LIKE '%" . $data . "%' OR lr.labresult LIKE '%" . $data . "%' OR s.site LIKE '%" . $data . "%' OR sl.comments LIKE '%" . $data . "%' OR st.statename LIKE '%" . $data . "%' OR s.address1 LIKE '%" . $data . "%')" );
		
		$lab_corvid = $this->db->get ();
		
		$sw = "";
		foreach ( $lab_corvid->result_array () as $val ) {
			
			preg_match ( "/" . $data . "/i", $val ['zone'], $matches_1 );
			preg_match ( "/" . $data . "/i", $val ['description'], $matches_2 );
			preg_match ( "/" . $data . "/i", $val ['labresult'], $matches_3 );
			preg_match ( "/" . $data . "/i", $val ['site'], $matches_4 );
			preg_match ( "/" . $data . "/i", $val ['statename'], $matches_5 );
			preg_match ( "/" . $data . "/i", $val ['address1'], $matches_6 );
			preg_match ( "/" . $data . "/i", $val ['comments'], $matches_7 );
			
			if ($matches_1)
				$sw = "zone";
			
			elseif ($matches_2)
				$sw = "description";
			
			elseif ($matches_3)
				$sw = "labresult";
			
			elseif ($matches_4)
				$sw = "site";
			
			elseif ($matches_5)
				$sw = "statename";
			
			elseif ($matches_6)
				$sw = "address1";
			
			elseif ($matches_7)
				$sw = "comments";
		}
		if ($lab_corvid->num_rows () > 0) {
			$data_result ['lab_corvid'] = $lab_corvid->result_array ();
			$data_result ['lab_corvid'] ['column_name'] = $sw;
		}
		
		// code for Lab (Sentinel)
		$this->db->select ( "sl.idsentinelchickenlab,sl.idsample, sl.datebled,sl.datesubmitted , sl.dateresults,sl.comments, sc.flockname , s.site, s.address1 , s.address1,s.address2,s.city,st.statename ,lr.labresult,z.zone,z.description" );
		$this->db->from ( 'sentinelchickenlabs AS sl' );
		$this->db->join ( 'sentinelchicken AS sc', 'sl.idsentinelchicken = sc.idsentinelchicken', 'LEFT' );
		$this->db->join ( 'sites AS s', 'sc.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'states AS st', 's.idstate = st.idstate', 'LEFT' );
		$this->db->join ( 'zones AS z', 'sc.idzone = z.idzone', 'LEFT' );
		$this->db->join ( 'labresults AS lr', 'sl.idlabresult = lr.idlabresult', 'LEFT' );
		$this->db->where ( "`s`.`idlocation` = '" . $id_location . "' AND `z`.`idlocation` = '" . $id_location . "' AND `s`.`isdeleted`='0' AND `z`.`isdeleted` = '0' AND `sl`.`isdeleted` = '0' AND (z.zone LIKE '%" . $data . "%' OR z.description LIKE '%" . $data . "%' OR lr.labresult LIKE '%" . $data . "%' OR s.site LIKE '%" . $data . "%' OR sl.comments LIKE '%" . $data . "%' OR st.statename LIKE '%" . $data . "%' OR s.address1 LIKE '%" . $data . "%')" );
		
		$lab_senti = $this->db->get ();
		
		$sw = "";
		foreach ( $lab_senti->result_array () as $val ) {
			
			preg_match ( "/" . $data . "/i", $val ['zone'], $matches_1 );
			preg_match ( "/" . $data . "/i", $val ['description'], $matches_2 );
			preg_match ( "/" . $data . "/i", $val ['labresult'], $matches_3 );
			preg_match ( "/" . $data . "/i", $val ['site'], $matches_4 );
			preg_match ( "/" . $data . "/i", $val ['statename'], $matches_5 );
			preg_match ( "/" . $data . "/i", $val ['address1'], $matches_6 );
			preg_match ( "/" . $data . "/i", $val ['comments'], $matches_7 );
			
			if ($matches_1)
				$sw = "zone";
			
			elseif ($matches_2)
				$sw = "description";
			
			elseif ($matches_3)
				$sw = "labresult";
			
			elseif ($matches_4)
				$sw = "site";
			
			elseif ($matches_5)
				$sw = "statename";
			
			elseif ($matches_6)
				$sw = "address1";
			
			elseif ($matches_7)
				$sw = "comments";
		}
		if ($lab_senti->num_rows () > 0) {
			$data_result ['lab_senti'] = $lab_senti->result_array ();
			$data_result ['lab_senti'] ['column_name'] = $sw;
		}
		
		// code for Landing Rate
		$this->db->select ( "l.* , s.site, s.address1 , s.address1,s.address2,s.city,st.statename ,z.zone,z.description" );
		$this->db->from ( 'landingrates AS l' );
		$this->db->join ( 'sites AS s', 'l.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'states AS st', 's.idstate = st.idstate', 'LEFT' );
		$this->db->join ( 'zones AS z', 'l.idzone = z.idzone', 'LEFT' );
		$this->db->where ( "`s`.`idlocation` = '" . $id_location . "' AND `z`.`idlocation` = '" . $id_location . "' AND `s`.`isdeleted`='0' AND `z`.`isdeleted` = '0' AND `l`.`isdeleted` = '0' AND (z.zone LIKE '%" . $data . "%' OR z.description LIKE '%" . $data . "%' OR s.site LIKE '%" . $data . "%' OR l.comments LIKE '%" . $data . "%' OR st.statename LIKE '%" . $data . "%' OR s.address1 LIKE '%" . $data . "%')" );
		
		$landing = $this->db->get ();
		
		$sw = "";
		foreach ( $landing->result_array () as $val ) {
			
			preg_match ( "/" . $data . "/i", $val ['zone'], $matches_1 );
			preg_match ( "/" . $data . "/i", $val ['description'], $matches_2 );
			preg_match ( "/" . $data . "/i", $val ['site'], $matches_4 );
			preg_match ( "/" . $data . "/i", $val ['statename'], $matches_5 );
			preg_match ( "/" . $data . "/i", $val ['address1'], $matches_6 );
			preg_match ( "/" . $data . "/i", $val ['comments'], $matches_7 );
			
			if ($matches_1)
				$sw = "zone";
			
			elseif ($matches_2)
				$sw = "description";
			
			elseif ($matches_4)
				$sw = "site";
			
			elseif ($matches_5)
				$sw = "statename";
			
			elseif ($matches_6)
				$sw = "address1";
			
			elseif ($matches_7)
				$sw = "comments";
		}
		if ($landing->num_rows () > 0) {
			$data_result ['landing'] = $landing->result_array ();
			$data_result ['landing'] ['column_name'] = $sw;
		}
		
		// code for adult adultsurveillance inspector
		$this->db->select ( "ast.*,s.idsite ,s.site,s.address1 , s.address1,s.address2,s.city,st.statename, users.username,users.firstname,users.lastname,users.middlename,concat(users.firstname,' ',users.lastname) as 'full_name',users.email, ms.mosquitospecies", FALSE );
		$this->db->from ( 'adultsurveillance as `ast`' );
		$this->db->join ( 'traps as t', 'ast.idtrap = t.idtrap', 'LEFT' );
		$this->db->join ( 'sites as s', 't.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'states as st', 's.idstate = st.idstate', 'LEFT' );
		$this->db->join ( 'users as users', 'ast.idinspector=users.iduser', 'LEFT' );
        $this->db->join ( 'adultsurveillancedetails as `adst`', 'adst.idadultsurveillance = ast.idadultsurveillance', 'LEFT' );
        $this->db->from ( 'mosquitospecies AS ms', 'adst.idmosquitospecies = ms.idmosquitospecies', 'LEFT' );
		$this->db->where ( "ast.idlocation ='" . $id_location . "' AND `s`.`isdeleted`='0' AND `users`.`isdeleted` = '0' AND `ast`.`isdeleted` = '0' AND (users.username LIKE '%" . $data . "%' OR users.firstname LIKE '%" . $data . "%' OR users.lastname LIKE '%" . $data . "%' OR users.middlename LIKE '%" . $data . "%' OR users.email LIKE '%" . $data . "%' OR concat(users.firstname,' ',users.lastname) LIKE '%" . $data . "%' OR ms.mosquitospecies LIKE '%" . $data . "%' )" );
		$this->db->order_by ( 'ast.idadultsurveillance', 'desc' );
		
		$adult_inspector = $this->db->get ();
		// echo $this->db->last_query();
		$sw = "";
		foreach ( $adult_inspector->result_array () as $val ) {
			preg_match ( "/" . $data . "/i", $val ['username'], $matches_1 );
			preg_match ( "/" . $data . "/i", $val ['firstname'], $matches_2 );
			preg_match ( "/" . $data . "/i", $val ['lastname'], $matches_3 );
			
			if (! empty ( $val ['middlename'] ))
				preg_match ( "/" . $data . "/i", $val ['middlename'], $matches_4 );
			
			preg_match ( "/" . $data . "/i", $val ['email'], $matches_5 );
			preg_match ( "/" . $data . "/i", $val ['full_name'], $matches_6 );
            preg_match ( "/" . $data . "/i", $val ['mosquitospecies'], $matches_7 );
            
			if ($matches_1)
				$sw = "username";
			
			elseif ($matches_2)
				$sw = "firstname";
			
			elseif ($matches_3)
				$sw = "lastname";
			
			elseif (! empty ( $val ['middlename'] ) && $matches_4)
				$sw = "middlename";
			
			elseif ($matches_5)
				$sw = "email";
			
			elseif ($matches_6)
				$sw = "full_name";
            
            elseif ($matches_7)
				$sw = "mosquitospecies";
		}
		
		if ($adult_inspector->num_rows () > 0) {
			$data_result ['adult_inspector'] = $adult_inspector->result_array ();
			$data_result ['adult_inspector'] ['column_name'] = $sw;
		}
		
		// code for Adult Treatment Equipment ID
		$this->db->select ( 'act.*, s.site, s.address1,apm.applicationmethod,st.systemtype,art.applicationratetype,pds.productname' );
		$this->db->from ( 'adulticidetreatments act' );
		$this->db->join ( 'sites AS s', 's.idsite = act.idsite', 'INNER' );
		
		$this->db->join ( 'applicationmethods as apm', 'act.idapplicationmethod=apm.idapplicationmethods', 'INNER' );
		$this->db->join ( 'systemtypes as st', 'act.idsystemtype=st.idsystemtype', 'INNER' );
		$this->db->join ( 'applicationratetypes as art', 'act.idapplicationratetype=art.idapplicationratetypes', 'INNER' );
		$this->db->join ( 'products as pds', 'act.idproduct=pds.idproduct', 'INNER' );
		$this->db->where ( "s.`idlocation` = " . $id_location . " AND `s`.`isdeleted`='0' AND `act`.`isdeleted` = '0' AND (pds.eparegistration LIKE '%" . $data . "%')" );
		
		$adulttreat = $this->db->get ();
		
		// echo $this->db->last_query();
		if ($adulttreat->num_rows () > 0) {
			$data_result ['adulttreatment_prdct'] = $adulttreat->result_array ();
			$data_result ['adulttreatment_prdct'] ['column_name'] = "eparegistration";
		}
		
		// code for Larval Treatment Equipment ID
		$this->db->select ( 'lt.*, s.site, s.address1,pds.productname,pds.eparegistration AS equipemtnid' );
		$this->db->from ( 'larvaltreatments lt' );
		$this->db->join ( 'sites AS s', 'lt.idsite = s.idsite', 'INNER' );
		$this->db->join ( 'products as pds', 'lt.idproduct=pds.idproduct', 'INNER' );
		$this->db->where ( "s.`idlocation` = " . $id_location . " AND `s`.`isdeleted`='0' AND `lt`.`isdeleted` = '0' AND (pds.eparegistration LIKE '%" . $data . "%')" );
		
		$larvaltreat = $this->db->get ();
		
		// echo $this->db->last_query();
		if ($larvaltreat->num_rows () > 0) {
			$data_result ['larvaltreatment_prdct'] = $larvaltreat->result_array ();
			$data_result ['larvaltreatment_prdct'] ['column_name'] = "equipemtnid";
		}
		// print'<pre>';
		// print_r($data_result);
		// die;
		
		/**
		 * ----------------------------
		 */
		
		// code for Site Management
		$this->db->select ( 's.* , st.statename' );
		$this->db->from ( 'sites AS s' );
		$this->db->join ( 'states AS st', 's.idstate = st.idstate', 'LEFT' );
		$this->db->join ( 'zones AS z', 's.idzone = z.idzone', 'LEFT' );
		$this->db->join ( 'sitetypes AS sty', 's.idsitetype = sty.idsitetype', 'LEFT' );
		$this->db->where ( "s.`idlocation` = " . $id_location . " AND `s`.`isdeleted`='0' AND (s.manphone LIKE '%" . $data . "%' OR s.alternatephone LIKE '%" . $data . "%' OR s.faxnumber LIKE '%" . $data . "%' )" );
		
		$site = $this->db->get ();
		// echo $this->db->last_query();
		$sw = "";
		if ($site->num_rows () > 0) {
			// $pattern = addcslashes($data,')(.\/ -');
			foreach ( $site->result_array () as $val ) {
				
				preg_match ( "/$data/i", $val ['manphone'], $matches_1 );
				preg_match ( "/$data/i", $val ['alternatephone'], $matches_2 );
				preg_match ( "/$data/i", $val ['faxnumber'], $matches_3 );
				
				if ($matches_1)
					$sw = "manphone";
				
				elseif ($matches_2)
					$sw = "alternatephone";
				
				elseif ($matches_3)
					$sw = "faxnumber";
			}
			$data_result ['site'] = $site->result_array ();
			$data_result ['site'] ['column_name'] = $sw;
		}
		// print'<pre>';
		// print_r($data_result);
		// die;
		
		/**
		 * ----------------------------
		 */
		// code for service request
		$this->db->select ( "sr.*,s.idsite ,s.site,s.address1 , s.address1,s.address2,s.city,st.statename , z.zone" );
		$this->db->from ( 'servicerequests as `sr`' );
		$this->db->join ( 'sites as s', 'sr.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'states as st', 's.idstate = st.idstate', 'LEFT' );
		$this->db->join ( 'zones as z', 's.idzone = z.idzone', 'LEFT' );
		$this->db->where ( "s.idlocation ='" . $id_location . "' AND z.idlocation ='" . $id_location . "' AND `s`.`isdeleted`='0' AND `z`.`isdeleted` = '0' AND `sr`.`isdeleted` = '0' AND (z.zone LIKE '%" . $data . "%' OR sr.comments LIKE '%" . $data . "%' OR sr.mainphone LIKE '%" . $data . "%' OR sr.altphone LIKE '%" . $data . "%' OR sr.faxphone LIKE '%" . $data . "%' OR `s`.`address1` LIKE '%" . $data . "%' OR `s`.`address2` LIKE '%" . $data . "%' OR `s`.`site` LIKE '%" . $data . "%')" );
		$this->db->order_by ( 'sr.idservicerequest', 'desc' );
		
		$service_zone = $this->db->get ();
		$service_zone_records = array ();
		
		$count = 0;
		foreach ( $service_zone->result_array () as $val ) {
			$sw = "";
			preg_match ( "/" . $data . "/i", $val ['zone'], $matches_1 );
			preg_match ( "/" . $data . "/i", $val ['comments'], $matches_2 );
			preg_match ( "/$data/i", $val ['mainphone'], $matches_3 );
			preg_match ( "/$data/i", $val ['altphone'], $matches_4 );
			preg_match ( "/$data/i", $val ['faxphone'], $matches_5 );
			preg_match ( "/" . $data . "/i", $val ['address1'], $matches_6 );
			preg_match ( "/" . $data . "/i", $val ['address2'], $matches_7 );
			preg_match ( "/" . $data . "/i", $val ['site'], $matches_8 );
			
			if ($matches_1)
				$sw = "zone";
			else if ($matches_2)
				$sw = "comments";
			else if ($matches_3)
				$sw = "mainphone";
			else if ($matches_4)
				$sw = "altphone";
			else if ($matches_5)
				$sw = "faxphone";
			else if ($matches_6)
				$sw = "address1";
			else if ($matches_7)
				$sw = "address2";
			else if ($matches_8)
				$sw = "site";
				// echo " Column : $sw <br>";
			
			if (! empty ( $sw )) {
				$data_result ['service'] [$count] = $val;
				$data_result ['service'] [$count] ['column_name'] = $sw;
				$count ++;
			}
		}
		
		$data_result ['search_word'] = stripcslashes ( $data );
		if (! empty ( $data_result )) {
			// echo "<pre>";
			// print_r($data_result);
			// die;
			return $data_result;
		}
	}
}
?>