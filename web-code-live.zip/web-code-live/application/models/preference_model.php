<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Preference_model extends CI_Model {
	public $data = array ();
	public $str;
	public $flag = 0;
	/**
	 * Constructor for the class
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}

	/**
	 * Function to save Preferences
	 */
	public function savePreference($idlocation = '') {
		$idlocation = $this->session->userdata ( 'idlocation' );
		$rainfallexceeds = $this->input->post ( 'rainfallexceeds' );
		$trapcountmosquito = $this->input->post ( 'trapcountmosquito' );
		$trapcountvector = $this->input->post ( 'trapcountvector' );
		$callsexceed = $this->input->post ( 'callsexceed' );
		$landingrateexceeds = $this->input->post ( 'landingrateexceeds' );

		$rainfallactive = $this->input->post ( 'rainfallactive' );
		$trapcountmosquitoactive = $this->input->post ( 'trapcountmosquitoactive' );
		$trapcountvectoractive = $this->input->post ( 'trapcountvectoractive' );
		$callsactive = $this->input->post ( 'callsactive' );
		$landingrateexceedsactive = $this->input->post ( 'landingrateexceedsactive' );
		$seasondates = $this->input->post ( 'season_date' );
		$seasondatesdeleted = $this->input->post ( 'season_date_deleted' );

		if (! empty ( $rainfallactive )) {
			$data ['rainfallexceeds'] = ! empty ( $rainfallexceeds ) ? $rainfallexceeds : '';
			$data ['rainfallactive'] = '1';
		} else {
			$data ['rainfallexceeds'] = '';
			$data ['rainfallactive'] = "0";
		}

		if (! empty ( $trapcountmosquitoactive )) {
			$data ['trapcountmosquito'] = ! empty ( $trapcountmosquito ) ? $trapcountmosquito : '';
			$data ['trapcountmosquitoactive'] = '1';
		} else {
			$data ['trapcountmosquito'] = '';
			$data ['trapcountmosquitoactive'] = "0";
		}

		if (! empty ( $trapcountvectoractive )) {
			$data ['trapcountvector'] = ! empty ( $trapcountvector ) ? $trapcountvector : '';
			$data ['trapcountvectoractive'] = '1';
		} else {
			$data ['trapcountvector'] = '';
			$data ['trapcountvectoractive'] = "0";
		}

		if (! empty ( $callsactive )) {
			$data ['callsexceed'] = ! empty ( $callsexceed ) ? $callsexceed : '';
			$data ['callsactive'] = '1';
		} else {
			$data ['callsexceed'] = '';
			$data ['callsactive'] = "0";
		}

		if (! empty ( $landingrateexceedsactive )) {
			$data ['landingrateexceeds'] = ! empty ( $landingrateexceeds ) ? $landingrateexceeds : '';
			$data ['landingrateexceedsactive'] = '1';
		} else {
			$data ['landingrateexceeds'] = '';
			$data ['landingrateexceeds'] = "0";
		}

		$data ['idlocation'] = ! empty ( $idlocation ) ? $idlocation : '';
		$idlocationprfr = "";

		if (! empty ( $seasondatesdeleted ))
		{
			foreach ( $seasondatesdeleted as $id )
			{
				$this->db->query ( "SET FOREIGN_KEY_CHECKS = 0" );
				$this->db->where ( 'idseasondate', $id );
				$this->db->delete ( 'seasondates' );
			}
		}
		if (! empty ( $seasondates )) {

			$seasondates = array_chunk($seasondates, 3);

			foreach ( $seasondates as $val )
			{
				$data_1 = array ();
				$data_1 ['idlocation'] = $idlocation;
				$data_1 ['year'] = $val[0];
				$data_1 ['month'] = $val[1];
				$data_1 ['day'] = $val[2];

				$this->db->query ( "SET FOREIGN_KEY_CHECKS = 0" );
				$this->db->insert ( 'seasondates', $data_1 );
				$this->db->query ( "SET FOREIGN_KEY_CHECKS = 1" );
				$this->flag = 1;
			}

		}

		if (! empty ( $rainfallactive ) || ! empty ( $trapcountmosquitoactive ) || ! empty ( $trapcountvectoractive ) || ! empty ( $callsactive ) || ! empty ( $landingrateexceedsactive ) || ! empty ( $idlocation )) {
			$this->db->select ( '*' );
			$this->db->from ( 'locationpreferences' );
			$this->db->where ( 'idlocation', $idlocation );
			$q = $this->db->get ();

			if ($q->num_rows () > 0) {
				$this->db->query ( "SET FOREIGN_KEY_CHECKS = 0" );
				$this->db->where ( 'idlocation', $idlocation );
				$this->db->update ( 'locationpreferences', $data );
				$this->db->query ( "SET FOREIGN_KEY_CHECKS = 1" );
			} else {
				$this->db->query ( "SET FOREIGN_KEY_CHECKS = 0" );
				$this->db->insert ( 'locationpreferences', $data );
				$idlocationprfr = $this->db->insert_id ();
				$this->db->query ( "SET FOREIGN_KEY_CHECKS = 1" );
			}
		}

		$locationmosquitospecies = $this->input->post ( 'locationmosquitospecies' );

		$locationvectrorspecies = $this->input->post ( 'locationvectrorspecies' );

		if (! empty ( $locationmosquitospecies )) {
			// print'<pre>';
			// print_r($locationmosquitospecies);
			// die;
			$this->db->select ( '*' );
			$this->db->from ( 'locationmosquitospecies' );
			$this->db->where ( 'idlocation', $idlocation );
			$q = $this->db->get ();

			if ($q->num_rows () > 0) {
				$this->db->query ( "SET FOREIGN_KEY_CHECKS = 0" );
				$this->db->where ( 'idlocation', $idlocation );
				$this->db->delete ( 'locationmosquitospecies' );

				$this->db->query ( "SET FOREIGN_KEY_CHECKS = 1" );

				foreach ( $locationmosquitospecies as $val ) {
					$data_1 = array ();
					$data_1 ['idmosquitospecies'] = $val;
					$data_1 ['idlocation'] = $idlocation;

					$this->db->query ( "SET FOREIGN_KEY_CHECKS = 0" );
					$this->db->insert ( 'locationmosquitospecies', $data_1 );
					$this->db->query ( "SET FOREIGN_KEY_CHECKS = 1" );
					$this->flag = 1;
				}
			} else {
				foreach ( $locationmosquitospecies as $val ) {
					$data_1 = array ();
					$data_1 ['idmosquitospecies'] = $val;
					$data_1 ['idlocation'] = $idlocation;

					$this->db->query ( "SET FOREIGN_KEY_CHECKS = 0" );
					$this->db->insert ( 'locationmosquitospecies', $data_1 );
					$this->db->query ( "SET FOREIGN_KEY_CHECKS = 1" );
					$this->flag = 1;
				}
			}
		}

		if (! empty ( $locationvectrorspecies )) {
			// print'<pre>';
			// print_r($locationvectrorspecies);
			// die;
			$this->db->select ( '*' );
			$this->db->from ( 'locationmosquitospecies' );
			$this->db->where ( 'idlocation', $idlocation );
			$q = $this->db->get ();

			if ($q->num_rows () > 0) {
				$this->db->query ( "SET FOREIGN_KEY_CHECKS = 0" );
				$this->db->where ( 'idlocation', $idlocation );
				$this->db->delete ( 'locationvectorspecies' );
				$this->db->query ( "SET FOREIGN_KEY_CHECKS = 1" );

				foreach ( $locationvectrorspecies as $val ) {
					$data_1 = array ();
					$data_1 ['idlocationmosquitospecies'] = $val;
					$data_1 ['idlocation'] = $idlocation;

					$this->db->query ( "SET FOREIGN_KEY_CHECKS = 0" );
					$this->db->insert ( 'locationvectorspecies', $data_1 );
					$this->db->query ( "SET FOREIGN_KEY_CHECKS = 1" );
					$this->flag = 1;
				}
			} else {
				foreach ( $locationvectrorspecies as $val ) {
					$data_1 = array ();
					$data_1 ['idlocationmosquitospecies'] = $val;
					$data_1 ['idlocation'] = $idlocation;

					$this->db->query ( "SET FOREIGN_KEY_CHECKS = 0" );
					$this->db->insert ( 'locationvectorspecies', $data_1 );
					$this->db->query ( "SET FOREIGN_KEY_CHECKS = 1" );
					$this->flag = 1;
				}
			}
		}
		$user_lock = $this->input->post ( 'user_lock' );

		$data_2 ['user_lock'] = !empty($user_lock) ? '1' : '0';
		$wa_filtering = $this->input->post ( 'wa_filtering' );
		$data_2 ['wa_filtering'] = !empty($wa_filtering) ? '1' : '0';
		
		$prefilled_user_dropdowns = $this->input->post ( 'prefilled_user_dropdowns' );
		$data_2 ['prefilled_user_dropdowns'] = !empty($prefilled_user_dropdowns) ? '1' : '0';
		$updatedStatus = array('user_lock' => $data_2 ['user_lock'] , 'wa_filtering' =>  $data_2 ['wa_filtering'] , 'prefilled_user_dropdowns' =>  $data_2 ['prefilled_user_dropdowns']);
		$this->db->where('idlocation', $data ['idlocation']);
		$this->db->update('locations', $updatedStatus); 
		if (empty ( $idlocationprfr ) && empty ( $this->flag ))
			return false;

		return true;
	}

	/**
	 * Function to status of prefilled_user_dropdowns for a specific location
	 */
	public function getPrefilled_user_dropdowns($idlocation)
	{
		$this->db->select ( 'prefilled_user_dropdowns' );
		$this->db->from ( 'locations' );
		$this->db->where ( 'idlocation', $idlocation );
		$row = $this->db->get()->row();
		return ! empty ( $row ) ? $row->prefilled_user_dropdowns : '';
	}
	/**
	 * Function to status of wa_filtering for a specific location
	 */
	public function getWAFiltering($idlocation)
	{
		$this->db->select ( 'wa_filtering' );
		$this->db->from ( 'locations' );
		$this->db->where ( 'idlocation', $idlocation );
		$row = $this->db->get()->row();
		return ! empty ( $row ) ? $row->wa_filtering : '';
	}
	/**
	 * Function to Move Preferences
	 */
	public function movePreference($type = '', $idloc = '') {
		if (empty ( $type ))
			return false;

		$id = "";
		$species = "";
		if ($type == "mosquito") {
			$locationmosquitospecies = $this->input->post ( 'locationmosquitospecies' );

			$species = $this->getSpeciesDetail ( $idloc, "mosquito" );

			$species_arr = array ();
			$species_arr = explode ( ",", $locationmosquitospecies );
			// print'<pre>';
			// print_r($locationmosquitospecies);
			// print_r($species_arr[0]);
			// die;
			//
			if (! empty ( $species_arr )) {
				$this->db->query ( "SET FOREIGN_KEY_CHECKS = 0" );
				$this->db->where ( 'idlocation =' . $idloc );
				$this->db->delete ( 'locationvectorspecies' );
				$this->db->query ( "SET FOREIGN_KEY_CHECKS = 1" );

				foreach ( $species_arr as $key => $val ) {
					$data_1 = array ();

					$data_1 ['idlocation'] = $idloc;
					$data_1 ['idlocationmosquitospecies'] = $val;

					$this->db->query ( "SET FOREIGN_KEY_CHECKS = 0" );
					$this->db->insert ( "locationvectorspecies", $data_1 );

					$id = $this->db->insert_id ();

					$this->db->query ( "SET FOREIGN_KEY_CHECKS = 1" );
				}
				$species = $this->getSpeciesDetail ( $idloc, "vector" );
			}
		} else if ($type == "mosquito_1") {
			$locationmosquitospecies = $this->input->post ( 'locationmosquitospecies' );
			// $species = $this->getSpeciesDetail($locationmosquitospecies);
			// print'<pre>';
			// print_r($species);
			// die;
			$species_arr = array ();
			$species_arr = explode ( ",", $locationmosquitospecies );
			// print'<pre>';
			// print_r($locationmosquitospecies);
			// //print_r($species_arr[0]);
			// die;

			if (! empty ( $species_arr )) {
				foreach ( $species_arr as $key => $val ) {
					$data_1 = array ();

					$this->db->select ( 'idlocationvectorspecies' );
					$this->db->from ( 'locationvectorspecies' );
					$this->db->where ( 'idlocation', $idloc );
					$this->db->where ( 'idlocationmosquitospecies', $val );

					$query = $this->db->get ();
					// echo $query -> num_rows();

					if ($query->num_rows () > 0)
						continue;
					else {
						$this->db->query ( "SET FOREIGN_KEY_CHECKS = 0" );
						$data_1 ['idlocation'] = $idloc;
						$data_1 ['idlocationmosquitospecies'] = $val;
						$this->db->insert ( "locationvectorspecies", $data_1 );
						$id = $this->db->insert_id ();
						$this->db->query ( "SET FOREIGN_KEY_CHECKS = 1" );
					}
				}
				// die;
				$species = $this->getSpeciesDetail ( $idloc, "vector" );
				// print'<pre>';
				// print_r($species);
				// die;
			}
		} else if ($type == "vector") {
			$locationvectorspecies = $this->input->post ( 'locationvectorspecies' );
			$species_arr = array ();
			$species_arr = explode ( ",", $locationvectorspecies );
			// print'<pre>';
			// print_r($locationvectorspecies);
			// print_r($species_arr[0]);
			// die;

			if (! empty ( $species_arr )) {
				foreach ( $species_arr as $key => $val ) {
					$this->db->query ( "SET FOREIGN_KEY_CHECKS = 0" );
					$this->db->where ( "idlocation", $idloc );
					$this->db->where ( "idlocationmosquitospecies", $val );
					$this->db->delete ( "locationvectorspecies" );
					$id = $this->db->affected_rows ();
					$this->db->query ( "SET FOREIGN_KEY_CHECKS = 1" );
				}
			}
			$species = "<option value=''></option>";
		} else if ($type == "vector_1") {
			$locationvectorspecies = $this->input->post ( 'locationvectorspecies' );
			$species_arr = array ();
			$species_arr = explode ( ",", $locationvectorspecies );
			// print'<pre>';
			// print_r($locationvectorspecies);
			// print_r($species_arr[0]);
			// die;

			if (! empty ( $species_arr )) {
				foreach ( $species_arr as $key => $val ) {
					$this->db->query ( "SET FOREIGN_KEY_CHECKS = 0" );
					$this->db->where ( "idlocation", $idloc );
					$this->db->where ( "idlocationmosquitospecies", $val );
					$this->db->delete ( "locationvectorspecies" );
					$id = $this->db->affected_rows ();
					$this->db->query ( "SET FOREIGN_KEY_CHECKS = 1" );
				}
			}
			$species = $this->getSpeciesDetail ( $idloc, "vector" );
		}

		if (empty ( $species ))
			return false;

		return $species;
	}
	/**
	 * Function to fetch All Mosquito Species
	 * and assign them to Universe
	 */
	public function getUniverse($id = '') {
		$allspecies = $this->getAllSpecies ( $id );

		$this->db->select ( 'm.*,
				g.genus' );
		$this->db->from ( 'mosquitospecies AS m' );
		$this->db->JOIN ( 'genuses AS g', 'm.idgenus = g.idgenus', 'INNER' );
		$this->db->order_by ( 'g.genus', 'asc' );
		$this->db->order_by ( 'mosquitospecies', 'asc' );
		$result = array ();
		$query = $this->db->get ();

		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) { // $row['idmosquitospecies']
				$result [$i] ['idspecies'] = $row ['idmosquitospecies'];
				$result [$i] ['species'] = $row ['mosquitospecies'];
				$result [$i] ['genus'] = $row ['genus'];
				$i ++;
			}
		}

		return $result;
	}

	/**
	 * Function to fetch All Species
	 * selected by user
	 */
	public function getAllSpecies($id = '') {
		if (empty ( $id ))
			return false;

		$this->db->select ( 'lvs.*' );
		$this->db->from ( 'locationvectorspecies AS lvs' );
		$this->db->where ( 'idlocation', $id );
		// $this->db->from('locationmosquitospecies AS lms');
		$data = array ();
		$query = $this->db->get ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$data [] = $row ['idlocationmosquitospecies'];
			}
		}

		$this->db->select ( 'lms.*' );
		$this->db->from ( 'locationmosquitospecies AS lms' );
		$this->db->where ( 'idlocation', $id );
		$query = $this->db->get ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$data [] = $row ['idmosquitospecies'];
			}
		}

		return $data;
	}

	/**
	 * Function to fetch All Location Vector Species
	 * selected by user
	 */
	public function getLocationVectorSpecies($id = '') {
		if (empty ( $id ))
			return false;

		$this->db->select ( 'l.*,
				m.*,
				g.genus' );
		$this->db->from ( 'locationvectorspecies AS l' );
		$this->db->join ( 'mosquitospecies AS m', 'l.idlocationmosquitospecies = m.idmosquitospecies', 'INNER' );
		$this->db->join ( 'genuses AS g', 'm.idgenus = g.idgenus', 'INNER' );
		$this->db->where ( 'idlocation', $id );
		$this->db->order_by ( 'g.genus', 'asc' );
		$this->db->order_by ( 'm.mosquitospecies', 'asc' );
		$result = array ();
		$query = $this->db->get ();

		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) { // $row['idmosquitospecies']
				$result [$i] ['idspecies'] = $row ['idmosquitospecies'];
				$result [$i] ['species'] = $row ['mosquitospecies'];
				$result [$i] ['genus'] = $row ['genus'];
				$i ++;
			}
		}

		return $result;
	}

	/**
	 * Function to fetch All Location Vector Species
	 * selected by user
	 */
	public function getLocationVectorSpecies_I($id = '') {
		if (empty ( $id ))
			return false;

		$this->db->select ( 'l.*' );
		$this->db->from ( 'locationvectorspecies AS l' );
		$this->db->where ( 'idlocation', $id );

		$query = $this->db->get ();

		$data = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$data [] = $row ['idlocationmosquitospecies'];
			}
		}

		return $data;
	}

	/**
	 * Function to fetch All Mosquito Species
	 * and assign them to Universe
	 */
	public function getLocationMosquitoSpecies($id = '') {
		if (empty ( $id ))
			return false;

		$allspecies = $this->getLocationVectorSpecies_I ( $id );

		$this->db->select ( 'l.*,
				m.*,
				g.genus' );
		$this->db->from ( 'locationmosquitospecies AS l' );
		$this->db->join ( 'mosquitospecies AS m', 'l.idmosquitospecies = m.idmosquitospecies', 'INNER' );
		$this->db->join ( 'genuses AS g', 'm.idgenus = g.idgenus', 'INNER' );
		$this->db->where ( 'idlocation', $id );
		$this->db->order_by ( 'g.genus', 'asc' );
		$this->db->order_by ( 'm.mosquitospecies', 'asc' );
		$result = array ();
		$query = $this->db->get ();

		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) { // $row['idmosquitospecies']
				$result [$i] ['idspecies'] = $row ['idmosquitospecies'];
				$result [$i] ['species'] = $row ['mosquitospecies'];
				$result [$i] ['genus'] = $row ['genus'];
				$i ++;
			}
		}

		return $result;
	}

	/**
	 * Function to fetch season dates
	 */
	public function getSeasonDates($id = '') {
		$this->db->select ( '*' );
		$this->db->from ( 'seasondates AS s' );
		$this->db->where ( 'idlocation', $id );
		$this->db->order_by ( 's.year', 'asc' );
		$query = $this->db->get ();
		$result = array ();
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idseasondate'] = $row ['idseasondate'];
				$result [$i] ['year'] = $row ['year'];
				$result [$i] ['month'] = $row ['month'];
				$result [$i] ['day'] = $row ['day'];
				$i ++;
			}
		}
		return $result;
	}

	/**
	 * Function to fetch Preferences
	 */
	public function getPreferencesData() {
		$this->db->select ( '*' );
		$this->db->from ( 'locationpreferences' );
		$this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
		$query = $this->db->get ();

		if ($query->num_rows () > 0) {
			$data = $query->result_array ();

			return $data [0];
		}
	}

	/**
	 * Function to fetch Species Detail
	 */
	public function getSpeciesDetail1($loc = '') {
		if (empty ( $loc ))
			return null;

		$species_arr = explode ( ",", $loc );

		$this->str = "";
		foreach ( $species_arr as $key => $val ) {
			$this->db->select ( 'mosquitospecies,
					idmosquitospecies' );
			$this->db->from ( 'mosquitospecies' );
			$this->db->where ( 'idmosquitospecies', $val );

			$query = $this->db->get ();

			if ($query->num_rows () > 0) {
				$result = $query->result_array ();
				$result = $result [0];
				$this->str .= "<option value='" . $result ['idmosquitospecies'] . "'>" . $result ['mosquitospecies'] . "</option>";
			}
		}
		return $this->str;
	}

	/**
	 * Function to fetch Species Detail
	 */
	public function getSpeciesDetail($idloc = '', $type) {
		$this->str = "";
		$table = "";
		$table_alias = "";
		$id = "";

		if ($type == "mosquito") {
			$table = "locationmosquitospecies";
			$id = "idmosquitospecies";
			$table_alias = "lms";
		} else if ($type == "vector") {
			$table = "locationvectorspecies";
			$table_alias = "lvs";
			$id = "idlocationmosquitospecies";
		}

		$this->db->select ( 'm.*,' . $table_alias . '.*,g.genus' );
		$this->db->from ( 'mosquitospecies AS m' );
		$this->db->join ( 'genuses AS g', 'm.idgenus = g.idgenus', 'INNER' );
		$this->db->join ( $table . ' AS ' . $table_alias, 'm.idmosquitospecies = ' . $table_alias . '.' . $id, 'LEFT' );
		$this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->order_by ( 'g.genus', 'asc' );
		$this->db->order_by ( 'm.mosquitospecies', 'asc' );

		$query = $this->db->get ();

		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $key => $val ) {
				$this->str .= "<option value='" . $val ['idmosquitospecies'] . "'>(" . $val ['genus'] . ")" . $val ['mosquitospecies'] . "</option>";
			}
		}

		return $this->str;
	}

	public function addSeasonDate($year, $month, $day) {

		$this->db->select('idseasondate');
		$this->db->from('seasondates');
		$this->db->where('idlocation', '57');
		$this->db->where('year', $year);
		$query = $this->db->get();		
		
		if($query->num_rows() > 0) return 1;

		$data = array(
			'year' => $year,
			'month' => $month,
			'day' => $day,
			'idlocation' => '57',
			'isdeleted' => '0',
			'dateadded' => date('Y-m-d')
		);

		$this->db->insert('seasondates', $data);

		$result = $this->db->affected_rows();

		if($result == 1) return 0;
		else return 2;
	}
	
	public function removeSeasonDate($year) {
		$this->db->delete('seasondates', array('idlocation'=>'57', 'year'=>$year));
		
		return $this->db->affected_rows() > 0 ? 0 : 1;
	}
}

?>