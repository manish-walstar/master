<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Outfallinsp_model extends CI_Model {
	public $str = "";
	public $map = "";
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to Add a new Zone
	 */
	public function addoutfallinspection($idloc = '') {
		$site_id = '';
		$idloc = $this->session->userdata ( 'idlocation' );
		$site_id = $this->input->post ( 'site_id' );
		$data ['site'] = $this->input->post ( 'site' );
		$data ['idsitetype'] = $this->input->post ( 'idsitetype' );
		$data ['maplabel'] = $this->input->post ( 'maplabel' );
		$data ['address1'] = $this->input->post ( 'address1' );
		$data ['address2'] = $this->input->post ( 'address2' );
		$data ['city'] = $this->input->post ( 'city' );
		$data ['idstate'] = $this->input->post ( 'idstate' );
		$data ['latitude'] = $this->input->post ( 'latitude' );
		$data ['longitude'] = $this->input->post ( 'longitude' );
		$data ['pdop'] = $this->input->post ( 'pdop' );
		$data ['postalcode'] = $this->input->post ( 'postalcode' );
		if ($site_id == '0') {
			$this->db->query ( "SET foreign_key_checks = 0" );
			$this->db->insert ( 'sites', $data );
			$row_site = $this->db->affected_rows ();
			if (empty ( $row_site ))
				return false;
			$site_id = $this->db->insert_id ();
			$this->db->query ( "SET foreign_key_checks = 1" );
		/**
		 * end insert data into sites table*
		 */
		}
	
		$observed_date = $this->input->post ( 'observed_date' );
		$observed_time = $this->input->post ( 'observed_time' );
		
		$this->load->model('usermodel');
		$data_1 ['userId'] = $this->usermodel->getUserId();
		$lastrain = $this->input->post ( 'last_rain_quantity' );
		$lastrainother = $this->input->post ( 'last_rain_quantity_other' );
		$outfallmaterial = $this->input->post ( 'outfall_material' );
		$outfallmaterialother = $this->input->post ( 'outfall_material_other' );
		$outfalldimensions = $this->input->post ( 'outfall_dimensions' );
		$outfalldimensionsother = $this->input->post ( 'outfall_dimensions_other' );

		$time =  date ( 'Y-m-d', strtotime ( $observed_date ) ) .' '.date ( 'H:i:s', strtotime ( $observed_time ) );
		$data_1 ['observeddatetime'] = $time;
		$data_1 ['idsite'] = $site_id;
		$data_1 ['idzone'] = $this->input->post ( 'idzone' );
		$data_1 ['maplabel'] = $this->input->post ( 'maplabel' );
		$data_1 ['latitude'] = $this->input->post ( 'latitude' );
		$data_1 ['longitude'] = $this->input->post ( 'longitude' );
		$data_1 ['sitename'] = $this->input->post ( 'site' );
		$data_1 ['idsitetype'] = $this->input->post ( 'idsitetype' );
		$data_1 ['time'] = date ( 'h:i:s A', strtotime ( $observed_time ) );
		$data_1 ['date'] = date ( 'Y-m-d', strtotime ( $observed_date ) );
		$data_1 ['weather'] = $this->input->post ( 'weather' );
		$data_1 ['lastraintime'] = $this->input->post ( 'lastrain' );
		$data_1 ['parcelnumber'] = $this->input->post ( 'parcelnumber' );
		$data_1 ['outfallnumber'] = $this->input->post ( 'outfallnumber' );
		$data_1 ['lastrainquantity'] = !empty($lastrain) && $lastrain == 'other'?$lastrainother : $lastrain;
		$data_1 ['watershed'] = $this->input->post ( 'watershed' );
		$data_1 ['localwatersheduses'] = implode( ',',$this->input->post ( 'localwatersheduses' ));
		$data_1 ['outfallmaterial'] = !empty($outfallmaterial) && $outfallmaterial == 'other' ? $outfallmaterialother:$outfallmaterial;
		$data_1 ['outfalldimensions'] = !empty($outfalldimensions) && $outfalldimensions == 'other' ? $outfalldimensionsother:$outfalldimensions;
		$data_1 ['dischargeobserved'] = $this->input->post ( 'discharge_observed' );
		$data_1 ['color'] = $this->input->post ( 'color' );
		$data_1 ['odor'] = $this->input->post ( 'odor' );
		$data_1 ['oilsheen'] = $this->input->post ( 'oilsheen' );
		$data_1 ['floatingsolids'] = $this->input->post ( 'floatingsolids' );
		$data_1 ['suspendedsolids'] = $this->input->post ( 'suspendedsolids' );
		$data_1 ['staining'] = $this->input->post ( 'staining' );
		$data_1 ['flora'] = $this->input->post ( 'flora' );
		$data_1 ['fauna'] = $this->input->post ( 'fauna' );
		$data_1 ['structuralcondition'] = $this->input->post ( 'sutructuralcondition' );
		$data_1 ['approxvelocity'] = $this->input->post ( 'approxvelocity' );
		$data_1 ['waterdepthinpipe'] = $this->input->post ( 'waterdepthinpipe' );
		$data_1 ['watertemperature'] = $this->input->post ( 'watertemperature' );
		$data_1 ['conductivity'] = $this->input->post ( 'conductivity' );
		$data_1 ['ph'] = $this->input->post ( 'ph' );
		$data_1 ['turbidity'] = $this->input->post ( 'turbidity' );
		$data_1 ['flouride'] = $this->input->post ( 'flouride' );
		$data_1 ['detergents'] = $this->input->post ( 'detergents' );
		$data_1 ['samplecollected'] = $this->input->post ( 'samplecollected' );
		$data_1 ['laboratoryanalyses'] = $this->input->post ( 'laboratoryanalyses' );
		$data_1 ['idinspector'] = $this->input->post ( 'idinspector' );
		$data_1 ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
		$this->db->query ( "SET foreign_key_checks = 0" );
		$this->db->insert ( 'outfallinspection', $data_1 );
		$rows = $this->db->affected_rows ();
		if (empty ( $rows ))
			return false;
		
		$id = $this->db->insert_id ();
		$this->db->query ( "SET foreign_key_checks = 1" );
		
		
		
		return $id;
	}
	
	/**
	 * Function to Update a new Adultsurveillance
	 */
	public function updateoutfallinspection($Id = '', $idloc = '') {
		if (empty ( $Id ))
			return false;
			
		$site_id = '';
		$site_id = $this->input->post ( 'site_id' );
		$data ['site'] = $this->input->post ( 'site' );
		$data ['idsitetype'] = $this->input->post ( 'idsitetype' );
		$data ['maplabel'] = $this->input->post ( 'maplabel' );
		$data ['address1'] = $this->input->post ( 'address1' );
		$data ['address2'] = $this->input->post ( 'address2' );
		$data ['city'] = $this->input->post ( 'city' );
		$data ['idstate'] = $this->input->post ( 'idstate' );
		$data ['latitude'] = $this->input->post ( 'latitude' );
		$data ['longitude'] = $this->input->post ( 'longitude' );
		$data ['pdop'] = $this->input->post ( 'pdop' );
		$data ['postalcode'] = $this->input->post ( 'postalcode' );
		if ($site_id == '0') {
			$this->db->query ( "SET foreign_key_checks = 0" );
			$this->db->insert ( 'sites', $data_site );
			$row_site = $this->db->affected_rows ();
			if (empty ( $row_site ))
				return false;
			$site_id = $this->db->insert_id ();
			$this->db->query ( "SET foreign_key_checks = 1" );
		}

		$observed_date = $this->input->post ( 'observed_date' );
		$observed_time = $this->input->post ( 'observed_time' );
		
		/**
		 * end insert data into sites table*
		 */



		$lastrain = $this->input->post ( 'last_rain_quantity' );
		$lastrainother = $this->input->post ( 'last_rain_quantity_other' );
		$outfallmaterial = $this->input->post ( 'outfall_material' );
		$outfallmaterialother = $this->input->post ( 'outfall_material_other' );
		$outfalldimensions = $this->input->post ( 'outfall_dimensions' );
		$outfalldimensionsother = $this->input->post ( 'outfall_dimensions_other' );

		$time =  date ( 'Y-m-d', strtotime ( $observed_date ) ) .' '.date ( 'H:i:s', strtotime ( $observed_time ) );
		$data_1 ['observeddatetime'] = $time;
		 $data_1 ['idsite'] = $site_id;
		$data_1 ['time'] = date ( 'h:i:s A', strtotime ( $observed_time ) );
		$data_1 ['date'] = date ( 'Y-m-d', strtotime ( $observed_date ) );
		$data_1 ['weather'] = $this->input->post ( 'weather' );
		$data_1 ['lastraintime'] = $this->input->post ( 'lastrain' );
		$data_1 ['parcelnumber'] = $this->input->post ( 'parcelnumber' );
		$data_1 ['outfallnumber'] = $this->input->post ( 'outfallnumber' );
		$data_1 ['lastrainquantity'] = !empty($lastrain) && $lastrain == 'other'?$lastrainother : $lastrain;
		$data_1 ['watershed'] = $this->input->post ( 'watershed' );
		$data_1 ['localwatersheduses'] = implode( ',',$this->input->post ( 'localwatersheduses' ));
		$data_1 ['outfallmaterial'] = !empty($outfallmaterial) && $outfallmaterial == 'other' ? $outfallmaterialother:$outfallmaterial;
		$data_1 ['outfalldimensions'] = !empty($outfalldimensions) && $outfalldimensions == 'other' ? $outfalldimensionsother:$outfalldimensions;
		$data_1 ['dischargeobserved'] = $this->input->post ( 'discharge_observed' );
		$data_1 ['color'] = $this->input->post ( 'color' );
		$data_1 ['odor'] = $this->input->post ( 'odor' );
		$data_1 ['oilsheen'] = $this->input->post ( 'oilsheen' );
		$data_1 ['floatingsolids'] = $this->input->post ( 'floatingsolids' );
		$data_1 ['suspendedsolids'] = $this->input->post ( 'suspendedsolids' );
		$data_1 ['staining'] = $this->input->post ( 'staining' );
		$data_1 ['flora'] = $this->input->post ( 'flora' );
		$data_1 ['fauna'] = $this->input->post ( 'fauna' );
		$data_1 ['structuralcondition'] = $this->input->post ( 'sutructuralcondition' );
		$data_1 ['approxvelocity'] = $this->input->post ( 'approxvelocity' );
		$data_1 ['waterdepthinpipe'] = $this->input->post ( 'waterdepthinpipe' );
		$data_1 ['watertemperature'] = $this->input->post ( 'watertemperature' );
		$data_1 ['conductivity'] = $this->input->post ( 'conductivity' );
		$data_1 ['ph'] = $this->input->post ( 'ph' );
		$data_1 ['turbidity'] = $this->input->post ( 'turbidity' );
		$data_1 ['flouride'] = $this->input->post ( 'flouride' );
		$data_1 ['detergents'] = $this->input->post ( 'detergents' );
		$data_1 ['samplecollected'] = $this->input->post ( 'samplecollected' );
		$data_1 ['laboratoryanalyses'] = $this->input->post ( 'laboratoryanalyses' );
		$data_1 ['idinspector'] = $this->input->post ( 'idinspector' );
		$data_1 ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
		$data_1 ['idzone'] = $this->input->post ( 'idzone' );
		$data_1 ['maplabel'] = $this->input->post ( 'maplabel' );
		$data_1 ['latitude'] = $this->input->post ( 'latitude' );
		$data_1 ['longitude'] = $this->input->post ( 'longitude' );
		$data_1 ['sitename'] = $this->input->post ( 'site' );
		$data_1 ['idsitetype'] = $this->input->post ( 'idsitetype' );

		$this->db->where ( 'idoutfallinspection', $Id );
		$this->db->update ( 'outfallinspection', $data_1 );
		
		$rows = $this->db->affected_rows ();
		if (empty ( $rows ) && empty ( $Id ))
			return false;
		
	
		
		return $Id;
	}
	
	/**
	 * Function to list all Adultsurveillances
	 */
	public function deleteoutfallinspection() {
		$idoutfallinspection = $this->input->get_post ( 'id' );
		
		if (empty ( $idoutfallinspection ))
			return false;
			
		$data ['isdeleted'] = '1';
		$this->db->where ( 'idoutfallinspection', $idoutfallinspection );
		$this->db->update ( 'outfallinspection', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ) && empty ( $id ))
			return false;
		
		return true;
	}
	
	
	/**
	 * Function to list all Adultsurveillances mail
	 */
	public function getoutfallinspection($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( '`outfallinspection`.*' );
		$this->db->from ( 'outfallinspection' );
		$this->db->where ( 'isdeleted', '0' );
		
		$this->db->where ( '`outfallinspection`.`idoutfallinspection`', $Id );
		
		$query = $this->db->get ();
		
		$data = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row )
				$data [] = $row;
			
			return $data [0];
		}
		
		return false;
	}
	/**
	 * Function to list all outfall inspection
	 */
	public function listoutfallinspection($Ids = "", $mapSite = "", $mapFlag = "") {
		$this->db->select ( 'outfallinspection.idoutfallinspection,
				s.site AS sitename,
				s.idzone, 
				zones.`zone`, 
				outfallinspection.observeddate, 
				outfallinspection.parcelnumber ,
				outfallinspection.outfallnumber ' );
		$this->db->from ( 'outfallinspection' );
		$this->db->join ( 'sites AS s', 'outfallinspection.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'zones', 's.idzone = zones.idzone', 'LEFT' );
		$this->db->join ( 'locations AS l', 'outfallinspection.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( 'outfallinspection.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'outfallinspection.isdeleted', '0' );
        
		$filter_date = $this->input->get ( 'filter_date' );
		$ttl = $this->input->get ( 'ttl' );
		$page = $this->input->get ( 'page' );
		$frmdate = $this->input->get ( 'frmdate' );
		$todate = $this->input->get ( 'todate' );
		$orderby = $this->input->get ( 'orderby' );
		
        if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 2;
		
		if (! isset ( $ttl ) || $ttl == '')
			$ttl = 10;
		
		if (! isset ( $page ) || $page == '')
			$page = 1;
		
        if(!empty($mapSite)){
            $this->db->where ( 's.idsite', $mapSite );
		}
        if(!empty($mapSite) || !empty($mapFlag)){
            $filter_date = "";
            $filter_daterange = "";
            $frmdate = "";
            $todate = "";
            $orderby = "";
            $ttl = "";
            $page = "";
		}
        
		if (! empty ( $frmdate ) && ! empty ( $todate )) {
			$frmdate = substr ( $frmdate, 0, 2 ) . '/' . substr ( $frmdate, 2, 2 ) . '/' . substr ( $frmdate, 4, 4 );
			$todate = substr ( $todate, 0, 2 ) . '/' . substr ( $todate, 2, 2 ) . '/' . substr ( $todate, 4, 4 );
			$this->db->where ( 'outfallinspection.observeddate' . ' >=', date ( 'Y-m-d', strtotime ( $frmdate ) ) );
			$this->db->where ( 'outfallinspection.observeddate' . ' <=', date ( 'Y-m-d', strtotime ( $todate ) ) );
		} else if (! is_null ( $filter_date )) {
			switch ($filter_date) {
				// date('H:i:s',strtotime('-1 day');
				case '1' :
					$this->db->where ( 'outfallinspection.observeddate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'outfallinspection.observeddate' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'outfallinspection.observeddate' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'outfallinspection.observeddate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'outfallinspection.observeddate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'outfallinspection.observeddate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'outfallinspection.observeddate' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'outfallinspection.observeddate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'outfallinspection.observeddate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'outfallinspection.observeddate' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		}
		
		
		
		if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
			switch ($orderby) {
				case '0:asc' :
					$this->db->order_by ( 'sites.site', 'ASC' );
					break;
				case '0:desc' :
					$this->db->order_by ( 'sites.site', 'DESC' );
					break;
				case '1:asc' :
					$this->db->order_by ( 'zones.zone', 'ASC' );
					break;
				case '1:desc' :
					$this->db->order_by ( 'zones.zone', 'DESC' );
					break;
				case '2:asc' :
					$this->db->order_by ( 'outfallinspection.observeddate', 'ASC' );
					$this->db->order_by ( 'outfallinspection.observedtime', 'DESC' );
					break;
				case '2:desc' :
					$this->db->order_by ( 'outfallinspection.observeddate', 'DESC' );
					$this->db->order_by ( 'outfallinspection.observedtime', 'DESC' );
					break;
				case '3:asc' :
					$this->db->order_by ( 'outfallinspection.parcelnumber', 'ASC' );
					break;
				case '3:desc' :
					$this->db->order_by ( 'outfallinspection.parcelnumber', 'DESC' );
					break;
				case '4:asc' :
					$this->db->order_by ( 'outfallinspection.outfallnumber', 'ASC' );
					break;
				case '4:desc' :
					$this->db->order_by ( 'outfallinspection.outfallnumber', 'DESC' );
					break;
			}
		} else {
			$this->db->order_by ( 'outfallinspection.observeddate', 'DESC' );
			$this->db->order_by ( 'outfallinspection.observedtime', 'DESC' );
		}
		
		$data_1 = array ();
        if(!empty($Ids)) {
            $this->db->where_in ( 'outfallinspection.idoutfallinspection', $Ids );
        }
		$query = $this->db->get ();
		$result = array ();
		if ($query->num_rows () > 0)
			return $query->result_array ();
		
		return false;
	}
	public function getLastImage($req){
		$last_row=$this->db->select('imageurl')->where('idoutfallinspection' , $req)->order_by('idimage',"desc")->limit(1)->get('outfallinspectionimages')->row();
		return $last_row;
	}
	public function saveImage($idoutfallinspection ,$url){
		$data['idoutfallinspection'] = $idoutfallinspection;
		$data['imageurl'] = $url;
		$this->db->insert('outfallinspectionimages' , $data);
	}
	public function getImages($idoutfallinspection){
		$this->db->select('i.imageurl');
		$this->db->from('outfallinspectionimages AS i');
		$this->db->where('i.idoutfallinspection' , $idoutfallinspection);
		$this->db->where('i.isdeleted' , 0);
		$query = $this->db->get();
		if($query->num_rows() >0 )
			return $query->result_array();
		return "";
	}
	public function removeImage($image){
		If(!empty($image)){
			$data['isdeleted'] = 1;
			$this->db->where('imageurl' , $image );
			$this->db->update('outfallinspectionimages' , $data);
			return true;
		}
		return false;
	}
	/**
	 * Function to fetch Inspector List
	 */
	public function getInspectors() {
		$this->db->select ( 'u.iduser,
				u.firstname,
				u.middlename,
				u.lastname' );
		$this->db->from ( 'users AS u' );
		$this->db->join ( 'userlocationassignment AS ula', 'u.iduser = ula.iduser', 'LEFT' );
		$this->db->join ( 'locations AS l', 'ula.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( 'l.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'u.is_active', '1' );
		$this->db->order_by ( 'u.firstname' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$middlename = ! empty ( $row ['middlename'] ) ? " " . $row ['middlename'] . " " : " ";
				$this->str .= '<option value="' . $row ['iduser'] . '">' . $row ['firstname'] . $middlename . $row ['lastname'] . '</option>';
			}
		}
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Inspector List
	 */
	public function getSelectedInspectors($Id = '') {
		$this->db->select ( 'u.iduser,
				u.firstname,
				u.middlename,
				u.lastname' );
		$this->db->from ( 'users AS u' );
		$this->db->join ( 'userlocationassignment AS ula', 'u.iduser = ula.iduser', 'LEFT' );
		$this->db->join ( 'locations AS l', 'ula.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( 'l.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'u.is_active', '1' );
		$this->db->order_by ( 'u.firstname' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$middlename = ! empty ( $row ['middlename'] ) ? " " . $row ['middlename'] . " " : " ";
				
				if ($Id == $row ['iduser'])
					$this->str .= '<option value="' . $row ['iduser'] . '" selected="true">' . $row ['firstname'] . $middlename . $row ['lastname'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['iduser'] . '">' . $row ['firstname'] . $middlename . $row ['lastname'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	
	
	/**
	 * function to get zone name
	 */
	public function getzone($Id = '') {
		$this->db->select ( 'idzone' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'sites.active', '1' );
		$this->db->where ( 'sites.isdeleted', '0' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'idsite', $Id );
		$query = $this->db->get ();
		if ($query->num_rows () > 0)
			return $query->result_array ();
	}
	
	/**
	 * Function to fetch Site Names
	 */
	public function getSitename($Id = '') {
		$this->db->select ( 'idsite,site' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'active', '1' );
		$this->db->where ( 'isdeleted', '0' );
		$this->db->order_by ( "site", "ASC" );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idsite']) {
					$this->str .= '<option value="' . $row ['idsite'] . ' " selected="true">' . $row ['site'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idsite'] . '">' . $row ['site'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	/**
	 * Function to fetch Site details
	 */
	public function getSiteDetails($Id = '') {
		$this->db->select ( '*' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'active', '1' );
		$this->db->where ( 'isdeleted', '0' );
		$this->db->where ( 'idsite', $Id );
		$results = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$results = $row;
			}
		}
		
		return $results;
	}
	/**
	 * Function to fetch site type
	 */
	public function getSelectedSitetype($Id = '') {
		$this->db->select ( 'idsitetype,sitetype' );
		$this->db->from ( 'sitetypes' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idsitetype']) {
					$this->str .= '<option value="' . $row ['idsitetype'] . '" selected="true">' . $row ['sitetype'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idsitetype'] . '">' . $row ['sitetype'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	/**
	 * Function to fetch selected Zone name
	 */
	public function getSelectedZonename($Id = '') {
		$this->db->select ( 'idzone,zone' );
		$this->db->order_by ( 'zone' );
		$this->db->from ( 'zones' );
		$this->db->where ( 'active', '1' );
		$this->db->where ( 'isdeleted', '0' );
		$this->db->where ( 'zones.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idzone']) {
					$this->str .= '<option value="' . $row ['idzone'] . '" selected="true">' . $row ['zone'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idzone'] . '">' . $row ['zone'] . '</option>';
				}
			}
		}
		return $this->str;
	}
	
	/**
	 * Function to fetch get State name
	 */
	public function getStatename($Id = '') {
		if (empty ( $Id )) {
			$this->db->select ( 'states.idstate' );
			$this->db->from ( 'states' );
			$this->db->join ( 'locations AS lc', "states.idstate = lc.idstate", 'LEFT' );
			$this->db->where ( 'lc.idlocation', $this->session->userdata ( 'idlocation' ) );
			
			$q = $this->db->get ();
			if ($q->num_rows () > 0) {
				$Id = $q->result_array ();
				$Id = $Id [0] ['idstate'];
			}
		}
		$this->db->select ( 'st.idstate,st.statename' );
		$this->db->from ( 'states AS st' );
		$this->db->order_by ( 'st.statename' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if (! empty ( $Id ) && $Id == $row ['idstate']) {
					$this->str .= '<option value="' . $row ['idstate'] . '" selected="true">' . $row ['statename'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idstate'] . '">' . $row ['statename'] . '</option>';
				}
			}
		}
		return $this->str;
	}
	
	/**
	 * Function to fetch get State value by name
	 */
	public function getStatebyName($Id = '') {
		if (empty ( $Id )) {
			$this->db->select ( 'states.idstate' );
			$this->db->from ( 'states' );
			$this->db->join ( 'locations AS lc', "states.idstate = lc.idstate", 'LEFT' );
			$this->db->where ( 'lc.idlocation', $this->session->userdata ( 'idlocation' ) );
			
			$q = $this->db->get ();
			if ($q->num_rows () > 0) {
				$Id = $q->result_array ();
				$Id = $Id [0] ['idstate'];
			}
		}
		$this->db->select ( 'st.idstate,st.statename' );
		$this->db->from ( 'states AS st' );
		$this->db->order_by ( 'st.statename' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idstate']) {
					$this->str .= '<option value="' . $row ['statename'] . '" selected="true">' . $row ['statename'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['statename'] . '">' . $row ['statename'] . '</option>';
				}
			}
		}
		return $this->str;
	}
	/**
	 * Function to list all Adultsurveillances
	 */
	
}
