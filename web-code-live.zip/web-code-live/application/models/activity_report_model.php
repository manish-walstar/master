<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
date_default_timezone_set('UTC');
error_reporting(-1);
class Activity_report_model extends CI_Model {
	
    public $data = "";
    
	/**
     * Constructor for the class 
     * Zone 
     */
    public function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    
    /**
     * Function to fetch Adult Treatment
     */
	 
    public function getActivity($startdate = '', $enddate = '') 
    {   
       
        $startdate_arr = explode("/",$startdate);
         $startdate = $startdate_arr[2]."-".$startdate_arr[0]."-".$startdate_arr[1];
        
         //$startdate = '2020-02-12';
        $all_fields = $this->input->get_post('all_fields_1');
        
        $enddate_arr = explode("/",$enddate);
        $enddate = $enddate_arr[2]."-".$enddate_arr[0]."-".$enddate_arr[1];
        
         echo $startdate." ".$enddate;
       // die;
        
        /** Test code Starts**/
      //  $adult = array();
//        
//        $this->db->select('a.*,tr.*');
//        $this->db->from('adultsurveillance AS a');
//        $this->db->join('tempranges AS tr','a.idtemprange = tr.idtemprange','LEFT');
//        $this->db->where('a.pudate >=',$startdate);
//        $this->db->where('a.pudate <=',$enddate);
//		$query = $this->db->get();
//        $k = 0;
//         if($query -> num_rows() > 0) 
//            foreach($query -> result_array() as $key => $val)
//            {
//                $adult[$k]['activity'] = $val;
//                $k++;
//            }
//            
//        
//        echo "<pre>";
//        print_r($adult);
//        die;
        
        /** Test code Ends **/
        $id_location = $this->session->userdata('idlocation');
        
        $adult = array();
        $ad_activity = array();
        $k = 0;
        
        $this->db->select('asr.idadultsurveillance, asr.pudate, asr.putime, s.idsite, s.site, s.latitude, s.longitude, s.address1, s.address2, s.city, st.statename, t.idtrap, t.trap, ty.traptype, u.firstname, u.lastname');
        $this->db->from('adultsurveillance AS asr');
        $this->db->join('traps AS t','asr.idtrap = t.idtrap','LEFT');
        $this->db->join('sites AS s','t.idsite = s.idsite','INNER');
        $this->db->join('states AS st','s.idstate = st.idstate','LEFT');
        $this->db->join('traptypes AS ty','t.idtraptype = ty.idtraptype','LEFT');
        $this->db->join('users AS u','asr.idinspector = u.iduser','LEFT');
        $this->db->where('asr.idlocation',$id_location);
        $this->db->where('s.idlocation',$id_location);
        $this->db->where('asr.isdeleted','0');
        $this->db->where('asr.pudate >=',$startdate);
        $this->db->where('asr.pudate <=',$enddate);
        $query = $this->db->get();
       //  echo $this->db->last_query();
       // die;
        $i = 0;
        if($query -> num_rows() > 0) 

            foreach($query -> result_array() as $key => $val)
            {
                $adult[$i]['id'] = $val['idadultsurveillance'];
                if($val['pudate'] && $val['pudate'] != '1970-01-01' && $val['pudate'] != '0001-01-30' && $val['pudate'] != '0000-00-00')
                    $adult[$i]['date'] = date("m/d/Y", strtotime($val['pudate']))." ".date("h:i:s A", strtotime($val['putime']));
                else
                    $adult[$i]['date'] = '';
                $adult[$i]['site'] = $val['site'];
                $adult[$i]['address1'] = $val['address1'];
                $adult[$i]['city'] = $val['city'];
                $adult[$i]['statename'] = $val['statename'];
                
                $adult[$i]['location'] = $val['latitude']. " " . $val['longitude'];
                $adult[$i]['activity']['trapid'] = $val['idtrap'];
                $adult[$i]['activity']['trap name'] = $val['trap'];
                $adult[$i]['activity']['trap type'] = $val['traptype'];
                $adult[$i]['activity']['inspector'] = $val['firstname']." ".$val['lastname'];;
                $i++;
            }
            
//        echo "<pre>";
//        print_r($adult);
//        die;
        
        $query->free_result(); 
        $larval_treatment = array();
        $lr_activity = array();
        $i = 0;
        
        /** Test code Starts**/
      
        $this->db->select('l.idlarvaltreatment, l.date, l.totalcount as larvaecountrange,l.time,l.latitude,l.longitude, s.idsite, s.site, s.address1, s.address2,s.city, st.statename, ty.sitetype, ins.instar, tr.temprange');
        $this->db->from('larvaltreatments as l');
        $this->db->join('sites AS s','l.idsite = s.idsite','INNER');
        $this->db->join('states AS st','s.idstate = st.idstate','LEFT');
        $this->db->join('sitetypes AS ty','s.idsitetype = ty.idsitetype','LEFT');
        $this->db->join('instar AS ins','l.idinstar = ins.idinstar','LEFT');
        $this->db->join('tempranges AS tr','l.idwatertemp = tr.idtemprange','LEFT');
        $this->db->where('l.idlocation',$id_location);
        $this->db->where('l.isdeleted','0');
        $this->db->where('date >=',$startdate);
        $this->db->where('date <=',$enddate);
		$query = $this->db->get();
        $i = 0;
         if($query -> num_rows() > 0) 
            foreach($query -> result_array() as $key => $val)
            {
                $lr_activity['site_type'] = $val['sitetype'];
                $lr_activity['larval_count'] = $val['larvaecountrange'];
                $lr_activity['instrar'] = $val['instar'];
                $lr_activity['water_temprature'] = $val['temprange'];
                $larval_treatment[$i]['id'] = $val['idlarvaltreatment'];
                if($val['date'] && $val['date'] != '1970-01-01' && $val['date'] != '0001-01-30' && $val['date'] != '0000-00-00')
                    $larval_treatment[$i]['date'] = date("m/d/Y", strtotime($val['date']))." ".date("h:i:s A", strtotime($val['time']));
                else
                    $larval_treatment[$i]['date'] = '';
                
                $larval_treatment[$i]['site'] = $val['site'];
                $larval_treatment[$i]['address1'] = $val['address1'];
                $larval_treatment[$i]['city'] = $val['city'];
                $larval_treatment[$i]['statename'] = $val['statename'];
                $larval_treatment[$i]['location'] = $val['latitude']. " " . $val['longitude'];
                $larval_treatment[$i]['activity'] = $lr_activity;
                $i++;  
            }
//            
//        
        //echo "<pre>";
//        print_r($larval_inspection);
//        die;
        
        $query->free_result();     
        $larval_inspection = array();
        $larval_activity = array();
        $j = 0;
        $this->db->select('lrt.*, s.idsite, s.site, s.address1,  s.address2 ,s.city, st.*, ins.*, wtr.*, sta.statename');
        $this->db->from('larvalsurveillance AS lrt');
        $this->db->join('watertempranges AS wtr','lrt.idwatertemprange = wtr.idwatertemprange','LEFT');
        $this->db->join('instar AS ins','lrt.idinstar = ins.idinstar','LEFT');
        $this->db->join('sitetypes AS st','lrt.idsitetype = st.idsitetype','LEFT');
        $this->db->join('sites AS s','lrt.idsite = s.idsite','INNER');
        $this->db->join('states AS sta','s.idstate = sta.idstate','LEFT');
        $this->db->where('lrt.idlocation',$id_location);
        $this->db->where('lrt.isdeleted','0');
        $this->db->where('lrt.date >=',$startdate);
        $this->db->where('lrt.date <=',$enddate);
        $query = $this->db->get();
        
        if($query -> num_rows() > 0) 
            foreach($query -> result_array() as $key => $val) 
            {
                //$larval_activity['sitetype'] = $val['sitetype'];
                $larval_activity['larval_count'] = $val['totalcount'];
                $larval_activity['instar'] = $val['instar'];
                $larval_activity['water_temprature'] = $val['watertemprange'];
                $larval_activity['sitetype'] = $val['sitetype'];
                
                
                $larval_inspection[$j]['id'] = $val['idlarvalsurveillance'];
                if($val['date'] && $val['date'] != '1970-01-01' && $val['date'] != '0001-01-30' && $val['date'] != '0000-00-00')
                    $larval_inspection[$j]['date'] = date("m/d/Y", strtotime($val['date']))." ".date("h:i:s A", strtotime($val['time']));
                else
                    $larval_inspection[$j]['date'] = '';
                
                $larval_inspection[$j]['site'] = $val['site'];
                $larval_inspection[$j]['address'] = $val['address1'];
                $larval_inspection[$j]['city'] = $val['city'];
                $larval_inspection[$j]['statename'] = $val['statename'];
                
                $larval_inspection[$j]['location'] = $val['latitude']. " " . $val['longitude'];
                $larval_inspection[$j]['activity'] = $larval_activity;
                $j++;
            }
            
        $query->free_result(); 
        $lab_result = array();
        $lab_activity = array();
        $j = 0;
        $this->db->select('al.idarbovirallab,al.testdate, al.testdate, s.site, s.latitude, s.longitude, s.address1,s.address2, s.city, st.statename, t.idtrap, ms.mosquitospecies, al.poolsize, aty.assaytype, lrs.labresult, al.rtprcconfirm , al.resultscorresspond');
        $this->db->from('arbovirallabs AS al');
        $this->db->join('traps AS t', 'al.idtrap = t.idtrap', 'LEFT');
        $this->db->join('sites AS s', 't.idsite = s.idsite', 'INNER');
        $this->db->join('states AS st','s.idstate = st.idstate','LEFT');
        $this->db->join('mosquitospecies AS ms', 'al.idmosquitospecies = ms.idmosquitospecies', 'LEFT');
        $this->db->join('assaytypes AS aty', 'al.idassaytype = aty.idassaytype', 'LEFT');
        $this->db->join('labresults AS lrs', 'al.idlabresult = lrs.idlabresult', 'LEFT');
        $this->db->where('al.idlocation',$id_location);
        $this->db->where('al.isdeleted','0');
        $this->db->where('al.testdate >=',$startdate);
        $this->db->where('al.testdate <=',$enddate);
        $query = $this->db->get();
        $j = 0;        
        if($query -> num_rows() > 0) 
            foreach($query -> result_array() as $key => $val) 
            {
                $this->db->select('asr.idadultsurveillance, asr.pudate');
                $this->db->from('adultsurveillance AS asr');
                $this->db->where('asr.idtrap',$val['idtrap']);
                $query = $this->db->get();
                if($query -> num_rows() > 0) 
                    foreach($query -> result_array() as $key1 => $val1) 
                    {
                        //." ".$val1['idadultsurveillance']
                        $lab_activity['date_collected'] = $val1['pudate']; 
                        $lab_activity['date_tested'] = $val['testdate'];
                        $lab_activity['species'] = $val['mosquitospecies'];
                        $lab_activity['poolsize'] = $val['poolsize'];
                        $lab_activity['assay_type'] = $val['assaytype'];
                            
                        if ($val['rtprcconfirm'] == 1)
                            $lab_activity['confirm'] = 'Yes';
                        else
                            $lab_activity['confirm'] = 'No';
                            
                        if ($val['resultscorresspond'] == 1)
                            $lab_activity['result'] = 'Yes';
                        else
                            $lab_activity['result'] = 'No';
                        
                        $lab_result[$j]['id'] = $val['idarbovirallab'];
                        if($val['testdate'] && $val['testdate'] != '1970-01-01' && $val['testdate'] != '0001-01-30' && $val['testdate'] != '0000-00-00')
                            $lab_result[$j]['date'] = date("m/d/Y", strtotime($val['testdate']));
                        else
                            $lab_result[$j]['date'] = '';
                        
                        $lab_result[$j]['site'] = $val['site'];
                        $lab_result[$j]['address1'] = $val['address1'];
                        $lab_result[$j]['city'] = $val['city'];
                        $lab_result[$j]['statename'] = $val['statename'];
                        $lab_result[$j]['location'] = $val['latitude']. " " . $val['longitude'];
                        $lab_result[$j]['activity'] = $lab_activity;
                            
                        $j++;
                                
                    }
                
                                
            }
            
            

        $query->free_result(); 
        $service_request = array();
        $l = 0;
        $this->db->select('sr.*');
        $this->db->from('servicerequests AS sr');
        $this->db->where('sr.isdeleted','0');
        $this->db->where('sr.opendate >=',$startdate);
        $this->db->where('sr.opendate <=',$enddate);
        $query = $this->db->get();
        if($query -> num_rows() > 0)
        //$discp = 0; 
            foreach($query -> result_array() as $key => $val) 
            {   $sr_activity = array();
                $this->db->select('s.idsite, s.site, s.address1 , s.address2, s.city, st.statename');
                $this->db->from('sites AS s');
                $this->db->join('states as st','s.idstate = st.idstate','LEFT');
                $this->db->where('s.idsite',$val['idsite']);
                $this->db->where('s.isdeleted','0');
                $this->db->where('s.idlocation',$id_location);
                $query1 = $this->db->get();
                if($query1 -> num_rows() > 0) 
                    foreach($query1 -> result_array() as $key1 => $val1) 
                    {
                        $sr_activity['open_date'] = $val['opendate'];
                        $sr_activity['close_date'] = $val['closetime'];
                        $sr_activity['description'] = $val['description'];
                        if ($val['dispcorvidpickup'] == 1)
                            $sr_activity['dispcorvidpickup'] = "Corvid Pickup";
                        
                        if ($val['disnoaction'] == 1)
                            $sr_activity['disnoaction'] = "No Action";
                       
                        if ($val['dispsourcereduction'] == 1)
                            $sr_activity['dispsourcereduction'] = "Source Reduction";
                       
                        if ($val['dispfollowupvisit'] == 1)
                            $sr_activity['dispfollowupvisit'] = "Follow-up Visit";
                            
                        if ($val['dispsampletaken'] == 1)
                            $sr_activity['dispsampletaken'] = "Sample Taken";
                       
                        $service_request[$l]['id'] = $val['idservicerequest'];
                        if($val['opendate'] && $val['opendate'] != '1970-01-01' && $val['opendate'] != '0001-01-30' && $val['opendate'] != '0000-00-00')
                            $service_request[$l]['date'] = date("m/d/Y", strtotime($val['opendate']))." ".date("h:i:s A", strtotime($val['opentime']));
                        else
                            $service_request[$l]['date'] = '';
                        
                        $service_request[$l]['site'] = $val['sitename'];
                        $service_request[$l]['address'] = $val1['address1'];
                        $service_request[$l]['city'] = $val1['city'];
                        $service_request[$l]['statename'] = $val1['statename'];
                        
                        $service_request[$l]['location'] = $val['latitude']. " " . $val['longitude'];
                        $service_request[$l]['activity'] = $sr_activity;
                        $l++;
                    } 
                    
                     
            }
       //  echo "<pre>";
       // print_r($service_request);
       // die;
        $query->free_result(); 
        $treatment_adult = array();
        $treat_activity = array();
        $m = 0;
        

        $this->db->select('atr.idadulticidetreatment, atr.date, atr.time,atr.totalareatreated,atr.latitude,atr.longitude, s.site, s.address1,s.address2, s.city, sta.statename, z.zone, am.applicationmethod, ps.productname, psz.productsize, trt.unitarea, u.firstname, u.lastname, st.sitetype');
        $this->db->from('adulticidetreatments AS atr');
        $this->db->join('sites as s', 'atr.idsite = s.idsite', 'INNER');
        $this->db->join('states AS sta','s.idstate = sta.idstate','LEFT');
        $this->db->join('sitetypes as st', 'atr.idsitetype = st.idsitetype', 'LEFT');
        $this->db->join('zones as z', 'atr.idzone = z.idzone', 'LEFT');
        $this->db->join('applicationmethods as am', 'atr.idapplicationmethod = am.idapplicationmethods', 'LEFT');
        $this->db->join('products as ps', 'atr.idproduct = ps.idproduct', 'LEFT');
        $this->db->join('productsizes as psz', 'ps.idproductsize = psz.idproductsize', 'LEFT');
        $this->db->join('area_treated as trt', 'atr.iduomtotalareatreated = trt.idareatreated', 'LEFT');
        $this->db->join('users as u', 'atr.idapplicator = u.iduser', 'LEFT');
        $this->db->where('atr.idlocation',$id_location);
        $this->db->where('atr.isdeleted','0');
        $this->db->where('atr.date >=',$startdate);
        $this->db->where('atr.date <=',$enddate);
        $m = 0;

         $query = $this->db->get();
       
        if($query -> num_rows() > 0) 

      
            foreach($query -> result_array() as $key => $val) 
            {

                $treat_activity['zone'] = $val['zone'];
                $treat_activity['treatment_method'] = $val['applicationmethod'];
                $treat_activity['product_name'] = $val['productname'];
                $treat_activity['amount'] = "";
                $treat_activity['product_size'] = $val['productsize'];
                $treat_activity['area_treated'] = $val['totalareatreated']. " (". $val['unitarea'].")";
                $treat_activity['applicator'] = $val['firstname']. " ". $val['lastname'];
                
                $treatment_adult[$m]['id'] = $val['idadulticidetreatment'];
                $treatment_adult[$m]['site'] = $val['site'];
                $treatment_adult[$m]['address1'] = $val['address1'];
                $treatment_adult[$m]['city'] = $val['city'];
                $treatment_adult[$m]['statename'] = $val['statename'];
                $treatment_adult[$m]['sitetype'] = $val['sitetype'];
                $treatment_adult[$m]['location'] = $val['latitude']. " " . $val['longitude'];
                if($val['date'] && $val['date'] != '1970-01-01' && $val['date'] != '0001-01-30' && $val['date'] != '0000-00-00')
                    $treatment_adult[$m]['date'] = date("m/d/Y", strtotime($val['date']))." ".date("h:i:s A", strtotime($val['time']));
                else
                    $treatment_adult[$m]['date'] = '';
                
                $treatment_adult[$m]['activity'] = $treat_activity;
                $m++;
            }
        
       //  echo "<pre>";
       // print_r($treatment_adult);
       // die;
        
        
        $this->data['adult'] = $adult;
        $this->data['larvel'] = $larval_inspection;
        $this->data['larveltrtment'] = $larval_treatment;
        $this->data['lab'] = $lab_result;
        $this->data ['service']= $service_request;
        $this->data['treatment'] = $treatment_adult;
		   
		    
       //  print'<pre>';
       // print_r($this->data);
       // die;
		return  $this->data;
    }
    
    /**
     * Function to fetch All Products
     */
    public function distance($lat1, $lng1, $lat2, $lng2)
    {
        $pi80 = M_PI / 180;
        $lat1 *= $pi80;
        $lng1 *= $pi80;
        $lat2 *= $pi80;
        $lng2 *= $pi80;
        $r = 6372.797; // mean radius of Earth in km
        $dlat = $lat2 - $lat1;
        $dlng = $lng2 - $lng1;
        $a = sin($dlat / 2) * sin($dlat / 2) + cos($lat1) * cos($lat2) * sin($dlng / 2) * sin($dlng / 2);
        $c = 2 * atan2(sqrt($a), sqrt(1 - $a));
        $km = $r * $c;
        
        return floor($km * 0.621371192);
    }
	
	public function is_within_10_miles($lat1, $lng1, $lat2, $lng2, $miles)
    {
   	echo $lat1." || ".$lng1." || ".$lat2." || ".$lng2. " || " .$miles;
       die;
        
        $d = $this->distance($lat1, $lng1, $lat2, $lng2);
        //echo $d.'<br />';
        if( $d <= $miles )
            return 1;
        else
            return 0;
    }

     
    function getmapdata12($street = '',$city = '' , $state = '')
    {
        if($state)
            $address = urlencode($street)."+".urlencode($city)."+".urlencode($state);
        else
            $address = urlencode($street)."+".urlencode($city);
        
        
        //file_get_contents($url);
        
        //$curlData = file_get_contents($url);
        
        //$address = json_decode($curlData);
        
        $i = 0;
        while($i < 5)
        {
            $response = getData($address);
            //echo '<pre>';print_r($response); die;
            if(!empty($response->results))
            {
                $lati = $response->results[0]->geometry->location->lat;
                $longi = $response->results[0]->geometry->location->lng;
                
                $data = array(
                    'lati' => $lati,
                    'longi' => $longi
                );
                
                return $data;
                
            }
            
            if($i == 0)
            {
                $pattern = '/'.$street."\+".'/';
                $address = preg_replace($pattern, '', $address);
            }
            else if($i == 1)
            {
                $pattern = '/'.$street."\+".'/';
                $address = preg_replace($pattern, '', $address);
            }
            else if($i == 2)
            {
                $pattern = '/'.$city."\+".'/';
                $address = preg_replace($pattern, '', $address);
            }
            else if($i == 3)
            {
                if($state)
                    $pattern = '/'.$state."\+".'/';
                else
                    $pattern = '/'.$state."\+".'/';
                
                $address = preg_replace($pattern, '', $address);
            }
            
            
            $i++;
   
        }
    }
    
	function getLatLong($address)
    {
        $add = array();
        $add = explode(',',$address);
        $street = $add[0];
        $city = $add[1];
        $state = $add[2];
        
        $_coords = $this->getmapdata12($street ,$city , $state);
        //print'<pre>'; print_r($_coords);
        return $_coords;
    }
   
   
   
    function getLatLongSite($address) 
    {
        if($address)
        {
            $latlong =array();
            $this->db->select('latitude, longitude');
            $this->db->from('sites');
            $this->db->where('idsite', $address);
            $query = $this->db->get();
            if($query -> num_rows() > 0) 
                foreach($query -> result_array() as $key => $val) 
                {
                    $latlong['lat'] = $val['latitude'];
                    $latlong['long'] = $val['longitude'];
                }    
        }
        if($latlong)
            return $latlong;
    }
    
    
	public function getActivityByZone($startdate = '',$enddate = '', $zoneid = '') 
    {   
        $startdate_arr = explode("/",$startdate);
        $startdate = $startdate_arr[2]."-".$startdate_arr[0]."-".$startdate_arr[1];
        $all_fields = $this->input->get_post('all_fields_1');
        
        $enddate_arr = explode("/",$enddate);
        $enddate = $enddate_arr[2]."-".$enddate_arr[0]."-".$enddate_arr[1];
        $id_location = $this->session->userdata('idlocation');
        
        $treatment_adult = array(); 
        $treat_activity = array();
        $i = 0;
        $this->db->select('at.*,s.idsite, s.site, s.address1,  s.address2 ,s.city, st.statename, z.*, tm.*, pd.*, ps.*, tre.*, u.*');
        $this->db->from('adulticidetreatments AS at');
        $this->db->join('users AS u','at.idapplicator = u.iduser','LEFT');
        $this->db->join('area_treated AS tre','at.iduomtotalareatreated = tre.idareatreated','LEFT');
        $this->db->join('products AS pd','at.idproduct = pd.idproduct','LEFT');
        $this->db->join('productsizes AS ps','pd.idproductsize = ps.idproductsize','LEFT');
        $this->db->join('treatmentmethods AS tm','at.idapplicationmethod = tm.idtreatmentmethod','LEFT');
        $this->db->join('zones AS z','at.idzone = z.idzone','INNER');
        $this->db->join('sites AS s','at.idsite = s.idsite','LEFT');
        $this->db->join('states AS st','s.idstate = st.idstate','LEFT');
        $this->db->where('at.idlocation',$id_location);
        $this->db->where('at.isdeleted','0');
        $this->db->where('at.date >=',$startdate);
        $this->db->where('at.date <=',$enddate);
        $this->db->where('at.idzone',$zoneid);
        //$this->db->group_by('z.idzone');
        //'at.idadulttreatment', 'at.date', 'at,time', 's.site'
        $query = $this->db->get();
        if($query -> num_rows() > 0) 
            foreach($query -> result_array() as $key => $val) 
            {
                $treat_activity['zone'] = $val['zone'];
                $treat_activity['treatment_method'] = $val['treatmentmethod'];
                $treat_activity['product_name'] = $val['productname'];
                $treat_activity['amount'] = "";
                $treat_activity['product_size'] = $val['productsize'];
                $treat_activity['area_treated'] = $val['totalareatreated']." ".$val['unitarea'];
                $treat_activity['applicator'] = $val['firstname']." ".$val['lastname'];
                $treatment_adult[$i]['id'] = $val['idadulticidetreatment'];                
                $treatment_adult[$i]['site'] = $val['site'];
                $treatment_adult[$i]['address'] = $val['address1'];
                $treatment_adult[$i]['city'] = $val['city'];
                $treatment_adult[$i]['statename'] = $val['statename'];
                
                $treatment_adult[$i]['location'] = $val['latitude']. " " . $val['longitude'];
                if($val['date'] && $val['date'] != '1970-01-01' && $val['date'] != '0001-01-30' && $val['date'] != '0000-00-00')
                    $treatment_adult[$i]['date'] = date("m/d/Y", strtotime($val['date']))." ".date("h:i:s A", strtotime($val['time']));
                else
                    $treatment_adult[$i]['date'] = '';
                
                //$treatment_adult[$i]['address'] = $val['address1'].", ".$val['address2'];
                $treatment_adult[$i]['activity'] = $treat_activity;
                $i++;
            }
            
        $query->free_result(); 
        $treatment_larva = array();
        $treatment_lr_activity = array();
        $k = 0;
        $this->db->select('lrt.*, s.idsite, s.site, s.address1,  s.address2 ,s.city, st.*, lcr.*, pd.*, tre.*, u.*, sta.statename');
        $this->db->from('larvaltreatments AS lrt');
        $this->db->join('users AS u','lrt.idapplicator = u.iduser','LEFT');
        $this->db->join('area_treated AS tre','lrt.iduomtotalareatreated = tre.idareatreated','LEFT');
        $this->db->join('products AS pd','lrt.idproduct = pd.idproduct','LEFT');
        $this->db->join('larvaecountrange AS lcr','lrt.idlarvaelcountrange = lcr.idlarvaecountrange','LEFT');
        $this->db->join('sitetypes AS st','lrt.idsitetype = st.idsitetype','LEFT');
        $this->db->join('sites AS s','lrt.idsite = s.idsite','LEFT');
        $this->db->join('states AS sta','s.idstate = sta.idstate','LEFT');
        $this->db->where('lrt.idlocation',$id_location);
        $this->db->where('lrt.isdeleted','0');
        $this->db->where('lrt.date >=',$startdate);
        $this->db->where('lrt.date <=',$enddate);
        $this->db->where('lrt.idzone',$zoneid);
        $query = $this->db->get();
        if($query -> num_rows() > 0) 
            foreach($query -> result_array() as $key => $val) 
            {
                $treatment_lr_activity['sitetype'] = $val['sitetype'];
                $treatment_lr_activity['larval_count'] = $val['larvaecountrange'];
                $treatment_lr_activity['product_name'] = $val['productname'];
                $treatment_lr_activity['amt_applied'] = "";
                $treatment_lr_activity['area_treated'] = $val['totalareatreated']." ".$val['unitarea'];
                $treatment_lr_activity['applicator'] = $val['firstname']." ".$val['lastname'];
                
                $treatment_larva[$k]['id'] = $val['idlarvaltreatment'];
                if($val['date'] && $val['date'] != '1970-01-01' && $val['date'] != '0001-01-30' && $val['date'] != '0000-00-00')
                    $treatment_larva[$k]['date'] = date("m/d/Y", strtotime($val['date']))." ".date("h:i:s A", strtotime($val['time']));
                else
                    $treatment_larva[$k]['date'] = '';
                
                $treatment_larva[$k]['location'] = $val['latitude']. " " . $val['longitude'];
                $treatment_larva[$k]['site'] = $val['site'];
                $treatment_larva[$k]['site'] = $val['site'];
                $treatment_larva[$k]['address'] = $val['address1'];
                $treatment_larva[$k]['city'] = $val['city'];
                $treatment_larva[$k]['statename'] = $val['statename'];
                
                $treatment_larva[$k]['address'] = $val['address1'].", ".$val['address2'];
                $treatment_larva[$k]['activity'] = $treatment_lr_activity;
                $k++;
            }
                
        $query->free_result();     
        $larval_inspection = array();
        $j = 0;
        $this->db->select('lrt.*, s.idsite, s.site, s.address1,  s.address2 ,s.city, st.*, lcr.*, ins.*, wtr.*, sta.statename');
        $this->db->from('larvalsurveillance AS lrt');
        $this->db->join('watertempranges AS wtr','lrt.idwatertemprange = wtr.idwatertemprange','LEFT');
        $this->db->join('instar AS ins','lrt.idinstar = ins.idinstar','LEFT');
        $this->db->join('sitetypes AS st','lrt.idsitetype = st.idsitetype','LEFT');
        $this->db->join('larvaecountrange AS lcr','lrt.idlarvaecountrange = lcr.idlarvaecountrange','LEFT');
        $this->db->join('sites AS s','lrt.idsite = s.idsite','LEFT');
        $this->db->join('states AS sta','s.idstate = sta.idstate','LEFT');
        $this->db->where('lrt.idlocation',$id_location);
        $this->db->where('lrt.isdeleted','0');
        $this->db->where('lrt.date >=',$startdate);
        $this->db->where('lrt.date <=',$enddate);
        $this->db->where('lrt.idzone',$zoneid);
        $query = $this->db->get();
        if($query -> num_rows() > 0) 
            foreach($query -> result_array() as $key => $val) 
            {
                //$larval_activity['sitetype'] = $val['sitetype'];
                $larval_activity['larval_count'] = $val['totalcount'];
                $larval_activity['instar'] = $val['instar'];
                $larval_activity['water_temprature'] = $val['watertemprange'];
                
                $larval_inspection[$j]['id'] = $val['idlarvalsurveillance'];
                if($val['date'] && $val['date'] != '1970-01-01' && $val['date'] != '0001-01-30' && $val['date'] != '0000-00-00')
                    $larval_inspection[$j]['date'] = date("m/d/Y", strtotime($val['date']))." ".date("h:i:s A", strtotime($val['time']));
                else
                    $larval_inspection[$j]['date'] = '';
                
                $larval_inspection[$j]['site'] = $val['site'];
                $larval_inspection[$j]['address'] = $val['address1'];
                $larval_inspection[$j]['city'] = $val['city'];
                $larval_inspection[$j]['statename'] = $val['statename'];
                
                $larval_inspection[$j]['location'] = $val['latitude']. " " . $val['longitude'];
                //$larval_inspection[$j]['address'] = $val['address1'].", ".$val['address2'];
                $larval_inspection[$j]['activity'] = $larval_activity;
                $j++;
            }
            
            //echo "<pre>";
//            print_r($larval_inspection);
//            die;
        $query->free_result(); 
        $service_request = array();
        $ser_activity = array();
        $l = 0;
        $this->db->select('sr.*, s.site , s.latitude AS lati, s.longitude AS longi,s.address1 , s.address2, st.statename');
        $this->db->from('servicerequests AS sr');
        $this->db->join('sites AS s','sr.idsite = s.idsite','LEFT');
        $this->db->join('states AS st','s.idstate = st.idstate','LEFT');
        $this->db->where('sr.idlocation',$id_location);
        $this->db->where('sr.isdeleted','0');
        $this->db->where('sr.opendate >=',$startdate);
        $this->db->where('sr.opendate <=',$enddate);
        $this->db->where('sr.idzone',$zoneid);
        $query = $this->db->get();
        
        //echo $this->db->last_query();
        
        
        if($query -> num_rows() > 0) 
            foreach($query -> result_array() as $val) 
            {
                $ser_activity['open_date'] = $val['opendate'];
                $ser_activity['close_date'] = $val['closedate'];
                $ser_activity['description'] = $val['description'];
                if ($val['dispcorvidpickup'] == 1)
                    $ser_activity['dispcorvidpickup'] = "Corvid Pickup";
                
                if ($val['disnoaction'] == 1)
                    $ser_activity['disnoaction'] = "No Action";
               
                if ($val['dispsourcereduction'] == 1)
                    $ser_activity['dispsourcereduction'] = "Source Reduction";
               
                if ($val['dispfollowupvisit'] == 1)
                    $ser_activity['dispfollowupvisit'] = "Follow-up Visit";
                    
                if ($val['dispsampletaken'] == 1)
                    $ser_activity['dispsampletaken'] = "Sample Taken";
                
                $service_request[$l]['id'] = !empty($val['idservicerequest'])?$val['idservicerequest']:'';
                if($val['closedate'] && $val['closedate'] != '1970-01-01' && $val['closedate'] != '0001-01-30' && $val['closedate'] != '0000-00-00')
                    $service_request[$l]['date'] = date("m/d/Y", strtotime($val['closedate']))." ".date("h:i:s A", strtotime($val['closetime']));
                else
                    $service_request[$l]['date'] = '';
                
                $service_request[$l]['site'] = !empty($val['site'])?$val['site']:'';
                $service_request[$l]['address'] = !empty($val['address1'])?$val['address1']:'';
                $service_request[$l]['city'] = !empty($val['city'])?$val['city']:'';
                $service_request[$l]['statename'] = !empty($val['statename'])?$val['statename']:'';
                
                $loc = '';
                if(empty($val['latitude']))
                    $loc = !empty($val['lati'])?$val['lati']:'';
                else
                    $loc = !empty($val['latitude'])?$val['latitude']:'';
                    
                if(empty($val['longitude']))
                    $loc .= ' '.!empty($val['longi'])?$val['longi']:'';
                else
                    $loc .= ' '.!empty($val['longitude'])?$val['longitude']:'';
                $service_request[$l]['location'] = $loc;
                //$service_request[$l]['address'] = $val['address1'].", ".$val['address2'];
                $service_request[$l]['activity'] = $ser_activity;
                $l++;
            }
        $query->free_result(); 
        $lab_result = array();
        $lab_activity = array();
        $m = 0;
        $this->db->select('al.*, s.*, tr.*, ms.*, at.*, lr.*, asr.*, st.statename');
        $this->db->from('arbovirallabs AS al');
        $this->db->join('labresults AS lr','al.idlabresult = lr.idlabresult','LEFT'); 
        $this->db->join('mosquitospecies AS ms','al.idmosquitospecies = ms.idmosquitospecies','LEFT'); 
        $this->db->join('assaytypes AS at','al.idassaytype = at.idassaytype','LEFT'); 
        $this->db->join('traps AS tr','al.idtrap = tr.idtrap','LEFT');
        $this->db->join('adultsurveillance AS asr','tr.idtrap = asr.idtrap','LEFT');
        $this->db->join('sites AS s','tr.idsite = s.idsite','LEFT');
        $this->db->join('states AS st','s.idstate = st.idstate','LEFT');
        $this->db->where('al.idlocation',$id_location); 
        $this->db->where('al.isdeleted','0');
        $this->db->where('al.testdate >=',$startdate);
        $this->db->where('al.testdate <=',$enddate);
        $this->db->where('tr.idzone',$zoneid); 
        $query = $this->db->get();
        if($query -> num_rows() > 0) 
            foreach($query -> result_array() as $key => $val) 
            {
                $lab_activity['date_collected'] = $val['pudate'];
                $lab_activity['date_tested'] = $val['testdate'];
                $lab_activity['species'] = $val['mosquitospecies'];
                $lab_activity['poolsize'] = $val['poolsize'];
                $lab_activity['assay_type'] = $val['assaytype'];
                $lab_activity['positive_result'] = $val['labresult'];
                             
                $lab_result[$m]['id'] = $val['idarbovirallab'];    
                if($val['testdate'] && $val['testdate'] != '1970-01-01' && $val['testdate'] != '0001-01-30' && $val['testdate'] != '0000-00-00')
                    $lab_result[$m]['date'] = date("m/d/Y", strtotime($val['testdate']))." 12:00 AM";
                else
                    $lab_result[$m]['date'] = '';
                
                $lab_result[$m]['site'] = $val['site'];
                $lab_result[$m]['address'] = $val['address1'];
                $lab_result[$m]['city'] = $val['city'];
                $lab_result[$m]['statename'] = $val['statename'];
                
                $lab_result[$m]['location'] = $val['latitude']. " " . $val['longitude'];
                //$lab_result[$m]['address'] = $val['address1'].", ".$val['address2'];
                $lab_result[$m]['activity'] = $lab_activity;
                $m++;
            }
         $query->free_result(); 
        $adult = array(); 
        //$ad_activity = array();
        $n = 0;
        $this->db->select('a.*, tr.*, s.*, ty.*, asd.*, ms.*, g.*, trg.*, u.*,st.statename');
        $this->db->from('adultsurveillance AS a');
        $this->db->join('users AS u','a.idinspector = u.iduser','LEFT');
        $this->db->join('adultsurveillancedetails AS asd','a.idadultsurveillance = asd.idadultsurveillance','LEFT');
        $this->db->join('mosquitospecies AS ms','asd.idmosquitospecies = ms.idmosquitospecies','LEFT');
        $this->db->join('genuses AS g','ms.idgenus = g.idgenus','LEFT');
        $this->db->join('traps AS tr','a.idtrap = tr.idtrap','LEFT'); 
        $this->db->join('traptypes AS ty','tr.idtraptype = ty.idtraptype','LEFT');
        $this->db->join('sites AS s','tr.idsite = s.idsite','LEFT');
        $this->db->join('states AS st','s.idstate = st.idstate','LEFT');  
        $this->db->join('tempranges AS trg','a.idtemprange = trg.idtemprange','LEFT');
        $this->db->where('a.idlocation',$id_location);
        $this->db->where('a.isdeleted','0');
        $this->db->where('a.pudate >=',$startdate);
        $this->db->where('a.pudate <=',$enddate);
        $this->db->where('tr.idzone',$zoneid);
        $this->db->group_by('tr.idzone');
		$query = $this->db->get();
        
        if($query -> num_rows() > 0) 
            foreach($query -> result_array() as $key => $val)
            {
                $ad_activity['trap name'] = $val['trap'];
                $ad_activity['trap type'] = $val['traptype'];
                $ad_activity['genus'] = $val['genus'];
                $ad_activity['species'] = $val['mosquitospecies'];
                $ad_activity['totalcount'] = $val['totalcount'];
                $ad_activity['idtemp'] = $val['idtemprange'];
                $ad_activity['temprange'] = $val['temprange'];
                $ad_activity['inspector'] = $val['firstname']." ".$val['lastname'];
                
                $adult[$n]['id'] = $val['idadultsurveillance'];
                if($val['pudate'] && $val['pudate'] != '1970-01-01' && $val['pudate'] != '0001-01-30' && $val['pudate'] != '0000-00-00')
                    $adult[$n]['date'] = date("m/d/Y", strtotime($val['pudate']))." ".date("h:i:s A", strtotime($val['putime']));
                else
                    $adult[$n]['date'] = '';
                
                $adult[$n]['site'] = $val['site'];
                $adult[$n]['address'] = $val['address1'];
                $adult[$n]['city'] = $val['city'];
                $adult[$n]['statename'] = $val['statename'];
                
                $adult[$n]['location'] = $val['latitude']. " " . $val['longitude'];
                $adult[$n]['activity'] = $ad_activity;
                $n++;
            }
                
        $this->data['adult'] =  !empty($adult)?$adult:'';
        $this->data['larvel'] = $larval_inspection;
        $this->data['lab'] = $lab_result;
        $this->data ['service']= $service_request;
        $this->data['treatment'] = $treatment_adult;  
        //echo "<pre>";
//        print_r(data);
//        die;
	   return $this->data;
    }
   
    
    
}
