<?php
error_reporting (0);
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Adultsurveillance_report_model extends CI_Model {
	public $data = array();
	public $trap_name = "";
	public $trap_count = "";
	public $temparr = array ();
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	// Get Inspectors
	public function getInspectors()
	
	{
	    $this->db->select ( 'u.iduser, u.firstname, u.middlename, u.lastname' );
	    $this->db->from ( 'users AS u' );
	    $this->db->join ( 'userlocationassignment AS ula', "u.iduser = ula.iduser", 'INNER' );
	    $this->db->where ( 'ula.idlocation', $this->session->userdata ( 'idlocation' ) );
	    $this->db->where ( 'u.is_active', '1' );
	    $this->db->order_by ( 'u.firstname', 'asc' );
	    $this->db->order_by ( 'u.lastname', 'asc' );
	    
	    $this->str = "";
	    $query = $this->db->get ();
	    
	    if ($query->num_rows () > 0) {
	        foreach ( $query->result_array () as $row ) {
	            $middlename = ! empty ( $row ['middlename'] ) ? " " . $row ['middlename'] . " " : " ";
	            $this->str .= '<option value="' . $row ['iduser'] . '">' . $row ['firstname'] . $middlename . $row ['lastname'] . '</option>';
	        }
	    }
	    
	    return $this->str;
	}
	
	
	
	/**
	 * Function to fetch Adult Surveillance
	 */
	public function getAdultSurveillanceGraph($startdate = '', $enddate = '', $zone = '', $site = '', $_species = '', $_traptypes = '', $techs = '', $inspector = '') {
		$startdate_arr = explode ( "/", $startdate );
		$startdate = $startdate_arr [2] . "-" . $startdate_arr [0] . "-" . $startdate_arr [1];
		
		$enddate_arr = explode ( "/", $enddate );
		$enddate = $enddate_arr [2] . "-" . $enddate_arr [0] . "-" . $enddate_arr [1];
		
		$this->db->select ( 'a.idadultsurveillance , 
				a.idtrap, 
				a.setdate, 
				a.settime,
				a.pudate, 
				a.putime,
                a.idinspector,
				z.zone, 
				s.site, 
				t.trap,
				tt.idtraptype, 
				tt.traptype' );
		$this->db->from ( 'adultsurveillance AS a' );
		$this->db->join ( 'traps AS t', 'a.idtrap = t.idtrap', 'LEFT' );
		$this->db->join ( 'sites AS s', 't.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'zones AS z', 's.idzone = z.idzone', 'LEFT' );
		$this->db->join ( 'traptypes AS tt', 't.idtraptype = tt.idtraptype', 'LEFT' );
		$this->db->where ( 'a.isdeleted', '0' );
		$this->db->where ( 's.idsite <> 0' );
		if (! empty ( $zone ))
			$this->db->where ( 'z.idzone', $zone );
			
			// $this->db->where("z.idlocation", $this->session->userdata('idlocation'));
			// $this->db->where("s.idlocation", $this->session->userdata('idlocation'));
		
		if (! empty ( $site ))
			$this->db->where ( 's.idsite', $site );
		
		if (! empty ( $_traptypes ))
			$this->db->where ( 't.idtrap', $_traptypes );
		
		$this->db->where ( "a.idlocation", $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'a.pudate >=', $startdate );
		$this->db->where ( 'a.pudate <=', $enddate );
		$this->db->order_by ( 'a.pudate', 'DESC' );
		// $this->db->order_by('a.putime' , 'DESC');
		$this->db->order_by ( 'tt.traptype', 'ASC' );
		
		$query = $this->db->get ();
		// echo $this->db->last_query();
		$result = array ();
		$pumon = '';
		$d = 0;
		if ($query->num_rows () > 0) {
			// print'<pre>';
			// print_r($query->result_array());
			foreach ( $query->result_array () as $key => $val ) {
				if ($pumon == date ( 'm', strtotime ( $val ['pudate'] ) )) {
					$result [$d] [] = $val;
				} else {
					$d ++;
					$result [$d] [] = $val;
				}
				// echo "here ->".$pumon."<- ".date('m' , strtotime($val['pudate']))."<br/>";
				$pumon = date ( 'm', strtotime ( $val ['pudate'] ) );
			}
		}
		
		// print'<pre>';
		// print_r($result);
		// print'</pre>';
		// die;
		$trapcount = 0;
		$traparr = array ();
		$monarr = array ();
		$i = 0;
		if (! empty ( $result )) {
			foreach ( $result as $key => $val ) {
				$traptype = '';
				$count = 0;
				$d = 0;
				foreach ( $val as $ka => $va ) {
					if ($va ['traptype'] != $traptype) {
						$d ++;
					}
					
					$result1 [$i] [$d] [] = $va;
					$traptype = $va ['traptype'];
				}
				$i ++;
			}
		}
		$trapcount = $d;
		// print'<pre>';
		// print_r($result1);
		// print'</pre>';
		// die;
		$str = '';
		$result = array ();
		if (! empty ( $result1 )) {
			$d = 0;
			foreach ( $result1 as $key1 => $val1 ) {
				foreach ( $val1 as $key2 => $val2 ) {
					$count = 0;
					$trapnight = 0;
					$mon = '';
					foreach ( $val2 as $key3 => $va ) {
						$this->db->select ( 'SUM(adst.count) AS count' );
						$this->db->from ( 'adultsurveillancedetails AS adst' );
						$this->db->where ( 'adst.idadultsurveillance', $va ['idadultsurveillance'] );
						
						$query = $this->db->get ();
						
						if ($query->num_rows () > 0) {
							$temp = $query->result_array ();
							$count += $temp [0] ['count'];
						}
						
						$date1 = $va ['pudate'] . ' ' . date ( 'H:i:s', strtotime ( $va ['putime'] ) );
						$date2 = $va ['setdate'] . ' ' . date ( 'H:i:s', strtotime ( $va ['settime'] ) );
						$diff = dateDiff ( $date1, $date2 );
						$mon = date ( 'M', strtotime ( $va ['pudate'] ) );
						if (! empty ( $diff ))
							$trapnight += $diff;
						$traptype = $va ['traptype'];
					}
					$this->temparr [$d] ['month'] = $mon;
					$this->temparr [$d] ['traptype'] = $traptype . " for " . $mon;
					
					if ($trapnight == 0)
						$this->temparr [$d] ['avg'] = $count;
					else
						$this->temparr [$d] ['avg'] = $count / $trapnight;
					$monarr [] = $mon;
					$traparr [] = $traptype . " for " . $mon;
					$d ++;
				}
			}
		}
		$trapcount = $d;
		// $traparr = array_unique($traparr);
		$monarr = array_unique ( $monarr );
		// print'<pre>';
		// print_R($this->temparr);
		// print_r($monarr);
		// print_R($traparr);
		// die;
		
		$mon = '';
		$d = 0;
		$str = '';
		if (! empty ( $monarr )) {
			foreach ( $monarr as $key => $val ) {
				$str .= "['" . $val . "',";
				$tstr = '';
				foreach ( $traparr as $k => $v ) {
					$tavg = $this->getTrapType ( $v, $val );
					$tstr .= $tavg . ",";
				}
				$tstr = ! empty ( $tstr ) ? trim ( $tstr, ',' ) : '';
				$str .= $tstr . "],";
			}
		}
		$str = ! empty ( $str ) ? trim ( $str, ',' ) : '';
		// echo $str;
		// die;
		$mon = '';
		$trapname = '';
		$trapcount = '';
		$traparr = array ();
		if (! empty ( $this->temparr )) {
			foreach ( $this->temparr as $key => $val ) {
				$trapname .= "'" . $val ['traptype'] . "',";
				$traparr [] = $val ['traptype'];
			}
			$trapname = ! empty ( $trapname ) ? trim ( $trapname, ',' ) : '';
		}
		// echo $str." ".$trapname."<br/>";
		// die;
		$data1 ['month'] = $str;
		$data1 ['trapname'] = $trapname;
		$data1 ['traparr'] = $traparr;
		return $data1;
		// print'<pre>';
		// print_r($temparr);
		// die;
	}
	public function getTrapType($trapname = '', $mon = '') {
		foreach ( $this->temparr as $key => $val ) {
			if ($val ['month'] == $mon && $val ['traptype'] == $trapname) {
				return $val ['avg'];
			}
		}
		return 0;
	}
	public function getAdultSurveillance($startdate = '', $enddate = '', $zone = '', $site = '', $_species = '', $_traptypes = '', $techs = '', $inspector = '') {
		// echo $startdate." ".$enddate." ".$zone." ".$site." ".$species." ".$traptypes." ".$techs."<br>";
		// echo "thr".$species;
		// die;
		$startdate_arr = explode ( "/", $startdate );
		$startdate = $startdate_arr [2] . "-" . $startdate_arr [0] . "-" . $startdate_arr [1];
		
		$enddate_arr = explode ( "/", $enddate );
		$enddate = $enddate_arr [2] . "-" . $enddate_arr [0] . "-" . $enddate_arr [1];
		
		// $this->db->select('z.idzone,z.zone');
		// $this->db->from('zones AS z');
		// $this->db->join('traps AS t','t.idzone = z.idzone','LEFT');
		// $this->db->join('adultsurveillance AS a','a.idtrap = t.idtrap','INNER');
		// $this->db->where("z.idlocation", $this->session->userdata('idlocation'));
		// $this->db->where('a.pudate >=',$startdate);
		// $this->db->where('a.pudate <=',$enddate);
		// $this->db->where('a.isdeleted','0');
		// $this->db->order_by('a.pudate' , 'DESC');
		// $this->db->order_by('a.putime' , 'DESC');
		//
		
		$this->db->select ( 'a.idadultsurveillance, a.idinspector, z.idzone, z.zone' );
		$this->db->from ( 'adultsurveillance AS a' );
		$this->db->join ( 'traps AS t', 't.idtrap = a.idtrap', 'LEFT' );
		$this->db->join ( 'sites AS s', 's.idsite = t.idsite', 'LEFT' );
		$this->db->join ( 'zones AS z', 's.idzone = z.idzone', 'LEFT' );
		$this->db->where ( "a.idlocation", $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'a.pudate >=', $startdate );
		$this->db->where ( 'a.pudate <=', $enddate );
		$this->db->where ( 'a.isdeleted', '0' );
		$this->db->where ( 't.idsite <> 0' );
		$this->db->order_by ( 'a.pudate', 'DESC' );
		$this->db->order_by ( 'a.putime', 'DESC' );
		
		if (! empty ( $zone ))
			$this->db->where ( 'z.idzone', $zone );
			// $this->db->group_by('z.idzone');
		$query = $this->db->get ();
		// echo $this->db->last_query();
		// die;
		$trapdata = array ();
		$traparr = array ();
		$data_1 = array ();
		$t = 0;
		if ($query->num_rows () > 0) {
			$i = 0;
			// $sitedata = $query -> result_array();
			foreach ( $query->result_array () as $key => $val ) {
				$this->db->select ( 's.idsite, s.site, s.idzone, a.pudate, a.idinspector, a.idadultsurveillance' );
				$this->db->from ( 'adultsurveillance AS a' );
				$this->db->join ( 'traps AS t', 'a.idtrap = t.idtrap', 'LEFT' );
				$this->db->join ( 'sites AS s', 't.idsite = s.idsite', 'LEFT' );
				$this->db->where ( "a.idlocation", $this->session->userdata ( 'idlocation' ) );
				$this->db->where ( "a.idadultsurveillance", $val ['idadultsurveillance'] );
				$this->db->where ( 'a.isdeleted', '0' );
				$this->db->where ( 'a.pudate >=', $startdate );
				$this->db->where ( 'a.pudate <=', $enddate );
				$this->db->order_by ( 'a.pudate', 'DESC' );
				$this->db->order_by ( 'a.putime', 'DESC' );
				if (! empty ( $site ))
					$this->db->where ( 's.idsite', $site );
					// $this->db->group_by('s.idsite');
				$query1 = $this->db->get ();
				// echo $this->db->last_query()."<br/>";
				// continue;
				$data_1 [$i] = $val;
				$j = 0;
				// print'<pre>';
				// print_r($query1 -> result_array());
				if ($query1->num_rows > 0) {
					foreach ( $query1->result_array () as $k1 => $v1 ) {
						$this->db->select ( 't.idtrap,t.trap,tt.idtraptype ,tt.traptype' );
						$this->db->from ( 'adultsurveillance AS a' );
						$this->db->join ( 'traps AS t', 'a.idtrap = t.idtrap', 'LEFY' );
						$this->db->join ( 'traptypes AS tt', 't.idtraptype = tt.idtraptype', 'LEFT' );
						// $this->db->where('t.idsite',$v1['idsite']);
						$this->db->where ( 'a.idadultsurveillance', $v1 ['idadultsurveillance'] );
						$this->db->where ( "a.idlocation", $this->session->userdata ( 'idlocation' ) );
						$this->db->where ( 'a.isdeleted', '0' );
						$this->db->order_by ( 'tt.traptype', 'ASC' );
						$trap = array ();
						
						if (! empty ( $_traptypes ))
							$this->db->where ( 'tt.idtraptype', $_traptypes );
						
						$data_1 [$i] ['site'] [$j] = $v1;
						$query2 = $this->db->get ();
						$k = 0;
						// echo $this->db->last_query()."<br/>";
						// continue;
						// echo $this->db->last_query()."<br/>";
						// print'<pre>';
						// print_r($query2 -> result_array());
						// continue;
						if ($query2->num_rows () > 0) {
							$m = 0;
							foreach ( $query2->result_array () as $k2 => $v2 ) {
								$this->db->select ( 'u.firstname, u.middlename, u.lastname,a.*' );
								$this->db->from ( 'adultsurveillance AS a' );
								$this->db->join ( 'users AS u', 'a.idinspector = u.iduser', 'LEFT' );
								$this->db->join ( 'traps AS t', 'a.idtrap = t.idtrap', 'LEFT' );
								$this->db->join ( 'traptypes AS tt', 't.idtraptype = tt.idtraptype', 'LEFT' );
								$this->db->where ( 'a.idlocation', $this->session->userdata ( 'idlocation' ) );
								// $this->db->where('a.idtrap',$v2['idtrap']);
								$this->db->where ( 'a.idadultsurveillance', $v1 ['idadultsurveillance'] );
								$this->db->where ( 'a.pudate >=', $startdate );
								$this->db->where ( 'a.pudate <=', $enddate );
								$this->db->order_by ( 'a.pudate', 'DESC' );
								$this->db->order_by ( 'a.putime', 'DESC' );
								$count = 0;
								
								if (! empty ( $techs ))
									$this->db->where ( 'u.iduser', $techs );
									
									// echo $this->db->last_query()."<br/>";
									// continue;
									// echo "<br>========START ============<br>";
									// print'<pre>';
									// print_r($trapdata);
									// print'</pre>';
									// $this->trap_name .= "'".$v2['traptype']."',";
								
								$data_1 [$i] ['site'] [$j] ['trap'] [$k] = $v2;
								$query3 = $this->db->get ();
								// echo $this->db->last_query()."<br>";
								$l = 0;
								if ($query3->num_rows () > 0) {
									foreach ( $query3->result_array () as $k3 => $v3 ) {
										$adult = array ();
										$this->db->select ( 'adst.idmosquitospecies,adst.count,m.mosquitospecies,g.genus' );
										$this->db->from ( 'adultsurveillancedetails AS adst' );
										$this->db->join ( 'mosquitospecies AS m', 'adst.idmosquitospecies = m.idmosquitospecies', 'LEFT' );
										$this->db->join ( 'genuses AS g', 'm.idgenus = g.idgenus', 'LEFT' );
										$this->db->where ( 'adst.idadultsurveillance', $v3 ['idadultsurveillance'] );
										
										if (! empty ( $_species ))
											$this->db->where ( 'adst.idmosquitospecies', $_species );
										
										$query4 = $this->db->get ();
										$species = array ();
										if ($query4->num_rows () > 0) {
											$species = $query4->result_array ();
										}
										
										$idadult = "";
										$this->db->select ( 'COUNT(*) AS count' );
										$this->db->from ( 'adultsurveillancedetails' );
										$this->db->where ( 'idadultsurveillance', $v3 ['idadultsurveillance'] );
										$q = $this->db->get ();
										// echo $this->db->last_query()."<br/>";
										// continue;
										if ($q->num_rows () > 0) {
											$idadult = $q->result_array ();
											$idadult = $idadult [0] ['count'];
										}
										
										// if(empty($idadult))
										// $idadult = 'SUM(adst.count) as "total"';
										// else
										// $idadult = '(SUM(adst.count)/'.$idadult.')as "total"';
										//
										// $this->db->select($idadult);
										// $this->db->from('adultsurveillancedetails AS adst');
										// $this->db->where('adst.idadultsurveillance',$v3['idadultsurveillance']);
										//
										// $query4 = $this->db->get();
										//
										// $tmpcount = 0;
										// if($query4 -> num_rows() > 0)
										// {
										// $tmpcount = $query4 -> result_array();
										// $tmpcount = !empty($tmpcount[0]['total'])?$tmpcount[0]['total']:0;
										// }
										
										$count += $idadult;
										$adult = $v3;
										if (! empty ( $species )) {
											
											$adult ['species'] = $species;
											$adult ['count'] = $count;
										}
										
										// $data_1[$i]['site'][$j]['trap'][$k]['adult'] = $adult;
										$data_1 [$i] ['site'] [$j] ['trap'] [$k] ['adult'] [$l] = $adult;
										$l ++;
									}
								}
								// echo "<br>=========$t Times=======".$v2['traptype']."===$count<br>";
								if (! empty ( $trapdata )) {
									foreach ( $trapdata as $kt => $vt ) {
										// print'<pre>';
										// echo $vt[0]." ".$v2['traptype']."<br>";
										//
										if (! empty ( $vt [0] ) && $vt [0] == $v2 ['traptype']) {
											$trapdata [$kt] [1] += ! empty ( $count ) ? $count : 0;
											;
										}
									}
								}
								
								// print'<pre>';
								// print_r($trapdata);
								// print'</pre>';
								// echo "<br>========END ============<br>";
								// $this->trap_count .= !empty($count)?$count.",":"0,";
								$k ++;
								$t ++;
							}
						}
						
						$j ++;
					}
				}
				
				$i ++;
			}
			// die;
		}
		
		$this->data ['data'] = $data_1;
		
		// print'<pre>';
		// print_r($data_1);
		// print_r($this->data);
		// print_r($trapdata);
		// die;
		return $this->data;
	}
}
