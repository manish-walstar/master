<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
error_reporting ( "-1" );
ini_set ( "memory_limit", "512M" );
ini_set ( "max_execution_time", "86400" );
class Lighttrap_report_model extends CI_Model {
	public $data = "";
	public $trap_name = "";
	public $trap_count = "";
	public $temparr = array ();
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	public function getLighttrap($startdate = '', $enddate = '') {
		$startdate_arr = explode ( "/", $startdate );
		$startdate = $startdate_arr [2] . "-" . $startdate_arr [0] . "-" . $startdate_arr [1];
		
		$enddate_arr = explode ( "/", $enddate );
		$enddate = $enddate_arr [2] . "-" . $enddate_arr [0] . "-" . $enddate_arr [1];
		
		// print'<pre>';
		// print_r($data_1);
		// print_r($adultId);
		// die();
		
		/**
		 * Fetching Report for last year and calculating this week
		 * and last week in the iteration
		 */
		$currdate = ! empty ( $startdate ) ? $startdate : date ( 'Y-m-d' );
		$thisweek = date ( 'Y-m-d', strtotime ( "-1 week" ) );
		$lastweek = date ( 'Y-m-d', strtotime ( "-1 week", strtotime ( $thisweek ) ) );
		
		if (! empty ( $startdate )) {
			// $thisweek = date('Y-m-d' , strtotime("-1 week" , strtotime($startdate)));
			// $lastweek = date('Y-m-d' , strtotime("-2 week" , strtotime($thisweek)));
			if (! empty ( $enddate ))
				$lastdate = $enddate;
			else
				$lastdate = date ( 'Y-m-d', strtotime ( "-1 year", strtotime ( $startdate ) ) );
		} else {
			$lastdate = date ( 'Y-m-d', strtotime ( "-1 year" ) );
		}
		
		$query = $this->db->query ( "CALL sp_light_trap_yearly('" . $currdate . "', '" . $lastdate . "', '" . $this->session->userdata ( 'idlocation' ) . "')" );
		$currdate = date ( 'Y-m-d' );
		$lastdate = date ( 'Y-m-d', strtotime ( "-1 year" ) );
		$lastyrFrmdate = date ( 'Y-m-d', strtotime ( "-1 year" ) );
		$lastyrTodate = date ( 'Y-m-d', strtotime ( "-2 year" ) );
		// $query = $this->db->query("");
		// echo $this->db->last_query()."<br>";
		$data_l1 = array ();
		$adultId = array ();
		// print'<pre>';
		// print_r($query->result());
		// die;
		//
		$SPECIES1 = array ();
		$CULEX = array ();
		$AEDES = array ();
		$ANOPHELES = array ();
		$CULISETA = array ();
		$OTHER_SPECIES = array ();
		$UNSPECIATED = array ();
		
		$data_1 = array ();
		$tempsite = '';
		$i = 0;
		
		$thisweek_trapcount = 0;
		$thisweek_niterun = 0;
		$SPECIES1 ['thisweek'] ['CULEX'] = array ();
		$SPECIES1 ['thisweek'] ['AEDES'] = array ();
		$SPECIES1 ['thisweek'] ['ANOPHELES'] = array ();
		$SPECIES1 ['thisweek'] ['CULISETA'] = array ();
		$SPECIES1 ['thisweek'] ['OTHER_SPECIES'] = array ();
		$SPECIES1 ['thisweek'] ['UNSPECIATED'] = array ();
		
		$lastweek_count = 0;
		$lastweek_trapcount = 0;
		$lastweek_niterun = 0;
		$SPECIES1 ['lastweek'] ['CULEX'] = array ();
		$SPECIES1 ['lastweek'] ['AEDES'] = array ();
		$SPECIES1 ['lastweek'] ['ANOPHELES'] = array ();
		$SPECIES1 ['lastweek'] ['CULISETA'] = array ();
		$SPECIES1 ['lastweek'] ['OTHER_SPECIES'] = array ();
		$SPECIES1 ['lastweek'] ['UNSPECIATED'] = array ();
		
		$lastyear_trapcount = 0;
		$lastyear_niterun = 0;
		$SPECIES1 ['lastyear'] ['CULEX'] = array ();
		$SPECIES1 ['lastyear'] ['AEDES'] = array ();
		$SPECIES1 ['lastyear'] ['ANOPHELES'] = array ();
		$SPECIES1 ['lastyear'] ['CULISETA'] = array ();
		$SPECIES1 ['lastyear'] ['OTHER_SPECIES'] = array ();
		$SPECIES1 ['lastyear'] ['UNSPECIATED'] = array ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result () as $row ) {
				$query->next_result ();
				$query->free_result ();
				if ($row->trapnight < 0)
					continue;
				$query1 = $this->db->query ( "CALL sp_light_trap_mosq(" . intval ( $row->idadultsurveillance ) . ");" );
				// echo $this->db->last_query()."<br>";
				$data_2 = array ();
				// if($row->idadultsurveillance == '57299')
				// {
				// print'<pre>';
				// print_r($query1->result());
				// }
				// echo $row->idadultsurveillance." ".$query1 -> num_rows()."<br>";
				// print'<pre>';
				// echo "<br>=======First Time Aedes===========<br>";
				// print_r($AEDES);
				if ($query1->num_rows () > 0) {
					foreach ( $query1->result () as $row1 ) {
						// if(!empty($row1->genus) && !empty($row1->malecount) && !empty($row1->femalecount))
						// print'<pre>';
						// print_r($row1);
						// echo $row1->genus." ".$row1->mosquitospecies."<br>";
						if (! empty ( $row1->genus ))
							switch (strtoupper ( $row1->genus )) {
								case 'CULEX' :
									$flg = 0;
									if (! empty ( $data_2 ['CULEX'] )) {
										foreach ( $data_2 ['CULEX'] as $key => $val ) {
											if ($val->mosquitospecies == $row1->mosquitospecies) {
												$val->ttlmosq += $row1->ttlmosq;
												$val->malecount += $row1->malecount;
												$val->femalecount += $row1->femalecount;
												$flg = 1;
											}
										}
										if ($flg == 0) {
											$data_2 ['CULEX'] [] = $row1;
										}
									} else
										$data_2 ['CULEX'] [] = $row1;
									
									if ($row->setdate >= $thisweek && $row->pudate <= $currdate) {
										$flg = 0;
										if (! empty ( $SPECIES1 ['thisweek'] ['CULEX'] )) {
											for($i = 0; $i < count ( $SPECIES1 ['thisweek'] ['CULEX'] ); $i ++) {
												if ($SPECIES1 ['thisweek'] ['CULEX'] [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
													$SPECIES1 ['thisweek'] ['CULEX'] [$i] ['ttlmosq'] += $row1->ttlmosq;
													$SPECIES1 ['thisweek'] ['CULEX'] [$i] ['malecount'] += $row1->malecount;
													$SPECIES1 ['thisweek'] ['CULEX'] [$i] ['femalecount'] += $row1->femalecount;
													$flg = 1;
													break;
												}
											}
											if ($flg == 0) {
												$c = count ( $SPECIES1 ['thisweek'] ['CULEX'] ) - 1;
												$SPECIES1 ['thisweek'] ['CULEX'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
												$SPECIES1 ['thisweek'] ['CULEX'] [$c + 1] ['malecount'] = $row1->malecount;
												$SPECIES1 ['thisweek'] ['CULEX'] [$c + 1] ['femalecount'] = $row1->femalecount;
												$SPECIES1 ['thisweek'] ['CULEX'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
											}
										} else {
											$c = - 1;
											$SPECIES1 ['thisweek'] ['CULEX'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$SPECIES1 ['thisweek'] ['CULEX'] [$c + 1] ['malecount'] = $row1->malecount;
											$SPECIES1 ['thisweek'] ['CULEX'] [$c + 1] ['femalecount'] = $row1->femalecount;
											$SPECIES1 ['thisweek'] ['CULEX'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									}
									
									if ($row->setdate >= $lastweek && $row->pudate < $thisweek) {
										$flg = 0;
										if (! empty ( $SPECIES1 ['lastweek'] ['CULEX'] )) {
											for($i = 0; $i < count ( $SPECIES1 ['lastweek'] ['CULEX'] ); $i ++) {
												if ($SPECIES1 ['lastweek'] ['CULEX'] [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
													$SPECIES1 ['lastweek'] ['CULEX'] [$i] ['ttlmosq'] += $row1->ttlmosq;
													$SPECIES1 ['lastweek'] ['CULEX'] [$i] ['malecount'] += $row1->malecount;
													$SPECIES1 ['lastweek'] ['CULEX'] [$i] ['femalecount'] += $row1->femalecount;
													$flg = 1;
													break;
												}
											}
											if ($flg == 0) {
												$c = count ( $SPECIES1 ['lastweek'] ['CULEX'] ) - 1;
												$SPECIES1 ['lastweek'] ['CULEX'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
												$SPECIES1 ['lastweek'] ['CULEX'] [$c + 1] ['malecount'] = $row1->malecount;
												$SPECIES1 ['lastweek'] ['CULEX'] [$c + 1] ['femalecount'] = $row1->femalecount;
												$SPECIES1 ['lastweek'] ['CULEX'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
											}
										} else {
											$c = - 1;
											$SPECIES1 ['lastweek'] ['CULEX'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$SPECIES1 ['lastweek'] ['CULEX'] [$c + 1] ['malecount'] = $row1->malecount;
											$SPECIES1 ['lastweek'] ['CULEX'] [$c + 1] ['femalecount'] = $row1->femalecount;
											$SPECIES1 ['lastweek'] ['CULEX'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									}
									
									$flg = 0;
									if (! empty ( $CULEX )) {
										for($i = 0; $i < count ( $CULEX ); $i ++) {
											if ($CULEX [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
												$CULEX [$i] ['ttlmosq'] = $row1->ttlmosq;
												$CULEX [$i] ['malecount'] = $row1->malecount;
												$CULEX [$i] ['femalecount'] = $row1->femalecount;
												$CULEX [$i] ['mosquitospecies'] = $row1->mosquitospecies;
												$flg = 1;
											}
										}
										if ($flg == 0) {
											$c = count ( $CULEX ) - 1;
											$CULEX [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$CULEX [$c + 1] ['malecount'] = $row1->malecount;
											$CULEX [$c + 1] ['femalecount'] = $row1->femalecount;
											$CULEX [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									} else {
										$c = - 1;
										$CULEX [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
										$CULEX [$c + 1] ['malecount'] = $row1->malecount;
										$CULEX [$c + 1] ['femalecount'] = $row1->femalecount;
										$CULEX [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
									}
									if ($row->setdate >= $lastyrFrmdate && $row->pudate <= $lastyrTodate) {
										$flg = 0;
										if (! empty ( $SPECIES1 ['lastyear'] ['CULEX'] )) {
											for($i = 0; $i < count ( $SPECIES1 ['lastyear'] ['CULEX'] ); $i ++) {
												if ($SPECIES1 ['lastyear'] ['CULEX'] [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
													$SPECIES1 ['lastyear'] ['CULEX'] [$i] ['ttlmosq'] += $row1->ttlmosq;
													$SPECIES1 ['lastyear'] ['CULEX'] [$i] ['malecount'] += $row1->malecount;
													$SPECIES1 ['lastyear'] ['CULEX'] [$i] ['femalecount'] += $row1->femalecount;
													$flg = 1;
													break;
												}
											}
											if ($flg == 0) {
												$c = count ( $SPECIES1 ['lastyear'] ['CULEX'] ) - 1;
												$SPECIES1 ['lastyear'] ['CULEX'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
												$SPECIES1 ['lastyear'] ['CULEX'] [$c + 1] ['malecount'] = $row1->malecount;
												$SPECIES1 ['lastyear'] ['CULEX'] [$c + 1] ['femalecount'] = $row1->femalecount;
												$SPECIES1 ['lastyear'] ['CULEX'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
											}
										} else {
											$c = - 1;
											$SPECIES1 ['lastyear'] ['CULEX'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$SPECIES1 ['lastyear'] ['CULEX'] [$c + 1] ['malecount'] = $row1->malecount;
											$SPECIES1 ['lastyear'] ['CULEX'] [$c + 1] ['femalecount'] = $row1->femalecount;
											$SPECIES1 ['lastyear'] ['CULEX'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									}
									break;
								case 'ANOPHELES' :
									$flg = 0;
									if (! empty ( $data_2 ['ANOPHELES'] )) {
										foreach ( $data_2 ['ANOPHELES'] as $key => $val ) {
											if ($val->mosquitospecies == $row1->mosquitospecies) {
												$val->ttlmosq += $row1->ttlmosq;
												$val->malecount += $row1->malecount;
												$val->femalecount += $row1->femalecount;
												$flg = 1;
											}
										}
										if ($flg == 0) {
											$data_2 ['ANOPHELES'] [] = $row1;
										}
									} else
										$data_2 ['ANOPHELES'] [] = $row1;
									
									if ($row->setdate >= $thisweek && $row->pudate <= $currdate) {
										$flg = 0;
										if (! empty ( $SPECIES1 ['thisweek'] ['ANOPHELES'] )) {
											for($i = 0; $i < count ( $SPECIES1 ['thisweek'] ['ANOPHELES'] ); $i ++) {
												if ($SPECIES1 ['thisweek'] ['ANOPHELES'] [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
													$SPECIES1 ['thisweek'] ['ANOPHELES'] [$i] ['ttlmosq'] += $row1->ttlmosq;
													$SPECIES1 ['thisweek'] ['ANOPHELES'] [$i] ['malecount'] += $row1->malecount;
													$SPECIES1 ['thisweek'] ['ANOPHELES'] [$i] ['femalecount'] += $row1->femalecount;
													$flg = 1;
													break;
												}
											}
											if ($flg == 0) {
												$c = count ( $SPECIES1 ['thisweek'] ['ANOPHELES'] ) - 1;
												$SPECIES1 ['thisweek'] ['ANOPHELES'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
												$SPECIES1 ['thisweek'] ['ANOPHELES'] [$c + 1] ['malecount'] = $row1->malecount;
												$SPECIES1 ['thisweek'] ['ANOPHELES'] [$c + 1] ['femalecount'] = $row1->femalecount;
												$SPECIES1 ['thisweek'] ['ANOPHELES'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
											}
										} else {
											$c = - 1;
											$SPECIES1 ['thisweek'] ['ANOPHELES'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$SPECIES1 ['thisweek'] ['ANOPHELES'] [$c + 1] ['malecount'] = $row1->malecount;
											$SPECIES1 ['thisweek'] ['ANOPHELES'] [$c + 1] ['femalecount'] = $row1->femalecount;
											$SPECIES1 ['thisweek'] ['ANOPHELES'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									}
									
									if ($row->setdate >= $lastweek && $row->pudate < $thisweek) {
										$flg = 0;
										if (! empty ( $SPECIES1 ['lastweek'] ['ANOPHELES'] )) {
											for($i = 0; $i < count ( $SPECIES1 ['lastweek'] ['ANOPHELES'] ); $i ++) {
												if ($SPECIES1 ['lastweek'] ['ANOPHELES'] [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
													$SPECIES1 ['lastweek'] ['ANOPHELES'] [$i] ['ttlmosq'] += $row1->ttlmosq;
													$SPECIES1 ['lastweek'] ['ANOPHELES'] [$i] ['malecount'] += $row1->malecount;
													$SPECIES1 ['lastweek'] ['ANOPHELES'] [$i] ['femalecount'] += $row1->femalecount;
													$flg = 1;
													break;
												}
											}
											if ($flg == 0) {
												$c = count ( $SPECIES1 ['lastweek'] ['CULEX'] ) - 1;
												$SPECIES1 ['lastweek'] ['ANOPHELES'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
												$SPECIES1 ['lastweek'] ['ANOPHELES'] [$c + 1] ['malecount'] = $row1->malecount;
												$SPECIES1 ['lastweek'] ['ANOPHELES'] [$c + 1] ['femalecount'] = $row1->femalecount;
												$SPECIES1 ['lastweek'] ['ANOPHELES'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
											}
										} else {
											$c = - 1;
											$SPECIES1 ['lastweek'] ['ANOPHELES'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$SPECIES1 ['lastweek'] ['ANOPHELES'] [$c + 1] ['malecount'] = $row1->malecount;
											$SPECIES1 ['lastweek'] ['ANOPHELES'] [$c + 1] ['femalecount'] = $row1->femalecount;
											$SPECIES1 ['lastweek'] ['ANOPHELES'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									}
									
									$flg = 0;
									if (! empty ( $ANOPHELES )) {
										for($i = 0; $i < count ( $ANOPHELES ); $i ++) {
											if ($ANOPHELES [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
												$ANOPHELES [$i] ['ttlmosq'] = $row1->ttlmosq;
												$ANOPHELES [$i] ['malecount'] = $row1->malecount;
												$ANOPHELES [$i] ['femalecount'] = $row1->femalecount;
												$ANOPHELES [$i] ['mosquitospecies'] = $row1->mosquitospecies;
												$flg = 1;
											}
										}
										if ($flg == 0) {
											$c = count ( $ANOPHELES ) - 1;
											$ANOPHELES [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$ANOPHELES [$c + 1] ['malecount'] = $row1->malecount;
											$ANOPHELES [$c + 1] ['femalecount'] = $row1->femalecount;
											$ANOPHELES [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									} else {
										$c = - 1;
										$ANOPHELES [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
										$ANOPHELES [$c + 1] ['malecount'] = $row1->malecount;
										$ANOPHELES [$c + 1] ['femalecount'] = $row1->femalecount;
										$ANOPHELES [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
									}
									// if($row->setdate >= $lastyrFrmdate && $row->pudate <= $lastyrTodate)
									if ($row->setdate >= $lastdate && $row->pudate <= $currdate) {
										$flg = 0;
										if (! empty ( $SPECIES1 ['lastyear'] ['ANOPHELES'] )) {
											for($i = 0; $i < count ( $SPECIES1 ['lastyear'] ['ANOPHELES'] ); $i ++) {
												if ($SPECIES1 ['lastyear'] ['ANOPHELES'] [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
													$SPECIES1 ['lastyear'] ['ANOPHELES'] [$i] ['ttlmosq'] += $row1->ttlmosq;
													$SPECIES1 ['lastyear'] ['ANOPHELES'] [$i] ['malecount'] += $row1->malecount;
													$SPECIES1 ['lastyear'] ['ANOPHELES'] [$i] ['femalecount'] += $row1->femalecount;
													$flg = 1;
													break;
												}
											}
											if ($flg == 0) {
												$c = count ( $SPECIES1 ['lastyear'] ['ANOPHELES'] ) - 1;
												$SPECIES1 ['lastyear'] ['ANOPHELES'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
												$SPECIES1 ['lastyear'] ['ANOPHELES'] [$c + 1] ['malecount'] = $row1->malecount;
												$SPECIES1 ['lastyear'] ['ANOPHELES'] [$c + 1] ['femalecount'] = $row1->femalecount;
												$SPECIES1 ['lastyear'] ['ANOPHELES'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
											}
										} else {
											$c = - 1;
											$SPECIES1 ['lastyear'] ['ANOPHELES'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$SPECIES1 ['lastyear'] ['ANOPHELES'] [$c + 1] ['malecount'] = $row1->malecount;
											$SPECIES1 ['lastyear'] ['ANOPHELES'] [$c + 1] ['femalecount'] = $row1->femalecount;
											$SPECIES1 ['lastyear'] ['ANOPHELES'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									}
									break;
								case 'CULISETA' :
									$flg = 0;
									if (! empty ( $data_2 ['CULISETA'] )) {
										foreach ( $data_2 ['CULISETA'] as $key => $val ) {
											if ($val->mosquitospecies == $row1->mosquitospecies) {
												$val->ttlmosq += $row1->ttlmosq;
												$val->malecount += $row1->malecount;
												$val->femalecount += $row1->femalecount;
												$flg = 1;
											}
										}
										if ($flg == 0) {
											$data_2 ['CULISETA'] [] = $row1;
										}
									} else
										$data_2 ['CULISETA'] [] = $row1;
									
									if ($row->setdate >= $thisweek && $row->pudate <= $currdate) {
										$flg = 0;
										if (! empty ( $SPECIES1 ['thisweek'] ['CULISETA'] )) {
											for($i = 0; $i < count ( $SPECIES1 ['thisweek'] ['CULISETA'] ); $i ++) {
												if ($SPECIES1 ['thisweek'] ['CULISETA'] [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
													$SPECIES1 ['thisweek'] ['CULISETA'] [$i] ['ttlmosq'] += $row1->ttlmosq;
													$SPECIES1 ['thisweek'] ['CULISETA'] [$i] ['malecount'] += $row1->malecount;
													$SPECIES1 ['thisweek'] ['CULISETA'] [$i] ['femalecount'] += $row1->femalecount;
													$flg = 1;
													break;
												}
											}
											if ($flg == 0) {
												$c = count ( $SPECIES1 ['thisweek'] ['CULISETA'] ) - 1;
												$SPECIES1 ['thisweek'] ['CULISETA'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
												$SPECIES1 ['thisweek'] ['CULISETA'] [$c + 1] ['malecount'] = $row1->malecount;
												$SPECIES1 ['thisweek'] ['CULISETA'] [$c + 1] ['femalecount'] = $row1->femalecount;
												$SPECIES1 ['thisweek'] ['CULISETA'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
											}
										} else {
											$c = - 1;
											$SPECIES1 ['thisweek'] ['CULISETA'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$SPECIES1 ['thisweek'] ['CULISETA'] [$c + 1] ['malecount'] = $row1->malecount;
											$SPECIES1 ['thisweek'] ['CULISETA'] [$c + 1] ['femalecount'] = $row1->femalecount;
											$SPECIES1 ['thisweek'] ['CULISETA'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									}
									
									if ($row->setdate >= $lastweek && $row->pudate < $thisweek) {
										$flg = 0;
										if (! empty ( $SPECIES1 ['lastweek'] ['CULISETA'] )) {
											for($i = 0; $i < count ( $SPECIES1 ['lastweek'] ['CULISETA'] ); $i ++) {
												if ($SPECIES1 ['lastweek'] ['CULISETA'] [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
													$SPECIES1 ['lastweek'] ['CULISETA'] [$i] ['ttlmosq'] += $row1->ttlmosq;
													$SPECIES1 ['lastweek'] ['CULISETA'] [$i] ['malecount'] += $row1->malecount;
													$SPECIES1 ['lastweek'] ['CULISETA'] [$i] ['femalecount'] += $row1->femalecount;
													$flg = 1;
													break;
												}
											}
											if ($flg == 0) {
												$c = count ( $SPECIES1 ['lastweek'] ['CULISETA'] ) - 1;
												$SPECIES1 ['lastweek'] ['CULISETA'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
												$SPECIES1 ['lastweek'] ['CULISETA'] [$c + 1] ['malecount'] = $row1->malecount;
												$SPECIES1 ['lastweek'] ['CULISETA'] [$c + 1] ['femalecount'] = $row1->femalecount;
												$SPECIES1 ['lastweek'] ['CULISETA'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
											}
										} else {
											$c = - 1;
											$SPECIES1 ['lastweek'] ['CULISETA'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$SPECIES1 ['lastweek'] ['CULISETA'] [$c + 1] ['malecount'] = $row1->malecount;
											$SPECIES1 ['lastweek'] ['CULISETA'] [$c + 1] ['femalecount'] = $row1->femalecount;
											$SPECIES1 ['lastweek'] ['CULISETA'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									}
									
									$flg = 0;
									if (! empty ( $CULISETA )) {
										for($i = 0; $i < count ( $CULISETA ); $i ++) {
											if ($CULISETA [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
												$CULISETA [$i] ['ttlmosq'] = $row1->ttlmosq;
												$CULISETA [$i] ['malecount'] = $row1->malecount;
												$CULISETA [$i] ['femalecount'] = $row1->femalecount;
												$CULISETA [$i] ['mosquitospecies'] = $row1->mosquitospecies;
												$flg = 1;
											}
										}
										if ($flg == 0) {
											$c = count ( $CULISETA ) - 1;
											$CULISETA [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$CULISETA [$c + 1] ['malecount'] = $row1->malecount;
											$CULISETA [$c + 1] ['femalecount'] = $row1->femalecount;
											$CULISETA [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									} else {
										$c = - 1;
										$CULISETA [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
										$CULISETA [$c + 1] ['malecount'] = $row1->malecount;
										$CULISETA [$c + 1] ['femalecount'] = $row1->femalecount;
										$CULISETA [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
									}
									
									if ($row->setdate >= $lastdate && $row->pudate <= $currdate) {
										$flg = 0;
										if (! empty ( $SPECIES1 ['lastyear'] ['CULISETA'] )) {
											for($i = 0; $i < count ( $SPECIES1 ['lastyear'] ['CULISETA'] ); $i ++) {
												if ($SPECIES1 ['lastyear'] ['CULISETA'] [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
													$SPECIES1 ['lastyear'] ['CULISETA'] [$i] ['ttlmosq'] += $row1->ttlmosq;
													$SPECIES1 ['lastyear'] ['CULISETA'] [$i] ['malecount'] += $row1->malecount;
													$SPECIES1 ['lastyear'] ['CULISETA'] [$i] ['femalecount'] += $row1->femalecount;
													$flg = 1;
													break;
												}
											}
											if ($flg == 0) {
												$c = count ( $SPECIES1 ['lastyear'] ['CULISETA'] ) - 1;
												$SPECIES1 ['lastyear'] ['CULISETA'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
												$SPECIES1 ['lastyear'] ['CULISETA'] [$c + 1] ['malecount'] = $row1->malecount;
												$SPECIES1 ['lastyear'] ['CULISETA'] [$c + 1] ['femalecount'] = $row1->femalecount;
												$SPECIES1 ['lastyear'] ['CULISETA'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
											}
										} else {
											$c = - 1;
											$SPECIES1 ['lastyear'] ['CULISETA'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$SPECIES1 ['lastyear'] ['CULISETA'] [$c + 1] ['malecount'] = $row1->malecount;
											$SPECIES1 ['lastyear'] ['CULISETA'] [$c + 1] ['femalecount'] = $row1->femalecount;
											$SPECIES1 ['lastyear'] ['CULISETA'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									}
									break;
								case 'AEDES' :
									$flg = 0;
									if (! empty ( $data_2 ['AEDES'] )) {
										foreach ( $data_2 ['AEDES'] as $key => $val ) {
											if ($val->mosquitospecies == $row1->mosquitospecies) {
												$val->ttlmosq += $row1->ttlmosq;
												$val->malecount += $row1->malecount;
												$val->femalecount += $row1->femalecount;
												$flg = 1;
											}
										}
										if ($flg == 0) {
											$data_2 ['AEDES'] [] = $row1;
										}
									} else
										$data_2 ['AEDES'] [] = $row1;
									
									if ($row->setdate >= $thisweek && $row->pudate <= $currdate) {
										$flg = 0;
										if (! empty ( $SPECIES1 ['thisweek'] ['AEDES'] )) {
											for($i = 0; $i < count ( $SPECIES1 ['thisweek'] ['AEDES'] ); $i ++) {
												if ($SPECIES1 ['thisweek'] ['AEDES'] [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
													$SPECIES1 ['thisweek'] ['AEDES'] [$i] ['ttlmosq'] += $row1->ttlmosq;
													$SPECIES1 ['thisweek'] ['AEDES'] [$i] ['malecount'] += $row1->malecount;
													$SPECIES1 ['thisweek'] ['AEDES'] [$i] ['femalecount'] += $row1->femalecount;
													$flg = 1;
													break;
												}
											}
											if ($flg == 0) {
												$c = count ( $SPECIES1 ['thisweek'] ['AEDES'] ) - 1;
												$SPECIES1 ['thisweek'] ['AEDES'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
												$SPECIES1 ['thisweek'] ['AEDES'] [$c + 1] ['malecount'] = $row1->malecount;
												$SPECIES1 ['thisweek'] ['AEDES'] [$c + 1] ['femalecount'] = $row1->femalecount;
												$SPECIES1 ['thisweek'] ['AEDES'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
											}
										} else {
											$c = - 1;
											$SPECIES1 ['thisweek'] ['AEDES'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$SPECIES1 ['thisweek'] ['AEDES'] [$c + 1] ['malecount'] = $row1->malecount;
											$SPECIES1 ['thisweek'] ['AEDES'] [$c + 1] ['femalecount'] = $row1->femalecount;
											$SPECIES1 ['thisweek'] ['AEDES'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									}
									
									// print('<pre>');
									// print_r($SPECIES1['thisweek']['AEDES']);
									if ($row->setdate >= $lastweek && $row->pudate < $thisweek) {
										$flg = 0;
										if (! empty ( $SPECIES1 ['lastweek'] ['AEDES'] )) {
											for($i = 0; $i < count ( $SPECIES1 ['lastweek'] ['AEDES'] ); $i ++) {
												if ($SPECIES1 ['lastweek'] ['AEDES'] [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
													$SPECIES1 ['lastweek'] ['AEDES'] [$i] ['ttlmosq'] += $row1->ttlmosq;
													$SPECIES1 ['lastweek'] ['AEDES'] [$i] ['malecount'] += $row1->malecount;
													$SPECIES1 ['lastweek'] ['AEDES'] [$i] ['femalecount'] += $row1->femalecount;
													$flg = 1;
													break;
												}
											}
											if ($flg == 0) {
												if (isset ( $SPECIES1 ['lastweek'] ['CULEX'] )) {
													$c = count ( $SPECIES1 ['lastweek'] ['CULEX'] ) - 1;
													$SPECIES1 ['lastweek'] ['AEDES'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
													$SPECIES1 ['lastweek'] ['AEDES'] [$c + 1] ['malecount'] = $row1->malecount;
													$SPECIES1 ['lastweek'] ['AEDES'] [$c + 1] ['femalecount'] = $row1->femalecount;
													$SPECIES1 ['lastweek'] ['AEDES'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
												}
											}
										} else {
											$c = - 1;
											$SPECIES1 ['lastweek'] ['AEDES'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$SPECIES1 ['lastweek'] ['AEDES'] [$c + 1] ['malecount'] = $row1->malecount;
											$SPECIES1 ['lastweek'] ['AEDES'] [$c + 1] ['femalecount'] = $row1->femalecount;
											$SPECIES1 ['lastweek'] ['AEDES'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									}
									
									$flg = 0;
									if (! empty ( $AEDES )) {
										for($i = 0; $i < count ( $AEDES ); $i ++) {
											if ($AEDES [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
												$AEDES [$i] ['ttlmosq'] = $row1->ttlmosq;
												$AEDES [$i] ['malecount'] = $row1->malecount;
												$AEDES [$i] ['femalecount'] = $row1->femalecount;
												$AEDES [$i] ['mosquitospecies'] = $row1->mosquitospecies;
												$flg = 1;
												break;
											}
										}
										if ($flg == 0) {
											$c = count ( $AEDES ) - 1;
											$AEDES [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$AEDES [$c + 1] ['malecount'] = $row1->malecount;
											$AEDES [$c + 1] ['femalecount'] = $row1->femalecount;
											$AEDES [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									} else {
										$c = - 1;
										$AEDES [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
										$AEDES [$c + 1] ['malecount'] = $row1->malecount;
										$AEDES [$c + 1] ['femalecount'] = $row1->femalecount;
										$AEDES [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
									}
									
									if ($row->setdate >= $lastdate && $row->pudate <= $currdate) {
										$flg = 0;
										if (! empty ( $SPECIES1 ['lastyear'] ['AEDES'] )) {
											for($i = 0; $i < count ( $SPECIES1 ['lastyear'] ['AEDES'] ); $i ++) {
												if ($SPECIES1 ['lastyear'] ['AEDES'] [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
													$SPECIES1 ['lastyear'] ['AEDES'] [$i] ['ttlmosq'] += $row1->ttlmosq;
													$SPECIES1 ['lastyear'] ['AEDES'] [$i] ['malecount'] += $row1->malecount;
													$SPECIES1 ['lastyear'] ['AEDES'] [$i] ['femalecount'] += $row1->femalecount;
													$flg = 1;
													break;
												}
											}
											if ($flg == 0) {
												$c = count ( $SPECIES1 ['lastyear'] ['AEDES'] ) - 1;
												$SPECIES1 ['lastyear'] ['AEDES'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
												$SPECIES1 ['lastyear'] ['AEDES'] [$c + 1] ['malecount'] = $row1->malecount;
												$SPECIES1 ['lastyear'] ['AEDES'] [$c + 1] ['femalecount'] = $row1->femalecount;
												$SPECIES1 ['lastyear'] ['AEDES'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
											}
										} else {
											$c = - 1;
											$SPECIES1 ['lastyear'] ['AEDES'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$SPECIES1 ['lastyear'] ['AEDES'] [$c + 1] ['malecount'] = $row1->malecount;
											$SPECIES1 ['lastyear'] ['AEDES'] [$c + 1] ['femalecount'] = $row1->femalecount;
											$SPECIES1 ['lastyear'] ['AEDES'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									}
									break;
								case 'OTHER' :
									$flg = 0;
									if (! empty ( $data_2 ['OTHER SPECIES'] )) {
										foreach ( $data_2 ['OTHER SPECIES'] as $key => $val ) {
											if ($val->mosquitospecies == $row1->mosquitospecies) {
												$val->ttlmosq += $row1->ttlmosq;
												$val->malecount += $row1->malecount;
												$val->femalecount += $row1->femalecount;
												$flg = 1;
											}
										}
										if ($flg == 0) {
											$data_2 ['OTHER SPECIES'] [] = $row1;
										}
									} else
										$data_2 ['OTHER SPECIES'] [] = $row1;
									
									if ($row->setdate >= $thisweek && $row->pudate <= $currdate) {
										$flg = 0;
										if (! empty ( $SPECIES1 ['thisweek'] ['OTHER SPECIES'] )) {
											for($i = 0; $i < count ( $SPECIES1 ['thisweek'] ['OTHER SPECIES'] ); $i ++) {
												if ($SPECIES1 ['thisweek'] ['OTHER SPECIES'] [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
													$SPECIES1 ['thisweek'] ['OTHER SPECIES'] [$i] ['ttlmosq'] += $row1->ttlmosq;
													$SPECIES1 ['thisweek'] ['OTHER SPECIES'] [$i] ['malecount'] += $row1->malecount;
													$SPECIES1 ['thisweek'] ['OTHER SPECIES'] [$i] ['femalecount'] += $row1->femalecount;
													$flg = 1;
													break;
												}
											}
											if ($flg == 0) {
												$c = count ( $SPECIES1 ['thisweek'] ['OTHER SPECIES'] ) - 1;
												$SPECIES1 ['thisweek'] ['OTHER SPECIES'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
												$SPECIES1 ['thisweek'] ['OTHER SPECIES'] [$c + 1] ['malecount'] = $row1->malecount;
												$SPECIES1 ['thisweek'] ['OTHER SPECIES'] [$c + 1] ['femalecount'] = $row1->femalecount;
												$SPECIES1 ['thisweek'] ['OTHER SPECIES'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
											}
										} else {
											$c = - 1;
											$SPECIES1 ['thisweek'] ['OTHER SPECIES'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$SPECIES1 ['thisweek'] ['OTHER SPECIES'] [$c + 1] ['malecount'] = $row1->malecount;
											$SPECIES1 ['thisweek'] ['OTHER SPECIES'] [$c + 1] ['femalecount'] = $row1->femalecount;
											$SPECIES1 ['thisweek'] ['OTHER SPECIES'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									}
									
									if ($row->setdate >= $lastweek && $row->pudate < $thisweek) {
										$flg = 0;
										if (! empty ( $SPECIES1 ['lastweek'] ['OTHER SPECIES'] )) {
											for($i = 0; $i < count ( $SPECIES1 ['lastweek'] ['OTHER SPECIES'] ); $i ++) {
												if ($SPECIES1 ['lastweek'] ['OTHER SPECIES'] [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
													$SPECIES1 ['lastweek'] ['OTHER SPECIES'] [$i] ['ttlmosq'] += $row1->ttlmosq;
													$SPECIES1 ['lastweek'] ['OTHER SPECIES'] [$i] ['malecount'] += $row1->malecount;
													$SPECIES1 ['lastweek'] ['OTHER SPECIES'] [$i] ['femalecount'] += $row1->femalecount;
													$flg = 1;
													break;
												}
											}
											if ($flg == 0) {
												$c = count ( $SPECIES1 ['lastweek'] ['CULEX'] ) - 1;
												$SPECIES1 ['lastweek'] ['OTHER SPECIES'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
												$SPECIES1 ['lastweek'] ['OTHER SPECIES'] [$c + 1] ['malecount'] = $row1->malecount;
												$SPECIES1 ['lastweek'] ['OTHER SPECIES'] [$c + 1] ['femalecount'] = $row1->femalecount;
												$SPECIES1 ['lastweek'] ['OTHER SPECIES'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
											}
										} else {
											$c = - 1;
											$SPECIES1 ['lastweek'] ['OTHER SPECIES'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$SPECIES1 ['lastweek'] ['OTHER SPECIES'] [$c + 1] ['malecount'] = $row1->malecount;
											$SPECIES1 ['lastweek'] ['OTHER SPECIES'] [$c + 1] ['femalecount'] = $row1->femalecount;
											$SPECIES1 ['lastweek'] ['OTHER SPECIES'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									}
									
									$flg = 0;
									if (! empty ( $OTHER_SPECIES )) {
										for($i = 0; $i < count ( $OTHER_SPECIES ); $i ++) {
											if ($OTHER_SPECIES [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
												$OTHER_SPECIES [$i] ['ttlmosq'] = $row1->ttlmosq;
												$OTHER_SPECIES [$i] ['malecount'] = $row1->malecount;
												$OTHER_SPECIES [$i] ['femalecount'] = $row1->femalecount;
												$OTHER_SPECIES [$i] ['mosquitospecies'] = $row1->mosquitospecies;
												$flg = 1;
												break;
											}
										}
										if ($flg == 0) {
											$c = count ( $OTHER_SPECIES ) - 1;
											$OTHER_SPECIES [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$OTHER_SPECIES [$c + 1] ['malecount'] = $row1->malecount;
											$OTHER_SPECIES [$c + 1] ['femalecount'] = $row1->femalecount;
											$OTHER_SPECIES [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									} else {
										$c = - 1;
										$OTHER_SPECIES [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
										$OTHER_SPECIES [$c + 1] ['malecount'] = $row1->malecount;
										$OTHER_SPECIES [$c + 1] ['femalecount'] = $row1->femalecount;
										$OTHER_SPECIES [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
									}
									
									if ($row->setdate >= $lastdate && $row->pudate <= $currdate) {
										$flg = 0;
										if (! empty ( $SPECIES1 ['lastyear'] ['OTHER SPECIES'] )) {
											for($i = 0; $i < count ( $SPECIES1 ['lastyear'] ['OTHER SPECIES'] ); $i ++) {
												if ($SPECIES1 ['lastyear'] ['OTHER SPECIES'] [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
													$SPECIES1 ['lastyear'] ['OTHER SPECIES'] [$i] ['ttlmosq'] += $row1->ttlmosq;
													$SPECIES1 ['lastyear'] ['OTHER SPECIES'] [$i] ['malecount'] += $row1->malecount;
													$SPECIES1 ['lastyear'] ['OTHER SPECIES'] [$i] ['femalecount'] += $row1->femalecount;
													$flg = 1;
													break;
												}
											}
											if ($flg == 0) {
												$c = count ( $SPECIES1 ['lastyear'] ['OTHER SPECIES'] ) - 1;
												$SPECIES1 ['lastyear'] ['OTHER SPECIES'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
												$SPECIES1 ['lastyear'] ['OTHER SPECIES'] [$c + 1] ['malecount'] = $row1->malecount;
												$SPECIES1 ['lastyear'] ['OTHER SPECIES'] [$c + 1] ['femalecount'] = $row1->femalecount;
												$SPECIES1 ['lastyear'] ['OTHER SPECIES'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
											}
										} else {
											$c = - 1;
											$SPECIES1 ['lastyear'] ['OTHER SPECIES'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$SPECIES1 ['lastyear'] ['OTHER SPECIES'] [$c + 1] ['malecount'] = $row1->malecount;
											$SPECIES1 ['lastyear'] ['OTHER SPECIES'] [$c + 1] ['femalecount'] = $row1->femalecount;
											$SPECIES1 ['lastyear'] ['OTHER SPECIES'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									}
									
									break;
								case 'UNSPECIATED' :
									$flg = 0;
									if (! empty ( $data_2 ['UNSPECIATED'] )) {
										foreach ( $data_2 ['UNSPECIATED'] as $key => $val ) {
											if ($val->mosquitospecies == $row1->mosquitospecies) {
												$val->ttlmosq += $row1->ttlmosq;
												$val->malecount += $row1->malecount;
												$val->femalecount += $row1->femalecount;
												$flg = 1;
											}
										}
										if ($flg == 0) {
											$data_2 ['UNSPECIATED'] [] = $row1;
										}
									} else
										$data_2 ['UNSPECIATED'] [] = $row1;
									
									if ($row->setdate >= $thisweek && $row->pudate <= $currdate) {
										$flg = 0;
										if (! empty ( $SPECIES1 ['thisweek'] ['UNSPECIATED'] )) {
											for($i = 0; $i < count ( $SPECIES1 ['thisweek'] ['UNSPECIATED'] ); $i ++) {
												if ($SPECIES1 ['thisweek'] ['UNSPECIATED'] [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
													$SPECIES1 ['thisweek'] ['UNSPECIATED'] [$i] ['ttlmosq'] += $row1->ttlmosq;
													$SPECIES1 ['thisweek'] ['UNSPECIATED'] [$i] ['malecount'] += $row1->malecount;
													$SPECIES1 ['thisweek'] ['UNSPECIATED'] [$i] ['femalecount'] += $row1->femalecount;
													$flg = 1;
													break;
												}
											}
											if ($flg == 0) {
												$c = count ( $SPECIES1 ['thisweek'] ['UNSPECIATED'] ) - 1;
												$SPECIES1 ['thisweek'] ['UNSPECIATED'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
												$SPECIES1 ['thisweek'] ['UNSPECIATED'] [$c + 1] ['malecount'] = $row1->malecount;
												$SPECIES1 ['thisweek'] ['UNSPECIATED'] [$c + 1] ['femalecount'] = $row1->femalecount;
												$SPECIES1 ['thisweek'] ['UNSPECIATED'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
											}
										} else {
											$c = - 1;
											$SPECIES1 ['thisweek'] ['UNSPECIATED'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$SPECIES1 ['thisweek'] ['UNSPECIATED'] [$c + 1] ['malecount'] = $row1->malecount;
											$SPECIES1 ['thisweek'] ['UNSPECIATED'] [$c + 1] ['femalecount'] = $row1->femalecount;
											$SPECIES1 ['thisweek'] ['UNSPECIATED'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									}
									
									if ($row->setdate >= $lastweek && $row->pudate < $thisweek) {
										$flg = 0;
										if (! empty ( $SPECIES1 ['lastweek'] ['UNSPECIATED'] )) {
											for($i = 0; $i < count ( $SPECIES1 ['lastweek'] ['UNSPECIATED'] ); $i ++) {
												if ($SPECIES1 ['lastweek'] ['UNSPECIATED'] [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
													$SPECIES1 ['lastweek'] ['UNSPECIATED'] [$i] ['ttlmosq'] += $row1->ttlmosq;
													$SPECIES1 ['lastweek'] ['UNSPECIATED'] [$i] ['malecount'] += $row1->malecount;
													$SPECIES1 ['lastweek'] ['UNSPECIATED'] [$i] ['femalecount'] += $row1->femalecount;
													$flg = 1;
													break;
												}
											}
											if ($flg == 0) {
												$c = count ( $SPECIES1 ['lastweek'] ['CULEX'] ) - 1;
												$SPECIES1 ['lastweek'] ['UNSPECIATED'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
												$SPECIES1 ['lastweek'] ['UNSPECIATED'] [$c + 1] ['malecount'] = $row1->malecount;
												$SPECIES1 ['lastweek'] ['UNSPECIATED'] [$c + 1] ['femalecount'] = $row1->femalecount;
												$SPECIES1 ['lastweek'] ['UNSPECIATED'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
											}
										} else {
											$c = - 1;
											$SPECIES1 ['lastweek'] ['UNSPECIATED'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$SPECIES1 ['lastweek'] ['UNSPECIATED'] [$c + 1] ['malecount'] = $row1->malecount;
											$SPECIES1 ['lastweek'] ['UNSPECIATED'] [$c + 1] ['femalecount'] = $row1->femalecount;
											$SPECIES1 ['lastweek'] ['UNSPECIATED'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									}
									
									$flg = 0;
									if (! empty ( $UNSPECIATED )) {
										for($i = 0; $i < count ( $UNSPECIATED ); $i ++) {
											if ($UNSPECIATED [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
												$UNSPECIATED [$i] ['ttlmosq'] = $row1->ttlmosq;
												$UNSPECIATED [$i] ['malecount'] = $row1->malecount;
												$UNSPECIATED [$i] ['femalecount'] = $row1->femalecount;
												$UNSPECIATED [$i] ['mosquitospecies'] = $row1->mosquitospecies;
												$flg = 1;
												break;
											}
										}
										if ($flg == 0) {
											$c = count ( $UNSPECIATED ) - 1;
											$UNSPECIATED [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$UNSPECIATED [$c + 1] ['malecount'] = $row1->malecount;
											$UNSPECIATED [$c + 1] ['femalecount'] = $row1->femalecount;
											$UNSPECIATED [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									} else {
										$c = - 1;
										$UNSPECIATED [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
										$UNSPECIATED [$c + 1] ['malecount'] = $row1->malecount;
										$UNSPECIATED [$c + 1] ['femalecount'] = $row1->femalecount;
										$UNSPECIATED [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
									}
									
									if ($row->setdate >= $lastdate && $row->pudate <= $currdate) {
										$flg = 0;
										if (! empty ( $SPECIES1 ['lastyear'] ['UNSPECIATED'] )) {
											for($i = 0; $i < count ( $SPECIES1 ['lastyear'] ['UNSPECIATED'] ); $i ++) {
												if ($SPECIES1 ['lastyear'] ['UNSPECIATED'] [$i] ['mosquitospecies'] == $row1->mosquitospecies) {
													$SPECIES1 ['lastyear'] ['UNSPECIATED'] [$i] ['ttlmosq'] += $row1->ttlmosq;
													$SPECIES1 ['lastyear'] ['UNSPECIATED'] [$i] ['malecount'] += $row1->malecount;
													$SPECIES1 ['lastyear'] ['UNSPECIATED'] [$i] ['femalecount'] += $row1->femalecount;
													$flg = 1;
													break;
												}
											}
											if ($flg == 0) {
												$c = count ( $SPECIES1 ['lastyear'] ['UNSPECIATED'] ) - 1;
												$SPECIES1 ['lastyear'] ['UNSPECIATED'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
												$SPECIES1 ['lastyear'] ['UNSPECIATED'] [$c + 1] ['malecount'] = $row1->malecount;
												$SPECIES1 ['lastyear'] ['UNSPECIATED'] [$c + 1] ['femalecount'] = $row1->femalecount;
												$SPECIES1 ['lastyear'] ['UNSPECIATED'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
											}
										} else {
											$c = - 1;
											$SPECIES1 ['lastyear'] ['UNSPECIATED'] [$c + 1] ['ttlmosq'] = $row1->ttlmosq;
											$SPECIES1 ['lastyear'] ['UNSPECIATED'] [$c + 1] ['malecount'] = $row1->malecount;
											$SPECIES1 ['lastyear'] ['UNSPECIATED'] [$c + 1] ['femalecount'] = $row1->femalecount;
											$SPECIES1 ['lastyear'] ['UNSPECIATED'] [$c + 1] ['mosquitospecies'] = $row1->mosquitospecies;
										}
									}
									break;
							}
					}
				}
				$query1->next_result ();
				$query1->free_result ();
				// print'<pre>';
				// echo "<br>========== Outer Loop==============<br>";
				// print_r($SPECIES1['thisweek']['CULISETA']);
				if ($tempsite == $row->site) {
					$trapnight += $row->trapnight;
					$row->trapnight = $trapnight;
					
					$query1 = $this->db->query ( "CALL sp_light_trap_mosq(" . intval ( $row->idadultsurveillance ) . ");" );
					// echo $query1 -> num_rows()."<br>";
					if ($query1->num_rows () > 0) {
						foreach ( $query1->result () as $row1 ) {
							if (! empty ( $row1->genus ))
								switch (strtoupper ( $row1->genus )) {
									case 'CULEX' :
										$flg = 0;
										if (! empty ( $species [0] ['CULEX'] )) {
											foreach ( $species [0] ['CULEX'] as $key => $val ) {
												if ($val->mosquitospecies == $row1->mosquitospecies) {
													$val->ttlmosq += $row1->ttlmosq;
													$val->malecount += $row1->malecount;
													$val->femalecount += $row1->femalecount;
													$flg = 1;
												}
											}
											if ($flg == 0) {
												$species [0] ['CULEX'] [] = $row1;
											}
										} else
											$species [0] ['CULEX'] [] = $row1;
										break;
									case 'ANOPHELES' :
										$flg = 0;
										if (! empty ( $species [0] ['ANOPHELES'] )) {
											foreach ( $species [0] ['ANOPHELES'] as $key => $val ) {
												if ($val->mosquitospecies == $row1->mosquitospecies) {
													$val->ttlmosq += $row1->ttlmosq;
													$val->malecount += $row1->malecount;
													$val->femalecount += $row1->femalecount;
													$flg = 1;
												}
											}
											if ($flg == 0) {
												$species [0] ['ANOPHELES'] [] = $row1;
											}
										} else
											$species [0] ['ANOPHELES'] [] = $row1;
										break;
									case 'CULISETA' :
										$flg = 0;
										if (! empty ( $species [0] ['CULISETA'] )) {
											foreach ( $species [0] ['CULISETA'] as $key => $val ) {
												if ($val->mosquitospecies == $row1->mosquitospecies) {
													$val->ttlmosq += $row1->ttlmosq;
													$val->malecount += $row1->malecount;
													$val->femalecount += $row1->femalecount;
													$flg = 1;
												}
											}
											if ($flg == 0) {
												$species [0] ['CULISETA'] [] = $row1;
											}
										} else
											$species [0] ['CULISETA'] [] = $row1;
										break;
									case 'AEDES' :
										$flg = 0;
										if (! empty ( $species [0] ['AEDES'] )) {
											foreach ( $species [0] ['AEDES'] as $key => $val ) {
												if ($val->mosquitospecies == $row1->mosquitospecies) {
													$val->ttlmosq += $row1->ttlmosq;
													$val->malecount += $row1->malecount;
													$val->femalecount += $row1->femalecount;
													$flg = 1;
												}
											}
											if ($flg == 0) {
												$species [0] ['AEDES'] [] = $row1;
											}
										} else
											$species [0] ['AEDES'] [] = $row1;
										break;
									case 'OTHER' :
										$flg = 0;
										if (! empty ( $species [0] ['OTHER SPECIES'] )) {
											foreach ( $species [0] ['OTHER SPECIES'] as $key => $val ) {
												if ($val->mosquitospecies == $row1->mosquitospecies) {
													$val->ttlmosq += $row1->ttlmosq;
													$val->malecount += $row1->malecount;
													$val->femalecount += $row1->femalecount;
													$flg = 1;
												}
											}
											if ($flg == 0) {
												$species [0] ['OTHER SPECIES'] [] = $row1;
											}
										} else
											$species [0] ['OTHER SPECIES'] [] = $row1;
										break;
									case 'UNSPECIATED' :
										$flg = 0;
										if (! empty ( $species [0] ['UNSPECIATED'] )) {
											foreach ( $species [0] ['UNSPECIATED'] as $key => $val ) {
												if ($val->mosquitospecies == $row1->mosquitospecies) {
													$val->ttlmosq += $row1->ttlmosq;
													$val->malecount += $row1->malecount;
													$val->femalecount += $row1->femalecount;
													$flg = 1;
												}
											}
											if ($flg == 0) {
												$species [0] ['UNSPECIATED'] [] = $row1;
											}
										} else
											$species [0] ['UNSPECIATED'] [] = $row1;
										break;
								}
						}
					}
					$query1->next_result ();
					$query1->free_result ();
				} else {
					$i ++;
					$trapnight = $row->trapnight;
					$species = array ();
					$query1 = $this->db->query ( "CALL sp_light_trap_mosq(" . intval ( $row->idadultsurveillance ) . ");" );
					// echo $query1 -> num_rows()."<br>";
					if ($query1->num_rows () > 0) {
						foreach ( $query1->result () as $row1 ) {
							if (! empty ( $row1->genus ))
								switch (strtoupper ( $row1->genus )) {
									case 'CULEX' :
										$flg = 0;
										if (! empty ( $species [0] ['CULEX'] )) {
											foreach ( $species [0] ['CULEX'] as $key => $val ) {
												if ($val->mosquitospecies == $row1->mosquitospecies) {
													$val->ttlmosq += $row1->ttlmosq;
													$val->malecount += $row1->malecount;
													$val->femalecount += $row1->femalecount;
													$flg = 1;
												}
											}
											if ($flg == 0) {
												$species [0] ['CULEX'] [] = $row1;
											}
										} else
											$species [0] ['CULEX'] [] = $row1;
										break;
									case 'ANOPHELES' :
										$flg = 0;
										if (! empty ( $species [0] ['ANOPHELES'] )) {
											foreach ( $species [0] ['ANOPHELES'] as $key => $val ) {
												if ($val->mosquitospecies == $row1->mosquitospecies) {
													$val->ttlmosq += $row1->ttlmosq;
													$val->malecount += $row1->malecount;
													$val->femalecount += $row1->femalecount;
													$flg = 1;
												}
											}
											if ($flg == 0) {
												$species [0] ['ANOPHELES'] [] = $row1;
											}
										} else
											$species [0] ['ANOPHELES'] [] = $row1;
										break;
									case 'CULISETA' :
										$flg = 0;
										if (! empty ( $species [0] ['CULISETA'] )) {
											foreach ( $species [0] ['CULISETA'] as $key => $val ) {
												if ($val->mosquitospecies == $row1->mosquitospecies) {
													$val->ttlmosq += $row1->ttlmosq;
													$val->malecount += $row1->malecount;
													$val->femalecount += $row1->femalecount;
													$flg = 1;
												}
											}
											if ($flg == 0) {
												$species [0] ['CULISETA'] [] = $row1;
											}
										} else
											$species [0] ['CULISETA'] [] = $row1;
										break;
									case 'AEDES' :
										$flg = 0;
										if (! empty ( $species [0] ['AEDES'] )) {
											foreach ( $species [0] ['AEDES'] as $key => $val ) {
												if ($val->mosquitospecies == $row1->mosquitospecies) {
													$val->ttlmosq += $row1->ttlmosq;
													$val->malecount += $row1->malecount;
													$val->femalecount += $row1->femalecount;
													$flg = 1;
												}
											}
											if ($flg == 0) {
												$species [0] ['AEDES'] [] = $row1;
											}
										} else
											$species [0] ['AEDES'] [] = $row1;
										break;
									case 'OTHER' :
										$flg = 0;
										if (! empty ( $species [0] ['OTHER SPECIES'] )) {
											foreach ( $species [0] ['OTHER SPECIES'] as $key => $val ) {
												if ($val->mosquitospecies == $row1->mosquitospecies) {
													$val->ttlmosq += $row1->ttlmosq;
													$val->malecount += $row1->malecount;
													$val->femalecount += $row1->femalecount;
													$flg = 1;
												}
											}
											if ($flg == 0) {
												$species [0] ['OTHER SPECIES'] [] = $row1;
											}
										} else
											$species [0] ['OTHER SPECIES'] [] = $row1;
										break;
									case 'UNSPECIATED' :
										$flg = 0;
										if (! empty ( $species [0] ['UNSPECIATED'] )) {
											foreach ( $species [0] ['UNSPECIATED'] as $key => $val ) {
												if ($val->mosquitospecies == $row1->mosquitospecies) {
													$val->ttlmosq += $row1->ttlmosq;
													$val->malecount += $row1->malecount;
													$val->femalecount += $row1->femalecount;
													$flg = 1;
												}
											}
											if ($flg == 0) {
												$species [0] ['UNSPECIATED'] [] = $row1;
											}
										} else
											$species [0] ['UNSPECIATED'] [] = $row1;
										break;
								}
						}
					}
					$query1->next_result ();
					$query1->free_result ();
				}
				
				$trow = $row;
				$trow->species = $species;
				// print'<pre>';
				// print_r($species);
				if ($row->setdate >= $startdate && $row->pudate <= $enddate)
					$data_1 [$row->site] = $trow;
				
				if (! empty ( $row->site ))
					$tempsite = $row->site;
					// echo "Nite run ".$row->trapnight."<br>";
				if ($row->setdate >= $thisweek && $row->pudate <= $currdate) {
					$thisweek_trapcount += 1;
					if ($row->trapnight > 0)
						$thisweek_niterun += $row->trapnight;
						// echo " thisweek_niterun ".$thisweek_niterun."<br>";
					$data_l1 ['thisweek'] ['trapcount'] = $thisweek_trapcount;
					$data_l1 ['thisweek'] ['niterun'] = $thisweek_niterun;
				}
				
				if ($row->setdate > $lastweek && $row->pudate <= $thisweek) {
					$lastweek_trapcount += 1;
					if ($row->trapnight > 0)
						$lastweek_niterun += $row->trapnight;
					$data_l1 ['lastweek'] ['trapcount'] = $lastweek_trapcount;
					// echo " lastweek_niterun ".$lastweek_niterun."<br>";
					$data_l1 ['lastweek'] ['niterun'] = $lastweek_niterun;
				}
				
				$lastyear_trapcount += 1;
				if ($row->trapnight > 0)
					$lastyear_niterun += $row->trapnight;
				
				$data_l1 ['lastyear'] ['trapcount'] = $lastyear_trapcount;
				$data_l1 ['lastyear'] ['niterun'] = $lastyear_niterun;
				if (! empty ( $SPECIES1 ))
					$data_l1 ['species'] = $SPECIES1;
			}
		}
		
		// echo"<pre>";
		// print_r($SPECIES1);
		// print_r($data_l1);
		// die;
		sort ( $CULEX );
		sort ( $CULISETA );
		sort ( $AEDES );
		sort ( $ANOPHELES );
		sort ( $OTHER_SPECIES );
		sort ( $UNSPECIATED );
		// echo "<br>==========CULEX===========<br>";
		// print_r($CULEX);
		// echo "<br>==========CULISET===========<br>";
		// print_r($CULISETA);
		// echo "<br>==========AEDES===========<br>";
		// print_r($AEDES);
		// echo "<br>==========ANOPHELES===========<br>";
		// print_r($ANOPHELES);
		// echo "<br>==========OTHER==========<br>";
		// print_r($OTHER_SPECIES);
		// echo "<br>==========Data l1==========<br>";
		$countSpeciesCol = 0;
		$chkType = '';
		$speciesType = '';
		// if(!empty($data_l1['species']))
		// foreach($data_l1['species'] as $key => $val)
		// {
		// //echo $key."<br>";
		// switch($key)
		// {
		// case 'thisweek':
		// foreach($val as $ky => $va)
		// {
		// switch($ky)
		// {
		// case 'CULEX':
		// if(count($va) > $countSpeciesCol)
		// {
		// $countSpeciesCol = count($va);
		// $chkType = 'thisweek';
		// $speciesType = 'CULEX';
		// }
		// break;
		// case 'AEDES':
		// if(count($va) > $countSpeciesCol)
		// {
		// $countSpeciesCol = count($va);
		// $chkType = 'thisweek';
		// $speciesType = 'AEDES';
		// }
		// break;
		// case 'CULISETA':
		// if(count($va) > $countSpeciesCol)
		// {
		// $countSpeciesCol = count($va);
		// $chkType = 'thisweek';
		// $speciesType = 'CULISETA';
		// }
		// break;
		// case 'ANOPHELES':
		// if(count($va) > $countSpeciesCol)
		// {
		// $countSpeciesCol = count($va);
		// $chkType = 'thisweek';
		// $speciesType = 'ANOPHELES';
		// }
		// break;
		// case 'OTHER':
		// if(count($va) > $countSpeciesCol)
		// {
		// $countSpeciesCol = count($va);
		// $chkType = 'thisweek';
		// $speciesType = 'OTHER SPECIES';
		// }
		// break;
		// case 'UNSPECIATED':
		// if(count($va) > $countSpeciesCol)
		// {
		// $countSpeciesCol = count($va);
		// $chkType = 'thisweek';
		// $speciesType = 'UNSPECIATED';
		// }
		// break;
		//
		// }
		// }
		// //echo $countSpeciesCol."<br>";
		// break;
		// case 'lastweek':
		// foreach($val as $ky => $va)
		// {
		// switch($ky)
		// {
		// case 'CULEX':
		// if(count($va) > $countSpeciesCol)
		// {
		// $countSpeciesCol = count($va);
		// $chkType = 'lastweek';
		// $speciesType = 'CULEX';
		// }
		// break;
		// case 'AEDES':
		// if(count($va) > $countSpeciesCol)
		// {
		// $countSpeciesCol = count($va);
		// $chkType = 'lastweek';
		// $speciesType = 'AEDES';
		// }
		// break;
		// case 'CULISETA':
		// if(count($va) > $countSpeciesCol)
		// {
		// $countSpeciesCol = count($va);
		// $chkType = 'lastweek';
		// $speciesType = 'CULISETA';
		// }
		// break;
		// case 'ANOPHELES':
		// if(count($va) > $countSpeciesCol)
		// {
		// $countSpeciesCol = count($va);
		// $chkType = 'lastweek';
		// $speciesType = 'ANOPHELES';
		// }
		// break;
		// case 'OTHER':
		// if(count($va) > $countSpeciesCol)
		// {
		// $countSpeciesCol = count($va);
		// $chkType = 'lastweek';
		// $speciesType = 'OTHER SPECIES';
		// }
		// break;
		// case 'UNSPECIATED':
		// if(count($va) > $countSpeciesCol)
		// {
		// $countSpeciesCol = count($va);
		// $chkType = 'lastweek';
		// $speciesType = 'UNSPECIATED';
		// }
		// break;
		//
		// }
		// }
		// //echo $countSpeciesCol."<br>";
		// break;
		// case 'lastyear':
		// foreach($val as $ky => $va)
		// {
		// switch($ky)
		// {
		// case 'CULEX':
		// if(count($va) > $countSpeciesCol)
		// {
		// $countSpeciesCol = count($va);
		// $chkType = 'lastyear';
		// $speciesType = 'CULEX';
		// }
		// break;
		// case 'AEDES':
		// if(count($va) > $countSpeciesCol)
		// {
		// $countSpeciesCol = count($va);
		// $chkType = 'lastyear';
		// $speciesType = 'AEDES';
		// }
		// break;
		// case 'CULISETA':
		// if(count($va) > $countSpeciesCol)
		// {
		// $countSpeciesCol = count($va);
		// $chkType = 'lastyear';
		// $speciesType = 'CULISETA';
		// }
		// break;
		// case 'ANOPHELES':
		// if(count($va) > $countSpeciesCol)
		// {
		// $countSpeciesCol = count($va);
		// $chkType = 'lastyear';
		// $speciesType = 'ANOPHELES';
		// }
		// break;
		// case 'OTHER':
		// if(count($va) > $countSpeciesCol)
		// {
		// $countSpeciesCol = count($va);
		// $chkType = 'lastyear';
		// $speciesType = 'OTHER SPECIES';
		// }
		// break;
		// case 'UNSPECIATED':
		// if(count($va) > $countSpeciesCol)
		// {
		// $countSpeciesCol = count($va);
		// $chkType = 'lastyear';
		// $speciesType = 'UNSPECIATED';
		// }
		// break;
		//
		// }
		// }
		// //echo $countSpeciesCol."<br>";
		// break;
		// }
		// }
		// print'<pre>';
		// echo $countSpeciesCol."<br>";
		// print_R($data_1);
		// print_r($data_l1['species']['lastyear']);
		// print_r($data_l1['species']['thisweek']);
		// print_r($OTHER_SPECIES);
		// die;
		// print'</pre>';
		$data = array (
				'report' => $data_1,
				'sreport' => $data_l1,
				'countSpeciesCol' => $countSpeciesCol,
				'speciesType' => $speciesType,
				'chkType' => $chkType,
				'culex' => json_decode ( json_encode ( $CULEX ) ),
				'culiseta' => json_decode ( json_encode ( $CULISETA ) ),
				'aedes' => json_decode ( json_encode ( $AEDES ) ),
				'annopheles' => json_decode ( json_encode ( $ANOPHELES ) ),
				'other_species' => json_decode ( json_encode ( $OTHER_SPECIES ) ),
				'unspeciated' => json_decode ( json_encode ( $UNSPECIATED ) ) 
		);
		
		return $data;
	}
}