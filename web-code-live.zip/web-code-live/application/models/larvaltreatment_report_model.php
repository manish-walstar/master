<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Larvaltreatment_report_model extends CI_Model {
	public $data = "";
	
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to fetch Larval Treatment
	 */
	public function getLarvalTreatment($startdate = '', $enddate = '', $sortorder = '') {
		$startdate_arr = explode ( "/", $startdate );
		$startdate = $startdate_arr [2] . "-" . $startdate_arr [0] . "-" . $startdate_arr [1];
		
		$enddate_arr = explode ( "/", $enddate );
		$enddate = $enddate_arr [2] . "-" . $enddate_arr [0] . "-" . $enddate_arr [1];
		// $startdate = '2012-01-01';
		// $enddate = '2013-08-01';
		$this->db->select ( 'l.*,
				s.site,
				s.idzone,
				s.idsitetype,
				s.city,
				z.zone,
				st.sitetype,
				ap.applicationmethod,
				m.mixratio,
				u.unitproduct AS uoms,
				at.unitarea AS units,
				usr.firstname,
				usr.middlename,
				usr.lastname,
				p.productname' );
		$this->db->from ( 'larvaltreatments AS l' );
		$this->db->join ( 'products AS p', 'l.idproduct = p.idproduct', "INNER" );
		$this->db->join ( 'sites AS s', 'l.idsite = s.idsite', "LEFT" );
		$this->db->join ( 'zones AS z', 's.idzone = z.idzone', "LEFT" );
		$this->db->join ( 'sitetypes AS st', 's.idsitetype = st.idsitetype', "LEFT" );
		$this->db->join ( 'applicationmethods AS ap', 'l.idapplicationmethod = ap.idapplicationmethods', "LEFT" );
		$this->db->join ( 'mixratios AS m', 'l.idmixratio = m.idmixratio', "LEFT" );
		// $this->db->join('uoms AS u','l.iduomtotalproductapplied = u.iduom',"LEFT");
		$this->db->join ( 'productunit AS u', 'l.iduomtotalproductapplied = u.idproductunit', "LEFT" );
		$this->db->join ( 'area_treated AS at', 'l.iduomtotalareatreated = at.idareatreated', "LEFT" );
		$this->db->join ( 'users AS usr', 'l.idapplicator = usr.iduser', "LEFT" );
		$this->db->where ( 'l.idlocation', $this->session->userdata ( 'idlocation' ) );
		// $this->db->where('z.idlocation',$this->session->userdata('idlocation'));
		// $this->db->where('p.idlocation',$this->session->userdata('idlocation'));
		$this->db->where ( 'date >=', $startdate );
		$this->db->where ( 'l.isdeleted', '0' );
		$this->db->where ( 'date <=', $enddate );
		
		if ($sortorder)
			$this->db->order_by ( 'p.idproduct', 'asc' );
		else
			$this->db->order_by ( 'p.productname', 'asc' );
		
		$this->db->order_by ( 'l.date', 'desc' );
		$query = $this->db->get ();
		// echo $this->db->last_query();
		// die;
		$result = array ();
		if ($query->num_rows () > 0) {
			$this->data = $query->result_array ();
			 //print'<pre>';
//			 print_r($this->data);
//			 die;
			return $this->data;
		}
		
		return $result;
	}
	
	/**
	 * Function to generate XML
	 */
	public function getXML($startdate = '', $enddate = '') {
		$startdate_arr = explode ( "/", $startdate );
		$startdate = $startdate_arr [2] . "-" . $startdate_arr [0] . "-" . $startdate_arr [1];
		
		$enddate_arr = explode ( "/", $enddate );
		$enddate = $enddate_arr [2] . "-" . $enddate_arr [0] . "-" . $enddate_arr [1];
		
		$this->db->select ( 'l.*,
				s.site,
				s.city,
				z.zone,
				st.sitetype,
				ap.applicationmethod,
				m.mixratio,
				u.unitproduct AS uoms,
				at.unitarea AS units,
				usr.firstname,
				usr.middlename,
				usr.lastname,
				p.productname' );
		$this->db->from ( 'larvaltreatments AS l' );
		$this->db->join ( 'products AS p', 'l.idproduct = p.idproduct', "INNER" );
		$this->db->join ( 'sites AS s', 'l.idsite = s.idsite', "LEFT" );
		$this->db->join ( 'zones AS z', 's.idzone = z.idzone', "LEFT" );
		$this->db->join ( 'sitetypes AS st', 's.idsitetype = st.idsitetype', "LEFT" );
		$this->db->join ( 'applicationmethods AS ap', 'l.idapplicationmethod = ap.idapplicationmethods', "LEFT" );
		$this->db->join ( 'mixratios AS m', 'l.idmixratio = m.idmixratio', "LEFT" );
		$this->db->join ( 'productunit AS u', 'l.iduomtotalproductapplied = u.idproductunit', "LEFT" );
		$this->db->join ( 'area_treated AS at', 'l.iduomtotalareatreated = at.idareatreated', "LEFT" );
		$this->db->join ( 'users AS usr', 'l.idapplicator = usr.iduser', "LEFT" );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		// $this->db->where('z.idlocation',$this->session->userdata('idlocation'));
		// $this->db->where('p.idlocation',$this->session->userdata('idlocation'));
		$this->db->where ( 'l.isdeleted', '0' );
		$this->db->where ( 'date >=', $startdate );
		$this->db->where ( 'date <=', $enddate );
		$this->db->order_by ( 'p.productname', 'asc' );
		$this->db->order_by ( 'l.date', 'desc' );
		$query = $this->db->get ();
		
		return $query;
	}
	
	/**
	 * Function to fetch Larval Treatment
	 */
	public function getLarvalTreatment_I($startdate = '', $enddate = '') {
		$this->db->select ( 'l.*' );
		$this->db->from ( 'larvaltreatments AS l' );
		$this->db->join ( 'larvaecountrange AS lc', 'l.idlarvaecountrange = lc.idlarvaecountrange', "LEFT" );
		$this->db->join ( 'products AS p', 'l.idproduct = p.idproduct', "LEFT" );
		$this->db->join ( 'zones AS z', 's.idzone = z.idzone', "LEFT" );
		$this->db->join ( 'sitetypes AS st', 's.idsitetype = st.idsitetype', "LEFT" );
		$this->db->join ( 'applicationmethods AS ap', 'l.idapplicationmethod = ap.idapplicationmethods', "LEFT" );
		$this->db->join ( 'mixratios AS m', 'l.idmixratio = m.idmixratio', "LEFT" );
		$this->db->join ( 'productunit AS u', 'l.iduomtotalproductapplied = u.idproductunit', "LEFT" );
		$this->db->join ( 'area_treated AS at', 'l.iduomtotalareatreated = at.idareatreated', "LEFT" );
		$this->db->join ( 'users AS usr', 'l.idapplicator = usr.iduser', "LEFT" );
		$this->db->join ( 'sites AS s', 'l.idsite = s.idsite', "LEFT" );
		$this->db->where ( 'l.idlocation', $this->session->userdata ( 'idlocation' ) );
		// $this->db->where('z.idlocation',$this->session->userdata('idlocation'));
		// $this->db->where('p.idlocation',$this->session->userdata('idlocation'));
		$this->db->where ( 'date >=', $startdate );
		$this->db->where ( 'date <=', $enddate );
		$this->db->order_by ( 'p.productname', 'asc' );
		$this->db->order_by ( 'l.date', 'desc' );
		$query = $this->db->get ();
		// echo $this->db->last_query();
		// die;
		$result = array ();
		if ($query->num_rows () > 0) {
			$this->data = $query->result_array ();
			// print'<pre>';
			// print_r($this->data);
			// die;
			return $this->data;
		}
		
		return $result;
	}
	
	/**
	 * Function to fetch All Products
	 */
	public function getProducts($startdate = '', $enddate = '') {
		$result = array ();
		$k = 0;
		$chk = "";
		$noft = 0;
		$ttlarea = 0;
		$ttlprdct = 0;
		$this->data = $this->getLarvalTreatment ( $startdate, $enddate );
		
		// print'<pre>';
		// print_r($this->data);
		// print'</pre>';
		// die;
		
		if (! empty ( $this->data )) {
			$noft = 1;
			$k = 0;
            $areaArr = array();
			foreach ( $this->data as $key => $val ) {
				if ($chk != $val ['productname']) {
					$this->db->select ( 'p.*,
							f.formulation,
							pm.manufacturer' );
					$this->db->from ( 'products AS p' );
					$this->db->join ( 'formulations AS f', 'p.idformulation = f.idformulation', "LEFT" );
					$this->db->join ( 'productmanufacturers AS pm', 'p.idmanufacturer = pm.idmanufacturer', 'LEFT' );
					$this->db->join ( 'locations AS l', "p.idlocation = l.idlocation", 'INNER' );
					$this->db->where ( "p.idlocation", $this->session->userdata ( 'idlocation' ) );
					$this->db->where ( 'p.idproduct', $val ['idproduct'] );
					$this->db->order_by ( 'p.productname', 'asc' );
					$query = $this->db->get ();
					// echo $this->db->last_query();
                    
					$ttlarea = $val ['totalareatreated'];
					$ttlprdct = $val ['totalproductapplied'];
					
					if ($query->num_rows () > 0) {
						$k ++;
						$noft = 1;
						$temp = $query->result_array ();
						$result [$k] = $temp [0];
						$result [$k] ['qty'] = $ttlprdct;
						$result [$k] ['uom'] = $val ['uoms'];
						$result [$k] ['units'] = $val ['units'];
                        
						switch($val['units'])
                        {
                            case 'Acres': 
                                $areaArr = array($ttlarea,0,0,0);
                                break;
                            case 'Sq. Ft.': 
                                $areaArr = array(0,$ttlarea,0,0);
                                break;
                            case 'Basins': 
                                $areaArr = array(0,0,$ttlarea,0);
                                break;
                            case 'Miles': 
                                $areaArr = array(0,0,0,$ttlarea);
                                break;                            
                        }
                        $result [$k] ['area'] = $areaArr;
						$result [$k] ['noft'] = $noft;
					}
				} else {
					$noft ++;
					
					$ttlprdct += $val ['totalproductapplied'];
					
					$result [$k] ['qty'] = $ttlprdct;
					$result [$k] ['uom'] = $val ['uoms'];
					$result [$k] ['units'] = $val ['units'];
                    
                    switch($val['units'])
                    {
                        case 'Acres': 
                            $areaArr[0] = (!empty($areaArr) && isset($areaArr[0])) ? $areaArr[0] + $val ['totalareatreated'] : $val ['totalareatreated'];
                            break;
                        case 'Sq. Ft.': 
                            $areaArr[1] = (!empty($areaArr) && isset($areaArr[1])) ? $areaArr[1] + $val ['totalareatreated'] : $val ['totalareatreated'];
                            break;
                        case 'Basins': 
                            $areaArr[2] = (!empty($areaArr) && isset($areaArr[2])) ? $areaArr[2] + $val ['totalareatreated'] : $val ['totalareatreated'];
                            break;
                        case 'Miles': 
                            $areaArr[3] = (!empty($areaArr) && isset($areaArr[3])) ? $areaArr[3] + $val ['totalareatreated'] : $val ['totalareatreated'];
                            break;                             
                    }
                    $result [$k] ['area'] = $areaArr;
                    
					//$result [$k] ['area'] = $ttlarea;
					$result [$k] ['noft'] = $noft;
				}
				
				$chk = $val ['productname'];
			}
		}
		// print'<pre>';
		// print_r($result);
		// die;
		return $result;
	}
	
	/**
	 * Function to fetch All Products
	 */
	public function getProducts_I($startdate = '', $enddate = '') {
		$result = array ();
		$k = 0;
		$flag = "";
		$this->data = $this->getLarvalTreatment ( $startdate, $enddate, 1 );
		if (! empty ( $this->data )) {
			foreach ( $this->data as $key => $val ) {
				if ($val ['idproduct'] != $flag) {
					$this->db->select ( 'p.*,
							f.formulation,
							pm.manufacturer' );
					$this->db->from ( 'products AS p' );
					$this->db->join ( 'formulations AS f', 'p.idformulation = f.idformulation', "LEFT" );
					$this->db->join ( 'productmanufacturers AS pm', 'p.idmanufacturer = pm.idmanufacturer', 'LEFT' );
					$this->db->join ( 'locations AS l', "p.idlocation = l.idlocation", 'INNER' );
					$this->db->where ( "p.idlocation", $this->session->userdata ( 'idlocation' ) );
					$this->db->where ( 'p.idproduct', $val ['idproduct'] );
					$query = $this->db->get ();
					$k = 0;
					if ($query->num_rows () > 0) {
						$temp = $query->result_array ();
						$result [$val ['idproduct']] = $temp [0];
					}
				}
				
				$queryProduct = $this->db->get_where ( 'larvaltreatments', array (
						'post_trtmnt_inspection' => '1',
						'idlarvaltreatment' => $val ['idlarvaltreatment'] 
				) );
				
				$qp = $queryProduct->result_array ();
				
				if ($queryProduct->num_rows () > 0 ) {
					// print'<pre>';
					// print_r($qp);
					$ptiInfo = array ();
					$ptiInfo ['pti'] = 'YES';
					$ptiInfo ['ptiDate'] = ! empty ( $qp [0] ['date'] ) ? $qp [0] ['date'] : '';
					$xyz = array_merge ( $val, $ptiInfo );
				} else {
					$ptiInfo = array ();
					$ptiInfo ['pti'] = 'NO';
					$ptiInfo ['ptiDate'] = '';
					$xyz = array_merge ( $val, $ptiInfo );
				}
				// print'<pre>';
				 //print_r($val);
				// print'</pre>';
				$result [$val ['idproduct']] ['misc'] [$k] = $xyz;
				$k ++;
				$flag = $val ['idproduct'];
			}
		}
		// print'<pre>';
		// print_r($result);
		// die('here');
		return $result;
	}
}
