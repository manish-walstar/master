<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
date_default_timezone_set('UTC');
ini_set('memory_limit', '512M');

class Webservice_model extends CI_Model {

    public function __construct() {
        
        // Call the Model constructor
        parent::__construct();
    }

    public function adultsurveillance() {
        $this->db->select('adultsurveillance.idadultsurveillance, adultsurveillance.pudate, adultsurveillance.putime, adultsurveillance.setdate, adultsurveillance.settime, adultsurveillance.comments, traptypes.traptype, traptypes.traptypeAcronym, traps.trap, traps.idsite, sites.latitude ,sites.longitude');
        $this->db->from('adultsurveillance');
        $this->db->join('traps', 'adultsurveillance.idtrap = traps.idtrap', 'LEFT');
        $this->db->join('sites','traps.idsite = sites.idsite','LEFT');
        $this->db->join('traptypes', 'traps.idtraptype = traptypes.idtraptype', 'LEFT');
        $this->db->where('sites.idlocation' , $this->session->userdata('idlocation'));
        $this->db->where('adultsurveillance.isdeleted', '0');
        $this->db->where('adultsurveillance.is_sent', '0');
        //$this->db->join('adultsurveillancedetails', 'adultsurveillance.idadultsurveillance = adultsurveillancedetails.idadultsurveillance', 'left');
        //$this->db->limit(5);
        $query = $this->db->get();
        //echo $this->db->last_query()."<br>";
        return $query->result();
    }
    
    public function getArboviral() {
        $this->db->select('a.idarbovirallab, a.idtrap, a.idmosquitospecies, a.labassayid, a.testdate, a.comments, a.poolsize, adult.pudate AS collection_date, t.trap, tt.traptype, tt.traptypeAcronym, s.idsite, s.site, s.latitude, s.longitude, mosquitospecies.mosquitospecies, g.genus');
        $this->db->from('arbovirallabs AS a');
        $this->db->join('adultsurveillance AS adult', 'a.idadultsurveillance = adult.idadultsurveillance', 'LEFT');
        $this->db->join('mosquitospecies', 'a.idmosquitospecies = mosquitospecies.idmosquitospecies', 'LEFT');
        $this->db->join('genuses AS g', 'mosquitospecies.idgenus = g.idgenus', 'LEFT');
        $this->db->join('traps AS t', 'a.idtrap = t.idtrap', 'LEFT');
        $this->db->join('sites AS s','t.idsite = s.idsite','LEFT');
        $this->db->join('traptypes AS tt', 't.idtraptype = tt.idtraptype', 'LEFT');
        $this->db->where('s.idlocation' , $this->session->userdata('idlocation'));
        $this->db->where('a.isdeleted', '0');
        $this->db->where('a.is_sent', '0');
        $this->db->order_by('a.idarbovirallab', 'DESC');
        //$this->db->limit(1);
        $query = $this->db->get();
        //print'<pre>';
//        print_r($query->result());
//        die;
        return $query->result();
    }
    
    function get_adult_species_data($id = FALSE) {
        $this->db->select('genuses.genus, adultsurveillancedetails.countm, adultsurveillancedetails.countf, mosquitospecies.mosquitospecies');
        $this->db->from('adultsurveillancedetails');
        $this->db->where('adultsurveillancedetails.idadultsurveillance', $id);
        $this->db->join('mosquitospecies', 'adultsurveillancedetails.idmosquitospecies = mosquitospecies.idmosquitospecies', 'LEFT');
        $this->db->join('genuses', 'mosquitospecies.idgenus = genuses.idgenus', 'LEFT');
        $query = $this->db->get();
        return $query->result();
    }

    function chicken_sential_lab() {
        $this->db->where('isdeleted', '0');
        $this->db->where('is_sent', '0');
        //$this->db->limit('10');
        $query = $this->db->get('sentinelchickenlabs');
        return $query->result_array();
    }

    function update_sent_chicken_sential_lab($id) {
        $this->db->where('idsentinelchickenlab', $id);
        $query = $this->db->update('sentinelchickenlabs', array('is_sent' => '1'));
        //return $query->result();
    }

    function get_chicken_data($id) {
        $this->db->where('isdeleted', '0');
        $this->db->where('idsentinelchicken', $id);
        $query = $this->db->get('sentinelchicken');
        return $query->row_array();
    }

    function get_chicken_sample($id) {
        $this->db->where('isdeleted', '0');
        $this->db->where('idsentinelchicken', $id);
        $query = $this->db->get('sentinelchickensamples');
        return $query->result_array();
    }

    function get_sentinel_chicken() {
        $this->db->select('`sentinelchicken`.*');
        $this->db->from('sentinelchicken');
        $this->db->where('sentinelchicken.isdeleted', '0');
        $this->db->join('sites AS s', "sentinelchicken.idsite = s.idsite", 'LEFT');
        $this->db->where('sites.idlocation', $this->session->userdata('idlocation'));
        $query = $this->db->get();
        return $query->result_array();
    }

    function get_sites($id = '' , $table = '') {
        $this->db->select('sites.*, s.sitetype , st.stateabbrev');
        $flag = 0;
        if(!empty($table))
        {
            switch($table)
            {
                case 'adultsurveillance':
                    $this->db->from('adultsurveillance AS a');
                    $this->db->join('traps AS t', "a.idtrap = t.idtrap", 'INNER');
                    $this->db->join('sites', "t.idsite = sites.idsite", 'INNER');
                    $flag = 1;
                    break;
                case 'arbovirallabs':
                    $this->db->from('arbovirallabs AS a');
                    $this->db->join('traps AS t', "a.idtrap = t.idtrap", 'INNER');
                    $this->db->join('sites', "t.idsite = sites.idsite", 'INNER');
                    $flag = 1;
                    break;
                case 'calsurvflock':
                    $this->db->from('calsurvflock AS c');
                    $this->db->join('sites', "c.idsite = sites.idsite", 'INNER');
                    $flag = 1;
                    break;
                case 'larvalsurveillance':
                    $this->db->from('larvalsurveillance AS l');
                    $this->db->join('sites', "l.idsite = sites.idsite", 'INNER');
                    $flag = 1;
                    break;
            }
        }
        if($flag == 0)
        $this->db->from('sites');
            
        $this->db->join('sitetypes AS s', "sites.idsitetype = s.idsitetype", 'LEFT');
        $this->db->join('states AS st', "sites.idstate = st.idstate", 'LEFT');
        $this->db->where('sites.isdeleted', '0');
        $this->db->where('sites.is_sent', '0');
        $this->db->where('sites.idlocation', $this->session->userdata('idlocation'));
        if(!empty($id))
            $this->db->where('sites.idsite', $id);
        //$this->db->limit(10);
        $query = $this->db->get();
        //echo $this->db->last_query()."<br>";
        //print'<pre>';
//        print_r($query->result_array());
//        die;
        return $query->result_array();
    }
    
    public function setImported($table = '', $pkId = '' , $array = array())
    {
        if(!empty($table) && !empty($pkId) && !empty($array))
        {
            foreach($array as $key => $val)
            {
                $data['is_sent'] = '1';
                $this->db->where($pkId,$val);
                $this->db->update($table , $data);
                
            }
        }
    }
    
    /** 
     * Function to send single site data to CA Gateway
    */
    public function chkSentSite($idsite = '') 
    {
        if(empty($idsite))
            return false;
        
        //$idsite = '137888';
        
        $this->load->model('site_model');
        $siteData = $this->site_model->getSiteData($idsite);
        
        $import = array(
            "type" => "site"
        );
        
        $caSite = $this->get_data($import);
        $site_code = '';
        $flag = 0;
        
        if(!empty($caSite->data) && !empty($siteData['site']))
        {
            $site = explode(" ", $siteData['site']);
            $sitename = "";
            if(!empty($site) && is_array($site))
            {
                for($i = 1; $i<count($site) ; $i++)
                    $sitename .= $site[$i]." ";
                $sitename = trim($sitename);
            }
            foreach($caSite->data as $kdata => $vdata)
            {
                $site_code = $kdata;
                foreach($vdata as $key => $val)
                {
                    //echo $val->site_name." == ".$siteData['site']."\n";                                        
                    if(!empty($val->site_name) && !empty($sitename) && trim($val->site_name) == trim($sitename) && !empty($site[0]) && !empty($site_code) && $site_code == $site[0])
                    {
                        $flag = 1;                
                        break;
                    }
                    else if(!empty($val->site_name) && trim($val->site_name) == trim($siteData['site']))
                    {
                        $flag = 1;                
                        break;
                    }
                    
                }   
                //echo " Flag ".$flag." sitecode : $site_code"." site: $val->site_name "."\n";
                if($flag == 1)
                    break;
            }
        }
        //print(" Flag ".$flag." site_code : $site_code");
        if($flag == 1)
            return $site_code;
        else
            return false; 
    }
    
    
    /** 
     * Function to send single site data to CA Gateway
    */
    public function sendSingleSite($idsite) 
    {
        if(empty($idsite))
            return false;
            
        $sites = $this->get_sites($idsite);
        $chkSentSite = $this->chkSentSite($idsite);
        
        $arr_records = array();
        $tempSite = array();
        if(!empty($sites) && empty($chkSentSite))
        {
            foreach ($sites as $key => $value) {
                $site = "";
                $site = explode(" ", $value['site']);
                $Site_Code = "";
                $Site_Name = "";
                if(!empty($site) && is_array($site))
                {
                    if(!empty($site[0]) && preg_match_all('[0-9]+', $site[0]))
                        $Site_Code = $site[0];
                    else
                        $Site_Code = $value['idsite'];
                        
                    $Site_Name = $site[1];
                }
                else
                {
                    $Site_Code = $value['idsite'];
                    $Site_Name = $value['site'];    
                }
                
                $latitude = !empty($value['latitude'])?$value['latitude']:'';
                $longitude = !empty($value['longitude'])?$value['longitude']:'';
                $elevation = '';
                $address1 = $value['address1'];
                $address2 = $value['address2'];
                $city = $value['city'];
                $country = 'USA';
                $state = $value['stateabbrev'];
                $county = 'Napa';
                $postalcode = $value['postalcode'];
                $surroundings = $value['sitetype'];
                $population = '';
                $comments = '';
                $usedranges = '';
                $availableranges = '';
                //echo "Addr1 ".$address1." <br>Addr2 ".$address2." <br>City ".$city." <br>Pos ".$postalcode." <br>State ".$state."<br>";
//                echo "<br>-----------------------------------------------------<br>";
                
                if(!empty($Site_Code))
                {
                    $arr_records_1 = array(
                        "code" => $Site_Code,
                        "name" => $Site_Name,
                        //"coordinates" => array(
//                            "latitude" => $latitude,
//                            "longitude" => $longitude
//                        ),
                        "elevation" => $elevation,
                        "population" => !empty($population)?$population:'',
                        "comments" => !empty($comments)?$comments:'',
                        "landusage" => !empty($usedranges)?$usedranges:''
                    );
                    
                    //if(!empty($address1) && !empty($city) && !empty($postalcode) && !empty($state))
                        $arr_records_1["address"] = array(
                            "primary" => $address1 . ' ' . $address2,
                            "city" => !empty($city)?$city:'',
                            "postal" => !empty($postalcode)?$postalcode:'',
                            "county" => !empty($county)?$county:'',
                            "state" => !empty($state)?$state:'',
                            "country" => !empty($country)?$country:''
                        );
                    
                    //print'<pre>';
//                    print_r($arr_records_1);
                    array_push($arr_records, $arr_records_1);    
                    array_push($tempSite, $value['idsite']);
                }
            }
            //print'<pre>';
//            print_r($arr_records);
//            die;
    
            if(!empty($arr_records))
            {
                $insert = array(
                    "recordset" => array(
                        array(
                            "type" => "site",
                            "record" => $arr_records
                        )
                    )
                );
                
                
                $flag = $this->send_data($insert);

                if(empty($flag->Error) && !empty($flag))
                {
                    $this->setImported('sites','idsite',$tempSite); 
                    return array("SITE_CODE" => $Site_Code);
                }
                //print'<pre>';
//                print_r($flag);
//                die;
                return $flag;
            }   
        }
        else 
            return array("SITE_CODE" => $chkSentSite);
    }
    
    public function sendSingleFlock($data)
    {
        if(empty($data))
            return false;
        //print'<pre>';
//        print_r($data);
//        die;
        
        
        $result = $this->sendSingleSite($data['idsite']);
        //die($result['SITE_CODE']);
        if(empty($result['SITE_CODE']))
            return $result;
                    
        $sitecode = !empty($result['SITE_CODE'])?$result['SITE_CODE']:'';
        $year = !empty($data['flockyear'])?date('Y', strtotime($data['flockyear'])):'';
        $collectiondate = !empty($data['datebled'])?$data['datebled']:'0000-00-00';
        $collectedby = !empty($data['collectedby'])?$data['collectedby']:'';
        $wholeblood = !empty($data['wholeblood'])?'1':'0';
        $comments = !empty($data['comments'])?$data['comments']:'';
        $bandset = !empty($data['bandIds'])?$data['bandIds']:array();
        $idcalsurv = !empty($data['idcalsurv'])?$data['idcalsurv']:0;
        
        $arr_records = array(
            "site" => $sitecode,
            "year" => $year,
            "collectiondate" => $collectiondate,
            "collectedby" => $collectedby,
            "wholeblood" => $wholeblood,
            "comments" => $comments,
            "bandset" => $bandset
        );
        
        $insert = array(
            "recordset" => array(
                array(
                    "type" => "sentinel",
                    "subtype" => "bleed",
                    "record" => array($arr_records)
                )
            )
        );
        
        /*----------For Testing open the comments ----------*/
        //if($this->chkSite($idsite))
//            echo "hh";
//        else
//            echo "ggh";
//        die("---------------------");
        //print'<pre>';
//        print_r($insert);
//        die;   
        //return $insert;
        /*--------------------*/
            
        if($this->chkCaSent($idcalsurv))
        {
            $flag = $this->send_data($insert);
            if(empty($flag->Error))
            {
                $tempCalsurv = array(
                            'issent' => '1',
                            'datesent' => date('Y-m-d')
                        );
                $this->db->where('idcalsurv',$idcalsurv);
                $this->db->update('calsurvflock' , $tempCalsurv);    
            }
            return $flag;    
        }
        else
        {
            $result['Error'][0] = "This data has already been sent";
            return json_decode(json_encode($result));
        }                              
    }
    
    public function sendSingleBand($data)
    {
        if(empty($data))
            return false;
        //print'<pre>';
//        print_r($data);
//        die;
        
        
        $result = $this->sendSingleSite($data['idsite']);
        //print'<pre>';
//        print_r($result);
//        die;
        //die($result['SITE_CODE']);
        if(empty($result['SITE_CODE']))
            return $result;
                    
        $sitecode = !empty($result['SITE_CODE'])?$result['SITE_CODE']:'';
        $year = !empty($data['flockyear'])? $data['flockyear']:'';
        $bandset = !empty($data['bandset'])?$data['bandset']:array();
        $idcalsurv = !empty($data['idcalsurv'])?$data['idcalsurv']:0;
        $insert = array();
        $arr_records = array(
            "site" => $sitecode,
            "year" => $year,
            "collectiondate" => !empty($data['datebled']) ? $data['datebled'] : '',
            "collectedby" => array($data['collctrFirstName'], $data['collctrLastName']),
            "wholeblood" => !empty($data['iswholeblood']) ? true : false,
            "comments" => $data['comments'],
            "bandset" => array()
        );
        
        if(!empty($bandset))
        {
            foreach($bandset as $key => $val)
            {
                if(!empty($val['official']))
                {
                    $arr_records_1 = array(
                        "official" => $val['official']
                    );
                    array_push($arr_records["bandset"], $arr_records_1);   
                }        
            }
        }
        
        if(!empty($arr_records))
        {
            $insert = array(
                "recordset" => array(
                    array(
                        "type" => "sentinel",
                        "subtype" => "bleed",
                        "record" => array($arr_records)
                    )
                )
            );
        }
        
        /*----------For Testing open the comments ----------*/
        //if($this->chkSite($idsite))
//            echo "hh";
//        else
//            echo "ggh";
//        die("---------------------");
        //print'<pre>';
//        print_r($insert);
//        echo json_encode($insert);
//        echo "\n\n\n\n";
//        die;   
        //return $insert;
        /*--------------------*/
            
        if($this->chkCaSent($idcalsurv) && !empty($insert))
        {
            $flag = $this->send_data($insert);
            //echo "-------I AM HERE --------------<br>";
//            print'<pre>';
//            print_r($flag);
//            die;
            if(!empty($flag->Success))
            {
                $tempCalsurv = array(
                    'issent' => '1',
                    'datesent' => date('Y-m-d')
                );
                $this->db->where('idcalsurv',$idcalsurv);
                $this->db->update('calsurvflock' , $tempCalsurv);    
            }
            return $flag;    
        }
        else
        {
            $result['Error'][0] = "This data had been already sent";
            return json_decode(json_encode($result));
        }                              
    }
    
    public function chkSite($idsite = '')
    {
        if(empty($idsite))
            return false;
            
        $this->db->select('is_sent');
        $this->db->from('sites');
        $this->db->where('is_sent' , '0');
        $this->db->where('idsite' , $idsite);
        
        $query = $this->db->get();
        
        if($query->num_rows() > 0)
            return true;
        
        return false;
    }
    
    public function chkCaSent($idcalsurv = '')
    {
        if(empty($idcalsurv))
            return false;
            
        $this->db->select('issent');
        $this->db->from('calsurvflock');
        $this->db->where('issent' , '0');
        $this->db->where('idcalsurv' , $idcalsurv);
        
        $query = $this->db->get();
        
        if($query->num_rows() > 0)
            return true;
        
        return false;
    }
    
    public function sendSites()
    {
        $sites = $this->webservice_model->get_sites('' , $table);
        $arr_records = array();
        $tempSite = array();
        if(!empty($sites))
        {
            foreach ($sites as $key => $value) {
                $Site_Code = $value['idsite'];
                $Site_Name = $value['site'];
                if(empty($value['latitude']) || $value['latitude'] == '0.0000000000')
                {
                    $latitude = $this->decToDms(28.7913728000);
                    $degLat = $latitude['deg'];
                    $minLat = $latitude['min'];
                    $secLat = $latitude['sec'];
                }
                else
                {
                    $latitude = $this->decToDms($value['latitude']);
                    $degLat = $latitude['deg'];
                    $minLat = $latitude['min'];
                    $secLat = $latitude['sec'];
                }
                
                if(empty($value['longitude']) || $value['longitude'] == '0.0000000000')
                {
                    $longitude = $this->decToDms(-81.2268175000);
                    $degLng = $longitude['deg'];
                    $minLng = $longitude['min'];
                    $secLng = $longitude['sec'];
                }
                else
                {
                    $longitude = $this->decToDms($value['longitude']);
                    $degLng = $longitude['deg'];
                    $minLng = $longitude['min'];
                    $secLng = $longitude['sec'];
                }
                
                $elvation = '';
                $address1 = $value['address1'];
                $address2 = $value['address2'];
                $city = $value['city'];
                $country = 'USA';
                $state = $value['stateabbrev'];
                $county = 'Napa';
                $postalcode = $value['postalcode'];
                $surroundings = $value['sitetype'];
                $population = '';
                $comments = '';
                $usedranges = '';
                $availableranges = '';
                //echo "Addr1 ".$address1." <br>Addr2 ".$address2." <br>City ".$city." <br>Pos ".$postalcode." <br>State ".$state."<br>";
//                echo "<br>-----------------------------------------------------<br>";
                if(!empty($address1) && !empty($city) && !empty($postalcode) && !empty($state))
                {
                    $arr_records_1 = array(
                        "code" => $Site_Code,
                        "name" => $Site_Name,
                        "coordinates" => array(
                            "latitude" => array(
                                "degrees" => $degLat,
                				"minutes" => $minLat,
                				"seconds" => $secLat
                            ),
                            "longitude" => array(
                                "degrees" => $degLng,
                				"minutes" => $minLng,
                				"seconds" => $secLng
                            )
                        ),
                        "elevation" => $elvation,
                        "address" => array(
                            "primary" => $address1 . ' ' . $address2,
                            "city" => $city,
                            "postal" => $postalcode,
                            "county" => $county,
                            "state" => $state,
                            "country" => $country
                        ),
                        "population" => $population,
                        "comments" => $comments,
                        "landusage" => $usedranges
                    );
                    array_push($arr_records, $arr_records_1);    
                    array_push($tempSite, $value['idsite']);
                }
            }
    
            if(!empty($arr_records) && $this->chkSentSite($Site_Code))
            {
                $insert = array(
                    "recordset" => array(
                        array(
                            "type" => "site",
                            "record" => $arr_records
                        )
                    )
                );
                //print'<pre>';
//                print_r($insert);
//                die;
                $flag = $this->send_data($insert);
                if($flag)
                    $this->webservice_model->setImported('sites','idsite',$tempSite);
            }   
        }  
    }
    
    public function send_data($insert) {
        $url = "http://sandbox.calsurv.org/ws.php?module=core&ppf=import.ws&output=json&token=6ca8e375945200b059bb7cbdad7d51349ac16b72";
        $insert = json_decode(json_encode($insert), TRUE);
        //print'<pre>';
//        print_r(json_encode($insert));
//        exit;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, array("insert" => json_encode($insert)));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $response = curl_exec($ch);
        $error_msg = curl_error($ch);
        curl_close($ch);
        $result = json_decode($response);
        //print'<pre>';
//        print_r($result);
//        print_r($error_msg);
//        die;
        //if (isset($result->Success)) {
//            return true;
//        } else {
//            //return false;
//            return $result;
//        }
        return $result;
    }
    
    public function get_data($export) {
        $url = "http://sandbox.calsurv.org/ws.php?module=core&ppf=export.ws&output=json&token=6ca8e375945200b059bb7cbdad7d51349ac16b72";
        
        if(empty($export))
            return false;
        //$export = array("export" => json_encode($export));
        //print'<pre>';
//        print_r(json_encode($export));
//        die;
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, array("export" => json_encode($export)));
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
        $response = curl_exec($ch);
        $error_msg = curl_error($ch);
        curl_close($ch);
        $result = json_decode($response);
        //print'<pre>';
//        print_r($result);
//        print_r($error_msg);
//        die;
        return $result;        
    }
}
