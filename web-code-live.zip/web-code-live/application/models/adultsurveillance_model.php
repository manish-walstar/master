<?php
error_reporting ( 0 );
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Adultsurveillance_model extends CI_Model {
	public $str = "";
	public $map = "";
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to Add a new Adult Surveillance Record
	 */
	public function addAdultSurveillance($Id = '') {
		$idtrap = $this->input->post ( 'idtrap' );
		$idinspector = $this->input->post ( 'idinspector' );
		$idtemprange = $this->input->post ( 'idtemprange' );
		$idhumidityrange = $this->input->post ( 'idhumidityrange' );
		$idwindspeed = $this->input->post ( 'idwindspeed' );
		$idcloudcoverage = $this->input->post ( 'idcloudcoverage' );
		$comments = $this->input->post ( 'comments' );
		$totalcount = $this->input->post ( 'totalcount' );
		$idloc = $this->session->userdata ( 'idlocation' );
		$startdate = $this->input->post ( 'setdate' );
		$pudate = $this->input->post ( 'pudate' );
		$id = '';
		    	
		$this->load->model('usermodel');
		$data ['userId'] = $this->usermodel->getUserId();
		
		$data ['idtrap'] = ! empty ( $idtrap ) ? $idtrap : "";
		$data ['idinspector'] = ! empty ( $idinspector ) ? $idinspector : "";
		$data ['setdate'] = date ( 'Y-m-d', strtotime ( $startdate ) );
		$data ['pudate'] = date ( 'Y-m-d', strtotime ( $pudate ) );
		$data ['settime'] = $this->input->post ( 'settime' );
		$data ['putime'] = $this->input->post ( 'putime' );
		$data ['settimestamp'] = strtotime ( $data ['setdate'] . ' ' . $data ['settime'] );
		$data ['puttimestamp'] = strtotime ( $data ['pudate'] . ' ' . $data ['putime'] );
		$data ['idtemprange'] = ! empty ( $idtemprange ) ? $idtemprange : "";
		$data ['idhumidityrange'] = ! empty ( $idhumidityrange ) ? $idhumidityrange : "";
		$data ['idwindspeed'] = ! empty ( $idwindspeed ) ? $idwindspeed : "";
		$data ['idcloudcover'] = ! empty ( $idcloudcoverage ) ? $idcloudcoverage : "";
		$data ['comments'] = ! empty ( $comments ) ? $comments : "";
		$data ['totalcount'] = ! empty ( $totalcount ) ? $totalcount : '0';
		$data ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
		$data ['eggraftcount'] = $this->input->post ( 'ideggraft' );
		
		$this->db->query ( "SET foreign_key_checks = 0" );
		$this->db->insert ( 'adultsurveillance', $data );
		$id = $this->db->insert_id ();
		$rows = $this->db->affected_rows ();
		$this->db->query ( "SET foreign_key_checks = 1" );
		// $rows = 1;
		if (empty ( $id )) {
			$data ['message'] = 'error';
			return $data;
		} else {
			$data ['message'] = 'success';
		}
		
		$species = $this->input->post ( 'species_val' );
		$s_count = $this->input->post ( 'species_countval' );
		$s_countm = $this->input->post ( 'species_countnew' );
		$s_countf = $this->input->post ( 'species_countnewf' );
		
		if (! empty ( $species )) {
		//if (isset ( $species ) && count ( $species ) > 0) {
			$this->db->query ( 'SET foreign_key_checks = 0' );
			for($i = 0; $i < count ( $species ); $i ++) {
				$data_species = array ();
				$data_species ['idadultsurveillance'] = $id;
				$data_species ['idmosquitospecies'] = ! empty ( $species [$i] ) ? $species [$i] : 0;
				$data_species ['count'] = ! empty ( $s_count [$i] ) ? $s_count [$i] : 0;
				$data_species ['countm'] = ! empty ( $s_countm [$i] ) ? $s_countm [$i] : 0;
				$data_species ['countf'] = ! empty ( $s_countf [$i] ) ? $s_countf [$i] : 0;
				// print'<pre>';
				// print_r($data_species);
				$this->db->insert ( 'adultsurveillancedetails', $data_species );
			}
			// die;
			$this->db->query ( 'SET foreign_key_checks = 1' );
		}
		
		// end here sonu code
		
		// if request come from service request page
		$service_req_id = $this->input->get_post ( 'service_req_id' );
		if (! empty ( $service_req_id )) {
			$data_common ['idadultsurveillance'] = $id;
			$data_common ['idservicerequest'] = $service_req_id;
			$this->db->insert ( 'adultsurveillanceservice', $data_common );
		}
		
		// die;
		
		return $data;
	}
	
	/**
	 * Function to Update a new Adultsurveillance
	 */
	public function updateAdultsurveillance($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$idtrap = $this->input->post ( 'idtrap' );
		$idinspector = $this->input->post ( 'idinspector' );
		$idtemprange = $this->input->post ( 'idtemprange' );
		$idhumidityrange = $this->input->post ( 'idhumidityrange' );
		$idwindspeed = $this->input->post ( 'idwindspeed' );
		$idcloudcoverage = $this->input->post ( 'idcloudcoverage' );
		$idloc = $this->session->userdata ( 'idlocation' );
		$totalcount = $this->input->post ( 'totalcount' );
		$startdate = $this->input->post ( 'setdate' );
		$pudate = $this->input->post ( 'pudate' );
		
		$data ['idtrap'] = ($idtrap) ? $idtrap : 0;
		$data ['idinspector'] = ($idinspector) ? $idinspector : 0;
		$data ['setdate'] = date ( 'Y-m-d', strtotime ( $startdate ) );
		$data ['pudate'] = date ( 'Y-m-d', strtotime ( $pudate ) );
		$data ['settime'] = $this->input->post ( 'settime' );
		$data ['putime'] = $this->input->post ( 'putime' );
		$data ['settimestamp'] = strtotime ( $data ['setdate'] . ' ' . $data ['settime'] );
		$data ['puttimestamp'] = strtotime ( $data ['pudate'] . ' ' . $data ['putime'] );
		$data ['idtemprange'] = ($idtemprange) ? $idtemprange : 0;
		$data ['idhumidityrange'] = ($idhumidityrange) ? $idhumidityrange : 0;
		$data ['idwindspeed'] = ($idwindspeed) ? $idwindspeed : 0;
		$data ['idcloudcover'] = ($idcloudcoverage) ? $idcloudcoverage : 0;
		$data ['comments'] = $this->input->post ( 'comments' );
		$data ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
		$data ['totalcount'] = ! empty ( $totalcount ) ? $totalcount : '0';
		
		if (! empty ( $idtrap ) && $idtrap == '135')
			$data ['eggraftcount'] = $this->input->post ( 'ideggraft' );
		else
			$data ['eggraftcount'] = 0;
		
		$this->db->query ( "SET foreign_key_checks = 0" );
		$this->db->where ( 'idadultsurveillance', $Id );
		$this->db->update ( 'adultsurveillance', $data );
		$this->db->query ( "SET foreign_key_checks = 1" );
		$rows = $this->db->affected_rows ();
		
		$species = $this->input->post ( 'species_val' );
		$s_count = $this->input->post ( 'species_countval' );
		$s_countm = $this->input->post ( 'species_countnew' );
		$s_countf = $this->input->post ( 'species_countnewf' );		
		
		$this->db->query ( 'SET foreign_key_checks = 0' );
		$this->db->where ( 'idadultsurveillance', $Id );
		$this->db->delete ( 'adultsurveillancedetails' );
		
		for($i = 0; $i < count ( $species ); $i ++) {
			$data_species = array ();
			$data_species ['idadultsurveillance'] = $Id;
			$data_species ['idmosquitospecies'] = ! empty ( $species [$i] ) ? $species [$i] : 0;
			$data_species ['count'] = ! empty ( $s_count [$i] ) ? $s_count [$i] : 0;
			$data_species ['countm'] = ! empty ( $s_countm [$i] ) ? $s_countm [$i] : 0;
			$data_species ['countf'] = ! empty ( $s_countf [$i] ) ? $s_countf [$i] : 0;
			$this->db->insert ( 'adultsurveillancedetails', $data_species );
		}
		$this->db->query ( 'SET foreign_key_checks = 1' );
		
		return true;
	}
	public function updateData() {
		$this->db->select ( 'idadultsurveillance,settimestamp,puttimestamp' );
		$this->db->from ( 'adultsurveillance' );
		
		$q = $this->db->get ();
		
		if ($q->num_rows ()) {
			// print'<pre>';
			// print_r($q->result_array());
			// die;
			foreach ( $q->result_array () as $row ) {
				$data ['pudate'] = date ( 'Y-m-d', $row ['puttimestamp'] );
				$data ['putime'] = date ( 'H:i:s', $row ['puttimestamp'] );
				$data ['setdate'] = date ( 'Y-m-d', $row ['settimestamp'] );
				$data ['settime'] = date ( 'H:i:s', $row ['settimestamp'] );
				
				$this->db->where ( 'idadultsurveillance', $row ['idadultsurveillance'] );
				$this->db->update ( 'adultsurveillance', $data );
				$rows1 = $this->db->affected_rows ();
				//
				print '<pre>';
				print_r ( $row );
				echo "Updated " . $rows1 . "<br>";
				
				// echo date('Y-m-d',strtotime($row['puttimestamp']))." ".date('Y-m-d',strtotime('1345546800'))."<br>";
			}
		}
	}
	/**
	 * Function to list all Adultsurveillances
	 */
	public function deleteAdultsurveillance() {
		$id = $this->input->get_post ( 'id' );
		
		if (empty ( $id ))
			return false;
			/*
		 * $this->db->select('*');
		 * $this->db->from('adultsurveillancedetails');
		 * $this->db->where('idadultsurveillance',$id);
		 *
		 * $q = $this->db->get();
		 * if($q->num_rows() > 0)
		 * {
		 *
		 * $this->db->query("SET foreign_key_checks = 0");
		 * $this->db->where('idadultsurveillance',$id);
		 * $this->db->delete('adultsurveillancedetails');
		 * $this->db->query("SET foreign_key_checks = 1");
		 * }
		 *
		 * // delete records from adult surveilance service
		 * $this->db->select('*');
		 * $this->db->from('adultsurveillanceservice');
		 * $this->db->where('idadultsurveillance',$id);
		 * $p = $this->db->get();
		 * if($p->num_rows() > 0)
		 * {
		 * $this->db->query("SET foreign_key_checks = 0");
		 * $this->db->where('idadultsurveillance',$id);
		 * $this->db->delete('adultsurveillanceservice');
		 * $this->db->query("SET foreign_key_checks = 1");
		 * }
		 */
		$data ['isdeleted'] = '1';
		$this->db->where ( 'idadultsurveillance', $id );
		$this->db->update ( 'adultsurveillance', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to Get Lati Longi
	 * of User's Location'
	 */
	public function getUserLoc() {
		$this->db->select ( 'filename' );
		$this->db->from ( 'locations' );
		$this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$query = $this->db->get ();
		$filename = "";
		if ($query->num_rows () > 0) {
			$filename = $query->result_array ();
			$filename = $filename [0] ['filename'];
		}

		$filenameArray = explode(',', $filename);
		$arr = array ();		
		
		$j = 0;
		if (! empty ( $filenameArray ) && count($filenameArray) > 0) {
			foreach ($filenameArray as $key => $outer_values) {
				$doc = $this->load->view ( 'xml_files/' . $outer_values, '', TRUE );
				// $doc = @simplexml_load_string ( $doc );
				$doc = simplexml_load_string ( $doc );				
				$i = 0;
            foreach($doc->point as $val){
                	$arr [$outer_values][$i] ['lati'] = $val['lat'];
            		$arr [$outer_values][$i] ['longi'] = $val ['lng'];
            		$i++;
                }
            
			}			
		}
				
		
		return $arr;
	}
	/**
	 * Function to Get Lati Longi
	 * for displaying on Maps
	 */
	public function getMapdata($columns = array()) {
		$page_limit = $this->input->get ( 'page_size' );
		$page = $this->input->get ( 'page' );
		$order = $this->input->get ( 'orderby' );

        $page = $page ? $page : 1;
        $page_limit = ($page_limit == 'all') ? 'all' : (is_numeric($page_limit) ? $page_limit : 10);
        $page_limit = (is_numeric($page_limit)) ? $page_limit : NULL;
        $offset = $page_limit * ($page - 1);        
    
		$filter_date = $this->input->get ( 'filter_date' );
		$setfromdate = $this->input->get ( 'setfromdate' );
		$settodate = $this->input->get ( 'settodate' );
		
		$this->db->select ( 'adultsurveillance.idadultsurveillance,
				traps.latitude,
				traps.longitude,
				sites.city,
				sites.address1,
				sites.address2,
				traptypes.traptype,
				traps.idtrap,
				traps.trap,
				adultsurveillance.pudate,
				adultsurveillance.putime,
				adultsurveillance.totalcount AS count,
                locations.GoogleZoom,
                CONCAT(users.firstname, \' \', users.middlename, \' \', users.lastname) AS inspector' );
		$this->db->from ( 'adultsurveillance' );
		$this->db->join ( 'traps', 'adultsurveillance.idtrap = traps.idtrap', 'LEFT' );
		$this->db->join ( 'traptypes', 'traps.idtraptype = traptypes.idtraptype', 'LEFT' );
		$this->db->join ( 'sites', 'traps.idsite = sites.idsite', 'LEFT' );
		$this->db->join ( 'users', 'adultsurveillance.idinspector =  users.iduser', 'LEFT' );
		$this->db->join ( 'locations', 'adultsurveillance.idlocation =  locations.idlocation', 'LEFT' );
        $this->db->where ( 'adultsurveillance.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'adultsurveillance.isdeleted', '0' );
		if (! is_null ( $filter_date ) && empty ( $setfromdate ) && empty ( $settodate )) {
			switch ($filter_date) {
				case '1' :
					$this->db->where ( 'adultsurveillance.pudate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'adultsurveillance.pudate' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'adultsurveillance.pudate' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'adultsurveillance.pudate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'adultsurveillance.pudate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'adultsurveillance.pudate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'adultsurveillance.pudate' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'adultsurveillance.pudate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'adultsurveillance.pudate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'adultsurveillance.pudate' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		} else if (! empty ( $setfromdate ) && ! empty ( $settodate )) {
			$this->db->where ( 'adultsurveillance.pudate' . ' >=', $setfromdate );
			$this->db->where ( 'adultsurveillance.pudate' . ' <=', $settodate );
		}
        $this->db->group_by ( 'adultsurveillance.idadultsurveillance');
		if (! is_null ( $order )) {
            $order = explode(":", $order);
            foreach ( $columns as $fkey => $field ) {
				if ($fkey == $order[0])
					switch ($field['type']) {
						case '1-n' :
							$this->db->order_by ( "{$field['ref_table_db_name']}.{$field['ref_field_db_name']}", $order[1] );
							break;
						case '1+2' :
							$this->db->order_by ( 'adultsurveillance.pudate', $order[1] );
							$this->db->order_by ( 'adultsurveillance.putime', $order[1] );
							break;
                        case '1-1-1' :
							$this->db->order_by ( "{$field['ref_table_db2_name']}.{$field['ref_field_db2_name']}", $order[1] );
							break;
                        case '1-1+2+3' :
							$this->db->order_by ( "{$field['ref_table_db_name']}.{$field['ref_field_db2_name']}", $order[1] );
                            $this->db->order_by ( "{$field['ref_table_db_name']}.{$field['ref_field_2_db_name']}", $order[1] );
                            $this->db->order_by ( "{$field['ref_table_db_name']}.{$field['ref_field_3_db_name']}", $order[1] );
							break;
                        default:
                            $this->db->order_by ( "adultsurveillance.{$field['db_name']}", $order[1] );
							break;
					}
			}		
		} else {
            $this->db->order_by ( 'ad.pudate', 'desc' );
		}
        
		$this->db->limit ( $page_limit, $offset );
		
		$query = $this->db->get ();
		//echo $this->db->last_query();
//		 die;
		$result = array();
		if ($query->num_rows () > 0){
            $result = $query->result_array ();
            foreach($result as $key => $val) {
                $this->db->select("SUM(IF (lvs.idlocationmosquitospecies = '', 0, ads.count)) AS vectorcount");
                $this->db->from ( 'adultsurveillance AS ad' );
        		$this->db->join ( 'adultsurveillancedetails AS ads', 'ad.idadultsurveillance = ads.idadultsurveillance', 'INNER' );
                $this->db->join ( 'locationvectorspecies AS lvs', 'ads.idmosquitospecies = lvs.idlocationmosquitospecies', 'INNER' );
        		$this->db->where ( 'ad.idadultsurveillance', $val['idadultsurveillance'] );
                $this->db->where ( 'ad.idlocation', $this->session->userdata ( 'idlocation' ) );
                $this->db->where ( 'lvs.idlocation', $this->session->userdata ( 'idlocation' ) ); 
                $vectorcount = $this->db->get()->row()->vectorcount;  
                $result[$key]['vectorcount'] = $vectorcount ? $vectorcount : 0;
            }
		}
        return $result;
	}
	/**
	 * Function to list all Adultsurveillances mail
	 */
	public function getAdultsurveillanceData($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( '`adultsurveillance`.*' );
		$this->db->from ( 'adultsurveillance' );
		$this->db->where ( 'adultsurveillance.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( '`adultsurveillance`.`idadultsurveillance`', $Id );
		
		$query = $this->db->get ();
		
		$data = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row )
				$data [] = $row;
			
			return $data [0];
		}
		
		return false;
	}
    
    /**
	 * Function to get site id based on adultsurveillance id
	 */
	public function getIdSite($id = '') {
		if (empty ( $id ))
			return false;
		
		$this->db->select ( '`traps`.`idsite`' );
		$this->db->from ( 'adultsurveillance' );
        $this->db->join ( 'traps', 'adultsurveillance.idtrap = traps.idtrap', 'INNER' );
		$this->db->where ( '`adultsurveillance`.`idadultsurveillance`', $id );
		$this->db->where ( 'adultsurveillance.isdeleted', '0' );
		
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
            return $query->row()->idsite;
		}
		
		return false;
	}
    
	/**
	 * Function to list all Adultsurveillances mail
	 */
	public function listAdultsurveillances($Ids = "", $mapSite = "", $mapFlag = "") {
		$this->db->select ( "`adultsurveillance`.`idadultsurveillance`,
				`adultsurveillance`.`totalcount` AS `count`,
				`traps`.`trap` AS `traps_trap`, 
				`traptypes`.`traptype` AS `traps_idtraptype`,
				`adultsurveillance`.`setdate` AS `setdate`,
				`adultsurveillance`.`settime` AS `settime`,
				`adultsurveillance`.`pudate` AS `pudate`,
				`adultsurveillance`.`putime` AS `putime`, 
				`sites`.`site`, 
				`users`.`firstname`,
				`users`.`middlename`, 
				`users`.`lastname`,
                CONCAT(`adultsurveillance`.`pudate`,' ',`adultsurveillance`.`putime`) AS pckupdttime" );
		$this->db->from ( 'adultsurveillance' );
		$this->db->join ( 'traps', 'adultsurveillance.idtrap = traps.idtrap', 'LEFT' );
		$this->db->join ( 'sites', 'traps.idsite = sites.idsite', 'LEFT' );
		$this->db->join ( 'traptypes', 'traps.idtraptype = traptypes.idtraptype', 'LEFT' );
		$this->db->join ( 'users', 'adultsurveillance.idinspector = users.iduser', 'LEFT' );
		$this->db->join ( 'locations', 'adultsurveillance.idlocation = locations.idlocation', 'LEFT' );
		$this->db->where ( 'adultsurveillance.isdeleted', '0' );
		$this->db->where ( 'adultsurveillance.idlocation', $this->session->userdata ( 'idlocation' ) );
		
        $filter_date = !empty($filter_date) ? $filter_date : $this->input->get ( 'filter_date' );
		$ttl = !empty($ttl) ? $ttl : $this->input->get ( 'ttl' );
		$page = !empty($page) ? $page : $this->input->get ( 'page' );
		$frmdate = !empty($filter_daterange) && isset($filter_daterange[0]) ? $filter_daterange[0] : $this->input->get ( 'frmdate' );
		$todate = !empty($filter_daterange) && isset($filter_daterange[1]) ? $filter_daterange[1] : $this->input->get ( 'todate' );
		$orderby = $this->input->get ( 'orderby' );
		
		if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 2;
		
		if (! isset ( $ttl ) || $ttl == '')
			$ttl = 10;
		
		if (! isset ( $page ) || $page == '')
			$page = 1;
		
        if(!empty($mapSite) || !empty($mapFlag)){
            $filter_date = "";
            $filter_daterange = "";
            $frmdate = "";
            $todate = "";
		}
        
        if(!empty($mapSite)) {
            $this->db->where ( 'sites.idsite', $mapSite );
        }
        
		if (! empty ( $frmdate ) && ! empty ( $todate )) {
			$frmdate = substr ( $frmdate, 0, 2 ) . '/' . substr ( $frmdate, 2, 2 ) . '/' . substr ( $frmdate, 4, 4 );
			$todate = substr ( $todate, 0, 2 ) . '/' . substr ( $todate, 2, 2 ) . '/' . substr ( $todate, 4, 4 );
			$this->db->where ( 'adultsurveillance.pudate' . ' >=', date ( 'Y-m-d', strtotime ( $frmdate ) ) );
			$this->db->where ( 'adultsurveillance.pudate' . ' <=', date ( 'Y-m-d', strtotime ( $todate ) ) );
		} else if (! is_null ( $filter_date )) {
			switch ($filter_date) {
				// date('H:i:s',strtotime('-1 day');
				case '1' :
					$this->db->where ( 'adultsurveillance.pudate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'adultsurveillance.pudate' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'adultsurveillance.pudate' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'adultsurveillance.pudate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'adultsurveillance.pudate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'adultsurveillance.pudate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'adultsurveillance.pudate' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'adultsurveillance.pudate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'adultsurveillance.pudate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'adultsurveillance.pudate' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		}
		
		if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
			switch ($orderby) {
				case '0:asc' :
					$this->db->order_by ( 'traps.trap', 'ASC' );
					break;
				case '0:desc' :
					$this->db->order_by ( 'traps.trap', 'DESC' );
					break;
				case '1:asc' :
					$this->db->order_by ( 'traptypes.traptype', 'ASC' );
					break;
				case '1:desc' :
					$this->db->order_by ( 'traptypes.traptype', 'DESC' );
					break;
				case '2:asc' :
					$this->db->order_by ( "adultsurveillance.pudate", 'ASC' );
					$this->db->order_by ( "adultsurveillance.putime", 'ASC' );
					break;
				case '2:desc' :
					$this->db->order_by ( "adultsurveillance.pudate", 'DESC' );
					$this->db->order_by ( "adultsurveillance.putime", 'DESC' );
					break;
				case '3:asc' :
					$this->db->order_by ( 'sites.site', 'ASC' );
					break;
				case '3:desc' :
					$this->db->order_by ( 'sites.site', 'DESC' );
					break;
				case '4:asc' :
					$this->db->order_by ( 'adultsurveillance.totalcount', 'ASC' );
					break;
				case '4:desc' :
					$this->db->order_by ( 'adultsurveillance.totalcount', 'DESC' );
					break;
				case '5:asc' :
					$this->db->order_by ( 'users.firstname', 'ASC' );
					$this->db->order_by ( 'users.middlename', 'ASC' );
					$this->db->order_by ( 'users.lastname', 'ASC' );
					break;
				case '5:desc' :
					$this->db->order_by ( 'users.firstname', 'DESC' );
					$this->db->order_by ( 'users.middlename', 'DESC' );
					$this->db->order_by ( 'users.lastname', 'DESC' );
					break;
			}
		} else {
			$this->db->order_by ( "adultsurveillance.pudate", 'DESC' );
			$this->db->order_by ( "adultsurveillance.putime", 'DESC' );
		}
		
		/*
		 * if(!is_null($ttl) && !is_null($page))
		 * {
		 * if($page == 1)
		 * $page = 0;
		 * else
		 * $page--;
		 *
		 * $page *= 10;
		 * $this->db->limit($ttl ,$page);
		 * }
		 * else if(!is_null($ttl))
		 * {
		 * $this->db->limit($ttl);
		 * }
		 */
		
		$data_1 = array ();
        if(!empty($Ids)) {
            $this->db->where_in ( 'adultsurveillance.idadultsurveillance', $Ids );
        }
		$query = $this->db->get ();
		if ($query->num_rows () > 0)
			return $query->result_array ();
		
		return false;
	}
	
	/**
	 * Function to fetch Inspector List
	 */
	public function getInspectors() 

	{
		$this->db->select ( 'u.iduser,u.firstname,u.middlename,u.lastname' );
		$this->db->from ( 'users AS u' );
		$this->db->join ( 'userlocationassignment AS ula', "u.iduser = ula.iduser", 'INNER' );
		//$this->db->join ( 'locations AS lc', "ula.idlocation = lc.idlocation", 'INNER' );
		$this->db->where ( 'ula.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'u.is_active', '1' );
		$this->db->order_by ( 'u.firstname', 'asc' );
		$this->db->order_by ( 'u.lastname', 'asc' );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$middlename = ! empty ( $row ['middlename'] ) ? " " . $row ['middlename'] . " " : " ";
				$this->str .= '<option value="' . $row ['iduser'] . '">' . $row ['firstname'] . $middlename . $row ['lastname'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Inspector List
	 */
	public function getSelectedInspectors($Id = '') {
		$this->db->select ( 'u.iduser,u.firstname,u.middlename,u.lastname' );
		$this->db->from ( 'users AS u' );
		
		$this->db->join ( 'userlocationassignment AS ula', "u.iduser = ula.iduser", 'INNER' );
		$this->db->join ( 'locations AS lc', "ula.idlocation = lc.idlocation", 'INNER' );
		$this->db->where ( 'lc.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'u.is_active', '1' );
		$this->db->order_by ( 'u.firstname', 'asc' );
		$this->db->order_by ( 'u.lastname', 'asc' );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$middlename = ! empty ( $row ['middlename'] ) ? " " . $row ['middlename'] . " " : " ";
				
				if ($Id == $row ['iduser'])
					$this->str .= '<option value="' . $row ['iduser'] . '" selected="true">' . $row ['firstname'] . $middlename . $row ['lastname'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['iduser'] . '">' . $row ['firstname'] . $middlename . $row ['lastname'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Trap Names
	 */
	public function getTrapname() {
		$this->db->select ( 't.idtrap,t.trap,t.idsite' );
		$this->db->order_by ( 'trap' );
		$this->db->from ( 'traps AS t' );
		$this->db->where ( 't.active', '1' );
		$this->db->where ( 't.isdeleted', '0' );
		$this->db->join ( 'sites AS s', "t.idsite = s.idsite", 'LEFT' );
		
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['idtrap'] . '">' . $row ['trap'] . '</option>';
			}
		}
		
		return $this->str;
	}
	public function getFilteredTrapname() {
		$this->db->select ( 't.idtrap,t.trap,t.idsite' );
		$this->db->order_by ( 'trap', 'asc' );
		$this->db->group_by ( 'idtrap' );
		$this->db->from ( 'traps AS t' );
		$this->db->where ( 't.active', '1' );
		$this->db->where ( 't.isdeleted', '0' );
		$this->db->join ( 'adultsurveillance', 'adultsurveillance.idtrap = t.idtrap', 'INNER' );
		// $this->db->join('sites AS s',"t.idsite = s.idsite",'LEFT');
		$this->db->where ( 't.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['idtrap'] . '">' . $row ['trap'] . '</option>';
			}
		}
		
		return $this->str;
	}
	/**
	 * Function to fetch Selected Trap Names
	 */
	public function getSelectedTrapname($Id = '') {
		$this->db->select ( 't.idtrap,t.trap,t.idsite' );
		$this->db->order_by ( 'trap' );
		$this->db->from ( 'traps AS t' );
		$this->db->where ( 't.active', '1' );
		$this->db->where ( 't.isdeleted', '0' );
		$this->db->join ( 'sites AS s', "t.idsite = s.idsite", 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idtrap'])
					$this->str .= '<option value="' . $row ['idtrap'] . '" selected="true">' . $row ['trap'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idtrap'] . '">' . $row ['trap'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Temp Range
	 */
	public function getTemprange() {
		$this->db->select ( 'idtemprange,temprange,ordering' );
		$this->db->order_by ( 'ordering', 'ASC' );
		$this->db->from ( 'tempranges' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['idtemprange'] . '">' . $row ['temprange'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Temp Range
	 */
	public function getSelectedTemprange($Id = '') {
		$this->db->select ( 'idtemprange,temprange,ordering' );
		$this->db->from ( 'tempranges' );
		$this->db->order_by ( 'ordering', 'ASC' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idtemprange'])
					$this->str .= '<option value="' . $row ['idtemprange'] . '" selected="true">' . $row ['temprange'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idtemprange'] . '">' . $row ['temprange'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Humidity Range
	 */
	public function getHumidityrange() {
		$this->db->select ( 'idhumidityrange,humidityrange' );
		$this->db->from ( 'humidityranges' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['idhumidityrange'] . '">' . $row ['humidityrange'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Humidity Range
	 */
	public function getSelectedHumidityrange($Id = '') {
		$this->db->select ( 'idhumidityrange,humidityrange' );
		$this->db->from ( 'humidityranges' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idhumidityrange'])
					$this->str .= '<option value="' . $row ['idhumidityrange'] . '" selected= "true">' . $row ['humidityrange'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idhumidityrange'] . '">' . $row ['humidityrange'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Wind Speed
	 */
	public function getWindspeed() {
		$this->db->select ( 'idwindspeed,windspeed' );
		$this->db->from ( 'windspeeds' );
		$this->db->order_by ( 'idwindspeed' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['idwindspeed'] . '">' . $row ['windspeed'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Wind Speed
	 */
	public function getSelectedWindspeed($Id = '') {
		$this->db->select ( 'idwindspeed,windspeed' );
		$this->db->from ( 'windspeeds' );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idwindspeed'])
					$this->str .= '<option value="' . $row ['idwindspeed'] . '" selected="true">' . $row ['windspeed'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idwindspeed'] . '">' . $row ['windspeed'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Cloud Coverage
	 */
	public function getCloudcoverage() {
		$this->db->select ( 'idcloudcoverage,cloudcoverage' );
		$this->db->order_by ( 'cloudcoverage' );
		$this->db->from ( 'cloudcoverage' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['idcloudcoverage'] . '">' . $row ['cloudcoverage'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Cloud Coverage
	 */
	public function getSelectedCloudcoverage($Id = '') {
		$this->db->select ( 'idcloudcoverage,cloudcoverage' );
		$this->db->order_by ( 'cloudcoverage' );
		$this->db->from ( 'cloudcoverage' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idcloudcoverage'])
					$this->str .= '<option value="' . $row ['idcloudcoverage'] . '" selected="true">' . $row ['cloudcoverage'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idcloudcoverage'] . '">' . $row ['cloudcoverage'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch selected Species Name
	 */
	public function getSelectedSpecies($Id = '') {
		$sel_species = array ();
		
		$this->db->select ( 'adultsurveillancedetails.idmosquitospecies,
				mosquitospecies.mosquitospecies,
				adultsurveillancedetails.count,
				adultsurveillancedetails.countm,
				adultsurveillancedetails.countf,
				g.genus' );
		$this->db->from ( 'adultsurveillancedetails' );
		$this->db->join ( 'mosquitospecies', 'adultsurveillancedetails.idmosquitospecies = mosquitospecies.idmosquitospecies', 'LEFT' );
		$this->db->join ( 'genuses AS g', 'mosquitospecies.idgenus = g.idgenus', 'INNER' );
		$this->db->where ( 'adultsurveillancedetails.idadultsurveillance', $Id );
		$this->db->order_by ( 'g.genus', 'asc' );
		$this->db->order_by ( 'mosquitospecies.mosquitospecies', 'asc' );
		$this->str = '';
		$query = $this->db->get ();
		// echo $this->db->last_query();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$sel_species [] = $row;
			}
		}
		// die;
		return $sel_species;
	}
	
	/**
	 * Function to fetch Species Name
	 */
	public function getSpecies($id = '') {
		$this->db->select ( 'm.*,lms.*,g.genus' );
		$this->db->from ( 'mosquitospecies AS m' );
		$this->db->join ( 'genuses AS g', 'm.idgenus = g.idgenus', 'INNER' );
		$this->db->join ( 'locationmosquitospecies AS lms', 'm.idmosquitospecies = lms.idmosquitospecies', 'INNER' );
		$this->db->where ( 'lms.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->order_by ( 'g.genus', 'asc' );
		$this->db->order_by ( 'm.mosquitospecies', 'asc' );
		
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) { // $row['idmosquitospecies']
				$result [$i] ['idspecies'] = $row ['idmosquitospecies'];
				$result [$i] ['species'] = $row ['mosquitospecies'];
				$result [$i] ['genus'] = $row ['genus'];
				$i ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to fetch Species Count
	 */
	public function getExistingSpecies($Id) {
		$this->db->select ( 'idmosquitospecies,count' );
		$this->db->from ( 'adultsurveillancedetails' );
		$this->db->where ( 'ad.idadultsurveillance', $Id );
		
		$query = $this->db->get ();
		$result = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$result [$row ['idmosquitospecies']] = $row ['count'];
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to fetch history Count
	 */
	public function getHistory($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( 'ad.idtrap' );
		$this->db->from ( 'adultsurveillance AS ad' );
		$this->db->where ( 'ad.idadultsurveillance', $Id );
		
		$q = $this->db->get ();
		$idtrap = "";
		
		if ($q->num_rows () > 0) {
			$idtrap = $q->result_array ();
			$idtrap = $idtrap [0] ['idtrap'];
		}
		
		$this->db->select ( 't.trap , t.idsite, tt.traptype , ad.pudate , ad.putime , ad.idadultsurveillance' );
		$this->db->from ( 'adultsurveillance AS ad' );
		$this->db->join ( 'traps AS t', 'ad.idtrap = t.idtrap', 'LEFT' );
		$this->db->join ( 'sites AS s', 's.idsite = t.idsite', 'LEFT' );
		$this->db->join ( 'traptypes AS tt', 't.idtraptype = tt.idtraptype', 'LEFT' );
		
		$this->db->where ( 'ad.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$this->db->where ( 't.idtrap', $idtrap );
		$this->db->order_by ( "ad.pudate", "DESC" );
		$data_1 = array ();
		
		$query = $this->db->get ();
		// echo $this->db->last_query();
		// die;
		$result = array ();
		
		// print'<pre>';
		// print_r($query->result_array());
		// die;
		$i = 0;
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->db->select ( 'm.idmosquitospecies , m.mosquitospecies, adst.count, (adst.count*100/(SELECT sum(adst.count) FROM adultsurveillancedetails AS adst WHERE adst.idadultsurveillance = ad.idadultsurveillance)) AS count_percent,(SELECT sum(ad.totalcount) FROM adultsurveillance AS ad WHERE adst.idadultsurveillance = ad.idadultsurveillance) AS total_count' );
				$this->db->from ( 'adultsurveillance AS ad' );
				$this->db->join ( 'adultsurveillancedetails AS adst', 'ad.idadultsurveillance = adst.idadultsurveillance', 'LEFT' );
				$this->db->join ( 'mosquitospecies AS m', 'adst.idmosquitospecies = m.idmosquitospecies', 'LEFT' );
				$this->db->where ( 'ad.idadultsurveillance', $row ['idadultsurveillance'] );
				
				$q1 = $this->db->get ();
				$data_1 [$i] = $row;
				if ($q1->num_rows () > 0) {
					// print'<pre>';
					// print_r($q1->result_array());
					// die;
					$data_1 [$i] ['species'] = $q1->result_array ();
				}
				$i ++;
			}
		}
		
		// print'<pre>';
		// print_r($data_1);
		// die;
		if (! empty ( $data_1 ))
			return $data_1;
		
		return false;
	}
	
	/**
	 * Function to fetch Species Count
	 */
	public function getSpeciesCount($Id = '', $Id2) {
		$this->db->select ( 'm.*,lms.*,g.genus' );
		$this->db->from ( 'mosquitospecies AS m' );
		$this->db->join ( 'genuses AS g', 'm.idgenus = g.idgenus', 'INNER' );
		$this->db->join ( 'locationmosquitospecies AS lms', 'm.idmosquitospecies = lms.idmosquitospecies', 'INNER' );
		$this->db->where ( 'lms.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->order_by ( 'g.genus', 'asc' );
		$this->db->order_by ( 'm.mosquitospecies', 'asc' );
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$j = 0;
			foreach ( $query->result_array () as $row ) {
				$this->db->select ( 'ad.idmosquitospecies,ad.count' );
				$this->db->from ( 'adultsurveillancedetails AS ad' );
				$this->db->where ( 'ad.idmosquitospecies', $row ['idmosquitospecies'] );
				if (! empty ( $Id2 ))
					$this->db->where ( 'ad.idadultsurveillance', $Id2 );
				
				$q = $this->db->get ();
				
				if ($q->num_rows () > 0) {
					$r = $q->result_array ();
					// print_r($r);
					// die;
					$result [$j] ['count'] = $r [0] ['count'];
				} else
					$result [$j] ['count'] = 0;
				
				$result [$j] ['genus'] = $row ['genus'];
				$result [$j] ['species'] = $row ['mosquitospecies'];
				$result [$j] ['idspecies'] = $row ['idmosquitospecies'];
				
				$j ++;
			}
		}
		// print'<pre>';
		// print_r($result);
		// die;
		return $result;
	}
	
	/**
	 * Function to fetch Species Count
	 */
	public function getSpeciesCountbydate($Id) {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( 'm.idmosquitospecies,m.mosquitospecies,ad.count' );
		$this->db->from ( 'mosquitospecies AS m' );
		$this->db->join ( 'adultsurveillancedetails AS ad', 'm.idmosquitospecies = ad.idmosquitospecies', "LEFT" );
		$this->db->where ( 'ad.idadultsurveillance', $Id );
		
		$query = $this->db->get ();
		$result = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$result [$row ['idmosquitospecies']] [] = $row ['mosquitospecies'];
				$result [$row ['idmosquitospecies']] [] = $row ['count'];
			}
		}
		
		return $result;
	}
}
