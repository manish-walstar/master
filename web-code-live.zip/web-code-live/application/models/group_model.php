<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Group_model extends CI_Model {
	public $data = array ();
	public $str = "";
	public $set_pwd = "";
	
	/**
	 * Constructor for the class
	 * User
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to Add a new User Group
	 */
	public function addGroup($req = '') {
		$id = '';
		$data ['usergroup'] = $this->input->post ( 'name' );
		$data ['description'] = $this->input->post ( 'description' );
		$data ['idlocation'] = $this->session->userdata ( 'idlocation' );
		
		if (! empty ( $req ) && $req > 0) {
			$this->db->select ( '*' );
			$this->db->from ( 'usergroups' );
			
			$this->db->where ( 'idusergroup', $req );
			
			$q = $this->db->get ();
			
			if ($q->num_rows () > 0) {
				$this->db->where ( 'idusergroup', $req );
				$this->db->update ( 'usergroups', $data );
			}
			
			$id = $req;
		} else {
			$this->db->select ( '*' );
			$this->db->from ( 'usergroups' );
			$this->db->where ( 'idusergroup', $id );
			
			$q = $this->db->get ();
			if ($q->num_rows () > 0) {
				$this->db->where ( 'idusergroup', $id );
				$this->db->update ( 'usergroups', $data );
			} else {
				$this->db->insert ( 'usergroups', $data );
				$id = $this->db->insert_id ();
				$req = $id;
			}
		}
		
		if (empty ( $id ))
			return false;
		
		return $id;
	}
	
	/**
	 * Function to Add a new Site Group
	 */
	public function addSiteGroup($req = '') {
		$id = '';
		$data ['sitegroup'] = $this->input->post ( 'name' );
		$data ['description'] = $this->input->post ( 'description' );
		$data ['idlocation'] = $this->session->userdata ( 'idlocation' );
		
		if (! empty ( $req ) && $req > 0) {
			$this->db->select ( '*' );
			$this->db->from ( 'sitegroups' );
			
			$this->db->where ( 'idsitegroup', $req );
			
			$q = $this->db->get ();
			
			if ($q->num_rows () > 0) {
				$this->db->where ( 'idsitegroup', $req );
				$this->db->update ( 'sitegroups', $data );
			}
			
			$id = $req;
		} else {
			$this->db->select ( '*' );
			$this->db->from ( 'sitegroups' );
			$this->db->where ( 'idsitegroup', $id );
			
			$q = $this->db->get ();
			if ($q->num_rows () > 0) {
				$this->db->where ( 'idvgroup', $id );
				$this->db->update ( 'sitegroups', $data );
			} else {
				$this->db->insert ( 'sitegroups', $data );
				$id = $this->db->insert_id ();
				$req = $id;
			}
		}
		
		if (empty ( $id ))
			return false;
		
		return $id;
	}
	
	/**
	 * Function to delete Group
	 */
	public function deleteGroup($id = '', $type = '') {
		if (empty ( $id ))
			return null;
		
		if (! empty ( $type ) && $type == "site") {
			$this->db->select ( '*' );
			$this->db->from ( 'sitegroups' );
			$this->db->where ( 'idsitegroup', $id );
		} else {
			$this->db->select ( '*' );
			$this->db->from ( 'usergroups' );
			$this->db->where ( 'idusergroup', $id );
		}
		
		$q = $this->db->get ();
		if ($q->num_rows () > 0) {
			$data ['isdeleted'] = '1';
			if (! empty ( $type ) && $type == "site") {
				$this->db->where ( 'idsitegroup', $id );
				$this->db->update ( 'sitegroups', $data );
			} else {
				$this->db->where ( 'idusergroup', $id );
				$this->db->update ( 'usergroups', $data );
			}
		}
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ) && empty ( $id ))
			return false;
		
		return $id;
	}
	
	/**
	 * Function to list all Group
	 */
	public function listGroup($type = '') {
		if (! empty ( $type ) && $type == "site") {
			$this->db->select ( '*' );
			$this->db->from ( 'sitegroups' );
			$this->db->join ( 'locations', 'sitegroups.idlocation = locations.idlocation', 'LEFT' );
			$this->db->where ( 'sitegroups.idlocation', $this->session->userdata ( 'idlocation' ) );
			// $this->db->order_by('sitegroups.sitegroup' , 'ASC');
			$orderby = $this->input->get ( 'orderby' );
			if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
				switch ($orderby) {
					case '1:asc' :
						$this->db->order_by ( 'sitegroups.sitegroup', 'ASC' );
						break;
					case '1:desc' :
						$this->db->order_by ( 'sitegroups.sitegroup', 'DESC' );
						break;
					case '2:asc' :
						$this->db->order_by ( 'sitegroups.description', 'ASC' );
						break;
					case '2:desc' :
						$this->db->order_by ( 'sitegroups.description', 'DESC' );
						break;
				}
			}
			$this->db->where ( 'sitegroups.isdeleted', '0' );
		} else {
			$this->db->select ( '*' );
			$this->db->from ( 'usergroups' );
			$this->db->join ( 'locations', 'usergroups.idlocation = locations.idlocation', 'LEFT' );
			$this->db->where ( 'usergroups.idlocation', $this->session->userdata ( 'idlocation' ) );
			// $this->db->order_by('usergroups.usergroup' , 'ASC');
			$orderby = $this->input->get ( 'orderby' );
			if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
				switch ($orderby) {
					case '1:asc' :
						$this->db->order_by ( 'usergroups.usergroup', 'ASC' );
						break;
					case '1:desc' :
						$this->db->order_by ( 'usergroups.usergroup', 'DESC' );
						break;
					case '2:asc' :
						$this->db->order_by ( 'usergroups.description', 'ASC' );
						break;
					case '2:desc' :
						$this->db->order_by ( 'usergroups.description', 'DESC' );
						break;
				}
			}
			$this->db->where ( 'usergroups.isdeleted', '0' );
		}
		/*
		 * $ttl = $this->input->get('ttl');
		 * $page = $this->input->get('page');
		 *
		 * if(!isset($ttl) || $ttl == '')
		 * $ttl = 10;
		 *
		 * if(!isset($page) || $page == '')
		 * $page = 1;
		 *
		 * if(!is_null($ttl) && !is_null($page))
		 * {
		 * if($page == 1)
		 * $page = 0;
		 * else
		 * $page--;
		 *
		 * $page *= 10;
		 * $this->db->limit($ttl ,$page);
		 * }
		 * else if(!is_null($ttl))
		 * {
		 * $this->db->limit($ttl);
		 * }
		 */
		$query = $this->db->get ();
		$result = array ();
		$i = 0;
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $key => $val ) {
				$result [$i] = $val;
				$i ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to fetch particular Group
	 */
	public function getGroupData($id = '', $type = '') {
		if (empty ( $id ))
			return null;
		
		$data_1 = array ();
		
		if (! empty ( $type ) && $type == "site") {
			$this->db->select ( '*' );
			$this->db->from ( 'sitegroups' );
			$this->db->order_by ( 'sitegroups.sitegroup', 'ASC' );
			$this->db->where ( 'idsitegroup', $id );
		} else {
			$this->db->select ( '*' );
			$this->db->from ( 'usergroups' );
			$this->db->order_by ( 'usergroups.usergroup', 'ASC' );
			$this->db->where ( 'idusergroup', $id );
		}
		
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$data_1 = $row;
			}
		}
		
		return $data_1;
	}
	
	/**
	 * Function to check for the existence of group
	 */
	public function groupExist($str = '', $type = '', $id = '') {
		if (empty ( $str ))
			return false;
		
		if (! empty ( $type ) && $type == "site") {
			$this->db->select ( '*' );
			$this->db->from ( 'sitegroups' );
			$this->db->where ( 'sitegroup', $str );
			if (! empty ( $id ))
				$this->db->where ( 'idsitegroup!=', $id );
		} else {
			$this->db->select ( '*' );
			$this->db->from ( 'usergroups' );
			$this->db->where ( 'usergroup', $str );
			if (! empty ( $id ))
				$this->db->where ( 'idusergroup!=', $id );
		}
		
		$this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0)
			return true;
		
		return false;
	}
}

?>