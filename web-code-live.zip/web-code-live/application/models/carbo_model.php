<?php

if (! defined ( "BASEPATH" ))
    exit ( "No direct script access allowed" );
    error_reporting ( 0 );
    date_default_timezone_set ( 'UTC' );
    /**
     * Carbo_model
     *
     * @package
     *
     * @author Skysoft Incorporated
     * @copyright 2014
     * @version $Id$
     * @access public
     */
    class Carbo_model extends CI_Model {
        // Types
        public $sitename = "";
        private $types = array (
            1 => 'integer',
            2 => 'string',
            3 => 'boolean',
            4 => '1-n',
            5 => 'text',
            6 => 'multilang',
            7 => 'n-m',
            8 => 'date',
            9 => 'datetime',
            10 => 'file'
        );
        public $date_arr = array (
            "adultsurveillance",
            "arbovirallabs",
            "corvidlabs",
            "sentinelchickenlabs",
            "landingrates",
            "servicerequests",
            "larvaltreatments",
            "adulticidetreatments",
            "larvalsurveillance",
            "weather",
            "maintenanceinspection",
            "outfallinspection" ,
            "missionskytracker"
        )
        ;
        public $cond_sarr = array (
            "sentinelchicken",
            "weathersensors",
            "larvaltreatments",
            "adulticidetreatments"
        );
        public $cond_all_sarr = array (
            "traps",
            "larvalsurveillance",
            "corvidlabs",
            "landingrates"
        );
        public $cond_tarr = array (
            "arbovirallabs"
        );
        public $cond_larr = array (
            "sentinelchickenlabs",
            "sentinelchickensamples"
        );
        public $cond_warr = array (
            "weather"
        );
        public $cond_marr = array (
            "monitormgmt",
            "servicerequests"
        );
        public $cond_xarr = array (
            "zones"
        );
        public $cond_deleted_arr = array (
            "users",
            "products",
            "monitormgmt"
        );
        public $previous_page_record;
        /**
         * Constructor
         */
        function __construct() {
            parent::__construct ();
        }
        
        /**
         * Get table dropdown
         */
        function get_table_dropdown($table, $id_name, $field_main, $type, $filters = array()) {
            $data = array (
                "" => lang ( "cg_select" )
            );
            
            $this->db->from ( "{$table} {$table}_main" );
            $this->db->select ( "{$table}_main.{$id_name} AS id" );
            $this->db->select ( "{$table}_main.{$field_main} AS field" );
            
            $query = $this->db->get ();
            
            if ($query->num_rows () > 0) {
                foreach ( $query->result () as $row ) {
                    $data [$row->id] = $row->field;
                }
            }
            return $data;
        }
        
        /**
         * Get items
         */
        function get_items($table, $id_name, $fields = NULL, $item_id = NULL, $filters = array(), $limit = NULL, $offset = 0, $order = NULL, $ref_ids = FALSE, $filter_date = NULL, $table1_rel = NULL, $filter_site = NULL, $filter_daterange = NULL, $filter_lab = NULL, $filter_trap = NULL, $filter_city = NULL, $filter_status = NULL, $service_rqstid = NULL, $idsentinel = NULL, $futureassign = NULL, $pendingassign = NULL, $filter_sitetype = NULL, $filter_siteofinterest = NULL, $page=NULL, $filter_wanum = NULL) {
            $data = array ();
            $columnno = '';
            $site_condition = NULL;
            // print'<pre>';
            //      print_r($fields);
            //      print'</pre>';
            //      die;
            
            if ($table == "sites" && ! is_null ( $filter_site )) {
                $this->db->select ( 'idsite,site' );
                $this->db->from ( 'sites AS s' );
                $this->db->where ( 'idsite', $filter_site );
                
                $q = $this->db->get ();
                
                if ($q->num_rows () > 0) {
                    $this->sitename = $q->result_array ();
                    $this->sitename = $this->sitename [0] ['site'];
                }
            }
            
            
            if (count ( $fields )) {
                // $this->db->from("{$table} {$table}_main");
                // $this->db->select("{$table}_main.{$id_name} AS id");
                $this->db->from ( "{$table}" );
                if ($table != 'servicerequests' && $table != 'corvidlabs')
                    $this->db->select ( "{$table}.{$id_name}" );
                    $join = 0;
                    $multilang = FALSE;
                    $flag = "";
                    $flag_n = "";
                    $tbl_arr = array ();
                    $check = 0;
                    $flag2 = "";
                    $flag_1_1_1 = "";
                    $flag_1_1_1_1 = "";
                    $flag_1_1_2 = "";
                    $flag_1_2_1 = "";
                    $flag_1_1_1_2 = "";
                    $flag_1_2_1_1 = "";
                    $flag_1_3_1_1 = "";
                    $flag_1_2_3 = "";
                    $flag_t = "";
                    $filter_date1 = "";
                    $filter_lab_table = "labresults.labresult";
                    
                    foreach ( $fields as $field ) {
                        // print'<pre>';
                        // print_r($tbl_arr);
                        // print'</pre>';
                        if (! in_array ( $table, $tbl_arr )) {
                            $tbl_arr [] = $table;
                        }
                        switch ($field->type) {
                            // Reference
                            case '1-n' :
                                $id1 = $table . "." . $field->db_name;
                                $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                                
                                if (! in_array ( $field->ref_table_db_name, $tbl_arr )) {
                                    $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "LEFT" );
                                    $tbl_arr [] = $field->ref_table_db_name;
                                }
                                // $this->db->select("{$field->ref_table_db_name}_join{$join}.{$field->ref_field_db_name} AS `{$field->unique_name}`");
                                $this->db->select ( "{$field->ref_table_db_name}.{$field->ref_field_db_name} AS `{$field->unique_name}`" );
                                
                                $field->table_name = $field->ref_table_db_name; // . "_join" . $join;
                                $field->order_name = $field->ref_field_db_name;
                                
                                $flag = $field->ref_table_db_name;
                                $flag_n = $field->ref_table_db_name;
                                $join ++;
                                // Select foreign keys as well
                                if ($ref_ids) {
                                    // $this->db->select("{$table}_main.{$field->db_name} AS `{$field->db_name}`");
                                    $this->db->select ( "{$table}.{$field->db_name} AS `{$field->unique_name}_id`" );
                                }
                                
                                // die;
                                if (! is_null ( $filter_lab ) && $filter_lab_table == "{$field->ref_table_db_name}.{$field->ref_field_db_name}") {
                                    // echo "here".$filter_lab ." "."{$field->ref_table_db_name}.{$field->ref_field_db_name}";
                                    switch ($filter_lab) {
                                        case '1' :
                                            $this->db->where ( "{$field->ref_table_db_name}.{$field->ref_field_db_name}", "Positive" );
                                            break;
                                        case '2' :
                                            $this->db->where ( "{$field->ref_table_db_name}.{$field->ref_field_db_name}", "Negative" );
                                            break;
                                        case '3' :
                                            $this->db->where ( "{$field->ref_table_db_name}.{$field->ref_field_db_name}", "Pending" );
                                            break;
                                    }
                                }
                                
                                if (preg_match_all ( '/date/', $field->ref_field_db_name, $matches )) {
                                    $filter_date1 = "{$field->ref_table_db_name}.{$field->ref_field_db_name}";
                                }
                                break;
                            case 'n-1' :
                                $id1 = $table . "." . $field->ref_table_id_name;
                                
                                // $id2 = $field->ref_table_db_name . "_join" . $join . ".{$field->ref_table_id_name}";
                                // $this->db->join("{$field->ref_table_db_name} {$field->ref_table_db_name}_join{$join}", $id1 . " = " . $id2, "left");
                                $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                                
                                $this->db->select ( $table . "." . $field->db_name );
                                
                                if (! in_array ( $field->ref_table_db_name, $tbl_arr )) {
                                    $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                                    if ($table != "sentinelchickensamples")
                                        $this->db->where ( $id2, "{$field->ref_table_id_val}" );
                                        $tbl_arr [] = $field->ref_table_db_name;
                                }
                                // $this->db->select("{$field->ref_table_db_name}_join{$join}.{$field->ref_field_db_name} AS `{$field->unique_name}`");
                                
                                $field->table_name = $table . "." . $field->ref_table_id_name; // . "_join" . $join;
                                $field->order_name = $table . "." . $field->ref_table_id_name;
                                $flag = $field->ref_table_id_name;
                                
                                $join ++;
                                // Select foreign keys as well
                                if ($ref_ids) {
                                    // $this->db->select("{$table}_main.{$field->db_name} AS `{$field->db_name}`");
                                    $this->db->select ( "{$table}.{$field->db_name} AS `{$field->unique_name}_id`" );
                                }
                                
                                if (preg_match_all ( '/date/', $field->ref_field_db_name, $matches )) {
                                    $filter_date1 = "{$field->ref_table_db_name}.{$field->ref_field_db_name}";
                                }
                                break;
                            case '1+2' :
                                $field1 = $table . "." . $field->db_name_1;
                                $field2 = $table . "." . $field->db_name_2;
                                $prefix = substr($table, 0, 2);
                                
                                $this->db->select ( "$field1 AS `$prefix$field->db_name_1`,$field2 AS `$prefix$field->db_name_2`" );
                                $field->table_name = $table;
                                $field->order_name = $field->db_name_1;
                                if (! empty ( $filter_date )) {
                                    if (preg_match_all ( '/date/', $field1, $matches )) {
                                        $filter_date1 = $field1;
                                    }
                                }
                                
                                break;
                            case '1+2+3+4+5' :
                                $field1 = $table . "." . $field->db_name_1;
                                
                                $field2 = $table . "." . $field->db_name_2;
                                
                                $field3 = $table . "." . $field->db_name_3;
                                
                                $field4 = $table . "." . $field->db_name_4;
                                
                                $field5 = $table . "." . $field->db_name_5;
                                
                                $this->db->select ( "$field1 AS `$field->db_name_1`,$field2 AS `$field->db_name_2`,$field3 AS `$field->db_name_3`,$field4 AS `$field->db_name_4`,$field5 AS `$field->db_name_5`" );
                                
                                $field->table_name = $table;
                                $field->order_name = $field->db_name_1;
                                
                                break;
                                
                            case 'dispositionjoin' :
                                
                                break;
                            case '1-(1+2)-1-1' :
                                $id1 = $table . "." . $field->db_name;
                                
                                $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                                
                                $id3 = $field->ref_table_db_name . "." . $field->ref_table_1_id_name;
                                
                                $id4 = $field->ref_table_1_db_name . "." . $field->ref_table_1_id_name;
                                
                                if (! in_array ( $field->ref_table_db_name, $tbl_arr )) {
                                    $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                                    $tbl_arr [] = $field->ref_table_db_name;
                                }
                                
                                if (! in_array ( $field->ref_table_1_db_name, $tbl_arr )) {
                                    $this->db->join ( "{$field->ref_table_1_db_name}", $id3 . " = " . $id4, "left" );
                                    $tbl_arr [] = $field->ref_table_1_db_name;
                                }
                                
                                $this->db->select ( "{$field->ref_table_db_name}.{$field->ref_field_db_name},{$field->ref_table_db_name}.{$field->ref_field_1_db_name},{$field->ref_table_1_db_name}.{$field->ref_field_1_1_db_name}" );
                                
                                $field->table_name = $field->ref_table_db_name;
                                $field->order_name = $field->ref_field_db_name;
                                
                                $flag = $field->ref_table_db_name;
                                
                                $flag_1_3_1_1 = $field->ref_table_db_name;
                                
                                $flag2 = $field->ref_table_1_db_name;
                                
                                $flag_1_2_1_1 = $field->ref_table_1_db_name;
                                
                                break;
                            case '1-(1+2+3)-1-1' :
                                $id1 = $table . "." . $field->db_name;
                                
                                $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                                
                                $id3 = $field->ref_table_db_name . "." . $field->ref_table_1_id_name;
                                
                                $id4 = $field->ref_table_1_db_name . "." . $field->ref_table_1_id_name;
                                
                                if (! in_array ( $field->ref_table_db_name, $tbl_arr )) {
                                    $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                                    $tbl_arr [] = $field->ref_table_db_name;
                                }
                                
                                if (! in_array ( $field->ref_table_1_db_name, $tbl_arr )) {
                                    $this->db->join ( "{$field->ref_table_1_db_name}", $id3 . " = " . $id4, "left" );
                                    $tbl_arr [] = $field->ref_table_1_db_name;
                                }
                                
                                $this->db->select ( "{$field->ref_table_db_name}.{$field->ref_field_db_name},{$field->ref_table_db_name}.{$field->ref_field_1_db_name},{$field->ref_table_db_name}.{$field->ref_field_2_db_name},{$field->ref_table_1_db_name}.{$field->ref_field_1_1_db_name}" );
                                
                                $field->table_name = $field->ref_table_db_name;
                                $field->order_name = $field->ref_field_db_name;
                                
                                $flag = $field->ref_table_db_name;
                                
                                $flag_1_3_1_1 = $field->ref_table_db_name;
                                
                                $flag2 = $field->ref_table_1_db_name;
                                
                                $flag_1_2_1_1 = $field->ref_table_1_db_name;
                                break;
                            case '1-(1+2+3)-1-1-PWA-CA' :
                                $field_PWA_CA_ADD = $table . "." . $field->db_name;
                                
                                $this->db->select ( "$field_PWA_CA_ADD AS `$field->db_name`" );
                                break;
                            case '1-(1+2+3)-1-1-PWA-CA-COMM' :
                                $field_PWA_CA_ADD_COMM = $table . "." . $field->db_name;
                                
                                $this->db->select ( "$field_PWA_CA_ADD_COMM AS `$field->db_name`" );
                                break;
                            case '1-1+2' :
                                
                                $id1 = $table . "." . $field->db_name;
                                
                                $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                                
                                if (! in_array ( $field->ref_table_db_name, $tbl_arr )) {
                                    $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                                }
                                
                                $this->db->select ( "{$field->ref_table_db_name}.{$field->ref_field_db_name},{$field->ref_table_db_name}.{$field->ref_field_2_db_name}" );
                                
                                $field->table_name = $field->ref_table_db_name;
                                $field->order_name = $field->ref_field_db_name;
                                
                                $flag = $field->ref_table_db_name;
                                
                                $flag_1_2_1 = $field->ref_table_db_name;
                                
                                $tbl_arr [] = $field->ref_table_db_name;
                                
                                break;
                            case '1-1+2+3' :
                                
                                $id1 = $table . "." . $field->db_name;
                                
                                $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                                
                                if (! in_array ( $field->ref_table_db_name, $tbl_arr )) {
                                    $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                                }
                                
                                $this->db->select ( "{$field->ref_table_db_name}.{$field->ref_field_db_name},{$field->ref_table_db_name}.{$field->ref_field_2_db_name},{$field->ref_table_db_name}.{$field->ref_field_3_db_name}" );
                                
                                $field->table_name = $field->ref_table_db_name;
                                $field->order_name = $field->ref_field_db_name;
                                
                                $flag = $field->ref_table_db_name;
                                
                                $flag_1_2_3 = $field->ref_table_db_name;
                                
                                $tbl_arr [] = $field->ref_table_db_name;
                                
                                break;
                            case '1-1-(1)-(2)' :
                                $id1 = $table . "." . $field->db_name;
                                
                                $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                                
                                $id2_1 = $field->ref_table_db_name . "." . $field->ref_table_1_id_name;
                                
                                $id3 = $field->ref_table_1_db_name . "." . $field->ref_table_1_id_name;
                                
                                if (! in_array ( $field->ref_table_db_name, $tbl_arr )) {
                                    $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                                }
                                
                                if (! in_array ( $field->ref_table_1_db_name, $tbl_arr )) {
                                    $this->db->join ( "{$field->ref_table_1_db_name}", $id2_1 . " = " . $id3, "left" );
                                }
                                
                                $this->db->select ( "{$field->ref_table_db_name}.{$field->ref_field_db_name},{$field->ref_table_1_db_name}.{$field->ref_field_1_db_name}" );
                                $field->table_name = $field->ref_table_db_name; // . "_join" . $join;
                                $field->order_name = $field->ref_field_db_name;
                                
                                $flag = $field->ref_table_db_name;
                                
                                $flag_1_1_1_1 = $field->ref_table_db_name;
                                
                                $flag2 = $field->ref_table_1_db_name;
                                
                                $flag_1_1_1_2 = $field->ref_table_1_db_name;
                                
                                $tbl_arr [] = $field->ref_table_db_name;
                                
                                $tbl_arr [] = $field->ref_table_1_db_name;
                                
                                break;
                            case '1-(1)-2' :
                                $id1 = $table . "." . $field->ref_table_id_name;
                                
                                $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                                
                                if (! in_array ( $field->ref_table_db_name, $tbl_arr )) {
                                    $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                                }
                                
                                $this->db->select ( "{$field->db_name},{$field->ref_table_db_name}.{$field->ref_field_db_name}" );
                                $field->table_name = $table; // . "_join" . $join;
                                $field->order_name = $field->db_name;
                                $flag = $field->ref_table_db_name;
                                $flag_1_1_2 = $field->ref_table_db_name;
                                $tbl_arr [] = $field->ref_table_db_name;
                                break;
                            case '1-t' :
                                
                                $id1 = $table . "." . $field->db_name;
                                
                                $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                                
                                if (! in_array ( $field->ref_table_db_name, $tbl_arr )) {
                                    $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                                }
                                
                                $this->db->select ( "sum({$field->ref_table_db_name}.{$field->ref_field_db_name}) AS count " );
                                $field->table_name = $field->ref_table_db_name;
                                $field->order_name = $field->ref_field_db_name;
                                $check = 1;
                                $flag = $field->ref_table_db_name;
                                $flag_t = $field->ref_table_db_name;
                                $tbl_arr [] = $field->ref_table_db_name;
                                break;
                            case '1-1-1' :
                                $id1 = $table . "." . $field->db_name;
                                // $id2 = $field->ref_table_db_name . "_join" . $join . ".{$field->ref_table_id_name}";
                                // $this->db->join("{$field->ref_table_db_name} {$field->ref_table_db_name}_join{$join}", $id1 . " = " . $id2, "left");
                                $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                                if (! in_array ( $field->ref_table_db_name, $tbl_arr )) {
                                    $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                                }
                                
                                $id2_1 = $field->ref_table_db_name . "." . $field->ref_table_id2_name;
                                $id3 = $field->ref_table_db2_name . "." . $field->ref_table_id2_name;
                                
                                if (! in_array ( $field->ref_table_db2_name, $tbl_arr )) {
                                    $this->db->join ( "{$field->ref_table_db2_name}", $id2_1 . " = " . $id3, "left" );
                                    $tbl_arr [] = $field->ref_table_db2_name;
                                }
                                
                                $this->db->select ( "{$field->ref_table_db2_name}.{$field->ref_field_db2_name} AS `{$field->reference_uniq_name}`" );
                                
                                if ($field->ref_table_db2_name == 'zones') {
                                    $field->table_name = $field->ref_table_db2_name; // . "_join" . $join;
                                    $field->order_name = $field->ref_field_db2_name;
                                } else {
                                    $field->table_name = $field->ref_table_db_name; // . "_join" . $join;
                                    $field->order_name = $field->ref_field_db_name;
                                }
                                
                                $flag = $field->ref_table_db_name;
                                $flag_1_1_1 = $field->ref_table_db_name;
                                $tbl_arr [] = $field->ref_table_db_name;
                                $join ++;
                                // Select foreign keys as well
                                if ($ref_ids) {
                                    // $this->db->select("{$table}_main.{$field->db_name} AS `{$field->db_name}`");
                                    $this->db->select ( "{$table}.{$field->db_name} AS `{$field->unique_name}_id`" );
                                }
                                break;
                            case '1-1+2+3-mission' :
                                
                                $id1 = $table . "." . $field->db_name;
                                
                                $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                                
                                // if (! in_array ( $field->ref_table_db_name, $tbl_arr )) {
                                $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                                // }
                                
                                $this->db->select ( "{$field->ref_table_db_name}.{$field->ref_field_db_name} AS '{$field->ref_field_db_name}'" );
                                
                                $field->table_name = $field->ref_table_db_name;
                                $field->order_name = $field->ref_field_db_name;
                                
                                $flag = $field->ref_table_db_name;
                                
                                $flag_1_2_3 = $field->ref_table_db_name;
                                
                                $tbl_arr [] = $field->ref_table_db_name;
                                
                                break;
                            default :
                                $field->table_name = $table; // . "_main";
                                $field->order_name = $field->db_name;
                                
                                if (! empty ( $filter_date )) {
                                    if ($table == 'servicerequests') {
                                        if (preg_match_all ( '/opendate/', $field->db_name, $matches )) {
                                            $filter_date1 = $table . "." . $field->db_name;
                                        }
                                    } else {
                                        if (preg_match_all ( '/date/', $field->db_name, $matches )) {
                                            $filter_date1 = $table . "." . $field->db_name;
                                        }
                                    }
                                }
                                
                                $this->db->select ( "{$table}.{$field->db_name} AS `{$field->unique_name}`" );
                        }
                    }
                    
                    // add additional condition when service request come
                    if (! empty ( $service_rqstid )) {
                        switch ($table) {
                            case 'larvalsurveillance' :
                                $table1_rel = 'larvalsurveillanceservice';
                                break;
                            case 'adultsurveillance' :
                                $table1_rel = 'adultsurveillanceservice';
                                break;
                        }
                        $additinal_var = $table . '.' . $id_name . '=' . $table1_rel . '.' . $id_name;
                        $this->db->where ( $table1_rel . '.idservicerequest', $service_rqstid );
                        $this->db->join ( $table1_rel, $additinal_var, 'INNER' );
                    } else if (! empty ( $_GET ['service_req_id'] )) {
                        switch ($table) {
                            case 'larvalsurveillance' :
                                $table1_rel = 'larvalsurveillanceservice';
                                break;
                            case 'adultsurveillance' :
                                $table1_rel = 'adultsurveillanceservice';
                                break;
                        }
                        $additinal_var = $table . '.' . $id_name . '=' . $table1_rel . '.' . $id_name;
                        $this->db->where ( $table1_rel . '.idservicerequest', $_GET ['service_req_id'] );
                        $this->db->join ( $table1_rel, $additinal_var, 'INNER' );
                    }
                    
                    if ($table == "users") {
                        $this->db->join ( 'userlocationassignment AS ula', "{$table}.{$id_name} = ula.iduser", 'LEFT' );
                        $this->db->join ( 'locations AS l', "ula.idlocation = l.idlocation", 'LEFT' );
                        
                        if (! empty ( $filters )) {
                            $this->db->where ( "ula.idlocation", $filters [0] ['value'] );
                        }
                    } else if (in_array ( "{$table}", $this->cond_sarr )) {
                        $this->db->join ( 'sites AS s', "{$table}.idsite = s.idsite", 'LEFT' );
                        $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                        
                        if (! empty ( $filters )) {
                            $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                        }
                    } else if (in_array ( "{$table}", $this->cond_all_sarr )) {
                        $this->db->join ( 'locations AS lcs', "sites.idlocation = lcs.idlocation", 'LEFT' );
                        
                        if (! empty ( $filters )) {
                            $this->db->where ( "sites.idlocation", $filters [0] ['value'] );
                        }
                    } else if (in_array ( "{$table}", $this->cond_warr )) {
                        $this->db->join ( 'weathersensors AS ws', "{$table}.idweathersensor = ws.idweathersensor", "LEFT" );
                        $this->db->join ( 'sites AS s', "ws.idsite = s.idsite", 'LEFT' );
                        $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                        
                        if (! empty ( $filters )) {
                            $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                        }
                    } else if (in_array ( "{$table}", $this->cond_tarr )) {
                        $this->db->join ( 'sites AS s', "traps.idsite = s.idsite", 'LEFT' );
                        $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                        
                        if (! empty ( $filters )) {
                            $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                        }
                    } else if (in_array ( "{$table}", $this->cond_larr ) && $table != 'sentinelchickensamples') {
                        $this->db->join ( 'sites AS s', "sentinelchicken.idsite = s.idsite", 'LEFT' );
                        $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                        
                        if (! empty ( $filters )) {
                            $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                        }
                    } else if (in_array ( "{$table}", $this->cond_larr ) && $table == 'sentinelchickensamples') {
                        $this->db->join ( 'sites AS s', "sentinelchicken.idsite = s.idsite", 'LEFT' );
                        $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                        
                        if (! empty ( $filters )) {
                            $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                        }
                    } else if (in_array ( "{$table}", $this->cond_marr )) {
                        // $this->db->join('locations AS l',"{$table}.GUID = l.GUID",'INNER');
                        //
                        // if(!empty($filters))
                        // {
                        // $this->db->where("l.idlocation", $filters[0]['value']);
                            // }
                        } else if (in_array ( "{$table}", $this->cond_xarr )) {
                            if (! empty ( $filters )) {
                                $this->db->where ( "{$table}.idlocation", $filters [0] ['value'] );
                            }
                        } else {
                            if (! empty ( $filters )) {
                                $this->db->join ( 'locations AS l', "{$table}.idlocation = l.idlocation", 'LEFT' );
                                $this->db->where ( "{$table}.idlocation", $filters [0] ['value'] );
                            }
                        }
                        
                        if (! is_null ( $item_id )) {
                            // $this->db->where("{$table}_main.{$id_name}", $item_id);
                            $this->db->where ( "{$table}.{$id_name}", $item_id );
                        }
                        if (is_null ( $filter_status ))
                            $filter_status = 3;
                            
                            $this->load->model('usermodel');
                            $data ['userId'] = $this->usermodel->getUserId();
                            
                            if (in_array ( $table, $this->date_arr ))
                                if (! is_null ( $filter_date ) && (empty ( $filter_daterange ) || (!empty ( $filter_daterange ) && isset ( $filter_daterange[0] )&& empty ( $filter_daterange[0]  ))) && empty ( $pendingassign ) && empty ( $futureassign )) {
                                    if ($table == "servicerequests" && ! is_null ( $filter_status )) {
                                        switch ($filter_status) {
                                            case '1' :
                                                $where = ' (servicerequests.closedate IS NULL OR servicerequests.closedate = "" OR  servicerequests.closedate = "0000-00-00")';
                                                $this->db->where ( $where );
                                                switch ($filter_date) {
                                                    case '1' :
                                                        $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
                                                        $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                        break;
                                                        
                                                    case '2' :
                                                        $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
                                                        $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                        break;
                                                    case '3' :
                                                        $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
                                                        $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                        break;
                                                    case '4' :
                                                        
                                                        $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
                                                        $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                        break;
                                                    case '5' :
                                                        $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
                                                        $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                        break;
                                                    case '6' :
                                                        $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) );
                                                        $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) );
                                                        break;
                                                }
                                                break;
                                            case '2' :
                                                $where = '(servicerequests.closedate IS NOT NULL AND servicerequests.closedate != "" AND servicerequests.closedate != "0000-00-00")';
                                                $this->db->where ( $where );
                                                switch ($filter_date) {
                                                    case '1' :
                                                        $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
                                                        $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                        break;
                                                        
                                                    case '2' :
                                                        $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
                                                        $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                        break;
                                                    case '3' :
                                                        $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
                                                        $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                        break;
                                                    case '4' :
                                                        
                                                        $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
                                                        $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                        break;
                                                    case '5' :
                                                        $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
                                                        $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                        break;
                                                    case '6' :
                                                        $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) );
                                                        $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) );
                                                        break;
                                                }
                                                break;
                                            case '3' :
                                                switch ($filter_date) {
                                                    case '1' :
                                                        $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
                                                        $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                        break;
                                                        
                                                    case '2' :
                                                        $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
                                                        $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                        break;
                                                    case '3' :
                                                        $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
                                                        $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                        break;
                                                    case '4' :
                                                        
                                                        $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
                                                        $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                        break;
                                                    case '5' :
                                                        $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
                                                        $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                        break;
                                                    case '6' :
                                                        $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) );
                                                        $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) );
                                                        break;
                                                }
                                                break;
                                        }
                                    } else {
                                        switch ($filter_date) {
                                            case '1' :
                                                $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
                                                $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                                                break;
                                                
                                            case '2' :
                                                $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
                                                $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                                                break;
                                            case '3' :
                                                $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
                                                $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                                                break;
                                            case '4' :
                                                
                                                $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
                                                $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                                                break;
                                            case '5' :
                                                $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
                                                $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                                                break;
                                            case '6' :
                                                $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) );
                                                $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) );
                                                break;
                                        }
                                    }
                                } else if (! empty ( $futureassign )) {
                                    switch ($filter_status) {
                                        case '1' :
                                            $where = ' (servicerequests.closedate IS NULL OR servicerequests.closedate = "" OR  servicerequests.closedate = "0000-00-00")';
                                            $this->db->where ( $where );
                                            break;
                                        case '2' :
                                            $where = '(servicerequests.closedate IS NOT NULL AND servicerequests.closedate != "" AND servicerequests.closedate != "0000-00-00")';
                                            $this->db->where ( $where );
                                            break;
                                        case '3' :
                                            break;
                                    }
                                    $this->db->where ( 'opendate >=', date ( 'Y-m-d' ) );
                                } else if (! empty ( $filter_daterange ) && isset($filter_daterange[0]) && !empty($filter_daterange[0])) {
                                    if ($table == "servicerequests")
                                        switch ($filter_status) {
                                            case '1' :
                                                $where = "(servicerequests.closedate = '' OR servicerequests.closedate IS NULL OR servicerequests.closedate ='0000-00-00')";
                                                $this->db->where ( $where );
                                                $this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) );
                                                $this->db->where ( 'servicerequests.closedate' . ' <=', date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) );
                                                break;
                                            case '2' :
                                                $where = "(servicerequests.closedate != '' AND servicerequests.closedate IS NOT NULL AND servicerequests.closedate !='0000-00-00')";
                                                $this->db->where ( $where );
                                                $this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) );
                                                $this->db->where ( 'servicerequests.closedate' . ' <=', date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) );
                                                break;
                                            case '3' :
                                                $this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) );
                                                $this->db->where ( 'servicerequests.closedate' . ' <=', date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) );
                                                break;
                                    }
                                }
                                
                                if (in_array ( $table, $this->date_arr ) && $table != "servicerequests")
                                    if (! empty ( $filter_daterange ) && isset($filter_daterange[0]) && !empty($filter_daterange[0]) && is_null ( $futureassign )) {
                                        $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) );
                                        $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) );
                                    }
                                
                                if ($table == "sites" && (! is_null ( $filter_site ) || ! is_null ( $filter_siteofinterest ))) {
                                    if (! empty ( $filter_site ))
                                        $this->db->where ( 'sites.idsite', $filter_site );
                                        if (! empty ( $filter_siteofinterest )) {
                                            $siteofinterest = explode ( "_", $filter_siteofinterest );
                                            $sitetemp = '';
                                            $or = '';
                                            foreach ( $siteofinterest as $key => $val ) {
                                                switch ($val) {
                                                    case '1' :
                                                        $sitetemp .= " sites.site_of_interest = '1'";
                                                        $or = ' OR';
                                                        break;
                                                    case '2' :
                                                        $sitetemp .= $or . " sites.landingrate_site = '1'";
                                                        $or = ' OR';
                                                        break;
                                                    case '3' :
                                                        $sitetemp .= $or . " sites.larval_site = '1'";
                                                        $or = ' OR';
                                                        break;
                                                    case '4' :
                                                        $sitetemp .= $or . " sites.adult_site = '1'";
                                                        $or = ' OR';
                                                        break;
                                                    case '5' :
                                                        $sitetemp .= $or . " sites.apiary = '1'";
                                                        $or = ' OR';
                                                        break;
                                                    case '6' :
                                                        $sitetemp .= $or . " sites.contact_before_spray = '1'";
                                                        $or = ' OR';
                                                        break;
                                                    case '7' :
                                                        $sitetemp .= $or . " sites.organic_farm = '1'";
                                                        $or = ' OR';
                                                        break;
                                                    case '8' :
                                                        $sitetemp .= $or . " sites.nospray = '1'";
                                                        $or = ' OR';
                                                        break;
                                                    case '9' :
                                                        $sitetemp .= $or . " sites.endangered_species = '1'";
                                                        $or = ' OR';
                                                        break;
                                                }
                                            }
                                            if (! empty ( $sitetemp )) {
                                                $sitetemp = "(" . trim ( $sitetemp, "OR" ) . ")";
                                                $this->db->where ( $sitetemp );
                                            }
                                        }
                                } else if ($table == "sites" && ! is_null ( $filter_sitetype )) {
                                    $this->db->where ( 'sites.idsitetype', $filter_sitetype );
                                }
                                
                                if ($table == "monitormgmt")
                                    $this->db->where ( 'monitormgmt.status', '0' );
                                    
                                    if ($table == "arbovirallabs" && ! is_null ( $filter_trap ))
                                        $this->db->like ( 'traps.trap', $filter_trap, 'after' );
                                        
                                        if ($table == "servicerequests") {
                                            if (! is_null ( $filter_city )) {
                                                $this->db->like ( 'sites.city', $filter_city, 'none' );
                                            }
                                            
                                            if (! empty ( $filter_wanum )) {
                                                $this->db->where ( 'servicerequests.idservicerequest = '.$filter_wanum);
                                            }
                                        }
                                        
                                        if ($table == "servicerequests") {
                                            if (! is_null ( $filter_city )) {
                                                $this->db->like ( 'sites.city', $filter_city, 'none' );
                                            }
                                            if (! empty ( $filter_wanum )) {
                                                $this->db->where ( 'servicerequests.idservicerequest = '.$filter_wanum);
                                            }
                                            
                                            if (! is_null ( $pendingassign )) {
                                                $this->db->where ( "servicerequests.isapproved = '0'" );
                                                $this->db->where ( "servicerequests.idlocation", $this->session->userdata ( 'idlocation' ) );
                                            } else
                                                $this->db->where ( "sites.idlocation", $this->session->userdata ( 'idlocation' ) );
                                        }
                                        
                                        if (! empty ( $idsentinel ) && $table == "sentinelchickensamples") {
                                            $this->db->where ( "sentinelchicken.idsentinelchicken", $idsentinel );
                                        }
                                        
                                        if ($table == "monitormgmt") {
                                            $this->db->join ( 'locations AS l', 'monitormgmt.GUID = l.GUID', 'INNER' );
                                            $this->db->where ( 'l.idlocation', $this->session->userdata ( 'idlocation' ) );
                                        }
                                        
                                        if (! is_null ( $order )) {
                                            foreach ( $order as $field_id => $dir ) {
                                                if ($fields [$field_id]->table_name == "sentinelchickensamples.idsentinelchicken") {
                                                    $ttable = explode ( ".", $fields [$field_id]->order_name );
                                                    $this->db->order_by ( "sentinelchickensamples.idscs", $dir );
                                                } else {
                                                    foreach ( $fields as $fkey => $field ) {
                                                        if ($fkey == $field_id)
                                                            switch ($field->type) {
                                                                case '1-n' :
                                                                    $this->db->order_by ( $field->where_name, $dir );
                                                                    break;
                                                                case 'n-1' :
                                                                    break;
                                                                case '1+2' :
                                                                    $this->db->order_by ( $field->where_name, $dir );
                                                                    $this->db->order_by ( $field->reference_where_name, $dir );
                                                                    break;
                                                                case '1+2+3+4+5' :
                                                                    break;
                                                                case '1-(1+2)' :
                                                                    $this->db->order_by ( $field->ref_table_db_name . "." . $field->ref_field_db_name, $dir );
                                                                    break;
                                                                case '1-(1+2+3)-1-1' :
                                                                    $this->db->order_by ( "SUBSTRING_INDEX($field->ref_table_db_name.$field->ref_field_db_name, ' ', 1) + 0", $dir );
                                                                    $this->db->order_by ( $field->ref_table_db_name . "." . $field->ref_field_1_db_name, $dir );
                                                                    $this->db->order_by ( $field->ref_table_db_name . "." . $field->ref_field_2_db_name, $dir );
                                                                    $this->db->order_by ( $field->ref_table_1_db_name . "." . $field->ref_field_1_1_db_name, $dir );
                                                                    break;
                                                                case '1-1+2' :
                                                                    $this->db->order_by ( $field->ref_table_db_name . "." . $field->ref_field_db_name, $dir );
                                                                    $this->db->order_by ( $field->ref_table_db_name . "." . $field->ref_field_2_db_name, $dir );
                                                                    break;
                                                                case '1-1+2+3' :
                                                                    $this->db->order_by ( $field->ref_table_db_name . "." . $field->ref_field_db_name, $dir );
                                                                    $this->db->order_by ( $field->ref_table_db_name . "." . $field->ref_field_2_db_name, $dir );
                                                                    $this->db->order_by ( $field->ref_table_db_name . "." . $field->ref_field_3_db_name, $dir );
                                                                    break;
                                                                case '1-1-(1)-(2)' :
                                                                    $this->db->order_by ( $field->ref_table_db_name . "." . $field->ref_field_db_name, $dir );
                                                                    $this->db->order_by ( $field->ref_table_1_db_name . "." . $field->ref_field_1_db_name, $dir );
                                                                    break;
                                                                case '1-(1)-2' :
                                                                    $this->db->order_by ( $field->ref_table_db_name . "." . $field->ref_field_db_name, $dir );
                                                                    break;
                                                                case 'dispositionjoin' :
                                                                    break;
                                                                case '1-t' :
                                                                    break;
                                                                case '1-1-1' :
                                                                    $this->db->order_by ( $field->ref_table_db2_name . "." . $field->ref_field_db2_name, $dir );
                                                                    break;
                                                                default :
                                                                    $this->db->order_by ( $field->where_name, $dir );
                                                                    break;
                                                        }
                                                    }
                                                }
                                                
                                                if ($table == "products" && $field_id == "0") {
                                                    $this->db->where ( "products.onhand >", '0' );
                                                }
                                            }
                                        }
                                        if ($check == 1)
                                            $this->db->group_by ( "{$table}.{$id_name}" );
                                            if (! is_null ( $limit )) {
                                                $this->db->limit ( $limit, $offset );
                                            }
                                            if (! in_array ( $table, $this->cond_deleted_arr ))
                                                $this->db->where ( $table . '.isdeleted', '0' );
                                                $query = $this->db->get ();
                                                //echo $this->db->last_query()."\n\n";die;
                                                //echo "num rows ". $query->num_rows();
                                                
                                                $pdata = array ();
                                                if ($table == "products" && $query->num_rows() < $limit) {
                                                    $cquery = $this->db->query ( "SELECT products.idproduct, products.productname AS `productname`, productpotency.potency AS `productpotency_potency`, productmanufacturers.manufacturer AS `productmanufacturers_manufacturer`, productsizes.productsize AS `productsizes_productsize`, packsizes.packsize AS `packsizes_packsize`, products.onhand AS `onhand` FROM (products) LEFT JOIN productpotency ON products.idpotency = productpotency.idpotency LEFT JOIN productmanufacturers ON products.idmanufacturer = productmanufacturers.idmanufacturer LEFT JOIN productsizes ON products.idproductsize = productsizes.idproductsize LEFT JOIN packsizes ON products.idpacksize = packsizes.idpacksize LEFT JOIN locations AS l ON products.idlocation = l.idlocation WHERE products.idlocation = '" . $this->session->userdata ( 'idlocation' ) . "' AND products.onhand > 0 ORDER BY products.productname ASC" );
                                                    
                                                    $cquery = $cquery->num_rows ();
                                                    
                                                    $cquery2 = $this->db->query ( "SELECT products.idproduct, products.productname AS `productname`, productpotency.potency AS `productpotency_potency`, productmanufacturers.manufacturer AS `productmanufacturers_manufacturer`, productsizes.productsize AS `productsizes_productsize`, packsizes.packsize AS `packsizes_packsize`, products.onhand AS `onhand` FROM (products) LEFT JOIN productpotency ON products.idpotency = productpotency.idpotency LEFT JOIN productmanufacturers ON products.idmanufacturer = productmanufacturers.idmanufacturer LEFT JOIN productsizes ON products.idproductsize = productsizes.idproductsize LEFT JOIN packsizes ON products.idpacksize = packsizes.idpacksize LEFT JOIN locations AS l ON products.idlocation = l.idlocation WHERE products.idlocation = '" . $this->session->userdata ( 'idlocation' ) . "' AND products.onhand = 0 ORDER BY products.productname ASC" );
                                                    
                                                    $cquery2 = $cquery2->num_rows ();
                                                    
                                                    $ttlrecords = $this->count_items ( $table, $id_name, $fields, $filters, $filter_date, $filter_site, $filter_daterange );
                                                    $ttlpage = ceil ( $ttlrecords / $limit );
                                                    
                                                    $currpage = $page;
                                                    if($cquery2 < $limit){
                                                        $nzero_rcrd_crrnt_page = 1;
                                                    } else {
                                                        $nzero_rcrd_crrnt_page = $cquery % $limit;
                                                    }
                                                    
                                                    if ($cquery > 1) {
                                                        $ttl_non_zero_page = floor ( $cquery / $limit );
                                                    }
                                                    $mixpage = 0;
                                                    if ($cquery2 > 1) {
                                                        $mixpage = $ttl_non_zero_page + 1;
                                                    }
                                                    //echo "ttlrecords : $ttlrecords \n";
                                                    //                echo "ttlpage : $ttlpage \n";
                                                    //                echo "cquery : $cquery \n";
                                                    //                echo "cquery2 : $cquery2 \n";
                                                    //                echo "mixpage : $mixpage \n";
                                                    //                echo "nzero_rcrd_crrnt_page : $nzero_rcrd_crrnt_page \n";
                                                    $cflag = 0;
                                                    for($i=1; $i<=$ttlpage; $i++){
                                                        if(!$cflag && $i == 1){
                                                            $this->previous_limit = $limit - $nzero_rcrd_crrnt_page - 1;
                                                            $this->previous_page_record = $this->previous_limit;
                                                            $cflag = 1;
                                                        }
                                                        
                                                        if($currpage == $mixpage){
                                                            $limit = $limit - $nzero_rcrd_crrnt_page - 1;
                                                            $query_limit = " LIMIT 0 ," . $limit;
                                                            break;
                                                        } else if($i > 1){
                                                            $this->previous_page_record += 1;
                                                            $this->previous_limit = $this->previous_page_record + $limit;
                                                            if($currpage == $i){
                                                                $query_limit = " LIMIT ". $this->previous_page_record ." ," . $limit;
                                                                break;
                                                            }
                                                            $this->previous_page_record = $this->previous_limit - 1;
                                                        }
                                                    }
                                                    
                                                    $query1 = "SELECT products.idproduct, products.productname AS `productname`, productpotency.potency AS `productpotency_potency`, productmanufacturers.manufacturer AS `productmanufacturers_manufacturer`, productsizes.productsize AS `productsizes_productsize`, packsizes.packsize AS `packsizes_packsize`, products.onhand AS `onhand` FROM (products) LEFT JOIN productpotency ON products.idpotency = productpotency.idpotency LEFT JOIN productmanufacturers ON products.idmanufacturer = productmanufacturers.idmanufacturer LEFT JOIN productsizes ON products.idproductsize = productsizes.idproductsize LEFT JOIN packsizes ON products.idpacksize = packsizes.idpacksize LEFT JOIN locations AS l ON products.idlocation = l.idlocation WHERE products.idlocation = '" . $this->session->userdata ( 'idlocation' ) . "' AND products.onhand = 0 ORDER BY products.productname ASC, products.onhand DESC " . $query_limit;
                                                    //echo $query1;
                                                    if (! empty ( $query1 )) {
                                                        $qq = $this->db->query ( $query1 );
                                                        $pdata = array_merge ( $query->result (), $qq->result () );
                                                    }
                                                    
                                                }
                                                
                                                if (! empty ( $pdata ))
                                                    return $pdata;
                                                    
                                                    return $query->result ();
            }
            return $data;
        }
        
        /**
         * Get items for Map Management
         */
        function get_items_map($table, $id_name, $fields = NULL, $item_id = NULL, $filters = array(), $limit = NULL, $offset = 0, $order = NULL, $ref_ids = FALSE, $filter_date = NULL, $filter_daterange = NULL, $filter_type = NULL, $filter_site = NULL, $filter_allsite = NULL, $isEvent, $dataForPDF, $dataForPDF_allSites) {
            
            $data = array ();
            $sql = NULL;
            $site_condition = NULL;
            
            if (count ( $fields )) {
                // start code to add date filter
                $weather_date_condition = $adult_date_condition = $landing_date_condition = $larvalsurv_date_condition = $larvaltrt_date_condition = $larvaltrt_only_date_condition = $adulttrt_date_condition = $work_assgnmnts_date_condition = '';
                $idlocation = (!empty($filters) && isset($filters [0] ['value'])) ? $filters [0] ['value'] : "";
                
                if(!empty($idlocation)){
                    $weather_date_condition = " AND `sites`.`idlocation` = '" . $idlocation . "'";
                    $adult_date_condition = " AND `sites`.`idlocation` = '" . $idlocation . "'";
                    $landing_date_condition = " AND `sites`.`idlocation` = '" . $idlocation . "'";
                    $larvalsurv_date_condition = " AND `sites`.`idlocation` = '" . $idlocation . "'";
                    $larvaltrt_date_condition = " AND `sites`.`idlocation` = '" . $idlocation . "'";
                    $larvaltrt_only_date_condition = " AND `sites`.`idlocation` = '" . $idlocation . "'";
                    $adulttrt_date_condition = " AND `sites`.`idlocation` = '" . $idlocation . "'";
                    $work_assgnmnts_date_condition = " AND `sites`.`idlocation` = '" . $idlocation . "'";
                }
                
                $allFilter = array(0,1,2,3,4,5,6,7,8,9,10,11,12);
                if (strpos($filter_type, 'type') !== false) {
                    $filter_type = substr($filter_type, -1);
                }
                if(!empty($filter_type) && empty($isEvent) || !empty($dataForPDF) ){
                    switch($filter_type){
                        case '1':
                            $allFilter = array(0);//adulticidetreatments
                            break;
                        case '2':
                            $allFilter = array(2,6,11);//larvaltreatments
                            break;
                        case '3':
                            $allFilter = array(1,7,10);//landingrates
                            break;
                        case '4':
                            $allFilter = array(12);//servicerequests
                            break;
                        case '5':
                            $allFilter = array(3);//weather
                            break;
                        case '6':
                            $allFilter = array(4,8);//adultSurveillance
                            break;
                    }
                }
                
                if(!empty($filter_allsite)){
                    //$filter_date = "";
                    //                $filter_daterange = "";
                    $limit = "";
                }
                if(!empty($filter_site)){
                    $site_condition = !empty($filter_site) ? ' AND `sites`.`idsite` = ' . $filter_site: '';
                }
                
                if (! empty ( $filter_date ) && (empty ( $filter_daterange ) || (!empty($filter_daterange) && !empty ($filter_daterange[0]) && !empty($filter_daterange[1]))) ||!empty($isEvent) || !empty($dataForPDF_allSites)) {
                    switch ($filter_date) {
                        case '1' :
                            $weather_date_condition = "AND (`weather`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `weather`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $adult_date_condition = "AND (`adultsurveillance`.`pudate` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `adultsurveillance`.`pudate` <= '" . date ( 'Y-m-d' ) . "' )";
                            $landing_date_condition = "AND (`landingrates`.`observeddate` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `landingrates`.`observeddate` <= '" . date ( 'Y-m-d' ) . "' )";
                            $larvalsurv_date_condition = "AND (`larvalsurveillance`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `larvalsurveillance`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $larvaltrt_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $larvaltrt_only_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $adulttrt_date_condition = "AND (`adulticidetreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `adulticidetreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $work_assgnmnts_date_condition = "AND (`servicerequests`.`opendate` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `servicerequests`.`opendate` <= '" . date ( 'Y-m-d' ) . "' )";
                            break;
                            
                        case '2' :
                            $weather_date_condition = "AND (`weather`.`date` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `weather`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $adult_date_condition = "AND (`adultsurveillance`.`pudate` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `adultsurveillance`.`pudate` <= '" . date ( 'Y-m-d' ) . "' )";
                            $landing_date_condition = "AND (`landingrates`.`observeddate` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `landingrates`.`observeddate` <= '" . date ( 'Y-m-d' ) . "' )";
                            $larvalsurv_date_condition = "AND (`larvalsurveillance`.`date` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `larvalsurveillance`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $larvaltrt_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $larvaltrt_only_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $adulttrt_date_condition = "AND (`adulticidetreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `adulticidetreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $work_assgnmnts_date_condition = "AND (`servicerequests`.`opendate` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `servicerequests`.`opendate` <= '" . date ( 'Y-m-d' ) . "' )";
                            
                            break;
                        case '3' :
                            $weather_date_condition = "AND (`weather`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `weather`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $adult_date_condition = "AND (`adultsurveillance`.`pudate` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `adultsurveillance`.`pudate` <= '" . date ( 'Y-m-d' ) . "' )";
                            $landing_date_condition = "AND (`landingrates`.`observeddate` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `landingrates`.`observeddate` <= '" . date ( 'Y-m-d' ) . "' )";
                            $larvalsurv_date_condition = "AND (`larvalsurveillance`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `larvalsurveillance`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $larvaltrt_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $larvaltrt_only_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $adulttrt_date_condition = "AND (`adulticidetreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `adulticidetreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $work_assgnmnts_date_condition = "AND (`servicerequests`.`opendate` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `servicerequests`.`opendate` <= '" . date ( 'Y-m-d' ) . "' )";
                            
                            break;
                        case '4' :
                            $weather_date_condition = "AND (`weather`.`date` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `weather`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $adult_date_condition = "AND (`adultsurveillance`.`pudate` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `adultsurveillance`.`pudate` <= '" . date ( 'Y-m-d' ) . "' )";
                            $landing_date_condition = "AND (`landingrates`.`observeddate` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `landingrates`.`observeddate` <= '" . date ( 'Y-m-d' ) . "' )";
                            $larvalsurv_date_condition = "AND (`larvalsurveillance`.`date` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `larvalsurveillance`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $larvaltrt_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $larvaltrt_only_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $adulttrt_date_condition = "AND (`adulticidetreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `adulticidetreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $work_assgnmnts_date_condition = "AND (`servicerequests`.`opendate` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `servicerequests`.`opendate` <= '" . date ( 'Y-m-d' ) . "' )";
                            
                            break;
                        case '5' :
                            $weather_date_condition = "AND (`weather`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `weather`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $adult_date_condition = "AND (`adultsurveillance`.`pudate` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `adultsurveillance`.`pudate` <= '" . date ( 'Y-m-d' ) . "' )";
                            $landing_date_condition = "AND (`landingrates`.`observeddate` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `landingrates`.`observeddate` <= '" . date ( 'Y-m-d' ) . "' )";
                            $larvalsurv_date_condition = "AND (`larvalsurveillance`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `larvalsurveillance`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $larvaltrt_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $larvaltrt_only_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $adulttrt_date_condition = "AND (`adulticidetreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `adulticidetreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                            $work_assgnmnts_date_condition = "AND (`servicerequests`.`opendate` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `servicerequests`.`opendate` <= '" . date ( 'Y-m-d' ) . "' )";
                            
                            break;
                    }
                }
                
                if (! empty ( $filter_daterange ) && ! empty ($filter_daterange[0]) && !empty($filter_daterange[1])) {
                    $weather_date_condition = "AND (`weather`.`date` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `weather`.`date` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
                    $adult_date_condition = "AND (`adultsurveillance`.`pudate` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `adultsurveillance`.`pudate` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
                    $landing_date_condition = "AND (`landingrates`.`observeddate` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `landingrates`.`observeddate` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
                    $larvalsurv_date_condition = "AND (`larvalsurveillance`.`date` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `larvalsurveillance`.`date` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
                    $larvaltrt_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
                    $larvaltrt_only_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
                    $adulttrt_date_condition = "AND (`adulticidetreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `adulticidetreatments`.`date` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
                    $work_assgnmnts_date_condition = "AND (`servicerequests`.`opendate` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `servicerequests`.`opendate` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
                    
                }
                
                // end code to add date filter
                $subQuery = array();
                
                if(!empty($isEvent))
                {
                    //echo"- YES Events - <br/>";
                    $subQuery[0] = "(SELECT `adulticidetreatments`.`idadulticidetreatment` AS id,
                    `adulticidetreatments`.`idadulticidetreatment` AS `idadultsurveillance`,
                    `adulticidetreatments`.`date` AS `eventdate`,
                    `sites`.`latitude` AS `latitude`,
    				`sites`.`longitude` AS `longitude`,
                    SUM(`adulticidetreatments`.`idadulticidetreatment`) AS `total`,
                    `adulticidetreatments`.`idadulticidetreatment` AS `exceed`,
                    'adlttreatment' as event,
                    `sites`.`site`,
                    `sites`.`idsite`,
                    CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
                    'adlt_trtmnts' as `type`,
                    'adlttrtmnt' as module
                    FROM `adulticidetreatments`
                    LEFT JOIN `sites` ON `adulticidetreatments`.`idsite` = `sites`.`idsite`
                    WHERE `adulticidetreatments`.`isdeleted` ='0' AND `adulticidetreatments`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $adulttrt_date_condition . "
                    $site_condition
                    GROUP BY `adulticidetreatments`.`idadulticidetreatment`)";
                    
                    $subQuery[1] = "(SELECT `landingrates`.`idlandingrate` AS id,
					`landingrates`.`idlandingrate` AS `idadultsurveillance`,
					`landingrates`.`observeddate` AS `eventdate`,
					`sites`.`latitude` AS `latitude`,
					`sites`.`longitude` AS `longitude`,
					`landingrates`.`countobserved` AS `total`,
					`lp`.`landingrateexceeds` AS `exceed`,
					'map_smmry_lndng_rte_excds_msqts' as event,
					`sites`.`site`,
					`sites`.`idsite`,
					CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					'sidebar_data_entry_lnding_rates' as `type`,
					'landingrates' as module
					FROM `landingrates`
					LEFT JOIN `landingratedetails` ON `landingratedetails`.`idlandingrate` = `landingrates`.`idlandingrate`
					LEFT JOIN `sites` ON `landingrates`.`idsite` = `sites`.`idsite`
					INNER JOIN `locationpreferences` AS lp ON `landingrates`.`idlocation` = `lp`.`idlocation`
					WHERE (`landingrates`.`idduration` * `lp`.`landingrateexceeds`) < `landingrates`.`countobserved` AND
					`landingrates`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $landing_date_condition . "
					$site_condition
					GROUP BY `landingrates`.`idlandingrate`)";
					
					$subQuery[2] = "(SELECT `larvaltreatments`.`idlarvaltreatment` AS id,
					`larvaltreatments`.`idlarvaltreatment` AS `idadultsurveillance`,
					`larvaltreatments`.`date` AS `eventdate`,
					`sites`.`latitude` AS `latitude`,
					`sites`.`longitude` AS `longitude`,
					SUM(`larvaltreatments`.`idlarvaltreatment`) AS `total`,
					`larvaltreatments`.`idlarvaltreatment` AS `exceed`,
					'lrvltreatment' as event,
					`sites`.`site`,
					`sites`.`idsite`,
					CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					'lrvl_trtmnt_hdng' as `type`,
					'lrvltrtmnt' as module
					FROM `larvaltreatments`
					LEFT JOIN `sites` ON `larvaltreatments`.`idsite` = `sites`.`idsite`
					LEFT JOIN `larvatreatmentdetails` ON `larvatreatmentdetails`.`idlarvaltreatment` = `larvaltreatments`.`idlarvaltreatment`
					WHERE  `larvaltreatments`.`isdeleted` != '1' AND `larvaltreatments`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $larvaltrt_only_date_condition . "
					$site_condition
					GROUP BY `larvaltreatments`.`idlarvaltreatment`)";
					
					$subQuery[3] = "(SELECT `weather`.`idweather` AS id ,
					`weather`.`idweather` AS `idadultsurveillance`,
					`weather`.`date` AS `eventdamap_smmry_rnfll_excds_inchste`,
					`sites`.`latitude` AS `latitude`,
					`sites`.`longitude` AS `longitude`,
					SUM(`weather`.`rainfall`) AS `total`,
					`lp`.`rainfallexceeds` AS `exceed`,
					'map_smmry_rnfll_excds_inchs' as event,
					`sites`.`site`,
					`sites`.`idsite`,
					CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					'sidebar_data_entry_wthr' as `type`,
					'rainfall' as module
					FROM `weather`
					LEFT JOIN `weathersensors` ON `weather`.`idweathersensor` = `weathersensors`.`idweathersensor`
					LEFT JOIN `sites` ON `weathersensors`.`idsite` = `sites`.`idsite`
					INNER JOIN `locationpreferences` AS lp ON `weather`.`idlocation` = `lp`.`idlocation`
					WHERE (SELECT SUM(`w`.`rainfall`) FROM `weather` AS `w` WHERE `w`.`idweather` = `weather`.`idweather` GROUP BY `w`.`idweather`) >`lp`.`rainfallexceeds`
					AND `weather`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $weather_date_condition . "
					$site_condition
					GROUP BY `weather`.`idweather`)";
					
					$subQuery[4] = "(SELECT `adultsurveillance`.`idadultsurveillance` AS id,
					`adultsurveillance`.`idadultsurveillance` AS `idadultsurveillance`,
					`adultsurveillance`.`pudate` AS `eventdate`,
					`sites`.`latitude` AS `latitude`,
					`sites`.`longitude` AS `longitude`,
					`adultsurveillance`.`totalcount` AS `total`,
					`lp`.`trapcountmosquito` AS `exceed`,
					'map_smmry_trap_cnt_excds_msqts' as event,
					`sites`.`site`,
					`sites`.`idsite`,
					CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					'sidebar_data_entry_adlt_srvlnc' as `type`,
					'adultsurveillance' as module
					FROM `adultsurveillance`
					LEFT JOIN `traps` ON `adultsurveillance`.`idtrap` = `traps`.`idtrap`
					LEFT JOIN `sites` ON `traps`.`idsite` = `sites`.`idsite`
					LEFT JOIN `adultsurveillancedetails` ON `adultsurveillancedetails`.`idadultsurveillance` = `adultsurveillance`.`idadultsurveillance`
					LEFT JOIN `locationmosquitospecies` ON `adultsurveillancedetails`.`idmosquitospecies` = `locationmosquitospecies`.`idmosquitospecies`
					INNER JOIN `locationpreferences` AS lp ON `adultsurveillance`.`idlocation` = `lp`.`idlocation`
					WHERE `adultsurveillance`.`totalcount` >`lp`.`trapcountmosquito`
					AND `adultsurveillance`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $adult_date_condition . "
					$site_condition
					GROUP BY `adultsurveillance`.`idadultsurveillance`)";
					
					$subQuery[5] = "";
					//	"(SELECT `larvalsurveillance`.`idlarvalsurveillance` AS id,
					// 	`larvalsurveillance`.`idlarvalsurveillance` AS `idadultsurveillance`,
					// 	`larvalsurveillance`.`date` AS `eventdate`,
					// 	`sites`.`latitude` AS `latitude`,
					// 	`sites`.`longitude` AS `longitude`,
					// 	SUM(`larvalsurveillancedetails`.`count`) AS `total`,
					// 	`lp`.`trapcountmosquito` AS `exceed`,
					// 	'map_smmry_trap_cnt_excds_msqts' as event,
					// 	`sites`.`site`,
					// 	`sites`.`idsite`,
					// 	CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					// 	'sidebar_data_entry_lrvl_srvlnc' as `type`,
					// 	'larvalsurveillance' as module
					// 	FROM `larvalsurveillance`
					// 	LEFT JOIN `sites` ON `larvalsurveillance`.`idsite` = `sites`.`idsite`
					// 	LEFT JOIN `larvalsurveillancedetails` ON `larvalsurveillancedetails`.`idlarvalsurveillance` = `larvalsurveillance`.`idlarvalsurveillance`
					// 	LEFT JOIN `locationmosquitospecies` ON `larvalsurveillancedetails`.`idmosquitospecies` = `locationmosquitospecies`.`idmosquitospecies`
					// 	INNER JOIN `locationpreferences` AS lp ON `larvalsurveillance`.`idlocation` = `lp`.`idlocation`
					// 	WHERE (SELECT SUM(`larvalsurveillancedetails`.`count`) FROM `larvalsurveillancedetails` WHERE `larvalsurveillancedetails`.`idlarvalsurveillance` = `larvalsurveillance`.`idlarvalsurveillance` GROUP BY `larvalsurveillance`.`idlarvalsurveillance`) >`lp`.`trapcountmosquito`
					// 	AND `larvalsurveillance`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $larvalsurv_date_condition . "
					// 	$site_condition
					// 	GROUP BY `larvalsurveillance`.`idlarvalsurveillance`)";
					
					$subQuery[6] = "";
					//	"(SELECT `larvaltreatments`.`idlarvaltreatment` AS id,
					// 	`larvaltreatments`.`idlarvaltreatment` AS `idadultsurveillance`,
					// 	`larvaltreatments`.`date` AS `eventdate`,
					// 	`sites`.`latitude` AS `latitude`,
					// 	`sites`.`longitude` AS `longitude`,
					// 	SUM(`larvatreatmentdetails`.`count`) AS `total`,
					// 	`lp`.`trapcountmosquito` AS `exceed`,
					// 	'map_smmry_trap_cnt_excds_msqts' as event,
					// 	`sites`.`site`,
					// 	`sites`.`idsite`,
					// 	CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					// 	'lrvl_trtmnt_hdng' as `type`,
					// 	'lrvltrtmnt' as module
					// 	FROM `larvaltreatments`
					// 	LEFT JOIN `sites` ON `larvaltreatments`.`idsite` = `sites`.`idsite`
					// 	LEFT JOIN `larvatreatmentdetails` ON `larvatreatmentdetails`.`idlarvaltreatment` = `larvaltreatments`.`idlarvaltreatment`
					// 	LEFT JOIN `locationmosquitospecies` ON `larvatreatmentdetails`.`idmosquitospecies` = `locationmosquitospecies`.`idmosquitospecies`
					// 	INNER JOIN `locationpreferences` AS lp ON `larvaltreatments`.`idlocation` = `lp`.`idlocation`
					// 	WHERE  `larvaltreatments`.`isdeleted` != '1' AND (SELECT SUM(`larvatreatmentdetails`.`count`) FROM `larvatreatmentdetails` WHERE `larvatreatmentdetails`.`idlarvaltreatment` = `larvaltreatments`.`idlarvaltreatment` GROUP BY `larvaltreatments`.`idlarvaltreatment`) >`lp`.`trapcountmosquito`
					// 	AND `larvaltreatments`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $larvaltrt_date_condition . "
					// 	$site_condition
					// 	GROUP BY `larvaltreatments`.`idlarvaltreatment`)";
					
					$subQuery[7] = "";
					//	"(SELECT `landingrates`.`idlandingrate` AS id,
					// 	`landingrates`.`idlandingrate` AS `idadultsurveillance`,
					// 	`landingrates`.`observeddate` AS `eventdate`,
					// 	`sites`.`latitude` AS `latitude`,
					// 	`sites`.`longitude` AS `longitude`,
					// 	SUM(`landingratedetails`.`count`) AS `total`,
					// 	`lp`.`trapcountmosquito` AS `exceed`,
					// 	'map_smmry_trap_cnt_excds_msqts' as event,
					// 	`sites`.`site`,
					// 	`sites`.`idsite`,
					// 	CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					// 	'sidebar_data_entry_lnding_rates' as `type`,
					// 	'landingrates' as module
					// 	FROM `landingrates`
					// 	LEFT JOIN `sites` ON `landingrates`.`idsite` = `sites`.`idsite`
					// 	LEFT JOIN `landingratedetails` ON `landingratedetails`.`idlandingrate` = `landingrates`.`idlandingrate`
					// 	LEFT JOIN `locationmosquitospecies` ON `landingratedetails`.`idlocationvectorspecies` = `locationmosquitospecies`.`idmosquitospecies`
					// 	INNER JOIN `locationpreferences` AS lp ON `landingrates`.`idlocation` = `lp`.`idlocation`
					// 	WHERE (SELECT SUM(`landingratedetails`.`count`) FROM `landingratedetails` WHERE `landingratedetails`.`idlandingrate` = `landingrates`.`idlandingrate` GROUP BY `landingrates`.`idlandingrate`) >`lp`.`trapcountmosquito`
					// 	AND `landingrates`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $landing_date_condition . "
					// 	$site_condition
					// 	GROUP BY `landingrates`.`idlandingrate`)";
					
					$subQuery[8] = "(SELECT `adultsurveillance`.`idadultsurveillance` AS id,
					`adultsurveillance`.`idadultsurveillance` AS `idadultsurveillance`,
					`adultsurveillance`.`pudate` AS `eventdate`,
					`sites`.`latitude` AS `latitude`,
					`sites`.`longitude` AS `longitude`,
					(SELECT SUM(`adultsurveillancedetails`.`count`) FROM `adultsurveillancedetails` WHERE `adultsurveillancedetails`.`idadultsurveillance` = `adultsurveillance`.`idadultsurveillance` GROUP BY `adultsurveillance`.`idadultsurveillance`) AS `total`,
					`lp`.`trapcountvector` AS `exceed`,
					'map_smmry_trap_cnt_vctr_excds_msqts' as event,
					`sites`.`site`,
					`sites`.`idsite`,
					CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					'sidebar_data_entry_adlt_srvlnc' as `type`,
					'adultsurveillance' as module
					FROM `adultsurveillance`
					LEFT JOIN `traps` ON `adultsurveillance`.`idtrap` = `traps`.`idtrap`
					LEFT JOIN `sites` ON `traps`.`idsite` = `sites`.`idsite`
					LEFT JOIN `adultsurveillancedetails` ON `adultsurveillancedetails`.`idadultsurveillance` = `adultsurveillance`.`idadultsurveillance`
					LEFT JOIN `locationvectorspecies` ON `adultsurveillancedetails`.`idmosquitospecies` = `locationvectorspecies`.`idlocationmosquitospecies`
					INNER JOIN `locationpreferences` AS lp ON `adultsurveillance`.`idlocation` = `lp`.`idlocation`
					WHERE (SELECT SUM(`adultsurveillancedetails`.`count`) FROM `adultsurveillancedetails` WHERE `adultsurveillancedetails`.`idadultsurveillance` = `adultsurveillance`.`idadultsurveillance` GROUP BY `adultsurveillance`.`idadultsurveillance`) >`lp`.`trapcountvector`
					AND `locationvectorspecies`.`idlocation`= '" . $this->session->userdata ( 'idlocation' ) . "'
					AND `adultsurveillance`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $adult_date_condition . "
					$site_condition
					GROUP BY `adultsurveillance`.`idadultsurveillance`)";
					
					$subQuery[9] = "";
					//  "(SELECT `larvalsurveillance`.`idlarvalsurveillance` AS id,
					// 	`larvalsurveillance`.`idlarvalsurveillance` AS `idadultsurveillance`,
					// 	`larvalsurveillance`.`date` AS `eventdate`,
					// 	`sites`.`latitude` AS `latitude`,
					// 	`sites`.`longitude` AS `longitude`,
					// 	SUM(`larvalsurveillancedetails`.`count`) AS `total`,
					// 	`lp`.`trapcountvector` AS `exceed`,
					// 	'map_smmry_trap_cnt_vctr_excds_msqts' as event,
					// 	`sites`.`site`,
					// 	`sites`.`idsite`,
					// 	CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					// 	'sidebar_data_entry_lrvl_srvlnc' as `type`,
					// 	'larvalsurveillance' as module
					// 	FROM `larvalsurveillance`
					// 	LEFT JOIN `sites` ON `larvalsurveillance`.`idsite` = `sites`.`idsite`
					// 	LEFT JOIN `larvalsurveillancedetails` ON `larvalsurveillancedetails`.`idlarvalsurveillance` = `larvalsurveillance`.`idlarvalsurveillance`
					// 	LEFT JOIN `locationvectorspecies` ON `larvalsurveillancedetails`.`idmosquitospecies` = `locationvectorspecies`.`idlocationmosquitospecies`
					// 	INNER JOIN `locationpreferences` AS lp ON `larvalsurveillance`.`idlocation` = `lp`.`idlocation`
					// 	WHERE (SELECT SUM(`larvalsurveillancedetails`.`count`) FROM `larvalsurveillancedetails` WHERE `larvalsurveillancedetails`.`idlarvalsurveillance` = `larvalsurveillance`.`idlarvalsurveillance` GROUP BY `larvalsurveillance`.`idlarvalsurveillance`) >`lp`.`trapcountvector`
					// 	AND `larvalsurveillance`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $larvalsurv_date_condition . "
					// 	$site_condition
					// 	GROUP BY `larvalsurveillance`.`idlarvalsurveillance`)";
					
					$subQuery[10] = "";
					//	"(SELECT `landingrates`.`idlandingrate` AS id,
					// 	`landingrates`.`idlandingrate` AS `idadultsurveillance`,
					// 	`landingrates`.`observeddate` AS `eventdate`,
					// 	`sites`.`latitude` AS `latitude`,
					// 	`sites`.`longitude` AS `longitude`,
					// 	SUM(`landingratedetails`.`count`) AS `total`,
					// 	`lp`.`trapcountvector` AS `exceed`,
					// 	'map_smmry_trap_cnt_vctr_excds_msqts' as event,
					// 	`sites`.`site`,
					// 	`sites`.`idsite`,
					// 	CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					// 	'sidebar_data_entry_lnding_rates' as `type`,
					// 	'landingrates' as module
					// 	FROM `landingrates`
					// 	LEFT JOIN `sites` ON `landingrates`.`idsite` = `sites`.`idsite`
					// 	LEFT JOIN `landingratedetails` ON `landingratedetails`.`idlandingrate` = `landingrates`.`idlandingrate`
					// 	LEFT JOIN `locationvectorspecies` ON `landingratedetails`.`idlocationvectorspecies` = `locationvectorspecies`.`idlocationmosquitospecies`
					// 	INNER JOIN `locationpreferences` AS lp ON `landingrates`.`idlocation` = `lp`.`idlocation`
					// 	WHERE (SELECT SUM(`landingratedetails`.`count`) FROM `landingratedetails` WHERE `landingratedetails`.`idlandingrate` = `landingrates`.`idlandingrate` GROUP BY `landingrates`.`idlandingrate`) >`lp`.`trapcountvector`
					// 	AND `landingrates`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $landing_date_condition . "
					// 	$site_condition
					// 	GROUP BY `landingrates`.`idlandingrate`)";
					
					$subQuery[11] = "";
					//	"(SELECT `larvaltreatments`.`idlarvaltreatment` AS id,
					// 	`larvaltreatments`.`idlarvaltreatment` AS `idadultsurveillance`,
					// 	`larvaltreatments`.`date` AS `eventdate`,
					// 	`sites`.`latitude` AS `latitude`,
					// 	`sites`.`longitude` AS `longitude`,
					// 	SUM(`larvatreatmentdetails`.`count`) AS `total`,
					// 	`lp`.`trapcountvector` AS `exceed`,
					// 	'map_smmry_trap_cnt_vctr_excds_msqts' as event,
					// 	`sites`.`site`,
					// 	`sites`.`idsite`,
					// 	CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					// 	'lrvl_trtmnt_hdng' as `type`,
					// 	'lrvltrtmnt' as module
					// 	FROM `larvaltreatments`
					// 	LEFT JOIN `sites` ON `larvaltreatments`.`idsite` = `sites`.`idsite`
					// 	LEFT JOIN `larvatreatmentdetails` ON `larvatreatmentdetails`.`idlarvaltreatment` = `larvaltreatments`.`idlarvaltreatment`
					// 	LEFT JOIN `locationvectorspecies` ON `larvatreatmentdetails`.`idmosquitospecies` = `locationvectorspecies`.`idlocationmosquitospecies`
					// 	INNER JOIN `locationpreferences` AS lp ON `larvaltreatments`.`idlocation` = `lp`.`idlocation`
					// 	WHERE `larvaltreatments`.`isdeleted` != '1' AND  (SELECT SUM(`larvatreatmentdetails`.`count`) FROM `larvatreatmentdetails` WHERE `larvatreatmentdetails`.`idlarvaltreatment` = `larvaltreatments`.`idlarvaltreatment` GROUP BY `larvaltreatments`.`idlarvaltreatment`) >`lp`.`trapcountvector`
					// 	AND `larvaltreatments`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $larvaltrt_date_condition . "
					// 	$site_condition
					// 	GROUP BY `larvaltreatments`.`idlarvaltreatment`)";
					
					$subQuery[12] = "(SELECT `servicerequests`.`idservicerequest` AS id,
					`servicerequests`.`idservicerequest` AS `idadultsurveillance`,
					`servicerequests`.`opendate` AS `eventdate`,
					`sites`.`latitude` AS `latitude`,
					`sites`.`longitude` AS `longitude`,
					(SELECT COUNT(`s`.`idservicerequest`)
							FROM `servicerequests` AS `s`
							LEFT JOIN `sites` ON `s`.`idsite` = `sites`.`idsite`
							WHERE `s`.`opendate` = `servicerequests`.`opendate`
							AND `s`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "'  AND `s`.`isdeleted` = '0'
							GROUP BY `s`.`opendate`) AS `total`,
					`lp`.`callsexceed` AS `exceed`,
					'workassgnmnts' as event,
					`sites`.`site`,
					`sites`.`idsite`,
					CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					'sidebar_data_entry_wrk_asgnmnts' as `type`,
					'workassgnmnts' as module
					FROM `servicerequests`
					LEFT JOIN `sites` ON `servicerequests`.`idsite` = `sites`.`idsite`
					INNER JOIN `locationpreferences` AS lp ON `servicerequests`.`idlocation` = `lp`.`idlocation`
					WHERE (
							SELECT COUNT(`s`.`idservicerequest`)
							FROM `servicerequests` AS `s`
							LEFT JOIN `sites` ON `s`.`idsite` = `sites`.`idsite`
							WHERE `s`.`opendate` = `servicerequests`.`opendate`
							AND `s`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "'  AND `s`.`isdeleted` = '0'
							GROUP BY `s`.`opendate`
						) > `lp`.`callsexceed`
					AND `servicerequests`.`isdeleted` = '0' AND `servicerequests`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $work_assgnmnts_date_condition . "
					$site_condition
					GROUP BY `servicerequests`.`idservicerequest`)";
					
                }
                else
                {
                    //echo"- NO Events - <br/>";
                    $subQuery[0] = "(SELECT `adulticidetreatments`.`idadulticidetreatment` AS id,
						`adulticidetreatments`.`idadulticidetreatment` AS `idadultsurveillance`,
						`adulticidetreatments`.`date` AS `eventdate`,
						`sites`.`latitude` AS `latitude`,
						`sites`.`longitude` AS `longitude`,
						SUM(`adulticidetreatments`.`idadulticidetreatment`) AS `total`,
						`adulticidetreatments`.`idadulticidetreatment` AS `exceed`,
						'adlttreatment' as event,
						`sites`.`site`,
						`sites`.`idsite`,
						CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
						'adlt_trtmnts' as `type`,
						'adlttrtmnt' as module
						FROM `adulticidetreatments`
						LEFT JOIN `sites` ON `adulticidetreatments`.`idsite` = `sites`.`idsite`
						WHERE `adulticidetreatments`.`isdeleted` ='0' AND  `adulticidetreatments`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $adulttrt_date_condition . "
						$site_condition
						GROUP BY `adulticidetreatments`.`idadulticidetreatment`)";
						
						$subQuery[1] = "(SELECT `landingrates`.`idlandingrate` AS id,
					`landingrates`.`idlandingrate` AS `idadultsurveillance`,
					`landingrates`.`observeddate` AS `eventdate`,
					`sites`.`latitude` AS `latitude`,
					`sites`.`longitude` AS `longitude`,
					COUNT(`landingratedetails`.`idlandingrate`) AS `total`,
					`lp`.`landingrateexceeds` AS `exceed`,
					'map_smmry_lndng_rte_excds_msqts' as event,
					`sites`.`site`,
					`sites`.`idsite`,
					CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					'sidebar_data_entry_lnding_rates' as `type`,
					'landingrates' as module
					FROM `landingrates`
					LEFT JOIN `landingratedetails` ON `landingratedetails`.`idlandingrate` = `landingrates`.`idlandingrate`
					LEFT JOIN `sites` ON `landingrates`.`idsite` = `sites`.`idsite`
					INNER JOIN `locationpreferences` AS lp ON `landingrates`.`idlocation` = `lp`.`idlocation`
					WHERE `landingrates`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $landing_date_condition . "
					$site_condition
					GROUP BY `landingrates`.`idlandingrate`)";
					
					$subQuery[2] = "(SELECT `larvaltreatments`.`idlarvaltreatment` AS id,
					`larvaltreatments`.`idlarvaltreatment` AS `idadultsurveillance`,
					`larvaltreatments`.`date` AS `eventdate`,
					`sites`.`latitude` AS `latitude`,
					`sites`.`longitude` AS `longitude`,
					SUM(`larvaltreatments`.`idlarvaltreatment`) AS `total`,
					`larvaltreatments`.`idlarvaltreatment` AS `exceed`,
					'lrvltreatment' as event,
					`sites`.`site`,
					`sites`.`idsite`,
					CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					'lrvl_trtmnt_hdng' as `type`,
					'lrvltrtmnt' as module
					FROM `larvaltreatments`
					LEFT JOIN `sites` ON `larvaltreatments`.`idsite` = `sites`.`idsite`
					LEFT JOIN `larvatreatmentdetails` ON `larvatreatmentdetails`.`idlarvaltreatment` = `larvaltreatments`.`idlarvaltreatment`
					WHERE  `larvaltreatments`.`isdeleted` != '1' AND `larvaltreatments`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $larvaltrt_only_date_condition . "
					$site_condition
					GROUP BY `larvaltreatments`.`idlarvaltreatment`)";
					
					$subQuery[3] = "(SELECT `weather`.`idweather` AS id ,
					`weather`.`idweather` AS `idadultsurveillance`,
					`weather`.`date` AS `eventdamap_smmry_rnfll_excds_inchste`,
					`sites`.`latitude` AS `latitude`,
					`sites`.`longitude` AS `longitude`,
					SUM(`weather`.`rainfall`) AS `total`,
					`lp`.`rainfallexceeds` AS `exceed`,
					'map_smmry_rnfll_excds_inchs' as event,
					`sites`.`site`,
					`sites`.`idsite`,
					CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					'sidebar_data_entry_wthr' as `type`,
					'rainfall' as module
					FROM `weather`
					LEFT JOIN `weathersensors` ON `weather`.`idweathersensor` = `weathersensors`.`idweathersensor`
					LEFT JOIN `sites` ON `weathersensors`.`idsite` = `sites`.`idsite`
					INNER JOIN `locationpreferences` AS lp ON `weather`.`idlocation` = `lp`.`idlocation`
					WHERE `weather`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $weather_date_condition . "
					$site_condition
					GROUP BY `weather`.`idweather`)";
					
					$subQuery[4] = "(SELECT `adultsurveillance`.`idadultsurveillance` AS id,
					`adultsurveillance`.`idadultsurveillance` AS `idadultsurveillance`,
					`adultsurveillance`.`pudate` AS `eventdate`,
					`sites`.`latitude` AS `latitude`,
					`sites`.`longitude` AS `longitude`,
					SUM(`adultsurveillancedetails`.`count`) AS `total`,
					`lp`.`trapcountmosquito` AS `exceed`,
					'map_smmry_trap_cnt_excds_msqts' as event,
					`sites`.`site`,
					`sites`.`idsite`,
					CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					'sidebar_data_entry_adlt_srvlnc' as `type`,
					'adultsurveillance' as module
					FROM `adultsurveillance`
					LEFT JOIN `traps` ON `adultsurveillance`.`idtrap` = `traps`.`idtrap`
					LEFT JOIN `sites` ON `traps`.`idsite` = `sites`.`idsite`
					LEFT JOIN `adultsurveillancedetails` ON `adultsurveillancedetails`.`idadultsurveillance` = `adultsurveillance`.`idadultsurveillance`
					LEFT JOIN `locationmosquitospecies` ON `adultsurveillancedetails`.`idmosquitospecies` = `locationmosquitospecies`.`idmosquitospecies`
					INNER JOIN `locationpreferences` AS lp ON `adultsurveillance`.`idlocation` = `lp`.`idlocation`
					WHERE `adultsurveillance`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $adult_date_condition . "
					$site_condition
					GROUP BY `adultsurveillance`.`idadultsurveillance`)";
					
					$subQuery[5] = "(SELECT `larvalsurveillance`.`idlarvalsurveillance` AS id,
					`larvalsurveillance`.`idlarvalsurveillance` AS `idadultsurveillance`,
					`larvalsurveillance`.`date` AS `eventdate`,
					`sites`.`latitude` AS `latitude`,
					`sites`.`longitude` AS `longitude`,
					SUM(`larvalsurveillancedetails`.`count`) AS `total`,
					`lp`.`trapcountmosquito` AS `exceed`,
					'map_smmry_trap_cnt_excds_msqts' as event,
					`sites`.`site`,
					`sites`.`idsite`,
					CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					'sidebar_data_entry_lrvl_srvlnc' as `type`,
					'larvalsurveillance' as module
					FROM `larvalsurveillance`
					LEFT JOIN `sites` ON `larvalsurveillance`.`idsite` = `sites`.`idsite`
					LEFT JOIN `larvalsurveillancedetails` ON `larvalsurveillancedetails`.`idlarvalsurveillance` = `larvalsurveillance`.`idlarvalsurveillance`
					LEFT JOIN `locationmosquitospecies` ON `larvalsurveillancedetails`.`idmosquitospecies` = `locationmosquitospecies`.`idmosquitospecies`
					INNER JOIN `locationpreferences` AS lp ON `larvalsurveillance`.`idlocation` = `lp`.`idlocation`
					WHERE `larvalsurveillance`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $larvalsurv_date_condition . "
					$site_condition
					GROUP BY `larvalsurveillance`.`idlarvalsurveillance`)";
					
					$subQuery[6] = "";
					//  "(SELECT `larvaltreatments`.`idlarvaltreatment` AS id,
					// 	`larvaltreatments`.`idlarvaltreatment` AS `idadultsurveillance`,
					// 	`larvaltreatments`.`date` AS `eventdate`,
					// 	`sites`.`latitude` AS `latitude`,
					// 	`sites`.`longitude` AS `longitude`,
					// 	SUM(`larvatreatmentdetails`.`count`) AS `total`,
					// 	`lp`.`trapcountmosquito` AS `exceed`,
					// 	'map_smmry_trap_cnt_excds_msqts' as event,
					// 	`sites`.`site`,
					// 	`sites`.`idsite`,
					// 	CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					// 	'lrvl_trtmnt_hdng' as `type`,
					// 	'lrvltrtmnt' as module
					// 	FROM `larvaltreatments`
					// 	LEFT JOIN `sites` ON `larvaltreatments`.`idsite` = `sites`.`idsite`
					// 	LEFT JOIN `larvatreatmentdetails` ON `larvatreatmentdetails`.`idlarvaltreatment` = `larvaltreatments`.`idlarvaltreatment`
					// 	LEFT JOIN `locationmosquitospecies` ON `larvatreatmentdetails`.`idmosquitospecies` = `locationmosquitospecies`.`idmosquitospecies`
					// 	INNER JOIN `locationpreferences` AS lp ON `larvaltreatments`.`idlocation` = `lp`.`idlocation`
					// 	WHERE `larvaltreatments`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $larvaltrt_date_condition . "
					// 	$site_condition
					// 	GROUP BY `larvaltreatments`.`idlarvaltreatment`)";
					
					$subQuery[7] = "";
					//"(SELECT `landingrates`.`idlandingrate` AS id,
					// 	`landingrates`.`idlandingrate` AS `idadultsurveillance`,
					// 	`landingrates`.`observeddate` AS `eventdate`,
					// 	`sites`.`latitude` AS `latitude`,
					// 	`sites`.`longitude` AS `longitude`,
					// 	SUM(`landingratedetails`.`count`) AS `total`,
					// 	`lp`.`trapcountmosquito` AS `exceed`,
					// 	'map_smmry_trap_cnt_excds_msqts' as event,
					// 	`sites`.`site`,
					// 	`sites`.`idsite`,
					// 	CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					// 	'sidebar_data_entry_lnding_rates' as `type`,
					// 	'landingrates' as module
					// 	FROM `landingrates`
					// 	LEFT JOIN `sites` ON `landingrates`.`idsite` = `sites`.`idsite`
					// 	LEFT JOIN `landingratedetails` ON `landingratedetails`.`idlandingrate` = `landingrates`.`idlandingrate`
					// 	LEFT JOIN `locationmosquitospecies` ON `landingratedetails`.`idlocationvectorspecies` = `locationmosquitospecies`.`idmosquitospecies`
					// 	INNER JOIN `locationpreferences` AS lp ON `landingrates`.`idlocation` = `lp`.`idlocation`
					// 	WHERE `landingrates`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $landing_date_condition . "
					// 	$site_condition
					// 	GROUP BY `landingrates`.`idlandingrate`)";
					
					$subQuery[8] = "";
					//  "(SELECT `adultsurveillance`.`idadultsurveillance` AS id,
					// 	`adultsurveillance`.`idadultsurveillance` AS `idadultsurveillance`,
					// 	`adultsurveillance`.`pudate` AS `eventdate`,
					// 	`sites`.`latitude` AS `latitude`,
					// 	`sites`.`longitude` AS `longitude`,
					// 	SUM(`adultsurveillancedetails`.`count`) AS `total`,
					// 	`lp`.`trapcountvector` AS `exceed`,
					// 	'map_smmry_trap_cnt_vctr_excds_msqts' as event,
					// 	`sites`.`site`,
					// 	`sites`.`idsite`,
					// 	CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					// 	'sidebar_data_entry_adlt_srvlnc' as `type`,
					// 	'adultsurveillance' as module
					// 	FROM `adultsurveillance`
					// 	LEFT JOIN `traps` ON `adultsurveillance`.`idtrap` = `traps`.`idtrap`
					// 	LEFT JOIN `sites` ON `traps`.`idsite` = `sites`.`idsite`
					// 	LEFT JOIN `adultsurveillancedetails` ON `adultsurveillancedetails`.`idadultsurveillance` = `adultsurveillance`.`idadultsurveillance`
					// 	LEFT JOIN `locationvectorspecies` ON `adultsurveillancedetails`.`idmosquitospecies` = `locationvectorspecies`.`idlocationmosquitospecies`
					// 	INNER JOIN `locationpreferences` AS lp ON `adultsurveillance`.`idlocation` = `lp`.`idlocation`
					// 	WHERE `adultsurveillance`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $adult_date_condition . "
					// 	$site_condition
					// 	GROUP BY `adultsurveillance`.`idadultsurveillance`)";
					
					$subQuery[9] = "";
					//  "(SELECT `larvalsurveillance`.`idlarvalsurveillance` AS id,
					// 	`larvalsurveillance`.`idlarvalsurveillance` AS `idadultsurveillance`,
					// 	`larvalsurveillance`.`date` AS `eventdate`,
					// 	`sites`.`latitude` AS `latitude`,
					// 	`sites`.`longitude` AS `longitude`,
					// 	SUM(`larvalsurveillancedetails`.`count`) AS `total`,
					// 	`lp`.`trapcountvector` AS `exceed`,
					// 	'map_smmry_trap_cnt_vctr_excds_msqts' as event,
					// 	`sites`.`site`,
					// 	`sites`.`idsite`,
					// 	CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					// 	'sidebar_data_entry_lrvl_srvlnc' as `type`,
					// 	'larvalsurveillance' as module
					// 	FROM `larvalsurveillance`
					// 	LEFT JOIN `sites` ON `larvalsurveillance`.`idsite` = `sites`.`idsite`
					// 	LEFT JOIN `larvalsurveillancedetails` ON `larvalsurveillancedetails`.`idlarvalsurveillance` = `larvalsurveillance`.`idlarvalsurveillance`
					// 	LEFT JOIN `locationvectorspecies` ON `larvalsurveillancedetails`.`idmosquitospecies` = `locationvectorspecies`.`idlocationmosquitospecies`
					// 	INNER JOIN `locationpreferences` AS lp ON `larvalsurveillance`.`idlocation` = `lp`.`idlocation`
					// 	WHERE `larvalsurveillance`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $larvalsurv_date_condition . "
					// 	$site_condition
					// 	GROUP BY `larvalsurveillance`.`idlarvalsurveillance`)";
					
					$subQuery[10] = "";
					//	"(SELECT `landingrates`.`idlandingrate` AS id,
					// 	`landingrates`.`idlandingrate` AS `idadultsurveillance`,
					// 	`landingrates`.`observeddate` AS `eventdate`,
					// 	`sites`.`latitude` AS `latitude`,
					// 	`sites`.`longitude` AS `longitude`,
					// 	SUM(`landingratedetails`.`count`) AS `total`,
					// 	`lp`.`trapcountvector` AS `exceed`,
					// 	'map_smmry_trap_cnt_vctr_excds_msqts' as event,
					// 	`sites`.`site`,
					// 	`sites`.`idsite`,
					// 	CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					// 	'sidebar_data_entry_lnding_rates' as `type`,
					// 	'landingrates' as module
					// 	FROM `landingrates`
					// 	LEFT JOIN `sites` ON `landingrates`.`idsite` = `sites`.`idsite`
					// 	LEFT JOIN `landingratedetails` ON `landingratedetails`.`idlandingrate` = `landingrates`.`idlandingrate`
					// 	LEFT JOIN `locationvectorspecies` ON `landingratedetails`.`idlocationvectorspecies` = `locationvectorspecies`.`idlocationmosquitospecies`
					// 	INNER JOIN `locationpreferences` AS lp ON `landingrates`.`idlocation` = `lp`.`idlocation`
					// 	WHERE `landingrates`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $landing_date_condition . "
					// 	$site_condition
					// 	GROUP BY `landingrates`.`idlandingrate`)";
					
					$subQuery[11] = "";
					//	 "(SELECT `larvaltreatments`.`idlarvaltreatment` AS id,
					// 	`larvaltreatments`.`idlarvaltreatment` AS `idadultsurveillance`,
					// 	`larvaltreatments`.`date` AS `eventdate`,
					// 	`sites`.`latitude` AS `latitude`,
					// 	`sites`.`longitude` AS `longitude`,
					// 	SUM(`larvatreatmentdetails`.`count`) AS `total`,
					// 	`lp`.`trapcountvector` AS `exceed`,
					// 	'map_smmry_trap_cnt_vctr_excds_msqts' as event,
					// 	`sites`.`site`,
					// 	`sites`.`idsite`,
					// 	CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					// 	'lrvl_trtmnt_hdng' as `type`,
					// 	'lrvltrtmnt' as module
					// 	FROM `larvaltreatments`
					// 	LEFT JOIN `sites` ON `larvaltreatments`.`idsite` = `sites`.`idsite`
					// 	LEFT JOIN `larvatreatmentdetails` ON `larvatreatmentdetails`.`idlarvaltreatment` = `larvaltreatments`.`idlarvaltreatment`
					// 	LEFT JOIN `locationvectorspecies` ON `larvatreatmentdetails`.`idmosquitospecies` = `locationvectorspecies`.`idlocationmosquitospecies`
					// 	INNER JOIN `locationpreferences` AS lp ON `larvaltreatments`.`idlocation` = `lp`.`idlocation`
					// 	WHERE `larvaltreatments`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $larvaltrt_date_condition . "
					// 	$site_condition
					// 	GROUP BY `larvaltreatments`.`idlarvaltreatment`)";
					
					
					$subQuery[12] = "(SELECT `servicerequests`.`idservicerequest` AS id,
					`servicerequests`.`idservicerequest` AS `idadultsurveillance`,
					`servicerequests`.`opendate` AS `eventdate`,
					`sites`.`latitude` AS `latitude`,
					`sites`.`longitude` AS `longitude`,
					COUNT(`servicerequests`.`idservicerequest`) AS `total`,
					`lp`.`callsexceed` AS `exceed`,
					'workassgnmnts' as event,
					`sites`.`site`,
					`sites`.`idsite`,
					CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
					'sidebar_data_entry_wrk_asgnmnts' as `type`,
					'workassgnmnts' as module
					FROM `servicerequests`
					LEFT JOIN `sites` ON `servicerequests`.`idsite` = `sites`.`idsite`
					INNER JOIN `locationpreferences` AS lp ON `servicerequests`.`idlocation` = `lp`.`idlocation`
					WHERE `servicerequests`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $work_assgnmnts_date_condition . "
					AND `servicerequests`.`isdeleted` = '0' $site_condition
					GROUP BY `servicerequests`.`idservicerequest`)";
                }
                
                foreach($allFilter as $kqry => $vqry){
                    if($subQuery[$vqry] != "") {
                        $sql .= $subQuery[$vqry] . " UNION ";
                    }
                }
                $sql = trim($sql, " UNION ");
                
                $sqlsort = '';
                $i = 0;
                if (! is_null ( $order )) {
                    foreach ( $order as $key => $val ) {
                        foreach ( $fields as $fkey => $field ) {
                            if ($fkey == $key) {
                                if(!empty($field->where_name)) {
                                    $sortby = explode('.', $field->where_name);
                                    $sortby = !empty($sortby) && isset($sortby[1]) ? $sortby[1] : '';
                                } else if(!empty($field['db_name'])) {
                                    $sortby = $field['db_name'];
                                }
                                if($i == 0)
                                    $sqlsort = "ORDER BY ";
                                    else
                                        $sqlsort .= ",";
                                        $sqlsort .= !empty($sortby) ? $sortby. " " . $val : "";
                                        $i++;
                            }
                        }
                    }
                }
                $sql .= " ".$sqlsort;
                if (! empty ( $limit ) ) {
                    $sql .= " LIMIT $offset, $limit";
                }
                // echo "<pre>";
                //			 print_r($sql);
                //die;
                $query = $this->db->query ( $sql );
                $data = $query->result ();
            }
            return $data;
        }
        
        /**
         * Get all module Ids
         */
        function get_all_module_ids($filter_site = NULL) {
            
            $data = array ();
            $subQuery = array();
            $sql = "";
            $site_condition = "";
            $idlocation = $this->session->userdata ( 'idlocation' );
            
            if(!empty($filter_site)){
                $site_condition = !empty($filter_site) ? ' AND `sites`.`idsite` = ' . $filter_site: '';
            }
            
            $subQuery[0] = "(SELECT `adultsurveillance`.`idadultsurveillance` AS id,
            'adultsurveillance' as module
            FROM `adultsurveillance`
            LEFT JOIN `traps` ON `adultsurveillance`.`idtrap` = `traps`.`idtrap`
            LEFT JOIN `sites` ON `traps`.`idsite` = `sites`.`idsite`
            WHERE `adultsurveillance`.`idlocation` = '$idlocation'
            AND `sites`.`idlocation` = '" . $idlocation . "'
            $site_condition)";
            
            $subQuery[1] = "(SELECT `larvalsurveillance`.`idlarvalsurveillance` AS id,
            'larvalsurveillance' as module
            FROM `larvalsurveillance`
            LEFT JOIN `sites` ON `larvalsurveillance`.`idsite` = `sites`.`idsite`
            WHERE `larvalsurveillance`.`idlocation` = '$idlocation'
            AND `sites`.`idlocation` = '" . $idlocation . "'
            $site_condition)";
            
            
            $subQuery[2] = "(SELECT `al`.`idarbovirallab` AS id,
            'arboviral' as module
            FROM `arbovirallabs` AS `al`
            LEFT JOIN `traps` ON `al`.`idtrap` = `traps`.`idtrap`
            LEFT JOIN `sites` ON `traps`.`idsite` = `sites`.`idsite`
            WHERE `al`.`idlocation` = '$idlocation'
            AND `sites`.`idlocation` = '" . $idlocation . "'
            $site_condition)";
            
            $subQuery[3] = "(SELECT `c`.`idcorvidlab` AS id,
            'corvid' as module
            FROM `corvidlabs` AS `c`
            LEFT JOIN `sites` ON `c`.`idsite` = `sites`.`idsite`
            WHERE `c`.`idlocation` = '$idlocation'
            AND `sites`.`idlocation` = '" . $idlocation . "'
            $site_condition)";
            
            $subQuery[4] = "(SELECT `sl`.`idsentinelchickenlab` AS id,
            'sentinelchickenlab' as module
            FROM `sentinelchickenlabs` AS `sl`
            LEFT JOIN `sentinelchicken` ON `sl`.`idsentinelchicken` = `sentinelchicken`.`idsentinelchicken`
            LEFT JOIN `sites` ON `sentinelchicken`.`idsite` = `sites`.`idsite`
            WHERE `sl`.`idlocation` = '$idlocation'
            AND `sites`.`idlocation` = '" . $idlocation . "'
            $site_condition)";
            
            
            $subQuery[5] = "(SELECT `landingrates`.`idlandingrate` AS id,
            'landingrates' as module
            FROM `landingrates`
            LEFT JOIN `sites` ON `landingrates`.`idsite` = `sites`.`idsite`
            WHERE `landingrates`.`idlocation` = '$idlocation'
            AND `sites`.`idlocation` = '" . $idlocation . "'
            $site_condition)";
            
            $subQuery[6] = "(SELECT `servicerequests`.`idservicerequest` AS id,
            'workassgnmnts' as module
            FROM `servicerequests`
            LEFT JOIN `sites` ON `servicerequests`.`idsite` = `sites`.`idsite`
            WHERE `servicerequests`.`idlocation` = '$idlocation'
            AND `sites`.`idlocation` = '" . $idlocation . "'
            $site_condition)";
            
            $subQuery[7] = "(SELECT `adulticidetreatments`.`idadulticidetreatment` AS id,
            'adlttrtmnt' as module
            FROM `adulticidetreatments`
            LEFT JOIN `sites` ON `adulticidetreatments`.`idsite` = `sites`.`idsite`
            WHERE `adulticidetreatments`.`idlocation` = '$idlocation'
            AND `sites`.`idlocation` = '" . $idlocation . "'
            $site_condition)";
            
            
            $subQuery[8] = "(SELECT `larvaltreatments`.`idlarvaltreatment` AS id,
            'lrvltrtmnt' as module
            FROM `larvaltreatments`
            LEFT JOIN `sites` ON `larvaltreatments`.`idsite` = `sites`.`idsite`
            WHERE `larvaltreatments`.`idlocation` = '$idlocation'
            AND `sites`.`idlocation` = '" . $idlocation . "'
            $site_condition)";
            
            $subQuery[9] = "(SELECT `weather`.`idweather` AS id,
            'rainfall' as module
            FROM `weather`
            LEFT JOIN `weathersensors` ON `weather`.`idweathersensor` = `weathersensors`.`idweathersensor`
            LEFT JOIN `sites` ON `weathersensors`.`idsite` = `sites`.`idsite`
            WHERE `weather`.`idlocation` = '$idlocation'
            AND `sites`.`idlocation` = '" . $idlocation . "'
            $site_condition)";
            
            
            foreach($subQuery as $kqry => $vqry){
                $sql .= $subQuery[$kqry] . " UNION ";
            }
            $sql = trim($sql, " UNION ");
            
            //echo $sql;
            //        die;
            $query = $this->db->query ( $sql );
            $data = $query->result ();
            
            return $data;
        }
        
        /**
         * Get items for Multiple Table
         * By UNION
         */
        function get_items_1($table1, $id1_name, $table2, $id2_name, $fields = NULL, $item_id = NULL, $filters = array(), $limit = NULL, $offset = 0, $order = NULL, $ref_ids = FALSE, $table1_rel = NULL, $table2_rel = NULL, $filter_date = NULL, $page = NULL, $ttl_count = NULL, $sep_ttl = NULL, $pagesize = NULL, $filter_daterange = NULL, $service_rqstid = NULL, $adultkey = NULL) {
            $data = array ();
            $type_u_order = 0;
            $dir_ordr = "";
            // echo $pagesize;
            // die;
            if (! empty ( $sep_ttl )) {
                $c = $sep_ttl ['c1'] + $sep_ttl ['c2'];
                $pgs = "";
                // $pagesize = "";
                if (! empty ( $pagesize ) && $pagesize != "all")
                    $pagesize = $pagesize;
                    // else
                    // $pagesize = 10;
                    $pgs = ceil ( $c / $pagesize );
                    $no_of_succ_pgs = 0;
                    
                    if ($sep_ttl ['c1'] <= $sep_ttl ['c2'])
                        $no_of_succ_pgs = ceil ( 2 * $sep_ttl ['c1'] / $pagesize );
                        else
                            $no_of_succ_pgs = ceil ( 2 * $sep_ttl ['c2'] / $pagesize );
                            
                            if ($page <= $no_of_succ_pgs) {
                                
                                switch ($pagesize) {
                                    case '5' :
                                        $limit = 2;
                                        break;
                                    case '10' :
                                        $limit = 5;
                                        break;
                                    case '50' :
                                        $limit = 25;
                                        break;
                                    case 'all' :
                                        $limit = '';
                                        break;
                                }
                                
                                if ($page == 1)
                                    $offset = 0;
                                    else
                                        $offset = $page * 5 - 4;
                            } else {
                                $diff_pgs = 0;
                                
                                if ($sep_ttl ['c1'] > $sep_ttl ['c2']) {
                                    $diff_pgs = $sep_ttl ['c1'] - $sep_ttl ['c2'];
                                } else {
                                    $diff_pgs = $sep_ttl ['c2'] - $sep_ttl ['c1'];
                                }
                                
                                $no_of_succ_pgs = ceil ( $diff_pgs / $pagesize );
                                $limit = $pagesize;
                                if ($page == 1)
                                    $offset = 0;
                                    else
                                        $offset = $page * 5 - 4;
                            }
            }
            
            if (count ( $fields )) {
                // $this->db->from("{$table} {$table}_main");
                // $this->db->select("{$table}_main.{$id_name} AS id");
                $this->db->from ( "{$table1}" );
                $this->db->select ( "{$table1}.{$id1_name}" );
                $join = 0;
                $multilang = FALSE;
                $flag = "";
                $check = 0;
                $filter_date1 = "";
                
                foreach ( $fields as $field ) {
                    
                    switch ($field->type) {
                        // Reference
                        case '1-n' :
                            $id1 = $table1 . "." . $field->db_name;
                            
                            if ($field->ref_table_db_name == $flag) {
                                $this->db->select ( "{$field->ref_table_db_name}.{$field->ref_field_db_name} AS `{$field->unique_name}`" );
                                break;
                            }
                            // $id2 = $field->ref_table_db_name . "_join" . $join . ".{$field->ref_table_id_name}";
                            // $this->db->join("{$field->ref_table_db_name} {$field->ref_table_db_name}_join{$join}", $id1 . " = " . $id2, "left");
                            $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                            $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                            
                            // $this->db->select("{$field->ref_table_db_name}_join{$join}.{$field->ref_field_db_name} AS `{$field->unique_name}`");
                            $this->db->select ( "{$field->ref_table_db_name}.{$field->ref_field_db_name} AS `{$field->unique_name}`" );
                            
                            $field->table_name = $field->ref_table_db_name; // . "_join" . $join;
                            $field->order_name = $field->ref_field_db_name;
                            $flag = $field->ref_table_db_name;
                            $join ++;
                            // Select foreign keys as well
                            if ($ref_ids) {
                                // $this->db->select("{$table}_main.{$field->db_name} AS `{$field->db_name}`");
                                $this->db->select ( "{$table1}.{$field->db_name} AS `{$field->unique_name}_id`" );
                            }
                            break;
                        case '1+2' :
                            $field1 = $table . "." . $field->db_name_1;
                            
                            $field2 = $table . "." . $field->db_name_2;
                            
                            $this->db->select ( "$field1 AS `$field->db_name_1`,$field2 AS `$field->db_name_2`" );
                            break;
                        case '1+2+3+4+5' :
                            $field1 = $table . "." . $field->db_name_1;
                            
                            $field2 = $table . "." . $field->db_name_2;
                            
                            $field3 = $table . "." . $field->db_name_3;
                            
                            $field4 = $table . "." . $field->db_name_4;
                            
                            $field5 = $table . "." . $field->db_name_5;
                            
                            $this->db->select ( "$field1 AS `$field->db_name_1`,$field2 AS `$field->db_name_2`,$field3 AS `$field->db_name_3`,$field4 AS `$field->db_name_4`,$field5 AS `$field->db_name_5`" );
                            break;
                        case '1-(1+2+3)-1-1' :
                            $id1 = $table . "." . $field->db_name;
                            
                            $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                            
                            $id3 = $field->ref_table_1_db_name . "." . $field->ref_table_1_id_name;
                            
                            $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                            
                            $this->db->join ( "{$field->ref_table_1_db_name}", $id2 . " = " . $id3, "left" );
                            
                            $this->db->select ( "{$field->ref_table_db_name}.{$field->ref_field_db_name},{$field->ref_table_db_name}.{$field->ref_field_1_db_name},{$field->ref_table_db_name}.{$field->ref_field_2_db_name},{$field->ref_table_1_db_name}.{$field->ref_field_1_1_db_name}" );
                            break;
                        case '1-1+2' :
                            
                            $id1 = $table1 . "." . $field->db_name;
                            
                            $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                            
                            $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                            
                            $this->db->select ( "{$field->ref_table_db_name}.{$field->ref_field_db_name},{$field->ref_table_db_name}.{$field->ref_field_2_db_name}" );
                            
                            $field->table_name = $field->ref_table_db_name; // . "_join" . $join;
                            $field->order_name = $field->ref_field_db_name;
                            
                            break;
                        case '1-t' :
                            
                            $id1 = $table . "." . $field->db_name;
                            
                            $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                            
                            $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                            
                            $this->db->select ( "sum({$field->ref_table_db_name}.{$field->ref_field_db_name}) AS count " );
                            $check = 1;
                            break;
                        case '1-1-1' :
                            $id1 = $table . "." . $field->db_name;
                            // $id2 = $field->ref_table_db_name . "_join" . $join . ".{$field->ref_table_id_name}";
                            // $this->db->join("{$field->ref_table_db_name} {$field->ref_table_db_name}_join{$join}", $id1 . " = " . $id2, "left");
                            $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                            if ($field->ref_table_db_name != $flag) {
                                $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                            }
                            
                            $id2_1 = $field->ref_table_db_name . "." . $field->ref_table_id2_name;
                            $id3 = $field->ref_table_db2_name . "." . $field->ref_table_id2_name;
                            
                            $this->db->join ( "{$field->ref_table_db2_name}", $id2_1 . " = " . $id3, "left" );
                            // $this->db->select("{$field->ref_table_db_name}_join{$join}.{$field->ref_field_db_name} AS `{$field->unique_name}`");
                            $this->db->select ( "{$field->ref_table_db2_name}.{$field->ref_field_db2_name} AS `{$field->reference_uniq_name}`" );
                            
                            $field->table_name = $field->ref_table_db_name; // . "_join" . $join;
                            $field->order_name = $field->ref_field_db_name;
                            $flag = $field->ref_table_db_name;
                            $join ++;
                            // Select foreign keys as well
                            if ($ref_ids) {
                                // $this->db->select("{$table}_main.{$field->db_name} AS `{$field->db_name}`");
                                $this->db->select ( "{$table}.{$field->db_name} AS `{$field->unique_name}_id`" );
                            }
                            break;
                        case 'u' :
                            
                            break;
                        case '1-n-u' :
                            $id1 = $table1 . "." . $field->db_name;
                            
                            if ($field->ref_table_db_name == $flag) {
                                $this->db->select ( "{$field->ref_table_db_name}.{$field->ref_field_db_name} AS `{$field->unique_name}`" );
                                break;
                            }
                            // $id2 = $field->ref_table_db_name . "_join" . $join . ".{$field->ref_table_id_name}";
                            // $this->db->join("{$field->ref_table_db_name} {$field->ref_table_db_name}_join{$join}", $id1 . " = " . $id2, "left");
                            $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                            $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                            
                            // $this->db->select("{$field->ref_table_db_name}_join{$join}.{$field->ref_field_db_name} AS `{$field->unique_name}`");
                            $this->db->select ( "{$field->ref_table_db_name}.{$field->ref_field_db_name} AS `{$field->unique_name}`" );
                            
                            $field->table_name = $field->ref_table_db_name; // . "_join" . $join;
                            $field->order_name = $field->ref_field_db_name;
                            $flag = $field->ref_table_db_name;
                            $join ++;
                            // Select foreign keys as well
                            if ($ref_ids) {
                                // $this->db->select("{$table}_main.{$field->db_name} AS `{$field->db_name}`");
                                $this->db->select ( "{$table1}.{$field->db_name} AS `{$field->unique_name}_id`" );
                            }
                            break;
                        default :
                            $field->table_name = $table1; // . "_main";
                            $field->order_name = $field->db_name;
                            if (! empty ( $filter_date )) {
                                if (preg_match_all ( '/date/', $field->db_name, $matches )) {
                                    $filter_date1 = $table1 . "." . $field->db_name;
                                }
                            }
                            // $this->db->select("{$table}_main.{$field->db_name} AS `{$field->unique_name}`");
                            $this->db->select ( "{$table1}.{$field->db_name} AS `{$field->unique_name}`" );
                    }
                }
                // add additional condition when service request come
                if (! empty ( $service_rqstid )) {
                    switch ($table1) {
                        case 'adulticidetreatments' :
                            $table1_rel = 'adulticidetreatmentsservice';
                            break;
                    }
                    $additinal_var = $table1 . '.' . $id1_name . '=' . $table1_rel . '.' . $id1_name;
                    $this->db->where ( $table1_rel . '.idservicerequest', $service_rqstid );
                    $this->db->join ( $table1_rel, $additinal_var, 'INNER' );
                } else if (! empty ( $_GET ['service_req_id'] )) {
                    switch ($table1) {
                        case 'adulticidetreatments' :
                            $table1_rel = 'adulticidetreatmentsservice';
                            break;
                    }
                    $additinal_var = $table1 . '.' . $id1_name . '=' . $table1_rel . '.' . $id1_name;
                    $this->db->where ( $table1_rel . '.idservicerequest', $_GET ['service_req_id'] );
                    $this->db->join ( $table1_rel, $additinal_var, 'INNER' );
                }
                
                if (! empty ( $adultkey )) {
                    switch ($table1) {
                        case 'adulticidetreatments' :
                            $table1_rel = 'adulticidetreatmentslarval';
                            break;
                    }
                    $additinal_var = $table1 . '.' . $id1_name . '=' . $table1_rel . '.' . $id1_name;
                    $this->db->where ( $table1_rel . '.idlarval', $adultkey );
                    $this->db->join ( $table1_rel, $additinal_var, 'INNER' );
                } else if (! empty ( $_GET ['adult_key'] )) {
                    switch ($table1) {
                        case 'adulticidetreatments' :
                            $table1_rel = 'adulticidetreatmentslarval';
                            break;
                    }
                    $additinal_var = $table1 . '.' . $id1_name . '=' . $table1_rel . '.' . $id1_name;
                    $this->db->where ( $table1_rel . '.idlarval', $_GET ['adult_key'] );
                    $this->db->join ( $table1_rel, $additinal_var, 'INNER' );
                }
                // Set filters
                // $this->set_filters($filters);
                
                if ($table1 == "users") {
                    $this->db->join ( 'userlocationassignment AS ula', "{$table1}.{$id_name} = ula.iduser", 'LEFT' );
                    $this->db->join ( 'locations AS l', "ula.idlocation = l.idlocation", 'LEFT' );
                    
                    if (isset ( $filters )) {
                        $this->db->where ( "ula.idlocation", $filters [0] ['value'] );
                    }
                } else if (in_array ( "{$table1}", $this->cond_sarr )) {
                    $this->db->join ( 'sites AS s', "{$table1}.idsite = s.idsite", 'LEFT' );
                    $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                    
                    if (isset ( $filters )) {
                        $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                    }
                } else if (in_array ( "{$table1}", $this->cond_all_sarr )) {
                    $this->db->join ( 'locations AS l', "sites.idlocation = l.idlocation", 'LEFT' );
                    
                    if (! empty ( $filters )) {
                        $this->db->where ( "sites.idlocation", $filters [0] ['value'] );
                    }
                } else if (in_array ( "{$table1}", $this->cond_tarr )) {
                    $this->db->join ( 'traps AS t', "{$table1}.idtrap = t.idtrap", 'LEFT' );
                    $this->db->join ( 'sites AS s', "t.idsite = s.idsite", 'LEFT' );
                    $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                    
                    if (isset ( $filters )) {
                        $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                    }
                } else if (in_array ( "{$table1}", $this->cond_larr )) {
                    $this->db->join ( 'sentinelchicken AS senti', "{$table1}.idsentinelchicken = senti.idsentinelchicken", 'LEFT' );
                    $this->db->join ( 'sites AS s', "senti.idsite = s.idsite", 'LEFT' );
                    $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                    
                    if (isset ( $filters )) {
                        $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                    }
                } else {
                    $this->db->join ( 'locations AS l', "{$table1}.idlocation = l.idlocation", 'LEFT' );
                    
                    if (isset ( $filters )) {
                        $this->db->where ( "{$table1}.idlocation", $filters [0] ['value'] );
                    }
                }
                
                if (! is_null ( $item_id )) {
                    // $this->db->where("{$table}_main.{$id_name}", $item_id);
                    $this->db->where ( "{$table}.{$id_name}", $item_id );
                }
                if (! is_null ( $filter_date ) && is_null ( $filter_daterange )) {
                    switch ($filter_date) {
                        // date('H:i:s',strtotime('-1 day');
                        case '1' :
                            $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
                            // $this->db->where($filter_time.' >=',date('H:i:s'));
                            $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                            // $this->db->where( $filter_time.' <=',"22:01:01");
                            break;
                            
                        case '2' :
                            $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
                            // $this->db->where($filter_time.' >=',date('H:i:s'));
                            $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                            // $this->db->where( $filter_time.' <=',"22:01:01");
                            break;
                        case '3' :
                            $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
                            // $this->db->where($filter_time.' >=',date('H:i:s'));
                            $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                            // $this->db->where( $filter_time.' <=',"22:01:01");
                            break;
                        case '4' :
                            $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
                            // $this->db->where($filter_time.' >=',date('H:i:s'));
                            $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                            // $this->db->where( $filter_time.' <=',date('H:i:s',strtotime('-4 month')));
                            break;
                        case '5' :
                            $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
                            // $this->db->where($filter_time.' >=',date('H:i:s'));
                            $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                            // $this->db->where( $filter_time.' <=',date('H:i:s',strtotime('-1 year')));
                            break;
                    }
                }
                
                if (in_array ( $table1, $this->date_arr ))
                    if (! is_null ( $filter_daterange )) {
                        $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) );
                        $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) );
                    }
                if (! is_null ( $order )) {
                    foreach ( $order as $field_id => $dir ) {
                        if ($field_id != 3)
                            $this->db->order_by ( $fields [$field_id]->table_name . "." . $fields [$field_id]->order_name, $dir );
                            else {
                                $type_u_order = 1;
                                $dir_ordr = $dir;
                            }
                    }
                }
                if ($check == 1)
                    $this->db->group_by ( "{$table}.{$id_name}" );
                    
                    if (! is_null ( $limit )) {
                        if ($pagesize != "all")
                            $this->db->limit ( $limit, $offset );
                    }
                    
                    $this->db->where ( $table1 . '.isdeleted', '0' );
                    
                    $query = $this->db->get ();
                    // echo $this->db->last_query()."<br>";
                    // die;
                    $data1 = $query->result ();
                    $temp = array ();
                    $i = 0;
                    foreach ( $data1 as $k => $v ) {
                        $temp [$i] = $v;
                        $temp [$i]->type = "Adulticide";
                        $i ++;
                    }
                    $data1 = $temp;
                    // print'<pre>';
                    // print_r($data1);
                    // print_r($data1);
                    // die;
                    
                    // echo $this->db->last_query()."<br/>";
                    // die;
                    
                    $this->db->from ( "{$table2}" );
                    $this->db->select ( "{$table2}.{$id2_name}" );
                    $join = 0;
                    $multilang = FALSE;
                    $flag = "";
                    $check = 0;
                    
                    foreach ( $fields as $field ) {
                        
                        switch ($field->type) {
                            // Reference
                            case '1-n' :
                                $id1 = $table2 . "." . $field->db_name;
                                
                                if ($field->ref_table_db_name == $flag) {
                                    $this->db->select ( "{$field->ref_table_db_name}.{$field->ref_field_db_name} AS `{$field->unique_name}`" );
                                    break;
                                }
                                // $id2 = $field->ref_table_db_name . "_join" . $join . ".{$field->ref_table_id_name}";
                                // $this->db->join("{$field->ref_table_db_name} {$field->ref_table_db_name}_join{$join}", $id1 . " = " . $id2, "left");
                                $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                                $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                                
                                // $this->db->select("{$field->ref_table_db_name}_join{$join}.{$field->ref_field_db_name} AS `{$field->unique_name}`");
                                $this->db->select ( "{$field->ref_table_db_name}.{$field->ref_field_db_name} AS `{$field->unique_name}`" );
                                
                                $field->table_name = $field->ref_table_db_name; // . "_join" . $join;
                                $field->order_name = $field->ref_field_db_name;
                                $flag = $field->ref_table_db_name;
                                $join ++;
                                // Select foreign keys as well
                                if ($ref_ids) {
                                    // $this->db->select("{$table}_main.{$field->db_name} AS `{$field->db_name}`");
                                    $this->db->select ( "{$table2}.{$field->db_name} AS `{$field->unique_name}_id`" );
                                }
                                break;
                            case '1+2' :
                                $field1 = $table2 . "." . $field->db_name_1;
                                
                                $field2 = $table2 . "." . $field->db_name_2;
                                
                                $this->db->select ( "$field1 AS `$field->db_name_1`,$field2 AS `$field->db_name_2`" );
                                break;
                            case '1+2+3+4+5' :
                                $field1 = $table2 . "." . $field->db_name_1;
                                
                                $field2 = $table2 . "." . $field->db_name_2;
                                
                                $field3 = $table2 . "." . $field->db_name_3;
                                
                                $field4 = $table2 . "." . $field->db_name_4;
                                
                                $field5 = $table2 . "." . $field->db_name_5;
                                
                                $this->db->select ( "$field1 AS `$field->db_name_1`,$field2 AS `$field->db_name_2`,$field3 AS `$field->db_name_3`,$field4 AS `$field->db_name_4`,$field5 AS `$field->db_name_5`" );
                                break;
                            case '1-(1+2+3)-1-1' :
                                $id1 = $table2 . "." . $field->db_name;
                                
                                $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                                
                                $id3 = $field->ref_table_1_db_name . "." . $field->ref_table_1_id_name;
                                
                                $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                                
                                $this->db->join ( "{$field->ref_table_1_db_name}", $id2 . " = " . $id3, "left" );
                                
                                $this->db->select ( "{$field->ref_table_db_name}.{$field->ref_field_db_name},{$field->ref_table_db_name}.{$field->ref_field_1_db_name},{$field->ref_table_db_name}.{$field->ref_field_2_db_name},{$field->ref_table_1_db_name}.{$field->ref_field_1_1_db_name}" );
                                break;
                            case '1-1+2' :
                                
                                $id1 = $table2 . "." . $field->db_name;
                                
                                $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                                
                                $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                                
                                $this->db->select ( "{$field->ref_table_db_name}.{$field->ref_field_db_name},{$field->ref_table_db_name}.{$field->ref_field_2_db_name}" );
                                break;
                            case '1-t' :
                                
                                $id1 = $table2 . "." . $field->db_name;
                                
                                $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                                
                                $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                                
                                $this->db->select ( "sum({$field->ref_table_db_name}.{$field->ref_field_db_name}) AS count " );
                                $check = 1;
                                break;
                            case '1-1-1' :
                                $id1 = $table2 . "." . $field->db_name;
                                // $id2 = $field->ref_table_db_name . "_join" . $join . ".{$field->ref_table_id_name}";
                                // $this->db->join("{$field->ref_table_db_name} {$field->ref_table_db_name}_join{$join}", $id1 . " = " . $id2, "left");
                                $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                                if ($field->ref_table_db_name != $flag) {
                                    $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                                }
                                
                                $id2_1 = $field->ref_table_db_name . "." . $field->ref_table_id2_name;
                                $id3 = $field->ref_table_db2_name . "." . $field->ref_table_id2_name;
                                
                                $this->db->join ( "{$field->ref_table_db2_name}", $id2_1 . " = " . $id3, "left" );
                                // $this->db->select("{$field->ref_table_db_name}_join{$join}.{$field->ref_field_db_name} AS `{$field->unique_name}`");
                                $this->db->select ( "{$field->ref_table_db2_name}.{$field->ref_field_db2_name} AS `{$field->reference_uniq_name}`" );
                                
                                $field->table_name = $field->ref_table_db_name; // . "_join" . $join;
                                $field->order_name = $field->ref_field_db_name;
                                $flag = $field->ref_table_db_name;
                                $join ++;
                                // Select foreign keys as well
                                if ($ref_ids) {
                                    // $this->db->select("{$table}_main.{$field->db_name} AS `{$field->db_name}`");
                                    $this->db->select ( "{$table2}.{$field->db_name} AS `{$field->unique_name}_id`" );
                                }
                                break;
                            case 'u' :
                                
                                break;
                            case '1-n-u' :
                                
                                break;
                            default :
                                $field->table_name = $table2; // . "_main";
                                $field->order_name = $field->db_name;
                                // $this->db->select("{$table}_main.{$field->db_name} AS `{$field->unique_name}`");
                                if (! empty ( $filter_date )) {
                                    if (preg_match_all ( '/date/', $field->db_name, $matches )) {
                                        $filter_date1 = $table2 . "." . $field->db_name;
                                    }
                                }
                                $this->db->select ( "{$table2}.{$field->db_name} AS `{$field->unique_name}`" );
                        }
                    }
                    // add additional condition when service request come
                    // if(!empty($table1_rel) && !empty($table2_rel))
                    // {
                        // $additinal_var2 = $table2_rel.'.'.$id2_name.'='.$table2.'.'.$id2_name;
                        //
                        // $this->db->join($table2_rel,$additinal_var2,'INNER');
                        //
                        // }
                        if (! empty ( $service_rqstid )) {
                            switch ($table2) {
                                case 'larvaltreatments' :
                                    $table2_rel = 'larvaltreatmentservice';
                                    break;
                            }
                            $additinal_var = $table2 . '.' . $id2_name . '=' . $table2_rel . '.' . $id2_name;
                            $this->db->where ( $table2_rel . '.idservicerequest', $service_rqstid );
                            $this->db->join ( $table2_rel, $additinal_var, 'INNER' );
                        } else if (! empty ( $_GET ['service_req_id'] )) {
                            switch ($table2) {
                                case 'larvaltreatments' :
                                    $table2_rel = 'larvaltreatmentservice';
                                    break;
                            }
                            $additinal_var = $table2 . '.' . $id2_name . '=' . $table2_rel . '.' . $id2_name;
                            $this->db->where ( $table2_rel . '.idservicerequest', $_GET ['service_req_id'] );
                            $this->db->join ( $table2_rel, $additinal_var, 'INNER' );
                        }
                        
                        if (! empty ( $adultkey )) {
                            switch ($table2) {
                                case 'larvaltreatments' :
                                    $table2_rel = 'larvaltreatmentlarval';
                                    break;
                            }
                            $additinal_var = $table2 . '.' . $id2_name . '=' . $table2_rel . '.' . $id2_name;
                            $this->db->where ( $table2_rel . '.idlarval', $adultkey );
                            $this->db->join ( $table2_rel, $additinal_var, 'INNER' );
                        } else if (! empty ( $_GET ['adult_key'] )) {
                            switch ($table2) {
                                case 'larvaltreatments' :
                                    $table2_rel = 'larvaltreatmentlarval';
                                    break;
                            }
                            $additinal_var = $table2 . '.' . $id2_name . '=' . $table2_rel . '.' . $id2_name;
                            $this->db->where ( $table2_rel . '.idlarval', $_GET ['adult_key'] );
                            $this->db->join ( $table2_rel, $additinal_var, 'INNER' );
                        }
                        // Set filters
                        // $this->set_filters($filters);
                        
                        if ($table2 == "users") {
                            $this->db->join ( 'userlocationassignment AS ula', "{$table2}.{$id_name} = ula.iduser", 'LEFT' );
                            $this->db->join ( 'locations AS l', "ula.idlocation = l.idlocation", 'LEFT' );
                            
                            if (isset ( $filters )) {
                                $this->db->where ( "ula.idlocation", $filters [0] ['value'] );
                            }
                        } else if (in_array ( "{$table2}", $this->cond_sarr )) {
                            $this->db->join ( 'sites AS s', "{$table2}.idsite = s.idsite", 'LEFT' );
                            $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                            
                            if (isset ( $filters )) {
                                $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                            }
                        } else if (in_array ( "{$table2}", $this->cond_all_sarr )) {
                            $this->db->join ( 'locations AS l', "sites.idlocation = l.idlocation", 'LEFT' );
                            
                            if (! empty ( $filters )) {
                                $this->db->where ( "sites.idlocation", $filters [0] ['value'] );
                            }
                        } else if (in_array ( "{$table2}", $this->cond_tarr )) {
                            $this->db->join ( 'traps AS t', "{$table2}.idtrap = t.idtrap", 'LEFT' );
                            $this->db->join ( 'sites AS s', "t.idsite = s.idsite", 'LEFT' );
                            $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                            
                            if (isset ( $filters )) {
                                $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                            }
                        } else if (in_array ( "{$table2}", $this->cond_larr )) {
                            $this->db->join ( 'sentinelchicken AS senti', "{$table2}.idsentinelchicken = senti.idsentinelchicken", 'LEFT' );
                            $this->db->join ( 'sites AS s', "senti.idsite = s.idsite", 'LEFT' );
                            $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                            
                            if (isset ( $filters )) {
                                $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                            }
                        } else {
                            $this->db->join ( 'locations AS l', "{$table2}.idlocation = l.idlocation", 'LEFT' );
                            
                            if (isset ( $filters )) {
                                $this->db->where ( "{$table2}.idlocation", $filters [0] ['value'] );
                            }
                        }
                        
                        if (! is_null ( $item_id )) {
                            // $this->db->where("{$table}_main.{$id_name}", $item_id);
                            $this->db->where ( "{$table2}.{$id_name}", $item_id );
                        }
                        if (! is_null ( $filter_date ) && is_null ( $filter_daterange )) {
                            switch ($filter_date) {
                                // date('H:i:s',strtotime('-1 day');
                                case '1' :
                                    $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
                                    // $this->db->where($filter_time.' >=',date('H:i:s'));
                                    $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                                    // $this->db->where( $filter_time.' <=',"22:01:01");
                                    break;
                                    
                                case '2' :
                                    $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
                                    // $this->db->where($filter_time.' >=',date('H:i:s'));
                                    $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                                    // $this->db->where( $filter_time.' <=',"22:01:01");
                                    break;
                                case '3' :
                                    $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
                                    // $this->db->where($filter_time.' >=',date('H:i:s'));
                                    $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                                    // $this->db->where( $filter_time.' <=',"22:01:01");
                                    break;
                                case '4' :
                                    $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
                                    // $this->db->where($filter_time.' >=',date('H:i:s'));
                                    $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                                    // $this->db->where( $filter_time.' <=',date('H:i:s',strtotime('-4 month')));
                                    break;
                                case '5' :
                                    $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
                                    // $this->db->where($filter_time.' >=',date('H:i:s'));
                                    $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                                    // $this->db->where( $filter_time.' <=',date('H:i:s',strtotime('-1 year')));
                                    break;
                            }
                        }
                        
                        if (in_array ( $table2, $this->date_arr ))
                            if (! is_null ( $filter_daterange )) {
                                $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) );
                                $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) );
                            }
                        
                        if (! is_null ( $order )) {
                            foreach ( $order as $field_id => $dir ) {
                                if ($field_id != 3)
                                    $this->db->order_by ( $fields [$field_id]->table_name . "." . $fields [$field_id]->order_name, $dir );
                                    else {
                                        $type_u_order = 1;
                                        $dir_ordr = $dir;
                                    }
                            }
                        }
                        if ($check == 1)
                            $this->db->group_by ( "{$table2}.{$id_name}" );
                            
                            if (! is_null ( $limit )) {
                                if ($pagesize != "all")
                                    $this->db->limit ( $limit, $offset );
                            }
                            $this->db->where ( $table2 . '.isdeleted', '0' );
                            $query = $this->db->get ();
                            
                            $data2 = $query->result ();
                            
                            $temp = array ();
                            $i = 0;
                            foreach ( $data2 as $k => $v ) {
                                $temp [$i] = $v;
                                $temp [$i]->type = "Larvicide";
                                $i ++;
                            }
                            $data2 = $temp;
                            
                            // print'<pre>';
                            // print_r($query->result());
                            // die;
                            
                            // echo "<br>".$this->db->last_query();
                            // die;
                            $data = array ();
                            if (! empty ( $data1 ) && ! empty ( $data2 )) {
                                if ($type_u_order == 1 && $dir == "DESC")
                                    $data = array_merge ( $data2, $data1 );
                                    else
                                        $data = array_merge ( $data1, $data2 );
                            } else if (! empty ( $data1 ) && empty ( $data2 ))
                                $data = $data1;
                                else if (! empty ( $data2 ) && empty ( $data1 ))
                                    $data = $data2;
                                    
                                    return $data;
                                    // print'<pre>';
                                    // print_r($data);
                                    // die;
        }
        return $data;
    }
    
    /**
     * Get item
     */
    function get_item($table, $id_name, $fields, $item_id) {
        $data = $this->get_items ( $table, $id_name, $fields, $item_id, array (), NULL, 0, NULL, TRUE );
        
        return reset ( $data );
    }
    
    /**
     * Get duplicate
     */
    function get_duplicate($table, $id_name, $field, $value, $item_id = NULL) {
        if (! is_null ( $item_id )) {
            $this->db->where ( "{$id_name} !=", $item_id );
        }
        
        $this->db->where ( $field, $value );
        
        $query = $this->db->get ( $table );
        
        if ($query->num_rows () > 0) {
            return FALSE;
        }
        
        return TRUE;
    }
    
    /**
     * Count items
     */
    function count_items($table, $id_name, $fields, $filters = array(), $filter_date = NULL, $filter_site = NULL, $filter_daterange = NULL, $filter_lab = NULL, $filter_trap = NULL, $filter_city = NULL, $filter_status = NULL, $table1_rel = NULL, $service_rqstid = NULL, $idsentinel = NULL, $futureassign = NULL, $pendingassign = NULL, $filter_sitetype = NULL, $filter_siteofinterest = NULL, $order = NULL, $filter_wanum = NULL) {
        $tbl_arr = array ();
        $ref_ids = "";
        $columnno = '';
        if ($table == "sites" && ! is_null ( $filter_site )) {
            $this->db->select ( 'site' );
            $this->db->from ( 'sites AS s' );
            $this->db->where ( 's.idsite', $filter_site );
            
            $q = $this->db->get ();
            
            if ($q->num_rows () > 0) {
                $this->sitename = $q->result_array ();
                $this->sitename = $this->sitename [0] ['site'];
            }
        }
        
        if (count ( $fields )) {
            // $this->db->from($table . " " . $table . "_main");
            $this->db->select ( "COUNT(*) AS count" );
            $this->db->from ( "{$table}" );
            
            $this->db->select ( "{$table}.{$id_name}" );
            $join = 0;
            $check = 0;
            $filter_lab_table = "labresults.labresult";
            $flag = "";
            $filter_date1 = "";
            foreach ( $fields as $field ) {
                switch ($field->type) {
                    // Reference
                    case '1-n' :
                        
                        if (in_array ( $field->ref_table_db_name, $tbl_arr ))
                            break;
                            
                            $id1 = $table . ".{$field->db_name}";
                            $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                            $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                            $flag = $field->ref_table_db_name;
                            $tbl_arr [] = $field->ref_table_db_name;
                            
                            if (! is_null ( $filter_lab ) && $filter_lab_table == "{$field->ref_table_db_name}.{$field->ref_field_db_name}") {
                                // echo "here".$filter_lab ." "."{$field->ref_table_db_name}.{$field->ref_field_db_name}";
                                switch ($filter_lab) {
                                    case '1' :
                                        $this->db->where ( "{$field->ref_table_db_name}.{$field->ref_field_db_name}", "Positive" );
                                        break;
                                    case '2' :
                                        $this->db->where ( "{$field->ref_table_db_name}.{$field->ref_field_db_name}", "Negative" );
                                        break;
                                    case '3' :
                                        $this->db->where ( "{$field->ref_table_db_name}.{$field->ref_field_db_name}", "Pending" );
                                        break;
                                }
                            }
                            
                            if (preg_match_all ( '/date/', $field->ref_field_db_name, $matches )) {
                                $filter_date1 = "{$field->ref_table_db_name}.{$field->ref_field_db_name}";
                            }
                            break;
                    case 'n-1' :
                        $id1 = $table . "." . $field->ref_table_id_name;
                        
                        // $id2 = $field->ref_table_db_name . "_join" . $join . ".{$field->ref_table_id_name}";
                        // $this->db->join("{$field->ref_table_db_name} {$field->ref_table_db_name}_join{$join}", $id1 . " = " . $id2, "left");
                        $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                        
                        $this->db->select ( $table . "." . $field->db_name );
                        
                        if (! in_array ( $field->ref_table_db_name, $tbl_arr )) {
                            // echo $id2." ".$field->ref_table_id_val;
                            $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                            if ($table != 'sentinelchicken')
                                $this->db->where ( $id2, "{$field->ref_table_id_val}" );
                        }
                        
                        $field->table_name = $table . "." . $field->ref_table_id_name; // . "_join" . $join;
                        $field->order_name = $table . "." . $field->ref_table_id_name;
                        $flag = $field->ref_table_id_name;
                        $tbl_arr [] = $field->ref_table_db_name;
                        $join ++;
                        // Select foreign keys as well
                        if ($ref_ids) {
                            // $this->db->select("{$table}_main.{$field->db_name} AS `{$field->db_name}`");
                            $this->db->select ( "{$table}.{$field->db_name} AS `{$field->unique_name}_id`" );
                        }
                        
                        if (preg_match_all ( '/date/', $field->ref_field_db_name, $matches )) {
                            $filter_date1 = "{$field->ref_table_db_name}.{$field->ref_field_db_name}";
                        }
                        break;
                    case '1+2' :
                        $field1 = $table . "." . $field->db_name_1;
                        
                        $field2 = $table . "." . $field->db_name_2;
                        
                        $this->db->select ( "$field1 AS `$field->db_name_1`,$field2 AS `$field->db_name_2`" );
                        $field->table_name = $table;
                        $field->order_name = $field->db_name_1;
                        if (! empty ( $filter_date )) {
                            if (preg_match_all ( '/date/', $field1, $matches )) {
                                $filter_date1 = $field1;
                            }
                        }
                        break;
                    case '1+2+3+4+5' :
                        $field1 = $table . "." . $field->db_name_1;
                        
                        $field2 = $table . "." . $field->db_name_2;
                        
                        $field3 = $table . "." . $field->db_name_3;
                        
                        $field4 = $table . "." . $field->db_name_4;
                        
                        $field5 = $table . "." . $field->db_name_5;
                        
                        $this->db->select ( "$field1 AS `$field->db_name_1`,$field2 AS `$field->db_name_2`,$field3 AS `$field->db_name_3`,$field4 AS `$field->db_name_4`,$field5 AS `$field->db_name_5`" );
                        
                        $field->table_name = $table;
                        $field->order_name = $field->db_name_1;
                        break;
                    case '1-(1+2)-1-1' :
                        $id1 = $table . "." . $field->db_name;
                        
                        $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                        
                        $id3 = $field->ref_table_1_db_name . "." . $field->ref_table_1_id_name;
                        
                        $id4 = $field->ref_table_db_name . "." . $field->ref_table_1_id_name;
                        
                        if (! in_array ( $field->ref_table_db_name, $tbl_arr )) {
                            $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                            $tbl_arr [] = $field->ref_table_db_name;
                        }
                        
                        if (! in_array ( $field->ref_table_1_db_name, $tbl_arr )) {
                            $this->db->join ( "{$field->ref_table_1_db_name}", $id4 . " = " . $id3, "left" );
                            $tbl_arr [] = $field->ref_table_1_db_name;
                        }
                        
                        $this->db->select ( "{$field->ref_table_db_name}.{$field->ref_field_db_name},{$field->ref_table_db_name}.{$field->ref_field_1_db_name},{$field->ref_table_1_db_name}.{$field->ref_field_1_1_db_name}" );
                        
                        $field->table_name = $field->ref_table_db_name;
                        $field->order_name = $field->ref_field_db_name;
                        
                        $flag = $field->ref_table_db_name;
                        
                        $flag_1_3_1_1 = $field->ref_table_db_name;
                        
                        $flag2 = $field->ref_table_1_db_name;
                        
                        $flag_1_2_1_1 = $field->ref_table_1_db_name;
                        
                        break;
                    case '1-(1+2+3)-1-1' :
                        $id1 = $table . "." . $field->db_name;
                        
                        $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                        
                        $id3 = $field->ref_table_1_db_name . "." . $field->ref_table_1_id_name;
                        
                        $id4 = $field->ref_table_db_name . "." . $field->ref_table_1_id_name;
                        
                        if (! in_array ( $field->ref_table_db_name, $tbl_arr )) {
                            $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                            $tbl_arr [] = $field->ref_table_db_name;
                        }
                        
                        if (! in_array ( $field->ref_table_1_db_name, $tbl_arr )) {
                            $this->db->join ( "{$field->ref_table_1_db_name}", $id4 . " = " . $id3, "left" );
                            $tbl_arr [] = $field->ref_table_1_db_name;
                        }
                        
                        $this->db->select ( "{$field->ref_table_db_name}.{$field->ref_field_db_name},{$field->ref_table_db_name}.{$field->ref_field_1_db_name},{$field->ref_table_db_name}.{$field->ref_field_2_db_name},{$field->ref_table_1_db_name}.{$field->ref_field_1_1_db_name}" );
                        
                        $field->table_name = $field->ref_table_db_name;
                        $field->order_name = $field->ref_field_db_name;
                        
                        $flag = $field->ref_table_db_name;
                        
                        $flag_1_3_1_1 = $field->ref_table_db_name;
                        
                        $flag2 = $field->ref_table_1_db_name;
                        
                        $flag_1_2_1_1 = $field->ref_table_1_db_name;
                        
                        break;
                    case '1-1+2' :
                        
                        $id1 = $table . "." . $field->db_name;
                        
                        $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                        
                        if (! in_array ( $field->ref_table_db_name, $tbl_arr )) {
                            $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                            $tbl_arr [] = $field->ref_table_db_name;
                        }
                        
                        $this->db->select ( "{$field->ref_table_db_name}.{$field->ref_field_db_name},{$field->ref_table_db_name}.{$field->ref_field_2_db_name}" );
                        
                        $field->table_name = $field->ref_table_db_name;
                        $field->order_name = $field->ref_field_db_name;
                        
                        $flag = $field->ref_table_db_name;
                        
                        $flag_1_2_1 = $field->ref_table_db_name;
                        
                        break;
                    case '1-1+2+3' :
                        
                        $id1 = $table . "." . $field->db_name;
                        
                        $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                        
                        if (! in_array ( $field->ref_table_db_name, $tbl_arr )) {
                            $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                            $tbl_arr [] = $field->ref_table_db_name;
                        }
                        
                        $this->db->select ( "{$field->ref_table_db_name}.{$field->ref_field_db_name},{$field->ref_table_db_name}.{$field->ref_field_2_db_name},{$field->ref_table_db_name}.{$field->ref_field_3_db_name}" );
                        
                        $field->table_name = $field->ref_table_db_name;
                        $field->order_name = $field->ref_field_db_name;
                        
                        $flag = $field->ref_table_db_name;
                        
                        $flag_1_2_3 = $field->ref_table_db_name;
                        
                        break;
                    case '1-1-(1)-(2)' :
                        $id1 = $table . "." . $field->db_name;
                        
                        $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                        
                        $id2_1 = $field->ref_table_db_name . "." . $field->ref_table_1_id_name;
                        
                        $id3 = $field->ref_table_1_db_name . "." . $field->ref_table_1_id_name;
                        
                        if (! in_array ( $field->ref_table_db_name, $tbl_arr )) {
                            $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                            $tbl_arr [] = $field->ref_table_db_name;
                        }
                        
                        if (! in_array ( $field->ref_table_1_db_name, $tbl_arr )) {
                            $this->db->join ( "{$field->ref_table_1_db_name}", $id2_1 . " = " . $id3, "left" );
                            $tbl_arr [] = $field->ref_table_1_db_name;
                        }
                        
                        $this->db->select ( "{$field->ref_table_db_name}.{$field->ref_field_db_name},{$field->ref_table_1_db_name}.{$field->ref_field_1_db_name}" );
                        $field->table_name = $field->ref_table_db_name; // . "_join" . $join;
                        $field->order_name = $field->ref_field_db_name;
                        
                        $flag = $field->ref_table_db_name;
                        
                        $flag_1_1_1_1 = $field->ref_table_db_name;
                        
                        $flag2 = $field->ref_table_1_db_name;
                        
                        $flag_1_1_1_2 = $field->ref_table_1_db_name;
                        
                        break;
                    case '1-(1)-2' :
                        $id1 = $table . "." . $field->ref_table_id_name;
                        
                        $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                        
                        if (! in_array ( $field->ref_table_db_name, $tbl_arr )) {
                            $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                            $tbl_arr [] = $field->ref_table_db_name;
                        }
                        
                        $this->db->select ( "{$field->db_name},{$field->ref_table_db_name}.{$field->ref_field_db_name}" );
                        $field->table_name = $table; // . "_join" . $join;
                        $field->order_name = $field->db_name;
                        $flag = $field->ref_table_db_name;
                        $flag_1_1_2 = $field->ref_table_db_name;
                        
                        break;
                    case '1-1-1' :
                        $id1 = $table . "." . $field->db_name;
                        $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                        if (! in_array ( $field->ref_table_db_name, $tbl_arr )) {
                            $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                            $tbl_arr [] = $field->ref_table_db_name;
                        }
                        
                        $id2_1 = $field->ref_table_db_name . "." . $field->ref_table_id2_name;
                        $id3 = $field->ref_table_db2_name . "." . $field->ref_table_id2_name;
                        
                        if (! in_array ( $field->ref_table_db2_name, $tbl_arr )) {
                            $this->db->join ( "{$field->ref_table_db2_name}", $id2_1 . " = " . $id3, "left" );
                            $tbl_arr [] = $field->ref_table_db2_name;
                        }
                        
                        $this->db->select ( "{$field->ref_table_db2_name}.{$field->ref_field_db2_name} AS `{$field->reference_uniq_name}`" );
                        
                        if ($field->ref_table_db2_name == 'zones') {
                            $field->table_name = $field->ref_table_db2_name; // . "_join" . $join;
                            $field->order_name = $field->ref_field_db2_name;
                        } else {
                            $field->table_name = $field->ref_table_db_name; // . "_join" . $join;
                            $field->order_name = $field->ref_field_db_name;
                        }
                        
                        $flag = $field->ref_table_db_name;
                        $flag_1_1_1 = $field->ref_table_db_name;
                        
                        $join ++;
                        // Select foreign keys as well
                        if ($ref_ids) {
                            // $this->db->select("{$table}_main.{$field->db_name} AS `{$field->db_name}`");
                            $this->db->select ( "{$table}.{$field->db_name} AS `{$field->unique_name}_id`" );
                        }
                        break;
                    default :
                        if (! empty ( $filter_date )) {
                            if (preg_match_all ( '/date/', $field->db_name, $matches )) {
                                $filter_date1 = $table . "." . $field->db_name;
                            }
                        }
                }
            }
            
            if (! empty ( $service_rqstid )) {
                switch ($table) {
                    case 'larvalsurveillance' :
                        $table1_rel = 'larvalsurveillanceservice';
                        break;
                    case 'adultsurveillance' :
                        $table1_rel = 'adultsurveillanceservice';
                        break;
                }
                $additinal_var = $table . '.' . $id_name . '=' . $table1_rel . '.' . $id_name;
                $this->db->where ( $table1_rel . '.idservicerequest', $service_rqstid );
                $this->db->join ( $table1_rel, $additinal_var, 'INNER' );
            } else if (! empty ( $_GET ['service_req_id'] )) {
                switch ($table) {
                    case 'larvalsurveillance' :
                        $table1_rel = 'larvalsurveillanceservice';
                        break;
                    case 'adultsurveillance' :
                        $table1_rel = 'adultsurveillanceservice';
                        break;
                }
                $additinal_var = $table . '.' . $id_name . '=' . $table1_rel . '.' . $id_name;
                $this->db->where ( $table1_rel . '.idservicerequest', $_GET ['service_req_id'] );
                $this->db->join ( $table1_rel, $additinal_var, 'INNER' );
            }
            
            if ($table == "users") {
                $this->db->join ( 'userlocationassignment AS ula', "{$table}.{$id_name} = ula.iduser", 'LEFT' );
                $this->db->join ( 'locations AS l', "ula.idlocation = l.idlocation", 'LEFT' );
                
                if (! empty ( $filters )) {
                    $this->db->where ( "ula.idlocation", $filters [0] ['value'] );
                }
            } else if (in_array ( "{$table}", $this->cond_sarr )) {
                $this->db->join ( 'sites AS s', "{$table}.idsite = s.idsite", 'LEFT' );
                $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                
                if (! empty ( $filters )) {
                    $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                }
            } else if (in_array ( "{$table}", $this->cond_all_sarr )) {
                $this->db->join ( 'locations AS l', "sites.idlocation = l.idlocation", 'LEFT' );
                
                if (! empty ( $filters )) {
                    $this->db->where ( "sites.idlocation", $filters [0] ['value'] );
                }
            } else if (in_array ( "{$table}", $this->cond_warr )) {
                $this->db->join ( 'weathersensors AS ws', "{$table}.idweathersensor = ws.idweathersensor", "LEFT" );
                $this->db->join ( 'sites AS s', "ws.idsite = s.idsite", 'LEFT' );
                $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                
                if (! empty ( $filters )) {
                    $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                }
            } else if (in_array ( "{$table}", $this->cond_tarr )) {
                
                $this->db->join ( 'sites AS s', "traps.idsite = s.idsite", 'LEFT' );
                $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                
                if (! empty ( $filters )) {
                    $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                }
            } else if (in_array ( "{$table}", $this->cond_larr )) {
                $this->db->join ( 'sentinelchicken AS senti', "{$table}.idsentinelchicken = senti.idsentinelchicken", 'LEFT' );
                $this->db->join ( 'sites AS s', "senti.idsite = s.idsite", 'LEFT' );
                $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                
                if (! empty ( $filters )) {
                    $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                }
            } else if (in_array ( "{$table}", $this->cond_marr )) {
                // $this->db->join('locations AS l',"{$table}.GUID = l.GUID",'LEFT');
                //
                // if(!empty($filters))
                // {
                // $this->db->where("l.idlocation", $filters[0]['value']);
                    // }
                } else if (in_array ( "{$table}", $this->cond_xarr )) {
                    if (! empty ( $filters )) {
                        $this->db->where ( "{$table}.idlocation", $filters [0] ['value'] );
                    }
                } else {
                    if (! empty ( $filters )) {
                        $this->db->join ( 'locations AS l', "{$table}.idlocation = l.idlocation", 'LEFT' );
                        $this->db->where ( "{$table}.idlocation", $filters [0] ['value'] );
                    }
                }
                
                if ($check == 1)
                    $this->db->group_by ( "{$table}.{$id_name}" );
                    
                    if (is_null ( $filter_status ))
                        $filter_status = 3;
                        
                        if (in_array ( $table, $this->date_arr ))
                            
                            if (! is_null ( $filter_date ) && (empty ( $filter_daterange ) || (!empty ( $filter_daterange ) && isset($filter_daterange[0]) && empty($filter_daterange[1]))) && empty ( $pendingassign ) && empty ( $futureassign )) {
                                
                                if ($table == "servicerequests" && ! is_null ( $filter_status )) {
                                    switch ($filter_status) {
                                        case '1' :
                                            $where = ' (servicerequests.closedate IS NULL OR servicerequests.closedate = "" OR  servicerequests.closedate = "0000-00-00")';
                                            $this->db->where ( $where );
                                            switch ($filter_date) {
                                                // date('H:i:s',strtotime('-1 day');
                                                case '1' :
                                                    $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
                                                    $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                    break;
                                                    
                                                case '2' :
                                                    $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
                                                    $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                    break;
                                                case '3' :
                                                    $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
                                                    $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                    break;
                                                case '4' :
                                                    
                                                    $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
                                                    $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                    break;
                                                case '5' :
                                                    $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
                                                    $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                    break;
                                                case '6' :
                                                    $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) );
                                                    $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) );
                                                    break;
                                            }
                                            break;
                                        case '2' :
                                            $where = '(servicerequests.closedate IS NOT NULL AND servicerequests.closedate != "" AND servicerequests.closedate != "0000-00-00")';
                                            $this->db->where ( $where );
                                            switch ($filter_date) {
                                                // date('H:i:s',strtotime('-1 day');
                                                case '1' :
                                                    $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
                                                    $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                    break;
                                                    
                                                case '2' :
                                                    $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
                                                    $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                    break;
                                                case '3' :
                                                    $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
                                                    $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                    break;
                                                case '4' :
                                                    
                                                    $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
                                                    $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                    break;
                                                case '5' :
                                                    $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
                                                    $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                    break;
                                                case '6' :
                                                    $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) );
                                                    $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) );
                                                    break;
                                            }
                                            break;
                                        case '3' :
                                            switch ($filter_date) {
                                                case '1' :
                                                    $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
                                                    $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                    break;
                                                    
                                                case '2' :
                                                    $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
                                                    $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                    break;
                                                case '3' :
                                                    $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
                                                    $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                    break;
                                                case '4' :
                                                    
                                                    $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
                                                    $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                    break;
                                                case '5' :
                                                    $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
                                                    $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d' ) );
                                                    break;
                                                case '6' :
                                                    $this->db->where ( 'servicerequests.opendate >=', date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) );
                                                    $this->db->where ( 'servicerequests.opendate <=', date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) );
                                                    break;
                                            }
                                            break;
                                    }
                                } else {
                                    switch ($filter_date) {
                                        case '1' :
                                            $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
                                            $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                                            break;
                                        case '2' :
                                            $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
                                            $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                                            break;
                                        case '3' :
                                            $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
                                            $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                                            break;
                                        case '4' :
                                            $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
                                            $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                                            break;
                                        case '5' :
                                            $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
                                            $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                                            break;
                                        case '6' :
                                            $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) );
                                            $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) );
                                            break;
                                    }
                                }
                            } else if (! empty ( $futureassign )) {
                                switch ($filter_status) {
                                    case '1' :
                                        $where = ' (servicerequests.closedate IS NULL OR servicerequests.closedate = "" OR  servicerequests.closedate = "0000-00-00")';
                                        $this->db->where ( $where );
                                        break;
                                    case '2' :
                                        $where = '(servicerequests.closedate IS NOT NULL AND servicerequests.closedate != "" AND servicerequests.closedate != "0000-00-00")';
                                        $this->db->where ( $where );
                                        break;
                                    case '3' :
                                        break;
                                }
                                $this->db->where ( 'opendate >=', date ( 'Y-m-d' ) );
                            } else if (! empty ( $filter_daterange ) && isset($filter_daterange[0]) && !empty($filter_daterange[0])) {
                                if ($table == "servicerequests")
                                    switch ($filter_status) {
                                        case '1' :
                                            $where = "(servicerequests.closedate = '' OR servicerequests.closedate IS NULL OR servicerequests.closedate ='0000-00-00')";
                                            $this->db->where ( $where );
                                            $this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) );
                                            $this->db->where ( 'servicerequests.closedate' . ' <=', date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) );
                                            break;
                                        case '2' :
                                            $where = "(servicerequests.closedate != '' AND servicerequests.closedate IS NOT NULL AND servicerequests.closedate !='0000-00-00')";
                                            $this->db->where ( $where );
                                            $this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) );
                                            $this->db->where ( 'servicerequests.closedate' . ' <=', date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) );
                                            break;
                                        case '3' :
                                            $this->db->where ( 'servicerequests.opendate' . ' >=', date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) );
                                            $this->db->where ( 'servicerequests.closedate' . ' <=', date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) );
                                            break;
                                }
                            } else if (! empty ( $futureassign )) {
                                if ($table == "servicerequests")
                                    $this->db->where ( 'opendate >=', date ( 'Y-m-d' ) );
                            }
                            
                            if (in_array ( $table, $this->date_arr ))
                                if (! empty ( $filter_daterange ) && isset($filter_daterange[0]) && !empty($filter_daterange[0]) && is_null ( $futureassign )) {
                                    $this->db->where ( "DATE($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) );
                                    $this->db->where ( "DATE($filter_date1)"     . ' <=', date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) );
                                }
                            if ($table == "sites" && (! is_null ( $filter_site ) || ! is_null ( $filter_siteofinterest ))) {
                                if (! empty ( $filter_site ))
                                    $this->db->where ( 'sites.idsite', $filter_site );
                                    if (! empty ( $filter_siteofinterest )) {
                                        $siteofinterest = explode ( "_", $filter_siteofinterest );
                                        $sitetemp = '';
                                        $or = '';
                                        foreach ( $siteofinterest as $key => $val ) {
                                            switch ($val) {
                                                case '1' :
                                                    $sitetemp .= " sites.site_of_interest = '1'";
                                                    $or = ' OR';
                                                    break;
                                                case '2' :
                                                    $sitetemp .= $or . " sites.landingrate_site = '1'";
                                                    $or = ' OR';
                                                    break;
                                                case '3' :
                                                    $sitetemp .= $or . " sites.larval_site = '1'";
                                                    $or = ' OR';
                                                    break;
                                                case '4' :
                                                    $sitetemp .= $or . " sites.adult_site = '1'";
                                                    $or = ' OR';
                                                    break;
                                                case '5' :
                                                    $sitetemp .= $or . " sites.apiary = '1'";
                                                    $or = ' OR';
                                                    break;
                                                case '6' :
                                                    $sitetemp .= $or . " sites.contact_before_spray = '1'";
                                                    $or = ' OR';
                                                    break;
                                                case '7' :
                                                    $sitetemp .= $or . " sites.organic_farm = '1'";
                                                    $or = ' OR';
                                                    break;
                                                case '8' :
                                                    $sitetemp .= $or . " sites.nospray = '1'";
                                                    $or = ' OR';
                                                    break;
                                                case '9' :
                                                    $sitetemp .= $or . " sites.endangered_species = '1'";
                                                    $or = ' OR';
                                                    break;
                                            }
                                        }
                                        if (! empty ( $sitetemp )) {
                                            $sitetemp = "(" . trim ( $sitetemp, "OR" ) . ")";
                                            // echo "siet temp".$sitetemp."\n";
                                            $this->db->where ( $sitetemp );
                                        }
                                    }
                            } else if ($table == "sites" && ! is_null ( $filter_sitetype )) {
                                $this->db->join ( 'sitetypes AS st', 'sites.idsitetype = st.idsitetype', 'left' );
                                $this->db->where ( 'sites.idsitetype', $filter_sitetype );
                            }
                            
                            if ($table == "monitormgmt")
                                $this->db->where ( 'monitormgmt.status', '0' );
                                
                                if ($table == "arbovirallabs" && ! is_null ( $filter_trap ))
                                    $this->db->like ( 'traps.trap', $filter_trap, 'after' );
                                    
                                    if ($table == "servicerequests") {
                                        if (! is_null ( $filter_city )) {
                                            $this->db->like ( 'sites.city', $filter_city, 'none' );
                                        }
                                        
                                        if (! empty ( $filter_wanum )) {
                                            $this->db->where ( 'servicerequests.idservicerequest = '.$filter_wanum);
                                        }
                                        
                                        if (! is_null ( $pendingassign )) {
                                            $this->db->where ( "servicerequests.isapproved = '0'" );
                                            $this->db->where ( "sites.idlocation", $this->session->userdata ( 'idlocation' ) );
                                        } else
                                            $this->db->where ( "sites.idlocation", $this->session->userdata ( 'idlocation' ) );
                                    }
                                    if (! empty ( $idsentinel ) && $table == "sentinelchickensamples") {
                                        $this->db->where ( "sentinelchicken.idsentinelchicken", $idsentinel );
                                    }
                                    if ($table == "products") {
                                        $this->db->where ( "products.onhand >", '0' );
                                        $this->db->order_by ( "products.onhand", 'DESC' );
                                    }
                                    
                                    if ($table == "monitormgmt") {
                                        // $this->db->join('user_monitor AS um' , 'monitormgmt.idmonitor = um.idmonitor' , 'LEFT');
                                        // $this->db->select('um.user_id,um.idmonitor,um.status');
                                        // $this->db->where('um.status','0');
                                        // $this->db->where('um.user_id',$userid);
                                        // $this->db->group_by('monitormgmt.idmonitor');
                                        $this->db->join ( 'locations AS l', 'monitormgmt.GUID = l.GUID', 'INNER' );
                                        $this->db->where ( 'l.idlocation', $this->session->userdata ( 'idlocation' ) );
                                    }
                                    
                                    if (! in_array ( $table, $this->cond_deleted_arr ))
                                        $this->db->where ( $table . '.isdeleted', '0' );
                                        
                                        $query = $this->db->get ();
                                        // echo $this->db->last_query()."\n";
                                        $cpdata = 0;
                                        if ($table == "products") {
                                            $query1 = $this->db->query ( "SELECT products.idproduct, products.productname AS `productname`, productpotency.potency AS `productpotency_potency`, productmanufacturers.manufacturer AS `productmanufacturers_manufacturer`, productsizes.productsize AS `productsizes_productsize`, packsizes.packsize AS `packsizes_packsize`, products.onhand AS `onhand` FROM (products) LEFT JOIN productpotency ON products.idpotency = productpotency.idpotency LEFT JOIN productmanufacturers ON products.idmanufacturer = productmanufacturers.idmanufacturer LEFT JOIN productsizes ON products.idproductsize = productsizes.idproductsize LEFT JOIN packsizes ON products.idpacksize = packsizes.idpacksize LEFT JOIN locations AS l ON products.idlocation = l.idlocation WHERE products.idlocation = '" . $this->session->userdata ( 'idlocation' ) . "' AND products.onhand = 0 ORDER BY products.productname ASC" );
                                            // echo $query->row()->count." ".$query1->num_rows();
                                            // echo $this->db->last_query()."\n";
                                            // if ($query1->num_rows () > 0) {
                                            // 	$cpdata = $query->row ()->count + $query1->num_rows ();
                                            // }
                                            $cpdata = $query1->num_rows ();
                                        }
                                        // echo $cpdata."<br>";
                                        // print'<pre>';
                                        // print_r($pdata);
                                        // print'</pre>';
                                        // die;
                                        if (! empty ( $cpdata ))
                                            return $cpdata;
                                            // echo $this->db->last_query()." HERE<br>";
                                            // die;
                                            return $query->row ()->count;
        }
        return 0;
    }
    
    /**
     * Count items in case of Multiple Table
     * By UNION
     */
    function count_items_1($table1, $id1_name, $table2, $id2_name, $fields, $filters = array(), $table1_rel = NULL, $table2_rel = NULL, $filter_date = NULL, $page = NULL, $filter_daterange = NULL, $service_rqstid = NULL, $adultkey = NULL) {
        $filter_date1 = '';
        $filter_date2 = '';
        
        if (count ( $fields )) {
            $this->db->select ( "COUNT(*) AS count" );
            $this->db->from ( "{$table1}" );
            
            $this->db->select ( "{$table1}.{$id1_name}" );
            $join = 0;
            
            // print'<pre>';
            // print_r($fields);
            // print'<pre>';
            // die;
            $flag = "";
            foreach ( $fields as $field ) {
                switch ($field->type) {
                    // Reference
                    case '1-n' :
                        if ($field->ref_table_db_name == $flag)
                            break;
                            
                            $id1 = $table1 . ".{$field->db_name}";
                            $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                            $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                            $flag = $field->ref_table_db_name;
                            break;
                    default :
                        
                        if (! empty ( $filter_date )) {
                            if (preg_match_all ( '/date/', $field->db_name, $matches )) {
                                $filter_date1 = $table1 . "." . $field->db_name;
                            }
                        }
                }
                
                // echo $this->db->last_query()."<br>";
            }
            // die;
            // Set filters
            // $this->set_filters($filters);
            
            if (! empty ( $service_rqstid )) {
                switch ($table1) {
                    case 'adulticidetreatments' :
                        $table1_rel = 'adulticidetreatmentsservice';
                        break;
                }
                $additinal_var = $table1 . '.' . $id1_name . '=' . $table1_rel . '.' . $id1_name;
                $this->db->where ( $table1_rel . '.idservicerequest', $service_rqstid );
                $this->db->join ( $table1_rel, $additinal_var, 'INNER' );
            } else if (! empty ( $_GET ['service_req_id'] )) {
                switch ($table1) {
                    case 'adulticidetreatments' :
                        $table1_rel = 'adulticidetreatmentsservice';
                        break;
                }
                $additinal_var = $table1 . '.' . $id1_name . '=' . $table1_rel . '.' . $id1_name;
                $this->db->where ( $table1_rel . '.idservicerequest', $_GET ['service_req_id'] );
                $this->db->join ( $table1_rel, $additinal_var, 'INNER' );
            }
            
            if (! empty ( $adultkey )) {
                switch ($table1) {
                    case 'adulticidetreatments' :
                        $table1_rel = 'adulticidetreatmentslarval';
                        break;
                }
                $additinal_var = $table1 . '.' . $id1_name . '=' . $table1_rel . '.' . $id1_name;
                $this->db->where ( $table1_rel . '.idlarval', $adultkey );
                $this->db->join ( $table1_rel, $additinal_var, 'INNER' );
            } else if (! empty ( $_GET ['adult_key'] )) {
                switch ($table1) {
                    case 'adulticidetreatments' :
                        $table1_rel = 'adulticidetreatmentslarval';
                        break;
                }
                $additinal_var = $table1 . '.' . $id1_name . '=' . $table1_rel . '.' . $id1_name;
                $this->db->where ( $table1_rel . '.idlarval', $_GET ['adult_key'] );
                $this->db->join ( $table1_rel, $additinal_var, 'INNER' );
            }
            
            if ($table1 == "users") {
                $this->db->join ( 'userlocationassignment AS ula', "{$table1}.{$id_name} = ula.iduser", 'LEFT' );
                $this->db->join ( 'locations AS l', "ula.idlocation = l.idlocation", 'LEFT' );
                
                if (isset ( $filters )) {
                    $this->db->where ( "ula.idlocation", $filters [0] ['value'] );
                }
            } else if (in_array ( "{$table1}", $this->cond_sarr )) {
                $this->db->join ( 'sites AS s', "{$table1}.idsite = s.idsite", 'LEFT' );
                $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                
                if (isset ( $filters )) {
                    $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                }
            } else if (in_array ( "{$table1}", $this->cond_all_sarr )) {
                $this->db->join ( 'locations AS l', "sites.idlocation = l.idlocation", 'LEFT' );
                
                if (! empty ( $filters )) {
                    $this->db->where ( "sites.idlocation", $filters [0] ['value'] );
                }
            } else if (in_array ( "{$table1}", $this->cond_tarr )) {
                $this->db->join ( 'traps AS t', "{$table1}.idtrap = t.idtrap", 'LEFT' );
                $this->db->join ( 'sites AS s', "t.idsite = s.idsite", 'LEFT' );
                $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                
                if (isset ( $filters )) {
                    $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                }
            } else if (in_array ( "{$table1}", $this->cond_larr )) {
                $this->db->join ( 'sentinelchicken AS senti', "{$table1}.idsentinelchicken = senti.idsentinelchicken", 'LEFT' );
                $this->db->join ( 'sites AS s', "senti.idsite = s.idsite", 'LEFT' );
                $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                
                if (isset ( $filters )) {
                    $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                }
            } else {
                if (isset ( $filters )) {
                    $this->db->join ( 'locations AS l', "{$table1}.idlocation = l.idlocation", 'LEFT' );
                    $this->db->where ( "{$table1}.idlocation", $filters [0] ['value'] );
                }
            }
            
            if (! is_null ( $filter_date ) && is_null ( $filter_daterange )) {
                switch ($filter_date) {
                    // date('H:i:s',strtotime('-1 day');
                    case '1' :
                        $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
                        // $this->db->where($filter_time.' >=',date('H:i:s'));
                        $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                        // $this->db->where( $filter_time.' <=',"22:01:01");
                        break;
                        
                    case '2' :
                        $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
                        // $this->db->where($filter_time.' >=',date('H:i:s'));
                        $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                        // $this->db->where( $filter_time.' <=',"22:01:01");
                        break;
                    case '3' :
                        $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
                        // $this->db->where($filter_time.' >=',date('H:i:s'));
                        $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                        // $this->db->where( $filter_time.' <=',"22:01:01");
                        break;
                    case '4' :
                        $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
                        // $this->db->where($filter_time.' >=',date('H:i:s'));
                        $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                        // $this->db->where( $filter_time.' <=',date('H:i:s',strtotime('-4 month')));
                        break;
                    case '5' :
                        $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
                        // $this->db->where($filter_time.' >=',date('H:i:s'));
                        $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                        // $this->db->where( $filter_time.' <=',date('H:i:s',strtotime('-1 year')));
                        break;
                }
            }
            
            if (in_array ( $table1, $this->date_arr ))
                if (! is_null ( $filter_daterange )) {
                    $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) );
                    $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) );
                }
            
            $this->db->where ( $table1 . '.isdeleted', '0' );
            $query = $this->db->get ();
            
            // echo $this->db->last_query();
            $c1 = $query->row ()->count;
            
            $this->db->select ( "COUNT(*) AS count" );
            $this->db->from ( "{$table2}" );
            
            $this->db->select ( "{$table2}.{$id2_name}" );
            $join = 0;
            // ,{$table2}.{$id2_name}
            // print'<pre>';
            // print_r($fields);
            // print'<pre>';
            // die;
            $flag = "";
            foreach ( $fields as $field ) {
                switch ($field->type) {
                    // Reference
                    case '1-n' :
                        if ($field->ref_table_db_name == $flag)
                            break;
                            
                            $id1 = $table2 . ".{$field->db_name}";
                            $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                            $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                            $flag = $field->ref_table_db_name;
                            break;
                    default :
                        if (! empty ( $filter_date )) {
                            if (preg_match_all ( '/date/', $field->db_name, $matches )) {
                                $filter_date2 = $table2 . "." . $field->db_name;
                            }
                        }
                }
                
                // echo $this->db->last_query()."<br>";
            }
            
            // if(!empty($table1_rel) && $table1_rel == 'larvalsurveillanceservice')
            // {
            // $additinal_var = $table.'.'.$id_name.'='.$table1_rel.'.'.$id_name;
                // $this->db->where($table1_rel.'.idservicerequest' , $service_rqstid);
                // $this->db->join($table1_rel,$additinal_var,'INNER');
                // }
                if (! empty ( $service_rqstid )) {
                    switch ($table2) {
                        case 'larvaltreatments' :
                            $table2_rel = 'larvaltreatmentservice';
                            break;
                    }
                    $additinal_var = $table2 . '.' . $id2_name . '=' . $table2_rel . '.' . $id2_name;
                    $this->db->where ( $table2_rel . '.idservicerequest', $service_rqstid );
                    $this->db->join ( $table2_rel, $additinal_var, 'INNER' );
                } else if (! empty ( $_GET ['service_req_id'] )) {
                    switch ($table2) {
                        case 'larvaltreatments' :
                            $table2_rel = 'larvaltreatmentservice';
                            break;
                    }
                    $additinal_var = $table2 . '.' . $id2_name . '=' . $table2_rel . '.' . $id2_name;
                    $this->db->where ( $table2_rel . '.idservicerequest', $_GET ['service_req_id'] );
                    $this->db->join ( $table2_rel, $additinal_var, 'INNER' );
                }
                
                if (! empty ( $adultkey )) {
                    switch ($table2) {
                        case 'larvaltreatments' :
                            $table2_rel = 'larvaltreatmentlarval';
                            break;
                    }
                    $additinal_var = $table2 . '.' . $id2_name . '=' . $table2_rel . '.' . $id2_name;
                    $this->db->where ( $table2_rel . '.idlarval', $adultkey );
                    $this->db->join ( $table2_rel, $additinal_var, 'INNER' );
                } else if (! empty ( $_GET ['adult_key'] )) {
                    switch ($table2) {
                        case 'larvaltreatments' :
                            $table2_rel = 'larvaltreatmentlarval';
                            break;
                    }
                    $additinal_var = $table2 . '.' . $id2_name . '=' . $table2_rel . '.' . $id2_name;
                    $this->db->where ( $table2_rel . '.idlarval', $_GET ['adult_key'] );
                    $this->db->join ( $table2_rel, $additinal_var, 'INNER' );
                }
                
                if ($table2 == "users") {
                    $this->db->join ( 'userlocationassignment AS ula', "{$table2}.{$id_name} = ula.iduser", 'LEFT' );
                    $this->db->join ( 'locations AS l', "ula.idlocation = l.idlocation", 'LEFT' );
                    
                    if (isset ( $filters )) {
                        $this->db->where ( "ula.idlocation", $filters [0] ['value'] );
                    }
                } else if (in_array ( "{$table2}", $this->cond_sarr )) {
                    $this->db->join ( 'sites AS s', "{$table2}.idsite = s.idsite", 'LEFT' );
                    $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                    
                    if (isset ( $filters )) {
                        $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                    }
                } else if (in_array ( "{$table2}", $this->cond_all_sarr )) {
                    $this->db->join ( 'locations AS l', "sites.idlocation = l.idlocation", 'LEFT' );
                    
                    if (! empty ( $filters )) {
                        $this->db->where ( "sites.idlocation", $filters [0] ['value'] );
                    }
                } else if (in_array ( "{$table2}", $this->cond_tarr )) {
                    $this->db->join ( 'traps AS t', "{$table2}.idtrap = t.idtrap", 'LEFT' );
                    $this->db->join ( 'sites AS s', "t.idsite = s.idsite", 'LEFT' );
                    $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                    
                    if (isset ( $filters )) {
                        $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                    }
                } else if (in_array ( "{$table2}", $this->cond_larr )) {
                    $this->db->join ( 'sentinelchicken AS senti', "{$table2}.idsentinelchicken = senti.idsentinelchicken", 'LEFT' );
                    $this->db->join ( 'sites AS s', "senti.idsite = s.idsite", 'LEFT' );
                    $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                    
                    if (isset ( $filters )) {
                        $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                    }
                } else {
                    if (isset ( $filters )) {
                        $this->db->join ( 'locations AS l', "{$table2}.idlocation = l.idlocation", 'LEFT' );
                        $this->db->where ( "{$table2}.idlocation", $filters [0] ['value'] );
                    }
                }
                // die;
                // Set filters
                // $this->set_filters($filters);
                if (! is_null ( $filter_date ) && is_null ( $filter_daterange )) {
                    switch ($filter_date) {
                        // date('H:i:s',strtotime('-1 day');
                        case '1' :
                            $this->db->where ( $filter_date2 . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
                            // $this->db->where($filter_time.' >=',date('H:i:s'));
                            $this->db->where ( $filter_date2 . ' <=', date ( 'Y-m-d' ) );
                            // $this->db->where( $filter_time.' <=',"22:01:01");
                            break;
                            
                        case '2' :
                            $this->db->where ( $filter_date2 . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
                            // $this->db->where($filter_time.' >=',date('H:i:s'));
                            $this->db->where ( $filter_date2 . ' <=', date ( 'Y-m-d' ) );
                            // $this->db->where( $filter_time.' <=',"22:01:01");
                            break;
                        case '3' :
                            $this->db->where ( $filter_date2 . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
                            // $this->db->where($filter_time.' >=',date('H:i:s'));
                            $this->db->where ( $filter_date2 . ' <=', date ( 'Y-m-d' ) );
                            // $this->db->where( $filter_time.' <=',"22:01:01");
                            break;
                        case '4' :
                            $this->db->where ( $filter_date2 . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
                            // $this->db->where($filter_time.' >=',date('H:i:s'));
                            $this->db->where ( $filter_date2 . ' <=', date ( 'Y-m-d' ) );
                            // $this->db->where( $filter_time.' <=',date('H:i:s',strtotime('-4 month')));
                            break;
                        case '5' :
                            $this->db->where ( $filter_date2 . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
                            // $this->db->where($filter_time.' >=',date('H:i:s'));
                            $this->db->where ( $filter_date2 . ' <=', date ( 'Y-m-d' ) );
                            // $this->db->where( $filter_time.' <=',date('H:i:s',strtotime('-1 year')));
                            break;
                    }
                }
                
                if (in_array ( $table2, $this->date_arr ))
                    if (! is_null ( $filter_daterange )) {
                        $this->db->where ( $filter_date2 . ' >=', date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) );
                        $this->db->where ( $filter_date2 . ' <=', date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) );
                    }
                $this->db->where ( $table2 . '.isdeleted', '0' );
                $query = $this->db->get ();
                // echo "<br>".$this->db->last_query();
                $c2 = $query->row ()->count;
                
                // $c = ($c1> $c2)?$c1:$c2;
                $c = $c1 + $c2;
                
                return $c;
        }
        return 0;
    }
    
    /**
     * Count items in Separate Tables(in case of Multiple Table)
     */
    function count_items_sep($table1, $id1_name, $table2, $id2_name, $fields, $filters = array(), $table1_rel = NULL, $table2_rel = NULL, $filter_date = NULL, $page = NULL, $filter_daterange = NULL, $service_rqstid = NULL, $adultkey = NULL) {
        $filter_date1 = '';
        $filter_date2 = '';
        
        if (count ( $fields )) {
            $this->db->select ( "COUNT(*) AS count" );
            $this->db->from ( "{$table1}" );
            
            $this->db->select ( "{$table1}.{$id1_name}" );
            $join = 0;
            
            // print'<pre>';
            // print_r($fields);
            // print'<pre>';
            // die;
            $flag = "";
            foreach ( $fields as $field ) {
                switch ($field->type) {
                    // Reference
                    case '1-n' :
                        if ($field->ref_table_db_name == $flag)
                            break;
                            
                            $id1 = $table1 . ".{$field->db_name}";
                            $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                            $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                            $flag = $field->ref_table_db_name;
                            break;
                    default :
                        
                        if (! empty ( $filter_date )) {
                            if (preg_match_all ( '/date/', $field->db_name, $matches )) {
                                $filter_date1 = $table1 . "." . $field->db_name;
                            }
                        }
                }
                
                // echo $this->db->last_query()."<br>";
            }
            // die;
            // Set filters
            // $this->set_filters($filters);
            
            if (! empty ( $service_rqstid )) {
                switch ($table1) {
                    case 'adulticidetreatments' :
                        $table1_rel = 'adulticidetreatmentsservice';
                        break;
                }
                $additinal_var = $table1 . '.' . $id1_name . '=' . $table1_rel . '.' . $id1_name;
                $this->db->where ( $table1_rel . '.idservicerequest', $service_rqstid );
                $this->db->join ( $table1_rel, $additinal_var, 'INNER' );
            } else if (! empty ( $_GET ['service_req_id'] )) {
                switch ($table1) {
                    case 'adulticidetreatments' :
                        $table1_rel = 'adulticidetreatmentsservice';
                        break;
                }
                $additinal_var = $table1 . '.' . $id1_name . '=' . $table1_rel . '.' . $id1_name;
                $this->db->where ( $table1_rel . '.idservicerequest', $_GET ['service_req_id'] );
                $this->db->join ( $table1_rel, $additinal_var, 'INNER' );
            }
            
            if (! empty ( $adultkey )) {
                switch ($table1) {
                    case 'adulticidetreatments' :
                        $table1_rel = 'adulticidetreatmentslarval';
                        break;
                }
                $additinal_var = $table1 . '.' . $id1_name . '=' . $table1_rel . '.' . $id1_name;
                $this->db->where ( $table1_rel . '.idlarval', $adultkey );
                $this->db->join ( $table1_rel, $additinal_var, 'INNER' );
            } else if (! empty ( $_GET ['adult_key'] )) {
                switch ($table1) {
                    case 'adulticidetreatments' :
                        $table1_rel = 'adulticidetreatmentslarval';
                        break;
                }
                $additinal_var = $table1 . '.' . $id1_name . '=' . $table1_rel . '.' . $id1_name;
                $this->db->where ( $table1_rel . '.idlarval', $_GET ['adult_key'] );
                $this->db->join ( $table1_rel, $additinal_var, 'INNER' );
            }
            
            if ($table1 == "users") {
                $this->db->join ( 'userlocationassignment AS ula', "{$table1}.{$id_name} = ula.iduser", 'LEFT' );
                $this->db->join ( 'locations AS l', "ula.idlocation = l.idlocation", 'LEFT' );
                
                if (isset ( $filters )) {
                    $this->db->where ( "ula.idlocation", $filters [0] ['value'] );
                }
            } else if (in_array ( "{$table1}", $this->cond_sarr )) {
                $this->db->join ( 'sites AS s', "{$table1}.idsite = s.idsite", 'LEFT' );
                $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                
                if (isset ( $filters )) {
                    $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                }
            } else if (in_array ( "{$table1}", $this->cond_all_sarr )) {
                $this->db->join ( 'locations AS l', "sites.idlocation = l.idlocation", 'LEFT' );
                
                if (! empty ( $filters )) {
                    $this->db->where ( "sites.idlocation", $filters [0] ['value'] );
                }
            } else if (in_array ( "{$table1}", $this->cond_tarr )) {
                $this->db->join ( 'traps AS t', "{$table1}.idtrap = t.idtrap", 'LEFT' );
                $this->db->join ( 'sites AS s', "t.idsite = s.idsite", 'LEFT' );
                $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                
                if (isset ( $filters )) {
                    $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                }
            } else if (in_array ( "{$table1}", $this->cond_larr )) {
                $this->db->join ( 'sentinelchicken AS senti', "{$table1}.idsentinelchicken = senti.idsentinelchicken", 'LEFT' );
                $this->db->join ( 'sites AS s', "senti.idsite = s.idsite", 'LEFT' );
                $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                
                if (isset ( $filters )) {
                    $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                }
            } else {
                if (isset ( $filters )) {
                    $this->db->join ( 'locations AS l', "{$table1}.idlocation = l.idlocation", 'LEFT' );
                    $this->db->where ( "{$table1}.idlocation", $filters [0] ['value'] );
                }
            }
            
            if (! is_null ( $filter_date ) && is_null ( $filter_daterange )) {
                switch ($filter_date) {
                    // date('H:i:s',strtotime('-1 day');
                    case '1' :
                        $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
                        // $this->db->where($filter_time.' >=',date('H:i:s'));
                        $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                        // $this->db->where( $filter_time.' <=',"22:01:01");
                        break;
                        
                    case '2' :
                        $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
                        // $this->db->where($filter_time.' >=',date('H:i:s'));
                        $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                        // $this->db->where( $filter_time.' <=',"22:01:01");
                        break;
                    case '3' :
                        $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
                        // $this->db->where($filter_time.' >=',date('H:i:s'));
                        $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                        // $this->db->where( $filter_time.' <=',"22:01:01");
                        break;
                    case '4' :
                        $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
                        // $this->db->where($filter_time.' >=',date('H:i:s'));
                        $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                        // $this->db->where( $filter_time.' <=',date('H:i:s',strtotime('-4 month')));
                        break;
                    case '5' :
                        $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
                        // $this->db->where($filter_time.' >=',date('H:i:s'));
                        $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d' ) );
                        // $this->db->where( $filter_time.' <=',date('H:i:s',strtotime('-1 year')));
                        break;
                }
            }
            
            if (in_array ( $table1, $this->date_arr ))
                if (! is_null ( $filter_daterange )) {
                    $this->db->where ( "date($filter_date1)" . ' >=', date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) );
                    $this->db->where ( "date($filter_date1)" . ' <=', date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) );
                }
            
            $this->db->where ( $table1 . '.isdeleted', '0' );
            $query = $this->db->get ();
            
            $c1 = $query->row ()->count;
            
            $this->db->select ( "COUNT(*) AS count" );
            $this->db->from ( "{$table2}" );
            
            $this->db->select ( "{$table2}.{$id2_name}" );
            $join = 0;
            // ,{$table2}.{$id2_name}
            // print'<pre>';
            // print_r($fields);
            // print'<pre>';
            // die;
            $flag = "";
            foreach ( $fields as $field ) {
                switch ($field->type) {
                    // Reference
                    case '1-n' :
                        if ($field->ref_table_db_name == $flag)
                            break;
                            
                            $id1 = $table2 . ".{$field->db_name}";
                            $id2 = $field->ref_table_db_name . "." . $field->ref_table_id_name;
                            $this->db->join ( "{$field->ref_table_db_name}", $id1 . " = " . $id2, "left" );
                            $flag = $field->ref_table_db_name;
                            break;
                    default :
                        if (! empty ( $filter_date )) {
                            if (preg_match_all ( '/date/', $field->db_name, $matches )) {
                                $filter_date2 = $table2 . "." . $field->db_name;
                            }
                        }
                }
                
                // echo $this->db->last_query()."<br>";
            }
            
            // if(!empty($table1_rel) && $table1_rel == 'larvalsurveillanceservice')
            // {
            // $additinal_var = $table.'.'.$id_name.'='.$table1_rel.'.'.$id_name;
                // $this->db->where($table1_rel.'.idservicerequest' , $service_rqstid);
                // $this->db->join($table1_rel,$additinal_var,'INNER');
                // }
                if (! empty ( $service_rqstid )) {
                    switch ($table2) {
                        case 'larvaltreatments' :
                            $table2_rel = 'larvaltreatmentservice';
                            break;
                    }
                    $additinal_var = $table2 . '.' . $id2_name . '=' . $table2_rel . '.' . $id2_name;
                    $this->db->where ( $table2_rel . '.idservicerequest', $service_rqstid );
                    $this->db->join ( $table2_rel, $additinal_var, 'INNER' );
                } else if (! empty ( $_GET ['service_req_id'] )) {
                    switch ($table2) {
                        case 'larvaltreatments' :
                            $table2_rel = 'larvaltreatmentservice';
                            break;
                    }
                    $additinal_var = $table2 . '.' . $id2_name . '=' . $table2_rel . '.' . $id2_name;
                    $this->db->where ( $table2_rel . '.idservicerequest', $_GET ['service_req_id'] );
                    $this->db->join ( $table2_rel, $additinal_var, 'INNER' );
                }
                
                if (! empty ( $adultkey )) {
                    switch ($table2) {
                        case 'larvaltreatments' :
                            $table2_rel = 'larvaltreatmentlarval';
                            break;
                    }
                    $additinal_var = $table2 . '.' . $id2_name . '=' . $table2_rel . '.' . $id2_name;
                    $this->db->where ( $table2_rel . '.idlarval', $adultkey );
                    $this->db->join ( $table2_rel, $additinal_var, 'INNER' );
                } else if (! empty ( $_GET ['adult_key'] )) {
                    switch ($table2) {
                        case 'larvaltreatments' :
                            $table2_rel = 'larvaltreatmentlarval';
                            break;
                    }
                    $additinal_var = $table2 . '.' . $id2_name . '=' . $table2_rel . '.' . $id2_name;
                    $this->db->where ( $table2_rel . '.idlarval', $_GET ['adult_key'] );
                    $this->db->join ( $table2_rel, $additinal_var, 'INNER' );
                }
                
                if ($table2 == "users") {
                    $this->db->join ( 'userlocationassignment AS ula', "{$table2}.{$id_name} = ula.iduser", 'LEFT' );
                    $this->db->join ( 'locations AS l', "ula.idlocation = l.idlocation", 'LEFT' );
                    
                    if (isset ( $filters )) {
                        $this->db->where ( "ula.idlocation", $filters [0] ['value'] );
                    }
                } else if (in_array ( "{$table2}", $this->cond_sarr )) {
                    $this->db->join ( 'sites AS s', "{$table2}.idsite = s.idsite", 'LEFT' );
                    $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                    
                    if (isset ( $filters )) {
                        $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                    }
                } else if (in_array ( "{$table2}", $this->cond_all_sarr )) {
                    $this->db->join ( 'locations AS l', "sites.idlocation = l.idlocation", 'LEFT' );
                    
                    if (! empty ( $filters )) {
                        $this->db->where ( "sites.idlocation", $filters [0] ['value'] );
                    }
                } else if (in_array ( "{$table2}", $this->cond_tarr )) {
                    $this->db->join ( 'traps AS t', "{$table2}.idtrap = t.idtrap", 'LEFT' );
                    $this->db->join ( 'sites AS s', "t.idsite = s.idsite", 'LEFT' );
                    $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                    
                    if (isset ( $filters )) {
                        $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                    }
                } else if (in_array ( "{$table2}", $this->cond_larr )) {
                    $this->db->join ( 'sentinelchicken AS senti', "{$table2}.idsentinelchicken = senti.idsentinelchicken", 'LEFT' );
                    $this->db->join ( 'sites AS s', "senti.idsite = s.idsite", 'LEFT' );
                    $this->db->join ( 'locations AS l', "s.idlocation = l.idlocation", 'LEFT' );
                    
                    if (isset ( $filters )) {
                        $this->db->where ( "s.idlocation", $filters [0] ['value'] );
                    }
                } else {
                    if (isset ( $filters )) {
                        $this->db->join ( 'locations AS l', "{$table2}.idlocation = l.idlocation", 'LEFT' );
                        $this->db->where ( "{$table2}.idlocation", $filters [0] ['value'] );
                    }
                }
                // die;
                // Set filters
                // $this->set_filters($filters);
                if (! is_null ( $filter_date ) && is_null ( $filter_daterange )) {
                    switch ($filter_date) {
                        // date('H:i:s',strtotime('-1 day');
                        case '1' :
                            $this->db->where ( $filter_date2 . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
                            // $this->db->where($filter_time.' >=',date('H:i:s'));
                            $this->db->where ( $filter_date2 . ' <=', date ( 'Y-m-d' ) );
                            // $this->db->where( $filter_time.' <=',"22:01:01");
                            break;
                            
                        case '2' :
                            $this->db->where ( $filter_date2 . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
                            // $this->db->where($filter_time.' >=',date('H:i:s'));
                            $this->db->where ( $filter_date2 . ' <=', date ( 'Y-m-d' ) );
                            // $this->db->where( $filter_time.' <=',"22:01:01");
                            break;
                        case '3' :
                            $this->db->where ( $filter_date2 . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
                            // $this->db->where($filter_time.' >=',date('H:i:s'));
                            $this->db->where ( $filter_date2 . ' <=', date ( 'Y-m-d' ) );
                            // $this->db->where( $filter_time.' <=',"22:01:01");
                            break;
                        case '4' :
                            $this->db->where ( $filter_date2 . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
                            // $this->db->where($filter_time.' >=',date('H:i:s'));
                            $this->db->where ( $filter_date2 . ' <=', date ( 'Y-m-d' ) );
                            // $this->db->where( $filter_time.' <=',date('H:i:s',strtotime('-4 month')));
                            break;
                        case '5' :
                            $this->db->where ( $filter_date2 . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
                            // $this->db->where($filter_time.' >=',date('H:i:s'));
                            $this->db->where ( $filter_date2 . ' <=', date ( 'Y-m-d' ) );
                            // $this->db->where( $filter_time.' <=',date('H:i:s',strtotime('-1 year')));
                            break;
                    }
                }
                
                if (in_array ( $table2, $this->date_arr ))
                    if (! is_null ( $filter_daterange )) {
                        $this->db->where ( $filter_date2 . ' >=', date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) );
                        $this->db->where ( $filter_date2 . ' <=', date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) );
                    }
                
                $this->db->where ( $table2 . '.isdeleted', '0' );
                $query = $this->db->get ();
                
                $c2 = $query->row ()->count;
                
                $ttl_arr = array ();
                
                $ttl_arr ['c1'] = $c1;
                $ttl_arr ['c2'] = $c2;
                $c = $c1 + $c2;
                
                return $ttl_arr;
        }
        return 0;
    }
    
    /**
     * Count items in cae of Map Management added by Nitya
     * By UNION
     */
    function count_items_map($table, $id_name, $fields, $filters = array(), $filter_date = NULL, $filter_daterange = NULL, $filter_type = NULL, $filter_site = NULL, $order = NULL) {
        $tbl_arr = array ();
        $sql = NULL;
        $site_condition = NULL;
        
        if (count ( $fields )) {
            // Initialize the date filters
            $weather_date_condition = $adult_date_condition = $landing_date_condition = $larvalsurv_date_condition = $larvaltrt_date_condition = $larvaltrt_only_date_condition = $adulttrt_date_condition = $work_assgnmnts_date_condition = '';
            
            $weather_date_condition = ' AND `sites`.`idlocation` = ' . $filters [0] ['value'];
            $landing_date_condition = ' AND `sites`.`idlocation` = ' . $filters [0] ['value'];
            $larvalsurv_date_condition = ' AND `sites`.`idlocation` = ' . $filters [0] ['value'];
            $larvaltrt_date_condition = ' AND `sites`.`idlocation` = ' . $filters [0] ['value'];
            $larvaltrt_only_date_condition = ' AND `sites`.`idlocation` = ' . $filters [0] ['value'];
            $adulttrt_date_condition = ' AND `sites`.`idlocation` = ' . $filters [0] ['value'];
            $work_assgnmnts_date_condition = ' AND `sites`.`idlocation` = ' . $filters [0] ['value'];
            
            if(!empty($filter_allsite)){
                //$filter_date = "";
                //                $filter_daterange = "";
                $limit = "";
            }
            if(!empty($filter_site)){
                $site_condition = !empty($filter_site) ? ' AND `sites`.`idsite` = ' . $filter_site: '';
            }
            
            $allFilter = array(0,1,2,3,4,5,6,7,8,9,10,11,12);
            if(!empty($filter_type)){
                switch($filter_type){
                    case '1':
                        $allFilter = array(0);
                        break;
                    case '2':
                        $allFilter = array(2,6,11);
                        break;
                    case '3':
                        $allFilter = array(1,7,10);
                        break;
                    case '4':
                        $allFilter = array(12);
                        break;
                    case '5':
                        $allFilter = array(3);
                        break;
                }
            }
            
            if (! empty ( $filter_date ) && (empty ( $filter_daterange ) || (!empty($filter_daterange) && !empty ($filter_daterange[0]) && !empty($filter_daterange[1])))) {
                switch ($filter_date) {
                    case '1' :
                        $weather_date_condition = "AND (`weather`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `weather`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $adult_date_condition = "AND (`adultsurveillance`.`pudate` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `adultsurveillance`.`pudate` <= '" . date ( 'Y-m-d' ) . "' )";
                        $landing_date_condition = "AND (`landingrates`.`observeddate` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `landingrates`.`observeddate` <= '" . date ( 'Y-m-d' ) . "' )";
                        $larvalsurv_date_condition = "AND (`larvalsurveillance`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `larvalsurveillance`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $larvaltrt_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $larvaltrt_only_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $adulttrt_date_condition = "AND (`adulticidetreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `adulticidetreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $work_assgnmnts_date_condition = "AND (`servicerequests`.`opendate` >='" . date ( 'Y-m-d', strtotime ( '-1 day' ) ) . "' AND `servicerequests`.`opendate` <= '" . date ( 'Y-m-d' ) . "' )";
                        
                        break;
                        
                    case '2' :
                        $weather_date_condition = "AND (`weather`.`date` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `weather`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $adult_date_condition = "AND (`adultsurveillance`.`pudate` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `adultsurveillance`.`pudate` <= '" . date ( 'Y-m-d' ) . "' )";
                        $landing_date_condition = "AND (`landingrates`.`observeddate` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `landingrates`.`observeddate` <= '" . date ( 'Y-m-d' ) . "' )";
                        $larvalsurv_date_condition = "AND (`larvalsurveillance`.`date` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `larvalsurveillance`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $larvaltrt_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $larvaltrt_only_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $adulttrt_date_condition = "AND (`adulticidetreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `adulticidetreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $work_assgnmnts_date_condition = "AND (`servicerequests`.`opendate` >='" . date ( 'Y-m-d', strtotime ( '-7 day' ) ) . "' AND `servicerequests`.`opendate` <= '" . date ( 'Y-m-d' ) . "' )";
                        
                        break;
                    case '3' :
                        $weather_date_condition = "AND (`weather`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `weather`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $adult_date_condition = "AND (`adultsurveillance`.`pudate` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `adultsurveillance`.`pudate` <= '" . date ( 'Y-m-d' ) . "' )";
                        $landing_date_condition = "AND (`landingrates`.`observeddate` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `landingrates`.`observeddate` <= '" . date ( 'Y-m-d' ) . "' )";
                        $larvalsurv_date_condition = "AND (`larvalsurveillance`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `larvalsurveillance`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $larvaltrt_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $larvaltrt_only_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $adulttrt_date_condition = "AND (`adulticidetreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `adulticidetreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $work_assgnmnts_date_condition = "AND (`servicerequests`.`opendate` >='" . date ( 'Y-m-d', strtotime ( '-1 month' ) ) . "' AND `servicerequests`.`opendate` <= '" . date ( 'Y-m-d' ) . "' )";
                        break;
                    case '4' :
                        $weather_date_condition = "AND (`weather`.`date` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `weather`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $adult_date_condition = "AND (`adultsurveillance`.`pudate` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `adultsurveillance`.`pudate` <= '" . date ( 'Y-m-d' ) . "' )";
                        $landing_date_condition = "AND (`landingrates`.`observeddate` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `landingrates`.`observeddate` <= '" . date ( 'Y-m-d' ) . "' )";
                        $larvalsurv_date_condition = "AND (`larvalsurveillance`.`date` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `larvalsurveillance`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $larvaltrt_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $larvaltrt_only_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $adulttrt_date_condition = "AND (`adulticidetreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `adulticidetreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $work_assgnmnts_date_condition = "AND (`servicerequests`.`opendate` >='" . date ( 'Y-m-d', strtotime ( '-4 month' ) ) . "' AND `servicerequests`.`opendate` <= '" . date ( 'Y-m-d' ) . "' )";
                        
                        break;
                    case '5' :
                        $weather_date_condition = "AND (`weather`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `weather`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $adult_date_condition = "AND (`adultsurveillance`.`pudate` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `adultsurveillance`.`pudate` <= '" . date ( 'Y-m-d' ) . "' )";
                        $landing_date_condition = "AND (`landingrates`.`observeddate` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `landingrates`.`observeddate` <= '" . date ( 'Y-m-d' ) . "' )";
                        $larvalsurv_date_condition = "AND (`larvalsurveillance`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `larvalsurveillance`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $larvaltrt_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $larvaltrt_only_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $adulttrt_date_condition = "AND (`adulticidetreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `adulticidetreatments`.`date` <= '" . date ( 'Y-m-d' ) . "' )";
                        $work_assgnmnts_date_condition = "AND (`servicerequests`.`opendate` >='" . date ( 'Y-m-d', strtotime ( '-1 year' ) ) . "' AND `servicerequests`.`opendate` <= '" . date ( 'Y-m-d' ) . "' )";
                        
                        break;
                }
            }
            
            if (! empty ( $filter_daterange ) && ! empty ($filter_daterange[0]) && !empty($filter_daterange[1])) {
                $weather_date_condition = "AND (`weather`.`date` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `weather`.`date` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
                $adult_date_condition = "AND (`adultsurveillance`.`pudate` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `adultsurveillance`.`pudate` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
                $landing_date_condition = "AND (`landingrates`.`observeddate` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `landingrates`.`observeddate` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
                
                $larvalsurv_date_condition = "AND (`larvalsurveillance`.`date` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `larvalsurveillance`.`date` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
                $larvaltrt_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
                
                $larvaltrt_only_date_condition = "AND (`larvaltreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `larvaltreatments`.`date` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
                $adulttrt_date_condition = "AND (`adulticidetreatments`.`date` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `adulticidetreatments`.`date` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
                $work_assgnmnts_date_condition = "AND (`servicerequests`.`opendate` >='" . date ( 'Y-m-d', strtotime ( $filter_daterange [0] ) ) . "' AND `servicerequests`.`opendate` <= '" . date ( 'Y-m-d', strtotime ( $filter_daterange [1] ) ) . "' )";
                
            }
            // end code to add date filter
            $subQuery = array();
            $subQuery[0] = "(SELECT `adulticidetreatments`.`idadulticidetreatment` AS id,
                    `adulticidetreatments`.`idadulticidetreatment` AS `idadultsurveillance`,
                    `adulticidetreatments`.`date` AS `eventdate`,
                    `adulticidetreatments`.`latitude` AS `latitude`,
    				`adulticidetreatments`.`longitude` AS `longitude`,
                    SUM(`adulticidetreatments`.`idadulticidetreatment`) AS `total`,
                    `adulticidetreatments`.`idadulticidetreatment` AS `exceed`,
                    'adlttrtmnt' as event,
                    `sites`.`site`,
                    `sites`.`idsite`,
                    CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
                    'adlt_trtmnts' as `type`,
                    'adlttrtmnt' as module
                    FROM `adulticidetreatments`
                    LEFT JOIN `sites` ON `adulticidetreatments`.`idsite` = `sites`.`idsite`
                    WHERE `adulticidetreatments`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $adulttrt_date_condition . "
                    $site_condition
                    GROUP BY `adulticidetreatments`.`idadulticidetreatment`)";
                    
                    $subQuery[1] = "(SELECT `landingrates`.`idlandingrate` AS id,
                `landingrates`.`idlandingrate` AS `idadultsurveillance`,
                `landingrates`.`observeddate` AS `eventdate`,
                `landingrates`.`latitude` AS `latitude`,
				`landingrates`.`longitude` AS `longitude`,
                COUNT(`landingratedetails`.`idlandingrate`) AS `total`,
                `lp`.`landingrateexceeds` AS `exceed`,
                'landingratecount' as event,
                `sites`.`site`,
                `sites`.`idsite`,
                CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
                'sidebar_data_entry_lnding_rates' as `type`,
                'landingrates' as module
                FROM `landingrates`
                LEFT JOIN `landingratedetails` ON `landingratedetails`.`idlandingrate` = `landingrates`.`idlandingrate`
                LEFT JOIN `sites` ON `landingrates`.`idsite` = `sites`.`idsite`
                INNER JOIN `locationpreferences` AS lp ON `landingrates`.`idlocation` = `lp`.`idlocation`
                WHERE `landingrates`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $landing_date_condition . "
                $site_condition
                GROUP BY `landingrates`.`idlandingrate`)";
                
                $subQuery[2] = "(SELECT `larvaltreatments`.`idlarvaltreatment` AS id,
                `larvaltreatments`.`idlarvaltreatment` AS `idadultsurveillance`,
                `larvaltreatments`.`date` AS `eventdate`,
                `larvaltreatments`.`latitude` AS `latitude`,
                `larvaltreatments`.`longitude` AS `longitude`,
                SUM(`larvaltreatments`.`idlarvaltreatment`) AS `total`,
                `larvaltreatments`.`idlarvaltreatment` AS `exceed`,
                'lrvltrtmnt' as event,
                `sites`.`site`,
                `sites`.`idsite`,
                CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
                'lrvl_trtmnt_hdng' as `type`,
                'lrvltrtmnt' as module
                FROM `larvaltreatments`
                LEFT JOIN `sites` ON `larvaltreatments`.`idsite` = `sites`.`idsite`
                LEFT JOIN `larvatreatmentdetails` ON `larvatreatmentdetails`.`idlarvaltreatment` = `larvaltreatments`.`idlarvaltreatment`
                WHERE `larvaltreatments`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $larvaltrt_only_date_condition . "
                $site_condition
                GROUP BY `larvaltreatments`.`idlarvaltreatment`)";
                
                $subQuery[3] = "(SELECT `weather`.`idweather` AS id ,
                `weather`.`idweather` AS `idadultsurveillance`,
                `weather`.`date` AS `eventdate`,
                `weathersensors`.`latitude` AS `latitude`,
                `weathersensors`.`longitude` AS `longitude`,
                SUM(`weather`.`rainfall`) AS `total`,
                `lp`.`rainfallexceeds` AS `exceed`,
                'rainfall' as event,
                `sites`.`site`,
                `sites`.`idsite`,
                CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
                'sidebar_data_entry_wthr' as `type`,
                'rainfall' as module
                FROM `weather`
                LEFT JOIN `weathersensors` ON `weather`.`idweathersensor` = `weathersensors`.`idweathersensor`
                LEFT JOIN `sites` ON `weathersensors`.`idsite` = `sites`.`idsite`
                INNER JOIN `locationpreferences` AS lp ON `weather`.`idlocation` = `lp`.`idlocation`
                WHERE `weather`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $weather_date_condition . "
                $site_condition
                GROUP BY `weather`.`idweather`)";
                
                $subQuery[4] = "(SELECT `adultsurveillance`.`idadultsurveillance` AS id,
                `adultsurveillance`.`idadultsurveillance` AS `idadultsurveillance`,
                `adultsurveillance`.`pudate` AS `eventdate`,
                `sites`.`latitude` AS `latitude`,
                `sites`.`longitude` AS `longitude`,
                SUM(`adultsurveillancedetails`.`count`) AS `total`,
                `lp`.`trapcountmosquito` AS `exceed`,
                'trapcount' as event,
                `sites`.`site`,
                `sites`.`idsite`,
                CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
                'sidebar_data_entry_adlt_srvlnc' as `type`,
                'adultsurveillance' as module
                FROM `adultsurveillance`
                LEFT JOIN `traps` ON `adultsurveillance`.`idtrap` = `traps`.`idtrap`
                LEFT JOIN `sites` ON `traps`.`idsite` = `sites`.`idsite`
                LEFT JOIN `adultsurveillancedetails` ON `adultsurveillancedetails`.`idadultsurveillance` = `adultsurveillance`.`idadultsurveillance`
                LEFT JOIN `locationmosquitospecies` ON `adultsurveillancedetails`.`idmosquitospecies` = `locationmosquitospecies`.`idmosquitospecies`
                INNER JOIN `locationpreferences` AS lp ON `adultsurveillance`.`idlocation` = `lp`.`idlocation`
                WHERE `adultsurveillance`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $adult_date_condition . "
                $site_condition
                GROUP BY `adultsurveillance`.`idadultsurveillance`)";
                
                $subQuery[5] = "(SELECT `larvalsurveillance`.`idlarvalsurveillance` AS id,
                `larvalsurveillance`.`idlarvalsurveillance` AS `idadultsurveillance`,
                `larvalsurveillance`.`date` AS `eventdate`,
                `sites`.`latitude` AS `latitude`,
                `sites`.`longitude` AS `longitude`,
                SUM(`larvalsurveillancedetails`.`count`) AS `total`,
                `lp`.`trapcountmosquito` AS `exceed`,
                'trapcount' as event,
                `sites`.`site`,
                `sites`.`idsite`,
                CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
                'sidebar_data_entry_lrvl_srvlnc' as `type`,
                'larvalsurveillance' as module
                FROM `larvalsurveillance`
                LEFT JOIN `sites` ON `larvalsurveillance`.`idsite` = `sites`.`idsite`
                LEFT JOIN `larvalsurveillancedetails` ON `larvalsurveillancedetails`.`idlarvalsurveillance` = `larvalsurveillance`.`idlarvalsurveillance`
                LEFT JOIN `locationmosquitospecies` ON `larvalsurveillancedetails`.`idmosquitospecies` = `locationmosquitospecies`.`idmosquitospecies`
                INNER JOIN `locationpreferences` AS lp ON `larvalsurveillance`.`idlocation` = `lp`.`idlocation`
                WHERE `larvalsurveillance`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $larvalsurv_date_condition . "
                $site_condition
                GROUP BY `larvalsurveillance`.`idlarvalsurveillance`)";
                
                $subQuery[6] = "(SELECT `larvaltreatments`.`idlarvaltreatment` AS id,
                `larvaltreatments`.`idlarvaltreatment` AS `idadultsurveillance`,
                `larvaltreatments`.`date` AS `eventdate`,
                `larvaltreatments`.`latitude` AS `latitude`,
                `larvaltreatments`.`longitude` AS `longitude`,
                SUM(`larvatreatmentdetails`.`count`) AS `total`,
                `lp`.`trapcountmosquito` AS `exceed`,
                'trapcount' as event,
                `sites`.`site`,
                `sites`.`idsite`,
                CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
                'lrvl_trtmnt_hdng' as `type`,
                'lrvltrtmnt' as module
                FROM `larvaltreatments`
                LEFT JOIN `sites` ON `larvaltreatments`.`idsite` = `sites`.`idsite`
                LEFT JOIN `larvatreatmentdetails` ON `larvatreatmentdetails`.`idlarvaltreatment` = `larvaltreatments`.`idlarvaltreatment`
                LEFT JOIN `locationmosquitospecies` ON `larvatreatmentdetails`.`idmosquitospecies` = `locationmosquitospecies`.`idmosquitospecies`
                INNER JOIN `locationpreferences` AS lp ON `larvaltreatments`.`idlocation` = `lp`.`idlocation`
                WHERE `larvaltreatments`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $larvaltrt_date_condition . "
                $site_condition
                GROUP BY `larvaltreatments`.`idlarvaltreatment`)";
                
                $subQuery[7] = "(SELECT `landingrates`.`idlandingrate` AS id,
                `landingrates`.`idlandingrate` AS `idadultsurveillance`,
                `landingrates`.`observeddate` AS `eventdate`,
                `landingrates`.`latitude` AS `latitude`,
				`landingrates`.`longitude` AS `longitude`,
                SUM(`landingratedetails`.`count`) AS `total`,
                `lp`.`trapcountmosquito` AS `exceed`,
                'trapcount' as event,
                `sites`.`site`,
                `sites`.`idsite`,
                CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
                'sidebar_data_entry_lnding_rates' as `type`,
                'landingrates' as module
                FROM `landingrates`
                LEFT JOIN `sites` ON `landingrates`.`idsite` = `sites`.`idsite`
                LEFT JOIN `landingratedetails` ON `landingratedetails`.`idlandingrate` = `landingrates`.`idlandingrate`
                LEFT JOIN `locationmosquitospecies` ON `landingratedetails`.`idlocationvectorspecies` = `locationmosquitospecies`.`idmosquitospecies`
                INNER JOIN `locationpreferences` AS lp ON `landingrates`.`idlocation` = `lp`.`idlocation`
                WHERE `landingrates`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $landing_date_condition . "
                $site_condition
                GROUP BY `landingrates`.`idlandingrate`)";
                
                $subQuery[8] = "(SELECT `adultsurveillance`.`idadultsurveillance` AS id,
                `adultsurveillance`.`idadultsurveillance` AS `idadultsurveillance`,
                `adultsurveillance`.`pudate` AS `eventdate`,
                `sites`.`latitude` AS `latitude`,
                `sites`.`longitude` AS `longitude`,
                SUM(`adultsurveillancedetails`.`count`) AS `total`,
                `lp`.`trapcountvector` AS `exceed`,
                'trapcountvector' as event,
                `sites`.`site`,
                `sites`.`idsite`,
                CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
                'sidebar_data_entry_adlt_srvlnc' as `type`,
                'adultsurveillance' as module
                FROM `adultsurveillance`
                LEFT JOIN `traps` ON `adultsurveillance`.`idtrap` = `traps`.`idtrap`
                LEFT JOIN `sites` ON `traps`.`idsite` = `sites`.`idsite`
                LEFT JOIN `adultsurveillancedetails` ON `adultsurveillancedetails`.`idadultsurveillance` = `adultsurveillance`.`idadultsurveillance`
                LEFT JOIN `locationvectorspecies` ON `adultsurveillancedetails`.`idmosquitospecies` = `locationvectorspecies`.`idlocationmosquitospecies`
                INNER JOIN `locationpreferences` AS lp ON `adultsurveillance`.`idlocation` = `lp`.`idlocation`
                WHERE `adultsurveillance`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $adult_date_condition . "
                $site_condition
                GROUP BY `adultsurveillance`.`idadultsurveillance`)";
                
                $subQuery[9] = "(SELECT `larvalsurveillance`.`idlarvalsurveillance` AS id,
                `larvalsurveillance`.`idlarvalsurveillance` AS `idadultsurveillance`,
                `larvalsurveillance`.`date` AS `eventdate`,
                `sites`.`latitude` AS `latitude`,
                `sites`.`longitude` AS `longitude`,
                SUM(`larvalsurveillancedetails`.`count`) AS `total`,
                `lp`.`trapcountvector` AS `exceed`,
                'trapcountvector' as event,
                `sites`.`site`,
                `sites`.`idsite`,
                CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
                'sidebar_data_entry_lrvl_srvlnc' as `type`,
                'larvalsurveillance' as module
                FROM `larvalsurveillance`
                LEFT JOIN `sites` ON `larvalsurveillance`.`idsite` = `sites`.`idsite`
                LEFT JOIN `larvalsurveillancedetails` ON `larvalsurveillancedetails`.`idlarvalsurveillance` = `larvalsurveillance`.`idlarvalsurveillance`
                LEFT JOIN `locationvectorspecies` ON `larvalsurveillancedetails`.`idmosquitospecies` = `locationvectorspecies`.`idlocationmosquitospecies`
                INNER JOIN `locationpreferences` AS lp ON `larvalsurveillance`.`idlocation` = `lp`.`idlocation`
                WHERE `larvalsurveillance`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $larvalsurv_date_condition . "
                $site_condition
                GROUP BY `larvalsurveillance`.`idlarvalsurveillance`)";
                
                $subQuery[10] = "(SELECT `landingrates`.`idlandingrate` AS id,
                `landingrates`.`idlandingrate` AS `idadultsurveillance`,
                `landingrates`.`observeddate` AS `eventdate`,
                `landingrates`.`latitude` AS `latitude`,
				`landingrates`.`longitude` AS `longitude`,
                SUM(`landingratedetails`.`count`) AS `total`,
                `lp`.`trapcountvector` AS `exceed`,
                'trapcountvector' as event,
                `sites`.`site`,
                `sites`.`idsite`,
                CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
                'sidebar_data_entry_lnding_rates' as `type`,
                'landingrates' as module
                FROM `landingrates`
                LEFT JOIN `sites` ON `landingrates`.`idsite` = `sites`.`idsite`
                LEFT JOIN `landingratedetails` ON `landingratedetails`.`idlandingrate` = `landingrates`.`idlandingrate`
                LEFT JOIN `locationvectorspecies` ON `landingratedetails`.`idlocationvectorspecies` = `locationvectorspecies`.`idlocationmosquitospecies`
                INNER JOIN `locationpreferences` AS lp ON `landingrates`.`idlocation` = `lp`.`idlocation`
                WHERE `landingrates`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $landing_date_condition . "
                $site_condition
                GROUP BY `landingrates`.`idlandingrate`)";
                
                $subQuery[11] = "(SELECT `larvaltreatments`.`idlarvaltreatment` AS id,
                `larvaltreatments`.`idlarvaltreatment` AS `idadultsurveillance`,
                `larvaltreatments`.`date` AS `eventdate`,
                `larvaltreatments`.`latitude` AS `latitude`,
                `larvaltreatments`.`longitude` AS `longitude`,
                SUM(`larvatreatmentdetails`.`count`) AS `total`,
                `lp`.`trapcountvector` AS `exceed`,
                'trapcountvector' as event,
                `sites`.`site`,
                `sites`.`idsite`,
                CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
                'lrvl_trtmnt_hdng' as `type`,
                'lrvltrtmnt' as module
                FROM `larvaltreatments`
                LEFT JOIN `sites` ON `larvaltreatments`.`idsite` = `sites`.`idsite`
                LEFT JOIN `larvatreatmentdetails` ON `larvatreatmentdetails`.`idlarvaltreatment` = `larvaltreatments`.`idlarvaltreatment`
                LEFT JOIN `locationvectorspecies` ON `larvatreatmentdetails`.`idmosquitospecies` = `locationvectorspecies`.`idlocationmosquitospecies`
                INNER JOIN `locationpreferences` AS lp ON `larvaltreatments`.`idlocation` = `lp`.`idlocation`
                WHERE `larvaltreatments`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $larvaltrt_date_condition . "
                $site_condition
                GROUP BY `larvaltreatments`.`idlarvaltreatment`)";
                
                
                $subQuery[12] = "(SELECT `servicerequests`.`idservicerequest` AS id,
                `servicerequests`.`idservicerequest` AS `idadultsurveillance`,
                `servicerequests`.`opendate` AS `eventdate`,
                `servicerequests`.`latitude` AS `latitude`,
                `servicerequests`.`longitude` AS `longitude`,
                COUNT(`servicerequests`.`idservicerequest`) AS `total`,
                `lp`.`callsexceed` AS `exceed`,
                'workassgnmnts' as event,
                `sites`.`site`,
                `sites`.`idsite`,
                CONCAT(`sites`.`address1`, ' ', `sites`.`address2`, ' ', `sites`.`city`) AS `addrs`,
                'sidebar_data_entry_wrk_asgnmnts' as `type`,
                'workassgnmnts' as module
                FROM `servicerequests`
                LEFT JOIN `sites` ON `servicerequests`.`idsite` = `sites`.`idsite`
                INNER JOIN `locationpreferences` AS lp ON `servicerequests`.`idlocation` = `lp`.`idlocation`
                WHERE `servicerequests`.`idlocation` = '" . $this->session->userdata ( 'idlocation' ) . "' " . $work_assgnmnts_date_condition . "
                $site_condition
                GROUP BY `servicerequests`.`idservicerequest`)";
                
                foreach($allFilter as $kqry => $vqry){
                    $sql .= $subQuery[$vqry] . " UNION ";
                }
                $sql = trim($sql, " UNION ");
                //echo $sql;
                $query = $this->db->query ( $sql );
                $data = $query->result ();
                // print'<pre>';
                // print_r($data);
                // print'</pre>';
                
                if (! empty ( $order )) {
                    $case = "";
                    $case_val = "";
                    
                    foreach ( $order as $key => $val ) {
                        $case = $key;
                        $case_val = $val;
                        // echo $case . " " . $case_val . "<br>";
                        if (! empty ( $case ) && ! empty ( $case_val ))
                            break;
                    }
                    // echo $case . " " . $case_val . "<br>";
                    switch ($case) {
                        case '0' :
                            
                            $n = count ( $data );
                            
                            for($c = 0; $c < ($n - 1); $c ++) {
                                $position = $c;
                                
                                for($d = $c + 1; $d < $n; $d ++) {
                                    if ($case_val == "DESC") {
                                        if ($data [$position]->id < $data [$d]->id)
                                            $position = $d;
                                    } else {
                                        if ($data [$position]->id > $data [$d]->id)
                                            $position = $d;
                                    }
                                }
                                if ($position != $c) {
                                    $swap = $data [$c];
                                    $data [$c] = $data [$position];
                                    $data [$position] = $swap;
                                }
                            }
                            
                            break;
                            
                        case '1' :
                            
                            $n = count ( $data );
                            
                            for($c = 0; $c < ($n - 1); $c ++) {
                                $position = $c;
                                
                                for($d = $c + 1; $d < $n; $d ++) {
                                    if ($case_val == "DESC") {
                                        if ($data [$position]->eventdate < $data [$d]->eventdate)
                                            $position = $d;
                                    } else {
                                        if ($data [$position]->eventdate > $data [$d]->eventdate)
                                            $position = $d;
                                    }
                                }
                                if ($position != $c) {
                                    $swap = $data [$c];
                                    $data [$c] = $data [$position];
                                    $data [$position] = $swap;
                                }
                            }
                            break;
                            
                        case '2' :
                            
                            if ($case_val == "ASC") {
                                $sql = $sql;
                            } else {
                                $allFilter = array(12,8,9,10,11,4,5,6,7,3,2,1,0);
                                
                                foreach($allFilter as $kqry => $vqry){
                                    $sql .= $subQuery[$vqry] . " UNION ";
                                }
                                $sql = trim($sql, " UNION ");
                            }
                            
                            if (! is_null ( @$limit )) {
                                $sql .= " LIMIT $offset, $limit";
                            }
                            // echo $sql;
                            $query = $this->db->query ( $sql );
                            $data = $query->result ();
                            break;
                    }
                }
                
                // return $query->num_rows();
                return count ( $data );
                // return 20;
        }
        return 0;
    }
    
    /**
     * Save item
     */
    function addDateFilter($req = '') {
        $data_site ['datefilterval'] = "sunnyval";
        
        // $this->db->query("SET foreign_key_checks = 0");
        $this->db->insert ( 'sites', $data_site );
        $row_site = $this->db->affected_rows ();
        if (empty ( $row_site ))
            return false;
            $site_id = $this->db->insert_id ();
            // $this->db->query("SET foreign_key_checks = 1");
    }
    function save_item($table, $id_name, $fields, $item_id = NULL, $item_data = NULL, $filters = array()) {
        if (count ( $fields )) {
            // $table_data = array("timestamp" => date("Y-m-d H:i:s"));
            $table_data = array ();
            foreach ( $fields as $key => $field ) {
                $value = $this->input->post ( "cg_field_" . $key );
                $value = ($value === FALSE) ? $field->form_default : $value;
                // $value = $values[$key];
                switch ($field->type) {
                    // Boolean
                    case 'boolean' :
                        $table_data [$field->db_name] = $value ? 1 : 0;
                        break;
                        
                        // Date
                    case 'date' :
                        // Convert to MySQL date
                        $table_data [$field->db_name] = $value ? carbo_format_date ( $value, $field->date_format, 'Y-m-d' ) : NULL;
                        break;
                        
                    case 'datetime' :
                        // Convert to MySQL datetime
                        $table_data [$field->db_name] = $value ? carbo_format_date ( $value, $field->date_format . ' ' . $field->time_format, 'Y-m-d H:i:s' ) : NULL;
                        break;
                        
                        // Date
                    case 'time' :
                        // Convert to MySQL time
                        $table_data [$field->db_name] = $value ? carbo_format_date ( $value, $field->time_format, 'H:i:s' ) : NULL;
                        break;
                        
                        // File
                    case 'file' :
                        
                        $path = rtrim ( $field->upload_path, '/' ) . '/';
                        $path_temp = rtrim ( $field->upload_path_temp, '/' ) . '/';
                        
                        // Delete old file
                        if (! is_null ( $item_data ) and ($item_data->{$field->db_name} !== $value) and file_exists ( $path . $item_data->{$field->db_name} )) {
                            @unlink ( $path . $item_data->{$field->db_name} );
                        }
                        // Copy new file to permanent location
                        if (file_exists ( $path_temp . $value )) {
                            @rename ( $path_temp . $value, $path . $value );
                        }
                        
                    default :
                        if ($value !== FALSE) {
                            $table_data [$field->db_name] = ($value === "") ? NULL : $value;
                        }
                }
            }
            
            if (is_null ( $item_id )) {
                // Insert the item
                $this->db->insert ( $table, $table_data );
                $insert_id = $this->db->insert_id ();
            } else {
                // Update the item
                $this->db->where ( $id_name, $item_id );
                $this->set_filters ( $filters );
                $this->db->update ( $table, $table_data );
            }
            
            return TRUE;
        }
        
        return FALSE;
    }
    
    /**
     * Delete items
     */
    function delete_items($table, $id_name, $item_ids = array(), $filters = array()) {
        // @todo - Cascade
        // Delete the rows
        $this->db->where_in ( $id_name, $item_ids );
        $this->set_filters ( $filters );
        $this->db->delete ( $table );
    }
    
    /**
     * Set filters
     */
    function set_filters($filters = array()) {
        foreach ( $filters as $filter ) {
            if (! isset ( $filter ['operator'] )) {
                $filter ['operator'] = 'eq';
            }
            switch ($filter ['operator']) {
                case 'noteq' :
                    $this->db->where ( $filter ['field'] . ' !=', $filter ['value'] );
                    break;
                case 'lt' :
                    $this->db->where ( $filter ['field'] . ' <', $filter ['value'] );
                    break;
                case 'lte' :
                    $this->db->where ( $filter ['field'] . ' <=', $filter ['value'] );
                    break;
                case 'gt' :
                    $this->db->where ( $filter ['field'] . ' >', $filter ['value'] );
                    break;
                case 'gte' :
                    $this->db->where ( $filter ['field'] . ' >=', $filter ['value'] );
                    break;
                case 'in' :
                    $this->db->where_in ( $filter ['field'], $filter ['value'] );
                    break;
                case 'notin' :
                    $this->db->where_not_in ( $filter ['field'], $filter ['value'] );
                    break;
                case 'like' :
                    $this->db->like ( $filter ['field'], $filter ['value'] );
                    break;
                case 'notlike' :
                    $this->db->not_like ( $filter ['field'], $filter ['value'] );
                    break;
                case 'starts' :
                    $this->db->where ( $filter ['field'] . ' LIKE \'' . $this->db->escape_like_str ( $filter ['value'] ) . '%\'' );
                    break;
                case 'ends' :
                    $this->db->where ( $filter ['field'] . ' LIKE \'%' . $this->db->escape_like_str ( $filter ['value'] ) . '\'' );
                    break;
                    
                default :
                    $this->db->where ( $filter ['field'], $filter ['value'] );
            }
        }
    }
    }
    
    /* End of file carbo_model.php */
    /* Location: ./application/models/carbo_model.php */