<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );

class Custom_report_model extends CI_Model {
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	public function getTreatedBasins($startdate = '', $enddate = '', $excludedSites, $loadFlag) {
		$location = '57';
		$startdate_arr = explode("/", $startdate);
		$startdate = $startdate_arr[2] . "-" . $startdate_arr[0] . "-" . $startdate_arr[1];
		
		$enddate_arr = explode("/", $enddate);
		$enddate = $enddate_arr[2] . "-" . $enddate_arr[0] . "-" . $enddate_arr[1];
		
		$startDateTime = new DateTime($startdate);
		$endDateTime = new DateTime($enddate);
		
		$endYear = $endDateTime->format('Y');
		$currentYearStart = $endYear.'-01-01';
		$currentYearEnd = $endYear.'-12-31';
		
		$result = array();
		
		$result['season_data'] = $this->getSeasonData($startdate, $enddate, $location);
			
		if(is_array($result['season_data'])) {
			$result['season_data']['hasSeasonWeeks'] = 1;
			$startdate = $result['season_data']['startdate'];
		}
		else {
			$timeDiff = $startDateTime->diff($endDateTime);
			$totalDays = intval($timeDiff->format('%a'));
			$result['season_data'] = array('totalSeasonWeeks'=>ceil(($totalDays)/7), "hasSeasonWeeks"=>0);
		}
		
		$weeks = $this->getWeeks($startDateTime, $endDateTime);
		$sitesAndTreatments = $this->getSitesAndTreatments($startdate, $enddate, $location, $excludedSites, $loadFlag);
		
		if(count($sitesAndTreatments['sites']) > 0) {
			for($i=0; $i<sizeof($sitesAndTreatments['sites']); $i++) {
				if($sitesAndTreatments['sites'][$i]['selected'] == 1)
					$sitesAndTreatments['sites'][$i]['closing_data'] = $this->getClosingData($sitesAndTreatments['sites'][$i], $currentYearStart, $currentYearEnd);
			}
		}
		
		$productData = $this->getProductData($startdate, $enddate, $location, $loadFlag);
		
		$result['site_totals'] = $sitesAndTreatments['sites'];
		$result['site_treatments'] = $sitesAndTreatments['treatments'];
		$result['product_data'] = $productData;
		$result['weeks'] = $weeks;
		$result['from'] = $startdate;
		$result['to'] = $enddate;
		$result['total_sites'] = $this->getTotalSites($location);
		
		return $result;
	}
	
	public function getNarrativeReport($date, $excludedsupervisorids) {
		
		$date_arr = explode("/", $date);
		$date = $date_arr[2] . "-" . $date_arr[0] . "-" . $date_arr[1];
		
		$selectedDate = new DateTime($date);
		
		$dow = $selectedDate->format('w');
		if($dow !== '1') {
			if($dow == '0') {
				$selectedDate->sub(new DateInterval('P6D'));
			}
			else {
				$daysToReverse = intval($dow) - 1;
				$selectedDate->sub(new DateInterval('P'.$daysToReverse.'D'));
			}
		}
		
		$startDate = clone $selectedDate;
		$selectedDate->add(new DateInterval('P4D'));
		$weekEnding = clone $selectedDate;
		$selectedDate->add(new DateInterval('P2D'));
		$endDate = clone $selectedDate;
		
		$this->db->select('l.idlarvaltreatment, l.comments, l.date, l.idapplicator, u.firstname, u.lastname, u.userfiltering');
		$this->db->from('larvaltreatments l');
		$this->db->join('users u', 'l.idapplicator = u.iduser');
		$this->db->where('l.comments !=', '');
		$this->db->where('l.idlocation', '57');
		$this->db->where("l.date BETWEEN '".$startDate->format('Y-m-d')."' AND '".$endDate->format('Y-m-d')."'");
		$query = $this->db->get();
		
		$locationSupervisors = $this->getAllSupervisorsInLocation($excludedsupervisorids, 57);
		$result = array('treatments'=>array(), 'week_ending'=>$weekEnding, 'LocationSupervisors'=>$locationSupervisors);		
		if($query->num_rows() > 0) $result['treatments'] = $query->result_array();				
		
		foreach($result['treatments'] as &$treatment) {
			if($treatment['userfiltering'] != '1') {
				$supervisor = $this->getGroupSupervisor($treatment['idapplicator']);
				$treatment['firstname'] = $supervisor['firstname'];
				$treatment['lastname'] = $supervisor['lastname'];
				$treatment['supervisorid'] = $supervisor['supervisorid'];
			}
			else{
				$treatment['supervisorid'] = $treatment['idapplicator'];
			}
		}
		
		$treatments = $result['treatments'];
		
		foreach($treatments as $key => $trt)
		{
			foreach($excludedsupervisorids as $exsupervisorid)
			{				
				if($trt['supervisorid'] == $exsupervisorid || $trt['idapplicator'] == $exsupervisorid)
				{					
					unset($treatments[$key]);
				}
			}
		}
		$result['treatments'] = $treatments;		
		return $result;
	}
	
	/**
	 * Function to fetch Adult Treatment
	 */
	private function getSeasonData($startdate = '', $enddate = '', $location) {
		if($startdate == '' || $enddate == '') return false;
		
		//Creating datetime objects to compare start and end years, reliably.
		$startDateTime = new DateTime($startdate);
		$endDateTime = new DateTime($enddate);
		
		$startYear = $startDateTime->format('Y');
		$endYear = $endDateTime->format('Y');
		
		if($startYear != $endYear) return false;
		
		$this->db->select('sd.year, sd.month, sd.day');
		$this->db->from('seasondates AS sd');
		$this->db->where('sd.idlocation', $location);
		$this->db->where('sd.isdeleted', '0');
		$query = $this->db->get();
		
		$seasonStartDate = false;
		
		if($query->num_rows() < 1) return false;
		
		foreach($query->result() as $row) {
			$seasonYear = $row->year;
			if($endYear == $seasonYear) {
				$seasonStartString = $row->year . '-' . $row->month . '-' . $row->day;
				$seasonStartDate = new DateTime($seasonStartString);
			}
		}
		
		if($seasonStartDate == false) return false;
		
		$result = array();
				
		//has time starting from season start to the given end date.
		$timeDiff = $seasonStartDate->diff($endDateTime);
		$totalDiffDays = intval($timeDiff->format('%a'));
		$result['totalSeasonWeeks'] = ceil($totalDiffDays/7);
		
		
		$result['startdate'] = $seasonStartDate->format('Y-m-d');
		return $result;
	}		
	
	private function getSitesAndTreatments($startdate, $enddate, $location, $siteIds, $loadFlag) {
		$siteData = $this->getAllSites($siteIds, $location, true, $loadFlag);
		$sites = $siteData['sites'];
		$treatments = $this->getAllTreatments($startdate, $enddate, $siteData['includedSites']);		

		foreach($treatments as $tre) {
			$index = $this->findSite($sites, $tre['idsite']);
			$treatment = array(
				'idlarvaltreatment'=>$tre['idlarvaltreatment'],
				'date'=>$tre['date'],
				'idsite'=>$tre['idsite'],
				'totalproductapplied'=>$tre['totalproductapplied']
			);
			
			if($index > -1) {
				array_push($sites[$index]['treatments'], $treatment);
			}
		}
		
		$result = array('sites'=>$sites, 'treatments'=>$treatments);
		return $result;
	}
	
	private function getAllTreatments($startdate, $enddate, $siteIds) {
		if(sizeof($siteIds) < 1) return array();
		
		$this->db->select('idlarvaltreatment, idsite, totalproductapplied, date');
		$this->db->from('larvaltreatments');
		$this->db->where_in('idsite', $siteIds);
		$this->db->where("date BETWEEN '$startdate' AND '$enddate'");
		$this->db->where('isdeleted', '0');
		$this->db->order_by('date');
		$query = $this->db->get();
		
		$result = array();
		if($query->num_rows() > 0) $result = $query->result_array();
		
		return $result;
	}
	
	private function getUntreatedSites($treatedSiteIds, $location) {
		$this->db->select('s.idsite, s.site, s.sitecord');
		$this->db->from('sites s');
		$this->db->where('idlocation', $location);
		$this->db->where('isdeleted', '0');
		$this->db->where_not_in('idsite', $treatedSiteIds);
		$query = $this->db->get();
		
		$result = array();
		if($query->num_rows() > 0) {
			$result = $query->result_array();			
		}
		
		return $result;
	}
	
	public function getClosingData($site, $dateStart, $dateEnd) {
		$result = array('is_closed'=>0, 'closed_at'=>'');
		$start = new DateTime($dateStart);
		$end = new DateTime($dateEnd);
		
		// echo "$dateStart - $dateEnd"."<br/>";
		if($site['active'] == '0') {
			$this->db->select('dateclosed');
			$this->db->from('wardsclosed');
			$this->db->where('idsite', $site['idsite']);
			$this->db->order_by('dateclosed');
			$query = $this->db->get();
		  
			if($query->num_rows() > 0) {
				$data = $query->result_array();
				foreach($data as $row) {
					$cDate = new DateTime($row['dateclosed']);
					if($cDate >= $start && $cDate <= $end) {
						$result['is_closed'] = 1;
						$result['closed_at'] = $row['dateclosed'];
					}
				}				
			}
		}
		
		return $result;
	}
	
	private function getTotalSites($location) {
		$this->db->select("COUNT(*) as total");
		$this->db->from("sites");
		$this->db->where('idlocation', $location);
		
		$query = $this->db->get();		
		
		$total = 0;
		if($query->num_rows() > 0) {
			$row = $query->first_row();
			$total = intval($row->total);
		}
		
		return $total;		
	}
	
	private function getWeeks($startDate, $endDate) {
		$diff = $startDate->diff($endDate);
		$totalDaysDiff = intval($diff->format('%a'));
		$totalWeeks = ceil($totalDaysDiff/7);
		
		$weeks = array();
		$cursorDate = $startDate;
		
		for($i=1; $i <= $totalWeeks; $i++) {
			
			$dow = intval($cursorDate->format('w'));
			$toEndDays = 4;
			
			if($i == 1) {
				$fromWeekStart = $cursorDate;
				if($dow == 0) {
					$interval = new DateInterval("P1D");
					$cursorDate->add($interval);
				}
				else if($dow == 6) {
					$interval = new DateInterval("P2D");
					$cursorDate->add($interval);
				}
				else if($dow == 5) {
					$toEndDays = 0;
				}
				else {
					$dayDiff = 5 - $dow;
					if($dayDiff > 0) {
						$toEndDays = $dayDiff;
					}
				}
			}
			
      $week = array("start"=>$cursorDate->format('Y-m-d'));
			
			$cursorDate->add(new DateInterval("P".$toEndDays."D"));
			
			$week["end"] = $cursorDate->format('Y-m-d');		
      
      array_push($weeks, $week);
      
      $cursorDate->add(new DateInterval('P3D'));
		}
		
		return $weeks;
	}
	
	private function getProductData($startdate, $enddate, $location, $loadFlag) {
		if($loadFlag === true) return array();
		
		$this->db->select('SUM(totalproductapplied) as treatments, p.productname, p.eparegistration');
		$this->db->from('larvaltreatments l');
		$this->db->join('products p', 'p.idproduct = l.idproduct');
		$this->db->where('l.idlocation', $location);
		$this->db->where("l.date BETWEEN '$startdate' AND '$enddate'");
		$this->db->where('l.isdeleted', '0');
		$this->db->group_by('l.idproduct');
		$query = $this->db->get();
		
		$result = array();
		if($query->num_rows() > 0) {
			$result = $query->result_array();			
		}
		
		return $result;
	}	
	
	public function findSite($sites, $idsite) {
		for($i=0; $i<count($sites); $i++) {
			if($sites[$i]['idsite'] == $idsite) return $i;
		}
		return -1;
	}
	
	public function getAllSites($siteIds, $location, $showCords = true, $loadFlag) {
	
		//UPDATE CALLER PARAMS
				
		$fields = 'idsite, site, active';
		if($showCords === true) $fields = $fields.', sitecord';
		
		$this->db->select($fields);
		$this->db->from('sites');
		$this->db->where('idlocation', $location);
		$this->db->where('isdeleted', '0');
		$this->db->order_by('site');
		$query = $this->db->get();
		
		$result = array();
		if($query->num_rows() > 0) $result['sites'] = $query->result_array();
		
		$includedSites = array();
		
		for($i=0; $i<sizeof($result['sites']); $i++) {
			$result['sites'][$i]['treatments'] = array();
			
			if($loadFlag === true) {
				$result['sites'][$i]['selected'] = 0;
			}
			else if(array_search($result['sites'][$i]['idsite'], $siteIds) === false) {
				array_push($includedSites, $result['sites'][$i]['idsite']);
				$result['sites'][$i]['selected'] = 1;
			}
			else {
				$result['sites'][$i]['selected'] = 0;
			}
		}
		$result['includedSites'] = $includedSites;
		
		return $result;
	}
	
	private function getGroupSupervisor($iduser) {
		$result = array('firstname'=>'-', 'lastname'=>'-', 'supervisorid'=>'');
		
		$this->db->select('idusergroup');
		$this->db->from('usergroupassignment');
		$this->db->where('iduser', $iduser);
		$query = $this->db->get();				
		
		if($query->num_rows() < 1) return $result;						
		
		$row = $query->first_row();
		$idusergroup = $row->idusergroup;
		
		$this->db->select('u.firstname, u.lastname, u.userfiltering, u.iduser');
		$this->db->from('usergroupassignment ug');
		$this->db->join('users u', 'u.iduser = ug.iduser');
		$this->db->where('ug.idusergroup', $idusergroup);
		$this->db->where('ug.iduser !=', $iduser);
		$query = $this->db->get();
		
		if($query->num_rows() < 1) return $result;
		
		$members = $query->result_array();
		
		foreach($members as $member) {
			if($member['userfiltering'] == '1') {
				$result['firstname'] = $member['firstname'];
				$result['lastname'] = $member['lastname'];
				$result['supervisorid'] = $member['iduser'];
				return $result;
			}
		}
		
		return $result;
	}
	
	private function getAllSupervisorsInLocation($excludedSupervisors, $idLocation) {
		$result = array();
		$this->db->select('Concat(u.firstname," ",u.lastname) as name, u.iduser');
		$this->db->from('users u');
		$this->db->where('u.idlocation', $idLocation);
		$this->db->where('u.userfiltering', 1);
		
		$query = $this->db->get();
		
		if($query->num_rows() < 1)
		{
			return $result;
		}
		foreach($query->result_array() as $data)
		{	$obj = array();
			$obj['username'] = $data['name']; 
			$obj['iduser'] = $data['iduser'];
			$obj['selected'] = 1;
			foreach($excludedSupervisors as $supervisorid)
			{
				if($supervisorid == $data['iduser'])
				{
					$obj['selected'] = 0;
				}
			}
			$result[] = $obj;
		}
		
		return $result;
	}
}