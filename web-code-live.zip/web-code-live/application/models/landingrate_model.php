<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Landingrate_model extends CI_Model {
	public $str = "";
	public $map = "";
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to Add a new Zone
	 */
	public function addlandingrate($idloc = '') {
		$site_id = '';
		$idloc = $this->session->userdata ( 'idlocation' );
		$site_id = $this->input->post ( 'site_id' );
		$data ['site'] = $this->input->post ( 'site' );
		$data ['idsitetype'] = $this->input->post ( 'idsitetype' );
		$data ['maplabel'] = $this->input->post ( 'maplabel' );
		$data ['address1'] = $this->input->post ( 'address1' );
		$data ['address2'] = $this->input->post ( 'address2' );
		$data ['city'] = $this->input->post ( 'city' );
		$data ['idstate'] = $this->input->post ( 'idstate' );
		$data ['latitude'] = $this->input->post ( 'latitude' );
		$data ['longitude'] = $this->input->post ( 'longitude' );
		$data ['pdop'] = $this->input->post ( 'pdop' );
		$data ['postalcode'] = $this->input->post ( 'postalcode' );
		if ($site_id == '0') {
			$this->db->query ( "SET foreign_key_checks = 0" );
			$this->db->insert ( 'sites', $data );
			$row_site = $this->db->affected_rows ();
			if (empty ( $row_site ))
				return false;
			$site_id = $this->db->insert_id ();
			$this->db->query ( "SET foreign_key_checks = 1" );
		/**
		 * end insert data into sites table*
		 */
		}
		
		$observed_date = $this->input->post ( 'observed_date' );
		$observed_time = $this->input->post ( 'observed_time' );
		
		$this->load->model('usermodel');
		$data_1 ['userId'] = $this->usermodel->getUserId();

		$data_1 ['idsite'] = $site_id;
		$data_1 ['observeddate'] = date ( 'Y-m-d', strtotime ( $observed_date ) );
		$data_1 ['observedtime'] = date ( 'h:i:s A', strtotime ( $observed_time ) );
		$data_1 ['idtemprange'] = $this->input->post ( 'temp_range' );
		$data_1 ['idhumidityrange'] = $this->input->post ( 'humidity_name' );
		$data_1 ['idwindspeed'] = $this->input->post ( 'wind_speed' );
		$data_1 ['idcloudcoverage'] = $this->input->post ( 'cloud_cover' );
		$data_1 ['idzone'] = $this->input->post ( 'idzone' );
		$data_1 ['maplabel'] = $this->input->post ( 'maplabel' );
		$data_1 ['latitude'] = $this->input->post ( 'latitude' );
		$data_1 ['longitude'] = $this->input->post ( 'longitude' );
		$data_1 ['idduration'] = $this->input->post ( 'duration' );
		$data_1 ['idinspector'] = $this->input->post ( 'inspector_name' );
		$data_1 ['comments'] = $this->input->post ( 'comment' );
		$data_1 ['countobserved'] = $this->input->post ( 'count_observed' );
		$data_1 ['sitename'] = $this->input->post ( 'site' );
		$data_1 ['idsitetype'] = $this->input->post ( 'idsitetype' );
		$data_1 ['countscollected'] = $this->input->post ( 'totalcount' );
		$data_1 ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
		// echo '<pre>';print_r($data_1);die;
		$this->db->query ( "SET foreign_key_checks = 0" );
		$this->db->insert ( 'landingrates', $data_1 );
		$rows = $this->db->affected_rows ();
		// $rows = 1;
		if (empty ( $rows ))
			return false;
		
		$id = $this->db->insert_id ();
		$this->db->query ( "SET foreign_key_checks = 1" );
		
		// $id =1 ;
		/*
		 * $species = $this->getSpecies($idloc);
		 *
		 * if(!empty($species))
		 * {
		 * foreach($species as $key => $val)
		 * {
		 * $data_1 = array();
		 * $flag = $this->input->post(strtolower($val));
		 * if(isset($flag))
		 * {
		 * $data_1['idlandingrate'] = $id;
		 * $data_1['idlocationvectorspecies'] = $key;
		 * $data_1['count'] = !empty($flag)?$flag:"0";
		 * //print'<pre>';
		 * // print_r($data_1);
		 * $this->db->query("SET foreign_key_checks = 0");
		 * $this->db->insert('landingratedetails',$data_1);
		 * $this->db->query("SET foreign_key_checks = 1");
		 * }
		 * }
		 *
		 * }
		 */
		// code by sonu form species and species data count insert
		
		$species = $this->input->post ( 'species_val' );
		// echo '<pre>'; print_r($species); echo '</pre>';
		$s_count = $this->input->post ( 'species_countval' );
		// echo '<pre>'; print_r($s_count); echo '</pre>'; die;
		
		if (count ( $species ) > 0) {
			$this->db->query ( 'SET foreign_key_checks = 0' );
			for($i = 0; $i < count ( $species ); $i ++) {
				$data_species = array ();
				$data_species ['idlandingrate'] = $id;
				$data_species ['idlocationvectorspecies'] = ! empty ( $species [$i] ) ? $species [$i] : 0;
				$data_species ['count'] = ! empty ( $s_count [$i] ) ? $s_count [$i] : 0;
				$this->db->insert ( 'landingratedetails', $data_species );
			}
			$this->db->query ( 'SET foreign_key_checks = 1' );
		}
		
		// end here sonu code
		
		//
		// die;
		
		return true;
	}
	
	/**
	 * Function to Update a new Adultsurveillance
	 */
	public function updateLandingrate($Id = '', $idloc = '') {
		if (empty ( $Id ))
			return false;
		
		$site_id = '';
		$site_id = $this->input->post ( 'site_id' );
		$data ['site'] = $this->input->post ( 'site' );
		$data ['idsitetype'] = $this->input->post ( 'idsitetype' );
		$data ['maplabel'] = $this->input->post ( 'maplabel' );
		$data ['address1'] = $this->input->post ( 'address1' );
		$data ['address2'] = $this->input->post ( 'address2' );
		$data ['city'] = $this->input->post ( 'city' );
		$data ['idstate'] = $this->input->post ( 'idstate' );
		$data ['latitude'] = $this->input->post ( 'latitude' );
		$data ['longitude'] = $this->input->post ( 'longitude' );
		$data ['pdop'] = $this->input->post ( 'pdop' );
		$data ['postalcode'] = $this->input->post ( 'postalcode' );
		if ($site_id == '0') {
			$this->db->query ( "SET foreign_key_checks = 0" );
			$this->db->insert ( 'sites', $data_site );
			$row_site = $this->db->affected_rows ();
			if (empty ( $row_site ))
				return false;
			$site_id = $this->db->insert_id ();
			$this->db->query ( "SET foreign_key_checks = 1" );
		}
		$observed_date = $this->input->post ( 'observed_date' );
		$observed_time = $this->input->post ( 'observed_time' );
		
		/**
		 * end insert data into sites table*
		 */
		$data_1 ['idsite'] = $site_id;
		$data_1 ['observeddate'] = date ( 'Y-m-d', strtotime ( $observed_date ) );
		$data_1 ['observedtime'] = date ( 'h:i:s A', strtotime ( $observed_time ) );
		$data_1 ['idtemprange'] = $this->input->post ( 'temp_range' );
		$data_1 ['idhumidityrange'] = $this->input->post ( 'humidity_name' );
		$data_1 ['idwindspeed'] = $this->input->post ( 'wind_speed' );
		$data_1 ['idcloudcoverage'] = $this->input->post ( 'cloud_cover' );
		$data_1 ['idzone'] = $this->input->post ( 'idzone' );
		$data_1 ['maplabel'] = $this->input->post ( 'maplabel' );
		$data_1 ['latitude'] = $this->input->post ( 'latitude' );
		$data_1 ['longitude'] = $this->input->post ( 'longitude' );
		
		$data_1 ['idduration'] = $this->input->post ( 'duration' );
		$data_1 ['idinspector'] = $this->input->post ( 'inspector_name' );
		$data_1 ['comments'] = $this->input->post ( 'comment' );
		$data_1 ['countobserved'] = $this->input->post ( 'count_observed' );
		$data_1 ['sitename'] = $this->input->post ( 'site' );
		$data_1 ['idsitetype'] = $this->input->post ( 'idsitetype' );
		$data_1 ['countscollected'] = $this->input->post ( 'totalcount' );
		// $data_1['idlocation'] = !empty($idloc)?$idloc:'0';
		$this->db->where ( 'idlandingrate', $Id );
		$this->db->update ( 'landingrates', $data_1 );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ) && empty ( $Id ))
			return false;
		
		$species = $this->input->post ( 'species_val' );
		$s_count = $this->input->post ( 'species_countval' );
		
        $this->db->query ( 'SET foreign_key_checks = 0' );
		$this->db->where ( 'idlandingrate', $Id );
		$this->db->delete ( 'landingratedetails' );
		
		for($i = 0; $i < count ( $species ); $i ++) {
			$data_species = array ();
			$data_species ['idlandingrate'] = $Id;
			$data_species ['idlocationvectorspecies'] = ! empty ( $species [$i] ) ? $species [$i] : 0;
			$data_species ['count'] = ! empty ( $s_count [$i] ) ? $s_count [$i] : 0;
			$this->db->insert ( 'landingratedetails', $data_species );
		}
		$this->db->query ( 'SET foreign_key_checks = 1' );
		
		return true;
	}
	
	/**
	 * Function to list all Adultsurveillances
	 */
	public function deleteLandingrate() {
		$idlandingrate = $this->input->get_post ( 'id' );
		
		if (empty ( $idlandingrate ))
			return false;
			
			/*
		 * $this->db->where('idlandingrate',$idlandingrate);
		 * $this->db->delete('landingratedetails');
		 *
		 * $rows = $this->db->affected_rows();
		 *
		 * if(empty($rows))
		 * return false;
		 *
		 */
		$data ['isdeleted'] = '1';
		$this->db->where ( 'idlandingrate', $idlandingrate );
		$this->db->update ( 'landingrates', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ) && empty ( $id ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to Get Lati Longi
	 * for displaying on Maps
	 */
	public function getMapdata() {
		$page_size = $this->input->get ( 'page_size' );
		$page = $this->input->get ( 'page' );
		$filter_date = $this->input->get ( 'filter_date' );
		$setfromdate = $this->input->get ( 'setfromdate' );
		$settodate = $this->input->get ( 'settodate' );
		
        $offset = 0;
        $page_size = ($page_size == 'all') ? 'all' : (is_numeric($page_size) ? $page_size : 10);
        $limit = (is_numeric($page_size)) ? $page_size : NULL;        
        $offset = $limit * ($page - 1);
        
        if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 2;
        
		$this->db->select ( 'ld.idlandingrate,
				ld.latitude,
				ld.longitude,
				ld.observeddate,
				ld.observedtime,
				ld.countobserved as count , 
				s.site AS sitename,
				l.GoogleZoom' );
		$this->db->from ( 'landingrates AS ld' );
		$this->db->join ( 'sites AS s', 'ld.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'zones AS z', 's.idzone = z.idzone', 'LEFT' );
		// $this->db->join('landingratedetails AS ldd','ld.idlandingrate = ldd.idlandingrate','LEFT');
		$this->db->join ( 'locations AS l', 'ld.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( 'ld.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'ld.isdeleted', '0' );
		if (! is_null ( $filter_date ) && empty ( $setfromdate ) && empty ( $settodate )) {
			switch ($filter_date) {
				case '1' :
					$this->db->where ( 'ld.observeddate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'ld.observeddate' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'ld.observeddate' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'ld.observeddate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'ld.observeddate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'ld.observeddate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'ld.observeddate' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'ld.observeddate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'ld.observeddate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'ld.observeddate' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		} else if (! empty ( $setfromdate ) && ! empty ( $settodate )) {
			$this->db->where ( 'ld.observeddate' . ' >=', $setfromdate );
			$this->db->where ( 'ld.observeddate' . ' <=', $settodate );
		}
		
		$this->db->group_by ( "`ld`.`idlandingrate`" );
		$this->db->order_by ( 'ld.observeddate', 'desc' );
		$this->db->limit ( $limit, $offset );
		
		$data_1 = array ();
		$query = $this->db->get ();
		// echo $this->db->last_query();
		// die;
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
	}
	/**
	 * Function to list all Adultsurveillances mail
	 */
	public function getLandingRate($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( '`landingrates`.*' );
		$this->db->from ( 'landingrates' );
		$this->db->where ( 'isdeleted', '0' );
		
		$this->db->where ( '`landingrates`.`idlandingrate`', $Id );
		
		$query = $this->db->get ();
		
		$data = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row )
				$data [] = $row;
			
			return $data [0];
		}
		
		return false;
	}
	/**
	 * Function to list all Landing Rates
	 */
	public function listLandingRates($Ids = "", $mapSite = "", $mapFlag = "") {
		$this->db->select ( 'landingrates.idlandingrate,
				s.site AS sitename,
				s.idzone, 
				zones.`zone`, 
				landingrates.observeddate, 
				landingrates.observedtime, 
				landingrates.countobserved ,
				landingrates.countscollected AS `count`' );
		$this->db->from ( 'landingrates' );
		$this->db->join ( 'sites AS s', 'landingrates.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'zones', 's.idzone = zones.idzone', 'LEFT' );
		$this->db->join ( 'locations AS l', 'landingrates.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( 'landingrates.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'landingrates.isdeleted', '0' );
        
		// $this->db->group_by("`landingrates`.`idlandingrate`");
		$filter_date = $this->input->get ( 'filter_date' );
		$ttl = $this->input->get ( 'ttl' );
		$page = $this->input->get ( 'page' );
		$frmdate = $this->input->get ( 'frmdate' );
		$todate = $this->input->get ( 'todate' );
		$orderby = $this->input->get ( 'orderby' );
		
        if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 2;
		
		if (! isset ( $ttl ) || $ttl == '')
			$ttl = 10;
		
		if (! isset ( $page ) || $page == '')
			$page = 1;
		
        if(!empty($mapSite)){
            $this->db->where ( 's.idsite', $mapSite );
		}
        if(!empty($mapSite) || !empty($mapFlag)){
            $filter_date = "";
            $filter_daterange = "";
            $frmdate = "";
            $todate = "";
            $orderby = "";
            $ttl = "";
            $page = "";
		}
        
		if (! empty ( $frmdate ) && ! empty ( $todate )) {
			$frmdate = substr ( $frmdate, 0, 2 ) . '/' . substr ( $frmdate, 2, 2 ) . '/' . substr ( $frmdate, 4, 4 );
			$todate = substr ( $todate, 0, 2 ) . '/' . substr ( $todate, 2, 2 ) . '/' . substr ( $todate, 4, 4 );
			$this->db->where ( 'landingrates.observeddate' . ' >=', date ( 'Y-m-d', strtotime ( $frmdate ) ) );
			$this->db->where ( 'landingrates.observeddate' . ' <=', date ( 'Y-m-d', strtotime ( $todate ) ) );
		} else if (! is_null ( $filter_date )) {
			switch ($filter_date) {
				// date('H:i:s',strtotime('-1 day');
				case '1' :
					$this->db->where ( 'landingrates.observeddate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'landingrates.observeddate' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'landingrates.observeddate' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'landingrates.observeddate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'landingrates.observeddate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'landingrates.observeddate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'landingrates.observeddate' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'landingrates.observeddate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'landingrates.observeddate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'landingrates.observeddate' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		}
		
		/*
		 * if(!is_null($ttl) && !is_null($page))
		 * {
		 * if($page == 1)
		 * $page = 0;
		 * else
		 * $page--;
		 *
		 * $page *= 10;
		 * $this->db->limit($ttl ,$page);
		 * }
		 * else if(!is_null($ttl))
		 * {
		 * $this->db->limit($ttl);
		 * }
		 */
		
		if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
			switch ($orderby) {
				case '0:asc' :
					$this->db->order_by ( 'sites.site', 'ASC' );
					break;
				case '0:desc' :
					$this->db->order_by ( 'sites.site', 'DESC' );
					break;
				case '1:asc' :
					$this->db->order_by ( 'zones.zone', 'ASC' );
					break;
				case '1:desc' :
					$this->db->order_by ( 'zones.zone', 'DESC' );
					break;
				case '2:asc' :
					$this->db->order_by ( 'landingrates.observeddate', 'ASC' );
					$this->db->order_by ( 'landingrates.observedtime', 'ASC' );
					break;
				case '2:desc' :
					$this->db->order_by ( 'landingrates.observeddate', 'DESC' );
					$this->db->order_by ( 'landingrates.observedtime', 'DESC' );
					break;
				case '3:asc' :
					$this->db->order_by ( 'landingrates.countobserved', 'ASC' );
					break;
				case '3:desc' :
					$this->db->order_by ( 'landingrates.countobserved', 'DESC' );
					break;
				case '4:asc' :
					$this->db->order_by ( 'landingrates.countscollected', 'ASC' );
					break;
				case '4:desc' :
					$this->db->order_by ( 'landingrates.countscollected', 'DESC' );
					break;
			}
		} else {
			$this->db->order_by ( 'landingrates.observeddate', 'DESC' );
			$this->db->order_by ( 'landingrates.observedtime', 'DESC' );
		}
		
		$data_1 = array ();
        if(!empty($Ids)) {
            $this->db->where_in ( 'landingrates.idlandingrate', $Ids );
        }
		$query = $this->db->get ();
		$result = array ();
		// echo $this->db->last_query();
		// die;
		if ($query->num_rows () > 0)
			return $query->result_array ();
		
		return false;
	}
	
	/**
	 * Function to fetch Inspector List
	 */
	public function getInspectors() {
		$this->db->select ( 'u.iduser,
				u.firstname,
				u.middlename,
				u.lastname' );
		$this->db->from ( 'users AS u' );
		$this->db->join ( 'userlocationassignment AS ula', 'u.iduser = ula.iduser', 'LEFT' );
		$this->db->join ( 'locations AS l', 'ula.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( 'l.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'u.is_active', '1' );
		$this->db->order_by ( 'u.firstname' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$middlename = ! empty ( $row ['middlename'] ) ? " " . $row ['middlename'] . " " : " ";
				$this->str .= '<option value="' . $row ['iduser'] . '">' . $row ['firstname'] . $middlename . $row ['lastname'] . '</option>';
			}
		}
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Inspector List
	 */
	public function getSelectedInspectors($Id = '') {
		$this->db->select ( 'u.iduser,
				u.firstname,
				u.middlename,
				u.lastname' );
		$this->db->from ( 'users AS u' );
		$this->db->join ( 'userlocationassignment AS ula', 'u.iduser = ula.iduser', 'LEFT' );
		$this->db->join ( 'locations AS l', 'ula.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( 'l.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'u.is_active', '1' );
		$this->db->order_by ( 'u.firstname' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$middlename = ! empty ( $row ['middlename'] ) ? " " . $row ['middlename'] . " " : " ";
				
				if ($Id == $row ['iduser'])
					$this->str .= '<option value="' . $row ['iduser'] . '" selected="true">' . $row ['firstname'] . $middlename . $row ['lastname'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['iduser'] . '">' . $row ['firstname'] . $middlename . $row ['lastname'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Trap Names
	 */
	public function getTrapname() {
		$this->db->select ( 't.idtrap,t.trap' );
		$this->db->from ( 'traps AS t' );
		$this->db->join ( 'sites AS s', 't.idsite = s.idsite', 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 't.active', '1' );
		$this->db->where ( 't.isdeleted', '0' );
		$this->db->order_by ( 't.trap', 'asc' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['idtrap'] . '">' . $row ['trap'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Trap Names
	 */
	public function getSelectedTrapname($Id = '') {
		$this->db->select ( 't.idtrap,t.trap' );
		$this->db->from ( 'traps AS t' );
		$this->db->join ( 'sites AS s', 't.idsite = s.idsite', 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 't.active', '1' );
		$this->db->where ( 't.isdeleted', '0' );
		$this->db->order_by ( 't.trap', 'asc' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idtrap'])
					$this->str .= '<option value="' . $row ['idtrap'] . '" selected="true">' . $row ['trap'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idtrap'] . '">' . $row ['trap'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Temp Range
	 */
	public function getTemprange($Id = '') {
		$this->db->select ( 'idtemprange,temprange,ordering' );
		$this->db->from ( 'tempranges' );
		$this->db->order_by ( "ordering", "ASC" );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idtemprange']) {
					$this->str .= '<option value="' . $row ['idtemprange'] . '" selected="true">' . $row ['temprange'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idtemprange'] . '">' . $row ['temprange'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Temp Range
	 */
	public function getSelectedTemprange($Id = '') {
		$this->db->select ( 'idtemprange,temprange,ordering' );
		$this->db->from ( 'tempranges' );
		$this->db->order_by ( "ordering", "ASC" );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idtemprange'])
					$this->str .= '<option value="' . $row ['idtemprange'] . '" selected="true">' . $row ['temprange'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idtemprange'] . '">' . $row ['temprange'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Humidity Range
	 */
	public function getHumidityrange($Id = '') {
		$this->db->select ( 'idhumidityrange,humidityrange' );
		$this->db->from ( 'humidityranges' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idhumidityrange'])
					$this->str .= '<option value="' . $row ['idhumidityrange'] . '" selected="true">' . $row ['humidityrange'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idhumidityrange'] . '">' . $row ['humidityrange'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Humidity Range
	 */
	public function getSelectedHumidityrange($Id = '') {
		$this->db->select ( 'idhumidityrange,humidityrange' );
		$this->db->from ( 'humidityranges' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idhumidityrange'])
					$this->str .= '<option value="' . $row ['idhumidityrange'] . '" selected= "true">' . $row ['humidityrange'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idhumidityrange'] . '">' . $row ['humidityrange'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Wind Speed
	 */
	public function getWindspeed() {
		$this->db->select ( 'idwindspeed,windspeed' );
		$this->db->from ( 'windspeeds' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['idwindspeed'] . '">' . $row ['windspeed'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Wind Speed
	 */
	public function getSelectedWindspeed($Id = '') {
		$this->db->select ( 'idwindspeed,windspeed' );
		$this->db->from ( 'windspeeds' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idwindspeed'])
					$this->str .= '<option value="' . $row ['idwindspeed'] . '" selected="true">' . $row ['windspeed'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idwindspeed'] . '">' . $row ['windspeed'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Cloud Coverage
	 */
	public function getCloudcoverage() {
		$this->db->select ( 'idcloudcoverage,cloudcoverage' );
		$this->db->order_by ( 'cloudcoverage' );
		$this->db->from ( 'cloudcoverage' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['idcloudcoverage'] . '">' . $row ['cloudcoverage'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Cloud Coverage
	 */
	public function getSelectedCloudcoverage($Id = '') {
		$this->db->select ( 'idcloudcoverage,cloudcoverage' );
		$this->db->from ( 'cloudcoverage' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idcloudcoverage'])
					$this->str .= '<option value="' . $row ['idcloudcoverage'] . '" selected="true">' . $row ['cloudcoverage'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idcloudcoverage'] . '">' . $row ['cloudcoverage'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Species Name
	 */
	public function getSpecies($id = '') {
		$this->db->select ( 'm.*,
				lms.*,
				g.genus' );
		$this->db->join ( 'locationmosquitospecies AS lms', 'm.idmosquitospecies = lms.idmosquitospecies', 'INNER' );
		$this->db->join ( 'genuses AS g', 'm.idgenus = g.idgenus', 'INNER' );
		$this->db->from ( 'mosquitospecies AS m' );
		$this->db->order_by ( 'g.genus' );
		$this->db->order_by ( 'm.mosquitospecies' );
		$this->db->where ( 'lms.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$result = array ();
		$query = $this->db->get ();
		if ($query->num_rows () > 0) {
			$j = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$j] ['mosquitospecies'] = $row ['mosquitospecies'];
				$result [$j] ['idmosquitospecies'] = $row ['idmosquitospecies'];
				$result [$j] ['genus'] = $row ['genus'];
				$j ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to fetch Species Count
	 */
	public function getExistingSpecies($Id) {
		$this->db->select ( 'idmosquitospecies,count' );
		$this->db->from ( 'adultsurveillancedetails' );
		$this->db->where ( 'ad.idadultsurveillance', $Id );
		
		$query = $this->db->get ();
		$result = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$result [$row ['idmosquitospecies']] = $row ['count'];
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to fetch history Count
	 */
	public function getHistory($Id) {
		if (empty ( $Id ))
			return false;
		$where = "adultsurveillance.idtrap = $Id";
		$this->db->select ( '`traps`.`trap` AS `traps_trap`, 
				`traptypes`.`traptype` AS `traps_idtraptype`, 
				`adultsurveillance`.`pudate` AS `pudate`, 
				`adultsurveillance`.`putime` AS `putime`,
				adultsurveillancedetails.idadultsurveillance,
				m.idmosquitospecies,
				m.mosquitospecies,
				adultsurveillancedetails.count,(adultsurveillancedetails.count*100/(SELECT sum(`adultsurveillancedetails`.`count`) 
				FROM `adultsurveillancedetails` 
				WHERE `adultsurveillancedetails`.`idadultsurveillance` = `adultsurveillance`.`idadultsurveillance`)) AS count_percent' );
		$this->db->from ( 'adultsurveillance' );
		$this->db->join ( 'traps', 'adultsurveillance.idtrap = traps.idtrap', 'LEFT' );
		$this->db->join ( 'traptypes', 'traps.idtraptype = traptypes.idtraptype', 'LEFT' );
		$this->db->join ( 'adultsurveillancedetails', 'adultsurveillance.idadultsurveillance = adultsurveillancedetails.idadultsurveillance', 'LEFT' );
		$this->db->join ( 'mosquitospecies AS m', 'adultsurveillancedetails.idmosquitospecies = m.idmosquitospecies', 'LEFT' );
		$this->db->where ( 'adultsurveillance.idlocation', $this->session->userdata ( 'idlocation' ) );
		// $this->db->group_by("`adultsurveillancedetails`.`idadultsurveillance`");
		$this->db->order_by ( "adultsurveillancedetails.idadultsurveillance", "ASC" );
		// $this->db->order_by("adultsurveillance.pudate","ASC");
		$data_1 = array ();
		
		$query = $this->db->get ();
		// echo $this->db->last_query();
		// die;
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
		
		return false;
	}
	
	/**
	 * Function to fetch Species Name
	 */
	public function getSelectedSpecies($Id = '') {
		$sel_species = array ();
		$this->db->select ( 'landingratedetails.idlocationvectorspecies,
				mosquitospecies.mosquitospecies,
				mosquitospecies.idmosquitospecies,
				landingratedetails.count,
				g.genus' );
		$this->db->from ( 'landingratedetails' );
		$this->db->join ( 'mosquitospecies', 'landingratedetails.idlocationvectorspecies = mosquitospecies.idmosquitospecies', 'LEFT' );
		$this->db->join ( 'genuses AS g', 'mosquitospecies.idgenus = g.idgenus', 'INNER' );
		$this->db->where ( 'landingratedetails.idlandingrate', $Id );
		$this->db->order_by ( 'g.genus' );
		$this->db->order_by ( 'mosquitospecies.mosquitospecies' );
		
		$this->str = '';
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				
				// $this->str .= '<option value="'.$row['idmosquitospecies'].' " selected="true">'.$row['mosquitospecies'].'</option>';
				$sel_species [] = $row;
			}
		}
		// die;
		return $sel_species;
	}
	
	/**
	 * Function to fetch Species Count
	 */
	public function getSpeciesCount($Id, $idloc) {
		$this->db->select ( 'landingratedetails.idlocationvectorspecies,
				landingratedetails.count' );
		$this->db->from ( 'landingratedetails' );
		$this->db->where ( 'landingratedetails.idlandingrate', $Id );
		$query = $this->db->get ();
		$this->str = "";
		$species_arr = array ();
		$count_arr = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$species_arr [] = $row ['idlocationvectorspecies'];
				$count_arr [$row ['idlocationvectorspecies']] = $row ['count'];
			}
		}
		
		// print'<pre>';
		// print_r($species_arr);
		//
		// print_r($count_arr);
		
		$this->db->select ( 'mosquitospecies.mosquitospecies,
				mosquitospecies.idmosquitospecies,
				g.genus' );
		$this->db->from ( 'mosquitospecies' );
		$this->db->join ( 'genuses AS g', 'mosquitospecies.idgenus = g.idgenus', 'LEFT' );
		$this->db->join ( 'locationmosquitospecies AS lms', 'mosquitospecies.idmosquitospecies = lms.idmosquitospecies', 'INNER' );
		$this->db->where ( 'lms.idlocation', $idloc );
		$this->db->order_by ( 'g.genus', 'asc' );
		$this->db->order_by ( 'mosquitospecies.mosquitospecies' );
		$query = $this->db->get ();
		$this->str = "";
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if (in_array ( $row ['idmosquitospecies'], $species_arr ))
					$this->str .= '<tr><td style="font:normal 14px Helvetica;padding-left:110px">(' . $row ['genus'] . ') ' . $row ['mosquitospecies'] . ':</td><td style="padding-left: 80px;"><input type="text" name="' . strtolower ( $row ['mosquitospecies'] ) . '" id="' . strtolower ( $row ['mosquitospecies'] ) . '" value="' . $count_arr [$row ['idmosquitospecies']] . '" class="text3"  /></td></tr>';
				else
					$this->str .= '<tr><td style="font:normal 14px Helvetica;padding-left:110px">(' . $row ['genus'] . ') ' . $row ['mosquitospecies'] . ':</td><td style="padding-left: 80px;"><input type="text" name="' . strtolower ( $row ['mosquitospecies'] ) . '" id="' . strtolower ( $row ['mosquitospecies'] ) . '" value="0" class="text3"  /></td></tr>';
				
				// print'<pre>';
				// print_r($row['idmosquitospecies']);
			}
		}
		// print'<pre>';
		// print_r($this->str);
		// die;
		return $this->str;
	}
	/**
	 * Function to fetch toal Species Count
	 */
	public function getSpeciesTotalCount($Id) {
		if (empty ( $Id ))
			return false;
		$this->db->select ( 'landingratedetails.count,
				mosquitospecies.mosquitospecies' );
		$this->db->from ( 'landingratedetails' );
		$this->db->join ( 'mosquitospecies', 'mosquitospecies.idmosquitospecies=landingratedetails.idlocationvectorspecies', "INNER" );
		$this->db->where ( 'landingratedetails.idlandingrate', $Id );
		$this->db->order_by ( 'mosquitospecies.mosquitospecies', 'asc' );
		$query = $this->db->get ();
		$result = "";
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$result += $row ['count'];
			}
		}
		return $result;
	}
	/**
	 * Function to fetch Species Count
	 */
	public function getSpeciesCountbydate($Id) {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( 'm.idmosquitospecies,
				m.mosquitospecies,ad.count' );
		$this->db->from ( 'mosquitospecies AS m' );
		$this->db->join ( 'adultsurveillancedetails AS ad', 'm.idmosquitospecies = ad.idmosquitospecies', "LEFT" );
		$this->db->where ( 'ad.idadultsurveillance', $Id );
		$this->db->order_by ( 'm.mosquitospecies', 'asc' );
		$query = $this->db->get ();
		$result = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$result [$row ['idmosquitospecies']] [] = $row ['mosquitospecies'];
				$result [$row ['idmosquitospecies']] [] = $row ['count'];
			}
		}
		
		return $result;
	}
	
	/**
	 * function to get zone name
	 */
	public function getzone($Id = '') {
		$this->db->select ( 'idzone' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'sites.active', '1' );
		$this->db->where ( 'sites.isdeleted', '0' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'idsite', $Id );
		$query = $this->db->get ();
		if ($query->num_rows () > 0)
			return $query->result_array ();
	}
	
	/**
	 * Function to fetch Site Names
	 */
	public function getSitename($Id = '') {
		$this->db->select ( 'idsite,site' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'active', '1' );
		$this->db->where ( 'isdeleted', '0' );
		$this->db->order_by ( "site", "ASC" );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idsite']) {
					$this->str .= '<option value="' . $row ['idsite'] . ' " selected="true">' . $row ['site'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idsite'] . '">' . $row ['site'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	/**
	 * Function to fetch Site details
	 */
	public function getSiteDetails($Id = '') {
		$this->db->select ( '*' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'active', '1' );
		$this->db->where ( 'isdeleted', '0' );
		$this->db->where ( 'idsite', $Id );
		$results = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$results = $row;
			}
		}
		
		return $results;
	}
	/**
	 * Function to fetch site type
	 */
	public function getSelectedSitetype($Id = '') {
		$this->db->select ( 'idsitetype,sitetype' );
		$this->db->from ( 'sitetypes' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idsitetype']) {
					$this->str .= '<option value="' . $row ['idsitetype'] . '" selected="true">' . $row ['sitetype'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idsitetype'] . '">' . $row ['sitetype'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	/**
	 * Function to fetch selected Zone name
	 */
	public function getSelectedZonename($Id = '') {
		$this->db->select ( 'idzone,zone' );
		$this->db->order_by ( 'zone' );
		$this->db->from ( 'zones' );
		$this->db->where ( 'active', '1' );
		$this->db->where ( 'isdeleted', '0' );
		$this->db->where ( 'zones.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idzone']) {
					$this->str .= '<option value="' . $row ['idzone'] . '" selected="true">' . $row ['zone'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idzone'] . '">' . $row ['zone'] . '</option>';
				}
			}
		}
		return $this->str;
	}
	
	/**
	 * Function to fetch get State name
	 */
	public function getStatename($Id = '') {
		if (empty ( $Id )) {
			$this->db->select ( 'states.idstate' );
			$this->db->from ( 'states' );
			$this->db->join ( 'locations AS lc', "states.idstate = lc.idstate", 'LEFT' );
			$this->db->where ( 'lc.idlocation', $this->session->userdata ( 'idlocation' ) );
			
			$q = $this->db->get ();
			if ($q->num_rows () > 0) {
				$Id = $q->result_array ();
				$Id = $Id [0] ['idstate'];
			}
		}
		$this->db->select ( 'st.idstate,st.statename' );
		$this->db->from ( 'states AS st' );
		$this->db->order_by ( 'st.statename' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if (! empty ( $Id ) && $Id == $row ['idstate']) {
					$this->str .= '<option value="' . $row ['idstate'] . '" selected="true">' . $row ['statename'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idstate'] . '">' . $row ['statename'] . '</option>';
				}
			}
		}
		return $this->str;
	}
	
	/**
	 * Function to fetch get State value by name
	 */
	public function getStatebyName($Id = '') {
		if (empty ( $Id )) {
			$this->db->select ( 'states.idstate' );
			$this->db->from ( 'states' );
			$this->db->join ( 'locations AS lc', "states.idstate = lc.idstate", 'LEFT' );
			$this->db->where ( 'lc.idlocation', $this->session->userdata ( 'idlocation' ) );
			
			$q = $this->db->get ();
			if ($q->num_rows () > 0) {
				$Id = $q->result_array ();
				$Id = $Id [0] ['idstate'];
			}
		}
		$this->db->select ( 'st.idstate,st.statename' );
		$this->db->from ( 'states AS st' );
		$this->db->order_by ( 'st.statename' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idstate']) {
					$this->str .= '<option value="' . $row ['statename'] . '" selected="true">' . $row ['statename'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['statename'] . '">' . $row ['statename'] . '</option>';
				}
			}
		}
		return $this->str;
	}
	/**
	 * Function to fetch get State name
	 */
	public function getDuration($Id = '') {
		$this->db->select ( 'durations.*' );
		$this->db->from ( 'durations' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idduration']) {
					$this->str .= '<option value="' . $row ['idduration'] . '" selected="true">' . $row ['durations'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idduration'] . '">' . $row ['durations'] . '</option>';
				}
			}
		}
		return $this->str;
	}
	
	/**
	 * Function to fetch get Collected species
	 */
	public function getLandCltSpecies($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( 'm.idmosquitospecies,
				m.mosquitospecies,
				lr.count,g.genus' );
		$this->db->from ( 'mosquitospecies AS m' );
		$this->db->join ( 'genuses AS g', 'm.idgenus = g.idgenus', "LEFT" );
		$this->db->join ( 'landingratedetails AS lr', 'm.idmosquitospecies = lr.idlocationvectorspecies', "LEFT" );
		$this->db->where ( 'lr.idlandingrate', $Id );
		$this->db->order_by ( 'g.genus', 'asc' );
		$this->db->order_by ( 'm.mosquitospecies', 'asc' );
		
		$query = $this->db->get ();
		$result = array ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$result [$row ['idmosquitospecies']] [] = $row ['mosquitospecies'];
				$result [$row ['idmosquitospecies']] [] = $row ['count'];
				$result [$row ['idmosquitospecies']] [] = $row ['genus'];
			}
		}
		
		return $result;
	}
}
