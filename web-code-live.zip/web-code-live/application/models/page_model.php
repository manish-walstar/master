<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
date_default_timezone_set('UTC');
class Page_model extends CI_Model {
    
    public $table = array(
        "applicationmethod" => "applicationmethods",
        "applicationratetype" => "applicationratetypes",
        "applicationrateuom, apprateabb" => "applicationrateuom",
        "unitarea" => "area_treated",
        "assaytype" => "assaytypes",
        "avianspecies" => "avianspecies",
        "baittype" => "baittypes",
        "dilutent" => "dilutents",
        "unitfinishedmix" => "finishedmix",
        "flowrate" => "flowratetypes",
        "formulation" => "formulations",
        "genus" => "genuses",
        "instar" => "instar",
        "labresult" => "labresults", 
        "mosquitospecies" => "mosquitospecies",
        "packsize" => "packsizes",
        "productcategory" => "productcategories",
        "manufacturer" => "productmanufacturers",
        "potency" => "productpotency",
        "productname, productcode" => "products",
        "unitproduct, unitproductabbrev" => "productunit",
        "salutation" => "salutations",
        "sensortype" => "sensortypes",
        "statename" => "states",
        "systemtype" => "systemtypes",
        "traptype" => "traptypes",
        "justification" => "treatmentjustification",
        "treatmentmethod" => "treatmentmethods",
        "treatmentsystem" => "treatmentsystems",
        "virustypes" => "virustypes",
        "winddirection" => "winddirections"
    );
	
	/**
     * Constructor for the class  
     * User 
     */
    public function __construct()
    {
        // Call the Model constructor
        parent::__construct();
    }
    
    /**
     * Function to save data submitted from
     * Sutter Yuba website 
     */
    public function saveServiceRequestData($id = '') 
    {
        //print('<pre>');
//        print_r($_POST);
//        die;
        $flag = false;
        $name = $this->input->post('element_0');
        $name1 = $name;
        $questn = "Do You Need To Be Present?";
        
        if(!empty($name))
        {
            $name = explode(" " , $name);
            $data['firstname'] = !empty($name[0])?$name[0]:'';
            $lastname = '';
            for($i = 1;$i< count($name); $i++)
            {
                $lastname .= " ".$name[$i];
            }
            $lastname = trim($lastname , ' ');
            $data['lastname'] = !empty($lastname)?" ".trim($lastname):'';
                
        }
        $address  = $this->input->post('element_1');
        $cross_street  = $this->input->post('element_2');
        $city  = $this->input->post('element_3');
        $mainphone  = $this->input->post('element_4');
        $email = $this->input->post('element_5');
        $ispresent = $this->input->post('element_6');
        $comments = $this->input->post('element_7');
        $misc = $this->input->post('misc');
        $opentime = $this->input->post('time');
        //echo $misc."\n";
        $misc = !empty($misc)?base64_decode($misc):'';
        $data['address'] = !empty($address)?$address:'';
        $data['cross_street'] = !empty($cross_street)?$cross_street:'';
        $data['city'] = !empty($city)?$city:'';
        $data['ispresent'] = (!empty($ispresent[0]) && $ispresent[0] == "Yes")?'1':'0';
        $data['description'] = !empty($comments)?$comments:'';
        $data['mainphone'] = !empty($mainphone)?$mainphone:'';
        $data['opendate'] = date('Y-m-d');
        $data['opentime'] = !empty($opentime) ? $opentime : date('H:i:s',time());
		$data['isapproved'] = '0';
        $data['wasource'] = 'W';
        
        if(!empty($id) || $id == '0'){
            switch($id){
                case '0':
                    $id = '37';
                    break;
                case '1':
                    $id = '36';
                    $questn = "Dog on Property?";
                    $ispresent = $this->input->post('dog');
                    switch($ispresent){
                        case '1': 
                            $ispresent = 'Yes';
                            $data['ispresent'] = '1';
                            break;
                        case '2': 
                            $ispresent = 'Not Sure';
                            $data['ispresent'] = '2';
                            break;
                        default: 
                            $ispresent = 'No';
                            $data['ispresent'] = '0';
                            break;
                    }
                    break;
                default:
                    $id = '1';
                    break;
            }
        }
        $data['idlocation'] = $id;
        
        //$captcha_code = $this->input->post('captcha_code');
        
        //echo $captcha_code."!=".$misc."\n";
        //if(empty($captcha_code) || $captcha_code != $misc)
//        {
//            $data['captcha'] = "nocaptcha";
//            return $data;
//        }

	 $ispresent = $ispresent[0];
        $this->db->query("SET foreign_key_checks = 0");
        $this->db->insert('servicerequests' , $data);
        $this->db->query("SET foreign_key_checks = 1");
        
        $element_5 = $email = $this->input->post('element_5');
        $element_6 = $present = $this->input->post('element_6');
        
        $config['protocol'] = 'sendmail';
        $config['mailpath'] = '/usr/sbin/sendmail';
        $config['charset'] = 'iso-8859-1';
        $config['wordwrap'] = TRUE;
        $config['mailtype'] = TRUE;
        
        $this->email->initialize($config);
        $this->email->from($email, $name1);
        //$this->email->to('walt.wilson.mail@gmail.com');
        //$this->email->to('dev.amirkhan@gmail.com');
        //$this->email->bcc('dev.amirkhan@gmail.com');
        $this->email->bcc('carlos@skysoftinc.com');
        
        $this->email->subject('Service Request');
        $message = '<table width="100%" cellspacing="0" cellpadding="0" border="0" style="width:100.0%">
	<tbody><tr><td width="20%" style="width:20.0%;background:#e1e1e1;padding:5.25pt 6.75pt 5.25pt 6.75pt"><p class="MsoNormal"><b>Your Name<span style="color:red">*</span>:<u></u><u></u></b></p></td><td width="80%" style="width:80.0%;background:#e1e1e1;padding:5.25pt 6.75pt 5.25pt 0in"><p class="MsoNormal">'.$name1.'<u></u><u></u></p></td></tr><tr><td width="20%" style="width:20.0%;padding:5.25pt 6.75pt 5.25pt 6.75pt"><p class="MsoNormal"><b>Your Address<span style="color:red">*</span>:<u></u><u></u></b></p></td><td width="80%" style="width:80.0%;padding:5.25pt 6.75pt 5.25pt 0in"><p class="MsoNormal">'.$address.'<u></u><u></u></p></td></tr><tr><td width="20%" style="width:20.0%;background:#e1e1e1;padding:5.25pt 6.75pt 5.25pt 6.75pt"><p class="MsoNormal"><b>Nearest Cross Street<span style="color:red">*</span>:<u></u><u></u></b></p></td><td width="80%" style="width:80.0%;background:#e1e1e1;padding:5.25pt 6.75pt 5.25pt 0in"><p class="MsoNormal">'.$cross_street.'<u></u><u></u></p></td></tr><tr><td width="20%" style="width:20.0%;padding:5.25pt 6.75pt 5.25pt 6.75pt"><p class="MsoNormal"><b>City/Town/Area<span style="color:red">*</span>:<u></u><u></u></b></p></td><td width="80%" style="width:80.0%;padding:5.25pt 6.75pt 5.25pt 0in"><p class="MsoNormal">'.$city.'<u></u><u></u></p></td></tr><tr><td width="20%" style="width:20.0%;background:#e1e1e1;padding:5.25pt 6.75pt 5.25pt 6.75pt"><p class="MsoNormal"><b>Telephone Number<span style="color:red">*</span>:<u></u><u></u></b></p></td><td width="80%" style="width:80.0%;background:#e1e1e1;padding:5.25pt 6.75pt 5.25pt 0in"><p class="MsoNormal">'.$mainphone.'<u></u><u></u></p></td></tr><tr><td width="20%" style="width:20.0%;padding:5.25pt 6.75pt 5.25pt 6.75pt"><p class="MsoNormal"><b>Email Address<span style="color:red">*</span>:<u></u><u></u></b></p></td><td width="80%" style="width:80.0%;padding:5.25pt 6.75pt 5.25pt 0in"><p class="MsoNormal"><a target="_blank" href="mailto:carlos@skysoftinc.com">'.$email.'</a><u></u><u></u></p></td></tr><tr><td width="20%" style="width:20.0%;background:#e1e1e1;padding:5.25pt 6.75pt 5.25pt 6.75pt"><p class="MsoNormal"><b>'.$questn.'<span style="color:red">*</span>:<u></u><u></u></b></p></td><td width="80%" style="width:80.0%;background:#e1e1e1;padding:5.25pt 6.75pt 5.25pt 0in"><p class="MsoNormal">'.$ispresent.'<u></u><u></u></p></td></tr><tr><td width="20%" style="width:20.0%;padding:5.25pt 6.75pt 5.25pt 6.75pt"><p class="MsoNormal"><b>Comments- locked gates/access issues, dogs, bring mosquitofish, specific directions, etc.:<u></u><u></u></b></p></td><td width="80%" style="width:80.0%;padding:5.25pt 6.75pt 5.25pt 0in"><p class="MsoNormal">'.$comments.'<u></u><u></u></p></td></tr></tbody></table>';
        $this->email->message($message);
        
        $flag = $this->email->send();
        if($flag)
            return "sent";
        else
            return "nsent";
    }
    
    /**
     * Function to login into  
     * Support Center Wordpress Site
     */
    public function loginSupport()
    {
        $url = "http://help.go.mygeopro.com/help/wp-login.php?action=postpass";
        $postData = "post_password=geoprosupport";
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL,$url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        print'<pre>';
        print_r(curl_error($ch));
        $content = curl_exec($ch);
        curl_close ($ch);
        print_r($content);
        die("hshs");
    } 
    
    /**
     * Function to get data from database
     */
    public function getDataFromDB()
    {
        $data = array();
        //print'<pre>';
        $this->table = array('productsize' => 'productsizes');
        foreach($this->table as $key => $val){
            $result = $this->db->query("SELECT " . $key . " FROM " . $val);
            if($result -> num_rows() > 0){
                //print_r($result -> result_array());
                foreach($result -> result_array() as $key1 => $val1){
                    $temp = array();
                    $k = preg_replace('/[^A-Za-z]/', '_', $val1[key($val1)]);
                    $k = preg_replace('/[\_]{1,}/', '_', $k);
                    $k = trim(strtolower($k), '_');
                    if(!empty($k) && $k != '_'){
                        $temp['drpdwn_' . $k] = $val1[key($val1)];
                        //print_r($temp);    
                        $data = array_merge($data, $temp);   
                    }
                }                 
            }   
        }
        return $data;
    } 
}



?>