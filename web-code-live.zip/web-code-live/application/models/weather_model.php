<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Weather_model extends CI_Model {
	public $str = "";
	public $map = "";
	/**
	 * Constructor for the class
	 * Zone
	 */ 
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to Add a new Zone
	 */
	public function addweather($message = '') {
		$idloc = $this->session->userdata ( 'idlocation' );
		$get_sensor_id = $this->input->post ( 'sensor_name' );
		$sensor_details = $this->getSensorData ( $get_sensor_id );
		$date = $this->input->post ( 'date' );
		$rainfall = $this->input->post ( 'rainfall' );
		$idweatherconditions = $this->input->post ( 'idweatherconditions' );
		$cloud_cover = $this->input->post ( 'cloud_cover' );
		$winddegree = $this->input->post ( 'winddegree' );
		$wind_speed = $this->input->post ( 'wind_speed' );
		$idtemprange = $this->input->post ( 'idtemprange' );
		$idhumidityrange = $this->input->post ( 'idhumidityrange' );
		$hightide_height = $this->input->post ( 'hightide_height' );
		$hightide_date = $this->input->post ( 'hightide_date' );
		$hightide_time = $this->input->post ( 'hightide_time' );
		$lowtide_height = $this->input->post ( 'lowtide_height' );
		$lowtide_date = $this->input->post ( 'lowtide_date' );
		$lowtide_time = $this->input->post ( 'lowtide_time' );
		
		$this->load->model('usermodel');
		$data ['userId'] = $this->usermodel->getUserId();
		$data ['sensor_name'] = (! empty ( $sensor_details ['weathersensor'] )) ? $sensor_details ['weathersensor'] : 0;
		$data ['date'] = date ( 'Y-m-d', strtotime ( $date ) );
		$data ['rainfall'] = (! empty ( $rainfall )) ? $rainfall : 0;
		$data ['idweatherconditions'] = (! empty ( $idweatherconditions )) ? $idweatherconditions : 0;
		$data ['idweathersensor'] = (! empty ( $sensor_details ['idweathersensor'] )) ? $sensor_details ['idweathersensor'] : 0;
		$data ['idcloudcoverage'] = (! empty ( $cloud_cover )) ? $cloud_cover : 0;
		$data ['winddegree'] = (! empty ( $winddegree )) ? $winddegree : 0;
		$data ['idwindspeed'] = (! empty ( $wind_speed )) ? $wind_speed : 0;
		$data ['idtemprange'] = (! empty ( $idtemprange )) ? $idtemprange : 0;
		$data ['idhumidityrange'] = (! empty ( $idhumidityrange )) ? $idhumidityrange : 0;
		$data ['hightide_height'] = (! empty ( $hightide_height )) ? $hightide_height : 0;
		$data ['hightide_date'] = date ( 'Y-m-d', strtotime ( $hightide_date ) );
		$data ['hightide_time'] = (! empty ( $hightide_time )) ? $hightide_time : 0;
		$data ['lowtide_height'] = (! empty ( $lowtide_height )) ? $lowtide_height : 0;
		$data ['lowtide_date'] = date ( 'Y-m-d', strtotime ( $lowtide_date ) );
		$data ['lowtide_time'] = (! empty ( $lowtide_time )) ? $lowtide_time : 0;
		$data ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
		
		$this->db->query ( "SET foreign_key_checks = 0" );
		$this->db->insert ( 'weather', $data );
		$rows = $this->db->affected_rows ();
		if (empty ( $rows ))
			return false;
		$this->db->query ( "SET foreign_key_checks = 1" );
		return true;
	}
    
	/**
	 * Function to list Weather Data
	 */
	public function getWeather($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( '`weather`.*' );
		$this->db->from ( 'weather' );
		
		$this->db->where ( '`weather`.`idweather`', $Id );
		$this->db->where ( 'weather.isdeleted', '0' );
		
		$query = $this->db->get ();
		
		$data = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row )
				$data [] = $row;
			
			return $data [0];
		}
		
		return false;
	}
    
    /**
	 * Function to get site id based on weather id
	 */
	public function getIdSite($id = '') {
		if (empty ( $id ))
			return false;
		
		$this->db->select ( '`weathersensors`.`idsite`' );
		$this->db->from ( 'weather' );
        $this->db->join ( 'weathersensors', 'weather.idweathersensor = weathersensors.idweathersensor', 'INNER' );
		$this->db->where ( '`weather`.`idweather`', $id );
		$this->db->where ( 'weather.isdeleted', '0' );
		
		$query = $this->db->get ();
		
		$data = array ();
		if ($query->num_rows () > 0) {
			return $query->row()->idsite;
		}
		
		return false;
	}
    
	/**
	 * Function to Update a new Adultsurveillance
	 */
	public function updateWeather($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$get_sensor_id = $this->input->post ( 'sensor_name' );
		$sensor_details = $this->getSensorData ( $get_sensor_id );
		$date = $this->input->post ( 'date' );
		$rainfall = $this->input->post ( 'rainfall' );
		$idweatherconditions = $this->input->post ( 'idweatherconditions' );
		$cloud_cover = $this->input->post ( 'cloud_cover' );
		$winddegree = $this->input->post ( 'winddegree' );
		$wind_speed = $this->input->post ( 'wind_speed' );
		$idtemprange = $this->input->post ( 'idtemprange' );
		$idhumidityrange = $this->input->post ( 'idhumidityrange' );
		$hightide_height = $this->input->post ( 'hightide_height' );
		$hightide_date = $this->input->post ( 'hightide_date' );
		$hightide_time = $this->input->post ( 'hightide_time' );
		$lowtide_height = $this->input->post ( 'lowtide_height' );
		$lowtide_date = $this->input->post ( 'lowtide_date' );
		$lowtide_time = $this->input->post ( 'lowtide_time' );
		
		$data ['sensor_name'] = (! empty ( $sensor_details ['weathersensor'] )) ? $sensor_details ['weathersensor'] : 0;
		$data ['date'] = date ( 'Y-m-d', strtotime ( $date ) );
		$data ['rainfall'] = (! empty ( $rainfall )) ? $rainfall : 0;
		$data ['idweatherconditions'] = (! empty ( $idweatherconditions )) ? $idweatherconditions : 0;
		$data ['idweathersensor'] = (! empty ( $sensor_details ['idweathersensor'] )) ? $sensor_details ['idweathersensor'] : 0;
		$data ['idcloudcoverage'] = (! empty ( $cloud_cover )) ? $cloud_cover : 0;
		$data ['winddegree'] = (! empty ( $winddegree )) ? $winddegree : 0;
		$data ['idwindspeed'] = (! empty ( $wind_speed )) ? $wind_speed : 0;
		$data ['idtemprange'] = (! empty ( $idtemprange )) ? $idtemprange : 0;
		$data ['idhumidityrange'] = (! empty ( $idhumidityrange )) ? $idhumidityrange : 0;
		$data ['hightide_height'] = (! empty ( $hightide_height )) ? $hightide_height : 0;
		$data ['hightide_date'] = date ( 'Y-m-d', strtotime ( $hightide_date ) );
		$data ['hightide_time'] = (! empty ( $hightide_time )) ? $hightide_time : 0;
		$data ['lowtide_height'] = (! empty ( $lowtide_height )) ? $lowtide_height : 0;
		$data ['lowtide_date'] = date ( 'Y-m-d', strtotime ( $lowtide_date ) );
		$data ['lowtide_time'] = (! empty ( $lowtide_time )) ? $lowtide_time : 0;
		
		$this->db->where ( 'idweather', $Id );
		$this->db->update ( 'weather', $data );
		$rows = $this->db->affected_rows ();
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to list all Adultsurveillances
	 */
	public function deleteweather() {
		$idweather = $this->input->get_post ( 'id' );
		
		if (empty ( $idweather ))
			return false;
		
		$data ['isdeleted'] = '1';
		$this->db->where ( 'idweather', $idweather );
		$this->db->update ( 'weather', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to Get Lati Longi
	 * for displaying on Maps
	 */
	public function getMapdata() { // ,w.date,w.sensor_name,s.latitude,s.longitude
		$page_size = $this->input->get ( 'page_size' );
		$page = $this->input->get ( 'page' );
        $filter_date = $this->input->get ( 'filter_date' );
		$setfromdate = $this->input->get ( 'setfromdate' );
		$settodate = $this->input->get ( 'settodate' );
		
        $offset = 0;
        $page_size = ($page_size == 'all') ? 'all' : (is_numeric($page_size) ? $page_size : 10);
        $limit = (is_numeric($page_size)) ? $page_size : NULL;        
        $offset = $limit * ($page - 1);
        
        if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 2;

        $this->db->select ( 'w.*,
				ws.weathersensor,
				ws.latitude,
				ws.longitude,
				locations.GoogleZoom' );
		$this->db->from ( 'weather AS w' );
		$this->db->join ( 'weatherconditions', 'w.idweatherconditions = weatherconditions.idweathercondition', 'LEFT' );
		$this->db->join ( 'windspeeds', 'w.idwindspeed = windspeeds.idwindspeed', 'LEFT' );
		$this->db->join ( 'tempranges', 'w.idtemprange = tempranges.idtemprange', 'LEFT' );
		$this->db->join ( 'humidityranges', 'w.idhumidityrange = humidityranges.idhumidityrange', 'LEFT' );
		$this->db->join ( 'weathersensors AS ws', 'w.idweathersensor = ws.idweathersensor', 'LEFT' );
		$this->db->join ( 'sites AS s', 'ws.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'locations', 's.idlocation = locations.idlocation', 'LEFT' );
		$this->db->where ( 'w.isdeleted', '0' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		if (! is_null ( $filter_date ) && empty ( $setfromdate ) && empty ( $settodate )) {
			switch ($filter_date) {
				case '1' :
					$this->db->where ( 'w.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'w.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'w.date' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'w.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'w.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'w.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'w.date' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'w.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'w.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'w.date' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		} else if (! empty ( $setfromdate ) && ! empty ( $settodate )) {
			$this->db->where ( 'w.date' . ' >=', $setfromdate );
			$this->db->where ( 'w.date' . ' <=', $settodate );
		}
		
		$this->db->order_by ( 'w.date', 'desc' );
		$this->db->limit ( $limit, $offset );
		
		$query = $this->db->get ();
		// echo $this->db->last_query();
		$result = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$result [$row ['idweathersensor']] [] = $row;
			}
		}
		$data = array ();
		
		foreach ( $result as $key => $val ) {
			$last_24_hr = 0;
			$last_week = 0;
			$last_mnth = 0;
			$last_year = 0;
			foreach ( $val as $k => $v ) {
				// $data[$k] = $v;
				
				$yday = date ( 'Y-m-d', strtotime ( "-1 day" ) );
				if ($v ['date'] >= $yday && $v ['date'] <= date ( 'Y-m-d' )) {
					$last_24_hr += $v ['rainfall'];
				}
				
				$yday = date ( 'Y-m-d', strtotime ( "-1 week" ) );
				if ($v ['date'] >= $yday && $v ['date'] <= date ( 'Y-m-d' )) {
					$last_week += $v ['rainfall'];
				}
				
				$yday = date ( 'Y-m-d', strtotime ( "-1 month" ) );
				if ($v ['date'] >= $yday && $v ['date'] <= date ( 'Y-m-d' )) {
					$last_mnth += $v ['rainfall'];
				}
				
				$yday = date ( 'Y-m-d', strtotime ( "-1 year" ) );
				if ($v ['date'] >= $yday && $v ['date'] <= date ( 'Y-m-d' )) {
					$last_year += $v ['rainfall'];
				}
				
				// print'<pre>';
				// print_r($v);
			}
			$data [$key] ['last_24_hr'] = number_format ( $last_24_hr, 2, '.', '' );
			$data [$key] ['last_week'] = number_format ( $last_week, 2, '.', '' );
			$data [$key] ['last_month'] = number_format ( $last_mnth, 2, '.', '' );
			$data [$key] ['last_year'] = number_format ( $last_year, 2, '.', '' );
			$data [$key] ['sensor_name'] = $v ['weathersensor'];
			$data [$key] ['latitude'] = $v ['latitude'];
			$data [$key] ['longitude'] = $v ['longitude'];
		}
		// print('<pre>');
		// print_r($data);
		// print_r($result);
		// die;
		return $data;
	}
	/**
	 * Function to fetch weather sensor name
	 */
	public function getSensorname($Id = '') {
		$this->db->select ( 'idweathersensor,
				weathersensor' );
		$this->db->from ( 'weathersensors' );
		$this->db->join ( 'sites', 'weathersensors.idsite = sites.idsite', 'INNER' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'weathersensors.isdeleted', '0' );
		$this->db->where ( 'weathersensors.active', '1' );
		$this->db->order_by ( 'weathersensor' );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idweathersensor']) {
					$this->str .= '<option value="' . $row ['idweathersensor'] . '" selected="true">' . $row ['weathersensor'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idweathersensor'] . '">' . $row ['weathersensor'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	/**
	 * Function to fetch weather sensor datails
	 */
	public function getSensorData($Id = '') {
		$this->db->select ( 'weathersensors.*' );
		$this->db->from ( 'weathersensors' );
		$this->db->where ( 'idweathersensor', $Id );
		$this->db->where ( 'weathersensors.isdeleted', '0' );
		$this->db->where ( 'weathersensors.active', '1' );
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$result [] = $row;
			}
		}
		
		return $result [0];
	}
	/**
	 * Function to list all Adultsurveillances mail
	 */
	public function listWeather($Ids = "", $mapSite = "", $mapFlag = "") {
		$this->db->select ( 'weather.idweather,
				weather.sensor_name AS sensor_name, 
				weather.date AS `date`, 
				weatherconditions.weathercondition AS weatherconditions_weathercondition, 
				weather.rainfall AS rainfall,  
				winddegree, 
				windspeeds.windspeed, 
				tempranges.temprange AS tempranges_temprange, 
				humidityranges.humidityrange AS humidityranges_humidityrange' );
		$this->db->from ( 'weather' );
		$this->db->join ( 'weatherconditions', 'weather.idweatherconditions = weatherconditions.idweathercondition', 'LEFT' );
		$this->db->join ( 'windspeeds', 'weather.idwindspeed = windspeeds.idwindspeed', 'LEFT' );
		$this->db->join ( 'tempranges', 'weather.idtemprange = tempranges.idtemprange', 'LEFT' );
		$this->db->join ( 'humidityranges', 'weather.idhumidityrange = humidityranges.idhumidityrange', 'LEFT' );
		$this->db->join ( 'weathersensors AS ws', 'weather.idweathersensor = ws.idweathersensor', 'LEFT' );
		$this->db->join ( 'sites AS s', 'ws.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'locations AS l', 's.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		// $this->db->order_by("weather.date" , 'DESC');
		$this->db->where ( 'weather.isdeleted', '0' );
		
		$filter_date = $this->input->get ( 'filter_date' );
		$page_size = $this->input->get ( 'ttl' );
		$page = $this->input->get ( 'page' );
		$frmdate = $this->input->get ( 'frmdate' );
		$todate = $this->input->get ( 'todate' );
		$orderby = $this->input->get ( 'orderby' );
        
		if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 2;
		
		$offset = 0;
        $page_size = ($page_size == 'all') ? 'all' : (is_numeric($page_size) ? $page_size : 10);
        $limit = (is_numeric($page_size)) ? $page_size : NULL;        
        $offset = $limit * ($page - 1);
		
        if(!empty($mapSite)){
            $this->db->where ( 's.idsite', $mapSite );
		}
        if(!empty($mapSite) || !empty($mapFlag)){
            $filter_date = "";
            $filter_daterange = "";
            $frmdate = "";
            $todate = "";
		}
        
        
		if (! empty ( $frmdate ) && ! empty ( $todate )) {
			$frmdate = substr ( $frmdate, 0, 2 ) . '/' . substr ( $frmdate, 2, 2 ) . '/' . substr ( $frmdate, 4, 4 );
			$todate = substr ( $todate, 0, 2 ) . '/' . substr ( $todate, 2, 2 ) . '/' . substr ( $todate, 4, 4 );
			$this->db->where ( 'weather.date' . ' >=', date ( 'Y-m-d', strtotime ( $frmdate ) ) );
			$this->db->where ( 'weather.date' . ' <=', date ( 'Y-m-d', strtotime ( $todate ) ) );
		} else if (! is_null ( $filter_date )) {
			switch ($filter_date) {
				// date('H:i:s',strtotime('-1 day');
				case '1' :
					$this->db->where ( 'weather.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'weather.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'weather.date' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'weather.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'weather.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'weather.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'weather.date' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'weather.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'weather.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'weather.date' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		}
        if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
			switch ($orderby) {
				case '0:asc' :
					$this->db->order_by ( 'weather.sensor_name', 'ASC' );
					break;
				case '0:desc' :
					$this->db->order_by ( 'weather.sensor_name', 'DESC' );
					break;
				case '1:asc' :
					$this->db->order_by ( 'weather.date', 'ASC' );
					break;
				case '1:desc' :
					$this->db->order_by ( 'weather.date', 'DESC' );
					break;
				case '2:asc' :
					$this->db->order_by ( 'weatherconditions.weathercondition', 'ASC' );
					break;
				case '2:desc' :
					$this->db->order_by ( 'weatherconditions.weathercondition', 'DESC' );
					break;
				case '3:asc' :
					$this->db->order_by ( 'weather.rainfall', 'ASC' );
					break;
				case '3:desc' :
					$this->db->order_by ( 'weather.rainfall', 'DESC' );
					break;
				case '4:asc' :
					$this->db->order_by ( 'weather.winddegree', 'ASC' );
					break;
				case '4:desc' :
					$this->db->order_by ( 'weather.winddegree', 'DESC' );
					break;
				case '5:asc' :
					$this->db->order_by ( 'tempranges.temprange', 'ASC' );
					break;
				case '5:desc' :
					$this->db->order_by ( 'tempranges.temprange', 'DESC' );
					break;
				case '6:asc' :
					$this->db->order_by ( 'humidityranges.humidityrange', 'ASC' );
					break;
				case '6:desc' :
					$this->db->order_by ( 'humidityranges.humidityrange', 'DESC' );
					break;
			}
		} else {
			$this->db->order_by ( 'weather.date', 'DESC' );
		}
		
		$data_1 = array ();
        if(!empty($Ids)) {
            $this->db->where_in ( 'weather.idweather', $Ids );
        }
		$query = $this->db->get ();
		 //echo $this->db->last_query()."<br>";
//		 die;
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
		
		return false;
	}
	
	/**
	 * Function to fetch Temp Range
	 */
	public function getTemprange($Id = '') {
		$this->db->select ( 'idtemprange,
				temprange,ordering' );
		$this->db->from ( 'tempranges' );
		$this->db->order_by ( 'ordering' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idtemprange']) {
					$this->str .= '<option value="' . $row ['idtemprange'] . '" selected="true">' . $row ['temprange'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idtemprange'] . '">' . $row ['temprange'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	/**
	 * Function to fetch weather condition
	 */
	public function getWeathercondition($Id = '') {
		$this->db->select ( 'idweathercondition,
				weathercondition' );
		$this->db->from ( 'weatherconditions' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idweathercondition']) {
					$this->str .= '<option value="' . $row ['idweathercondition'] . '" selected="true">' . $row ['weathercondition'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idweathercondition'] . '">' . $row ['weathercondition'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Humidity Range
	 */
	public function getHumidityrange($Id = '') {
		$this->db->select ( 'idhumidityrange,
				humidityrange' );
		$this->db->from ( 'humidityranges' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idhumidityrange'])
					$this->str .= '<option value="' . $row ['idhumidityrange'] . '" selected="true">' . $row ['humidityrange'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idhumidityrange'] . '">' . $row ['humidityrange'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Wind Speed
	 */
	public function getSelectedWindspeed($Id = '') {
		$this->db->select ( 'idwindspeed,
				windspeed' );
		$this->db->from ( 'windspeeds' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idwindspeed'])
					$this->str .= '<option value="' . $row ['idwindspeed'] . '" selected="true">' . $row ['windspeed'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idwindspeed'] . '">' . $row ['windspeed'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Cloud Coverage
	 */
	public function getCloudcoverage($Id = '') {
		$this->db->select ( 'idcloudcoverage,
				cloudcoverage' );
		$this->db->order_by ( 'cloudcoverage' );
		$this->db->from ( 'cloudcoverage' );
		$this->str = "";
		$query = $this->db->get ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idcloudcoverage'])
					$this->str .= '<option value="' . $row ['idcloudcoverage'] . '" selected="true">' . $row ['cloudcoverage'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idcloudcoverage'] . '">' . $row ['cloudcoverage'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch history Count
	 */
	public function getHistory($Id) {
		if (empty ( $Id ))
			return false;
		$where = "adultsurveillance.idtrap = $Id";
		$this->db->select ( '`traps`.`trap` AS `traps_trap`, 
				`traptypes`.`traptype` AS `traps_idtraptype`, 
				`adultsurveillance`.`pudate` AS `pudate`, 
				`adultsurveillance`.`putime` AS `putime`,
				adultsurveillancedetails.idadultsurveillance,
				m.idmosquitospecies,
				m.mosquitospecies,
				adultsurveillancedetails.count,
				(adultsurveillancedetails.count*100/(SELECT sum(`adultsurveillancedetails`.`count`) 
				FROM `adultsurveillancedetails` 
				WHERE `adultsurveillancedetails`.`idadultsurveillance` = `adultsurveillance`.`idadultsurveillance`)) 
				AS count_percent' );
		$this->db->from ( 'adultsurveillance' );
		$this->db->join ( 'traps', 'adultsurveillance.idtrap = traps.idtrap', 'LEFT' );
		$this->db->join ( 'traptypes', 'traps.idtraptype = traptypes.idtraptype', 'LEFT' );
		$this->db->join ( 'adultsurveillancedetails', 'adultsurveillance.idadultsurveillance = adultsurveillancedetails.idadultsurveillance', 'LEFT' );
		$this->db->join ( 'mosquitospecies AS m', 'adultsurveillancedetails.idmosquitospecies = m.idmosquitospecies', 'LEFT' );
		// $this->db->where($where);
		// $this->db->group_by("`adultsurveillancedetails`.`idadultsurveillance`");
		$this->db->order_by ( "adultsurveillancedetails.idadultsurveillance", "ASC" );
		// $this->db->order_by("adultsurveillance.pudate","ASC");
		$data_1 = array ();
		
		$query = $this->db->get ();
		// echo $this->db->last_query();
		// die;
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
		
		return false;
	}
	
	/**
	 * Function to check site name
	 */
	public function check_sitename($Id = '') {
		$this->db->select ( 'idsite' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'idsite', $Id );
		$result = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$result = '1';
		}
		
		return $result;
	}
}
