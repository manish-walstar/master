<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Larvalsurveillance_model extends CI_Model {
	public $str = "";
	public $map = "";
	
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to Add a new Zone
	 */
	public function addLarvalsurveillance($message = '') {
		// get service request id
		$idloc = $this->session->userdata ( 'idlocation' );
		$new_site = $this->input->post ( 'new_site' );
		
		// sonu code end here
		/**
		 * start insert data into sites table*
		 */
		$data_site ['site'] = $this->input->post ( 'idsite' );
		$data_site ['idsitetype'] = $this->input->post ( 'idsitetype' );
		$data_site ['maplabel'] = $this->input->post ( 'maplabel' );
		$data_site ['address1'] = $this->input->post ( 'address1' );
		$data_site ['address2'] = $this->input->post ( 'address2' );
		$data_site ['city'] = $this->input->post ( 'city' );
		$data_site ['idstate'] = $this->input->post ( 'idstate' );
		$data_site ['postalcode'] = $this->input->post ( 'postalcode' );
		$data_site ['latitude'] = $this->input->post ( 'latitude' );
		$data_site ['longitude'] = $this->input->post ( 'longitude' );
		$data_site ['pdop'] = $this->input->post ( 'pdop' );
		$data_site ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
		
		$this->db->query ( "SET foreign_key_checks = 0" );
		$site_id = "";
		if ($new_site == "0") {
			$this->db->insert ( 'sites', $data_site );
			$site_id = $this->db->insert_id ();
		} else {
			$site_id = $new_site;
		}
		
		$this->db->query ( "SET foreign_key_checks = 1" );
		
		$date = $this->input->post ( 'date' );
		$time = $this->input->post ( 'time' );
		
		/**
		 * end insert data into sites table*
		 */
		$data ['idsite'] = $site_id;
		
		$this->load->model('usermodel');
		$data ['userId'] = $this->usermodel->getUserId();
		
		$data ['idinspector'] = $this->input->post ( 'idinspector' );
		$data ['latitude'] = $this->input->post ( 'latitude' );
		$data ['longitude'] = $this->input->post ( 'longitude' );
		$data ['date'] = ! empty ( $date ) ? date ( 'Y-m-d', strtotime ( $date ) ) : date ( 'Y-m-d' );
		$data ['time'] = ! empty ( $time ) ? date ( 'h:i:s A', strtotime ( $time ) ) : date ( 'h:i:s A' );
		$data ['idsitetype'] = $this->input->post ( 'idsitetype' );
		$data ['idzone'] = $this->input->post ( 'idzone' );
		$data ['maplabel'] = $this->input->post ( 'maplabel' );
		$data ['idwatertemprange'] = $this->input->post ( 'idwatertemprange' );
		$data ['larvaepresent'] = $this->input->post ( 'larvaepresent' );
		$data ['idlarvaecountrange'] = $this->input->post ( 'idlarvaecountrange' );
		$data ['idinstar'] = $this->input->post ( 'idinstar' );
		$data ['idsitestatus'] = $this->input->post ( 'idsitestatus' );
		$data ['comments'] = $this->input->post ( 'comments' );
		$data ['totalcount'] = $this->input->post ( 'idlarvaecountrange' );
		$data ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
		
		$this->db->query ( "SET foreign_key_checks = 0" );
		$this->db->insert ( 'larvalsurveillance', $data );
		
		$rows = $this->db->affected_rows ();
		// $rows = 1;
		
		$id = $this->db->insert_id ();
		$this->db->query ( "SET foreign_key_checks = 1" );
		// $id =1 ;
		
		// code by sonu form species and species data count insert
		
		$species = $this->input->post ( 'species_val' );
		// echo '<pre>'; print_r($species); echo '</pre>';
		$s_count = $this->input->post ( 'species_countval' );
		// echo '<pre>'; print_r($s_count); echo '</pre>'; die;
		
		if (! empty ( $species )) {
		//if (isset ( $species ) && count ( $species ) > 0) {
			$this->db->query ( 'SET foreign_key_checks = 0' );
			for($i = 0; $i < count ( $species ); $i ++) {
				$data_species = array ();
				$data_species ['idlarvalsurveillance'] = $id;
				$data_species ['idmosquitospecies'] = ! empty ( $species [$i] ) ? $species [$i] : 0;
				$data_species ['count'] = ! empty ( $s_count [$i] ) ? $s_count [$i] : 0;
				$this->db->insert ( 'larvalsurveillancedetails', $data_species );
			}
			$this->db->query ( 'SET foreign_key_checks = 1' );
		}
		
		// end here sonu code
		$service_req_id = $this->input->get_post ( 'service_req_id' );
		if (! empty ( $service_req_id )) {
			$data_common ['idlarvalsurveillance'] = $id;
			$data_common ['idservicerequest'] = $service_req_id;
			$data_common ['idlocation'] = $idloc;
			$this->db->insert ( 'larvalsurveillanceservice', $data_common );
		}
		
		// die;
		
		return true;
	}

	/**
	 * Function to Update a new Larvalsurveillance
	 */
	public function updateLarvalsurveillance($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$idloc = $this->session->userdata ( 'idlocation' );
		$new_site = $this->input->post ( 'new_site' );
		/*
		 * echo '<pre>';
		 * print_r($_POST);die;
		 */
		/**
		 * start update data into sites table*
		 */
		$data_site ['site'] = $this->input->post ( 'idsite' );
		$exit_site_id = $this->input->post ( 'new_site' );
		$data_site ['idsitetype'] = $this->input->post ( 'idsitetype' );
		$data_site ['maplabel'] = $this->input->post ( 'maplabel' );
		$data_site ['address1'] = $this->input->post ( 'address1' );
		$data_site ['address2'] = $this->input->post ( 'address2' );
		$data_site ['city'] = $this->input->post ( 'city' );
		$data_site ['idstate'] = $this->input->post ( 'idstate' );
		$data_site ['postalcode'] = $this->input->post ( 'postalcode' );
		$data_site ['latitude'] = $this->input->post ( 'latitude' );
		$data_site ['longitude'] = $this->input->post ( 'longitude' );
		$data_site ['pdop'] = $this->input->post ( 'pdop' );
		$data_site ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
		
		$site_id = "";
		if ($new_site == "0") {
			$this->db->insert ( 'sites', $data_site );
			$site_id = $this->db->insert_id ();
		} else {
			$site_id = $new_site;
		}
		
		$date = $this->input->post ( 'date' );
		$time = $this->input->post ( 'time' );
		
		/**
		 * end update data into sites table*
		 */
		$data ['idsite'] = $site_id;
		$data ['idinspector'] = $this->input->post ( 'idinspector' );
		$data ['latitude'] = $this->input->post ( 'latitude' );
		$data ['longitude'] = $this->input->post ( 'longitude' );
		$data ['date'] = ! empty ( $date ) ? date ( 'Y-m-d', strtotime ( $date ) ) : date ( 'Y-m-d' );
		$data ['time'] = ! empty ( $time ) ? date ( 'h:i:s A', strtotime ( $time ) ) : date ( 'h:i:s A' );
		$data ['idsitetype'] = $this->input->post ( 'idsitetype' );
		$data ['idzone'] = $this->input->post ( 'idzone' );
		$data ['maplabel'] = $this->input->post ( 'maplabel' );
		$data ['idwatertemprange'] = $this->input->post ( 'idwatertemprange' );
		$data ['larvaepresent'] = $this->input->post ( 'larvaepresent' );
		$data ['idlarvaecountrange'] = $this->input->post ( 'idlarvaecountrange' );
		$data ['idinstar'] = $this->input->post ( 'idinstar' );
		$data ['idsitestatus'] = $this->input->post ( 'idsitestatus' );
		$data ['comments'] = $this->input->post ( 'comments' );
		$data ['totalcount'] = $this->input->post ( 'idlarvaecountrange' );
		$this->db->where ( 'idlarvalsurveillance', $Id );
		$this->db->update ( 'larvalsurveillance', $data );
		
		$locationvector_id = $this->getLocationvectorId ( $Id );
		
		if (! empty ( $locationvector_id )) {
			foreach ( $locationvector_id as $val ) {
				$this->db->where ( 'idlarvalsurveillancedetails', $val );
				$this->db->delete ( 'larvalsurveillancedetails' );
			}
		}
		
		$species = $this->input->post ( 'species_val' );
		$s_count = $this->input->post ( 'species_countval' );
		
		$this->db->query ( 'SET foreign_key_checks = 0' );
		$this->db->where ( 'idlarvalsurveillance', $Id );
		$this->db->delete ( 'larvalsurveillancedetails' );
		
		for($i = 0; $i < count ( $species ); $i ++) {
			$data_species = array ();
			$data_species ['idlarvalsurveillance'] = $Id;
			$data_species ['idmosquitospecies'] = ! empty ( $species [$i] ) ? $species [$i] : 0;
			$data_species ['count'] = ! empty ( $s_count [$i] ) ? $s_count [$i] : 0;
			$this->db->insert ( 'larvalsurveillancedetails', $data_species );
			echo $this->db->last_query () . '<br />';
		}
		$this->db->query ( 'SET foreign_key_checks = 1' );
		
		return true;
	}
	
	/**
	 * Function to fetch Larva Count
	 */
	public function getLarvaecount($Id = '') {
		$this->db->select ( 'larvalsurveillance.totalcount,
				s.idsite' );
		
		$this->db->from ( 'larvalsurveillance' );
		$this->db->join ( 'sites AS s', "larvalsurveillance.idsite = s.idsite", 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'idlarvalsurveillance', $Id );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				/*
				 * if($Id==$row['idlarvaecountrange']) {
				 * $this->str .= '<option value="'.$row['idlarvaecountrange'].'" selected="true">'.$row['larvaecountrange'].'</option>';
				 * } else {
				 * $this->str .= '<option value="'.$row['idlarvaecountrange'].'">'.$row['larvaecountrange'].'</option>';
				 * }
				 */
				$this->str = $row ['totalcount'];
			}
		}
		return $this->str;
	}
	
	/**
	 * Function to fetch site id
	 */
	public function getLocationvectorId($Id = '') {
		$this->db->select ( 'idlarvalsurveillancedetails' );
		$this->db->from ( 'larvalsurveillancedetails' );
		$this->db->where ( 'idlarvalsurveillance', $Id );
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$result [] = $row ['idlarvalsurveillancedetails'];
			}
		}
		return $result;
	}
	/**
	 * Function to list all Larvalsurveillances
	 */
	public function deleteLarvalsurveillance() {
		$id = $this->input->get_post ( 'id' );
		
		if (empty ( $id ))
			return false;
			
			/*
		 * $this->db->select('*');
		 * $this->db->from('larvalsurveillancedetails');
		 * $this->db->where('idlarvalsurveillance',$id);
		 *
		 * $q = $this->db->get();
		 * if($q->num_rows() > 0)
		 * {
		 * $this->db->query("SET foreign_key_checks = 0");
		 * $this->db->where('idlarvalsurveillance',$id);
		 * $this->db->delete('larvalsurveillancedetails');
		 * $this->db->query("SET foreign_key_checks = 1");
		 * }
		 *
		 * // delete records from larval surveilance service
		 * $this->db->select('*');
		 * $this->db->from('larvalsurveillanceservice');
		 * $this->db->where('idlarvalsurveillance',$id);
		 * $p = $this->db->get();
		 * if($p->num_rows() > 0)
		 * {
		 * $this->db->query("SET foreign_key_checks = 0");
		 * $this->db->where('idlarvalsurveillance',$id);
		 * $this->db->delete('larvalsurveillanceservice');
		 * $this->db->query("SET foreign_key_checks = 1");
		 * }
		 */
		$data ['isdeleted'] = '1';
		$this->db->where ( 'idlarvalsurveillance', $id );
		$this->db->update ( 'larvalsurveillance', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to Show Map
	 * having Multiple markers for Larval
	 */
	public function showmap() {
		$query ['data'] = $this->getMapdata ();
		
		// print'<pre>';
		// print_r($query['data']);
		// die;
		$this->load->view ( 'larvalsurveillances/map_view', $query );
		// die;
		// $this->map = $this->load->view('larvalsurveillances/map_view',$query,TRUE);
		// echo $this->map;
		// die;
		// return $this->map;
	}
	
	/**
	 * Function to Get Lati Longi
	 * for displaying on Maps
	 */
	public function getMapdata() {
		$page_size = $this->input->get ( 'page_size' );
		$page = $this->input->get ( 'page' );
		$filter_date = $this->input->get ( 'filter_date' );
		$setfromdate = $this->input->get ( 'setfromdate' );
		$settodate = $this->input->get ( 'settodate' );
		
        $offset = 0;
        $page_size = ($page_size == 'all') ? 'all' : (is_numeric($page_size) ? $page_size : 10);
        $limit = (is_numeric($page_size)) ? $page_size : NULL;        
        $offset = $limit * ($page - 1);
        
        if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 2;

		$this->db->select ( 'ld.*,
				s.idsite,
				s.site,
				s.idlocation,
				s.address1,
				s.address2,
				s.city,
				s.idstate,
				st.sitetype,
				u.firstname,
				u.lastname,
				u.middlename,
				ld.totalcount AS larvaecountrange,
				l.GoogleZoom' );
		$this->db->from ( 'larvalsurveillance AS ld' );
		// $this->db->join('sitestatuses AS ss','ld.idsitestatus = ss.idsitestatus','LEFT');
		// $this->db->join('watertempranges AS wt','ld.idwatertemprange = wt.idwatertemprange','LEFT');
		// $this->db->join('larvaecountrange AS lc','ld.idlarvaecountrange = lc.idlarvaecountrange','LEFT');
		// $this->db->join('instar','ld.idinstar = instar.idinstar','LEFT');
		$this->db->join ( 'users AS u', 'ld.idinspector = u.iduser', 'LEFT' );
		$this->db->join ( 'sites AS s', 'ld.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'locations AS l', 's.idlocation = l.idlocation', 'LEFT' );
		$this->db->join ( 'sitetypes AS st', 's.idsitetype = st.idsitetype', 'LEFT' );
		// $this->db->join('sitezoneassignment AS sz','s.idsite = sz.idsite','LEFT');
		// $this->db->join('zones AS z','sz.idzone = z.idzone','LEFT');
		// $this->db->join('larvalsurveillancedetails AS ldst','ld.idlarvalsurveillance = ldst.idlarvalsurveillance','LEFT');
		$this->db->where ( 'ld.isdeleted', '0' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		if (! is_null ( $filter_date ) && empty ( $setfromdate ) && empty ( $settodate )) {
			switch ($filter_date) {
				// date('H:i:s',strtotime('-1 day');
				case '1' :
					$this->db->where ( 'ld.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'ld.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'ld.date' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'ld.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'ld.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'ld.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'ld.date' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'ld.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'ld.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'ld.date' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		} else if (! empty ( $setfromdate ) && ! empty ( $settodate )) {
			$this->db->where ( 'ld.date' . ' >=', $setfromdate );
			$this->db->where ( 'ld.date' . ' <=', $settodate );
		}
		$this->db->order_by ( 'ld.date', 'desc' );
		$this->db->limit ( $limit, $offset );
		
		$data_1 = array ();
		$query = $this->db->get ();
		// echo $this->db->last_query();
		// die;
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
	}
	/**
	 * Function to list all Larvalsurveillances mail
	 */
	public function getLarvalsurveillanceData($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( '`larvalsurveillance`.*, 
				s.idzone as idzone1 , 
				s.idsitetype as idsitetype1' );
		$this->db->from ( 'larvalsurveillance' );
		$this->db->join ( 'sites AS s', "larvalsurveillance.idsite = s.idsite", 'LEFT' );
		$this->db->join ( 'zones AS z', "s.idzone = z.idzone", 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		// $this->db->where('z.idlocation',$this->session->userdata('idlocation'));
		$this->db->where ( 'larvalsurveillance.isdeleted', '0' );
		$this->db->where ( '`larvalsurveillance`.`idlarvalsurveillance`', $Id );
		
		$query = $this->db->get ();
		// echo $this->db->last_query();
		$data = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row )
				$data [] = $row;
			
			return $data [0];
		}
		
		return false;
	}
	/**
	 * Function to fetch comment field
	 */
	public function getComment($Id = '') {
		$this->db->select ( 'comments,s.idsite' );
		$this->db->from ( 'larvalsurveillance' );
		
		$this->db->join ( 'sites AS s', "larvalsurveillance.idsite = s.idsite", 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$this->db->where ( '`larvalsurveillance`.`idlarvalsurveillance`', $Id );
		
		$query = $this->db->get ();
		
		$results = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row )
				$results = $row ['comments'];
			
			return $results;
		}
	}
	/**
	 * Function to list all Larvalsurveillances mail
	 */
	public function listLarvalsurveillances($Ids = "", $mapSite = "", $mapFlag = "") {
		$this->db->select ( "larvalsurveillance.idlarvalsurveillance, 
				sites.site, 
				larvalsurveillance.date AS `date`, 
				larvalsurveillance.time AS `time`, 
				users.firstname, 
				users.middlename, 
				users.lastname, 
				larvalsurveillance.totalcount AS larvaecountrange, 
				sites.address1, 
				sites.address2, 
				sites.city, 
				states.statename,
                CONCAT(larvalsurveillance.date,' ',larvalsurveillance.time) AS schdledatetime,
                CONCAT(users.firstname,' ',users.middlename,' ',users.lastname) AS inspctr,
                CONCAT(sites.address1,' ',sites.address2) AS addrs" );
		$this->db->from ( 'larvalsurveillance' );
		$this->db->join ( 'sites', 'larvalsurveillance.idsite = sites.idsite', 'LEFT' );
		$this->db->join ( 'states', 'sites.idstate = states.idstate', 'LEFT' );
		$this->db->join ( 'users', 'larvalsurveillance.idinspector = users.iduser', 'LEFT' );
		// $this->db->join('larvaecountrange','larvalsurveillance.idlarvaecountrange = larvaecountrange.idlarvaecountrange','LEFT');
		$this->db->join ( 'locations', 'sites.idlocation = locations.idlocation', 'LEFT' );
		$this->db->where ( 'larvalsurveillance.isdeleted', '0' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		
        $filter_date = $this->input->get ( 'filter_date' );
		$ttl = $this->input->get ( 'ttl' );
		$page = $this->input->get ( 'page' );
		$frmdate = $this->input->get ( 'frmdate' );
		$todate = $this->input->get ( 'todate' );
		$orderby = $this->input->get ( 'orderby' );
		
		if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 2;
		
		if (! isset ( $ttl ) || $ttl == '')
			$ttl = 10;
		
		if (! isset ( $page ) || $page == '')
			$page = 1;
		if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 2;
		
        if(!empty($mapSite)){
            $this->db->where ( 'sites.idsite', $mapSite );
		}
        
        if(!empty($mapSite) || !empty($mapFlag)){
            $filter_date = "";
            $filter_daterange = "";
            $frmdate = "";
            $todate = "";
		}
        
		if (! empty ( $frmdate ) && ! empty ( $todate )) {
			$frmdate = substr ( $frmdate, 0, 2 ) . '/' . substr ( $frmdate, 2, 2 ) . '/' . substr ( $frmdate, 4, 4 );
			$todate = substr ( $todate, 0, 2 ) . '/' . substr ( $todate, 2, 2 ) . '/' . substr ( $todate, 4, 4 );
			$this->db->where ( 'larvalsurveillance.date' . ' >=', date ( 'Y-m-d', strtotime ( $frmdate ) ) );
			$this->db->where ( 'larvalsurveillance.date' . ' <=', date ( 'Y-m-d', strtotime ( $todate ) ) );
		} else if (! is_null ( $filter_date )) {
			switch ($filter_date) {
				// date('H:i:s',strtotime('-1 day');
				case '1' :
					$this->db->where ( 'larvalsurveillance.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'larvalsurveillance.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'larvalsurveillance.date' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'larvalsurveillance.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'larvalsurveillance.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'larvalsurveillance.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'larvalsurveillance.date' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'larvalsurveillance.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'larvalsurveillance.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'larvalsurveillance.date' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		}
		
		if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
			switch ($orderby) {
				case '0:asc' :
					$this->db->order_by ( 'sites.site', 'ASC' );
					break;
				case '0:desc' :
					$this->db->order_by ( 'sites.site', 'DESC' );
					break;
				case '1:asc' :
					$this->db->order_by ( 'larvalsurveillance.date', 'ASC' );
					$this->db->order_by ( 'larvalsurveillance.time', 'ASC' );
					break;
				case '1:desc' :
					$this->db->order_by ( 'larvalsurveillance.date', 'DESC' );
					$this->db->order_by ( 'larvalsurveillance.time', 'DESC' );
					break;
				case '2:asc' :
					$this->db->order_by ( "users.firstname", 'ASC' );
					$this->db->order_by ( "users.middlename", 'ASC' );
					$this->db->order_by ( "users.lastname", 'ASC' );
					break;
				case '2:desc' :
					$this->db->order_by ( "users.firstname", 'DESC' );
					$this->db->order_by ( "users.middlename", 'DESC' );
					$this->db->order_by ( "users.lastname", 'DESC' );
					break;
				case '3:asc' :
					$this->db->order_by ( 'larvalsurveillance.totalcount', 'ASC' );
					break;
				case '3:desc' :
					$this->db->order_by ( 'larvalsurveillance.totalcount', 'DESC' );
					break;
				case '4:asc' :
					$this->db->order_by ( "SUBSTRING_INDEX(sites.address1, ' ', 1) + 0", 'ASC' );
					$this->db->order_by ( "sites.address2", 'ASC' );
					$this->db->order_by ( "sites.city", 'ASC' );
					$this->db->order_by ( "states.statename", 'ASC' );
					break;
				case '4:desc' :
					$this->db->order_by ( "SUBSTRING_INDEX(sites.address1, ' ', 1) + 0", 'DESC' );
					$this->db->order_by ( "sites.address2", 'DESC' );
					$this->db->order_by ( "sites.city", 'DESC' );
					$this->db->order_by ( "states.statename", 'DESC' );
					break;
			}
		} else {
			$this->db->order_by ( "larvalsurveillance.date", 'DESC' );
			$this->db->order_by ( "larvalsurveillance.time", 'DESC' );
		}
		
		$data_1 = array ();
        if(!empty($Ids)) {
            $this->db->where_in ( 'larvalsurveillance.idlarvalsurveillance', $Ids );
        }
		$query = $this->db->get ();
		// echo $this->db->last_query()."<br>";
		// die;
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
		
		return false;
	}
	
	/**
	 * Function to fetch Inspector List
	 */
	
	/* code by Sunny */
	public function getUserGroups() {
		$this->db->select ( 'idusergroup,
				usergroup' );
		$this->db->from ( 'usergroups' );
		$this->db->where ( 'usergroups.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'isdeleted', '0' );
		$this->db->order_by ( 'usergroup' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['idusergroup'] . '">' . $row ['usergroup'] . '</option>';
			}
		}
		
		return $this->str;
	}
	public function getSelectedGroups($Id = '') {
		$this->db->select ( 'idusergroup,
				usergroup' );
		$this->db->from ( 'usergroups' );
		$this->db->where ( 'usergroups.isdeleted', '0' );
		$this->db->where ( 'usergroups.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->order_by ( 'usergroup' );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				if ($row ['idusergroup'] == $Id && ! empty ( $Id ))
					$this->str .= '<option value="' . $row ['idusergroup'] . '" selected="true">' . $row ['usergroup'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idusergroup'] . '">' . $row ['usergroup'] . '</option>';
			}
		}
		
		return $this->str;
	}
	public function getInspectors() {
		$this->db->select ( 'u.iduser,
				u.firstname,
				u.middlename,
				u.lastname' );
		$this->db->from ( 'users AS u' );
		$this->db->join ( 'userlocationassignment AS ula', "u.iduser = ula.iduser", 'INNER' );
		$this->db->join ( 'locations AS lc', "ula.idlocation = lc.idlocation", 'INNER' );
		$this->db->where ( 'lc.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'u.is_active', '1' );
		$this->db->order_by ( 'u.firstname' );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$middlename = ! empty ( $row ['middlename'] ) ? " " . $row ['middlename'] . " " : " ";
				$this->str .= '<option value="' . $row ['iduser'] . '">' . $row ['firstname'] . $middlename . $row ['lastname'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Inspector List
	 */
	public function getSelectedInspectors($Id = '') {
		$this->db->select ( 'u.iduser,
				u.firstname,
				u.middlename,
				u.lastname' );
		$this->db->from ( 'users AS u' );
		$this->db->join ( 'userlocationassignment AS ula', "u.iduser = ula.iduser", 'INNER' );
		$this->db->join ( 'locations AS lc', "ula.idlocation = lc.idlocation", 'INNER' );
		$this->db->where ( 'lc.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'u.is_active', '1' );
		$this->db->order_by ( 'u.firstname' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$middlename = ! empty ( $row ['middlename'] ) ? " " . $row ['middlename'] . " " : " ";
				
				if ($Id == $row ['iduser'])
					$this->str .= '<option value="' . $row ['iduser'] . '" selected="true">' . $row ['firstname'] . $middlename . $row ['lastname'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['iduser'] . '">' . $row ['firstname'] . $middlename . $row ['lastname'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Trap Names
	 */
	public function getSitename($Id = '') {
		$this->db->select ( 'idsite,
				site' );
		$this->db->order_by ( 'site' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'active', '1' );
		$this->db->where ( 'isdeleted', '0' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idsite']) {
					$this->str .= '<option value="' . $row ['idsite'] . ' " selected="true">' . $row ['site'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idsite'] . '">' . $row ['site'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	/**
	 * Function to fetch site type
	 */
	public function getSelectedSitetype($Id = '') {
		$this->db->select ( 'idsitetype,
				sitetype' );
		$this->db->from ( 'sitetypes' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idsitetype']) {
					$this->str .= '<option value="' . $row ['idsitetype'] . '" selected="true">' . $row ['sitetype'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idsitetype'] . '">' . $row ['sitetype'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Trap Names
	 */
	public function getSelectedSitedetails($Id = '') {
		$this->db->select ( 'sites.*' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'sites.active', '1' );
		$this->db->where ( 'sites.isdeleted', '0' );
		$this->db->where ( 'idsite', $Id );
		$results = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				
				$results = $row;
			}
		}
		return $results;
	}
	/**
	 * Function to fetch Temp Range
	 */
	public function getTemprange() {
		$this->db->select ( 'idtemprange,
				temprange,ordering' );
		$this->db->from ( 'tempranges' );
		$this->db->order_by ( 'ordering', 'ASC' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['idtemprange'] . '">' . $row ['temprange'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Temp Range
	 */
	public function getSelectedTemprange($Id = '') {
		$this->db->select ( 'idtemprange,temprange,
				ordering' );
		$this->db->from ( 'tempranges' );
		$this->db->order_by ( 'ordering', 'ASC' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idtemprange'])
					$this->str .= '<option value="' . $row ['idtemprange'] . '" selected="true">' . $row ['temprange'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idtemprange'] . '">' . $row ['temprange'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Humidity Range
	 */
	public function getHumidityrange() {
		$this->db->select ( 'idhumidityrange,
				humidityrange' );
		$this->db->from ( 'humidityranges' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['idhumidityrange'] . '">' . $row ['humidityrange'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Humidity Range
	 */
	public function getSelectedHumidityrange($Id = '') {
		$this->db->select ( 'idhumidityrange,
				humidityrange' );
		$this->db->from ( 'humidityranges' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idhumidityrange'])
					$this->str .= '<option value="' . $row ['idhumidityrange'] . '" selected= "true">' . $row ['humidityrange'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idhumidityrange'] . '">' . $row ['humidityrange'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Wind Speed
	 */
	public function getWindspeed() {
		$this->db->select ( 'idwindspeed,
				windspeed' );
		$this->db->from ( 'windspeeds' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['idwindspeed'] . '">' . $row ['windspeed'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Wind Speed
	 */
	public function getSelectedWindspeed($Id = '') {
		$this->db->select ( 'idwindspeed,
				windspeed' );
		$this->db->from ( 'windspeeds' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idwindspeed'])
					$this->str .= '<option value="' . $row ['idwindspeed'] . '" selected="true">' . $row ['windspeed'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idwindspeed'] . '">' . $row ['windspeed'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Cloud Coverage
	 */
	public function getCloudcoverage() {
		$this->db->select ( 'idcloudcoverage,
				cloudcoverage' );
		$this->db->from ( 'cloudcoverage' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['idcloudcoverage'] . '">' . $row ['cloudcoverage'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Cloud Coverage
	 */
	public function getSelectedCloudcoverage($Id = '') {
		$this->db->select ( 'idcloudcoverage,
				cloudcoverage' );
		$this->db->from ( 'cloudcoverage' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idcloudcoverage'])
					$this->str .= '<option value="' . $row ['idcloudcoverage'] . '" selected="true">' . $row ['cloudcoverage'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idcloudcoverage'] . '">' . $row ['cloudcoverage'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Species Name
	 */
	public function getSpecies($id = '') {
		// $allspecies = $this->getSelectedSpecies_I();
		$this->db->select ( 'lvm.*,
				m.*,
				g.genus' );
		$this->db->from ( 'locationmosquitospecies AS lvm' );
		$this->db->join ( 'mosquitospecies AS m', 'lvm.idmosquitospecies = m.idmosquitospecies', 'INNER' );
		$this->db->join ( 'genuses AS g', 'm.idgenus = g.idgenus', 'INNER' );
		$this->db->order_by ( 'g.genus' );
		$this->db->order_by ( 'm.mosquitospecies' );
		$this->db->where ( 'lvm.idlocation', $this->session->userdata ( 'idlocation' ) );
		$result = array ();
		$query = $this->db->get ();
		// echo $this->db->last_query();
		// die;
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				// if(!in_array($row['idmosquitospecies'],$allspecies))
				// modified by sonu
				$result [$row ['idmosquitospecies']] = '(' . $row ['genus'] . ')' . $row ['mosquitospecies'];
			}
		}
		return $result;
	}
	
	/**
	 * Function to fetch Species Name
	 */
	public function getSelectedSpecies_I() {
		$this->db->select ( '*' );
		$this->db->from ( 'larvalsurveillancedetails' );
		$result = array ();
		$query = $this->db->get ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$result [] = $row ['idmosquitospecies'];
			}
		}
		return $result;
	}
	
	/**
	 * Function to fetch Species Name
	 */
	public function getSelectedSpecies($Id = '') {
		$sel_species = array ();
		$this->db->select ( 'larvalsurveillancedetails.idmosquitospecies,
				mosquitospecies.mosquitospecies,
				mosquitospecies.idmosquitospecies,
				larvalsurveillancedetails.count,
				g.genus' );
		$this->db->from ( 'larvalsurveillancedetails' );
		$this->db->join ( 'mosquitospecies', 'larvalsurveillancedetails.idmosquitospecies=mosquitospecies.idmosquitospecies', 'LEFT' );
		$this->db->join ( 'genuses AS g', 'mosquitospecies.idgenus = g.idgenus', 'INNER' );
		$this->db->where ( 'larvalsurveillancedetails.idlarvalsurveillance', $Id );
		$this->db->order_by ( 'g.genus' );
		$this->db->order_by ( 'mosquitospecies.mosquitospecies' );
		
		$this->str = '';
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				
				// $this->str .= '<option value="'.$row['idmosquitospecies'].' " selected="true">'.$row['mosquitospecies'].'</option>';
				$sel_species [] = $row;
			}
		}
		// die;
		return $sel_species;
	}
	
	/**
	 * Function to fetch Species Count
	 */
	public function getExistingSpecies($Id) {
		$this->db->select ( 'idmosquitospecies,count' );
		$this->db->from ( 'larvalsurveillancedetails' );
		$this->db->where ( 'idlarvalsurveillance', $Id );
		
		$query = $this->db->get ();
		$result = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$result [$row ['idmosquitospecies']] = $row ['count'];
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to fetch history Count
	 */
	public function getHistory($Id) {
		if (empty ( $Id ))
			return false;
		$where = "larvalsurveillance.idtrap = $Id";
		$this->db->select ( '`traps`.`trap` AS `traps_trap`, 
				`traptypes`.`traptype` AS `traps_idtraptype`, 
				`larvalsurveillance`.`pudate` AS `pudate`, 
				`larvalsurveillance`.`putime` AS `putime`,
				larvalsurveillancedetails.idlarvalsurveillance,
				m.idmosquitospecies,
				m.mosquitospecies,
				larvalsurveillancedetails.count,(larvalsurveillancedetails.count*100/(SELECT sum(`larvalsurveillancedetails`.`count`) 
				FROM `larvalsurveillancedetails` 
				WHERE `larvalsurveillancedetails`.`idlarvalsurveillance` = `larvalsurveillance`.`idlarvalsurveillance`)) AS count_percent' );
		$this->db->from ( 'larvalsurveillance' );
		$this->db->join ( 'traps', 'larvalsurveillance.idtrap = traps.idtrap', 'LEFT' );
		$this->db->join ( 'traptypes', 'traps.idtraptype = traptypes.idtraptype', 'LEFT' );
		$this->db->join ( 'larvalsurveillancedetails', 'larvalsurveillance.idlarvalsurveillance = larvalsurveillancedetails.idlarvalsurveillance', 'LEFT' );
		$this->db->join ( 'mosquitospecies AS m', 'larvalsurveillancedetails.idmosquitospecies = m.idmosquitospecies', 'LEFT' );
		// $this->db->where($where);
		// $this->db->group_by("`larvalsurveillancedetails`.`idlarvalsurveillance`");
		
		$this->db->join ( 'sites AS s', "larvalsurveillance.idsite = s.idsite", 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$this->db->order_by ( "larvalsurveillancedetails.idlarvalsurveillance", "ASC" );
		// $this->db->order_by("larvalsurveillance.pudate","ASC");
		$data_1 = array ();
		
		$query = $this->db->get ();
		// echo $this->db->last_query();
		// die;
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
		
		return false;
	}
	
	/**
	 * Function to fetch Species Count
	 */
	public function getSpeciesCount($Id) {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( 'm.idmosquitospecies,
				m.mosquitospecies,ad.count' );
		$this->db->from ( 'mosquitospecies AS m' );
		$this->db->join ( 'larvalsurveillancedetails AS ld', 'm.idmosquitospecies = ld.idmosquitospecies', "LEFT" );
		$this->db->where ( 'ld.idlarvalsurveillance', $Id );
		
		$query = $this->db->get ();
		$result = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$result [$row ['idmosquitospecies']] [] = $row ['mosquitospecies'];
				$result [$row ['idmosquitospecies']] [] = $row ['count'];
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to fetch Species Count
	 */
	public function getSpeciesCountbydate($Id) {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( 'm.idmosquitospecies,
				m.mosquitospecies,
				ad.count' );
		$this->db->from ( 'mosquitospecies AS m' );
		$this->db->join ( 'larvalsurveillancedetails AS ld', 'm.idmosquitospecies = ld.idmosquitospecies', "LEFT" );
		$this->db->where ( 'ld.idlarvalsurveillance', $Id );
		
		$query = $this->db->get ();
		$result = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$result [$row ['idmosquitospecies']] [] = $row ['mosquitospecies'];
				$result [$row ['idmosquitospecies']] [] = $row ['count'];
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to fetch Site Type
	 */
	public function getSitetype() {
		$this->db->select ( 'idsitetype,
				sitetype' );
		$this->db->order_by ( 'sitetype' );
		$this->db->from ( 'sitetypes' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['idsitetype'] . '">' . $row ['sitetype'] . '</option>';
			}
		}
		return $this->str;
	}
	/**
	 * Function to fetch get Zone name
	 */
	public function getZonename() {
		$this->db->select ( 'idzone,
				zone' );
		$this->db->order_by ( 'zone' );
		$this->db->from ( 'zones' );
		$this->db->where ( 'active', '1' );
		$this->db->where ( 'isdeleted', '0' );
		$this->db->where ( 'zones.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['idzone'] . '">' . $row ['zone'] . '</option>';
			}
		}
		return $this->str;
	}
	/**
	 * Function to fetch selected Zone name
	 */
	public function getSelectedZonename($Id = '') {
		// echo $Id;
		// die;
		$this->db->select ( 'idzone,
				zone' );
		$this->db->order_by ( 'zone' );
		$this->db->from ( 'zones' );
		$this->db->where ( 'zones.active', '1' );
		$this->db->where ( 'zones.isdeleted', '0' );
		$this->db->where ( 'zones.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->str = "";
		$query = $this->db->get ();
		
		// echo "<pre>";
		// print_r($query -> result_array());
		// die;
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				
				if ($Id == $row ['idzone']) {
					
					$this->str .= '<option value="' . $row ['idzone'] . '" selected="true">' . $row ['zone'] . '</option>';
				} else {
					
					$this->str .= '<option value="' . $row ['idzone'] . '">' . $row ['zone'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	/**
	 * Function to fetch get State name
	 */
	public function getStatename() {
		$this->db->select ( 'states.idstate' );
		$this->db->from ( 'states' );
		$this->db->join ( 'locations AS lc', "states.idstate = lc.idstate", 'LEFT' );
		$this->db->where ( 'lc.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$idstate = "";
		$q = $this->db->get ();
		if ($q->num_rows () > 0) {
			$idstate = $q->result_array ();
			$idstate = $idstate [0] ['idstate'];
		}
		
		$this->db->select ( 'states.idstate,
				states.statename' );
		$this->db->order_by ( 'statename' );
		$this->db->from ( 'states' );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if (! empty ( $idstate ) && $row ['idstate'] == $idstate)
					$this->str .= '<option value="' . $row ['idstate'] . '" selected="true">' . $row ['statename'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idstate'] . '">' . $row ['statename'] . '</option>';
			}
		}
		return $this->str;
	}
	/**
	 * Function to fetch get State name
	 */
	public function getSelectedStatename($Id = '') {
		$this->db->select ( 'larvalsurveillance.idsite,
				sites.idstate' );
		$this->db->from ( 'larvalsurveillance' );
		$this->db->join ( 'sites', 'larvalsurveillance.idsite=sites.idsite', 'LEFT' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'larvalsurveillance.idlarvalsurveillance', $Id );
		$query = $this->db->get ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$site_id = $row ['idstate'];
			}
		}
		
		$this->db->select ( 'states.idstate,
				states.statename' );
		$this->db->order_by ( 'statename' );
		$this->db->from ( 'states' );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($row ['idstate'] == $site_id) {
					$this->str .= '<option value="' . $row ['idstate'] . '" selected="true">' . $row ['statename'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idstate'] . '">' . $row ['statename'] . '</option>';
				}
			}
		}
		return $this->str;
	}
	/**
	 * Function to fetch get site status
	 */
	public function getSitestatus() {
		$this->db->select ( 'idsitestatus,
				sitestatus' );
		$this->db->order_by ( 'sitestatus' );
		$this->db->from ( 'sitestatuses' );
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$k = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$k] ['sitestatus'] = $row ['sitestatus'];
				$result [$k] ['idsitestatus'] = $row ['idsitestatus'];
				$k ++;
			}
		}
		
		return $result;        
	}
	/**
	 * Function to fetch Seleted site status
	 */
	public function getSelectedSitestatus($Id = '') {
		$this->db->select ( 'idsitestatus,
				sitestatus' );
		$this->db->order_by ( 'sitestatus' );
		$this->db->from ( 'sitestatuses' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idsitestatus']) {
					$this->str .= '<option value="' . $row ['idsitestatus'] . '" selected="true">' . $row ['sitestatus'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idsitestatus'] . '">' . $row ['sitestatus'] . '</option>';
				}
			}
		}
		return $this->str;
	}
	/**
	 * Function to fetch get water Temperature
	 */
	public function getWatertemprange($Id = '') {
		$this->db->select ( 'idwatertemprange,
				watertemprange' );
		$this->db->order_by ( 'idwatertemprange' );
		$this->db->from ( 'watertempranges' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idwatertemprange']) {
					$this->str .= '<option value="' . $row ['idwatertemprange'] . '"  selected="true">' . $row ['watertemprange'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idwatertemprange'] . '">' . $row ['watertemprange'] . '</option>';
				}
			}
		}
		return $this->str;
	}
	
	/**
	 * Function to fetch get instar data
	 */
	public function getInstar($Id = '') {
		$this->db->select ( 'idinstar,
				instar' );
		$this->db->order_by ( 'idinstar' );
		$this->db->from ( 'instar' );
        $result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$k = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$k] ['instar'] = $row ['instar'];
				$result [$k] ['idinstar'] = $row ['idinstar'];
				$k ++;
			}
		}
		
		return $result;
	}
	/**
	 * Function to fetch get Larvae Present
	 */
	public function getLarvaePresent($Id = '') {
		$this->db->select ( 'larvaepresent,
				s.idsite' );
		$this->db->from ( 'larvalsurveillance' );
		
		$this->db->join ( 'sites AS s', "larvalsurveillance.idsite = s.idsite", 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$results = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$results = $row ['larvaepresent'];
			}
		}
		return $results;
	}
	/**
	 * Function to fetch Selected Date
	 */
	public function getSelectedDate($Id = '') {
		$this->db->select ( 'date,
				s.idsite' );
		$this->db->from ( 'larvalsurveillance' );
		
		$this->db->join ( 'sites AS s', "larvalsurveillance.idsite = s.idsite", 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$this->db->where ( 'idlarvalsurveillance', $Id );
		$results = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$results = $row ['date'];
			}
		}
		return $results;
	}
	/**
	 * Function to fetch Selected Time
	 */
	public function getSelectedTime($Id = '') {
		$this->db->select ( 'time,
				s.idsite' );
		$this->db->from ( 'larvalsurveillance' );
		
		$this->db->join ( 'sites AS s', "larvalsurveillance.idsite = s.idsite", 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$this->db->where ( 'idlarvalsurveillance', $Id );
		$results = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$results = $row ['time'];
			}
		}
		return $results;
	}
	/**
	 * Function to listed site details when edit or add
	 */
	public function getSiteNameData($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( '`sites`.*' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'sites.active', '1' );
		$this->db->where ( 'sites.isdeleted', '0' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$this->db->where ( '`sites`.`idsite`', $Id );
		
		$query = $this->db->get ();
		
		$data = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row )
				$data [] = $row;
			
			return $data [0];
		}
		
		return false;
	}
}
