<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Zone_model extends CI_Model {
	
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to Add a new Zone
	 */
	public function addZone($idlocation = '') {
		$idlocation = $this->session->userdata ( 'idlocation' );
		$data ['zone'] = $this->input->post ( 'zone_name' );
		$data ['active'] = '1';
		$data ['squaremileage'] = $this->input->post ( 'mileage' );
		$data ['description'] = $this->input->post ( 'zone_desc' );
		$data ['idlocation'] = ! empty ( $idlocation ) ? $idlocation : 0;

		$this->db->insert ( 'zones', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows )) {
			return false;
		}  // end of if(empty($rows))
else {
			$zonecorddata ['idzone'] = $this->db->insert_id ();
			$zonecord = $this->input->post ( 'zonecord' );
			if (! empty ( $zonecord )) {
				$zonecorddata ['zonecord'] = $zonecord;
			}  // end of if(!empty($zonecord))
else {
				$zonecorddata ['zonecord'] = '0';
			} // end of else of if(!empty($zonecord))
			$this->db->insert ( 'zonecords', $zonecorddata );
			$rows2 = $this->db->affected_rows ();
			if (empty ( $rows2 )) {
				return false;
			} // end of if(empty($rows2))
			return true;
		} // end of else of if(empty($rows))
	}
	
	/**
	 * Function to Update a new Zone
	 */
	public function updateZone($data = '') {
		$idzone = $this->input->post ( 'idzone' );
		
		if (empty ( $idzone ))
			return false;
		
		$idlocation = $this->session->userdata ( 'idlocation' );
		$status = $this->input->post ( 'active' );
		
		$data ['zone'] = $this->input->post ( 'zone_name' );
		$data ['squaremileage'] = $this->input->post ( 'mileage' );
		$data ['description'] = $this->input->post ( 'zone_desc' );
		$data ['active'] = (! empty ( $status ) && $status == "1") ? '1' : '0';
		$data ['idlocation'] = ! empty ( $idlocation ) ? $idlocation : 0;
		
		$this->db->where ( 'idzone', $idzone );
		$this->db->update ( 'zones', $data );
		
		$rows = $this->db->affected_rows ();
		
		$this->db->where ( 'idzone', $idzone );
		$this->db->from ( 'zonecords' );
		if ($this->db->count_all_results () > 0) {
			// update zonecords table
			$zonecord = $this->input->post ( 'zonecord' );
			
			$zonecorddata = array ();
			if (! empty ( $zonecord )) {
				$zonecorddata ['zonecord'] = $zonecord;
				$this->db->where ( 'idzone', $idzone );
				$this->db->update ( 'zonecords', $zonecorddata );
			} else {
				$this->db->query ( "SET foreign_key_checks = 0" );
				$this->db->where ( 'idzone', $idzone );
				$this->db->delete ( 'zonecords' );
				$this->db->query ( "SET foreign_key_checks = 1" );
			}
		} else {
			// insert in zonecords table
			$zonecorddata ['idzone'] = $idzone;
			$zonecord = $this->input->post ( 'zonecord' );
			if (! empty ( $zonecord )) {
				$zonecorddata ['zonecord'] = $zonecord;
				$this->db->insert ( 'zonecords', $zonecorddata );
			}
		}
		
		return true;
	}
	
	/**
	 * Function to list all Zones
	 */
	public function deleteZone() {
		$idzone = $this->input->get_post ( 'id' );
		if (empty ( $idzone ))
			return false;
		
		$data ['isdeleted'] = '1';
		$this->db->where ( 'idzone', $idzone );
		$this->db->update ( 'zones', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to check for the existence of zone
	 */
	public function zoneExist($str = '') {
		if (empty ( $str ))
			return false;
		
		$this->db->select ( '*' );
		$this->db->from ( 'zones' );
		$this->db->where ( 'zone', $str );
		$this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0)
			return true;
		
		return false;
	}
	
	/**
	 * Function to fetch Statuses of Zones
	 */
	public function getStatuses() {
		$this->db->select ( 'idzone,
				active' );
		$this->db->from ( 'zones' );
		
		$this->db->join ( 'locations AS lc', "zones.idlocation = lc.idlocation", 'LEFT' );
		$this->db->where ( 'lc.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$k = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$k] ['status'] = $row ['active'];
				$result [$k] ['idzone'] = $row ['idzone'];
				$k ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to activate Zones
	 */
	public function activeZone() {
		$idzone = $this->input->get_post ( 'id' );
		
		if (empty ( $idzone ))
			return false;
		
		$data ['active'] = '1';
		
		$this->db->where ( 'idzone', $idzone );
		$this->db->update ( 'zones', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to deactivate Zones
	 */
	public function deactiveZone() {
		$idzone = $this->input->get_post ( 'id' );
		
		if (empty ( $idzone ))
			return false;
		
		$data ['active'] = '0';
		
		$this->db->where ( 'idzone', $idzone );
		$this->db->update ( 'zones', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to list all Zones mail
	 */
	public function getZoneData($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( '*' );
		$this->db->from ( 'zones' );
		$this->db->where ( 'idzone', $Id );
		$this->db->where ( 'zones.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$query = $this->db->get ();
		
		$data = array ();
		if ($query->num_rows () > 0) {
			$data = $query->result_array ();
			$data = $data [0];
		}
		
		return $data;
	}
	
	/**
	 * Function to list Zone Coordinates
	 */
	public function getZoneCords($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( '*' );
		$this->db->from ( 'zonecords' );
		$this->db->where ( 'idzone', $Id );
		
		$query = $this->db->get ();
		
		$data = array ();
		if ($query->num_rows () > 0) {
			$data = $query->result_array ();
			$data = $data [0];
		}
		return $data;
	} // end of public function getZoneCords($Id = '')
	
	/**
	 * Function to list all Zones mail
	 */
	public function listZones() {
		$this->db->select ( '*' );
		$this->db->from ( 'zones AS z' );
		$this->db->where ( 'z.active', '1' );
		$this->db->where ( 'z.isdeleted', '0' );
		$this->db->where ( 'z.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$ttl = $this->input->get ( 'ttl' );
		$page = $this->input->get ( 'page' );
		$orderby = $this->input->get ( 'orderby' );
		
		if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
			switch ($orderby) {
				case '0:asc' :
					$this->db->order_by ( 'z.zone', 'ASC' );
					break;
				case '0:desc' :
					$this->db->order_by ( 'z.zone', 'DESC' );
					break;
				case '1:asc' :
					$this->db->order_by ( 'z.description', 'ASC' );
					break;
				case '1:desc' :
					$this->db->order_by ( 'z.description', 'DESC' );
					break;
				case '2:asc' :
					$this->db->order_by ( 'z.active', 'ASC' );
					break;
				case '2:desc' :
					$this->db->order_by ( 'z.active', 'DESC' );
					break;
			}
		} else {
			$this->db->order_by ( 'z.zone', 'ASC' );
		}
		
		// if(!isset($ttl) || $ttl == '')
		// $ttl = 10;
		//
		// if(!isset($page) || $page == '')
		// $page = 1;
		//
		// if(!is_null($ttl) && !is_null($page))
		// {
		// if($page == 1)
		// $page = 0;
		// else
		// $page--;
		//
		// $page *= 10;
		// $this->db->limit($ttl ,$page);
		// }
		// else if(!is_null($ttl))
		// {
		// $this->db->limit($ttl);
		// }
		$data_1 = array ();
		$query = $this->db->get ();
		// echo $this->db->last_query()."<br>";
		// die;
		$result = array ();
		// print'<pre>';
		// print_r($query->result_array());
		// die;
		if ($query->num_rows () > 0)
			return $query->result_array ();
	}
	
	/**
	 * Function to fetch the zone coords
	 * from zonecords table for displaying the
	 * zone boundary
	 */
	public function getZoneCord() {
		$this->db->select ( '*' );
		$this->db->from ( 'zonecords AS zc' );
		$this->db->join ( 'zones AS z', 'zc.idzone=z.idzone', 'inner' );
		$this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'z.isdeleted', '0' );
		$this->db->where ( 'z.active', '1' );
		$zonecoords = array ();
		$q = $this->db->get ();
		if ($q->num_rows ()) {
			foreach ( $q->result_array () as $k => $v ) {
				$zonecoords [] = $v ['zonecord'];
			}
		}
		return $zonecoords;
	}
}
