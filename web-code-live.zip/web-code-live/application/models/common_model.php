<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );

//ini_set('error_reporting', E_ALL);
//ini_set('display_errors',1);
class Common_model extends CI_Model {
    /**
	 * Constructor for the class
	 * User
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
    /**
	 * This function sets the order by  string for sql query as per the 
     * carbogrid library
	 */
    public function getOrderBy($orderby) {
        $ord = array();
        if(empty($orderby))
            return $ord;
            
        $orderby = explode('_', $orderby);
        foreach ($orderby as $o)
        {
            $o = explode(':', $o);
            if (!isset($o[1]) OR (strtolower($o[1]) != 'desc'))
            {
                $ord[$o[0]] = 'ASC';
            }
            else
            {
                $ord[$o[0]] = 'DESC';
            }
        }
        return $ord;
    }
}

?>