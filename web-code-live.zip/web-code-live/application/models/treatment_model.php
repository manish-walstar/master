<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );

date_default_timezone_set ( 'UTC' );
class Treatment_model extends CI_Model {
	public $data = array ();
	public $str = "";
	public $set_pwd = "";
	
	/**
	 * Constructor for the class
	 * User
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to Add a new Larva Treatment
	 */
	public function addLarvalTreatment($req = '') {
		
		$species_new = $this->input->post ( 'species_val' );
		$s_count = $this->input->post ( 'species_countval' );
		
        $site_id = '';
		$site_id = $this->input->post ( 'site' );
		$data_site ['site'] = $this->input->post ( 'idsite' );
		$data_site ['idsitetype'] = $this->input->post ( 'idsitetype' );
		$data_site ['maplabel'] = $this->input->post ( 'maplabel' );
		$data_site ['address1'] = $this->input->post ( 'address1' );
		$data_site ['address2'] = $this->input->post ( 'address2' );
		$data_site ['city'] = $this->input->post ( 'city' );
		$data_site ['idstate'] = $this->input->post ( 'idstate' );
		$data_site ['postalcode'] = $this->input->post ( 'postalcode' );
		$data_site ['latitude'] = $this->input->post ( 'latitude' );
		$data_site ['longitude'] = $this->input->post ( 'longitude' );
		$data_site ['pdop'] = $this->input->post ( 'pdop' );
		// if add new site value is -1
		if ($site_id == '0') {
			$this->db->query ( "SET foreign_key_checks = 0" );
			$this->db->insert ( 'sites', $data_site );
			$row_site = $this->db->affected_rows ();
			if (empty ( $row_site ))
				return false;
			$site_id = $this->db->insert_id ();
			$this->db->query ( "SET foreign_key_checks = 1" );
		}
		
		/**
		 * end insert data into sites table*
		 */
		$idsite = $site_id;
		$idloc = $this->session->userdata ( 'idlocation' );
		$idsitetype = $this->input->post ( 'idsitetype' );
		$idzone = $this->input->post ( 'idzone' );
		$idstate = $this->input->post ( 'idstate' );
		$id = "";
		$sourcereduction = $this->input->post ( 'sourcereduction' );
		$idsitestatus = $this->input->post ( 'idsitestatus' );
		$idweatherconditions = $this->input->post ( 'idweatherconditions' );
		$idwatertemprange = $this->input->post ( 'idwatertemp' );
		$larvaepresent = $this->input->post ( 'larvaepresent' );
		$totalcount = $this->input->post ( 'totalcount' );
		$idinstar = $this->input->post ( 'idinstar' );
		$idapplicator = $this->input->post ( 'idapplicator' );
		$idapplicationmethod = $this->input->post ( 'idapplicationmethod' );
        $idwindspeed = $this->input->post ( 'idwindspeed' );
		$idwinddirection = $this->input->post ( 'idwinddirection' );
		$idproduct = $this->input->post ( 'idproduct' );
		$idformulation = $this->input->post ( 'idformulation' );
		$idapplicationratetype = $this->input->post ( 'idapplicationratetype' );
		$idproductpreferences = $this->input->post ( 'idproductpreferences' );
		$idapplicationrateuom = $this->input->post ( 'idapplicationrateuom' );
		$idmixratio = $this->input->post ( 'idmixratio' );
		$iduomfinishedmix = $this->input->post ( 'iduomfinishedmix' );
		$iduomtotalproductapplied = $this->input->post ( 'iduomtotalproductapplied' );
		$iduomtotalareatreated = $this->input->post ( 'iduomtotalareatreated' );
		$post_trtmnt_inspection = $this->input->post ( 'post_trtmnt_inspection' );
		$post_trtmnt_date = $this->input->post ( 'post_trtmnt_date' );
		$iswaterofus = $this->input->post ( 'iswaterofus' );
		$date = $this->input->post ( 'date' );
		$time = $this->input->post ( 'time' );
		
		$this->load->model('usermodel');
		$data ['userId'] = $this->usermodel->getUserId();

		$data ['date'] = ! empty ( $date ) ? date ( 'Y-m-d', strtotime ( $date ) ) : '';
		$data ['time'] = ! empty ( $time ) ? date ( 'h:i:s A', strtotime ( $time ) ) : '';
		$data ['timestamp'] = strtotime ( $data ['date'] . ' ' . $data ['time'] );
		$data ['idsite'] = (! empty ( $idsite )) ? $idsite : 0;
		$data ['idsitetype'] = (! empty ( $idsitetype )) ? $idsitetype : 0;
		$data ['idzone'] = (! empty ( $idzone )) ? $idzone : 0;
		$data ['latitude'] = $this->input->post ( 'latitude' );
		$data ['longitude'] = $this->input->post ( 'longitude' );
		$data ['idsitestatus'] = (! empty ( $idsitestatus )) ? $idsitestatus : 0;
		$data ['idweatherconditions'] = (! empty ( $idweatherconditions )) ? $idweatherconditions : 0;
		$data ['idwatertemp'] = (! empty ( $idwatertemprange )) ? $idwatertemprange : 0;
		$data ['idlarvaelcountrange'] = (! empty ( $idlarvaecountrange )) ? $idlarvaecountrange : 0;
		$data ['idinstar'] = (! empty ( $idinstar )) ? $idinstar : 0;
		$data ['idapplicator'] = (! empty ( $idapplicator )) ? $idapplicator : 0;
		$data ['idapplicationmethod'] = (! empty ( $idapplicationmethod )) ? $idapplicationmethod : 0;
        $data ['idwindspeed'] = (! empty ( $idwindspeed )) ? $idwindspeed : 0;
		$data ['idwinddirection'] = (! empty ( $idwinddirection )) ? $idwinddirection : 0;
		$data ['idproduct'] = (! empty ( $idproduct )) ? $idproduct : 0;
		$data ['idformulation'] = (! empty ( $idformulation )) ? $idformulation : 0;
		$data ['idapplicationrateuom'] = (! empty ( $idapplicationrateuom )) ? $idapplicationrateuom : 0;
		$data ['idapplicationratetype'] = (! empty ( $idapplicationratetype )) ? $idapplicationratetype : 0;
		$data ['idproductpreferences'] = (! empty ( $idproductpreferences )) ? $idproductpreferences : 0;
		$data ['idmixratio'] = (! empty ( $idmixratio )) ? $idmixratio : 0;
		$data ['iduomfinishedmix'] = (! empty ( $iduomfinishedmix )) ? $iduomfinishedmix : 0;
		$data ['iduomtotalproductapplied'] = (! empty ( $iduomtotalproductapplied )) ? $iduomtotalproductapplied : 0;
		$data ['iduomtotalareatreated'] = (! empty ( $iduomtotalareatreated )) ? $iduomtotalareatreated : 0;
		$data ['equipemtnid'] = $this->input->post ( 'equipemtnid' );
		$data ['sourcereduction'] = (! empty ( $sourcereduction ) && $sourcereduction == "on") ? "1" : "0";
		$data ['sourcereductioncomments'] = $this->input->post ( 'sourcereductioncomments' );
		$data ['applicationrate'] = $this->input->post ( 'applicationrate' );
		$data ['finishedmix'] = $this->input->post ( 'finishedmix' );
		$data ['totalproductapplied'] = $this->input->post ( 'totalproductapplied' );
		$data ['totalareatreated'] = $this->input->post ( 'totalareatreated' );
		$data ['comments'] = $this->input->post ( 'comments' );
		$data ['iswaterofus'] = (! empty ( $iswaterofus ) && $iswaterofus == "on") ? '1' : '0';
		$data ['trtmnt_justification'] = $this->input->post ( 'trtmnt_justification' );
		$data ['totalcount'] = $totalcount;
		$data ['larvaepresent'] = $larvaepresent;
		$data ['idmonitor'] = $this->input->post ( 'monitor_key' );
		$data ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
		
		if (! empty ( $data ['idmonitor'] )) {
			$mdata ['status'] = '1';
			$this->db->where ( 'idmonitor', $data ['idmonitor'] );
			$this->db->update ( 'monitormgmt', $mdata );
			
			$userid = $this->session->userdata ( 'id' );
			$userid = json_decode ( base64_decode ( $userid ) );
			
			$userid_arr = explode ( "_", $userid );
			
			$userid = json_decode ( base64_decode ( $userid_arr [0] ) );
			
			$mdata = array ();
			$mdata ['user_id'] = $userid;
			$mdata ['idmonitor'] = $data ['idmonitor'];
			
			$this->db->insert ( 'user_monitor', $mdata );
		}
		
		$species = $this->input->post ( 'idmosquitospecies' );
		
		if (! empty ( $post_trtmnt_inspection ) && $post_trtmnt_inspection == "on") {
			$data ['post_trtmnt_inspection'] = '1';
			$data ['post_trtmnt_date'] = date ( 'Y-m-d', strtotime ( $post_trtmnt_date ) );
		} else {
			$data ['post_trtmnt_inspection'] = '0';
			$data ['post_trtmnt_date'] = "";
		}
		
		// print'<pre>';
		// print_r($_POST);
		// print_r($data);
		// die;
		// modified by sonu
		if (! empty ( $req ) && $req > 0) {
			$this->db->select ( '*' );
			$this->db->from ( 'larvaltreatments' );
			$this->db->where ( 'idlarvaltreatment', $req );
			
			$q = $this->db->get ();
			
			if ($q->num_rows () > 0) {
				$this->db->query ( "SET foreign_key_checks = 0" );
				$this->db->where ( 'idlarvaltreatment', $req );
				$this->db->update ( 'larvaltreatments', $data );
				$this->db->query ( "SET foreign_key_checks = 1" );
			}
			
			$this->db->select ( '*' );
			$this->db->from ( 'larvatreatmentdetails' );
			$this->db->where ( 'idlarvaltreatment', $req );
			
			$q = $this->db->get ();
			if ($q->num_rows () > 0) {
				$this->db->where ( 'idlarvaltreatment', $req );
				$this->db->delete ( 'larvatreatmentdetails' );
			}
			
			for($i = 0; $i < count ( $species_new ); $i ++) {
				$data_species = array ();
				$data_species ['idlarvaltreatment'] = $req;
				$data_species ['idmosquitospecies'] = ! empty ( $species_new [$i] ) ? $species_new [$i] : 0;
				$data_species ['count'] = ! empty ( $s_count [$i] ) ? $s_count [$i] : 0;
				$this->db->query ( 'SET foreign_key_checks = 0' );
				$this->db->insert ( 'larvatreatmentdetails', $data_species );
				$this->db->query ( 'SET foreign_key_checks = 1' );
			}
		} else {
			$this->db->query ( "SET foreign_key_checks = 0" );
			$this->db->insert ( 'larvaltreatments', $data );
			$id = $this->db->insert_id ();
			$this->db->query ( "SET foreign_key_checks = 1" );
			
			if (isset ( $species_new ) && ! empty ( $species_new ) && is_array ( $species_new )) {
				for($i = 0; $i < count ( $species_new ); $i ++) {
					$data_species = array ();
					
					$data_species ['idlarvaltreatment'] = $id;
					$data_species ['idmosquitospecies'] = ! empty ( $species_new [$i] ) ? $species_new [$i] : 0;
					$data_species ['count'] = ! empty ( $s_count [$i] ) ? $s_count [$i] : 0;
					$this->db->query ( 'SET foreign_key_checks = 0' );
					$this->db->insert ( 'larvatreatmentdetails', $data_species );
					$this->db->query ( 'SET foreign_key_checks = 1' );
				}
			}
			
			// for service request
			$service_req_id = $this->input->get_post ( 'service_req_id' );
			if (! empty ( $service_req_id )) {
				$data_common ['idlarvaltreatment'] = $id;
				$data_common ['idservicerequest'] = $service_req_id;
				$data_common ['idlocation'] = $idloc;
				$this->db->insert ( 'larvaltreatmentservice', $data_common );
			}
			// for larval surveilance
			$adult_key = $this->input->get_post ( 'adult_key' );
			if (! empty ( $adult_key )) {
				$data_common ['idlarvaltreatment'] = $id;
				$data_common ['idlarval'] = $adult_key;
				$data_common ['idlocation'] = $idloc;
				$this->db->insert ( 'larvaltreatmentlarval', $data_common );
			}
		}
		
		// end here
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ) && empty ( $id ) && empty ( $req ))
			return false;
		
		if (empty ( $id ) && ! empty ( $req ))
			$id = $req;
		
		return $id;
	}
	
	/**
	 * Function to fetch Larva Count
	 */
	public function getLarvaecount($Id = '') {
		$this->db->select ( 'totalcount' );
		$this->db->from ( 'larvaltreatments' );
		$this->db->where ( 'idlarvaltreatment', $Id );
		$this->str = "";
		$query = $this->db->get ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str = $row ['totalcount'];
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to Add a new Adult Treatment
	 */
	public function addAdultTreatment($req = '') {
		$id = "";
		$site_id = '';
		$idloc = $this->session->userdata ( 'idlocation' );
		$site_id = $this->input->post ( 'site' );
		$data_site ['site'] = $this->input->post ( 'idsite' );
		$data_site ['idsitetype'] = $this->input->post ( 'idsitetype' );
		$data_site ['maplabel'] = $this->input->post ( 'maplabel' );
		$data_site ['address1'] = $this->input->post ( 'address1' );
		$data_site ['address2'] = $this->input->post ( 'address2' );
		$data_site ['city'] = $this->input->post ( 'city' );
		$data_site ['idstate'] = $this->input->post ( 'idstate' );
		$data_site ['postalcode'] = $this->input->post ( 'postalcode' );
		$data_site ['latitude'] = $this->input->post ( 'latitude' );
		$data_site ['longitude'] = $this->input->post ( 'longitude' );
		$data_site ['pdop'] = $this->input->post ( 'pdop' );
		// if add new site value is -1
		if ($site_id == '0') {
			$this->db->query ( "SET foreign_key_checks = 0" );
			$this->db->insert ( 'sites', $data_site );
			$row_site = $this->db->affected_rows ();
			if (empty ( $row_site ))
				return false;
			$site_id = $this->db->insert_id ();
			$this->db->query ( "SET foreign_key_checks = 1" );
		}
		
		/**
		 * end insert data into sites table*
		 */
		
		$idsite = $site_id;
		$idsitetype = $this->input->post ( 'idsitetype' );
		$idzone = $this->input->post ( 'idzone' );
		$idstate = $this->input->post ( 'idstate' );
		$idsystemtype = $this->input->post ( 'idsystemtype' );
		$idapplicationmethod = $this->input->post ( 'idapplicationmethod' );
		$idapplicator = $this->input->post ( 'idapplicator' );
		$idtempatstart = $this->input->post ( 'idtempatstart' );
		$tempatthreem = $this->input->post ( 'tempatthreem' );
		$idtempatend = $this->input->post ( 'idtempatend' );
		$tempattenm = $this->input->post ( 'tempattenm' );
		$idhumidityrange = $this->input->post ( 'idhumidityrange' );
		$idwindspeed = $this->input->post ( 'idwindspeed' );
		$idwinddirection = $this->input->post ( 'idwinddirection' );
		$idcloudcoverage = $this->input->post ( 'idcloudcoverage' );
		$idproduct = $this->input->post ( 'idproduct' );
		$idformulation = $this->input->post ( 'idformulation' );
		$idmixratio = $this->input->post ( 'idmixratio' );
		$iddilutent = $this->input->post ( 'iddilutent' );
		$iduomfinishedmix = $this->input->post ( 'iduomfinishedmix' );
		$idapplicationratetype = $this->input->post ( 'idapplicationratetype' );
		$idproductpreferences = $this->input->post ( 'idproductpreferences' );
		$idapplicationrateuom = $this->input->post ( 'idapplicationrateuom' );
		$idflowratetypes = $this->input->post ( 'idflowratetypes' );
		$iduomtotalproductapplied = $this->input->post ( 'iduomtotalproductapplied' );
		$iduomtotalareatreated = $this->input->post ( 'iduomtotalareatreated' );
		$iswaterofus = $this->input->post ( 'iswaterofus' );
		$date = $this->input->post ( 'date' );
		$time = $this->input->post ( 'time' );
		$date_arr = explode ( "/", $date );
		$date = $date_arr [2] . "-" . $date_arr [0] . "-" . $date_arr [1];
		
		$this->load->model('usermodel');
		$data ['userId'] = $this->usermodel->getUserId();
		
		$data ['date'] = ! empty ( $date ) ? $date : date ( 'Y-m-d' );
		$data ['time'] = ! empty ( $time ) ? date ( 'h:i:s A', strtotime ( $time ) ) : '';
		$data ['timestamp'] = strtotime ( $data ['date'] . ' ' . $data ['time'] );
		$data ['idsite'] = (! empty ( $idsite )) ? $idsite : 0;
		$data ['idsitetype'] = (! empty ( $idsitetype )) ? $idsitetype : 0;
		$data ['idzone'] = (! empty ( $idzone )) ? $idzone : 0;
		$data ['latitude'] = $this->input->post ( 'latitude' );
		$data ['longitude'] = $this->input->post ( 'longitude' );
		$data ['idsystemtype'] = (! empty ( $idsystemtype )) ? $idsystemtype : 0;
		$data ['idapplicationmethod'] = (! empty ( $idapplicationmethod )) ? $idapplicationmethod : 0;
		$data ['equipmentserial'] = $this->input->post ( 'equipmentserial' );
		$data ['odometerstart'] = $this->input->post ( 'odometerstart' );
		$data ['odometerend'] = $this->input->post ( 'odometerend' );
		$applicationstartdate = $this->input->post ( 'applicationstartdate' );
		$applicationenddate = $this->input->post ( 'applicationenddate' );
		
		$data ['idapplicator'] = (! empty ( $idapplicator )) ? $idapplicator : 0;
		$data ['applicationstartdate'] = ! empty ( $applicationstartdate ) ? date ( 'Y-m-d', strtotime ( $applicationstartdate ) ) : '';
		$data ['applicationstarttime'] = $this->input->post ( 'applicationstarttime' );
		$data ['applicationenddate'] = ! empty ( $applicationenddate ) ? date ( 'Y-m-d', strtotime ( $applicationenddate ) ) : '';
		$data ['applicationendtime'] = $this->input->post ( 'applicationendtime' );
		$data ['idtempatstart'] = (! empty ( $idtempatstart )) ? $idtempatstart : 0;
		$data ['tempatthreem'] = (! empty ( $tempatthreem )) ? round ( $tempatthreem, 2 ) : 0;
		$data ['idtempatend'] = (! empty ( $idtempatend )) ? $idtempatend : 0;
		$data ['tempattenm'] = (! empty ( $tempattenm )) ? round ( $tempattenm, 2 ) : 0;
		$data ['idhumidityrange'] = (! empty ( $idhumidityrange )) ? $idhumidityrange : 0;
		$data ['idwindspeed'] = (! empty ( $idwindspeed )) ? $idwindspeed : 0;
		$data ['idwinddirection'] = (! empty ( $idwinddirection )) ? $idwinddirection : 0;
		$data ['idcloudcover'] = (! empty ( $idcloudcoverage )) ? $idcloudcoverage : 0;
		$data ['idproduct'] = (! empty ( $idproduct )) ? $idproduct : 0;
		$data ['idformulation'] = (! empty ( $idformulation )) ? $idformulation : 0;
		$data ['idmixratio'] = (! empty ( $idmixratio )) ? $idmixratio : 0;
		$data ['iddilutent'] = (! empty ( $iddilutent )) ? $iddilutent : 0;
		$data ['finishedmix'] = $this->input->post ( 'finishedmix' );
		$data ['iduomfinishedmix'] = (! empty ( $iduomfinishedmix )) ? $iduomfinishedmix : 0;
		$data ['idapplicationratetype'] = (! empty ( $idapplicationratetype )) ? $idapplicationratetype : 0;
		$data ['idproductpreferences'] = (! empty ( $idproductpreferences )) ? $idproductpreferences : 0;
		$data ['applicationrate'] = $this->input->post ( 'applicationrate' );
		$data ['idapplicationrateuom'] = (! empty ( $idapplicationrateuom )) ? $idapplicationrateuom : 0;
		$data ['flowrate'] = $this->input->post ( 'flowrate' );
		$data ['idflowratetypes'] = (! empty ( $idflowratetypes )) ? $idflowratetypes : 0;
		$data ['totalproductapplied'] = $this->input->post ( 'totalproductapplied' );
		$data ['iduomtotalproductapplied'] = (! empty ( $iduomtotalproductapplied )) ? $iduomtotalproductapplied : 0;
		$data ['totalareatreated'] = $this->input->post ( 'totalareatreated' );
		$data ['iduomtotalareatreated'] = (! empty ( $iduomtotalareatreated )) ? $iduomtotalareatreated : 0;
		$data ['comments'] = $this->input->post ( 'comments' );
		$data ['iswaterofus'] = (! empty ( $iswaterofus ) && $iswaterofus == "on") ? '1' : '0';
		$data ['trtmnt_justification'] = $this->input->post ( 'trtmnt_justification' );
		$data ['idmonitor'] = $this->input->post ( 'monitor_id' );
		$data ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
		// print'<pre>';
		
		// print_r($data);
		// die;
		
		if (! empty ( $data ['idmonitor'] )) {
			$mdata ['status'] = '1';
			$this->db->where ( 'idmonitor', $data ['idmonitor'] );
			$this->db->update ( 'monitormgmt', $mdata );
			
			$userid = $this->session->userdata ( 'id' );
			$userid = json_decode ( base64_decode ( $userid ) );
			
			$userid_arr = explode ( "_", $userid );
			
			$userid = json_decode ( base64_decode ( $userid_arr [0] ) );
			
			$mdata = array ();
			$mdata ['user_id'] = $userid;
			$mdata ['idmonitor'] = $data ['idmonitor'];
			
			$this->db->insert ( 'user_monitor', $mdata );
		}
		
		if (! empty ( $req ) && $req > 0) {
			$this->db->select ( '*' );
			$this->db->from ( 'adulticidetreatments' );
			$this->db->where ( 'idadulticidetreatment', $req );
			
			$q = $this->db->get ();
			
			if ($q->num_rows () > 0) {
				$this->db->query ( "SET foreign_key_checks = 0" );
				$this->db->where ( 'idadulticidetreatment', $req );
				$this->db->update ( 'adulticidetreatments', $data );
				$this->db->query ( "SET foreign_key_checks = 1" );
			}
		} else {
			$this->db->query ( "SET foreign_key_checks = 0" );
			$this->db->insert ( 'adulticidetreatments', $data );
			$id = $this->db->insert_id ();
			$this->db->query ( "SET foreign_key_checks = 1" );
			
			$service_req_id = $this->input->get_post ( 'service_req_id' );
			if (! empty ( $service_req_id )) {
				$data_common ['idadulticidetreatment'] = $id;
				$data_common ['idservicerequest'] = $service_req_id;
				$data_common ['idlocation'] = $idloc;
				$this->db->insert ( 'adulticidetreatmentsservice', $data_common );
			}
			
			$adult_key = $this->input->get_post ( 'adult_key' );
			if (! empty ( $adult_key )) {
				$data_common ['idadulticidetreatment'] = $id;
				$data_common ['idlarval'] = $adult_key;
				$this->db->insert ( 'adulticidetreatmentslarval', $data_common );
			}
		}
		// print'<pre>';
		
		// print_r($data);
		// die;
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ) && empty ( $id ) && empty ( $req ))
			return false;
		
		if (empty ( $id ) && ! empty ( $req ))
			$id = $req;
		// print'<pre>';
		
		// print_r($rows);
		// die;
		return $id;
	}
	
	/**
	 * Function to delete Larval Treatment
	 */
	public function deleteLarvalTreatment($id = '') {
		if (empty ( $id ))
			return null;
			
			/*
		 * $this->db->select('*');
		 * $this->db->from('larvaltreatments');
		 * $this->db->where('idlarvaltreatment',$id);
		 *
		 * $q = $this->db->get();
		 *
		 * if($q->num_rows() > 0)
		 * {
		 * $this->db->query("SET foreign_key_checks = 0");
		 * $this->db->where('idlarvaltreatment',$id);
		 * $this->db->delete('larvaltreatments');
		 * $this->db->query("SET foreign_key_checks = 1");
		 *
		 * // delete records from larvaltreatments service
		 * $this->db->select('*');
		 * $this->db->from('larvaltreatmentservice');
		 * $this->db->where('idlarvaltreatment',$id);
		 * $p = $this->db->get();
		 * if($p->num_rows() > 0)
		 * {
		 * $this->db->query("SET foreign_key_checks = 0");
		 * $this->db->where('idlarvaltreatment',$id);
		 * $this->db->delete('larvaltreatmentservice');
		 * $this->db->query("SET foreign_key_checks = 1");
		 * }
		 * }
		 *
		 * $this->db->select('*');
		 * $this->db->from('larvatreatmentdetails');
		 * $this->db->where('idlarvaltreatment',$id);
		 *
		 * $q = $this->db->get();
		 * if($q->num_rows() > 0)
		 * {
		 * $this->db->where('idlarvaltreatment',$id);
		 * $this->db->delete('larvatreatmentdetails');
		 * }
		 *
		 */
		
		$data ['isDeleted'] = '1';
		$this->db->where ( 'idlarvaltreatment', $id );
		$this->db->update ( 'larvaltreatments', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ) && empty ( $id ))
			return false;
		
		return $id;
	}
	
	/**
	 * Function to delete Adult Treatment
	 */
	public function deleteAdultTreatment($id = '') {
		if (empty ( $id ))
			return null;
			
			/*
		 * $this->db->select('*');
		 * $this->db->from('adulticidetreatments');
		 * $this->db->where('ilarvaltreatmentsdadulticidetreatment',$id);
		 *
		 * $q = $this->db->get();
		 *
		 * if($q->num_rows() > 0)
		 * {
		 * $this->db->query("SET foreign_key_checks = 0");
		 * $this->db->where('idadulticidetreatment',$id);
		 * $this->db->delete('adulticidetreatments');
		 * $this->db->query("SET foreign_key_checks = 1");
		 *
		 * // delete records from adulticidetreatment service
		 * $this->db->select('*');
		 * $this->db->from('adulticidetreatmentsservice');
		 * $this->db->where('idadulticidetreatment',$id);
		 * $p = $this->db->get();
		 * if($p->num_rows() > 0)
		 * {
		 * $this->db->query("SET foreign_key_checks = 0");
		 * $this->db->where('idadulticidetreatment',$id);
		 * $this->db->delete('adulticidetreatmentsservice');
		 * $this->db->query("SET foreign_key_checks = 1");
		 * }
		 * }
		 */
		$data ['isDeleted'] = '1';
		$this->db->where ( 'idadulticidetreatment', $id );
		$this->db->update ( 'adulticidetreatments', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ) && empty ( $id ))
			return false;
		
		return $id;
	}
	
    /**
	 * Function to Get Adulticide Data for Map Summary
	 */
	public function getAdulticideMapData() {
		$page_limit = $this->input->get ( 'page_size' );
		if (empty ( $page_limit ))
			$page_limit = 10;
		$page = $this->input->get ( 'page' );
		if (empty ( $page ) || $page == '' || $page == 1)
			$offset = 0;
		else
			$offset = $page * $page_limit;
		
		$filter_date = $this->input->get ( 'filter_date' );
		$setfromdate = $this->input->get ( 'setfromdate' );
		$settodate = $this->input->get ( 'settodate' );
		
		if (empty ( $filter_date ))
			$filter_date = "2";
		
		$this->db->select ( 'adt.*,
				st.sitetype,
				l.GoogleZoom' );
		$this->db->from ( 'adulticidetreatments AS adt' );
		$this->db->join ( 'sites AS s', 'adt.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'zones AS z', 's.idzone = z.idzone', 'LEFT' );
		$this->db->join ( 'users AS u', 'adt.idapplicator = u.iduser', 'LEFT' );
		$this->db->join ( 'sitetypes AS st', 'st.idsitetype = s.idsitetype', 'LEFT' );
		$this->db->join ( 'systemtypes AS sys', 'adt.idsystemtype = sys.idsystemtype', 'LEFT' );
		$this->db->join ( 'locations AS l', 's.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'adt.isdeleted', '0' );
		
		if (! is_null ( $filter_date ) && empty ( $setfromdate ) && empty ( $settodate )) {
			switch ($filter_date) {
				case '1' :
					$this->db->where ( 'adt.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'adt.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'adt.date' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'adt.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'adt.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'adt.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'adt.date' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'adt.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'adt.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'adt.date' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		} else if (! empty ( $setfromdate ) && ! empty ( $settodate )) {
			$this->db->where ( 'adt.date' . ' >=', $setfromdate );
			$this->db->where ( 'adt.date' . ' <=', $settodate );
		}
		
		$this->db->order_by ( 'adt.date', 'desc' );
		$this->db->limit ( $page_limit, $offset );
		
		$data = array ();
		$data_1 = array ();
		$zonecoords = array ();
		$query = $this->db->get ();
		// echo $this->db->last_query()."<br>";
		// echo "<br>".$query -> num_rows()."<br>";
		if ($query->num_rows () > 0) {
			// print'<pre>';
			// print_r($query->result_array());
			// die;
			foreach ( $query->result_array () as $row ) {
				$this->db->select ( '*' );
				$this->db->from ( 'zonecords' );
				$this->db->where ( 'idzone', $row ['idzone'] );
				
				$q = $this->db->get ();
				if ($q->num_rows ()) {
					foreach ( $q->result_array () as $k => $v ) {
						$zonecoords [] = $v ['zonecord'];
					}
				}
				$row ['type'] = "Adulticide";
				$data_1 [] = $row;
			}
		}
        
    }
    
	/**
	 * Function to Get Lati Longi
	 * for displaying on Maps
	 */
	public function getMapdata() {
        $data = array ();
		$data_1 = array ();
        $data_2 = array ();
		$zonecoords = array ();
        
        $offset = 0;
		$page_size = $this->input->get ( 'page_size' );
		$filter_date = $this->input->get ( 'filter_date' );
		$setfromdate = $this->input->get ( 'setfromdate' );
		$settodate = $this->input->get ( 'settodate' );
		$filter_type = $this->input->get ( 'type' );
        
        $page_size = ($page_size == 'all') ? 'all' : (is_numeric($page_size) ? $page_size : 10);
        $limit = (is_numeric($page_size)) ? $page_size : NULL;        
        $offset = $limit * ($page - 1);
        
		if (empty ( $filter_date ))
			$filter_date = "2";
		
		if (strpos($filter_type, 'type') !== false) {
			$filter_type = substr($filter_type, -1);
		}
        //if(empty($filter_type) || (!empty($filter_type) && $filter_type == '1')){
    		$this->db->select ( 'adt.*,
    				st.sitetype,
    				l.GoogleZoom' );
    		$this->db->from ( 'adulticidetreatments AS adt' );
    		$this->db->join ( 'sites AS s', 'adt.idsite = s.idsite', 'LEFT' );
    		$this->db->join ( 'zones AS z', 's.idzone = z.idzone', 'LEFT' );
    		$this->db->join ( 'users AS u', 'adt.idapplicator = u.iduser', 'LEFT' );
    		$this->db->join ( 'sitetypes AS st', 'st.idsitetype = s.idsitetype', 'LEFT' );
    		$this->db->join ( 'systemtypes AS sys', 'adt.idsystemtype = sys.idsystemtype', 'LEFT' );
    		$this->db->join ( 'locations AS l', 's.idlocation = l.idlocation', 'LEFT' );
    		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
    		$this->db->where ( 'adt.isdeleted', '0' );
    		
    		if (! is_null ( $filter_date ) && empty ( $setfromdate ) && empty ( $settodate )) {
    			switch ($filter_date) {
    				case '1' :
    					$this->db->where ( 'adt.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
    					$this->db->where ( 'adt.date' . ' <=', date ( 'Y-m-d' ) );
    					break;
    				
    				case '2' :
    					$this->db->where ( 'adt.date' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
    					$this->db->where ( 'adt.date' . ' <=', date ( 'Y-m-d' ) );
    					break;
    				case '3' :
    					$this->db->where ( 'adt.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
    					$this->db->where ( 'adt.date' . ' <=', date ( 'Y-m-d' ) );
    					break;
    				case '4' :
    					$this->db->where ( 'adt.date' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
    					$this->db->where ( 'adt.date' . ' <=', date ( 'Y-m-d' ) );
    					break;
    				case '5' :
    					$this->db->where ( 'adt.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
    					$this->db->where ( 'adt.date' . ' <=', date ( 'Y-m-d' ) );
    					break;
    			}
    		} else if (! empty ( $setfromdate ) && ! empty ( $settodate )) {
    			$this->db->where ( 'adt.date' . ' >=', $setfromdate );
    			$this->db->where ( 'adt.date' . ' <=', $settodate );
    		}
    		
    		$this->db->order_by ( 'adt.date', 'desc' );
    		$this->db->limit ( $limit, $offset );
    		
    		$query = $this->db->get ();
    		// echo $this->db->last_query()."<br>";
    		// echo "<br>".$query -> num_rows()."<br>";
    		if ($query->num_rows () > 0) {
    			// print'<pre>';
    			// print_r($query->result_array());
    			// die;
    			foreach ( $query->result_array () as $row ) {
    				$this->db->select ( '*' );
    				$this->db->from ( 'zonecords' );
    				$this->db->where ( 'idzone', $row ['idzone'] );
    				
    				$q = $this->db->get ();
    				if ($q->num_rows ()) {
    					foreach ( $q->result_array () as $k => $v ) {
    						$zonecoords [] = $v ['zonecord'];
    					}
    				}
    				$row ['type'] = "Adulticide";
    				$data_1 [] = $row;
    			}
    		}
        //}
		// print'<pre>';
		// print_r($query->result());
		// echo "here";
		// die;
        //if(empty($filter_type) || (!empty($filter_type) && $filter_type == '2')){
    		$this->db->select ( 'lt.*,
    				st.sitetype,
    				l.GoogleZoom' );
    		$this->db->from ( 'larvaltreatments AS lt' );
    		$this->db->join ( 'sites AS s', 'lt.idsite = s.idsite', 'LEFT' );
    		$this->db->join ( 'zones AS z', 's.idzone = z.idzone', 'LEFT' );
    		$this->db->join ( 'users AS u', 'lt.idapplicator = u.iduser', 'LEFT' );
    		$this->db->join ( 'sitetypes AS st', 's.idsitetype = st.idsitetype', 'LEFT' );
    		$this->db->join ( 'systemtypes AS sys', 'lt.idsystemtype = sys.idsystemtype', 'LEFT' );
    		$this->db->join ( 'locations AS l', 's.idlocation = l.idlocation', 'LEFT' );
    		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
    		$this->db->where ( 'lt.isdeleted', '0' );
    		
    		if (! is_null ( $filter_date )) {
    			switch ($filter_date) {
    				case '1' :
    					$this->db->where ( 'lt.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
    					$this->db->where ( 'lt.date' . ' <=', date ( 'Y-m-d' ) );
    					break;
    				
    				case '2' :
    					$this->db->where ( 'lt.date' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
    					$this->db->where ( 'lt.date' . ' <=', date ( 'Y-m-d' ) );
    					break;
    				case '3' :
    					$this->db->where ( 'lt.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
    					$this->db->where ( 'lt.date' . ' <=', date ( 'Y-m-d' ) );
    					break;
    				case '4' :
    					$this->db->where ( 'lt.date' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
    					$this->db->where ( 'lt.date' . ' <=', date ( 'Y-m-d' ) );
    					break;
    				case '5' :
    					$this->db->where ( 'lt.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
    					$this->db->where ( 'lt.date' . ' <=', date ( 'Y-m-d' ) );
    					break;
    			}
    		}
    		
    		$this->db->order_by ( 'lt.date', 'desc' );
    		$this->db->limit ( $limit, $offset );
    		
    		$query = $this->db->get ();
    		if ($query->num_rows () > 0) {
    			foreach ( $query->result_array () as $row ) {
    				$this->db->select ( '*' );
    				$this->db->from ( 'zonecords' );
    				$this->db->where ( 'idzone', $row ['idzone'] );
    				
    				$q = $this->db->get ();
    				if ($q->num_rows ()) {
    					foreach ( $q->result_array () as $k => $v ) {
    						$zonecoords [] = $v ['zonecord'];
    					}
    				}
    				$row ['type'] = "Larvicide";
    				$data_2 [] = $row;
    			}
    		}
        //}
		// echo "thr";
		// print'<pre>';
		// print_r($data_1);
		// print_r($data_2);
		// die;
		if (! empty ( $data_1 ) && ! empty ( $data_2 )) {
			$data ['result'] = array_merge ( $data_1, $data_2 );
			$data ['zonecords'] = $zonecoords;
		} else if (! empty ( $data_1 )) {
			$data ['result'] = $data_1;
			$data ['zonecords'] = $zonecoords;
		} else if (! empty ( $data_2 )) {
			$data ['result'] = $data_2;
			$data ['zonecords'] = $zonecoords;
		}
		
		return $data;
	}
	
	/**
	 * Function to list all members mail
	 */
	public function ToExcelAll() {
		$this->db->select ( '*' );
		$this->db->from ( 'users' );
		$this->db->order_by ( 'iduser', 'desc' );
		$getData = $this->db->get ();
		
		if ($getData->num_rows () > 0)
			return $getData->result_array ();
		else
			return null;
	}
	
	/**
	 * Function to list all Treatment
	 */
	public function listTreatment($Ids = "", $type = "", $mapSite = "", $mapFlag = "") {
        //print_r($Ids);
//        print_r($ttl);
//        print_r($page);
//        print_r($filter_date);
//        print_r($filter_daterange);
		$result = array ();
		$i = 0;
		
		$this->db->select ( 'adulticidetreatments.idadulticidetreatment,
				sites.site, 
				sites.idsitetype,
				adulticidetreatments.iswaterofus,
				zones.zone,
				adulticidetreatments.date,
				users.firstname,
				users.lastname,
				sitetypes.sitetype,
				systemtypes.systemtype,
                CONCAT(users.firstname," ",users.lastname) AS applicator' , FALSE);
		$this->db->from ( 'adulticidetreatments' );
		$this->db->join ( 'sites', 'adulticidetreatments.idsite = sites.idsite', 'LEFT' );
		$this->db->join ( 'zones', 'sites.idzone = zones.idzone', 'LEFT' );
		$this->db->join ( 'users', 'adulticidetreatments.idapplicator = users.iduser', 'LEFT' );
		$this->db->join ( 'sitetypes', 'sites.idsitetype = sitetypes.idsitetype', 'LEFT' );
		$this->db->join ( 'systemtypes', 'adulticidetreatments.idsystemtype = systemtypes.idsystemtype', 'LEFT' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$filter_date = !empty($filter_date) ? $filter_date : $this->input->get ( 'filter_date' );
		$ttl = $this->input->get ( 'ttl' );
		$page = $this->input->get ( 'page' );
		$service = $this->input->get ( 'service' );
		$adult = $this->input->get ( 'adult' );
		$frmdate = $this->input->get ( 'frmdate' );
		$todate = $this->input->get ( 'todate' );
		
        if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 2;
		
		if (! isset ( $ttl ) || $ttl == '')
			$ttl = 10;
		
		if (! isset ( $page ) || $page == '')
			$page = 1;
		
        if(!empty($mapSite) || !empty($mapFlag)){
            $filter_date = "";
            $filter_daterange = "";
            $frmdate = "";
            $todate = "";
		}
        
        if(!empty($mapSite)) {
            $this->db->where ( 'sites.idsite', $mapSite );
        }
        
		if (! empty ( $frmdate ) && ! empty ( $todate )) {
			$frmdate = substr ( $frmdate, 0, 2 ) . '/' . substr ( $frmdate, 2, 2 ) . '/' . substr ( $frmdate, 4, 4 );
			$todate = substr ( $todate, 0, 2 ) . '/' . substr ( $todate, 2, 2 ) . '/' . substr ( $todate, 4, 4 );
			$this->db->where ( 'adulticidetreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( $frmdate ) ) );
			$this->db->where ( 'adulticidetreatments.date' . ' <=', date ( 'Y-m-d', strtotime ( $todate ) ) );
		} else if (! is_null ( $filter_date )) {
			switch ($filter_date) {
				// date('H:i:s',strtotime('-1 day');
				case '1' :
					$this->db->where ( 'adulticidetreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'adulticidetreatments.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'adulticidetreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'adulticidetreatments.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'adulticidetreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'adulticidetreatments.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'adulticidetreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'adulticidetreatments.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'adulticidetreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'adulticidetreatments.date' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		}
		
		if (! empty ( $service )) {
			$this->db->join ( 'adulticidetreatmentsservice', 'adulticidetreatments.idadulticidetreatment = adulticidetreatmentsservice.idadulticidetreatment', 'LEFT' );
			$this->db->where ( 'adulticidetreatmentsservice.idservicerequest', $service );
		}
		
		if (! empty ( $adult )) {
			$this->db->join ( 'adulticidetreatmentslarval', 'adulticidetreatments.idadulticidetreatment = adulticidetreatmentslarval.idadulticidetreatment', 'LEFT' );
			$this->db->where ( 'adulticidetreatmentslarval.idlarval', $adult );
		}
		$this->db->where ( 'adulticidetreatments.isdeleted', '0' );
		$this->db->order_by ( 'adulticidetreatments.date', 'DESC' );
        
        if(!empty($Ids) && !empty($type) && $type == "adult") {
            $this->db->where_in ( 'adulticidetreatments.idadulticidetreatment', $Ids );
        }
		$query = $this->db->get ();
		//echo $this->db->last_query()."<br>";
		if(!empty($type) && $type == "adult"){
		  //print_r($query->result_array ());die;
            return $query->result_array ();
        }
		$csql = $this->db->last_query ();
		$csql = str_replace ( "SELECT ", "SELECT " . "COUNT(*) AS count ,", $csql );
		$c1 = 0;
		$query = $this->db->query ( $csql );
		if ($query->num_rows () > 0) {
			$c1 = $query->result_array ();
			$c1 = $c1 [0] ['count'];
		}
		
		$this->db->select ( 'larvaltreatments.idlarvaltreatment, 
				sites.site, 
				sites.idsitetype, 
				larvaltreatments.iswaterofus, 
				zones.zone,
				larvaltreatments.date, 
				users.firstname, 
				users.lastname, 
				sitetypes.sitetype, 
				systemtypes.systemtype,
				l.GoogleZoom,
                CONCAT(users.firstname," ",users.lastname) AS applicator' , FALSE);
		$this->db->from ( 'larvaltreatments' );
		$this->db->join ( 'sites', 'larvaltreatments.idsite = sites.idsite', 'LEFT' );
		$this->db->join ( 'zones', 'sites.idzone = zones.idzone', 'LEFT' );
		$this->db->join ( 'users', 'larvaltreatments.idapplicator = users.iduser', 'LEFT' );
		$this->db->join ( 'sitetypes', 'sites.idsitetype = sitetypes.idsitetype', 'LEFT' );
		$this->db->join ( 'systemtypes', 'larvaltreatments.idsystemtype = systemtypes.idsystemtype', 'LEFT' );
		$this->db->join ( 'locations AS l', 'sites.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		if(!empty($mapSite)){
            $this->db->where ( 'sites.idsite', $mapSite );
		}
		if (! empty ( $frmdate ) && ! empty ( $todate )) {
			$this->db->where ( 'larvaltreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( $frmdate ) ) );
			$this->db->where ( 'larvaltreatments.date' . ' <=', date ( 'Y-m-d', strtotime ( $todate ) ) );
		} else if (! is_null ( $filter_date )) {
			switch ($filter_date) {
				// date('H:i:s',strtotime('-1 day');
				case '1' :
					$this->db->where ( 'larvaltreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'larvaltreatments.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'larvaltreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'larvaltreatments.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'larvaltreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'larvaltreatments.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'larvaltreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'larvaltreatments.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'larvaltreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'larvaltreatments.date' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		}
		
		if (! empty ( $service )) {
			$this->db->join ( 'larvaltreatmentservice', 'larvaltreatments.idlarvaltreatment = larvaltreatmentservice.idlarvaltreatment', 'LEFT' );
			$this->db->where ( 'larvaltreatmentservice.idservicerequest', $service );
		}
		
		if (! empty ( $adult )) {
			$this->db->join ( 'larvaltreatmentlarval', 'larvaltreatments.idlarvaltreatment = larvaltreatmentlarval.idlarvaltreatment', 'LEFT' );
			$this->db->where ( 'larvaltreatmentlarval.idlarval', $adult );
		}
		$this->db->where ( 'larvaltreatments.isdeleted', '0' );
		$this->db->order_by ( 'larvaltreatments.date', 'DESC' );
        if(!empty($Ids) && !empty($type) && $type == "larval") {
            $this->db->where_in ( 'larvaltreatments.idlarvaltreatment', $Ids );
        }
		$query = $this->db->get ();
        if(!empty($type) && $type == "larval"){
            return $query->result_array ();
        }
		
		$csql = $this->db->last_query ();
		$csql = str_replace ( "SELECT ", "SELECT " . "COUNT(*) AS count ,", $csql );
		$c2 = 0;
		$query = $this->db->query ( $csql );
		if ($query->num_rows () > 0) {
			$c2 = $query->result_array ();
			$c2 = $c2 [0] ['count'];
		}
		
		$c = $c1 + $c2;
		$pgs = "";
		// $pagesize = "";
		if (! empty ( $ttl ) && $ttl != "all")
			$ttl = $ttl;
			// else
			// $pagesize = 10;
		$pgs = ceil ( $c / $ttl );
		$no_of_succ_pgs = 0;
		$offset = 0;
		
		if ($c1 <= $c2)
			$no_of_succ_pgs = ceil ( 2 * $c1 / $ttl );
		else
			$no_of_succ_pgs = ceil ( 2 * $c2 / $ttl );
		
		if (! empty ( $page ) && $page <= $no_of_succ_pgs) {
			switch ($ttl) {
				case '5' :
					$limit = 2;
					break;
				case '10' :
					$limit = 5;
					break;
				case '50' :
					$limit = 25;
					break;
				case 'all' :
					$limit = '';
					break;
				default :
					$limit = '';
					break;
			}
			
			if ($page == 1)
				$offset = 0;
			else
				$offset = $page * 5 - 4;
		} else {
			$diff_pgs = 0;
			
			if ($c1 > $c2) {
				$diff_pgs = $c1 - $c2;
			} else {
				$diff_pgs = $c2 - $c1;
			}
			
			$no_of_succ_pgs = ceil ( $diff_pgs / $ttl );
			$limit = $ttl;
			if ($page == 1)
				$offset = 0;
			else
				$offset = $page * 5 - 4;
		}
		
		$this->db->select ( 'adulticidetreatments.idadulticidetreatment,
				sites.idsite , 
				sites.site, 
				sites.idsitetype,
				adulticidetreatments.iswaterofus,
				zones.zone,
				adulticidetreatments.date,
				users.firstname,
				users.lastname,
				sitetypes.sitetype,
				systemtypes.systemtype' );
		$this->db->from ( 'adulticidetreatments' );
		$this->db->join ( 'sites', 'adulticidetreatments.idsite = sites.idsite', 'LEFT' );
		$this->db->join ( 'zones', 'sites.idzone = zones.idzone', 'LEFT' );
		$this->db->join ( 'users', 'adulticidetreatments.idapplicator = users.iduser', 'LEFT' );
		$this->db->join ( 'sitetypes', 'sites.idsitetype = sitetypes.idsitetype', 'LEFT' );
		$this->db->join ( 'systemtypes', 'adulticidetreatments.idsystemtype = systemtypes.idsystemtype', 'LEFT' );
		$this->db->join ( 'locations', 'sites.idlocation = locations.idlocation', 'LEFT' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		
		if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 2;
		
		if (! isset ( $ttl ) || $ttl == '')
			$ttl = 10;
		
		if (! isset ( $page ) || $page == '')
			$page = 1;

		if(!empty($mapSite)){
            $this->db->where ( 'sites.idsite', $mapSite );
            $filter_date = "";
            $filter_daterange = "";
            $frmdate = "";
            $todate = "";
            $limit = "";
		}
		if (! empty ( $frmdate ) && ! empty ( $todate )) {
			$this->db->where ( 'adulticidetreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( $frmdate ) ) );
			$this->db->where ( 'adulticidetreatments.date' . ' <=', date ( 'Y-m-d', strtotime ( $todate ) ) );
		} else if (! is_null ( $filter_date )) {
			switch ($filter_date) {
				// date('H:i:s',strtotime('-1 day');
				case '1' :
					$this->db->where ( 'adulticidetreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'adulticidetreatments.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'adulticidetreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'adulticidetreatments.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'adulticidetreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'adulticidetreatments.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'adulticidetreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'adulticidetreatments.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'adulticidetreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'adulticidetreatments.date' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		}
		
		if (! empty ( $service )) {
			$this->db->join ( 'adulticidetreatmentsservice', 'adulticidetreatments.idadulticidetreatment = adulticidetreatmentsservice.idadulticidetreatment', 'LEFT' );
			$this->db->where ( 'adulticidetreatmentsservice.idservicerequest', $service );
		}
		
		if (! empty ( $adult )) {
			$this->db->join ( 'adulticidetreatmentslarval', 'adulticidetreatments.idadulticidetreatment = adulticidetreatmentslarval.idadulticidetreatment', 'LEFT' );
			$this->db->where ( 'adulticidetreatmentslarval.idlarval', $adult );
		}
		$this->db->where ( 'adulticidetreatments.isdeleted', '0' );
		$this->db->order_by ( 'adulticidetreatments.date', 'DESC' );
		
		if (! empty ( $limit ))
			$this->db->limit ( $limit, $offset );
		
		$query = $this->db->get ();
		// echo $this->db->last_query()."<br>";
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$result [$i] = $row;
				$result [$i] ['type'] = "Adulticide";
				$i ++;
			}
		}
		
		$this->db->select ( 'larvaltreatments.idlarvaltreatment,
				sites.idsite , 
				sites.site, 
				sites.idsitetype,
				larvaltreatments.iswaterofus , 
				zones.zone,
				larvaltreatments.date, 
				users.firstname, 
				users.lastname, 
				sitetypes.sitetype, 
				systemtypes.systemtype' );
		$this->db->from ( 'larvaltreatments' );
		$this->db->join ( 'sites', 'larvaltreatments.idsite = sites.idsite', 'LEFT' );
		$this->db->join ( 'zones', 'sites.idzone = zones.idzone', 'LEFT' );
		$this->db->join ( 'users', 'larvaltreatments.idapplicator = users.iduser', 'LEFT' );
		$this->db->join ( 'sitetypes', 'sites.idsitetype = sitetypes.idsitetype', 'LEFT' );
		$this->db->join ( 'systemtypes', 'larvaltreatments.idsystemtype = systemtypes.idsystemtype', 'LEFT' );
		$this->db->join ( 'locations', 'sites.idlocation = locations.idlocation', 'LEFT' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		if(!empty($mapSite)){
            $this->db->where ( 'sites.idsite', $mapSite );
		}
		if (! empty ( $frmdate ) && ! empty ( $todate )) {
			$this->db->where ( 'larvaltreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( $frmdate ) ) );
			$this->db->where ( 'larvaltreatments.date' . ' <=', date ( 'Y-m-d', strtotime ( $todate ) ) );
		} else if (! is_null ( $filter_date )) {
			switch ($filter_date) {
				// date('H:i:s',strtotime('-1 day');
				case '1' :
					$this->db->where ( 'larvaltreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'larvaltreatments.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'larvaltreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'larvaltreatments.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'larvaltreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'larvaltreatments.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'larvaltreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'larvaltreatments.date' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'larvaltreatments.date' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'larvaltreatments.date' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		}
		
		if (! empty ( $service )) {
			$this->db->join ( 'larvaltreatmentservice', 'larvaltreatments.idlarvaltreatment = larvaltreatmentservice.idlarvaltreatment', 'LEFT' );
			$this->db->where ( 'larvaltreatmentservice.idservicerequest', $service );
		}
		
		if (! empty ( $adult )) {
			$this->db->join ( 'larvaltreatmentlarval', 'larvaltreatments.idlarvaltreatment = larvaltreatmentlarval.idlarvaltreatment', 'LEFT' );
			$this->db->where ( 'larvaltreatmentlarval.idlarval', $adult );
		}
		$this->db->where ( 'larvaltreatments.isdeleted', '0' );
		$this->db->order_by ( 'larvaltreatments.date', 'DESC' );
		if (! empty ( $limit ))
			$this->db->limit ( $limit, $offset );
		$query = $this->db->get ();
		// echo $this->db->last_query();
		// die;
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$result [$i] = $row;
				$result [$i] ['type'] = "Larvicide";
				$i ++;
			}
		}
		// echo $c1." ".$c2;
		// die;
		// print'<pre>';
		// print_r($result);
		// die;
		return $result;
	}
	
	/**
	 * Function to fetch Species Name
	 */
	public function getSpecies($id = '') {
		$this->db->select ( 'm.*,
				lms.*,
				g.genus' );
		$this->db->from ( 'mosquitospecies AS m' );
		$this->db->join ( 'locationmosquitospecies AS lms', 'm.idmosquitospecies = lms.idmosquitospecies', 'INNER' );
		$this->db->join ( 'genuses AS g', 'm.idgenus = g.idgenus', 'INNER' );
		$this->db->order_by ( 'g.genus' );
		$this->db->order_by ( 'm.mosquitospecies' );
		$this->db->where ( 'lms.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$result = array ();
		$query = $this->db->get ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				// modified by sonu
				$result [] = $row;
			}
		}
		return $result;
                
	}
	
	/**
	 * Function to fetch Species Name
	 */
	public function getSelectedSpecies_I() {
		$this->db->select ( '*' );
		$this->db->from ( 'larvatreatmentdetails' );
		$result = array ();
		$query = $this->db->get ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$result [] = $row ['idmosquitospecies'];
			}
		}
		return $result;
	}
	
	/**
	 * Function to fetch Selected Species Name
	 */
	public function getSelectedSpecies($Id = '') {
		// modified by sonu
		$sel_species = array ();
		$this->db->select ( 'l.count,
				l.idmosquitospecies,
				m.mosquitospecies,
				g.genus' );
		$this->db->from ( 'larvatreatmentdetails AS l' );
		$this->db->join ( 'mosquitospecies AS m', 'l.idmosquitospecies = m.idmosquitospecies', 'LEFT' );
		$this->db->join ( 'genuses AS g', 'm.idgenus = g.idgenus', 'INNER' );
		$this->db->where ( 'l.idlarvaltreatment', $Id );
		$this->db->order_by ( 'g.genus' );
		
		$this->str = '';
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				
				// $this->str .= '<option value="'.$row['idmosquitospecies'].' " selected="true">'.$row['mosquitospecies'].'</option>';
				$sel_species [] = $row;
			}
		}
		// die;
		return $sel_species;
	}
	
	/**
	 * Function to fetch Larval Treatment Details
	 */
	public function getLarvalTreatmentData($id = '') {
		if (empty ( $id ))
			return null;
		
		$this->db->select ( 'l.*' );
		$this->db->from ( 'larvaltreatments AS l' );
		$this->db->join ( 'sites AS s', "l.idsite = s.idsite", 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'l.idlarvaltreatment', $id );
		$data_1 = array ();
		$query = $this->db->get ();
		$result = array ();
		if ($query->num_rows () > 0) {
			$recordCount = $query->num_rows ();
			foreach ( $query->result_array () as $row ) {
				$data_1 = $row;
			}
			// Return result to jTable
			
			return $data_1;
		}
	}
	
	/**
	 * Function to fetch Adult Treatment Details
	 */
	public function getAdultTreatmentData($id = '') {
		if (empty ( $id ))
			return null;
		
		$this->db->select ( 'a.*' );
		$this->db->from ( 'adulticidetreatments AS a' );
		$this->db->join ( 'sites AS s', "a.idsite = s.idsite", 'INNER' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'a.idadulticidetreatment', $id );
		$data_1 = array ();
		$query = $this->db->get ();
		$result = array ();
		if ($query->num_rows () > 0) {
			$recordCount = $query->num_rows ();
			foreach ( $query->result_array () as $row ) {
				$data_1 = $row;
			}
			// Return result to jTable
			
			return $data_1;
		}
	}
	
	/**
	 * Function to fetch All Data of Adulticide Treatment
	 * selected by Monitor
	 */
	public function getAdultTreatmentAllData($id = '') {
		if (empty ( $id ))
			return null;
		
		$this->db->select ( 'a.*,
				apm.applicationmethod,
				syst.systemtype,
				p.productname,
				at.unitarea,
				pu.unitproduct, 
				s.site, 
				s.idsitetype,
				st.sitetype,
				s.latitude AS sitelati, 
				s.longitude AS sitelongi' );
		$this->db->from ( 'adulticidetreatments AS a' );
		$this->db->join ( 'applicationmethods AS apm', 'a.idapplicationmethod = apm.idapplicationmethods', 'LEFT' );
		$this->db->join ( 'systemtypes AS syst', 'a.idsystemtype = syst.idsystemtype', 'LEFT' );
		$this->db->join ( 'sites AS s', "a.idsite = s.idsite", 'LEFT' );
        $this->db->join ( 'sitetypes AS st', 'st.idsitetype = s.idsitetype', 'LEFT' );
		$this->db->join ( 'products AS p', 'a.idproduct = p.idproduct', 'LEFT' );
		$this->db->join ( 'area_treated AS at', 'a.iduomtotalareatreated = at.idareatreated', 'LEFT' );
		$this->db->join ( 'productunit AS pu', 'a.iduomtotalproductapplied = pu.idproductunit', 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'idadulticidetreatment', $id );
		$data_1 = array ();
		$query = $this->db->get ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$data_1 [] = $row;
			}
			// print'<pre>';
			// print_r($data_1);
			// die;
			$this->db->select ( '*' );
			$this->db->from ( 'location_treatment' );
			$this->db->where ( 'treatment_id', $id );
			$this->db->where ( 'type', 'adult' );
			
			$q = $this->db->get ();
			$data_2 = array ();
			if ($q->num_rows () > 0) {
				foreach ( $q->result_array () as $row ) {
					$data_2 [] = $row;
				}
			}
			
			$data_3 = array ();
			
			if (! empty ( $data_1 [0] ['idmonitor'] )) {
				$this->db->select ( '*' );
				$this->db->from ( 'monitormgmt_detail' );
				$this->db->where ( 'idmonitor', $data_1 [0] ['idmonitor'] );
				
				$q = $this->db->get ();
				
				if ($q->num_rows () > 0) {
					foreach ( $q->result_array () as $row ) {
						$data_3 [] = $row;
					}
				}
			}
			
			$data_1 [0] ['map'] = $data_3;
			if (! empty ( $data_2 ))
				$data_1 [0] ['loc'] = $data_2;
			$data_1 = $data_1 [0];
			// print'<pre>';
			// print_r($data_1);
			// print_r($data_2);
			// die;
			// //
			if (! empty ( $data_1 ))
				return $data_1;
		}
		
		return $data_1;
	}
	
	/**
	 * Function to fetch All Data of Larvicide Treatment
	 * selected by Monitor
	 */
	public function getLarvaTreatmentAllData($id = '') {
		if (empty ( $id ))
			return null;
		
		$this->db->select ( 'l.*,
				apm.applicationmethod,
				syst.systemtype,
				p.productname,
				a.unitarea,
				pu.unitproduct, 
				s.site, 
				s.idsitetype,
				st.sitetype,
				s.latitude AS sitelati, 
				s.longitude AS sitelongi' );
		$this->db->from ( 'larvaltreatments AS l' );
		$this->db->join ( 'applicationmethods AS apm', 'l.idapplicationmethod = apm.idapplicationmethods', 'LEFT' );
		$this->db->join ( 'systemtypes AS syst', 'l.idsystemtype = syst.idsystemtype', 'LEFT' );
		$this->db->join ( 'sites AS s', "l.idsite = s.idsite", 'LEFT' );
		$this->db->join ( 'sitetypes AS st', 'st.idsitetype = s.idsitetype', 'LEFT' );
		$this->db->join ( 'products AS p', 'l.idproduct = p.idproduct', 'LEFT' );
		$this->db->join ( 'area_treated AS a', 'l.iduomtotalareatreated = a.idareatreated', 'LEFT' );
		$this->db->join ( 'productunit AS pu', 'l.iduomtotalproductapplied = pu.idproductunit', 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'l.idlarvaltreatment', $id );
		$data_1 = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$data_1 [] = $row;
			}
			
			$this->db->select ( 'lct.id, 
					lct.treatment_id, 
					lct.type, 
					lct.gps_lati, 
					lct.gps_lati AS latitude, 
					lct.gps_logi, 
					lct.gps_logi AS longitude, 
					lct.dateadded ' );
			$this->db->from ( 'location_treatment AS lct' );
			$this->db->where ( 'lct.treatment_id', $id );
			$this->db->where ( 'lct.type', 'larva' );
			
			$q = $this->db->get ();
			$data_2 = array ();
			if ($q->num_rows () > 0) {
				foreach ( $q->result_array () as $row ) {
					$data_2 [] = $row;
				}
			}
			
			if (! empty ( $data_2 )) {
				$data_1 [0] ['loc'] = $data_2;
				$data_1 [0] ['map'] = $data_2;
			}
			$data_1 = $data_1 [0];
			// print'<pre>';
			// print_r($data_1);
			// print_r($data_2);
			// die;
			if (! empty ( $data_1 ))
				return $data_1;
		}
		
		return $data_1;
	}
	
	/**
	 * Function to list all Weather Conditions
	 */
	public function getWheatherCondtn($id = '') {
		$this->db->select ( '*' );
		$this->db->from ( 'weatherconditions' );
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idweathercondition'] = $row ['idweathercondition'];
				$result [$i] ['weathercondition'] = $row ['weathercondition'];
				$i ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to list all Application Methods
	 */
	public function getAppMethod($id = '') {
		$this->db->select ( '*' );
		$this->db->order_by ( 'applicationmethod' );
		$this->db->from ( 'applicationmethods' );
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idapplicationmethods'] = $row ['idapplicationmethods'];
				$result [$i] ['applicationmethod'] = $row ['applicationmethod'];
				$i ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to list all Application Rate
	 * Units
	 */
	public function getAppRate($id = '') {
		$this->db->select ( '*' );
		$this->db->from ( 'applicationrateuom' );
		$this->db->order_by ( 'applicationrateuom', 'ASC' );
		
        $result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idapplicationrateuom'] = $row ['idapplicationrateuom'];
				$result [$i] ['applicationrateuom'] = $row ['applicationrateuom'];
				$i ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to list all Application Rate
	 * Type
	 */
	public function getAppRateType($id = '') {
		$this->db->select ( '*' );
		$this->db->from ( 'applicationratetypes' );
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idapplicationratetypes'] = $row ['idapplicationratetypes'];
				$result [$i] ['applicationratetype'] = $row ['applicationratetype'];
				$i ++;
			}
		}
		
		return $result;        
	}
	
	/**
	 * Function to list all Products
	 */
	public function getProducts($id = '', $type = '') {
		$this->db->select ( 'p.idproduct,
				p.productname,
				pz.packsize' );
		$this->db->from ( 'products AS p' );
		$this->db->join ( 'packsizes AS pz', 'p.idpacksize = pz.idpacksize', 'LEFT' );
		// $this->db->join('product_inventory AS pi','p.idproduct = pi.idproduct','LEFT');
		if (! empty ( $type )) {
			if (is_array ( $type )) {
				$str = '';
				for($i = 0; $i < count ( $type ); $i ++) {
					$str .= 'p.idcategory=' . $type [$i];
					if (! empty ( $type [$i + 1] ))
						$str .= ' OR ';
				}
				if (! empty ( $str ))
					$this->db->where ( '(' . $str . ')' );
			} else
				$this->db->where ( 'p.idcategory', $type );
		}
		$this->db->where ( 'p.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'p.onhand > 0' );
		$this->db->order_by ( 'p.productname' );
		
		$query = $this->db->get ();
		// echo $this->db->last_query();
		// die;
		$this->str = "";
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if (isset ( $id ) && $row ['idproduct'] == $id)
					$this->str .= '<option value="' . $row ['idproduct'] . '" selected="true">' . $row ['productname'] . ' ' . $row ['packsize'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idproduct'] . '">' . $row ['productname'] . ' ' . $row ['packsize'] . '</option>';
			}
		}
		
		return $this->str;
        
	}
	
	/**
	 * Function to list all Formulation
	 */
	public function getFormulation($id = '') {
		$this->db->select ( '*' );
		$this->db->from ( 'formulations' );
		$this->db->order_by ( 'formulation', 'ASC' );
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idformulation'] = $row ['idformulation'];
				$result [$i] ['formulation'] = $row ['formulation'];
				$i ++;
			}
		}
		
		return $result;        
	}
	
	/**
	 * Function to list all Mix Ratio
	 */
	public function getMixRatio($id = '') {
		$this->db->select ( '*' );
		$this->db->from ( 'mixratios' );
		$this->db->order_by ( 'sort', 'ASC' );
		$query = $this->db->get ();
		$this->str = "";
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if (isset ( $id ) && $row ['idmixratio'] == $id)
					$this->str .= '<option value="' . $row ['idmixratio'] . '" selected="true">' . $row ['mixratio'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idmixratio'] . '">' . $row ['mixratio'] . '</option>';
			}
		}
		return $this->str;
	}
	
	/**
	 * Function to list all Finished Mix
	 */
	public function getFinishedMix($id = '') {
		$this->db->select ( '*' );
		$this->db->from ( 'finishedmix' );
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idfinishedmix'] = $row ['idfinishedmix'];
				$result [$i] ['unitfinishedmix'] = $row ['unitfinishedmix'];
				$i ++;
			}
		}
		
		return $result;        
	}
	
	/**
	 * Function to list all Total Area Teated
	 */
	public function getTAreaTreated($id = '') {
		$this->db->select ( '*' );
		$this->db->from ( 'area_treated' );
		$this->db->order_by ( 'unitarea' );
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idareatreated'] = $row ['idareatreated'];
				$result [$i] ['unitarea'] = $row ['unitarea'];
				$i ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to list all Total Product Applied
	 */
	public function getTProductApp($id = '') {
		$this->db->select ( '*' );
		$this->db->from ( 'productunit' );
		$this->db->order_by ( 'unitproduct', 'ASC' );
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idproductunit'] = $row ['idproductunit'];
				$result [$i] ['unitproduct'] = $row ['unitproduct'];
				$i ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to fetch all System Types
	 */
	public function getSystem($id = '') {
		$this->db->select ( '*' );
		$this->db->from ( 'systemtypes' );
		
		$query = $this->db->get ();
		$result = array();
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idsystemtype'] = $row ['idsystemtype'];
				$result [$i] ['systemtype'] = $row ['systemtype'];
				$i ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to fetch all Dilutents
	 */
	public function getDilutent($id = '') {
		$this->db->select ( '*' );
		$this->db->from ( 'dilutents' );
		
		$query = $this->db->get ();
		$result = array();
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['iddilutent'] = $row ['iddilutent'];
				$result [$i] ['dilutent'] = $row ['dilutent'];
				$i ++;
			}
		}
		
		return $result;
	}
    
	
	/**
	 * Function to fetch Flow Rate Types
	 */
	public function getFlowRateType($id = '') {
		$this->db->select ( '*' );
		$this->db->from ( 'flowratetypes' );
		
        $result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idflowratetype'] = $row ['idflowratetype'];
				$result [$i] ['flowrate'] = $row ['flowrate'];
				$i ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to fetch Easi Track API Key
	 * based on idlocation from locations table
	 */
	public function getEasiTrackAPIKey() {
		$key = '';
		$this->db->select ( 'token' );
		$this->db->from ( 'locations' );
		$this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$query = $this->db->get ();
		if ($query->num_rows () > 0) {
			$key = $query->result_array ();
			$key = ! empty ( $key [0] ) ? $key [0] ['token'] : '66D40F58-F7AC-4D9A-B0E1-B446C27BAF2C';
		}
		return $key;
	}
	
	/**
	 * Function to fetch Wind Direction
	 */
	public function getWindDirection($id = '') {
		$this->db->select ( '*' );
		$this->db->from ( 'winddirections' );
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idwinddirection'] = $row ['idwinddirection'];
				$result [$i] ['winddirection'] = $row ['winddirection'];
				$i ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to fetch Treatment Justification
	 */
	public function getTrtmentJustification() {
		$this->db->select ( '*' );
		$this->db->from ( 'treatmentjustification' );
		
		$query = $this->db->get ();
		$result = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$result [$row ['idtreatmentjustification']] = $row ['justification'];
			}
		}
		return $result;
	}
}

?>
