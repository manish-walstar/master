<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Disposition_model extends CI_Model {
	
	/**
	 * Constructor for the class
	 * Disposition
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to Add a new Disposition
	 */
	public function addDisposition($id = '') {
		// print'<pre>';
		// print_r($_POST);
		// die;
		$idlocation = $this->session->userdata ( 'idlocation' );
		$state = $this->input->post ( 'state' );
		
		if (! empty ( $state ) && $state == "on")
			$state = '1';
		else
			$state = '0';

		$data ['disposition'] = $this->input->post ( 'disposition' );
		$data ['state'] = $state;
		$data ['idlocation'] = ! empty ( $idlocation ) ? $idlocation : 0;
		
		if (! empty ( $id )) {
			$this->db->where ( 'iddispositions', $id );
			$this->db->update ( 'dispositions', $data );
		} else {
			$this->db->insert ( 'dispositions', $data );
			$id = $this->db->insert_id ();
		}
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ) && empty ( $id ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to list all Dispositions
	 */
	// public function deleteDisposition()
	// {
	// $iddisposition = $this->input->get_post('id');
	//
	// if(empty($iddisposition))
	// return false;
	//
	// $this->db->where('iddispositions',$iddisposition);
	// $this->db->delete('dispositions');
	//
	// $rows = $this->db->affected_rows();
	//
	// if(empty($rows) && empty($iddisposition))
	// return false;
	//
	// return true;
	//
	// }
	
	/**
	 * Function to fetch Statuses of Dispositions
	 */
	public function getStatuses() {
		$this->db->select ( 'iddispositions,state' );
		$this->db->from ( 'dispositions' );
		$this->db->where ( 'dispositions.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'dispositions.isdeleted', '0' );
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$k = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$k] ['status'] = $row ['state'];
				$result [$k] ['iddisposition'] = $row ['iddispositions'];
				$k ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to activate Dispositions
	 */
	public function activeDisposition() {
		$iddisposition = $this->input->get_post ( 'id' );
		
		if (empty ( $iddisposition ))
			return false;
		
		$data ['state'] = '1';
		
		$this->db->where ( 'iddispositions', $iddisposition );
		$this->db->update ( 'dispositions', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to deactivate Dispositions
	 */
	public function deactiveDisposition() {
		$iddisposition = $this->input->get_post ( 'id' );
		
		if (empty ( $iddisposition ))
			return false;
		
		$data ['state'] = '0';
		
		$this->db->where ( 'iddispositions', $iddisposition );
		$this->db->update ( 'dispositions', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to list all Dispositions mail
	 */
	public function getDispositionData($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( '*' );
		$this->db->from ( 'dispositions' );
		$this->db->where ( 'iddispositions', $Id );
		$this->db->order_by ( 'dispositions.disposition', 'ASC' );
		$this->db->where ( 'dispositions.idlocation', $this->session->userdata ( 'idlocation' ) );
		// $this->db->where('dispositions.isdeleted','0');
		$query = $this->db->get ();
		
		$data = array ();
		if ($query->num_rows () > 0) {
			$data = $query->result_array ();
			$data = $data [0];
		}
		
		return $data;
	}
	
	/**
	 * Function to list all Dispositions mail
	 */
	public function listDispositions() {
		$this->db->select ( 'dispositions.iddispositions, 
				dispositions.disposition AS `disposition`, 
				dispositions.state AS `state`' );
		$this->db->from ( 'dispositions' );
		$this->db->where ( 'dispositions.isdeleted', '0' );
		$this->db->join ( 'locations AS l', "dispositions.idlocation = l.idlocation", 'LEFT' );
		$this->db->where ( 'dispositions.idlocation', $this->session->userdata ( 'idlocation' ) );
		$ttl = $this->input->get ( 'ttl' );
		$page = $this->input->get ( 'page' );
		$orderby = $this->input->get ( 'orderby' );
		
		if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
			switch ($orderby) {
				case '0:asc' :
					$this->db->order_by ( 'dispositions.disposition', 'ASC' );
					break;
				case '0:desc' :
					$this->db->order_by ( 'dispositions.disposition', 'DESC' );
					break;
				case '1:asc' :
					$this->db->order_by ( 'dispositions.state', 'ASC' );
					break;
				case '1:desc' :
					$this->db->order_by ( 'dispositions.state', 'DESC' );
					break;
			}
		} else {
			$this->db->order_by ( 'dispositions.disposition' );
		}
		/*
		 * if(!isset($ttl) || $ttl == '')
		 * $ttl = 10;
		 *
		 * if(!isset($page) || $page == '')
		 * $page = 1;
		 *
		 * if(!is_null($ttl) && !is_null($page))
		 * {
		 * if($page == 1)
		 * $page = 0;
		 * else
		 * $page--;
		 *
		 * $page *= 10;
		 * $this->db->limit($ttl ,$page);
		 * }
		 * else if(!is_null($ttl))
		 * {
		 * $this->db->limit($ttl);
		 * }
		 */
		$data_1 = array ();
		$query = $this->db->get ();
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
	}
	public function getDispositionsByServiceRequestId($sid) {
		return $this->db->query ( "SELECT d.disposition
                                   FROM dispositions d
                                   LEFT JOIN servicerequestsdetail srd 
                                   ON d.iddispositions = srd.iddispositions
                                   LEFT JOIN servicerequests sr 
                                   ON srd.idservicerequest = sr.idservicerequest
                                   WHERE sr.idservicerequest = " . $sid );
	}
	
	/**
	 * Function to check for the existence of disposition
	 */
	public function disExist($str = '') {
		if (empty ( $str ))
			return false;
		
		$this->db->select ( '*' );
		$this->db->from ( 'dispositions' );
		$this->db->where ( 'disposition', $str );
		$this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0)
			return true;
		
		return false;
	}
}
