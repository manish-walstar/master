<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Truck_model extends CI_Model {
	
	/**
	 * Function to Add a new Truck
	 */
	public function addTruck($id = '') {
		$data ['name'] = $this->input->post ( 'name' );
		$data ['vehicletype'] = $this->input->post ( 'vehicletype' );
		$data ['make'] = $this->input->post ( 'make' );
		$data ['model'] = $this->input->post ( 'model' );
		$data ['modelyear'] = $this->input->post ( 'modelyear' );
		$data ['idlocation'] = $this->session->userdata ( 'idlocation' );
		
		if (! empty ( $id )) {
			$this->db->where ( 'idtruck', $id );
			$this->db->update ( 'trucks', $data );
			$insert_id = $id;
		} else {
			$this->db->insert ( 'trucks', $data );
			$insert_id = $this->db->insert_id ();
		}
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ) && empty ( $insert_id ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to delete Truck
	 */
	public function deleteTruck() {
		$idtruck = $this->input->get_post ( 'id' );
		if (empty ( $idtruck ))
			return false;
		
		$data ['isdeleted'] = '1';
		$this->db->where ( 'idtruck', $idtruck );
		$this->db->update ( 'trucks', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to get Trucks Detail
	 */
	public function getTruckData($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( '*' );
		$this->db->from ( 'trucks AS t' );
		$this->db->where ( 't.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 't.isdeleted', '0' );
		$this->db->where ( 't.idtruck', $Id );
		
		$query = $this->db->get ();
		$data = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row )
				$data [] = $row;
			
			return $data [0];
		}
	}
	
	/**
	 * Function to get Vehicle Detail
	 */
	public function getVehicles() {
		$this->db->select ( '*' );
		$this->db->from ( 'vehicletypes' );
		$query = $this->db->get ();
		$data = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row )
				$data [$row ['idvehicletype']] = $row ['vehicletype'];
		}
		return $data;
	}
	
	/**
	 * Function to list all Trucks mail
	 */
	public function listTrucks() {
		$this->db->select ( '*' );
		$this->db->from ( 'trucks AS t' );
		$this->db->join ( 'vehicletypes', "t.vehicletype = vehicletypes.idvehicletype", 'LEFT' );
		$this->db->where ( 't.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 't.isdeleted', '0' );
		$orderby = $this->input->get ( 'orderby' );
		
		if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
			switch ($orderby) {
				case '0:asc' :
					$this->db->order_by ( 't.name', 'ASC' );
					break;
				case '0:desc' :
					$this->db->order_by ( 't.name', 'DESC' );
					break;
				case '1:asc' :
					$this->db->order_by ( 'vehicletypes.vehicletype', 'ASC' );
					break;
				case '1:desc' :
					$this->db->order_by ( 'vehicletypes.vehicletype', 'DESC' );
					break;
				case '2:asc' :
					$this->db->order_by ( 't.make', 'ASC' );
					break;
				case '2:desc' :
					$this->db->order_by ( 't.make', 'DESC' );
					break;
				case '3:asc' :
					$this->db->order_by ( 't.model', 'ASC' );
					break;
				case '3:desc' :
					$this->db->order_by ( 't.model', 'DESC' );
					break;
				case '4:asc' :
					$this->db->order_by ( 't.modelyear', 'ASC' );
					break;
				case '4:desc' :
					$this->db->order_by ( 't.modelyear', 'DESC' );
					break;
			}
		} else {
			$this->db->order_by ( 't.name', 'desc' );
		}
		$ttl = $this->input->get ( 'ttl' );
		$page = $this->input->get ( 'page' );
		/*
		 * if(!isset($ttl) || $ttl == '')
		 * $ttl = 10;
		 *
		 * if(!isset($page) || $page == '')
		 * $page = 1;
		 *
		 * if(!is_null($ttl) && !is_null($page))
		 * {
		 * if($page == 1)
		 * $page = 0;
		 * else
		 * $page--;
		 *
		 * $page *= 10;
		 * $this->db->limit($ttl ,$page);
		 * }
		 * else if(!is_null($ttl))
		 * {
		 * $this->db->limit($ttl);
		 * }
		 */
		
		$query = $this->db->get ();
		// echo $this->db->last_query();
		// die;
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
	}
}
