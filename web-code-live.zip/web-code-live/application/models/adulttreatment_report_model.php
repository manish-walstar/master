<?php

if (! defined ( 'BASEPATH' ))
    exit ( 'No direct script access allowed' );
    date_default_timezone_set ( 'UTC' );
    class Adulttreatment_report_model extends CI_Model {
        public $data = "";
        
        /**
         * Constructor for the class
         * Zone
         */
        public function __construct() {
            // Call the Model constructor
            parent::__construct ();
        }
        
        /**
         * Function to fetch Adult Treatment
         */
        public function getAdultTreatment($startdate = '', $enddate = '', $sortorder = '') {
            $startdate_arr = explode ( "/", $startdate );
            $startdate = $startdate_arr [2] . "-" . $startdate_arr [0] . "-" . $startdate_arr [1];
            
            $enddate_arr = explode ( "/", $enddate );
            $enddate = $enddate_arr [2] . "-" . $enddate_arr [0] . "-" . $enddate_arr [1];
            
            // $startdate = '2012-01-01';
            // $enddate = '2013-08-01';
            
            $this->db->select ( 'a.*,
				s.site,
				s.idzone,
				s.idsitetype,
				s.city,
				z.zone,
				st.sitetype,
                f.wetdry,
				ap.applicationmethod,
				m.mixratio,
				u.unitproduct AS uoms,
				at.unitarea AS units,
				usr.firstname,
				usr.middlename,
				usr.lastname,
				p.productname,
				p.idproduct,
				at.unitarea' );
            $this->db->from ( 'adulticidetreatments AS a' );
            $this->db->join ( 'products AS p', 'a.idproduct = p.idproduct', "INNER" );
            $this->db->join ( 'sites AS s', 'a.idsite = s.idsite', "LEFT" );
            $this->db->join ( 'zones AS z', 's.idzone = z.idzone', "LEFT" );
            $this->db->join ( 'sitetypes AS st', 's.idsitetype = st.idsitetype', "LEFT" );
            $this->db->join ( 'applicationmethods AS ap', 'a.idapplicationmethod = ap.idapplicationmethods', "LEFT" );
            $this->db->join ( 'formulations AS f', 'p.idformulation = f.idformulation', 'LEFT' );
            $this->db->join ( 'mixratios AS m', 'a.idmixratio = m.idmixratio', "LEFT" );
            $this->db->join ( 'productunit AS u', 'a.iduomtotalproductapplied = u.idproductunit', "LEFT" );
            $this->db->join ( 'area_treated AS at', 'a.iduomtotalareatreated = at.idareatreated', "LEFT" );
            $this->db->join ( 'users AS usr', 'a.idapplicator = usr.iduser', "LEFT" );
            $this->db->where ( 'a.idlocation', $this->session->userdata ( 'idlocation' ) );
            // $this->db->where('z.idlocation',$this->session->userdata('idlocation'));
            // $this->db->where('p.idlocation',$this->session->userdata('idlocation'));
            $this->db->where ( 'date >=', $startdate );
            $this->db->where ( 'date <=', $enddate );
            $this->db->where ( 'a.isdeleted', '0' );
            $this->db->where ( 'a.idsite <> 0' );
            if ($sortorder)
                $this->db->order_by ( 'p.idproduct', 'asc' );
                else
                    $this->db->order_by ( 'p.productname', 'asc' );
                    $this->db->order_by ( 'a.date', 'desc' );
                    // $this->db->group_by('p.idproduct');
                    // $this->db->group_by('at.unitarea');
                    // $this->db->group_by('p.idproduct');
                    $query = $this->db->get ();
                    // echo $this->db->last_query()."<br><br>";
                    // die;
                    $result = array ();
                    if ($query->num_rows () > 0) {
                        $this->data = $query->result_array ();
                        // print'<pre>';
                        // print_r($this->data);
                        // die;
                        return $this->data;
                    }
                    
                    return $result;
        }
        
        /**
         * Function to generate XML
         */
        public function getXML($startdate = '', $enddate = '') {
            $startdate_arr = explode ( "/", $startdate );
            $startdate = $startdate_arr [2] . "-" . $startdate_arr [0] . "-" . $startdate_arr [1];
            
            $enddate_arr = explode ( "/", $enddate );
            $enddate = $enddate_arr [2] . "-" . $enddate_arr [0] . "-" . $enddate_arr [1];
            
            $this->db->select ( 'a.*,
				s.site,
				s.city,
				z.zone,
				st.sitetype,
                f.wetdry,
				ap.applicationmethod,
				m.mixratio,
				u.unitproduct AS uoms,
				at.unitarea AS units,
				usr.firstname,
				usr.middlename,
				usr.lastname,
				p.productname' );
            $this->db->from ( 'adulticidetreatments AS a' );
            $this->db->join ( 'products AS p', 'a.idproduct = p.idproduct', "INNER" );
            $this->db->join ( 'sites AS s', 'a.idsite = s.idsite', "LEFT" );
            $this->db->join ( 'zones AS z', 's.idzone = z.idzone', "LEFT" );
            $this->db->join ( 'sitetypes AS st', 's.idsitetype = st.idsitetype', "LEFT" );
            $this->db->join ( 'applicationmethods AS ap', 'a.idapplicationmethod = ap.idapplicationmethods', "LEFT" );
            $this->db->join ( 'mixratios AS m', 'a.idmixratio = m.idmixratio', "LEFT" );
            $this->db->join ( 'formulations AS f', 'p.idformulation = f.idformulation', 'LEFT' );
            $this->db->join ( 'productunit AS u', 'a.iduomtotalproductapplied = u.idproductunit', "LEFT" );
            $this->db->join ( 'area_treated AS at', 'a.iduomtotalareatreated = at.idareatreated', "LEFT" );
            $this->db->join ( 'users AS usr', 'a.idapplicator = usr.iduser', "LEFT" );
            $this->db->where ( 'a.idlocation', $this->session->userdata ( 'idlocation' ) );
            // $this->db->where('z.idlocation',$this->session->userdata('idlocation'));
            // $this->db->where('p.idlocation',$this->session->userdata('idlocation'));
            $this->db->where ( 'a.isdeleted', '0' );
            $this->db->where ( 'a.idsite <> 0' );
            $this->db->where ( 'date >=', $startdate );
            $this->db->where ( 'date <=', $enddate );
            
            $this->db->order_by ( 'p.productname', 'asc' );
            $this->db->order_by ( 'a.date', 'desc' );
            
            $query = $this->db->get ();
            
            return $query;
        }
        
        /**
         * Function to fetch All Products
         */
        public function getProducts($startdate = '', $enddate = '') {
            $result = array ();
            $k = 0;
            $chk = "";
            $noft = 0;
            $ttlarea = 0;
            $totalProducts = array();
            // echo "<br> 3 -->".$startdate." ".$enddate;
            $this->data = $this->getAdultTreatment ( $startdate, $enddate );
            //log_message('debug','Skysoft Debugging -------------->>>>> data of adult treatment is  ....... '.print_r($this->data,1));
            // exit();
            // print('<pre>');
            // print_r($this->data);
            // die;
            if (! empty ( $this->data )) {
                $k = 0;
                $noft = 1;
                $areaArr = array();
                foreach ( $this->data as $key => $val ) {
                    // print('<pre>');
                    // print_r($val);
                    // print('</pre>');
                    // echo $chk." ".$val['productname']."<br>";
                    if ($chk != $val ['productname']) {
                        $this->db->select ( 'p.*,
							f.formulation, f.wetdry,
							pm.manufacturer' );
                        $this->db->from ( 'products AS p' );
                        $this->db->join ( 'productmanufacturers AS pm', 'p.idmanufacturer = pm.idmanufacturer', 'LEFT' );
                        $this->db->join ( 'formulations AS f', 'p.idformulation = f.idformulation', 'LEFT' );
                        $this->db->where ( "p.idlocation", $this->session->userdata ( 'idlocation' ) );
                        $this->db->where ( 'p.idproduct', $val ['idproduct'] );
                        $this->db->order_by ( 'p.productname', 'asc' );
                        
                        $query = $this->db->get ();
                        $ttlarea = $val ['totalareatreated'];
                        //log_message('debug','Skysoft Debugging -------------->>>>>Enter in first if condition.......... ');
                        // echo $this->db->last_query()." K:".$k."<br>";
                        // print'<pre>';
                        // print_r($query -> num_rows());
                        // print'</pre>';
                        if ($query->num_rows () > 0) {
                            $k ++;
                            $noft = 1;
                            $temp = $query->result_array ();
                            $result [$k] = $temp [0];
                            // $result [$k] ['pr'] ['qty'] = $ttlprdct;
                            $totalProducts[$val ['productname'].$val ['uoms']] = (isset($totalProducts[$val ['productname'].$val ['uoms']]) ? $totalProducts[$val ['productname'].$val ['uoms']] : 0) + $val ['totalproductapplied'];
                            //log_message('debug','Skysoft Debugging -------------->>>>>detail of product   ........ '.print_r($val,1));
                            
                            
                            
                            
                            if(($val ['wetdry'] == '1')) {
                                
                                $result [$k] ['pr'] ['qty_ounces'] = $totalProducts[$val ['productname'].$val ['uoms']]/128;
                                $result [$k] ['pr'] ['uom_ounces'] = 'Gallons';
                                $result [$k] ['pr'] ['qty_gal'] = ($totalProducts[$val ['productname'].$val ['uoms']]);
                                $result [$k] ['pr'] ['uom_gal']  = $val ['uoms'];
                            }
                            if(($val ['wetdry'] == '2') ) {
                                $result [$k] ['pr'] ['qty_ounces'] = $totalProducts[$val ['productname'].$val ['uoms']]/16;
                                $result [$k] ['pr'] ['uom_ounces'] =  'Pounds';
                                $result [$k] ['pr'] ['qty_gal'] = ($totalProducts[$val ['productname'].$val ['uoms']]);
                                $result [$k] ['pr'] ['uom_gal'] =  $val ['uoms'];
                                
                                
                            }
                            $result [$k] ['pr'] ['uom'] = $val ['uoms'];
                            $result [$k] ['pr'] ['units'] = $val ['units'];
                            switch($val['units'])
                            {
                                case 'Acres':
                                    $areaArr = array($ttlarea,0,0,0);
                                    break;
                                case 'Sq. Ft.':
                                    $areaArr = array(0,$ttlarea,0,0);
                                    break;
                                case 'Basins':
                                    $areaArr = array(0,0,$ttlarea,0);
                                    break;
                                case 'Miles':
                                    $areaArr = array(0,0,0,$ttlarea);
                                    break;
                            }
                            $result [$k] ['pr'] ['area'] = $areaArr;
                            $result [$k] ['pr'] ['noft'] = $noft;
                        }
                    } else {
                        $noft ++;
                        $totalProducts[$val ['productname'].$val ['uoms']] = (isset($totalProducts[$val ['productname'].$val ['uoms']]) ? $totalProducts[$val ['productname'].$val ['uoms']] : 0) + $val ['totalproductapplied'];
                        if(($val ['wetdry'] == '1')) {
                            
                            $result [$k] ['pr'] ['qty_ounces'] = $totalProducts[$val ['productname'].$val ['uoms']]/128;
                            $result [$k] ['pr'] ['uom_ounces'] = 'Gallons';
                            $result [$k] ['pr'] ['qty_gal'] = ($totalProducts[$val ['productname'].$val ['uoms']]);
                            $result [$k] ['pr'] ['uom_gal']  = $val ['uoms'];
                        }
                        if(($val ['wetdry'] == '2') ) {
                            $result [$k] ['pr'] ['qty_ounces'] = $totalProducts[$val ['productname'].$val ['uoms']]/16;
                            $result [$k] ['pr'] ['uom_ounces'] =  'Pounds';
                            $result [$k] ['pr'] ['qty_gal'] = ($totalProducts[$val ['productname'].$val ['uoms']]);
                            $result [$k] ['pr'] ['uom_gal'] =  $val ['uoms'];
                            
                            
                        }
                        $result [$k] ['pr'] ['uom'] = $val ['uoms'];
                        $result [$k] ['pr'] ['units'] = $val ['units'];
                        switch($val['units'])
                        {
                            case 'Acres':
                                $areaArr[0] += $val ['totalareatreated'];
                                break;
                            case 'Sq. Ft.':
                                $areaArr[1] += $val ['totalareatreated'];
                                break;
                            case 'Basins':
                                $areaArr[2] += $val ['totalareatreated'];
                                break;
                            case 'Miles':
                                $areaArr[3] += $val ['totalareatreated'];
                                break;
                        }
                        $result [$k] ['pr'] ['area'] = $areaArr;
                        $result [$k] ['pr'] ['noft'] = $noft;
                    }
                    $chk = $val ['productname'];
                }
            }
            // echo "<br>------------RSLT ---------------<br>";
            // print'<pre>';
            // print_r($result);
            // print'</pre>';
            // die;
            return $result;
        }
        
        /**
         * Function to fetch All Products
         */
        public function getProducts_I($startdate = '', $enddate = '') {
            $result = array ();
            $k = 0;
            $flag = "";
            $this->data = $this->getAdultTreatment ( $startdate, $enddate, 1 );
            if (! empty ( $this->data )) {
                foreach ( $this->data as $key => $val ) {
                    if ($val ['idproduct'] != $flag) {
                        $this->db->select ( 'p.*,f.formulation,pm.manufacturer' );
                        $this->db->from ( 'products AS p' );
                        $this->db->join ( 'formulations AS f', 'p.idformulation = f.idformulation', 'LEFT' );
                        $this->db->join ( 'productmanufacturers AS pm', 'p.idmanufacturer = pm.idmanufacturer', 'LEFT' );
                        $this->db->join ( 'locations AS l', "p.idlocation = l.idlocation", 'INNER' );
                        $this->db->where ( "p.idlocation", $this->session->userdata ( 'idlocation' ) );
                        $this->db->where ( 'idproduct', $val ['idproduct'] );
                        
                        $this->db->order_by ( 'p.productname', 'asc' );
                        
                        $query = $this->db->get ();
                        // echo $this->db->last_query()."<br>";
                        $k = 0;
                        if ($query->num_rows () > 0) {
                            $temp = $query->result_array ();
                            $result [$val ['idproduct']] = $temp [0];
                        }
                    }
                    
                    $queryProduct = $this->db->get_where ( 'post_treatment_inspection', array (
                        'trtmnt_type' => 'adult',
                        'idtreatment' => $val ['idadulticidetreatment']
                    ) );
                    
                    $qp = $queryProduct->result_array ();
                    
                    $xyz = array ();
                    $temparr = $val;
                    $ptiInfo = array ();
                    $ptiInfo ['pti'] = 'NO';
                    $ptiInfo ['ptiDate'] = '';
                    
                    if ($queryProduct->num_rows () > 0) {
                        $ptiInfo ['pti'] = 'YES';
                        $ptiInfo ['ptiDate'] = $qp [0] ['date'];
                    }
                    $xyz = array_merge ( $temparr, $ptiInfo );
                    $result [$val ['idproduct']] ['misc'] [$k] = $xyz;
                    $k ++;
                    $flag = $val ['idproduct'];
                }
            }
            // echo "<br>===============FINAL RES=================<br>";
            // print'<pre>';
            // print_r($result);
            // print'</pre>';
            return $result;
        }
    }