<?php

if (! defined ( 'BASEPATH' ))
    exit ( 'No direct script access allowed' );
    date_default_timezone_set ( 'UTC' );
    class Usermodel extends CI_Model {
        public $data = array ();
        public $str = "";
        public $set_pwd = "";
        
        /**
         * Constructor for the class
         * User
         */
        public function __construct() {
            // Call the Model constructor
            parent::__construct ();
        }
        
        /**
         * Function to process
         * logging in the home
         */
        public function process($input = '') {
            if (empty ( $input )) {
                $username = $this->input->post ( 'username' );
                $password = $this->input->post ( 'password' );
            } else {
                $username = $input ['username'];
                $password = $input ['password'];
            }
            
            $salt = "";
            
            $this->db->select ( 'username,salt' );
            $this->db->from ( 'users' );
            $this->db->where ( 'username', $username );
            $this->db->where ( 'is_active', '1' );
            
            $query = $this->db->get ();
            // print'<pre>';
            // print_r($query->result_array());
            // die;
            
            $result = array ();
            if ($query->num_rows () > 0) {
                $data_1 = $query->result_array ();
                
                foreach ( $data_1 as $key => $val ) {
                    $salt = $val ['salt'];
                    
                    if (! empty ( $salt )) {
                        $this->db->select ( '*' );
                        $this->db->from ( 'users' );
                        $this->db->where ( 'username', $username );
                        $this->db->where ( 'encrypted_password', md5 ( $salt . $password ) );
                        $this->db->where ( 'is_active', '1' );
                        
                        $query_1 = $this->db->get ();
                        
                        if ($query_1->num_rows () > 0) {
                            foreach ( $query_1->result_array () as $r ) {
                                $_data [] = $r;
                            }
                            
                            return $_data [0];
                        } else
                            return false;
                    } else {
                        return false;
                    }
                }
            } else {
                return false;
            }
        }
        
        /**
         * Function to status of user_lock_setting for a specific location
         */
        public function getUserLockControl($idlocation)
        {
            $this->db->select ( 'user_lock' );
            $this->db->from ( 'locations' );
            $this->db->where ( 'idlocation', $idlocation );
            $row = $this->db->get()->row();
            return ! empty ( $row ) ? $row->user_lock : '';
        }
        
        public function getUserId() {
            $encid = $this->session->userdata ( 'id' );
            $encid = explode ( "_", json_encode ( base64_decode ( $encid ) ) );
            return json_decode ( base64_decode ( $encid [0] ) );
        }
        /**
         * Function to check User existence
         * By Email Id
         */
        public function userExist($str = '') {
            if (empty ( $str ))
                return false;
                
                $this->db->select ( '*' );
                $this->db->from ( 'users' );
                $this->db->where ( 'email', $str );
                
                $query = $this->db->get ();
                
                if ($query->num_rows () > 0)
                    return true;
                    
                    return false;
        }
        
        /**
         * Function to fetch the location id
         * of user
         */
        public function getLocation($Id = '') {
            if (empty ( $Id ))
                return false;
                
                $this->db->select ( 'idlocation' );
                $this->db->from ( 'userlocationassignment' );
                $this->db->where ( 'iduser', $Id );
                
                $query = $this->db->get ();
                $data = array ();
                
                if ($query->num_rows () > 0) {
                    foreach ( $query->result_array () as $row )
                        $data = $row;
                        return $data ['idlocation'];
                }
                
                return false;
        }
        
        /**
         * Function to fetch the * from location
         * table through location id
         * of user
         */
        public function getLocationDetail($Id = '') {
            if (empty ( $Id ))
                return false;
                
                $this->db->select ( '*' );
                $this->db->from ( 'locations' );
                $this->db->where ( 'idlocation', $Id );
                
                $query = $this->db->get ();
                $data = array ();
                
                if ($query->num_rows () > 0) {
                    foreach ( $query->result_array () as $row )
                        $data = $row;
                        return $data;
                }
                
                return false;
        }
        
        /**
         * Function to fetch the ismenu option from location
         * table through location id
         * of user
         */
        public function getLocationMenu($Id = '') {
            if (empty ( $Id ))
                return false;
                
                $this->db->select ( 'ismenu' );
                $this->db->from ( 'locations' );
                $this->db->where ( 'idlocation', $Id );
                
                $query = $this->db->get ();
                $data = array ();
                
                if ($query->num_rows () > 0) {
                    foreach ( $query->result_array () as $row )
                        $data = $row;
                        return $data ['ismenu'];
                }
                
                return false;
        }
        public function getDashBoardZoom($Id = '') {
            if (empty ( $Id ))
                return false;
                
                $this->db->select ( 'dashboardzoom' );
                $this->db->from ( 'locationpreferences' );
                $this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
                
                $query = $this->db->get ();
                $data = array ();
                
                if ($query->num_rows () > 0) {
                    foreach ( $query->result_array () as $row )
                        $data = $row;
                        
                        return $data ['dashboardzoom'];
                }
                echo $data;
                return false;
        }
        
        /**
         * Function to check whether the mobile user
         * is already logged in or not
         */
        public function checklogin($Id = '', $ip = '') {
            if (empty ( $Id ))
                return false;
                
                if (empty ( $ip ))
                    return false;
                    
                    $this->db->select ( '*' );
                    $this->db->from ( 'session' );
                    $this->db->where ( 'user_id', $Id );
                    $this->db->where ( 'ip_addr', $ip );
                    
                    $query = $this->db->get ();
                    
                    if ($query->num_rows () > 0)
                        return true;
                        
                        return false;
        }
        
        /**
         * Function to enter the mobile user login
         * details into db
         */
        public function loginentry($Id = '') {
            if (empty ( $Id ))
                return false;
                
                $ip = $this->input->ip_address ();
                
                if (empty ( $ip ))
                    return false;
                    
                    if (! $this->input->valid_ip ( $ip ))
                        return false;
                        
                        $flag = $this->checklogin ( $Id, $ip );
                        
                        if ($flag)
                            return true;
                            
                            $data = array (
                                'user_id' => $Id,
                                'ip_addr' => $ip,
                                'loggedin_datetime' => time ()
                            );
                            
                            $this->db->insert ( 'session', $data );
                            
                            $rows = $this->db->affected_rows ();
                            
                            if (empty ( $rows ))
                                return false;
                                
                                return true;
        }
        
        /**
         * Function to enter the mobile user login
         * details into db
         */
        public function mlogoutentry($Id = '') {
            if (empty ( $Id ))
                return false;
                
                $ip = $this->input->ip_address ();
                
                if (empty ( $ip ))
                    return false;
                    
                    if (! $this->input->valid_ip ( $ip ))
                        return false;
                        
                        $flag = $this->checklogin ( $Id, $ip );
                        
                        if (! $flag)
                            return false;
                            
                            $this->db->delete ( 'session', array (
                                'user_id' => $Id
                            ) );
                            
                            $rows = $this->db->affected_rows ();
                            
                            if (empty ( $rows ))
                                return false;
                                return true;
        }
        
        /**
         * Function to Update User Profile
         */
        public function updateUserData($Id) {
            if (empty ( $Id ))
                return false;
                
                $id = json_decode ( base64_decode ( $Id ) );
                
                $id_arr = explode ( "_", $id );
                
                $id = json_decode ( base64_decode ( $id_arr [0] ) );
                
                if (empty ( $id ))
                    return false;
                    
                    $idsuffix = $this->input->post ( 'idsuffix' );
                    $idsalutation = $this->input->post ( 'idsalutation' );
                    $service_request = $this->input->post ( 'srvice_rqst' );
                    $surveillance = $this->input->post ( 'surveillance' );
                    $treatments = $this->input->post ( 'treatments' );
                    $reports = $this->input->post ( 'reports' );
                    $company_admin = $this->input->post ( 'cmpny_admin' );
                    $device_managment = $this->input->post ( 'device_mngmnt' );
                    $skytrackeradmin = $this->input->post ( 'skytrackeradmin' );
                    $pilot = $this->input->post ( 'pilot' );
                    
                    $this->db->select ( '*' );
                    $this->db->from ( 'users' );
                    $this->db->where ( 'iduser', $id );
                    
                    $query = $this->db->get ();
                    $result = array ();
                    $crrnt_password = $this->input->post ( 'crrnt_password' );
                    $new_passwrd = $this->input->post ( 'password' );
                    $mtch_password = $this->input->post ( 'passconf' );
                    if ($query->num_rows () > 0) {
                        foreach ( $query->result_array () as $row ) {
                            $result [] = $row;
                        }
                    }
                    
                    $result = $result [0];
                    // print'<pre>';
                    // print_r($_POST);
                    // print_r($result);
                    // echo $result['encrypted_password']." ".md5($result['salt'].$crrnt_password);
                    // die;
                    if (! empty ( $crrnt_password ) && ! empty ( $new_passwrd ) && ! empty ( $mtch_password ) && $mtch_password == $new_passwrd) {
                        // echo "thr";
                        if ($result ['encrypted_password'] != md5 ( $result ['salt'] . $crrnt_password ))
                            return false;
                            else if ($result ['encrypted_password'] == md5 ( $result ['salt'] . $crrnt_password )) {
                                $data ['salt'] = generateRandomString ();
                                $data ['encrypted_password'] = md5 ( $data ['salt'] . $new_passwrd );
                            }
                    }
                    // echo "here1";
                    // die;
                    $data ['username'] = $this->input->post ( 'username' );
                    $data ['email'] = $this->input->post ( 'email' );
                    $data ['idsalutation'] = ($idsalutation) ? $idsalutation : NULL;
                    $data ['firstname'] = $this->input->post ( 'firstname' );
                    $data ['middlename'] = $this->input->post ( 'middlename' );
                    $data ['lastname'] = $this->input->post ( 'lastname' );
                    $data ['idsuffix'] = ($idsuffix) ? $idsuffix : NULL;
                    $data ['officephone'] = $this->input->post ( 'officephone' );
                    $data ['mobilephone'] = $this->input->post ( 'mobilephone' );
                    $data ['faxnumber'] = $this->input->post ( 'faxnumber' );
                    $data ['hideboundary'] = $this->input->post ( 'hideboundary' );
                    $data ['unique_id'] = uniqid ();
                    $data ['is_active'] = '1';
                    
                    // print'<pre>';
                    // echo $id;
                    // print_r($data);
                    // die;
                    
                    $this->db->where ( 'iduser', $id );
                    $this->db->update ( 'users', $data );
                    
                    $rows = $this->db->affected_rows ();
                    
                    if (empty ( $rows ) && empty ( $id ))
                        return false;
                        
                        return true;
        }
        
        /**
         * Function to sendForgotmail
         */
        public function sendForgotmail() {
            $email = $this->input->post ( 'email' );
            if (empty ( $email ))
                return false;
                
                $this->db->select ( 'CONCAT(firstname," ",middlename," ",lastname) AS name', FALSE );
                $this->db->from ( 'users' );
                $this->db->where ( 'email', $email );
                
                $query = $this->db->get ();
                $result = array ();
                $data = array ();
                if ($query->num_rows () > 0)
                    foreach ( $query->result_array () as $row )
                        $result = $row;
                        
                        $this->set_pwd = generateRandomString ();
                        $data ['salt'] = generateRandomString ();
                        
                        $data ['encrypted_password'] = md5 ( $data ['salt'] . $this->set_pwd );
                        
                        $this->db->where ( 'email', $email );
                        $this->db->update ( 'users', $data );
                        
                        $name = ! empty ( $result ['name'] ) ? $result ['name'] : 'Customer';
                        $to = $email;
                        $subject = 'Your password has been changed';
                        $message = '
            <html>
            <head>
              <title>Password Alert</title>
            </head>
            <body>
              <table>
                <tr>
                  <td>
                    Hi ' . $name . ',
                  </td>
                </tr>
                <tr>
                  <td>&nbsp;</td>
                </tr>
                <tr>
                  <td>Your new password is ' . $this->set_pwd . '</td>
                </tr>
              </table>
            </body>
            </html>
            ';
                        
                        // To send HTML mail, the Content-type header must be set
                        $headers = 'MIME-Version: 1.0' . "\r\n";
                        $headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
                        
                        // Additional headers
                        $headers .= 'To: ' . $name . ' < ' . $email . '>' . "\r\n";
                        $headers .= 'From: Adapco Support <dev.amirkhan@gmail.com>' . "\r\n";
                        // $headers .= 'Cc: birthdayarchive@example.com' . "\r\n";
                        // $headers .= 'Bcc: birthdaycheck@example.com' . "\r\n";
                        
                        // Mail it
                        $t = mail ( $to, $subject, $message, $headers );
                        // $t = sendlocalmail($to, $subject, $message, $name);
                        
                        if ($t)
                            return true;
                            else
                                return false;
        }
        /**
         * Function to return logged in
         * user data
         */
        public function getUserData($Id) {
            if (empty ( $Id ))
                return false;
                
                // $id = json_decode(base64_decode($Id));
                // $id_arr = explode("_",$id);
                // $id = json_decode(base64_decode($id_arr[0]));
                $id = $Id;
                if (empty ( $id ))
                    return false;
                    
                    $this->db->select ( '*' );
                    $this->db->from ( 'users' );
                    $this->db->where ( 'iduser', $id );
                    
                    $query = $this->db->get ();
                    
                    $_data = array ();
                    
                    if ($query->num_rows () > 0) {
                        foreach ( $query->result_array () as $row ) {
                            $_data [] = $row;
                        }
                        
                        if (empty ( $_data [0] ))
                            return false;
                            
                            return $_data [0];
                    }
                    
                    return false;
        }
        public function getUserLockStatus() {
            $this->db->select ( '*' );
            $this->db->from ( 'locations' );
            $this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
            
            $row = $this->db->get ()->row();
            return $row->user_lock;
        }
        
        public function checkIsSameUser($itemId , $tableName , $idFieldName)
        {
            $this->db->select ( '*' );
            $this->db->from ( $tableName );
            $this->db->where ( $idFieldName ,  $itemId );
            
            $id = $this->getUserId();
            $this->db->where ( 'userId' ,  $id );
            
            $query = $this->db->get ();
            
            if($this->db->_error_message())
                return false;
                
                if ($query->num_rows () > 0)
                    return true;
                    else
                        return false;
        }
        
        /**
         * Function for access control
         */
        public function user_access($field) {
            $encid = $this->session->userdata ( 'id' );
            $encid = explode ( "_", json_encode ( base64_decode ( $encid ) ) );
            
            $Id = json_decode ( base64_decode ( $encid [0] ) );
            $query = $this->db->query ( "select $field from users where iduser = '$Id' " );
            foreach ( $query->result_array () as $row ) {
                if ($row [$field] == 1)
                    return true;
                    else
                        return false;
            }
        }
        public function set_access_session() {
            $encid = $this->session->userdata ( 'id' );
            $encid = explode ( "_", json_encode ( base64_decode ( $encid ) ) );
            $Id = json_decode ( base64_decode ( $encid [0] ) );
            $query = $this->db->query ( "select * from users where iduser = '$Id' " );
            $access = array ();
            foreach ( $query->result_array () as $row ) {
                
                $access ['treatments'] = !empty($row ['treatments']) ? $row ['treatments'] : '';
                $access ['reports'] = !empty($row ['reports']) ? $row ['reports'] : '';
                $access ['company_admin'] = !empty($row ['company_admin']) ? $row ['company_admin'] : '';
                $access ['device_managment'] = !empty($row ['device_managment']) ? $row ['device_managment'] : '';
                $access ['service_request'] = !empty($row ['service_request']) ? $row ['service_request'] : '';
                $access ['surveillance'] = !empty($row ['surveillance']) ? $row ['surveillance'] : '';
                $access ['skytrackeradmin'] = !empty($row ['skytrackeradmin']) ? $row ['skytrackeradmin'] : '';
                $access ['pilot'] = !empty($row ['pilot']) ? $row ['pilot'] : '';
            }
            $this->session->set_userdata ( 'access_permission', $access );
        }
        /**
         * ***************************Functions for access control ends*****************************************
         */
        
        /**
         * Function to Get Lati Longi
         * for displaying on Maps
         */
        public function getMapdata() {
            $data = array ();
            $i = 1;
            
            // Landing Rate Counts
            $trap_count_landing = $this->getLandingRate ();
            if (! empty ( $trap_count_landing )) {
                
                foreach ( $trap_count_landing as $row ) {
                    $data [$i] ['trcomo'] = $row ['count'];
                    $data [$i] ['trapname'] = 'Trap Mos';
                    $data [$i] ['traplink'] = '<span class="link_color">Max Landing Rate Count</a>';
                    $data [$i] ['id'] = $row ['idlandingrate'];
                    $data [$i] ['longitude'] = $row ['longitude'];
                    $data [$i] ['latitude'] = $row ['latitude'];
                    $data [$i] ['pudate'] = $row ['pudate'];
                    $data [$i] ['putime'] = $row ['putime'];
                    $data [$i] ['type'] = 'landing';
                    $data [$i] ['linktype'] = $row ['linktype'];
                    $i ++;
                }
            }
            
            // for trap count mosquito
            $trap_count_mos = $this->getTrapCountMos ();
            if (! empty ( $trap_count_mos )) {
                
                foreach ( $trap_count_mos as $row ) {
                    $data [$i] ['trcomo'] = $row ['count'];
                    $data [$i] ['trapname'] = 'Trap Mos';
                    $data [$i] ['traplink'] = '<span class="link_color">Max Trap Count All Mosquitos</a>';
                    $data [$i] ['id'] = $row ['idadultsurveillance'];
                    $data [$i] ['longitude'] = $row ['longitude'];
                    $data [$i] ['latitude'] = $row ['latitude'];
                    $data [$i] ['pudate'] = $row ['pudate'];
                    $data [$i] ['putime'] = $row ['putime'];
                    $data [$i] ['type'] = 'adult';
                    $data [$i] ['linktype'] = $row ['linktype'];
                    $i ++;
                }
            }
            
            // for trap count vector
            $trap_count_vector = $this->getTrapCountVector ();
            if (! empty ( $trap_count_vector )) {
                
                foreach ( $trap_count_vector as $row ) {
                    $data [$i] ['trcomo'] = $row ['count'];
                    $data [$i] ['trapname'] = 'Trap Mos';
                    $data [$i] ['traplink'] = '<span class="link_color">Max Trap Count Vector Mosquitos</a>';
                    $data [$i] ['id'] = $row ['idlarvalsurveillance'];
                    $data [$i] ['longitude'] = $row ['longitude'];
                    $data [$i] ['latitude'] = $row ['latitude'];
                    $data [$i] ['pudate'] = $row ['pudate'];
                    $data [$i] ['putime'] = $row ['putime'];
                    $data [$i] ['type'] = 'larval';
                    $data [$i] ['linktype'] = $row ['linktype'];
                    $i ++;
                }
            }
            
            // for trap count rainfall
            $trap_count_rain = $this->getCountRain ();
            if (! empty ( $trap_count_rain )) {
                
                foreach ( $trap_count_rain as $row ) {
                    $data [$i] ['trcomo'] = $row ['count'];
                    $data [$i] ['trapname'] = 'Trap Mos';
                    $data [$i] ['traplink'] = '<span class="link_color">Rainfall amount in 24 hours</a>';
                    $data [$i] ['id'] = $row ['idweather'];
                    $data [$i] ['longitude'] = $row ['longitude'];
                    $data [$i] ['latitude'] = $row ['latitude'];
                    $data [$i] ['pudate'] = $row ['pudate'];
                    $data [$i] ['putime'] = $row ['putime'];
                    $data [$i] ['type'] = 'weather';
                    $data [$i] ['linktype'] = $row ['linktype'];
                    $i ++;
                }
            }
            
            // echo '<pre>';
            // print_r($data);
            // die;
            return $data;
        }
        
        // get data from landing rates
        public function getLandingRate() {
            // Get Landing Rate Exceeds Count
            $this->db->select ( 'landingrateexceeds' );
            $this->db->from ( 'locationpreferences' );
            $this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
            $query = $this->db->get ();
            if($query->num_rows() > 0){
                $count = $query->first_row ();
            }
            else {
                return false;
            }
            $trap_mos_count = $count->landingrateexceeds;
            
            if (empty ( $trap_mos_count )) {
                return false;
            }
            
            // Compare Landing Rates to Landing Rate Exceeds
            $this->db->select ( 'landingrates.idlandingrate,landingrates.idsite,landingrates.observeddate,landingrates.observedtime,landingrates.latitude,landingrates.longitude,landingrates.countobserved,sum(landingratedetails.count) as counts' );
            $this->db->from ( 'landingrates' );
            $this->db->join ( 'landingratedetails', 'landingrates.idlandingrate=landingratedetails.idlandingrate', 'LEFT' );
            $this->db->join ( 'sites', 'landingrates.idsite=sites.idsite', 'LEFT' );
            
            $this->db->where ( 'landingrates.observeddate BETWEEN DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND CURDATE()' );
            $this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->group_by ( 'landingrates.idlandingrate' );
            $query = $this->db->get ();
            
            // echo $this->db->last_query()."<br>";
            $data = array ();
            if ($query->num_rows () > 0) {
                $j = 1;
                foreach ( $query->result_array () as $row ) {
                    // echo $row['counts'] ." ". $trap_mos_count."<br>";
                    if ($row ['counts'] > $trap_mos_count) {
                        $data [$j] ['latitude'] = $row ['latitude'];
                        $data [$j] ['longitude'] = $row ['longitude'];
                        $data [$j] ['idlandingrate'] = $row ['idlandingrate'];
                        $data [$j] ['pudate'] = $row ['observeddate'];
                        $data [$j] ['putime'] = $row ['observedtime'];
                        $data [$j] ['count'] = $row ['counts'];
                        $data [$j] ['linktype'] = 'landing';
                        $j ++;
                    }
                }
                // echo '<pre>';
                // print_r($data);
                // die;
                return $data;
            }
        }
        
        // Get Trap Count Exceeds
        public function getTrapCountMos_amir() {
            // get trap count
            $this->db->select ( 'trapcountmosquito' );
            $this->db->from ( 'locationpreferences' );
            $this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
            $query = $this->db->get ();
            $count = $query->first_row ();
            $trap_mos_count = $count->trapcountmosquito;
            if (empty ( $trap_mos_count )) {
                return false;
            }
            
            // Compare Trap Counts to Trap Count Exceeds
            $this->db->select ( 'adultsurveillance.idadultsurveillance,adultsurveillance.idtrap,adultsurveillance.pudate,adultsurveillance.putime,traps.latitude,traps.longitude,adultsurveillance.totalcount,adultsurveillance.totalcount as counts' );
            $this->db->from ( 'adultsurveillance' );
            $this->db->join ( 'adultsurveillancedetails', 'adultsurveillance.idadultsurveillance=adultsurveillancedetails.idadultsurveillance', 'inner' );
            $this->db->where ( 'adultsurveillance.pudate BETWEEN DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND CURDATE()' );
            $this->db->join ( 'traps', 'adultsurveillance.idtrap=traps.idtrap', 'inner' );
            $this->db->group_by ( 'adultsurveillance.idadultsurveillance' );
            $this->db->where ( 'adultsurveillance.idlocation', $this->session->userdata ( 'idlocation' ) );
            $query = $this->db->get ();
            $data = array ();
            // echo $this->db->last_query();
            
            if ($query->num_rows () > 0) {
                $j = 1;
                foreach ( $query->result_array () as $row ) {
                    // echo $row['counts'];
                    if ($row ['counts'] >= $trap_mos_count) {
                        $data [$j] ['latitude'] = $row ['latitude'];
                        $data [$j] ['longitude'] = $row ['longitude'];
                        $data [$j] ['idadultsurveillance'] = $row ['idadultsurveillance'];
                        $data [$j] ['pudate'] = $row ['pudate'];
                        $data [$j] ['putime'] = $row ['putime'];
                        $data [$j] ['count'] = $row ['counts'];
                        $j ++;
                    }
                }
                // print_r($data);
                return $data;
            }
        }
        
        // Get Trap Count Exceeds
        public function getTrapCountMos() {
            // get trap count
            $this->db->select ( 'trapcountmosquito' );
            $this->db->from ( 'locationpreferences' );
            $this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
            $query = $this->db->get ();
            if($query->num_rows() > 0){
                $count = $query->first_row ();
            }
            else {
                return false;
            }
            $trap_mos_count = $count->trapcountmosquito;
            
            if (empty ( $trap_mos_count )) {
                return false;
            }
            
            $this->db->select ( 'landingrates.idlandingrate,landingrates.idsite,landingrates.observeddate,landingrates.observedtime,landingrates.latitude,landingrates.longitude,landingrates.countobserved,sum(landingratedetails.count) as counts' );
            $this->db->from ( 'landingrates' );
            $this->db->join ( 'landingratedetails', 'landingrates.idlandingrate=landingratedetails.idlandingrate', 'LEFT' );
            $this->db->join ( 'sites', 'landingrates.idsite=sites.idsite', 'LEFT' );
            $this->db->join ( 'locationmosquitospecies AS lms', 'landingratedetails.idlocationvectorspecies = lms.idmosquitospecies', 'LEFT' );
            $this->db->where ( 'landingrates.observeddate BETWEEN DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND CURDATE()' );
            $this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->where ( 'lms.idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->group_by ( 'landingrates.idlandingrate' );
            $query = $this->db->get ();
            
            $data = array ();
            
            $j = 1;
            if ($query->num_rows () > 0) {
                // $j=1;
                foreach ( $query->result_array () as $row ) {
                    if ($row ['counts'] > $trap_mos_count) {
                        $data [$j] ['latitude'] = $row ['latitude'];
                        $data [$j] ['longitude'] = $row ['longitude'];
                        $data [$j] ['idadultsurveillance'] = $row ['idlandingrate'];
                        $data [$j] ['pudate'] = $row ['observeddate'];
                        $data [$j] ['putime'] = $row ['observedtime'];
                        $data [$j] ['count'] = $row ['counts'];
                        $data [$j] ['linktype'] = 'landing';
                        $j ++;
                    }
                }
            }
            
            // Compare Trap Counts to Trap Count Exceeds in Adult Surveillance Table
            $this->db->select ( 'adultsurveillance.idadultsurveillance,adultsurveillance.idtrap,adultsurveillance.pudate,adultsurveillance.putime,traps.latitude,traps.longitude , SUM(adst.count) AS counts' );
            $this->db->from ( 'adultsurveillance' );
            $this->db->join ( 'adultsurveillancedetails AS adst', 'adultsurveillance.idadultsurveillance = adst.idadultsurveillance', 'INNER' );
            $this->db->where ( 'adultsurveillance.pudate BETWEEN DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND CURDATE()' );
            $this->db->join ( 'traps', 'adultsurveillance.idtrap = traps.idtrap', 'LEFT' );
            $this->db->join ( 'locationmosquitospecies AS lms', 'adst.idmosquitospecies = lms.idmosquitospecies', 'INNER' );
            $this->db->where ( 'adultsurveillance.idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->where ( 'lms.idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->group_by ( 'adultsurveillance.idadultsurveillance' );
            // $this->db->order_by('adultsurveillance.idadultsurveillance' , 'DESC');
            
            $query = $this->db->get ();
            
            if ($query->num_rows () > 0) {
                foreach ( $query->result_array () as $row ) {
                    
                    if ($row ['counts'] > $trap_mos_count) {
                        $data [$j] ['latitude'] = $row ['latitude'];
                        $data [$j] ['longitude'] = $row ['longitude'];
                        $data [$j] ['idadultsurveillance'] = $row ['idadultsurveillance'];
                        $data [$j] ['pudate'] = $row ['pudate'];
                        $data [$j] ['putime'] = $row ['putime'];
                        $data [$j] ['count'] = $row ['counts'];
                        $data [$j] ['linktype'] = 'adultsrv';
                        $j ++;
                    }
                }
            }
            
            // Compare Trap Counts to Trap Count Exceeds in Larval Surveillance Table
            $this->db->select ( 'larvalsurveillance.idlarvalsurveillance,larvalsurveillance.idsite,larvalsurveillance.date,larvalsurveillance.time,larvalsurveillance.latitude,larvalsurveillance.longitude,larvalsurveillancedetails.idlarvalsurveillance,sum(larvalsurveillancedetails.count) as counts' );
            $this->db->from ( 'larvalsurveillance' );
            $this->db->join ( 'larvalsurveillancedetails', 'larvalsurveillance.idlarvalsurveillance=larvalsurveillancedetails.idlarvalsurveillance', 'inner' );
            $this->db->join ( 'locationmosquitospecies AS lms', 'larvalsurveillancedetails.idmosquitospecies = lms.idmosquitospecies', 'INNER' );
            $this->db->join ( 'sites', 'larvalsurveillance.idsite = sites.idsite', 'INNER' );
            
            $this->db->where ( 'larvalsurveillance.date BETWEEN DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND CURDATE()' );
            $this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->where ( 'lms.idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->group_by ( 'larvalsurveillance.idlarvalsurveillance' );
            $query = $this->db->get ();
            // echo $this->db->last_query();
            
            if ($query->num_rows () > 0) {
                foreach ( $query->result_array () as $row ) {
                    if ($row ['counts'] > $trap_mos_count) {
                        $data [$j] ['latitude'] = $row ['latitude'];
                        $data [$j] ['longitude'] = $row ['longitude'];
                        $data [$j] ['idadultsurveillance'] = $row ['idlarvalsurveillance'];
                        $data [$j] ['pudate'] = $row ['date'];
                        $data [$j] ['putime'] = $row ['time'];
                        $data [$j] ['count'] = $row ['counts'];
                        $data [$j] ['linktype'] = 'larvalsrv';
                        $j ++;
                    }
                }
                
                // return $data;
            }
            
            // Compare Trap Counts to Trap Count Exceeds in Larval Treatment Table
            $this->db->select ( 'larvaltreatments.idlarvaltreatment,larvaltreatments.latitude, larvaltreatments.longitude, larvaltreatments.date , larvaltreatments.time , SUM(larvatreatmentdetails.count) AS counts' );
            $this->db->from ( 'larvaltreatments' );
            $this->db->join ( 'sites', 'larvaltreatments.idsite = sites.idsite', 'LEFT' );
            $this->db->join ( 'larvatreatmentdetails', 'larvaltreatments.idlarvaltreatment = larvatreatmentdetails.idlarvaltreatment', 'INNER' );
            $this->db->join ( 'locationmosquitospecies AS lms', 'larvatreatmentdetails.idmosquitospecies = lms.idmosquitospecies', 'INNER' );
            $this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->where ( 'larvaltreatments.date BETWEEN DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND CURDATE()' );
            $this->db->where ( 'lms.idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->group_by ( 'larvaltreatments.idlarvaltreatment' );
            $query = $this->db->get ();
            
            // echo $this->db->last_query();
            if ($query->num_rows () > 0) {
                foreach ( $query->result_array () as $row ) {
                    if ($row ['counts'] > $trap_mos_count) {
                        $data [$j] ['latitude'] = $row ['latitude'];
                        $data [$j] ['longitude'] = $row ['longitude'];
                        $data [$j] ['idadultsurveillance'] = $row ['idlarvaltreatment'];
                        $data [$j] ['pudate'] = $row ['date'];
                        $data [$j] ['putime'] = $row ['time'];
                        $data [$j] ['count'] = $row ['counts'];
                        $data [$j] ['linktype'] = 'larvaltrtmnt';
                        $j ++;
                    }
                }
                
                // return $data;
            }
            // $data = array();
            
            return $data;
            // print'<pre>';
            // print_r($data);
            // die;
        }
        public function getTrapCountVector() {
            // get trap count
            $this->db->select ( 'trapcountvector' );
            $this->db->from ( 'locationpreferences' );
            $this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
            $query = $this->db->get ();
            if($query->num_rows() > 0){
                $count = $query->first_row ();
            }
            else {
                return false;
            }
            $trap_mos_count = $count->trapcountvector;
            if (empty ( $trap_mos_count )) {
                return false;
            }
            
            // Compare Trap Counts to Trap Count Exceeds in Adult Surveillance Table
            $this->db->select ( 'adultsurveillance.idadultsurveillance,adultsurveillance.idtrap,adultsurveillance.pudate,adultsurveillance.putime,traps.latitude,traps.longitude , SUM(adst.count) AS counts' );
            $this->db->from ( 'adultsurveillance' );
            $this->db->join ( 'adultsurveillancedetails AS adst', 'adultsurveillance.idadultsurveillance = adst.idadultsurveillance', 'LEFT' );
            $this->db->join ( 'traps', 'adultsurveillance.idtrap = traps.idtrap', 'LEFT' );
            $this->db->join ( 'locationvectorspecies AS lms', 'adst.idmosquitospecies = lms.idlocationmosquitospecies', 'LEFT' );
            $this->db->where ( 'adultsurveillance.pudate BETWEEN DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND CURDATE()' );
            $this->db->where ( 'adultsurveillance.idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->where ( 'lms.idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->group_by ( 'adultsurveillance.idadultsurveillance' );
            // $this->db->order_by('adultsurveillance.idadultsurveillance' , 'DESC');
            
            $query = $this->db->get ();
            $data = array ();
            // echo $this->db->last_query()."<br><br>";
            $j = 1;
            if ($query->num_rows () > 0) {
                foreach ( $query->result_array () as $row ) {
                    if ($row ['counts'] > $trap_mos_count) {
                        $data [$j] ['latitude'] = $row ['latitude'];
                        $data [$j] ['longitude'] = $row ['longitude'];
                        $data [$j] ['idadultsurveillance'] = $row ['idadultsurveillance'];
                        $data [$j] ['pudate'] = $row ['pudate'];
                        $data [$j] ['putime'] = $row ['putime'];
                        $data [$j] ['count'] = $row ['counts'];
                        $data [$j] ['linktype'] = 'adultsrv';
                        $j ++;
                    }
                }
            }
            
            // Compare Trap Counts to Trap Count Exceeds in Larval Surveillance Table
            $this->db->select ( 'larvalsurveillance.idlarvalsurveillance,larvalsurveillance.idsite,larvalsurveillance.date,larvalsurveillance.time,larvalsurveillance.latitude,larvalsurveillance.longitude,larvalsurveillancedetails.idlarvalsurveillance,sum(larvalsurveillancedetails.count) as counts' );
            $this->db->from ( 'larvalsurveillance' );
            $this->db->join ( 'larvalsurveillancedetails', 'larvalsurveillance.idlarvalsurveillance=larvalsurveillancedetails.idlarvalsurveillance', 'LEFT' );
            $this->db->join ( 'locationvectorspecies AS lms', 'larvalsurveillancedetails.idmosquitospecies = lms.idlocationmosquitospecies', 'LEFT' );
            $this->db->join ( 'sites', 'larvalsurveillance.idsite = sites.idsite', 'LEFT' );
            $this->db->where ( 'larvalsurveillance.date BETWEEN DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND CURDATE()' );
            $this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->where ( 'lms.idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->group_by ( 'larvalsurveillance.idlarvalsurveillance' );
            $query = $this->db->get ();
            // echo $this->db->last_query();
            
            if ($query->num_rows () > 0) {
                foreach ( $query->result_array () as $row ) {
                    if ($row ['counts'] > $trap_mos_count) {
                        $data [$j] ['latitude'] = $row ['latitude'];
                        $data [$j] ['longitude'] = $row ['longitude'];
                        $data [$j] ['idadultsurveillance'] = $row ['idlarvalsurveillance'];
                        $data [$j] ['pudate'] = $row ['date'];
                        $data [$j] ['putime'] = $row ['time'];
                        $data [$j] ['count'] = $row ['counts'];
                        $data [$j] ['linktype'] = 'larvalsrv';
                        $j ++;
                    }
                }
                
                // return $data;
            }
            
            // Compare Trap Counts to Trap Count Exceeds in Larval Treatment Table
            $this->db->select ( 'larvaltreatments.idlarvaltreatment,larvaltreatments.latitude, larvaltreatments.longitude, larvaltreatments.date , larvaltreatments.time , SUM(larvatreatmentdetails.count) AS counts' );
            $this->db->from ( 'larvaltreatments' );
            $this->db->join ( 'sites', 'larvaltreatments.idsite = sites.idsite', 'LEFT' );
            $this->db->join ( 'larvatreatmentdetails', 'larvaltreatments.idlarvaltreatment = larvatreatmentdetails.idlarvaltreatment', 'LEFT' );
            $this->db->join ( 'locationvectorspecies AS lms', 'larvatreatmentdetails.idmosquitospecies = lms.idlocationmosquitospecies', 'LEFT' );
            $this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->where ( 'larvaltreatments.date BETWEEN DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND CURDATE()' );
            $this->db->where ( 'lms.idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->group_by ( 'larvaltreatments.idlarvaltreatment' );
            $query = $this->db->get ();
            
            // echo $this->db->last_query();
            if ($query->num_rows () > 0) {
                foreach ( $query->result_array () as $row ) {
                    if ($row ['counts'] > $trap_mos_count) {
                        $data [$j] ['latitude'] = $row ['latitude'];
                        $data [$j] ['longitude'] = $row ['longitude'];
                        $data [$j] ['idadultsurveillance'] = $row ['idlarvaltreatment'];
                        $data [$j] ['pudate'] = $row ['date'];
                        $data [$j] ['putime'] = $row ['time'];
                        $data [$j] ['count'] = $row ['counts'];
                        $data [$j] ['linktype'] = 'larvaltrtmnt';
                        $j ++;
                    }
                }
                
                // return $data;
            }
            // $data = array();
            $this->db->select ( 'landingrates.idlandingrate,landingrates.idsite,landingrates.observeddate,landingrates.observedtime,landingrates.latitude,landingrates.longitude,landingrates.countobserved,sum(landingratedetails.count) as counts' );
            $this->db->from ( 'landingrates' );
            $this->db->join ( 'landingratedetails', 'landingrates.idlandingrate=landingratedetails.idlandingrate', 'LEFT' );
            $this->db->join ( 'sites', 'landingrates.idsite=sites.idsite', 'LEFT' );
            $this->db->join ( 'locationvectorspecies AS lms', 'landingratedetails.idlocationvectorspecies = lms.idlocationmosquitospecies', 'LEFT' );
            $this->db->where ( 'landingrates.observeddate BETWEEN DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND CURDATE()' );
            $this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->where ( 'lms.idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->group_by ( 'landingrates.idlandingrate' );
            $query = $this->db->get ();
            
            // echo $this->db->last_query()." ".$trap_mos_count;
            // print('<pre>');
            // print_r($query->result_array());
            if ($query->num_rows () > 0) {
                // $j=1;
                foreach ( $query->result_array () as $row ) {
                    if ($row ['counts'] > $trap_mos_count) {
                        $data [$j] ['latitude'] = $row ['latitude'];
                        $data [$j] ['longitude'] = $row ['longitude'];
                        $data [$j] ['idlandingrate'] = $row ['idlandingrate'];
                        $data [$j] ['pudate'] = $row ['observeddate'];
                        $data [$j] ['putime'] = $row ['observedtime'];
                        $data [$j] ['count'] = $row ['counts'];
                        $data [$j] ['linktype'] = 'landing';
                        $j ++;
                    }
                }
                // echo '<pre>';
                // print_r($data);
                // die;
                // return $data;
            }
            // print'<pre>';
            // print_r($data);
            // die;
        }
        public function getTrapCountVector_I() {
            // get trap count
            $this->db->select ( 'trapcountvector' );
            $this->db->from ( 'locationpreferences' );
            $this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
            $query = $this->db->get ();
            $count = $query->first_row ();
            $trap_mos_count = $count->trapcountvector;
            if (empty ( $trap_mos_count )) {
                return false;
            }
            
            // Counts in Larval Surveillance
            $this->db->select ( 'larvalsurveillance.idlarvalsurveillance,larvalsurveillance.idsite,larvalsurveillance.date,larvalsurveillance.time,larvalsurveillance.latitude,larvalsurveillance.longitude,larvalsurveillancedetails.idlarvalsurveillance,sum(larvalsurveillance.totalcount) as counts' );
            $this->db->from ( 'larvalsurveillance' );
            $this->db->join ( 'larvalsurveillancedetails', 'larvalsurveillance.idlarvalsurveillance=larvalsurveillancedetails.idlarvalsurveillance', 'inner' );
            $this->db->join ( 'sites', 'larvalsurveillance.idsite=sites.idsite', 'inner' );
            $this->db->group_by ( 'larvalsurveillance.idlarvalsurveillance' );
            $this->db->where ( 'larvalsurveillance.date BETWEEN DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND CURDATE()' );
            $this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
            $query = $this->db->get ();
            $data = array ();
            if ($query->num_rows () > 0) {
                $j = 1;
                foreach ( $query->result_array () as $row ) {
                    
                    if ($row ['counts'] >= $trap_mos_count) {
                        $data [$j] ['latitude'] = $row ['latitude'];
                        $data [$j] ['longitude'] = $row ['longitude'];
                        $data [$j] ['idlarvalsurveillance'] = $row ['idlarvalsurveillance'];
                        $data [$j] ['pudate'] = $row ['date'];
                        $data [$j] ['putime'] = $row ['time'];
                        $data [$j] ['count'] = $row ['counts'];
                        $j ++;
                    }
                }
                // print_r($data);
                return $data;
            }
        }
        
        // get data from weathor table
        public function getCountRain() {
            // Get rainfall thresholds
            $this->db->select ( 'rainfallexceeds' );
            $this->db->from ( 'locationpreferences' );
            $this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
            $query = $this->db->get ();
            if($query->num_rows() > 0){
                $count = $query->first_row ();
            }
            else {
                return false;
            }
            $trap_mos_count = $count->rainfallexceeds;
            
            if (empty ( $trap_mos_count )) {
                return false;
            }
            
            // Get Weather Sensor information and compare to preferences
            $this->db->select ( 'weather.idweather,sites.idsite,weather.date,weather.hightide_time,weathersensors.latitude,weathersensors.longitude,weathersensors.idweathersensor,sum(weather.rainfall) as counts' );
            $this->db->from ( 'weather' );
            $this->db->join ( 'weathersensors', 'weather.idweathersensor=weathersensors.idweathersensor', 'inner' );
            $this->db->join ( 'sites', 'weathersensors.idsite=sites.idsite', 'inner' );
            $this->db->where ( 'weather.date BETWEEN DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND CURDATE()' );
            $this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->group_by ( 'weathersensors.idweathersensor' );
            $query = $this->db->get ();
            $data = array ();
            // echo $this->db->last_query()."<br>";
            if ($query->num_rows () > 0) {
                $j = 1;
                foreach ( $query->result_array () as $row ) {
                    
                    if ($row ['counts'] > $trap_mos_count) {
                        $data [$j] ['latitude'] = $row ['latitude'];
                        $data [$j] ['longitude'] = $row ['longitude'];
                        $data [$j] ['idweather'] = $row ['idweather'];
                        $data [$j] ['pudate'] = $row ['date'];
                        $data [$j] ['putime'] = $row ['hightide_time'];
                        $data [$j] ['count'] = $row ['counts'];
                        $data [$j] ['linktype'] = 'weather';
                        $j ++;
                    }
                }
                // print_r($data);
                return $data;
            }
        }
        
        // Inspection Performance over 7 days
        public function getLarvaeCountRange() {
            $this->db->select ( 'la.date,count(la.idlarvalsurveillance) as "total"' );
            $this->db->from ( 'larvalsurveillance as la' );
            // $this->db->join('larvalsurveillancedetails as ld','la.idlarvalsurveillance=ld.idlarvalsurveillance','inner');
            $this->db->join ( 'sites as s', 'la.idsite = s.idsite', 'inner' );
            $this->db->where ( 'la.date BETWEEN DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND CURDATE()' );
            $this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->group_by ( 'la.date' );
            $this->db->order_by ( 'la.date ASC' );
            $query = $this->db->get ();
            $sdata = $tdata = array ();
            $return = '';
            if ($query->num_rows () > 0) {
                
                foreach ( $query->result_array () as $row ) {
                    $sdata [strtotime ( $row ['date'] )] [] = $row ['date'];
                    $sdata [strtotime ( $row ['date'] )] [] = $row ['total'];
                }
            }
            
            $this->db->select ( 'lt.date, count(lt.idlarvaltreatment) as "total"' );
            $this->db->from ( 'larvaltreatments as lt' );
            // $this->db->join('larvatreatmentdetails as ltd','lt.idlarvaltreatment=ltd.idlarvaltreatment','inner');
            $this->db->join ( 'sites as s', 'lt.idsite = s.idsite', 'inner' );
            $this->db->where ( 'lt.date BETWEEN DATE_SUB(CURDATE(), INTERVAL 7 DAY) AND CURDATE()' );
            $this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->group_by ( 'lt.date' );
            $this->db->order_by ( 'lt.date ASC' );
            $query = $this->db->get ();
            
            $return = '';
            if ($query->num_rows () > 0) {
                
                foreach ( $query->result_array () as $row ) {
                    $tdata [strtotime ( $row ['date'] )] [] = $row ['date'];
                    $tdata [strtotime ( $row ['date'] )] [] = $row ['total'];
                }
            }
            
            foreach ( $sdata as $key => $value ) {
                if (in_array ( $key, array_keys ( $tdata ) )) {
                    $sdata [$key] [] = $tdata [$key] [1];
                    unset ( $tdata [$key] );
                }
            }
            
            foreach ( $sdata as $key => $value ) {
                if (count ( $value ) <= 2)
                    $sdata [$key] [] = 0;
            }
            $tdata1 = array ();
            foreach ( $tdata as $key => $value ) {
                if (count ( $value ) <= 2) {
                    $tdata1 [$key] [] = $tdata [$key] [0];
                    $tdata1 [$key] [] = 0;
                    $tdata1 [$key] [] = $tdata [$key] [1];
                }
            }
            
            $data = array_merge ( $sdata, $tdata1 );
            if (count ( $data ) > 0) {
                
                foreach ( $data as $key => $value ) {
                    $return .= "['{$value[0]}',{$value[1]},{$value[2]}],";
                }
            }
            $return = rtrim ( $return, ',' );
            if (empty ( $return ))
                $return = '["' . date ( 'Y' ) . '",0,0]';
                return $return;
        }
        
        // Surveillance over 14 days - Trap Types and Nights
        /**
         * Hidden Formula
         * Lets say you have 5 traps with trap type (propane)
         * You collect 20 mosquitoes in each one total
         * You multiply 5 x 20 = 100
         * Then you divide this number (100) by TRAP TYPE NIGHTS - Set Date Time and Pickup Date Time - 12-24 hour period defines a day
         */
        public function getSurveillanceMapData() {
            $this->db->select ( 'a.idadultsurveillance ,a.setdate , a.pudate ,ABS(to_days(`a`.`pudate`) - to_days(`a`.`setdate`)) AS `trapnights` , traps.idtrap , SUM(adst.count) AS count, traps.trap ,traps.idtraptype , tt.traptype , tt.idtraptype' );
            $this->db->from ( 'adultsurveillance AS a' );
            $this->db->join ( 'traps', 'traps.idtrap = a.idtrap', 'INNER' );
            $this->db->join ( 'traptypes AS tt', 'traps.idtraptype = tt.idtraptype', 'LEFT' );
            $this->db->join ( 'adultsurveillancedetails AS adst', 'a.idadultsurveillance = adst.idadultsurveillance', 'LEFT' );
            $this->db->where ( 'a.idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->where ( 'a.pudate BETWEEN DATE_SUB(CURDATE(), INTERVAL 14 DAY) AND CURDATE()' );
            $this->db->group_by ( 'a.idadultsurveillance' );
            $this->db->order_by ( 'a.pudate', 'DESC' );
            $query = $this->db->get ();
            // echo $this->db->last_query();
            $date = array ();
            $traptype = array ();
            $datetrap = array ();
            $trpstr = '';
            $tmpdate = '';
            $result = array ();
            $return = '';
            if ($query->num_rows () > 0) {
                // print'<pre>';
                // print_r($query->result_array());
                // die;
                $c = 0;
                $i = 0;
                foreach ( $query->result_array () as $row ) {
                    if ($row ['traptype'] == $tmpdate) {
                        ++ $c;
                        $data [$i] [$c] = $row;
                    } else {
                        $i ++;
                        $c = 0;
                        $data [$i] [$c] = $row;
                    }
                    $tmpdate = $row ['traptype'];
                }
            }
            $tmpdate = '';
            $i = 0;
            $c = 0;
            $trpnght = 0;
            // print'<pre>';
            // print_r($data);
            //
            if (! empty ( $data ))
                foreach ( $data as $row ) {
                    $tmpdate = '';
                    foreach ( $row as $key ) {
                        if ($key ['pudate'] == $tmpdate) {
                            $count += $key ['count'];
                            if ($key ['trapnights'] == 0)
                                $trpnght += 1;
                                else
                                    $trpnght += $key ['trapnights'];
                        } else {
                            $i ++;
                            $count = $key ['count'];
                            if ($key ['trapnights'] == 0)
                                $trpnght = 1;
                                else
                                    $trpnght = $key ['trapnights'];
                        }
                        
                        $result [$i] ['traptype'] = $key ['traptype'];
                        $result [$i] ['date'] = $key ['pudate'];
                        $result [$i] ['trapnight'] = $trpnght;
                        $result [$i] ['count'] = $count;
                        
                        $tmpdate = $key ['pudate'];
                    }
                }
            
            if (! empty ( $result )) {
                $data = array ();
                foreach ( $result as $row ) {
                    $trapnight = $row ['trapnight'];
                    if ($trapnight == 0) {
                        $trapnight = 1;
                    }
                    $avg = floatval ( $row ['count'] / $trapnight );
                    $data [$i] = $row;
                    $data [$i] ['avg'] = $avg;
                    $i ++;
                }
                $result = $data;
                
                foreach ( $result as $row ) {
                    if (! in_array ( $row ['traptype'], $traptype )) {
                        $trpstr .= "'" . $row ['traptype'] . "',";
                        $traptype [] = $row ['traptype'];
                    }
                    
                    if (! in_array ( $row ['date'], $date )) {
                        $date [] = $row ['date'];
                    }
                }
                
                if (! empty ( $date )) {
                    $count = count ( $traptype );
                    foreach ( $date as $row ) {
                        $data = '';
                        for($c = 0; $c < $count; $c ++) {
                            // echo $row." ".$traptype[$c]."<br>";
                            $data .= $this->getTrapDate ( $result, $row, $traptype [$c] ) . ',';
                        }
                        $data = trim ( $data, ',' );
                        
                        $return .= "['" . $row . "'," . $data . "],";
                        // echo "<br>============================<br>";
                    }
                }
            }
            
            // print'<pre>';
            // print_r($result);
            // print_r($date);
            // echo $return;
            // die;
            $data = array ();
            $data ['trapname'] = trim ( $trpstr, ',' );
            $data ['datetrap'] = trim ( $return, ',' );
            return $data;
        }
        public function getTrapDate($traptype, $date, $trap) {
            foreach ( $traptype as $row ) {
                // echo $row['date']." ".$date." && ".$trap." ".$row['traptype']."<br>";
                if ($row ['date'] == $date && $trap == $row ['traptype'])
                    return $row ['avg'];
            }
            return 0;
        }
        public function getSurveillanceMapData_I() {
            $return = '';
            $tnight = $it_trap = $result_a = array ();
            $this->db->select ( 'traps.idtraptype' );
            $this->db->distinct ( 'traps.idtraptype' );
            $this->db->from ( 'adultsurveillance' );
            $this->db->where ( 'adultsurveillance.idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->join ( 'traps', 'traps.idtrap = adultsurveillance.idtrap', 'INNER' );
            $this->db->where ( 'adultsurveillance.pudate BETWEEN DATE_SUB(CURDATE(), INTERVAL 14 DAY) AND CURDATE()' );
            $this->db->order_by ( 'pudate', "asc" );
            
            $query = $this->db->get ();
            
            if ($query->num_rows () > 0) {
                foreach ( $query->result_array () as $row ) {
                    $it_trap [] = $row ['idtraptype'];
                    // $tnight[] = $row['trapnights'];
                }
            }
            //
            $this->db->select ( 'pudate,setdate,traps.idtraptype,idadultsurveillance,(to_days(`adultsurveillance`.`pudate`) - to_days(`adultsurveillance`.`setdate`)) AS `trapnights`' );
            $this->db->from ( 'adultsurveillance' );
            $this->db->where ( 'adultsurveillance.idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->where ( 'pudate BETWEEN DATE_SUB(CURDATE(), INTERVAL 14 DAY) AND CURDATE()' );
            $this->db->join ( 'traps', 'traps.idtrap = adultsurveillance.idtrap', 'INNER' );
            
            $this->db->order_by ( 'pudate', 'asc' );
            $query = $this->db->get ();
            if ($query->num_rows () > 0) {
                foreach ( $query->result_array () as $row ) {
                    $count_n = $count_n1 = 0;
                    // echo $row['trapnights']."<br>";
                    $idadult = "";
                    $tnight = $row ['trapnights'];
                    
                    if ($row ['pudate'] == $row ['setdate'])
                        $tnight = 1;
                        $this->db->select ( '*' );
                        $this->db->from ( 'adultsurveillance' );
                        $this->db->where ( 'idadultsurveillance', $row ['idadultsurveillance'] );
                        $q = $this->db->get ();
                        if ($q->num_rows () > 0) {
                            $idadult = $q->result_array ();
                            $idadult = $idadult [0] ['idadultsurveillance'];
                            // $ttttt = count();
                            // $daycount = $count->rainfallexceeds;
                        }
                        
                        // if(empty($idadult))
                        // $idadult = 'sum(totalcount) as "total"';
                        //
                        // else
                        // $idadult = '(sum(totalcount)/'.$idadult.')as "total"';
                            $idadult = '( sum(totalcount) / ' . $tnight . ') as "total"';
                            $this->db->select ( $idadult );
                            $this->db->from ( 'adultsurveillance' );
                            $this->db->where ( 'idadultsurveillance', $row ['idadultsurveillance'] );
                            $this->db->group_by ( 'idadultsurveillance' );
                            $query1 = $this->db->get ();
                            if ($query1->num_rows () > 0) {
                                foreach ( $query1->result_array () as $row1 ) {
                                    $count_n1 = $row1 ['total'];
                                }
                            }
                            
                            // echo $count_n1."<br>";
                            if (in_array ( strtotime ( $row ['pudate'] ), array_keys ( $result_a ) )) {
                                foreach ( $it_trap as $value ) {
                                    if ($value == $row ['idtraptype'])
                                        $result_a [strtotime ( $row ['pudate'] )] [$value] = $count_n1;
                                }
                            } else {
                                $result_a [strtotime ( $row ['pudate'] )] ['date'] = $row ['pudate'];
                                $result_a [strtotime ( $row ['pudate'] )] ['sdate'] = $row ['setdate'];
                                foreach ( $it_trap as $value ) {
                                    if ($value == $row ['idtraptype'])
                                        $result_a [strtotime ( $row ['pudate'] )] [$value] = $count_n1;
                                        else
                                            $result_a [strtotime ( $row ['pudate'] )] [$value] = $count_n;
                                }
                            }
                            // echo $result_a."<br>";
                }
            }
            
            $id_tllist = implode ( ',', $it_trap );
            $t_list = '';
            
            // print'<pre>';
            // print_r($it_trap);
            // print_r($result_a);
            // print_r($tnight);
            // die;
            $result_c = 0;
            // echo $id_tllist;
            
            if (! empty ( $it_trap )) {
                foreach ( $it_trap as $key => $val ) {
                    $this->db->select ( 'tt.traptype AS trap' );
                    $this->db->from ( 'traptypes AS tt' );
                    $this->db->where ( 'tt.idtraptype', $val );
                    
                    $query = $this->db->get ();
                    
                    // echo $this->db->last_query();
                    if ($query->num_rows () > 0) {
                        foreach ( $query->result_array () as $row ) {
                            
                            $t_list .= '\'' . $row ['trap'] . '\',';
                            $result_c ++;
                        }
                    }
                }
            } else
                $t_list = '\'N/A\'';
                
                $t_list = rtrim ( $t_list, ',' );
                $return = "['Date',$t_list],";
                $result_c ++;
                $return1 = '';
                // return rtrim($return,',');
                // echo $return."<br>";
                // die;
                $j = 0;
                foreach ( $result_a as $key => $value ) {
                    $return1 .= "['{$value['date']}',";
                    $return2 = '';
                    foreach ( $it_trap as $val ) {
                        $return2 .= "$value[$val],";
                    }
                    $return2 = rtrim ( $return2, ',' ) . "],";
                    $return1 .= $return2;
                }
                $return1 = rtrim ( $return1, ',' );
                if (empty ( $return1 )) {
                    $return1 = "[";
                    $ex = explode ( ',', rtrim ( $return, ',' ) );
                    for($i = 0; $i < count ( $ex ); $i ++) {
                        if ($i == 0)
                            $return1 .= "'" . date ( 'Y' ) . "',";
                            else
                                $return1 .= "0,";
                    }
                    $return1 = rtrim ( $return1, ',' ) . "]";
                    // $return1=rtrim($return1,',');
                }
                // echo $return.$return1;
                // die;
                return $return . $return1;
        }
        public function getServiceRequestMapData() {
            $s_req = array ();
            $this->db->select ( 'idservicerequest,opendate,total_sr,idlocation' );
            $this->db->from ( 'srchart' );
            $this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
            $this->db->where ( 'opendate BETWEEN DATE_SUB(CURDATE(), INTERVAL 30 DAY) AND CURDATE()' );
            $this->db->order_by ( 'opendate' );
            $query = $this->db->get ();
            if ($query->num_rows () > 0) {
                foreach ( $query->result_array () as $row ) {
                    
                    if (in_array ( strtotime ( $row ['opendate'] ), array_keys ( $s_req ) )) {
                        $s_req [strtotime ( $row ['opendate'] )] ['count'] = ( int ) ($s_req [strtotime ( $row ['opendate'] )] ['count']);
                    } else {
                        $s_req [strtotime ( $row ['opendate'] )] ['date'] = $row ['opendate'];
                        $s_req [strtotime ( $row ['opendate'] )] ['count'] = $row ['total_sr'];
                    }
                }
            }
            $return = '';
            if (count ( $s_req ) > 0) {
                foreach ( $s_req as $value ) {
                    $return .= "['{$value['date']}',{$value['count']}],";
                }
            }
            $return = rtrim ( $return, ',' );
            if (empty ( $return ))
                $return = '["' . date ( 'Y' ) . '",0]';
                return $return;
        }
        
        /**
         * Function to get Zoom Level
         */
        public function getzoom($idlocation = '') {
            if (empty ( $idlocation ))
                return false;
                
                if (! empty ( $idlocation )) {
                    $this->db->select ( '*' );
                    $this->db->from ( 'locations' );
                    $this->db->where ( 'idlocation', $idlocation );
                    $query = $this->db->get ();
                    if ($query->num_rows () > 0) {
                        $zoom = $query->result_array ();
                        // print'<pre>';
                        // print_r($zoom);
                        // die;
                        $zoom = ! empty ( $zoom [0] ['GoogleZoom'] ) ? $zoom [0] ['GoogleZoom'] : '0';
                    }
                }
                return $zoom;
        }
        
        /**
         * Function to save User's Acceptance Info
         */
        public function saveAcceptance($data = '') {
            if (empty ( $data ))
                return false;
                
                $this->db->insert ( 'user_acceptance', $data );
                $id = $this->db->insert_id ();
                
                if (empty ( $id ))
                    return false;
                    
                    return true;
        }
        
        /**
         * Function to check User's Acceptance
         */
        public function checkAcceptance($iduser = '') {
            if (empty ( $iduser ))
                return false;
                
                $this->db->select ( '*' );
                $this->db->from ( 'user_acceptance' );
                $this->db->where ( 'iduser', $iduser );
                
                $query = $this->db->get ();
                
                if ($query->num_rows () > 0)
                    return true;
                    
                    return false;
        }
        
        /**
         * Function to save security token
         */
        public function saveToken($data = '') {
            if (empty ( $data ))
                return false;
                
                $flag = $this->getToken($data['iduser']);
                
                if( !$flag) {
                    $this->db->insert ( 'login_token', $data );
                    $id = $this->db->insert_id ();
                    
                    if (empty ( $id ))
                        return false;
                        $flag = $data['securityToken'];
                }
                return $flag;
        }
        
        /**
         * Function to get security token
         */
        public function getToken($iduser = '') {
            if (empty ( $iduser ))
                return false;
                
                $this->db->select ( 'securityToken' );
                $this->db->from ( 'login_token' );
                $this->db->where ( 'iduser', $iduser );
                
                $query = $this->db->get ();
                
                if ($query->num_rows () > 0)
                    return $query->row('securityToken');
                    
                    return false;
        }
    }
    ?>