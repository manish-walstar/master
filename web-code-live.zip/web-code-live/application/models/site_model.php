<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Site_model extends CI_Model {
	public $str = "";
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}

	public function addclosedwardAjax()
	{
		$data ['dateclosed'] = $this->input->post('closedDate');
		$data ['idsite'] = $this->input->post('wardID');
		$data ['idlocation'] = $this->session->userdata ( 'idlocation' );

		$this->db->insert ( 'wardsclosed', $data );
		$id = $this->db->insert_id ();
		
		$data1 ['active'] = '0';
		
		$this->db->where ( 'idsite', $this->input->post('wardID'));
		$this->db->update ( 'sites', $data1 );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;

	}

	/**
	 * Function to Add a new Site Using Ajax
	 * Returns ID of newly added site
	 */
	public function addSiteUsingAjax($message = '') {
		$idstate = $this->input->post ( 'state' );
		$landing = $this->input->post ( 'landingrate_site' );
		$site_of_interest = $this->input->post ( 'site_of_interest' );
		$sitecord = $this->input->post ( 'sitecord' );
		$larval = $this->input->post ( 'larval_site' );
		$adult = $this->input->post ( 'adult_site' );
		$apiary = $this->input->post ( 'apiary' );
		$contact = $this->input->post ( 'contact_before_spray' );
		$organic_farm = $this->input->post ( 'organic_farm' );
		$nospray = $this->input->post ( 'nospray' );
		$water_of_us = $this->input->post ( 'water_of_us' );
		$iduomwatersize = $this->input->post ( 'iduomwatersize' );
		$endangered_species = $this->input->post ( 'endangered_species' );
		$idzone = $this->input->post ( 'zone' );
		
		$data ['site'] = $this->input->post ( 'site_name' );
		$data ['idsitetype'] = $this->input->post ( 'site_type' );
		$data ['maplabel'] = $this->input->post ( 'maplabel' );
		$data ['address1'] = $this->input->post ( 'street1' );
		$data ['address2'] = $this->input->post ( 'street2' );
		$data ['city'] = $this->input->post ( 'city' );
		$data ['idstate'] = ! empty ( $idstate ) ? $idstate : '0';
		$data ['postalcode'] = $this->input->post ( 'postalcode' );
		$data ['latitude'] = $this->input->post ( 'latitude' );
		$data ['longitude'] = $this->input->post ( 'longitude' );
		$data ['pdop'] = $this->input->post ( 'pdop' );
		$data ['manphone'] = $this->input->post ( 'manphone' );
		$data ['alternatephone'] = $this->input->post ( 'alternatephone' );
		$data ['faxnumber'] = $this->input->post ( 'faxnumber' );
		$data ['idlocation'] = $this->session->userdata ( 'idlocation' );
		$data ['active'] = '1';
		$data ['flag'] = 1;
		$data ['idzone'] = ! empty ( $idzone ) ? $idzone : '0';
		$data ['landingrate_site'] = ! empty ( $landing ) ? '1' : '0';
		$data ['larval_site'] = ! empty ( $larval ) ? '1' : '0';
		$data ['adult_site'] = ! empty ( $adult ) ? '1' : '0';
		$data ['apiary'] = ! empty ( $apiary ) ? '1' : '0';
		$data ['contact_before_spray'] = ! empty ( $contact ) ? '1' : '0';
		$data ['organic_farm'] = ! empty ( $organic_farm ) ? '1' : '0';
		$data ['site_of_interest'] = ! empty ( $site_of_interest ) ? $site_of_interest : '0';
		$data ['nospray'] = ! empty ( $nospray ) ? '1' : '0';
		$data ['water_of_us'] = ! empty ( $water_of_us ) ? '1' : '0';
		$data ['idsitegroup'] = $this->input->post ( 'idsitegroup' );
		
		if (! empty ( $water_of_us )) {
			$data ['watersize'] = $this->input->post ( 'watersize' );
			$data ['iduomwatersize'] = ! empty ( $iduomwatersize ) ? $iduomwatersize : '0';
		} else {
			$data ['watersize'] = '';
			$data ['iduomwatersize'] = '0';
		}
		
		$data ['endangered_species'] = ! empty ( $endangered_species ) ? '1' : '0';
		
		if (! empty ( $endangered_species ))
			$data ['site_comments'] = $this->input->post ( 'site_comments' );
		else
			$data ['site_comments'] = '';
		
		if (! empty ( $sitecord )) {
			$data ['sitecord'] = $sitecord;
		} else {
			$data ['sitecord'] = '';
		}
		// print'<pre>';
		// print_r($data);
		// die;
		$this->db->insert ( 'sites', $data );
		$id = $this->db->insert_id ();
		
		if (empty ( $id ))
			return false;
		
		return $id;
	}
	
	/**
	 * Function to Add a new Site
	 */
	public function addSite($message = '') {
		$sitecord = $this->input->post ( 'sitecord' );
		$idstate = $this->input->post ( 'state' );
		$idloc = $this->session->userdata ( 'idlocation' );
		$idsitetype = $this->input->post ( 'site_type' );
		$active = $this->input->post ( 'active' );
		$landing = $this->input->post ( 'landingrate_site' );
		$site_of_interest = $this->input->post ( 'site_of_interest' );
		$larval = $this->input->post ( 'larval_site' );
		$adult = $this->input->post ( 'adult_site' );
		$apiary = $this->input->post ( 'apiary' );
		$contact = $this->input->post ( 'contact_before_spray' );
		$organic_farm = $this->input->post ( 'organic_farm' );
		$nospray = $this->input->post ( 'nospray' );
		$water_of_us = $this->input->post ( 'water_of_us' );
		$iduomwatersize = $this->input->post ( 'iduomwatersize' );
		$endangered_species = $this->input->post ( 'endangered_species' );
		$idzone = $this->input->post ( 'zone' );
		
		$data ['site'] = $this->input->post ( 'site_name' );
		$data ['idsitetype'] = ! empty ( $idsitetype ) ? $idsitetype : '0';
		$data ['maplabel'] = $this->input->post ( 'maplabel' );
		$data ['address1'] = $this->input->post ( 'street1' );
		$data ['address2'] = $this->input->post ( 'street2' );
		$data ['city'] = $this->input->post ( 'city' );
		$data ['idstate'] = ! empty ( $idstate ) ? $idstate : '0';
		$data ['postalcode'] = $this->input->post ( 'postalcode' );
		$data ['latitude'] = $this->input->post ( 'latitude' );
		$data ['longitude'] = $this->input->post ( 'longitude' );
		$data ['pdop'] = $this->input->post ( 'pdop' );
		$data ['manphone'] = $this->input->post ( 'manphone' );
		$data ['alternatephone'] = $this->input->post ( 'alternatephone' );
		$data ['faxnumber'] = $this->input->post ( 'faxnumber' );
		$data ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
		$data ['active'] = '1';
		$data ['idzone'] = ! empty ( $idzone ) ? $idzone : '0';
		$data ['site_of_interest'] = ! empty ( $site_of_interest ) ? $site_of_interest : '0';
		$data ['landingrate_site'] = ! empty ( $landing ) ? '1' : '0';
		$data ['larval_site'] = ! empty ( $larval ) ? '1' : '0';
		$data ['adult_site'] = ! empty ( $adult ) ? '1' : '0';
		$data ['apiary'] = ! empty ( $apiary ) ? '1' : '0';
		$data ['contact_before_spray'] = ! empty ( $contact ) ? '1' : '0';
		$data ['organic_farm'] = ! empty ( $organic_farm ) ? '1' : '0';
		$data ['nospray'] = ! empty ( $nospray ) ? '1' : '0';
		$data ['water_of_us'] = ! empty ( $water_of_us ) ? '1' : '0';
		
		if (! empty ( $water_of_us )) {
			$data ['watersize'] = $this->input->post ( 'watersize' );
			$data ['iduomwatersize'] = ! empty ( $iduomwatersize ) ? $iduomwatersize : '0';
		} else {
			$data ['watersize'] = '';
			$data ['iduomwatersize'] = '0';
		}
		
		$data ['endangered_species'] = ! empty ( $endangered_species ) ? '1' : '0';
		$data ['idsitegroup'] = $this->input->post ( 'idsitegroup' );
		
		if (! empty ( $endangered_species ))
			$data ['site_comments'] = $this->input->post ( 'site_comments' );
		else
			$data ['site_comments'] = '';
		
		if (! empty ( $sitecord )) {
			$data ['sitecord'] = $sitecord;
		} else {
			$data ['sitecord'] = '';
		}
		// print('<pre>');
		// print_r($data);
		// die;
		$this->db->insert ( 'sites', $data );
		$id = $this->db->insert_id ();
		
		if (empty ( $id ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to check for the existence of site
	 */
	public function siteExist($str = '') {
		if (empty ( $str ))
			return false;
		
		$this->db->select ( '*' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'site', $str );
		$this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0)
			return true;
		
		return false;
	}
	
	public function checkSiteExist($str, $siteId) {
		if (empty ( $str ))
			return false;
		log_message('debug','Skysoft Debugging -------------->>>>>>>>>>>>>>>>>>>>>>>>>>>>>> site name is .................. ' .$str);
		log_message('debug','Skysoft Debugging -------------->>>>>>>>>>>>>>>>>>>>>>>>>>>>>> site id is .................. ' .$siteId);
		$this->db->select ( '*' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'idsite !=', $siteId);
		$this->db->where ( 'site', $str );
		$this->db->where ( 'idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0)
			return true;
		
		return false;
	}


	/**
	 * Function to Update a new Site
	 */
	public function updateSite() {
		$idsite = $this->input->post ( 'idsite' );
		
		if (empty ( $idsite ))
			return false;
			// print'<pre>';
			// print_r($_POST);
			// die;
		$sitecord = $this->input->post ( 'sitecord' );
		$idstate = $this->input->post ( 'state' );
		$idloc = $this->session->userdata ( 'idlocation' );
		$idsitetype = $this->input->post ( 'site_type' );
		$landing = $this->input->post ( 'landingrate_site' );
		$site_of_interest = $this->input->post ( 'site_of_interest' );
		$larval = $this->input->post ( 'larval_site' );
		$adult = $this->input->post ( 'adult_site' );
		$apiary = $this->input->post ( 'apiary' );
		$contact = $this->input->post ( 'contact_before_spray' );
		$organic_farm = $this->input->post ( 'organic_farm' );
		$nospray = $this->input->post ( 'nospray' );
		$water_of_us = $this->input->post ( 'water_of_us' );
		$endangered_species = $this->input->post ( 'endangered_species' );
		$iduomwatersize = $this->input->post ( 'iduomwatersize' );
		$idzone = $this->input->post ( 'zone' );
		$idsiteGroup = $this->input->post ( 'idsitegroup' );

		$data ['site'] = $this->input->post ( 'site_name' );
		$data ['idsitetype'] = ! empty ( $idsitetype ) ? $idsitetype : '0';
		$data ['maplabel'] = $this->input->post ( 'maplabel' );
		$data ['address1'] = $this->input->post ( 'street1' );
		$data ['address2'] = $this->input->post ( 'street2' );
		$data ['city'] = $this->input->post ( 'city' );
		$data ['idstate'] = ! empty ( $idstate ) ? $idstate : 0;
		$data ['postalcode'] = $this->input->post ( 'postalcode' );
		$data ['latitude'] = $this->input->post ( 'latitude' );
		$data ['longitude'] = $this->input->post ( 'longitude' );
		$data ['manphone'] = $this->input->post ( 'manphone' );
		$data ['alternatephone'] = $this->input->post ( 'alternatephone' );
		$data ['faxnumber'] = $this->input->post ( 'faxnumber' );
		$data ['idlocation'] = ! empty ( $idloc ) ? $idloc : 0;
		$status = $this->input->post ( 'active' );
		$data ['active'] = ! empty ( $status ) ? '1' : '0';
		$data ['idzone'] = ! empty ( $idzone ) ? $idzone : 0;
		$data ['landingrate_site'] = ! empty ( $landing ) ? '1' : '0';
		$data ['larval_site'] = ! empty ( $larval ) ? '1' : '0';
		$data ['adult_site'] = ! empty ( $adult ) ? '1' : '0';
		$data ['apiary'] = ! empty ( $apiary ) ? '1' : '0';
		$data ['contact_before_spray'] = ! empty ( $contact ) ? '1' : '0';
		$data ['organic_farm'] = ! empty ( $organic_farm ) ? '1' : '0';
		$data ['site_of_interest'] = ! empty ( $site_of_interest ) ? $site_of_interest : '0';
		$data ['nospray'] = ! empty ( $nospray ) ? '1' : '0';
		$data ['water_of_us'] = ! empty ( $water_of_us ) ? '1' : '0';
		$data ['idsitegroup'] = !empty($idsiteGroup) ? $idsiteGroup : 0;
		//$data ['idsitegroup'] = $this->input->post ( 'idsitegroup' );
		
		if (! empty ( $water_of_us )) {
			$data ['watersize'] = $this->input->post ( 'watersize' );
			$data ['iduomwatersize'] = ! empty ( $iduomwatersize ) ? $iduomwatersize : '0';
		} else {
			$data ['watersize'] = 0;
			$data ['iduomwatersize'] = 0;
		}
		
		$data ['endangered_species'] = ! empty ( $endangered_species ) ? '1' : '0';
		
		if (! empty ( $endangered_species ))
			$data ['site_comments'] = $this->input->post ( 'site_comments' );
		else
			$data ['site_comments'] = '';
			
			// echo $idsite;
			// print'<pre>';
			// print_r($data);
			// die;
		if (! empty ( $sitecord )) {
			$data ['sitecord'] = $sitecord;
		} else {
			$data ['sitecord'] = '';
		}
		$this->db->where ( 'idsite', $idsite );
		$this->db->update ( 'sites', $data );
		// echo $this->db->last_query();
		// die;
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ) && empty ( $idsite ))
			return false;
			
			// $data_1['idzone'] = $this->input->post('zone');
			//
			// $this->db->where('idsite',$idsite);
			// $this->db->update('sitezoneassignment',$data_1);
			//
			// $rows = $this->db->affected_rows();
			//
			// if(empty($rows) && empty($idsite))
			// return false;
		
		return true;
	}

	
	/**
	 * Function to list all Sites
	 */
	public function deleteSite() {
		$idsite = $this->input->get_post ( 'id' );
		if (empty ( $idsite ))
			return false;
			/*
		 * $this->db->query("SET foreign_key_checks = 0");
		 * $this->db->where('idsite',$idsite);
		 * $this->db->delete('sitezoneassignment');
		 * $this->db->query("SET foreign_key_checks = 1");
		 */
		$data ['isdeleted'] = '1';
		$this->db->where ( 'idsite', $idsite );
		$this->db->update ( 'sites', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to activate Sites
	 */
	public function activeSite() {
		$idsite = $this->input->get_post ( 'id' );
		
		if (empty ( $idsite ))
			return false;
		
		$data ['active'] = '1';
		
		$this->db->where ( 'idsite', $idsite );
		$this->db->update ( 'sites', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}


	/**
	 * Function to deactivate Sites
	 */
	public function deactiveSite() {
		$idsite = $this->input->get_post ( 'id' );
		
		if (empty ( $idsite ))
			return false;
		
		$data ['active'] = '0';
		
		$this->db->where ( 'idsite', $idsite );
		$this->db->update ( 'sites', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to fetch Statuses of Sites
	 */
	public function getStatuses() {
		$this->db->select ( 'idsite,
				active' );
		$this->db->from ( 'sites' );
		
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$k = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$k] ['status'] = ! empty ( $row ['active'] ) ? $row ['active'] : '0';
				$result [$k] ['idsite'] = $row ['idsite'];
				$k ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to list all Sites mail
	 */
	public function getSiteData($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( 'sites.*, 
				states.statename AS states_statename,
				states.idstate , 
				z.zone' );
		$this->db->from ( 'sites' );
		$this->db->join ( 'zones AS z', 'sites.idzone = z.idzone', 'LEFT' );
		$this->db->join ( 'locations', 'sites.idlocation = locations.idlocation', 'LEFT' );
		$this->db->join ( 'states', 'sites.idstate = states.idstate', 'LEFT' );
		$this->db->where ( 'sites.isdeleted', '0' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( '`sites`.`idsite`', $Id );
		
		$query = $this->db->get ();
		
		$data = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row )
				$data [] = $row;
			
			return $data [0];
		}
		
		return false;
	}
	
	/**
	 * Function to list all Sites
	 */
	public function listSites() {
		$this->db->select ( '`sites`.`idsite`, 
				`sites`.`site` AS `site`, 
				`sites`.`maplabel` AS `maplabel`, 
				`sites`.`address1` AS `address1`, 
				`zones`.`zone` AS `zones_zone`, 
				`sites`.`city` AS `city`, 
				`states`.`statename` AS `states_statename`, 
				`sites`.`postalcode` AS `postalcode`, 
				`sites`.`active` AS `active`,
				`sitetypes`.`sitetype`' );
		$this->db->from ( 'sites' );
		$this->db->join ( 'sitetypes', 'sites.idsitetype = sitetypes.idsitetype', 'LEFT' );
		$this->db->join ( 'zones', 'sites.idzone = zones.idzone', 'LEFT' );
		$this->db->join ( 'states', 'sites.idstate = states.idstate', 'LEFT' );
		$this->db->join ( 'locations', 'sites.idlocation = locations.idlocation', 'LEFT' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		// $this->db->where('sites.active','1');
		$this->db->where ( 'sites.isdeleted', '0' );
		if ($this->input->get ( 'site' )) {
			$this->db->where ( 'sites.idsite', $this->input->get ( 'site' ) );
		}
		
		if ($this->input->get ( 'siteofinterest' )) {
			$siteofinterest = explode ( "_", $this->input->get ( 'siteofinterest' ) );
			$sitetemp = '';
			$or = '';
			foreach ( $siteofinterest as $key => $val ) {
				switch ($val) {
					case '1' :
						$sitetemp .= " sites.site_of_interest = '1'";
						$or = ' OR';
						break;
					case '2' :
						$sitetemp .= $or . " sites.landingrate_site = '1'";
						$or = ' OR';
						break;
					case '3' :
						$sitetemp .= $or . " sites.larval_site = '1'";
						$or = ' OR';
						break;
					case '4' :
						$sitetemp .= $or . " sites.adult_site = '1'";
						$or = ' OR';
						break;
					case '5' :
						$sitetemp .= $or . " sites.apiary = '1'";
						$or = ' OR';
						break;
					case '6' :
						$sitetemp .= $or . " sites.contact_before_spray = '1'";
						$or = ' OR';
						break;
					case '7' :
						$sitetemp .= $or . " sites.organic_farm = '1'";
						$or = ' OR';
						break;
					case '8' :
						$sitetemp .= $or . " sites.nospray = '1'";
						$or = ' OR';
						break;
					case '9' :
						$sitetemp .= $or . " sites.endangered_species = '1'";
						$or = ' OR';
						break;
				}
			}
			if (! empty ( $sitetemp )) {
				$sitetemp = "(" . trim ( $sitetemp, "OR" ) . ")";
				$this->db->where ( $sitetemp );
			}
		}
		$orderby = $this->input->get ( 'orderby' );
		
		if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
			switch ($orderby) {
				case '0:asc' :
					$this->db->order_by ( 'sites.site', 'ASC' );
					break;
				case '0:desc' :
					$this->db->order_by ( 'sites.site', 'DESC' );
					break;
				case '1:asc' :
					$this->db->order_by ( 'sitetypes.sitetype', 'ASC' );
					break;
				case '1:desc' :
					$this->db->order_by ( 'sitetypes.sitetype', 'DESC' );
					break;
				case '2:asc' :
					$this->db->order_by ( 'sites.address1', 'ASC' );
					break;
				case '2:desc' :
					$this->db->order_by ( 'sites.address1', 'DESC' );
					break;
				case '3:asc' :
					$this->db->order_by ( 'zones.zone', 'ASC' );
					break;
				case '3:desc' :
					$this->db->order_by ( 'zones.zone', 'DESC' );
					break;
				case '4:asc' :
					$this->db->order_by ( 'sites.city', 'ASC' );
					break;
				case '4:desc' :
					$this->db->order_by ( 'sites.city', 'DESC' );
					break;
				case '5:asc' :
					$this->db->order_by ( 'states.statename', 'ASC' );
					break;
				case '5:desc' :
					$this->db->order_by ( 'states.statename', 'DESC' );
					break;
				case '6:asc' :
					$this->db->order_by ( 'sites.postalcode', 'ASC' );
					break;
				case '6:desc' :
					$this->db->order_by ( 'sites.postalcode', 'DESC' );
					break;
				case '7:asc' :
					$this->db->order_by ( 'sites.active', 'ASC' );
					break;
				case '7:desc' :
					$this->db->order_by ( 'sites.active', 'DESC' );
					break;
			}
		} else {
			$this->db->order_by ( 'sites.site' );
		}
		
		// $ttl = $this->input->get('ttl');
		// $page = $this->input->get('page');
		//
		// if(!isset($ttl) || $ttl == '')
		// $ttl = 10;
		//
		// if(!isset($page) || $page == '')
		// $page = 1;
		//
		// if(!is_null($ttl) && !is_null($page))
		// {
		// if($page == 1)
		// $page = 0;
		// else
		// $page--;
		//
		// $page *= 10;
		// $this->db->limit($ttl ,$page);
		// }
		// else if(!is_null($ttl))
		// {
		// $this->db->limit($ttl);
		// }
		$data_1 = array ();
		$query = $this->db->get ();
		// echo $this->db->last_query();
		// die;
		// print'<pre>';
		// print_r($query->result_array());
		// die;
		if ($query->num_rows () > 0)
			return $query->result_array ();
		
		return false;
	}
	
	/**
	 * Function to fetch State List
	 * for maps
	 */
	public function getStatesList($name = '') {
		$this->db->select ( '*' );
		$this->db->from ( 'states' );
		$this->str = "";
		
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if (! empty ( $name ) && $row ['statename'] == $name)
					$this->str .= '<option value="' . $row ['idstate'] . '" selected="true">' . $row ['statename'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idstate'] . '">' . $row ['statename'] . '</option>';
			}
		}
		
		return $this->str;
	}
	public function getStates() {
		$this->db->select ( 'states.idstate,
				states.statename' );
		$this->db->order_by ( 'statename' );
		$this->db->from ( 'states' );
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idstate'] = $row ['idstate'];
				$result [$i] ['statename'] = $row ['statename'];
				$i ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to fetch Selected State
	 * based on Trap
	 */
	public function getSelectedStatesTrap($id) {
		$this->db->select ( 'states.idstate,
				states.statename' );
		$this->db->order_by ( 'statename' );
		$this->db->from ( 'states' );
		
		$query = $this->db->get ();
		$this->str = "";
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if (isset ( $row ['idstate'] ) && $row ['idstate'] == $id)
					$this->str .= '<option value="' . $row ['idstate'] . '" selected="true">' . $row ['statename'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idstate'] . '">' . $row ['statename'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected State
	 * based on idlocation
	 */
	public function getSelectedStates($Id = '') {
		$this->db->select ( 'idstate,
				statename' );
		$this->db->from ( 'states' );
		$this->db->order_by ( 'statename' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if (! empty ( $Id ) && $Id == $row ['idstate'])
					$this->str .= '<option value="' . $row ['idstate'] . '" selected="true">' . $row ['statename'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idstate'] . '">' . $row ['statename'] . '</option>';
			}
			return $this->str;
		}
		
		return $this->str;
		
		/*
		 * $this->db->select('idstate,statename');
		 * $this->db->order_by('statename');
		 * $this->db->from('states');
		 *
		 * $query = $this->db->get();
		 *
		 * if($query -> num_rows() > 0)
		 * {
		 * foreach($query -> result_array() as $row)
		 * {
		 * if(isset($row['idstate']) && $row['idstate'] == $id)
		 * $this->str .= '<option value="'.$row['idstate'].'" selected="true">'.$row['statename'].'</option>';
		 * else
		 * $this->str .= '<option value="'.$row['idstate'].'">'.$row['statename'].'</option>';
		 * }
		 * }
		 *
		 * return $this->str;
		 */
	}
	
	/**
	 * Function to fetch Existing Site
	 */
	public function getExisting_site($id = '') {
		$this->db->select ( 'idsite,
				site' );
		$this->db->order_by ( 'site' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'sites.active', '1' );
		$this->db->where ( 'sites.isdeleted', '0' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if (! empty ( $id ) && $row ['idsite'] == $id)
					$this->str .= '<option value="' . $row ['idsite'] . '" slelected="true">' . $row ['site'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idsite'] . '">' . $row ['site'] . '</option>';
			}
		}
		
		return $this->str;   
	}

	/**
	 * Function to fetch wards
	 */
	public function getwards($id = '') {
		$this->db->select ( 'sites.idsite AS wardId, sites.site AS ward, wardsclosed.idwardsclosed  AS wardclosedId' );
		$this->db->order_by ( 'ward' );
		$this->db->from ( 'sites' );
		$this->db->join ( 'wardsclosed', 'wardsclosed.idsite = sites.idsite', 'LEFT' );
		$this->db->where ( 'sites.isdeleted', '0' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		$query = $this->db->get ();
		$result = array ();
		if ($query->num_rows () > 0) {
			 return  $query->result_array ();   
		}
		
		return $result;   
	}

	/**
	 * Function to activate Sites
	 */
	public function activateWard() {
		$idward = $this->input->get_post ( 'id' );
	 
		if (empty ( $idward ))
			return false;
		
	   	$this->db->query("SET foreign_key_checks = 0");
	   	$this->db->where('idsite',$idward);
	  	$this->db->delete('wardsclosed');
	  	
	  	$data ['active'] = '1';
		
		$this->db->where ( 'idsite', $idward );
		$this->db->update ( 'sites', $data );

	  	$this->db->query("SET foreign_key_checks = 1");
		
		$rows = $this->db->affected_rows (); 
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	

	/**
	 * Function to fetch closed wards
	 */
	public function getclosedwards($id = '') {
		$this->db->select ( 'wardsclosed.idsite AS wardId' );
		$this->db->order_by ( 'idsite' );
		$this->db->from ( 'wardsclosed' );
		$this->db->where ( 'wardsclosed.idlocation', $this->session->userdata ( 'idlocation' ) );
		$query = $this->db->get ();
		$result = array ();
		if ($query->num_rows () > 0) {
			 return  $query->result_array ();   
		}
		
		return $result;   
	}

		/**
	 * Function to fetch closed wards
	 */
	public function getward($id = '') {
		$this->db->select ( 'sites.idsite AS wardId, sites.site AS ward' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'sites.idsite', $id );
		$query = $this->db->get ();
		$result = array ();
		if ($query->num_rows () > 0) {
			 return  $query->result_array ()[0];   
		}
		
		return $result;   
	}
	
	/**
	 * Function to fetch All Sites
	 */
	public function getAllSite($id = '') {
		$this->db->select ( 'idsite,
				site' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'sites.active', '1' );
		$this->db->where ( 'sites.isdeleted', '0' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->order_by ( 'site' );
	
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idsite'] = $row ['site'];
				$i ++;
			}
		}
		
		return $result;
	}
	
    /**
	 * Function to fetch All Sites Data
	 */
	public function getAllSiteData($id = '') {
		$this->db->select ( '*' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'sites.active', '1' );
		$this->db->where ( 'sites.isdeleted', '0' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
        
        if(!empty($id)) {
            $this->db->where ( 'sites.idsite', $id);
        }
		$this->db->order_by ( 'site' );
		
        $result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] = $row ;
				$i ++;
			}
		}
		
		return $result;
	}
    
	/**
	 * Function to fetch Site Type
	 */
	public function getSitetypes() {
		$this->db->select ( '*' );
		$this->db->from ( 'sitetypes' );
		$this->db->order_by ( 'sitetype' );
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idsitetype'] = $row ['idsitetype'];
				$result [$i] ['sitetype'] = $row ['sitetype'];
				$i ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to fetch Selected Site TYpe
	 * selected by Site
	 */
	public function getSelectedsitetype($id = '') {
		$this->db->select ( 'idsitetype,
				sitetype' );
		$this->db->from ( 'sitetypes' );
		$this->db->order_by ( 'sitetype' );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if (! empty ( $id ) && $id == $row ['idsitetype'])
					$this->str .= '<option value="' . $row ['idsitetype'] . '" selected="true">' . $row ['sitetype'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idsitetype'] . '">' . $row ['sitetype'] . '</option>';
			}
			return $this->str;
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Site Type
	 * selected by Trap
	 */
	public function getSelected_sitetype($id = '') {
		$this->db->select ( 'idsitetype,
				sitetype' );
		$this->db->from ( 'sitetypes' );
		$this->db->order_by ( 'sitetype' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if (! empty ( $id ) && $row ['idsitetype'] == $id)
					$this->str .= '<option value="' . $row ['idsitetype'] . '" selected="true">' . $row ['sitetype'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idsitetype'] . '">' . $row ['sitetype'] . '</option>';
			}
			return $this->str;
		}
		
		return $this->str;
	}
	/**
	 * Function to fetch Site Group Based on idlocation
	 * If idsitegroup is provided then selected Site Group
	 * will get fetched
	 */
	public function getSiteGroup($id = '') {
		$this->db->select ( '*' );
		$this->db->from ( 'sitegroups AS sg' );
		$this->db->where ( 'sg.isdeleted', '0' );
		$this->db->where ( 'sg.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->order_by ( 'sg.sitegroup', 'ASC' );
		
		$this->str = "";
		$query = $this->db->get ();
		$result = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$result [$row ['idsitegroup']] = $row ['sitegroup'];
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to fetch Selected Zones
	 * selected by Site
	 */
	public function getSelectedZones($id = '') {
		$this->db->select ( 'idzone,
				zone' );
		$this->db->from ( 'zones' );
		$this->db->where ( 'zones.active', '1' );
		$this->db->where ( 'zones.isdeleted', '0' );
		$this->db->where ( 'zones.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->order_by ( 'zone' );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				if ($row ['idzone'] == $id && ! empty ( $id ))
					$this->str .= '<option value="' . $row ['idzone'] . '" selected="true">' . $row ['zone'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idzone'] . '">' . $row ['zone'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Zones
	 * selected by Site Zone Relation
	 */
	public function getSelectedSiteZones($id = '') {
		$this->db->select ( 'szm.idzone' );
		$this->db->from ( 'sitezoneassignment AS szm' );
		
		if (! empty ( $id ))
			$this->db->where ( 'szm.idsite', $id );
		
		$this->str = "";
		$query = $this->db->get ();
		$idzone = "";
		if ($query->num_rows () > 0) {
			$idzone = $query->result_array ();
			$idzone = $idzone [0] ['idzone'];
		}
		$this->db->select ( 'z.idzone,z.zone' );
		$this->db->order_by ( 'zone' );
		$this->db->from ( 'zones AS z' );
		
		$this->db->where ( 'z.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$q = $this->db->get ();
		
		foreach ( $q->result_array () as $row ) {
			if ($row ['idzone'] == $idzone)
				$this->str .= '<option value="' . $row ['idzone'] . '" selected="true">' . $row ['zone'] . '</option>';
			else
				$this->str .= '<option value="' . $row ['idzone'] . '">' . $row ['zone'] . '</option>';
		}
		return $this->str;
	}
	
	/**
	 * Function to fetch Zones
	 * selected by Site
	 */
	public function getZones($id = '') {
		$this->db->select ( 'idzone,
				zone' );
		$this->db->order_by ( 'zone' );
		$this->db->from ( 'zones' );
		$this->db->where ( 'zones.active', '1' );
		$this->db->where ( 'zones.isdeleted', '0' );
		$this->db->where ( 'zones.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if (! empty ( $id ) && $id == $row ['idzone'])
					$this->str .= '<option value="' . $row ['idzone'] . '" selected="true">' . $row ['zone'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idzone'] . '">' . $row ['zone'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Site
	 * selected by Trap
	 */
	public function getSelectedExistingSite($Id = '') {
		$this->db->select ( 'idsite,
				site' );
		$this->db->order_by ( 'site' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'sites.active', '1' );
		$this->db->where ( 'sites.isdeleted', '0' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($row ['idsite'] == $Id)
					$this->str .= '<option value="' . $row ['idsite'] . '" selected="true">' . $row ['site'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idsite'] . '">' . $row ['site'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	public function getUserSiteGroup($id = '') {
		$this->db->select ( '*' );
		$this->db->from ( 'sitegroups AS sg' );
		$this->db->where ( 'sg.isdeleted', '0' );
		$this->db->where ( 'sg.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->order_by ( 'sg.sitegroup', 'ASC' );
		
		$this->str = "";
		$query = $this->db->get ();
		$result = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if($row['idsitegroup']==$id)
					$this->str .='<option value="' . $row['idsitegroup'] . '" selected="true">' . $row['sitegroup']. '</option>';
				else
					$this->str .='<option value="' . $row['idsitegroup'] . '">' . $row['sitegroup']. '</option>';
			}
		}
		return $this->str;
	}

	public function getSitesOfGroupSite($groupSiteId, $id) {
		$this->db->select ( 'idsite,site' );
		$this->db->from('sites');
		$this->db->where('sites.idsitegroup', $groupSiteId);
		$value="";
		$this->str = "<option value='".$value."'>All Sites</options>";
		$query = $this->db->get ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if($row['idsite']== $id)
					$this->str .= '<option value="'.$row['idsite'] . '"  selected="true">' . $row['site'] . '</option>';
				else 
					$this->str .= '<option value="' . $row ['idsite'] . '" >' . $row ['site'] . '</option>';
			}
		}
		return $this->str;
	}
	public function getSelectedExistingSites($Id = '') {
		$this->db->select ( 'idsite,
				site' );
		$this->db->order_by ( 'site' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'sites.active', '1' );
		$this->db->where ( 'sites.isdeleted', '0' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		$value="";
		$this->str = "<option value='".$value."'>All Sites</options>";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($row ['idsite'] == $Id)
					$this->str .= '<option value="' . $row ['idsite'] . '" selected="true">' . $row ['site'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idsite'] . '">' . $row ['site'] . '</option>';
			}
		}
		
		return $this->str;
	}

	/**
	 * Function to fetch Site
	 * selected by User either through dropdown or by typing
	 */
	public function getSelectedSiteList($char = '') {
		$this->db->select ( 'idsite,
				site' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'sites.active', '1' );
		$this->db->where ( 'sites.isdeleted', '0' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->order_by ( 'sites.site', 'ASC' );
		$this->db->like ( 'site', $char, 'after' );
		$arr = array ();
		$query = $this->db->get ();
		// echo $this->db->last_query()."<br>";
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $key => $val ) {
				$arr [] = array (
						'id' => $val ['idsite'],
						'data' => $val ['site'] 
				);
			}
		}
		return $arr;
	}
	
	/**
	 * Function to fetch Site Type
	 * selected by User either through dropdown or by typing
	 */
	public function getSelectedSiteTypeList($char = '') {
		$this->db->select ( 'st.idsitetype,
				st.sitetype' );
		$this->db->from ( 'sitetypes AS st' );
		$this->db->like ( 'st.sitetype', $char, 'after' );
		$arr = array ();
		$query = $this->db->get ();
		// echo $this->db->last_query()."<br>";
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $key => $val ) {
				$arr [] = array (
						'id' => $val ['idsitetype'],
						'data' => $val ['sitetype'] 
				);
			}
		}
		return $arr;
	}
	
	/**
	 * Function to fetch Site Group
	 * selected by User either through dropdown or by typing
	 */
	public function getSelectedSiteGroupList($char = '') {
		$this->db->select ( 'sg.idsitegroup,
				sg.sitegroup' );
		$this->db->from ( 'sitegroups AS sg' );
		$this->db->where ( 'sg.isdeleted', '0' );
		$this->db->where ( 'sg.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->like ( 'sg.sitegroup', $char, 'after' );
		$arr = array ();
		$query = $this->db->get ();
		// echo $this->db->last_query()."<br>";
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $key => $val ) {
				$arr [] = array (
						'id' => $val ['idsitegroup'],
						'data' => $val ['sitegroup'] 
				);
			}
		}
		return $arr;
	}
	
	/**
	 * Function to fetch Site
	 * selected by Trap
	 */
	public function getSelectedSiteStates($Id) {
		$this->db->select ( 'sites.idstate' );
		$this->db->from ( 'sites' );
		
		if (! empty ( $Id ))
			$this->db->where ( 'idsite', $Id );
		
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$idstate = $query->result_array ();
			$idstate = $idstate [0] ['idstate'];
			
			$this->db->select ( 'states.idstate,states.statename' );
			$this->db->order_by ( 'statename' );
			$this->db->from ( 'states' );
			
			$q = $this->db->get ();
			
			if ($q->num_rows () > 0) {
				foreach ( $q->result_array () as $row ) {
					if ($row ['idstate'] == $idstate)
						$this->str .= '<option value="' . $row ['idstate'] . '" selected="true">' . $row ['statename'] . '</option>';
					else
						$this->str .= '<option value="' . $row ['idstate'] . '">' . $row ['statename'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to check whether the Site
	 * is WATER OF THE US
	 */
	public function isWaterOfUs($id = '') {
		if (empty ( $id ))
			return false;
		
		$this->db->select ( 'water_of_us' );
		$this->db->from ( 'sites AS s' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 's.idsite', $id );
		
		$q = $this->db->get ();
		
		if ($q->num_rows () > 0) {
			$wt = $q->result_array ();
			$wt = $wt [0] ['water_of_us'];
			
			if ($wt == "1")
				return true;
		}
		
		return false;
	}
}