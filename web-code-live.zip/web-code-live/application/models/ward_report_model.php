<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );

class Ward_report_model extends CI_Model {
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
    $this->load->model('custom_report_model');
	}
  
  public function getReport($date, $excludedSites, $loadFlag) {
    $date_arr = explode("/", $date);
		$date = $date_arr[2] . "-" . $date_arr[0] . "-" . $date_arr[1];
		
		$selectedDate = new DateTime($date);
		
		$dow = $selectedDate->format('w');
		if($dow !== '1') {
			if($dow == '0') {
				$selectedDate->sub(new DateInterval('P6D'));
			}
			else {
				$daysToReverse = intval($dow) - 1;
				$selectedDate->sub(new DateInterval('P'.$daysToReverse.'D'));
			}
		} 
		
		$startDate = clone $selectedDate;
		$selectedDate->add(new DateInterval('P4D'));
		$weekEnding = clone $selectedDate;
		$selectedDate->add(new DateInterval('P2D'));
		$endDate = clone $selectedDate;
		
		$endYear = $endDate->format('Y');
		$currentYearStart = $endYear.'-01-01';
		$currentYearEnd = $endYear.'-12-31';
    
    $result = $this->getSiteTreatments($startDate->format('Y-m-d'), $endDate->format('Y-m-d'), $excludedSites, $loadFlag);
		
		foreach($result['sites'] as &$site) {
			if($site['selected'] == '1')
				$site['closing_data'] = $this->custom_report_model->getClosingData($site, $currentYearStart, $currentYearEnd);
		}
		
		$result['weekStart'] = $startDate;
		$result['weekEnd'] = $weekEnding;
    return $result;
  }
  
  private function getSiteTreatments($startdate, $enddate, $siteIds, $loadFlag) {
    $siteData = $this->custom_report_model->getAllSites($siteIds, '57', false, $loadFlag);
		$sites = $siteData['sites'];
		$treatments = $this->getAllTreatments($startdate, $enddate, $siteData['includedSites'], $loadFlag);
		
		$applicators = array();

		foreach($treatments as $tre) {
			$index = $this->findApplicator($applicators, $tre['idapplicator']);
			
			$treatment = array(
					'idlarvaltreatment'=>$tre['idlarvaltreatment'],
					'date'=>$tre['date'],
					'idsite'=>$tre['idsite'],
					'totalproductapplied'=>$tre['totalproductapplied'],
          'firstname'=>$tre['firstname'],
          'lastname'=>$tre['lastname'],
          'zone'=>$tre['zone'],
					'site'=>$tre['site']
			);
		  
			if($index > -1) {
				array_push($applicators[$index]['treatments'], $treatment);
			}
			else {
				array_push($applicators, array(
					'idapplicator'=> $tre['idapplicator'],
					'firstname' => $tre['firstname'],
					'lastname' => $tre['lastname'],
					'treatments' => array($treatment)
				));
			}
		}
		
		$result = array('sites'=>$sites, 'applicators'=>$applicators);
		return $result;
  }
  
  private function getAllTreatments($startdate, $enddate, $siteIds, $loadFlag) {
		if($loadFlag === true) return array();
		if(sizeof($siteIds) < 1) return array();
    
		$this->db->select('l.idlarvaltreatment, l.idsite, l.date, l.idapplicator, l.totalproductapplied, u.firstname, u.lastname, z.zone, s.site');
		$this->db->from('larvaltreatments l');
    $this->db->join('users u', 'u.iduser = l.idapplicator');
    $this->db->join('zones z', 'z.idzone = l.idzone');
		$this->db->join('sites s', 's.idsite = l.idsite');
		$this->db->where_in('l.idsite', $siteIds);
		$this->db->where("l.date BETWEEN '$startdate' AND '$enddate'");
		$this->db->where('l.isdeleted', '0');
		$this->db->order_by('l.date');
		$query = $this->db->get();
		
		$result = array();
		if($query->num_rows() > 0) $result = $query->result_array();
		
		return $result;
	}
  
  private function findApplicator($applicators, $idapplicator) {
		for($i = 0; $i < count($applicators); $i++) {
			if($applicators[$i]['idapplicator'] == $idapplicator) return $i;
		}
		return -1;
	}
}