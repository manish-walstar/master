<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Membermodel extends CI_Model {
	public $data = array ();
	public $str = "";
	public $set_pwd = "";
	
	/**
	 * Constructor for the class
	 * User
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to Add a new Member
	 */
	public function addMember($id = '', $idloc = '') {
		$idsuffix = $this->input->post ( 'idsuffix' );
		$idsalutation = $this->input->post ( 'idsalutation' );
		$service_request = $this->input->post ( 'srvice_rqst' );
		$surveillance = $this->input->post ( 'surveillance' );
		$treatments = $this->input->post ( 'treatments' );
		$reports = $this->input->post ( 'reports' );
		$company_admin = $this->input->post ( 'cmpny_admin' );
		$device_managment = $this->input->post ( 'device_mngmnt' );
        $geotracker_admin = $this->input->post ( 'geotracker_admin' );
        $skytrackeradmin = $this->input->post ( 'skytrackeradmin' );
        $pilot = $this->input->post ( 'pilot' );
        $driver = $this->input->post ( 'driver' );
        // $skytrackeradmin = $this->input->post ( 'skytrackeradmin' );
        // $pilot = $this->input->post ( 'pilot' );
        $userfilter = $this->input->post ( 'userfilter_admin' );
		$idgroup = $this->input->post ( 'group_val' );
	
		$data ['username'] = $this->input->post ( 'username' );
		$data ['email'] = $this->input->post ( 'email' );
		$data ['idsalutation'] = ($idsalutation) ? $idsalutation : NULL;
		$data ['firstname'] = $this->input->post ( 'firstname' );
		$data ['middlename'] = $this->input->post ( 'middlename' );
		$data ['lastname'] = $this->input->post ( 'lastname' );
		$data ['idsuffix'] = ($idsuffix) ? $idsuffix : NULL;
		$data ['officephone'] = $this->input->post ( 'officephone' );
		$data ['mobilephone'] = $this->input->post ( 'mobilephone' );
		$data ['faxnumber'] = $this->input->post ( 'faxnumber' );
		$this->set_pwd = $this->input->post ( 'password' );
		
		$data ['unique_id'] = uniqid ();
		$data ['is_active'] = '1';
		$data ['service_request'] = ($service_request == "on" || $service_request == "1") ? "1" : "0";
		$data ['surveillance'] = ($surveillance == "on" || $surveillance == "1") ? "1" : "0";
		$data ['treatments'] = ($treatments == "on" || $treatments == "1") ? "1" : "0";
		$data ['reports'] = ($reports == "on" || $reports == "1") ? "1" : "0";
		$data ['company_admin'] = ($company_admin == "on" || $company_admin == "1") ? "1" : "0";
		$data ['device_managment'] = ($device_managment == "on" || $device_managment == "1") ? "1" : "0";
        $data ['geotracker_admin'] = ($geotracker_admin == "on" || $geotracker_admin == "1") ? "1" : "0";
         $data ['skytrackeradmin'] = ($skytrackeradmin == "on" || $skytrackeradmin == "1") ? "1" : "0";
         $data ['pilot'] = ($pilot == "on" || $pilot == "1") ? "1" : "0";
        $data ['driver'] = ($driver == "on" || $driver == "1") ? "1" : "0";
        $data ['userfiltering'] = ($userfilter == "on" || $userfilter == "1") ? "1" : "0";
		$data ['hideboundary'] = '0';
		$data ['idlocation'] = $this->session->userdata ( 'idlocation' );
        
        $gplite = $this->session->userdata ( 'gplite' );
        if($gplite) {
            $data ['gplite'] = '1';
        }
        
        $gplites = $this->session->userdata ( 'gplites' );
        if($gplites) {
            $data ['gplites'] = '1';
        }
		// print'<pre>';
		// print_r($idgroup);
		// die;
		// print'<pre>';
		// print_r($data ['userfiltering']);
		// die;
		if (! empty ( $id )) {
			$nwpwd = $this->input->post ( 'password' );
			$crrntpwd = $this->input->post ( 'confirmpassword' );
			
			if (! empty ( $nwpwd ) && ! empty ( $crrntpwd ) && $nwpwd == $crrntpwd) {
				$data ['salt'] = generateRandomString ();
				$data ['encrypted_password'] = md5 ( $data ['salt'] . $this->set_pwd );
			}
			// echo $id."<br>";
			// print'<pre>';
			// print_r($data);
			// die;
			$this->db->query ( 'SET foreign_key_checks = 0' );
			$this->db->where ( 'iduser', $id );
			$this->db->update ( 'users', $data );
			$this->db->query ( 'SET foreign_key_checks = 1' );
			// echo $this->db->affected_rows();
			// die;
			if (! empty ( $idgroup )) {
				$this->db->where ( 'iduser', $id );
				$this->db->delete ( 'usergroupassignment' );
				foreach ( $idgroup as $key => $val ) {
					$data_2 ['iduser'] = $id;
					$data_2 ['idusergroup'] = $val;
					$this->db->insert ( 'usergroupassignment', $data_2 );
					// print('<pre>');
					// print_r($val);
				}
				// die;
			}
			
			return true;
		} else {
			$data ['salt'] = generateRandomString ();
			$data ['encrypted_password'] = md5 ( $data ['salt'] . $this->set_pwd );
			$this->db->insert ( 'users', $data );
			
			$id = $this->db->insert_id ();
			$idloc = $this->session->userdata ( 'idlocation' );
			$data_1 ['iduser'] = $id;
			$data_1 ['iduserrole'] = '1';
			$data_1 ['active'] = '1';
			$data_1 ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
			$this->db->insert ( 'userlocationassignment', $data_1 );
			
			if (! empty ( $idgroup )) {
				foreach ( $idgroup as $key => $val ) {
					$data_2 ['iduser'] = $id;
					$data_2 ['idusergroup'] = $val;
					$this->db->insert ( 'usergroupassignment', $data_2 );
				}
			}
		}
		
		$rows = $this->db->affected_rows ();
		// $rows = 1;
		if (empty ( $rows ) && empty ( $id ))
			return false;
			
			// $return = array(
			// 'firstname' => $data['firstname'],
			// 'username' => $data['username'],
			// 'pwd' => $this->set_pwd
			// );
			// $to = $data['email'];
			// $subject = "Your account has been created";
			
		// if($this->sendMail($to,$subject,$message))
		return true;
		
		// return false;
	}
	
	/**
	 * Function to check user name existence
	 */
	public function userExist($str = '', $id = '') {
		if (empty ( $str ))
			return false;
		
		$this->db->select ( '*' );
		$this->db->from ( 'users' );
		
		if (! empty ( $id )) {
			$this->db->where ( 'iduser !=', $id );
			$this->db->where ( 'username', $str );
		} else
			$this->db->where ( 'username', $str );
		
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0)
			return true;
		
		return false;
	}
	
	/**
	 * Function to check current user name exist
	 */
	public function currentuserExist() {
		$str = $this->input->post ( 'username' );
		$Id = $this->input->post ( 'x_s_' );
		
		$id = json_decode ( base64_decode ( $Id ) );
		
		$id_arr = explode ( "_", $id );
		
		$id = json_decode ( base64_decode ( $id_arr [0] ) );
		
		if (empty ( $id ))
			return false;
		
		$condition = array (
				'username' => $str,
				'iduser !=' => $id 
		);
		
		$this->db->select ( '*' );
		$this->db->from ( 'users' );
		$this->db->where ( $condition );
		
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0)
			return true;
		
		return false;
	}
	
	/**
	 * Function to fetch Group List
	 */
	public function getUserGroups($id = '') {
		$this->db->select ( 'idusergroup,
				usergroup' );
		$this->db->from ( 'usergroups' );
		$this->db->where ( 'usergroups.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->order_by ( 'usergroups.usergroup', 'ASC' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($row ['idusergroup'] == $id && ! empty ( $id ))
					$this->str .= '<option value="' . $row ['idusergroup'] . '" selected="true">' . $row ['usergroup'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idusergroup'] . '">' . $row ['usergroup'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Group List
	 * Old Function
	 */
	public function getSelectedUserGroups_I($id = '') {
		$this->db->select ( 'ug.idusergroup,
				ug.usergroup' );
		$this->db->from ( 'usergroups AS ug' );
		$this->db->join ( 'usergroupassignment AS uga', 'ug.idusergroup = uga.idusergroup', 'INNER' );
		$this->db->join ( 'users AS u', 'uga.iduser = u.iduser', 'INNER' );
		$this->db->where ( 'ug.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'u.iduser', $id );
		
		$this->str = "";
		$query = $this->db->get ();
		$idgroup = '';
		if ($query->num_rows () > 0) {
			$idgroup = $query->result_array ();
			$idgroup = $idgroup [0] ['idusergroup'];
		}
		
		$this->str = $this->getUserGroups ( $idgroup );
		return $this->str;
	}
	
	/**
	 * Function to fetch Group List
	 * Edited By Skysoft Incorporated
	 * Based on new Requirement
	 */
	public function getSelectedUserGroups($id = '') {
		$this->db->select ( 'ug.idusergroup,
				ug.usergroup' );
		$this->db->from ( 'usergroups AS ug' );
		$this->db->join ( 'usergroupassignment AS uga', 'ug.idusergroup = uga.idusergroup', 'INNER' );
		$this->db->join ( 'users AS u', 'uga.iduser = u.iduser', 'INNER' );
		$this->db->where ( 'ug.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'u.iduser', $id );
		
		$group = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$k = 0;
			foreach ( $query->result_array () as $row ) {
				$group [$k] ['usergroup'] = $row ['usergroup'];
				$group [$k] ['idusergroup'] = $row ['idusergroup'];
				$k ++;
			}
		}
		
		return $group;
	}
	/**
	 * Function to list all members mail
	 */
	public function ToExcelAll() {
		$orderby = $this->input->get ( 'orderby' );
		$this->db->select ( 'u.iduser, 
				u.firstname AS `firstname`, 
				u.lastname AS `lastname`, 
				u.email AS `email`, 
				u.is_active AS `is_active`, 
				u.service_request AS `service_request`, 
				u.surveillance AS `surveillance`, 
				u.treatments AS `treatments`, 
				u.reports AS `reports`, 
				u.company_admin AS `company_admin`, 
				u.device_managment AS `device_managment`' );
		$this->db->from ( 'users AS u' );
		$this->db->join ( 'userlocationassignment AS ula', "u.iduser = ula.iduser", 'LEFT' );
		$this->db->join ( 'locations AS lc', "ula.idlocation = lc.idlocation", 'LEFT' );
		$this->db->where ( 'ula.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$orderby = $this->input->get ( 'orderby' );
		if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
			switch ($orderby) {
				case '0:asc' :
					$this->db->order_by ( 'u.firstname', 'ASC' );
					break;
				case '0:desc' :
					$this->db->order_by ( 'u.firstname', 'DESC' );
					break;
				case '1:asc' :
					$this->db->order_by ( 'u.email', 'ASC' );
					break;
				case '1:desc' :
					$this->db->order_by ( 'u.email', 'DESC' );
					break;
				case '2:asc' :
					$this->db->order_by ( 'u.is_active', 'ASC' );
					break;
				case '2:desc' :
					$this->db->order_by ( 'u.is_active', 'DESC' );
					break;
				case '3:asc' :
					$this->db->order_by ( 'u.service_request', 'ASC' );
					break;
				case '3:desc' :
					$this->db->order_by ( 'u.service_request', 'DESC' );
					break;
				case '4:asc' :
					$this->db->order_by ( 'u.surveillance', 'ASC' );
					break;
				case '4:desc' :
					$this->db->order_by ( 'u.surveillance', 'DESC' );
					break;
				case '5:asc' :
					$this->db->order_by ( 'u.treatments', 'ASC' );
					break;
				case '5:desc' :
					$this->db->order_by ( 'u.treatments', 'DESC' );
					break;
				case '6:asc' :
					$this->db->order_by ( 'u.reports', 'ASC' );
					break;
				case '6:desc' :
					$this->db->order_by ( 'u.reports', 'DESC' );
					break;
				case '7:asc' :
					$this->db->order_by ( 'u.company_admin', 'ASC' );
					break;
				case '7:desc' :
					$this->db->order_by ( 'u.company_admin', 'DESC' );
					break;
				case '8:asc' :
					$this->db->order_by ( 'u.device_managment', 'ASC' );
					break;
				case '8:desc' :
					$this->db->order_by ( 'u.device_managment', 'DESC' );
					break;
			}
		} else {
			$this->db->order_by ( 'u.firstname', 'ASC' );
		}
		
		$getData = $this->db->get ();
		// echo $this->db->last_query()."<br>";
		// die;
		if ($getData->num_rows () > 0)
			return $getData->result_array ();
		else
			return null;
	}
	
	/**
	 * Function to list all members mail
	 */
	public function listMembers() {
		$this->db->select ( '*' );
		$this->db->from ( 'users' );
		$ttl = $this->input->get ( 'ttl' );
		$page = $this->input->get ( 'page' );
		
		if (! isset ( $ttl ) || $ttl == '')
			$ttl = 10;
		
		if (! isset ( $page ) || $page == '')
			$page = 1;
		
		if (! is_null ( $ttl ) && ! is_null ( $page )) {
			if ($page == 1)
				$page = 0;
			else
				$page --;
			
			$page *= 10;
			$this->db->limit ( $ttl, $page );
		} else if (! is_null ( $ttl )) {
			$this->db->limit ( $ttl );
		}
		$data_1 = array ();
		$query = $this->db->get ();
		$result = array ();
		if ($query->num_rows () > 0) {
			$recordCount = $query->num_rows ();
			foreach ( $query->result_array () as $row ) {
				$data_1 [] = $row;
			}
			// Return result to jTable
			
			return $data_1;
		}
	}
	
	/**
	 * Function to fetch Salutaions in string
	 */
	public function getSalutations() {
		$this->db->select ( '*' );
		$this->db->from ( 'salutations' );
		$result = array ();
		$query = $this->db->get ();
		
        if ($query->num_rows () > 0) {
			$i = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$i] ['idsalutation'] = $row ['idsalutation'];
				$result [$i] ['salutation'] = $row ['salutation'];
				$i ++;
			}
		}
		return $result;
	}
	
	/**
	 * Function to fetch Salutaions
	 * selected by User
	 */
	public function getSalutationsSelected($Id) {
		if (empty ( $Id ))
			$Id = 0;
		
		$this->db->select ( '*' );
		$this->db->from ( 'salutations' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($row ['idsalutation'] == $Id)
					$this->str .= '<option value="' . $row ['idsalutation'] . '" selected="selected">' . $row ['salutation'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idsalutation'] . '">' . $row ['salutation'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Statuses of Member
	 */
	public function getStatuses() {
		$this->db->select ( 'iduser,
				is_active' );
		$this->db->from ( 'users' );
		$result = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			$k = 0;
			foreach ( $query->result_array () as $row ) {
				$result [$k] ['status'] = $row ['is_active'];
				$result [$k] ['iduser'] = $row ['iduser'];
				$k ++;
			}
		}
		
		return $result;
	}
	
	/**
	 * Function to fetch Suffixes in string
	 */
	public function getSuffixes() {
		$this->db->select ( '*' );
		$this->db->from ( 'suffixes' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['idsuffix'] . '">' . $row ['suffix'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Suffixes
	 * selected by User
	 */
	public function getSuffixesSelected($Id) {
		if (empty ( $Id ))
			$Id = 0;
		
		$this->db->select ( '*' );
		$this->db->from ( 'suffixes' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($row ['idsuffix'] == $Id)
					$this->str .= '<option value="' . $row ['idsuffix'] . '" selected="selected">' . $row ['suffix'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idsuffix'] . '">' . $row ['suffix'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to activate Member
	 */
	public function activeMember() {
		$id = $this->input->get_post ( 'id' );
		
		if (empty ( $id ))
			return false;
		
		$data ['is_active'] = '1';
		
		$this->db->where ( 'iduser', $id );
		$this->db->update ( 'users', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to deactivate Member
	 */
	public function deactiveMember() {
		$id = $this->input->get_post ( 'id' );
		
		if (empty ( $id ))
			return false;
		
		$data ['is_active'] = '0';
		
		$this->db->where ( 'iduser', $id );
		$this->db->update ( 'users', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}
    
    /**
	 * Function to get user by name
	 */
	public function getUserIdByName($name = '') {
        $iduser = '';
		if (empty ( $name ))
			return $iduser;
		
        $name = explode(' ', $name);
        if(count($name) > 0 && isset($name[0]) && !empty($name[0])) {
            $this->db->select ( 'users.iduser' );
    		$this->db->from ( 'users' );
            $this->db->join ( 'userlocationassignment AS ula', 'users.iduser = ula.iduser', 'INNER' );
            $this->db->where ( 'ula.idlocation', $this->session->userdata('idlocation') );
            $this->db->where ( 'users.isdeleted', '0' );
            $this->db->where ( 'users.firstname', $name[0] );
            if(count($name) == 2 && isset($name[1]) && !empty($name[1])) {
                $this->db->where ( 'users.lastname', $name[1] );   
            } else if(count($name) == 3) {
                if(isset($name[1]) && !empty($name[1])) {
                    $this->db->where ( 'users.middlename = $name[1]', $name[1] );
                    $this->db->or_where ( 'users.lastname', $name[1] );
                }
                if(isset($name[2]) && !empty($name[2])) {
                    $this->db->where ( 'users.lastname', $name[2] );
                    $this->db->or_where ( 'users.lastname', $name[1] );
                }
            }
            $iduser = $this->db->get()->row()->iduser;
            //echo $this->db->last_query()." $iduser <br>";
        }
        
		return $iduser;
	}
}

?>