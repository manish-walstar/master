<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Maintenanceinsp_model extends CI_Model {
	public $str = "";
	public $map = "";
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to Add a new Zone
	 */
	public function addmaintenanceinspection($idloc = '') {
		$site_id = '';
		$idloc = $this->session->userdata ( 'idlocation' );
		$site_id = $this->input->post ( 'site_id' );
		$data ['site'] = $this->input->post ( 'site' );
		$data ['idsitetype'] = $this->input->post ( 'idsitetype' );
		$data ['maplabel'] = $this->input->post ( 'maplabel' );
		$data ['address1'] = $this->input->post ( 'address1' );
		$data ['address2'] = $this->input->post ( 'address2' );
		$data ['city'] = $this->input->post ( 'city' );
		$data ['idstate'] = $this->input->post ( 'idstate' );
		$data ['latitude'] = $this->input->post ( 'latitude' );
		$data ['longitude'] = $this->input->post ( 'longitude' );
		$data ['pdop'] = $this->input->post ( 'pdop' );
		$data ['postalcode'] = $this->input->post ( 'postalcode' );
		if ($site_id == '0') {
			$this->db->query ( "SET foreign_key_checks = 0" );
			$this->db->insert ( 'sites', $data );
			$row_site = $this->db->affected_rows ();
			if (empty ( $row_site ))
				return false;
			$site_id = $this->db->insert_id ();
			$this->db->query ( "SET foreign_key_checks = 1" );
		/**
		 * end insert data into sites table*
		 */
		}
		
		$observed_date = $this->input->post ( 'observed_date' );
		$last_observed_date = $this->input->post ( 'last_observed_date' );
		$observed_time = $this->input->post ( 'observed_time' );
		$last_observed_time = $this->input->post ( 'last_observed_time' );
		
		$time =  date ( 'Y-m-d', strtotime ( $observed_date ) ) .' '.date ( 'H:i:s', strtotime ( $observed_time ) );
		$this->load->model('usermodel');
		$data_1 ['userId'] = $this->usermodel->getUserId();

		$data_1 ['idsite'] = $site_id;
		$data_1 ['observeddatetime'] = $time;
		$data_1 ['observedtime'] = date ( 'h:i:s A', strtotime ( $observed_time ) );
		$data_1 ['observeddate'] = date ( 'Y-m-d', strtotime ( $observed_date ) );
		$data_1 ['lastdateobserved'] = date ( 'Y-m-d', strtotime ( $last_observed_date ) );
		$data_1 ['lasttimeobserved'] = date ( 'h:i:s A', strtotime ( $last_observed_time ) );
		$data_1 ['reinspection'] = $this->input->post ( 're_inspection' );
		$data_1 ['ownerinformation'] = $this->input->post ( 'owner_information' );
		$data_1 ['parcelnumber'] = $this->input->post ( 'parcel_number' );
		$data_1 ['outfallnumber'] = $this->input->post ( 'outfall_number' );
		$data_1 ['arcms4outfall'] = $this->input->post ( 'arc_outfall' );
		$data_1 ['localcontact'] = $this->input->post ( 'local_contact' );
		$data_1 ['watershed'] = $this->input->post ( 'watershed' );
		$data_1 ['installed_flag'] = $this->input->post ( 'installed_flag' );
		$data_1 ['installed_notes'] = $this->input->post ( 'installed_notes' );
		$data_1 ['intact_flag'] = $this->input->post ( 'intact_flag' );
		$data_1 ['intact_notes'] = $this->input->post ( 'intact_notes' );
		$data_1 ['locked_flag'] = $this->input->post ( 'locked_flag' );
		$data_1 ['locked_notes'] = $this->input->post ( 'locked_notes' );
		$data_1 ['overgrown_flag'] = $this->input->post ( 'overgrown_flag' );
		$data_1 ['overgrown_notes'] = $this->input->post ( 'overgrown_notes' );
		$data_1 ['surfaceerosion_flag'] = $this->input->post ( 'surface_erosion_flag' );
		$data_1 ['surfaceerosion_notes'] = $this->input->post ( 'surface_erosion_notes' );
		$data_1 ['stagnatewater_flag'] = $this->input->post ( 'stagnate_water_flag' );
		$data_1 ['stagnatewater_notes'] = $this->input->post ( 'stagnate_water_notes' );
		$data_1 ['trashdebrisfree_flag'] = $this->input->post ( 'trash_free_flag' );
		$data_1 ['trashdebrisfree_notes'] = $this->input->post ( 'trash_free_notes' );
		$data_1 ['banksintact_flag'] = $this->input->post ( 'banks_intact_flag' );
		$data_1 ['banksintact_notes'] = $this->input->post ( 'banks_intact_notes' );
		$data_1 ['damcracking_flag'] = $this->input->post ( 'dam_cracking_flag' );
		$data_1 ['damcracking_notes'] = $this->input->post ( 'dam_cracking_notes' );
		$data_1 ['channelizedflow_flag'] = $this->input->post ( 'channelized_flow_flag' );
		$data_1 ['channelizedflow_notes'] = $this->input->post ( 'channelized_flow_notes' );
		$data_1 ['controlstructureintact_flag'] = $this->input->post ( 'control_structure_intact_flag' );
		$data_1 ['controlstructureintact_notes'] = $this->input->post ( 'control_structure_intact_notes' );
		$data_1 ['controlstructurefunctional_flag'] = $this->input->post ( 'control_structure_functional_flag' );
		$data_1 ['controlstructurefunctional_notes'] = $this->input->post ( 'control_structure_functional_notes' );
		$data_1 ['trashaccumulation_flag'] = $this->input->post ( 'trash_accumulation_flag' );
		$data_1 ['trashaccumulation_notes'] = $this->input->post ( 'trash_accumulation_notes' );
		$data_1 ['emergencyspillway_flag'] = $this->input->post ( 'emg_spillway_flag' );
		$data_1 ['emergencyspillway_notes'] = $this->input->post ( 'emg_spillway_notes' );
		$data_1 ['outflowstructureintact_flag'] = $this->input->post ( 'outflow_structure_intact_flag' );
		$data_1 ['outflowstructureintact_notes'] = $this->input->post ( 'outflow_structure_intact_notes' );
		$data_1 ['outflowstructurefunctional_flag'] = $this->input->post ( 'outflow_structure_functional_flag' );
		$data_1 ['outflowstructurefunctional_notes'] = $this->input->post ( 'outflow_structure_functional_notes' );
		$data_1 ['dischargeoutletaccessible'] = $this->input->post ( 'discharge_outlet_accessible' );
		$data_1 ['outletcontrolpresent'] = $this->input->post ( 'outlet_control_present' );
		$data_1 ['dischargepipediameter'] = $this->input->post ( 'pipe_diameter' );
		$data_1 ['dischargepipematerial'] = $this->input->post ( 'pipe_material' );
		$data_1 ['idzone'] = $this->input->post ( 'idzone' );
		$data_1 ['maplabel'] = $this->input->post ( 'maplabel' );
		$data_1 ['latitude'] = $this->input->post ( 'latitude' );
		$data_1 ['longitude'] = $this->input->post ( 'longitude' );
		$data_1 ['idinspector'] = $this->input->post ( 'idinspector' );
		$data_1 ['comments'] = $this->input->post ( 'comments' );
		$data_1 ['sitename'] = $this->input->post ( 'site' );
		$data_1 ['idsitetype'] = $this->input->post ( 'idsitetype' );
		$data_1 ['idlocation'] = ! empty ( $idloc ) ? $idloc : '0';
		// echo '<pre>';print_r($data_1);die;
		$this->db->query ( "SET foreign_key_checks = 0" );
		$this->db->insert ( 'maintenanceinspection', $data_1 );
		$rows = $this->db->affected_rows ();
		// $rows = 1;
		if (empty ( $rows ))
			return false;
		
		$id = $this->db->insert_id ();
		$this->db->query ( "SET foreign_key_checks = 1" );
		
		
		
		return $id;
	}
	
	/**
	 * Function to Update a new Adultsurveillance
	 */
	public function updateMaintenanceinspection($Id = '', $idloc = '') {
		if (empty ( $Id ))
			return false;
			
		$site_id = '';
		$site_id = $this->input->post ( 'site_id' );
		$data ['site'] = $this->input->post ( 'site' );
		$data ['idsitetype'] = $this->input->post ( 'idsitetype' );
		$data ['maplabel'] = $this->input->post ( 'maplabel' );
		$data ['address1'] = $this->input->post ( 'address1' );
		$data ['address2'] = $this->input->post ( 'address2' );
		$data ['city'] = $this->input->post ( 'city' );
		$data ['idstate'] = $this->input->post ( 'idstate' );
		$data ['latitude'] = $this->input->post ( 'latitude' );
		$data ['longitude'] = $this->input->post ( 'longitude' );
		$data ['pdop'] = $this->input->post ( 'pdop' );
		$data ['postalcode'] = $this->input->post ( 'postalcode' );
		if ($site_id == '0') {
			$this->db->query ( "SET foreign_key_checks = 0" );
			$this->db->insert ( 'sites', $data_site );
			$row_site = $this->db->affected_rows ();
			if (empty ( $row_site ))
				return false;
			$site_id = $this->db->insert_id ();
			$this->db->query ( "SET foreign_key_checks = 1" );
		}
		$observed_date = $this->input->post ( 'observed_date' );
		$observed_time = $this->input->post ( 'observed_time' );
		$last_observed_date = $this->input->post ( 'last_observed_date' );
		$last_observed_time = $this->input->post ( 'last_observed_time' );
		
		/**
		 * end insert data into sites table*
		 */
		 $time =  date ( 'Y-m-d', strtotime ( $observed_date ) ) .' '.date ( 'H:i:s', strtotime ( $observed_time ) );


		 $data_1 ['idsite'] = $site_id;
		$data_1 ['observeddatetime'] = $time;
		$data_1 ['observedtime'] = date ( 'h:i:s A', strtotime ( $observed_time ) );
		$data_1 ['observeddate'] = date ( 'Y-m-d', strtotime ( $observed_date ) );
		$data_1 ['lastdateobserved'] = date ( 'Y-m-d', strtotime ( $last_observed_date ) );
		$data_1 ['lasttimeobserved'] = date ( 'h:i:s A', strtotime ( $last_observed_time ) );
		$data_1 ['reinspection'] = $this->input->post ( 're_inspection' );
		$data_1 ['ownerinformation'] = $this->input->post ( 'owner_information' );
		$data_1 ['parcelnumber'] = $this->input->post ( 'parcel_number' );
		$data_1 ['outfallnumber'] = $this->input->post ( 'outfall_number' );
		$data_1 ['arcms4outfall'] = $this->input->post ( 'arc_outfall' );
		$data_1 ['localcontact'] = $this->input->post ( 'local_contact' );
		$data_1 ['watershed'] = $this->input->post ( 'watershed' );
		$data_1 ['installed_flag'] = $this->input->post ( 'installed_flag' );
		$data_1 ['installed_notes'] = $this->input->post ( 'installed_notes' );
		$data_1 ['intact_flag'] = $this->input->post ( 'intact_flag' );
		$data_1 ['intact_notes'] = $this->input->post ( 'intact_notes' );
		$data_1 ['locked_flag'] = $this->input->post ( 'locked_flag' );
		$data_1 ['locked_notes'] = $this->input->post ( 'locked_notes' );
		$data_1 ['overgrown_flag'] = $this->input->post ( 'overgrown_flag' );
		$data_1 ['overgrown_notes'] = $this->input->post ( 'overgrown_notes' );
		$data_1 ['surfaceerosion_flag'] = $this->input->post ( 'surface_erosion_flag' );
		$data_1 ['surfaceerosion_notes'] = $this->input->post ( 'surface_erosion_notes' );
		$data_1 ['stagnatewater_flag'] = $this->input->post ( 'stagnate_water_flag' );
		$data_1 ['stagnatewater_notes'] = $this->input->post ( 'stagnate_water_notes' );
		$data_1 ['trashdebrisfree_flag'] = $this->input->post ( 'trash_free_flag' );
		$data_1 ['trashdebrisfree_notes'] = $this->input->post ( 'trash_free_notes' );
		$data_1 ['banksintact_flag'] = $this->input->post ( 'banks_intact_flag' );
		$data_1 ['banksintact_notes'] = $this->input->post ( 'banks_intact_notes' );
		$data_1 ['damcracking_flag'] = $this->input->post ( 'dam_cracking_flag' );
		$data_1 ['damcracking_notes'] = $this->input->post ( 'dam_cracking_notes' );
		$data_1 ['channelizedflow_flag'] = $this->input->post ( 'channelized_flow_flag' );
		$data_1 ['channelizedflow_notes'] = $this->input->post ( 'channelized_flow_notes' );
		$data_1 ['controlstructureintact_flag'] = $this->input->post ( 'control_structure_intact_flag' );
		$data_1 ['controlstructureintact_notes'] = $this->input->post ( 'control_structure_intact_notes' );
		$data_1 ['controlstructurefunctional_flag'] = $this->input->post ( 'control_structure_functional_flag' );
		$data_1 ['controlstructurefunctional_notes'] = $this->input->post ( 'control_structure_functional_notes' );
		$data_1 ['trashaccumulation_flag'] = $this->input->post ( 'trash_accumulation_flag' );
		$data_1 ['trashaccumulation_notes'] = $this->input->post ( 'trash_accumulation_notes' );
		$data_1 ['emergencyspillway_flag'] = $this->input->post ( 'emg_spillway_flag' );
		$data_1 ['emergencyspillway_notes'] = $this->input->post ( 'emg_spillway_notes' );
		$data_1 ['outflowstructureintact_flag'] = $this->input->post ( 'outflow_structure_intact_flag' );
		$data_1 ['outflowstructureintact_notes'] = $this->input->post ( 'outflow_structure_intact_notes' );
		$data_1 ['outflowstructurefunctional_flag'] = $this->input->post ( 'outflow_structure_functional_flag' );
		$data_1 ['outflowstructurefunctional_notes'] = $this->input->post ( 'outflow_structure_functional_notes' );
		$data_1 ['dischargeoutletaccessible'] = $this->input->post ( 'discharge_outlet_accessible' );
		$data_1 ['outletcontrolpresent'] = $this->input->post ( 'outlet_control_present' );
		$data_1 ['dischargepipediameter'] = $this->input->post ( 'pipe_diameter' );
		$data_1 ['dischargepipematerial'] = $this->input->post ( 'pipe_material' );
		$data_1 ['idzone'] = $this->input->post ( 'idzone' );
		$data_1 ['maplabel'] = $this->input->post ( 'maplabel' );
		$data_1 ['latitude'] = $this->input->post ( 'latitude' );
		$data_1 ['longitude'] = $this->input->post ( 'longitude' );
		$data_1 ['idinspector'] = $this->input->post ( 'idinspector' );
		$data_1 ['comments'] = $this->input->post ( 'comments' );
		$data_1 ['sitename'] = $this->input->post ( 'site' );
		$data_1 ['idsitetype'] = $this->input->post ( 'idsitetype' );


		//echo '<pre>';print_r($data_1);die;
		// $data_1['idlocation'] = !empty($idloc)?$idloc:'0';
		$this->db->where ( 'idmaintenanceinspection', $Id );
		$this->db->update ( 'maintenanceinspection', $data_1 );
		
		$rows = $this->db->affected_rows ();
		if (empty ( $rows ) && empty ( $Id ))
			return false;
		
		
		
		return $Id;
	}
	
	/**
	 * Function to list all maintenance inspection
	 */
	public function deleteMaintenanceinspection() {
		$idmaintenanceinspection = $this->input->get_post ( 'id' );
		
		if (empty ( $idmaintenanceinspection ))
			return false;
			
		
		$data ['isdeleted'] = '1';
		$this->db->where ( 'idmaintenanceinspection', $idmaintenanceinspection );
		$this->db->update ( 'maintenanceinspection', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ) && empty ( $id ))
			return false;
		
		return true;
	}
	
	
	/**
	 * Function to list all Adultsurveillances mail
	 */
	public function getmaintenanceinspection($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( '`maintenanceinspection`.*' );
		$this->db->from ( 'maintenanceinspection' );
		$this->db->where ( 'isdeleted', '0' );
		
		$this->db->where ( '`maintenanceinspection`.`idmaintenanceinspection`', $Id );
		
		$query = $this->db->get ();
		
		$data = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row )
				$data [] = $row;
			
			return $data [0];
		}
		
		return false;
	}
	/**
	 * Function to list all maintenance inspection
	 */
	public function listMaintenanceinspection($Ids = "", $mapSite = "", $mapFlag = "") {
		$this->db->select ( 'maintenanceinspection.idmaintenanceinspection,
				s.site AS sitename,
				s.idzone, 
				zones.`zone`, 
				maintenanceinspection.observeddate, 
				maintenanceinspection.parcelnumber ,
				maintenanceinspection.outfallnumber ' );
		$this->db->from ( 'maintenanceinspection' );
		$this->db->join ( 'sites AS s', 'maintenanceinspection.idsite = s.idsite', 'LEFT' );
		$this->db->join ( 'zones', 's.idzone = zones.idzone', 'LEFT' );
		$this->db->join ( 'locations AS l', 'maintenanceinspection.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( 'maintenanceinspection.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'maintenanceinspection.isdeleted', '0' );
        
		$filter_date = $this->input->get ( 'filter_date' );
		$ttl = $this->input->get ( 'ttl' );
		$page = $this->input->get ( 'page' );
		$frmdate = $this->input->get ( 'frmdate' );
		$todate = $this->input->get ( 'todate' );
		$orderby = $this->input->get ( 'orderby' );
		
        if (! isset ( $filter_date ) || $filter_date == '')
			$filter_date = 2;
		
		if (! isset ( $ttl ) || $ttl == '')
			$ttl = 10;
		
		if (! isset ( $page ) || $page == '')
			$page = 1;
		
        if(!empty($mapSite)){
            $this->db->where ( 's.idsite', $mapSite );
		}
        if(!empty($mapSite) || !empty($mapFlag)){
            $filter_date = "";
            $filter_daterange = "";
            $frmdate = "";
            $todate = "";
            $orderby = "";
            $ttl = "";
            $page = "";
		}
        
		if (! empty ( $frmdate ) && ! empty ( $todate )) {
			$frmdate = substr ( $frmdate, 0, 2 ) . '/' . substr ( $frmdate, 2, 2 ) . '/' . substr ( $frmdate, 4, 4 );
			$todate = substr ( $todate, 0, 2 ) . '/' . substr ( $todate, 2, 2 ) . '/' . substr ( $todate, 4, 4 );
			$this->db->where ( 'maintenanceinspection.observeddate' . ' >=', date ( 'Y-m-d', strtotime ( $frmdate ) ) );
			$this->db->where ( 'maintenanceinspection.observeddate' . ' <=', date ( 'Y-m-d', strtotime ( $todate ) ) );
		} else if (! is_null ( $filter_date )) {
			switch ($filter_date) {
				// date('H:i:s',strtotime('-1 day');
				case '1' :
					$this->db->where ( 'maintenanceinspection.observeddate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 day' ) ) );
					$this->db->where ( 'maintenanceinspection.observeddate' . ' <=', date ( 'Y-m-d' ) );
					break;
				
				case '2' :
					$this->db->where ( 'maintenanceinspection.observeddate' . ' >=', date ( 'Y-m-d', strtotime ( '-7 day' ) ) );
					$this->db->where ( 'maintenanceinspection.observeddate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '3' :
					$this->db->where ( 'maintenanceinspection.observeddate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 month' ) ) );
					$this->db->where ( 'maintenanceinspection.observeddate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '4' :
					$this->db->where ( 'maintenanceinspection.observeddate' . ' >=', date ( 'Y-m-d', strtotime ( '-4 month' ) ) );
					$this->db->where ( 'maintenanceinspection.observeddate' . ' <=', date ( 'Y-m-d' ) );
					break;
				case '5' :
					$this->db->where ( 'maintenanceinspection.observeddate' . ' >=', date ( 'Y-m-d', strtotime ( '-1 year' ) ) );
					$this->db->where ( 'maintenanceinspection.observeddate' . ' <=', date ( 'Y-m-d' ) );
					break;
			}
		}
		
		
		
		if (isset ( $orderby ) && ! empty ( $orderby ) && $orderby != 'none') {
			switch ($orderby) {
				case '0:asc' :
					$this->db->order_by ( 'sites.site', 'ASC' );
					break;
				case '0:desc' :
					$this->db->order_by ( 'sites.site', 'DESC' );
					break;
				case '1:asc' :
					$this->db->order_by ( 'zones.zone', 'ASC' );
					break;
				case '1:desc' :
					$this->db->order_by ( 'zones.zone', 'DESC' );
					break;
				case '2:asc' :
					$this->db->order_by ( 'maintenanceinspection.observeddatetime', 'ASC' );
					break;
				case '2:desc' :
					$this->db->order_by ( 'maintenanceinspection.observeddatetime', 'DESC' );
					break;
				case '3:asc' :
					$this->db->order_by ( 'maintenanceinspection.parcelnumber', 'ASC' );
					break;
				case '3:desc' :
					$this->db->order_by ( 'maintenanceinspection.parcelnumber', 'DESC' );
					break;
				case '4:asc' :
					$this->db->order_by ( 'maintenanceinspection.outfallnumber', 'ASC' );
					break;
				case '4:desc' :
					$this->db->order_by ( 'maintenanceinspection.outfallnumber', 'DESC' );
					break;
			}
		} else {
			$this->db->order_by ( 'maintenanceinspection.observeddatetime', 'DESC' );
		}
		
		$data_1 = array ();
        if(!empty($Ids)) {
            $this->db->where_in ( 'maintenanceinspection.idmaintenanceinspection', $Ids );
        }
		$query = $this->db->get ();
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
		
		return false;
	}
	public function getLastImage($req){
		$last_row=$this->db->select('imageurl')->where('idmaintenanceinspection' , $req)->order_by('idimage',"desc")->limit(1)->get('mirimages')->row();
		//echo"last row:" ; print_r($last_row);die;
		return $last_row;
	}
	public function saveImage($idmaintenanceinspection ,$url){
		$data['idmaintenanceinspection'] = $idmaintenanceinspection;
		$data['imageurl'] = $url;
		$this->db->insert('mirimages' , $data);
	}
	public function getImages($idmaintenanceinspection){
		$this->db->select('i.imageurl');
		$this->db->from('mirimages AS i');
		$this->db->where('i.idmaintenanceinspection' , $idmaintenanceinspection);
		$this->db->where('i.isdeleted' , 0);
		$query = $this->db->get();
		if($query->num_rows() >0 )
			return $query->result_array();
		return "";
	}
	public function removeImage($image){
		If(!empty($image)){
			$data['isdeleted'] = 1;
			$this->db->where('imageurl' , $image );
			$this->db->update('mirimages' , $data);
			//echo"query: " . $this->db->last_query() . "rows affected:" . $this->db->affected_rows (); die;
			return true;
		}
		return false;
	}
	/**
	 * Function to fetch Inspector List
	 */
	public function getInspectors() {
		$this->db->select ( 'u.iduser,
				u.firstname,
				u.middlename,
				u.lastname' );
		$this->db->from ( 'users AS u' );
		$this->db->join ( 'userlocationassignment AS ula', 'u.iduser = ula.iduser', 'LEFT' );
		$this->db->join ( 'locations AS l', 'ula.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( 'l.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'u.is_active', '1' );
		$this->db->order_by ( 'u.firstname' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$middlename = ! empty ( $row ['middlename'] ) ? " " . $row ['middlename'] . " " : " ";
				$this->str .= '<option value="' . $row ['iduser'] . '">' . $row ['firstname'] . $middlename . $row ['lastname'] . '</option>';
			}
		}
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Inspector List
	 */
	public function getSelectedInspectors($Id = '') {
		$this->db->select ( 'u.iduser,
				u.firstname,
				u.middlename,
				u.lastname' );
		$this->db->from ( 'users AS u' );
		$this->db->join ( 'userlocationassignment AS ula', 'u.iduser = ula.iduser', 'LEFT' );
		$this->db->join ( 'locations AS l', 'ula.idlocation = l.idlocation', 'LEFT' );
		$this->db->where ( 'l.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'u.is_active', '1' );
		$this->db->order_by ( 'u.firstname' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$middlename = ! empty ( $row ['middlename'] ) ? " " . $row ['middlename'] . " " : " ";
				
				if ($Id == $row ['iduser'])
					$this->str .= '<option value="' . $row ['iduser'] . '" selected="true">' . $row ['firstname'] . $middlename . $row ['lastname'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['iduser'] . '">' . $row ['firstname'] . $middlename . $row ['lastname'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Trap Names
	 */
	public function getTrapname() {
		$this->db->select ( 't.idtrap,t.trap' );
		$this->db->from ( 'traps AS t' );
		$this->db->join ( 'sites AS s', 't.idsite = s.idsite', 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 't.active', '1' );
		$this->db->where ( 't.isdeleted', '0' );
		$this->db->order_by ( 't.trap', 'asc' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['idtrap'] . '">' . $row ['trap'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Trap Names
	 */
	public function getSelectedTrapname($Id = '') {
		$this->db->select ( 't.idtrap,t.trap' );
		$this->db->from ( 'traps AS t' );
		$this->db->join ( 'sites AS s', 't.idsite = s.idsite', 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 't.active', '1' );
		$this->db->where ( 't.isdeleted', '0' );
		$this->db->order_by ( 't.trap', 'asc' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idtrap'])
					$this->str .= '<option value="' . $row ['idtrap'] . '" selected="true">' . $row ['trap'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idtrap'] . '">' . $row ['trap'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Temp Range
	 */
	public function getTemprange($Id = '') {
		$this->db->select ( 'idtemprange,temprange,ordering' );
		$this->db->from ( 'tempranges' );
		$this->db->order_by ( "ordering", "ASC" );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idtemprange']) {
					$this->str .= '<option value="' . $row ['idtemprange'] . '" selected="true">' . $row ['temprange'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idtemprange'] . '">' . $row ['temprange'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Temp Range
	 */
	public function getSelectedTemprange($Id = '') {
		$this->db->select ( 'idtemprange,temprange,ordering' );
		$this->db->from ( 'tempranges' );
		$this->db->order_by ( "ordering", "ASC" );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idtemprange'])
					$this->str .= '<option value="' . $row ['idtemprange'] . '" selected="true">' . $row ['temprange'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idtemprange'] . '">' . $row ['temprange'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Humidity Range
	 */
	public function getHumidityrange($Id = '') {
		$this->db->select ( 'idhumidityrange,humidityrange' );
		$this->db->from ( 'humidityranges' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idhumidityrange'])
					$this->str .= '<option value="' . $row ['idhumidityrange'] . '" selected="true">' . $row ['humidityrange'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idhumidityrange'] . '">' . $row ['humidityrange'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Humidity Range
	 */
	public function getSelectedHumidityrange($Id = '') {
		$this->db->select ( 'idhumidityrange,humidityrange' );
		$this->db->from ( 'humidityranges' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idhumidityrange'])
					$this->str .= '<option value="' . $row ['idhumidityrange'] . '" selected= "true">' . $row ['humidityrange'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idhumidityrange'] . '">' . $row ['humidityrange'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Wind Speed
	 */
	public function getWindspeed() {
		$this->db->select ( 'idwindspeed,windspeed' );
		$this->db->from ( 'windspeeds' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['idwindspeed'] . '">' . $row ['windspeed'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Wind Speed
	 */
	public function getSelectedWindspeed($Id = '') {
		$this->db->select ( 'idwindspeed,windspeed' );
		$this->db->from ( 'windspeeds' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idwindspeed'])
					$this->str .= '<option value="' . $row ['idwindspeed'] . '" selected="true">' . $row ['windspeed'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idwindspeed'] . '">' . $row ['windspeed'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Cloud Coverage
	 */
	public function getCloudcoverage() {
		$this->db->select ( 'idcloudcoverage,cloudcoverage' );
		$this->db->order_by ( 'cloudcoverage' );
		$this->db->from ( 'cloudcoverage' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$this->str .= '<option value="' . $row ['idcloudcoverage'] . '">' . $row ['cloudcoverage'] . '</option>';
			}
		}
		
		return $this->str;
	}
	
	/**
	 * Function to fetch Selected Cloud Coverage
	 */
	public function getSelectedCloudcoverage($Id = '') {
		$this->db->select ( 'idcloudcoverage,cloudcoverage' );
		$this->db->from ( 'cloudcoverage' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idcloudcoverage'])
					$this->str .= '<option value="' . $row ['idcloudcoverage'] . '" selected="true">' . $row ['cloudcoverage'] . '</option>';
				else
					$this->str .= '<option value="' . $row ['idcloudcoverage'] . '">' . $row ['cloudcoverage'] . '</option>';
			}
		}
		
		return $this->str;
	}
	

	
	
	/**
	 * function to get zone name
	 */
	public function getzone($Id = '') {
		$this->db->select ( 'idzone' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'sites.active', '1' );
		$this->db->where ( 'sites.isdeleted', '0' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'idsite', $Id );
		$query = $this->db->get ();
		if ($query->num_rows () > 0)
			return $query->result_array ();
	}
	
	/**
	 * Function to fetch Site Names
	 */
	public function getSitename($Id = '') {
		$this->db->select ( 'idsite,site' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'active', '1' );
		$this->db->where ( 'isdeleted', '0' );
		$this->db->order_by ( "site", "ASC" );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idsite']) {
					$this->str .= '<option value="' . $row ['idsite'] . ' " selected="true">' . $row ['site'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idsite'] . '">' . $row ['site'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	/**
	 * Function to fetch Site details
	 */
	public function getSiteDetails($Id = '') {
		$this->db->select ( '*' );
		$this->db->from ( 'sites' );
		$this->db->where ( 'sites.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'active', '1' );
		$this->db->where ( 'isdeleted', '0' );
		$this->db->where ( 'idsite', $Id );
		$results = array ();
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				$results = $row;
			}
		}
		
		return $results;
	}
	/**
	 * Function to fetch site type
	 */
	public function getSelectedSitetype($Id = '') {
		$this->db->select ( 'idsitetype,sitetype' );
		$this->db->from ( 'sitetypes' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idsitetype']) {
					$this->str .= '<option value="' . $row ['idsitetype'] . '" selected="true">' . $row ['sitetype'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idsitetype'] . '">' . $row ['sitetype'] . '</option>';
				}
			}
		}
		
		return $this->str;
	}
	/**
	 * Function to fetch selected Zone name
	 */
	public function getSelectedZonename($Id = '') {
		$this->db->select ( 'idzone,zone' );
		$this->db->order_by ( 'zone' );
		$this->db->from ( 'zones' );
		$this->db->where ( 'active', '1' );
		$this->db->where ( 'isdeleted', '0' );
		$this->db->where ( 'zones.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idzone']) {
					$this->str .= '<option value="' . $row ['idzone'] . '" selected="true">' . $row ['zone'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idzone'] . '">' . $row ['zone'] . '</option>';
				}
			}
		}
		return $this->str;
	}
	
	/**
	 * Function to fetch get State name
	 */
	public function getStatename($Id = '') {
		if (empty ( $Id )) {
			$this->db->select ( 'states.idstate' );
			$this->db->from ( 'states' );
			$this->db->join ( 'locations AS lc', "states.idstate = lc.idstate", 'LEFT' );
			$this->db->where ( 'lc.idlocation', $this->session->userdata ( 'idlocation' ) );
			
			$q = $this->db->get ();
			if ($q->num_rows () > 0) {
				$Id = $q->result_array ();
				$Id = $Id [0] ['idstate'];
			}
		}
		$this->db->select ( 'st.idstate,st.statename' );
		$this->db->from ( 'states AS st' );
		$this->db->order_by ( 'st.statename' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if (! empty ( $Id ) && $Id == $row ['idstate']) {
					$this->str .= '<option value="' . $row ['idstate'] . '" selected="true">' . $row ['statename'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['idstate'] . '">' . $row ['statename'] . '</option>';
				}
			}
		}
		return $this->str;
	}
	
	/**
	 * Function to fetch get State value by name
	 */
	public function getStatebyName($Id = '') {
		if (empty ( $Id )) {
			$this->db->select ( 'states.idstate' );
			$this->db->from ( 'states' );
			$this->db->join ( 'locations AS lc', "states.idstate = lc.idstate", 'LEFT' );
			$this->db->where ( 'lc.idlocation', $this->session->userdata ( 'idlocation' ) );
			
			$q = $this->db->get ();
			if ($q->num_rows () > 0) {
				$Id = $q->result_array ();
				$Id = $Id [0] ['idstate'];
			}
		}
		$this->db->select ( 'st.idstate,st.statename' );
		$this->db->from ( 'states AS st' );
		$this->db->order_by ( 'st.statename' );
		$this->str = "";
		$query = $this->db->get ();
		
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row ) {
				if ($Id == $row ['idstate']) {
					$this->str .= '<option value="' . $row ['statename'] . '" selected="true">' . $row ['statename'] . '</option>';
				} else {
					$this->str .= '<option value="' . $row ['statename'] . '">' . $row ['statename'] . '</option>';
				}
			}
		}
		return $this->str;
	}
	
	
	
}
