<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Chicken_model extends CI_Model {
	
	/**
	 * Constructor for the class
	 * Chicken
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to Add a new Chicken
	 */
	public function addChicken($id = '') {
		$insert_id = "";
		
		$idsentinel = $this->input->post ( 'sentinel' );
		$dateinstalled = $this->input->post ( 'dateinstalled' );
		
		$data ['idsentinelchicken'] = ! empty ( $idsentinel ) ? $idsentinel : '0';
		$data ['bandid'] = $this->input->post ( 'bandid' );
		$data ['dateinstalled'] = ! empty ( $dateinstalled ) ? date ( 'Y-m-d', strtotime ( $dateinstalled ) ) : date ( 'Y-m-d' );
		
		if (! empty ( $id )) {
			$this->db->where ( 'idscs', $id );
			$this->db->update ( 'sentinelchickensamples', $data );
			$insert_id = $id;
		} else {
			$this->db->insert ( 'sentinelchickensamples', $data );
			$insert_id = $this->db->insert_id ();
		}
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ) && empty ( $insert_id ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to list all Chickens
	 */
	public function deleteChicken() {
		$idchicken = $this->input->get_post ( 'id' );
		if (empty ( $idchicken ))
			return false;
		
		$data ['isDeleted'] = '1';
		$this->db->where ( 'idscs', $idchicken );
		$this->db->update ( 'sentinelchickensamples', $data );
		
		$rows = $this->db->affected_rows ();
		
		if (empty ( $rows ))
			return false;
		
		return true;
	}
	
	/**
	 * Function to list all Chickens mail
	 */
	public function getChickenData($Id = '') {
		if (empty ( $Id ))
			return false;
		
		$this->db->select ( 'ss.*' );
		$this->db->from ( 'sentinelchickensamples AS ss' );
		$this->db->join ( 'sentinelchicken AS sc', "ss.idsentinelchicken = sc.idsentinelchicken", 'LEFT' );
		$this->db->join ( 'sites AS s', "sc.idsite = s.idsite", 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'ss.isdeleted', '0' );
		$this->db->where ( 'ss.idscs', $Id );
		
		$query = $this->db->get ();
		$data = array ();
		if ($query->num_rows () > 0) {
			foreach ( $query->result_array () as $row )
				$data [] = $row;
			
			return $data [0];
		}
	}
	
	/**
	 * Function to list all Chickens mail
	 */
	public function listChickens($id = '') {
		$this->db->select ( '*' );
		$this->db->from ( 'sentinelchickensamples AS ss' );
		$this->db->join ( 'sentinelchicken AS sc', "ss.idsentinelchicken = sc.idsentinelchicken", 'LEFT' );
		$this->db->join ( 'sites AS s', "sc.idsite = s.idsite", 'LEFT' );
		$this->db->where ( 's.idlocation', $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'ss.isdeleted', '0' );
		$idsentinel = $this->input->get ( 'idsentinel' );
		$page_size = $this->input->get ( 'ttl' );
		$page = $this->input->get ( 'page' );
		
        $offset = 0;
        $page_size = ($page_size == 'all') ? 'all' : (is_numeric($page_size) ? $page_size : 10);
        $limit = (is_numeric($page_size)) ? $page_size : NULL;        
        $offset = $limit * ($page - 1);
        
		$this->db->limit ( $limit, $offset );
                
		if (! empty ( $idsentinel ))
			$this->db->where ( 'sc.idsentinelchicken', $idsentinel );
		
		$data_1 = array ();
		$query = $this->db->get ();
		// echo $this->db->last_query();
		// die;
		$result = array ();
		
		if ($query->num_rows () > 0)
			return $query->result_array ();
	}
	
	/**
	 * Function to fetch Flock Name
	 */
	public function getFlockName($id = '') {
		if (empty ( $id ))
			return null;
		
		$this->db->select ( 'flockname' );
		$this->db->from ( 'sentinelchicken' );
		
		$this->db->join ( 'sites AS s', "sentinelchicken.idsite = s.idsite", 'LEFT' );
		$this->db->where ( 'sentinelchicken.idlocation', $this->session->userdata ( 'idlocation' ) );
		
		$this->db->where ( 'idsentinelchicken', $id );
		
		$query = $this->db->get ();
		$result = array ();
		
		if ($query->num_rows () > 0) {
			$result = $query->result_array ();
			
			return $result [0] ['flockname'];
		}
		
		return null;
	}
}
