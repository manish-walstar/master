<?php
error_reporting ( 0 );
//error_reporting(E_ALL);
//ini_set("display_errors", 1);
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Larvalsurveillance_report_model extends CI_Model {
	public $data = array();
	
	/**
	 * Constructor for the class
	 * Zone
	 */
	public function __construct() {
		// Call the Model constructor
		parent::__construct ();
	}
	
	/**
	 * Function to fetch Larval Surveillance
	 */
	public function getLarvalSurveillance($startdate = '', $enddate = '', $zone = '', $site = '', $_species = '', $techs = '') {
		$startdate_arr = explode ( "/", $startdate );
		$startdate = $startdate_arr [2] . "-" . $startdate_arr [0] . "-" . $startdate_arr [1];
		
		$enddate_arr = explode ( "/", $enddate );
		$enddate = $enddate_arr [2] . "-" . $enddate_arr [0] . "-" . $enddate_arr [1];
		
		$this->db->select ( 'z.idzone, z.zone' );
		$this->db->from ( 'larvalsurveillance AS ls' );
		$this->db->join ( 'sites AS s', "ls.idsite = s.idsite", 'INNER' );
		$this->db->join ( 'zones AS z', "s.idzone = z.idzone", 'INNER' );
		$this->db->where ( "s.idlocation", $this->session->userdata ( 'idlocation' ) );
		$this->db->where ( 'ls.date >=', $startdate );
		$this->db->where ( 'ls.date <=', $enddate );
		$this->db->where ( 'ls.isdeleted', '0' );
		if (! empty ( $zone ))
			$this->db->where ( 'z.idzone', $zone );
		
		$this->db->group_by ( 'z.idzone' );
		
		$query = $this->db->get ();
		// echo $this->db->last_query();
		// die;
		if ($query->num_rows () > 0) {
			$k = 0;
			
			foreach ( $query->result_array () as $key => $val ) {
				// print'<pre>';
				// print_r($val);
				
				$this->db->select ( 's.idsite, s.site' );
				$this->db->from ( 'larvalsurveillance AS ls' );
				$this->db->join ( 'sites AS s', "ls.idsite = s.idsite", 'INNER' );
				$this->db->join ( 'zones AS z', "s.idzone = z.idzone", 'INNER' );
				$this->db->where ( "s.idlocation", $this->session->userdata ( 'idlocation' ) );
				$this->db->where ( 'ls.date >=', $startdate );
				$this->db->where ( 'ls.date <=', $enddate );
				$this->db->where ( 'z.idzone', $val ['idzone'] );
				//$this->db->where ( 'ls.isdeleted', '0' );
				if (! empty ( $site ))
					$this->db->where ( 's.idsite', $site );
				
				$this->db->group_by ( 's.idsite' );
				
				$query1 = $this->db->get ();
				// echo $this->db->last_query();
				$sitedata = array ();
				$j = 0;
				if ($query1->num_rows () > 0) {
					foreach ( $query1->result_array () as $k_1 => $v_1 ) {
						// print'<pre>';
						// print_r($v_1);
						$this->db->select ( 'l.idlarvalsurveillance,
								u.firstname,
								u.middlename,
								u.lastname,
								l.*,
								w.watertemprange,
								lc.larvaecountrange' );
						$this->db->from ( 'larvalsurveillance AS l' );
						$this->db->join ( 'users AS u', 'l.idinspector = u.iduser', 'LEFT' );
						$this->db->join ( 'watertempranges AS w', 'l.idwatertemprange = w.idwatertemprange', 'LEFT' );
						$this->db->join ( 'larvaecountrange AS lc', 'l.idlarvaecountrange = lc.idlarvaecountrange', 'LEFT' );
						$this->db->where ( 'l.idsite', $v_1 ['idsite'] );
						$this->db->where ( 'l.date >=', $startdate );
						$this->db->where ( 'l.date <=', $enddate );
						//$this->db->where ( 'ls.isdeleted', '0' );
						if (! empty ( $techs ))
							$this->db->where ( 'u.iduser', $techs );
						
						$query2 = $this->db->get ();
						
						// echo $this->db->last_query();
						$larval = array ();
						
						$i = 0;
						
						if ($query2->num_rows () > 0) {
							foreach ( $query2->result_array () as $k_2 => $v_2 ) {
								$this->db->select ( 'lsdt.idmosquitospecies,
										lsdt.count,
										m.mosquitospecies,
										g.genus' );
								$this->db->from ( 'larvalsurveillancedetails AS lsdt' );
								$this->db->join ( 'mosquitospecies AS m', 'lsdt.idmosquitospecies = m.idmosquitospecies', 'LEFT' );
								$this->db->join ( 'genuses AS g', 'm.idgenus = g.idgenus', 'LEFT' );
								$this->db->where ( 'lsdt.idlarvalsurveillance', $v_2 ['idlarvalsurveillance'] );
								
								if (! empty ( $_species ))
									$this->db->where ( 'lsdt.idmosquitospecies', $_species );
								
								$query3 = $this->db->get ();
								$species = array ();
								if ($query3->num_rows () > 0) {
									$species = $query3->result_array ();
								}
								
								// echo $this->db->last_query()."<br>";
								
								$this->db->select ( 'SUM(lsdt.count) AS count' );
								$this->db->from ( 'larvalsurveillancedetails AS lsdt' );
								$this->db->where ( 'lsdt.idlarvalsurveillance', $v_2 ['idlarvalsurveillance'] );
								
								$query4 = $this->db->get ();
								$count = 0;
								if ($query4->num_rows () > 0) {
									$count = $query4->result_array ();
									$count = ! empty ( $count [0] ['count'] ) ? $count [0] ['count'] : 0;
								}
								
								$larval [$i] = $v_2;
								
								if (! empty ( $count ))
									$larval [$i] ['count'] = $count;
								
								if (! empty ( $species ))
									$larval [$i] ['species'] = $species;
								
								$i ++;
							}
						}
						$sitedata [$j] = $v_1;
						if (! empty ( $larval ))
							$sitedata [$j] ['larval'] = $larval;
						
						$j ++;
					}
				}
				$this->data [$k] = $val;
				
				if (! empty ( $sitedata ))
					$this->data [$k] ['sitedata'] = $sitedata;
					
					 //print'<pre>';
					//
					 //print_r($val);
					
				 //print_r($query1 -> result_array());
				$k ++;
			}
		}
		
		// print'<pre>';
		// print_r($this->data);
		// die;
		
		return $this->data;
	}
	
	/**
	 * Function to fetch All Products
	 */
	public function getProducts() {
		$result = array ();
		$k = 0;
		$this->data = $this->getLarvalSurveillance ();
		if (! empty ( $this->data )) {
			foreach ( $this->data as $key => $val ) {
				$this->db->select ( 'p.*,
						pm.manufacturer' );
				$this->db->from ( 'products AS p' );
				$this->db->join ( 'productmanufacturers AS pm', 'p.idmanufacturer = pm.idmanufacturer', 'LEFT' );
				$this->db->join ( 'locations AS l', "p.idlocation = l.idlocation", 'INNER' );
				$this->db->where ( "p.idlocation", $this->session->userdata ( 'idlocation' ) );
				$this->db->where ( 'idproduct', $val ['idproduct'] );
				$query = $this->db->get ();
				
				if ($query->num_rows () > 0) {
					$temp = $query->result_array ();
					$result [$k] = $temp [0];
					$result [$k] ['qty'] = $val ['totalproductapplied'];
					$result [$k] ['uom'] = $val ['uoms'];
					$result [$k] ['units'] = $val ['units'];
					$result [$k] ['area'] = $val ['totalareatreated'];
					
					$k ++;
				}
			}
		}
		// print'<pre>';
		// print_r($result);
		// die;
		return $result;
	}
}
