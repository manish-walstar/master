<?php
	
	$config = array(
                 'addmember' => array(
                                    array(
                                            'field' => 'username',
                                            'label' => 'Username',
                                            'rules' => 'trim|required|alpha_dash'
                                         ),
                                    /*array(
                                            'field' => 'password',
                                            'label' => 'Password',
                                            'rules' => 'trim|required|matches[passconf]'
                                         ),
                                    array(
                                            'field' => 'passconf',
                                            'label' => 'PasswordConfirmation',
                                            'rules' => 'trim|required'
                                         ),*/
                                    array(
                                            'field' => 'email',
                                            'label' => 'Email',
                                            'rules' => 'trim|required|valid_email'
                                         ),
                                    array(
                                            'field' => 'idsalutation',
                                            'label' => 'Salutation',
                                            'rules' => 'trim'
                                         ),
                                    array(
                                            'field' => 'firstname',
                                            'label' => 'First Name',
                                            'rules' => 'trim|required|alpha'
                                         ),
                                    array(
                                            'field' => 'middlename',
                                            'label' => 'Middle Name',
                                            'rules' => 'trim|alpha'
                                         ),
                                    array(
                                            'field' => 'lastname',
                                            'label' => 'Last Name',
                                            'rules' => 'trim|required|alpha'
                                         ),
                                    array(
                                            'field' => 'idsuffix',
                                            'label' => 'Suffix',
                                            'rules' => 'trim'
                                         ),
                                    array(
                                            'field' => 'officephone',
                                            'label' => 'Office Phone',
                                            'rules' => 'trim|integer'
                                         ),
                                    array(
                                            'field' => 'mobilephone',
                                            'label' => 'Mobile Phone',
                                            'rules' => 'trim|integer'
                                         ),
                                    array(
                                            'field' => 'faxnumber',
                                            'label' => 'Fax Number',
                                            'rules' => 'trim|integer'
                                         )
                                    )/*,
                 'editmember' => array(
                                    array(
                                            'field' => 'username',
                                            'label' => 'Username',
                                            'rules' => 'trim|required'
                                         ),
                                    array(
                                            'field' => 'crrnt_password',
                                            'label' => 'Current Password',
                                            'rules' => 'trim'
                                     ), 
                                    array(
                                            'field' => 'password',
                                            'label' => 'Password',
                                            'rules' => 'trim|matches[passconf]'
                                         ),
                                    array(
                                            'field' => 'passconf',
                                            'label' => 'PasswordConfirmation',
                                            'rules' => 'trim'
                                         ),
                                    array(
                                            'field' => 'email',
                                            'label' => 'Email',
                                            'rules' => 'trim|required|valid_email'
                                         ),
                                    array(
                                            'field' => 'idsalutation',
                                            'label' => 'Salutation',
                                            'rules' => 'trim'
                                         ),
                                    array(
                                            'field' => 'firstname',
                                            'label' => 'First Name',
                                            'rules' => 'trim|required|alpha'
                                         ),
                                    array(
                                            'field' => 'middlename',
                                            'label' => 'Middle Name',
                                            'rules' => 'trim|alpha'
                                         ),
                                    array(
                                            'field' => 'lastname',
                                            'label' => 'Last Name',
                                            'rules' => 'trim|required|alpha'
                                         ),
                                    array(
                                            'field' => 'idsuffix',
                                            'label' => 'Suffix',
                                            'rules' => 'trim'
                                         ),
                                    array(
                                            'field' => 'officephone',
                                            'label' => 'Office Phone',
                                            'rules' => 'trim|integer'
                                         ),
                                    array(
                                            'field' => 'mobilephone',
                                            'label' => 'Mobile Phone',
                                            'rules' => 'trim|integer'
                                         ),
                                    array(
                                            'field' => 'faxnumber',
                                            'label' => 'Fax Number',
                                            'rules' => 'trim|integer'
                                         ),
                                    array(
                                            'field' => 'hideboundary',
                                            'label' => 'Hide Boundary',
                                            'rules' => 'trim'
                                         )
                                    ),                                    
                 'login' => array(
                                    array(
                                            'field' => 'username',
                                            'label' => 'Username',
                                            'rules' => 'trim|required'
                                         ),
                                    array(
                                            'field' => 'password',
                                            'label' => 'Password',
                                            'rules' => 'trim|required'
                                         )
                                    )    */                      
               );

?>