<?php

if (! defined('BASEPATH'))
    exit('No direct script access allowed');
session_start();

class Carbogrid
{

    /**
     *
     * @todo After add/edit go to page and higlight
     *      
     *       Multipage select
     */
    
    // -----------------------
    // Public options
    public $id = 'carbogrid';

    public $url = '';

    public $params_before = '';

    public $params_after = '';

    public $uri_param = 'none';

    // public $uri_segment = 3;
    public $nested = FALSE;

    public $ajax = TRUE;

    public $ajax_history = TRUE;

    public $allow_add = TRUE;

    public $allow_edit = TRUE;

    public $allow_delete = TRUE;

    public $allow_filter = TRUE;

    public $allow_columns = TRUE;

    public $allow_select = TRUE;

    public $allow_pagination = TRUE;

    public $allow_page_size = TRUE;

    public $allow_sort = TRUE;

    public $allow_multisort = FALSE;

    public $page_size = 10;

    public $page = 1;

    public $pagination_links = 5;

    public $limits = array(
        5 => 5,
        10 => 10,
        20 => 20,
        50 => 50,
        100 => 100
    );

    public $show_empty_rows = FALSE;

    public $max_cell_length = 1000;

    public $filters = array();

    public $hard_filters = array();

    public $order = array();

    public $filter_date;

    public $filter_site;

    public $filter_sitetype;

    public $filter_siteofinterest;

    public $select_site_id;

    public $select_site;

    public $filter_city;

    public $select_city_id;

    public $select_city;

    public $filter_status_string;

    public $filter_lab_string;

    public $filter_daterange;

    public $filter_trap;

    public $filter_service;

    public $filter_adultkey;

    public $filter_sentinel;

    public $filter_futureassign;

    public $filter_pendingassign;

    public $filter_by_type;

    public $filter_site_string;

    public $filter_pendingassign_string;

    public $filter_wanum;

    public $columns = array();

    public $columns_visible = array();

    public $selected_ids = array();

    public $selected_tab;

    public $commands = array();

    public $table = NULL;

    public $multiple = NULL;

    public $table_id_name = '';

    public $table_id_1_name = '';

    public $table_id_2_name = '';

    // Custom function to populate the grid
    public $get_data = '';

    // -----------------------
    // Private options
    public $is_ajax = FALSE;

    public $show_col_list = FALSE;

    public $response = NULL;

    public $filter_nr = 0;
 // Number of filters, if none, we render no filter row
    public $headers = array();

    public $total = 0;

    public $limit = 10;

    public $offset = 0;

    public $sep_total = 0;

    public $data = array();

    // Pagination
    public $page_max = 0;

    public $page_curr = 1;

    public $page_start = 1;

    public $page_nr = 0;

    public $first_link;

    public $prev_link;

    public $next_link;

    public $last_link;

    public $page_links = array();

    public $item_start = 0;

    public $item_end = 0;

    // String params
    public $order_string = 'desc';

    public $filter_string = 'all';

    public $column_string = 'all';

    // Current command
    public $command = NULL;

    public $command_arg = NULL;

    // Confirm dialog
    public $confirm = FALSE;

    public $confirm_command = NULL;

    public $confirm_arg = NULL;

    public $confirm_title = '';

    public $confirm_text = '';

    public $table1 = NULL;

    public $table2 = NULL;

    public $table1_rel = NULL;

    public $table2_rel = NULL;

    public $service_req_id = NULL;

    // Render table
    public $render_table = TRUE;

    public $iscollieradmin = array();

    // Default column settings
    private $column_defaults = array(
        'name' => '',
        'type' => '',
        'header' => '',
        'display' => '',
        'visible' => TRUE,
        'strconcat' => '',
        // 'filter' => NULL,
        'allow_filter' => TRUE,
        'allow_sort' => TRUE,
        // Date type settings
        'date_format' => 'm/d/Y',
        'time_format' => 'h:i A',
        // URL type settings
        'url_target' => '_self',
        // File upload settings
        'upload_path' => './files',
        'upload_path_temp' => './files/temp',
        'allowed_types' => 'gif|jpg|png',
        'max_size' => '1024',
        // Foreign key settings
        'ref_table_id_name' => '',
        'ref_table_db_name' => '',
        'ref_field_db_name' => '',
        'ref_field_type' => '',
        // Form settings
        'group' => '',
        'form_visible' => TRUE,
        'form_default' => '',
        'form_control' => 'text_long',
        // Validation settings
        'validation' => '',
        'min_length' => NULL,
        'max_length' => NULL,
        'required' => FALSE,
        'unique' => FALSE
    );

    // Default command settings
    private $command_defaults = array(
        'name' => '',
        'text' => '',
        'url' => '',
        'function' => '',
        'icon' => '',
        'type' => 'dialog', // dialog, post, link...
        'toolbar' => FALSE,
        'multi' => FALSE,
        'grid' => TRUE,
        'ajax' => TRUE,
        'confirm' => FALSE,
        'confirm_title' => '',
        'confirm_text' => '',
        'confirm_yes' => '',
        'confirm_no' => '',
        'dialog_save' => '',
        'dialog_cancel' => '',
        'filters' => array()
    );

    // Default dialog settings
    public $dialog = array(
        'title' => '&nbsp;',
        'class' => 'cg-dialog-confirm',
        'content' => '',
        'yes' => '',
        'no' => '',
        'visible' => FALSE
    );

    public $invalidParams = array(
        "daterange",
        "lab",
        "trap",
        "city",
        "service",
        "adult",
        "sentinel",
        "futureassign",
        "pendingassign",
        "sitetype",
        "sitegroup",
        "siteofinterest",
        "type"
    );

    /**
     * Constructor
     */
    function __construct($params = array())
    {
        $this->CI = & get_instance();
        
        $this->CI->load->language('carbo');
        
        $this->CI->load->helper('carbo');
        
        $this->CI->load->model('Carbo_model');
        
        $this->filter_operators = array(
            '' => lang('cg_filter_all'),
            'like' => lang('cg_filter_like'),
            'notlike' => lang('cg_filter_not_like'),
            'starts' => lang('cg_filter_starts'),
            'ends' => lang('cg_filter_ends'),
            'eq' => '=',
            'noteq' => '!=',
            'lt' => '<',
            'lte' => '<=',
            'gt' => '>',
            'gte' => '>='
            // 'in' => lang('cg_filter_in'),
            // 'not_in' => lang('cg_filter_not_in'),
        );
        $this->date_filter_operators = array(
            '' => lang('cg_filter_all'),
            'eq' => '=',
            'noteq' => '!=',
            'lt' => '<',
            'lte' => '<=',
            'gt' => '>',
            'gte' => '>='
        );
        
        $this->month_names = array(
            lang('cg_january'),
            lang('cg_february'),
            lang('cg_march'),
            lang('cg_april'),
            lang('cg_may'),
            lang('cg_june'),
            lang('cg_july'),
            lang('cg_august'),
            lang('cg_september'),
            lang('cg_october'),
            lang('cg_november'),
            lang('cg_december')
        );
        
        $this->month_names_short = array(
            lang('cg_january_short'),
            lang('cg_february_short'),
            lang('cg_march_short'),
            lang('cg_april_short'),
            lang('cg_may_short'),
            lang('cg_june_short'),
            lang('cg_july_short'),
            lang('cg_august_short'),
            lang('cg_september_short'),
            lang('cg_october_short'),
            lang('cg_november_short'),
            lang('cg_december_short')
        );
        
        $this->day_names = array(
            lang('cg_sunday'),
            lang('cg_monday'),
            lang('cg_tuesday'),
            lang('cg_wednesday'),
            lang('cg_thursday'),
            lang('cg_friday'),
            lang('cg_saturday')
        );
        
        $this->day_names_short = array(
            lang('cg_sunday_short'),
            lang('cg_monday_short'),
            lang('cg_tuesday_short'),
            lang('cg_wednesday_short'),
            lang('cg_thursday_short'),
            lang('cg_friday_short'),
            lang('cg_saturday_short')
        );
        
        $this->day_names_min = array(
            lang('cg_sunday_min'),
            lang('cg_monday_min'),
            lang('cg_tuesday_min'),
            lang('cg_wednesday_min'),
            lang('cg_thursday_min'),
            lang('cg_friday_min'),
            lang('cg_saturday_min')
        );
        
        // Get selected ids
        if (is_array($item_ids = $this->CI->input->post('cg_' . $this->id . '_item_ids'))) {
            $this->selected_ids = $item_ids;
        }
        
        // print'<pre>';
        // print_r($params);
        // print'</pre>';die;
        foreach ($params as $key => $value) {
            $this->$key = $value;
            // echo $this->$key ." ". $value."<br>";
            if ($key == "id")
                $this->table_id_name = $value;
            
            if ($key == "id1")
                $this->table_id_1_name = $value;
            
            if ($key == "id2")
                $this->table_id_2_name = $value;
            
            if ($key == "filter_date") {
                $this->filter_date = $value;
            }
            
            if ($key == "para") {
                $this->filter_sentinel = $value;
            }
        }
        
        // Do we have an ajax call?
        $this->is_ajax = ($this->CI->input->post('cg_ajax_' . $this->id) === '1');
        // Initialize the id
        
        // print'<pre>';
        // print_r($this->filters);
        // print_r($this->order);
        // print'</pre>';
        // Set initial filters
        if ($this->allow_filter) {
            $this->filter_string = '';
            foreach ($this->filters as $key => $filter) {
                $op = isset($filter['operator']) ? $filter['operator'] : 'eq';
                $this->filter_string .= $key . ':' . $this->encode($filter['value']) . ':' . $op . '_';
            }
            $this->filter_string = $this->filter_string ? rtrim($this->filter_string, '_') : 'all';
        }
        
        // Set initial order
        if ($this->allow_sort) {
            $this->order_string = '';
            foreach ($this->order as $key => $dir) {
                $dir = (strtolower($dir) == 'desc') ? 'desc' : 'asc';
                $this->order_string .= $key . ':' . $dir . '_';
            }
            $this->order_string = $this->order_string ? rtrim($this->order_string, '_') : 'desc';
        }
        
        // Set initial column visibility
        if ($this->allow_columns) {
            if (count($this->columns_visible)) {
                $this->column_string = implode(':', $this->columns_visible);
            }
        }
        
        //
        $this->selected_tab = isset($_COOKIE['activeTab']) ? $_COOKIE['activeTab'] : 'data-li';
        
        // Parse uri parameter
        // $uri_param = $this->CI->uri->segment($this->uri_segment);
        $uri_param = $this->uri_param;
        if ($uri_param) {
            $uri_param = explode('-', $uri_param);
            // print'<pre>';
            // print_R($uri_param);
            // print'</pre>';
            if (isset($uri_param[0]))
                $this->page_size = $this->allow_page_size ? $uri_param[0] : $this->page_size;
            if (isset($uri_param[1]))
                $this->page = $uri_param[1];
            if (isset($uri_param[2]))
                $this->column_string = $uri_param[2];
            if (isset($uri_param[3]))
                $this->order_string = $uri_param[3];
            if (isset($uri_param[4]))
                $this->filter_string = $uri_param[4];
            if (isset($uri_param[5]))
                $this->filter_date_string = $uri_param[5];
            
            if (isset($uri_param[6]) && ! in_array($uri_param[6], $this->invalidParams))
                $this->filter_site_string = $uri_param[6];
            if (isset($uri_param[6]) && $uri_param[6] == "daterange") {
                $fromDate = substr($uri_param[7], 0, 2) . '/' . substr($uri_param[7], 2, 2) . '/' . substr($uri_param[7], 4, 4);
                $toDate = substr($uri_param[8], 0, 2) . '/' . substr($uri_param[8], 2, 2) . '/' . substr($uri_param[8], 4, 4);
                $this->filter_daterange = array(
                    $fromDate,
                    $toDate
                );
            } else if (isset($uri_param[8]) && $uri_param[8] == "daterange") {
                $fromDate = substr($uri_param[9], 0, 2) . '/' . substr($uri_param[9], 2, 2) . '/' . substr($uri_param[9], 4, 4);
                $toDate = substr($uri_param[10], 0, 2) . '/' . substr($uri_param[10], 2, 2) . '/' . substr($uri_param[10], 4, 4);
                $this->filter_daterange = array(
                    $fromDate,
                    $toDate
                );
            }
            
            if (isset($uri_param[6]) && $uri_param[6] == "lab")
                $this->filter_lab_string = $uri_param[7];
            else if (isset($uri_param[9]) && $uri_param[9] == "lab")
                $this->filter_lab_string = $uri_param[10];
            
            if (isset($uri_param[6]) && $uri_param[6] == "status")
                $this->filter_status_string = urldecode($uri_param[7]);
            else if (isset($uri_param[8]) && $uri_param[8] == "status")
                $this->filter_status_string = urldecode($uri_param[9]);
            else if (isset($uri_param[9]) && $uri_param[9] == "status")
                $this->filter_status_string = urldecode($uri_param[10]);
            else if (isset($uri_param[10]) && $uri_param[10] == "status")
                $this->filter_status_string = urldecode($uri_param[11]);
            else if (isset($uri_param[11]) && $uri_param[11] == "status")
                $this->filter_status_string = urldecode($uri_param[12]);
            
            if (isset($uri_param[6]) && $uri_param[6] == "city")
                $this->filter_city = urldecode($uri_param[7]);
            else if (isset($uri_param[9]) && $uri_param[9] == "city")
                $this->filter_city = urldecode($uri_param[10]);
            else if (isset($uri_param[10]) && $uri_param[10] == "city")
                $this->filter_city = urldecode($uri_param[11]);
            
            if (isset($uri_param[6]) && $uri_param[6] == "trap")
                $this->filter_trap = urldecode($uri_param[7]);
            else if (isset($uri_param[9]) && $uri_param[9] == "trap")
                $this->filter_trap = urldecode($uri_param[10]);
            else if (isset($uri_param[10]) && $uri_param[10] == "trap")
                $this->filter_trap = urldecode($uri_param[11]);
            
            if (isset($uri_param[6]) && $uri_param[6] == "service")
                $this->filter_service = $uri_param[7];
            else if (isset($uri_param[9]) && $uri_param[9] == "service")
                $this->filter_service = $uri_param[10];
            else if (isset($uri_param[10]) && $uri_param[10] == "service")
                $this->filter_service = $uri_param[11];
            
            if (isset($uri_param[6]) && $uri_param[6] == "adult")
                $this->filter_adultkey = $uri_param[7];
            else if (isset($uri_param[9]) && $uri_param[9] == "adult")
                $this->filter_adultkey = $uri_param[10];
            else if (isset($uri_param[10]) && $uri_param[10] == "adult")
                $this->filter_adultkey = $uri_param[11];
            
            if (isset($uri_param[6]) && $uri_param[6] == "sentinel")
                $this->filter_sentinel = $uri_param[7];
            else if (isset($uri_param[9]) && $uri_param[9] == "sentinel")
                $this->filter_sentinel = $uri_param[10];
            else if (isset($uri_param[10]) && $uri_param[10] == "sentinel")
                $this->filter_sentinel = $uri_param[11];
            
            if (isset($uri_param[6]) && $uri_param[6] == "futureassign")
                $this->filter_futureassign = $uri_param[7];
            else if (isset($uri_param[8]) && $uri_param[8] == "futureassign")
                $this->filter_futureassign = $uri_param[9];
            else if (isset($uri_param[9]) && $uri_param[9] == "futureassign")
                $this->filter_futureassign = $uri_param[10];
            else if (isset($uri_param[10]) && $uri_param[10] == "futureassign")
                $this->filter_futureassign = $uri_param[11];
            
            if (isset($uri_param[6]) && $uri_param[6] == "pendingassign")
                $this->filter_pendingassign = $uri_param[7];
            else if (isset($uri_param[8]) && $uri_param[8] == "pendingassign")
                $this->filter_pendingassign = $uri_param[9];
            else if (isset($uri_param[9]) && $uri_param[9] == "pendingassign")
                $this->filter_pendingassign = $uri_param[10];
            else if (isset($uri_param[10]) && $uri_param[10] == "pendingassign")
                $this->filter_pendingassign = $uri_param[11];
            
            if (isset($uri_param[6]) && $uri_param[6] == "sitetype")
                $this->filter_sitetype = $uri_param[7];
            else if (isset($uri_param[9]) && $uri_param[9] == "sitetype")
                $this->filter_sitetype = $uri_param[10];
            else if (isset($uri_param[10]) && $uri_param[10] == "sitetype")
                $this->filter_sitetype = $uri_param[11];
            
            if (isset($uri_param[6]) && $uri_param[6] == "siteofinterest")
                $this->filter_siteofinterest = $uri_param[7];
            else if (isset($uri_param[7]) && $uri_param[7] == "siteofinterest")
                $this->filter_siteofinterest = $uri_param[8];
            else if (isset($uri_param[9]) && $uri_param[9] == "siteofinterest")
                $this->filter_siteofinterest = $uri_param[10];
            else if (isset($uri_param[10]) && $uri_param[10] == "siteofinterest")
                $this->filter_siteofinterest = $uri_param[11];
            
            if (isset($uri_param[6]) && $uri_param[6] == "type")
                $this->filter_by_type = urldecode($uri_param[7]);
            else if (isset($uri_param[7]) && $uri_param[7] == "type")
                $this->filter_by_type = urldecode($uri_param[8]);
            else if (isset($uri_param[8]) && $uri_param[8] == "type")
                $this->filter_by_type = urldecode($uri_param[9]);
            else if (isset($uri_param[9]) && $uri_param[9] == "type")
                $this->filter_by_type = urldecode($uri_param[10]);
            else if (isset($uri_param[10]) && $uri_param[10] == "type")
                $this->filter_by_type = urldecode($uri_param[11]);
            else if (isset($uri_param[11]) && $uri_param[11] == "type")
                $this->filter_by_type = urldecode($uri_param[12]);
            
            if (isset($uri_param[6]) && $uri_param[6] == "wanum")
                $this->filter_wanum = $uri_param[7];
            else if (isset($uri_param[7]) && $uri_param[7] == "wanum")
                $this->filter_wanum = $uri_param[8];
            else if (isset($uri_param[9]) && $uri_param[9] == "wanum")
                $this->filter_wanum = $uri_param[10];
            else if (isset($uri_param[10]) && $uri_param[10] == "wanum")
                $this->filter_wanum = $uri_param[11];
        }
        
        /*
         * foreach ($this->CI->uri->segment_array() as $key => $segment)
         * {
         * if ($key < $this->uri_segment)
         * {
         * $this->params_before .= $segment . '/';
         * }
         * elseif ($key > $this->uri_segment)
         * {
         * $this->params_after .= '/' . $segment;
         * }
         * }
         * $this->url = '';
         */
        $this->params_before = $this->params_before ? (rtrim($this->params_before, '/') . '/') : '';
        $this->params_after = $this->params_after ? ('/' . ltrim($this->params_after, '/')) : '';
        
        // Ensure trailing slash to the url end
        $this->url = rtrim($this->url, '/') . '/';
        
        // Dialog settings
        $this->dialog = (object) $this->dialog;
        
        // Setup headers, all columns are visible by default
        $this->filter_nr = 0;
        $this->columns_visible = array();
        
        if (! isset($this->multiple) && empty($this->multiple)) {
            foreach ($this->columns as $key => $column) {
                $this->columns[$key] = array_merge($this->column_defaults, (array) $column);
                // Set unique name
                if ($this->columns[$key]['type'] == '1-n') {
                    $this->columns[$key]['unique_name'] = $this->columns[$key]['ref_table_db_name'] . '_' . $this->columns[$key]['ref_field_db_name'];
                    $this->columns[$key]['where_name'] = $this->columns[$key]['ref_table_db_name'] . '.' . $this->columns[$key]['ref_field_db_name'];
                } else if ($this->columns[$key]['type'] == '1-1-1') {
                    $this->columns[$key]['unique_name'] = $this->columns[$key]['ref_table_db_name'] . '_' . $this->columns[$key]['ref_field_db_name'];
                    $this->columns[$key]['where_name'] = $this->columns[$key]['ref_table_db_name'] . '.' . $this->columns[$key]['ref_field_db_name'];
                    
                    $this->columns[$key]['reference_uniq_name'] = $this->columns[$key]['ref_table_db2_name'] . '_' . $this->columns[$key]['ref_field_db2_name'];
                    $this->columns[$key]['reference_where_name'] = $this->columns[$key]['ref_table_db2_name'] . '.' . $this->columns[$key]['ref_field_db2_name'];
                } else if ($this->columns[$key]['type'] == '1+2') {
                    $this->columns[$key]['unique_name'] = substr($this->table, 0, 2) . $this->columns[$key]['db_name_1'];
                    $this->columns[$key]['where_name'] = $this->table . '.' . $this->columns[$key]['db_name_1'];
                    
                    $this->columns[$key]['reference_uniq_name'] = substr($this->table, 0, 2) . $this->columns[$key]['db_name_2'];
                    $this->columns[$key]['reference_where_name'] = $this->table . '.' . $this->columns[$key]['db_name_2'];
                } else if ($this->columns[$key]['type'] == '1+2+3+4+5') {
                    $this->columns[$key]['unique_name'] = $this->columns[$key]['db_name_1'];
                    $this->columns[$key]['where_name'] = $this->table . '.' . $this->columns[$key]['db_name_1'];
                    
                    $this->columns[$key]['reference_uniq_name'] = $this->columns[$key]['db_name_2'];
                    $this->columns[$key]['reference_where_name'] = $this->table . '.' . $this->columns[$key]['db_name_2'];
                    
                    $this->columns[$key]['reference_uniq_name_1'] = $this->columns[$key]['db_name_3'];
                    $this->columns[$key]['reference_where_name_1'] = $this->table . '.' . $this->columns[$key]['db_name_3'];
                    
                    $this->columns[$key]['reference_uniq_name_2'] = $this->columns[$key]['db_name_4'];
                    $this->columns[$key]['reference_where_name_2'] = $this->table . '.' . $this->columns[$key]['db_name_4'];
                    
                    $this->columns[$key]['reference_uniq_name_3'] = $this->columns[$key]['db_name_5'];
                    $this->columns[$key]['reference_where_name_3'] = $this->table . '.' . $this->columns[$key]['db_name_5'];
                } else if ($this->columns[$key]['type'] == '1-t') {
                    $this->columns[$key]['unique_name'] = $this->columns[$key]['db_name'];
                    $this->columns[$key]['where_name'] = $this->table . '.' . $this->columns[$key]['db_name'];
                    
                    $this->columns[$key]['reference_uniq_name'] = $this->columns[$key]['ref_field_db_name'];
                    $this->columns[$key]['reference_where_name'] = $this->table . '.' . $this->columns[$key]['ref_field_db_name'];
                } else if ($this->columns[$key]['type'] == '1-1+2') {
                    $this->columns[$key]['unique_name'] = $this->columns[$key]['ref_field_db_name'];
                    $this->columns[$key]['where_name'] = $this->table . '.' . $this->columns[$key]['ref_field_db_name'];
                    
                    $this->columns[$key]['reference_uniq_name'] = $this->columns[$key]['ref_field_2_db_name'];
                    $this->columns[$key]['reference_where_name'] = $this->table . '.' . $this->columns[$key]['ref_field_2_db_name'];
                } else if ($this->columns[$key]['type'] == '1-(1)-2') {
                    $this->columns[$key]['unique_name'] = $this->columns[$key]['db_name'];
                    $this->columns[$key]['where_name'] = $this->table . '.' . $this->columns[$key]['db_name'];
                    
                    $this->columns[$key]['reference_uniq_name'] = $this->columns[$key]['ref_field_db_name'];
                    $this->columns[$key]['reference_where_name'] = $this->columns[$key]['ref_table_db_name'] . '.' . $this->columns[$key]['ref_field_db_name'];
                } else if ($this->columns[$key]['type'] == '1-(1+2)-1-1') {
                    $this->columns[$key]['unique_name'] = $this->columns[$key]['ref_field_db_name'];
                    $this->columns[$key]['where_name'] = $this->table . '.' . $this->columns[$key]['ref_field_db_name'];
                    
                    $this->columns[$key]['reference_uniq_name'] = $this->columns[$key]['ref_field_1_db_name'];
                    $this->columns[$key]['reference_where_name'] = $this->table . '.' . $this->columns[$key]['ref_field_1_db_name'];
                    
                    $this->columns[$key]['reference_uniq_name_1'] = $this->columns[$key]['ref_field_1_1_db_name'];
                    $this->columns[$key]['reference_where_name_1'] = $this->table . '.' . $this->columns[$key]['ref_field_1_1_db_name'];
                } else if ($this->columns[$key]['type'] == '1-(1+2+3)-1-1') {
                    $this->columns[$key]['unique_name'] = $this->columns[$key]['ref_field_db_name'];
                    $this->columns[$key]['where_name'] = $this->table . '.' . $this->columns[$key]['ref_field_db_name'];
                    
                    $this->columns[$key]['reference_uniq_name'] = $this->columns[$key]['ref_field_1_db_name'];
                    $this->columns[$key]['reference_where_name'] = $this->table . '.' . $this->columns[$key]['ref_field_1_db_name'];
                    
                    $this->columns[$key]['reference_uniq_name_1'] = $this->columns[$key]['ref_field_2_db_name'];
                    $this->columns[$key]['reference_where_name_1'] = $this->table . '.' . $this->columns[$key]['ref_field_2_db_name'];
                    
                    $this->columns[$key]['reference_uniq_name_2'] = $this->columns[$key]['ref_field_1_1_db_name'];
                    $this->columns[$key]['reference_where_name_2'] = $this->table . '.' . $this->columns[$key]['ref_field_1_1_db_name'];
                } else if ($this->columns[$key]['type'] == '1-1-(1)-(2)') {
                    $this->columns[$key]['unique_name'] = $this->columns[$key]['ref_field_db_name'];
                    $this->columns[$key]['where_name'] = $this->table . '.' . $this->columns[$key]['ref_field_db_name'];
                    
                    $this->columns[$key]['reference_uniq_name'] = $this->columns[$key]['ref_field_1_db_name'];
                    $this->columns[$key]['reference_where_name'] = $this->table . '.' . $this->columns[$key]['ref_field_1_db_name'];
                } else if ($this->columns[$key]['type'] == '1-1-2') {
                    $this->columns[$key]['unique_name'] = $this->columns[$key]['ref_table_db2_name'] . '_' . $this->columns[$key]['ref_field_db2_name'];
                    $this->columns[$key]['where_name'] = $this->columns[$key]['ref_table_db2_name'] . '.' . $this->columns[$key]['ref_field_db2_name'];
                } else {
                    $this->columns[$key]['unique_name'] = /*$this->table . '_' . */$this->columns[$key]['db_name'];
                    $this->columns[$key]['where_name'] = $this->table . '.' . $this->columns[$key]['db_name'];
                }
                
                // Convert columns to objects
                $this->columns[$key] = (object) $this->columns[$key];
                
                // Count filters
                if ($this->columns[$key]->allow_filter !== FALSE) {
                    $this->filter_nr ++;
                }
                $this->headers[$key] = $this->columns[$key]->header;
                // $this->columns_visible[$key] = TRUE;
                $this->columns_visible[] = $key;
            }
        } else {
            foreach ($this->columns as $key => $column) {
                $this->columns[$key] = array_merge($this->column_defaults, (array) $column);
                // Set unique name
                if ($this->columns[$key]['type'] == '1-n') {
                    $this->columns[$key]['unique_name'] = $this->columns[$key]['ref_table_db_name'] . '_' . $this->columns[$key]['ref_field_db_name'];
                    $this->columns[$key]['where_name'] = $this->columns[$key]['ref_table_db_name'] . '.' . $this->columns[$key]['ref_field_db_name'];
                } else if ($this->columns[$key]['type'] == '1-1-1') {
                    $this->columns[$key]['unique_name'] = $this->columns[$key]['ref_table_db_name'] . '_' . $this->columns[$key]['ref_field_db_name'];
                    $this->columns[$key]['where_name'] = $this->columns[$key]['ref_table_db_name'] . '.' . $this->columns[$key]['ref_field_db_name'];
                    
                    $this->columns[$key]['reference_uniq_name'] = $this->columns[$key]['ref_table_db2_name'] . '_' . $this->columns[$key]['ref_field_db2_name'];
                    $this->columns[$key]['reference_where_name'] = $this->columns[$key]['ref_table_db2_name'] . '.' . $this->columns[$key]['ref_field_db2_name'];
                } else if ($this->columns[$key]['type'] == '1+2') {
                    $this->columns[$key]['unique_name'] = $this->columns[$key]['db_name_1'];
                    $this->columns[$key]['where_name'] = $this->table . '.' . $this->columns[$key]['db_name_1'];
                    
                    $this->columns[$key]['reference_uniq_name'] = $this->columns[$key]['db_name_2'];
                    $this->columns[$key]['reference_where_name'] = $this->table . '.' . $this->columns[$key]['db_name_2'];
                } else if ($this->columns[$key]['type'] == '1+2+3+4+5') {
                    $this->columns[$key]['unique_name'] = $this->columns[$key]['db_name_1'];
                    $this->columns[$key]['where_name'] = $this->table . '.' . $this->columns[$key]['db_name_1'];
                    
                    $this->columns[$key]['reference_uniq_name'] = $this->columns[$key]['db_name_2'];
                    $this->columns[$key]['reference_where_name'] = $this->table . '.' . $this->columns[$key]['db_name_2'];
                    
                    $this->columns[$key]['reference_uniq_name_1'] = $this->columns[$key]['db_name_3'];
                    $this->columns[$key]['reference_where_name_1'] = $this->table . '.' . $this->columns[$key]['db_name_3'];
                    
                    $this->columns[$key]['reference_uniq_name_2'] = $this->columns[$key]['db_name_4'];
                    $this->columns[$key]['reference_where_name_2'] = $this->table . '.' . $this->columns[$key]['db_name_4'];
                    
                    $this->columns[$key]['reference_uniq_name_3'] = $this->columns[$key]['db_name_5'];
                    $this->columns[$key]['reference_where_name_3'] = $this->table . '.' . $this->columns[$key]['db_name_5'];
                } else if ($this->columns[$key]['type'] == '1-t') {
                    $this->columns[$key]['unique_name'] = $this->columns[$key]['db_name'];
                    $this->columns[$key]['where_name'] = $this->table . '.' . $this->columns[$key]['db_name'];
                    
                    $this->columns[$key]['reference_uniq_name'] = $this->columns[$key]['ref_field_db_name'];
                    $this->columns[$key]['reference_where_name'] = $this->table . '.' . $this->columns[$key]['ref_field_db_name'];
                } else if ($this->columns[$key]['type'] == '1-1+2') {
                    $this->columns[$key]['unique_name'] = $this->columns[$key]['ref_field_db_name'];
                    $this->columns[$key]['where_name'] = $this->table . '.' . $this->columns[$key]['ref_field_db_name'];
                    
                    $this->columns[$key]['reference_uniq_name'] = $this->columns[$key]['ref_field_2_db_name'];
                    $this->columns[$key]['reference_where_name'] = $this->table . '.' . $this->columns[$key]['ref_field_2_db_name'];
                } else if ($this->columns[$key]['type'] == '1-(1+2)-1-1') {
                    $this->columns[$key]['unique_name'] = $this->columns[$key]['ref_field_db_name'];
                    $this->columns[$key]['where_name'] = $this->table . '.' . $this->columns[$key]['ref_field_db_name'];
                    
                    $this->columns[$key]['reference_uniq_name'] = $this->columns[$key]['ref_field_1_db_name'];
                    $this->columns[$key]['reference_where_name'] = $this->table . '.' . $this->columns[$key]['ref_field_1_db_name'];
                    
                    $this->columns[$key]['reference_uniq_name_1'] = $this->columns[$key]['ref_field_1_1_db_name'];
                    $this->columns[$key]['reference_where_name_1'] = $this->table . '.' . $this->columns[$key]['ref_field_1_1_db_name'];
                } else if ($this->columns[$key]['type'] == '1-(1+2+3)-1-1') {
                    $this->columns[$key]['unique_name'] = $this->columns[$key]['ref_field_db_name'];
                    $this->columns[$key]['where_name'] = $this->table . '.' . $this->columns[$key]['ref_field_db_name'];
                    
                    $this->columns[$key]['reference_uniq_name'] = $this->columns[$key]['ref_field_1_db_name'];
                    $this->columns[$key]['reference_where_name'] = $this->table . '.' . $this->columns[$key]['ref_field_1_db_name'];
                    
                    $this->columns[$key]['reference_uniq_name_1'] = $this->columns[$key]['ref_field_2_db_name'];
                    $this->columns[$key]['reference_where_name_1'] = $this->table . '.' . $this->columns[$key]['ref_field_2_db_name'];
                    
                    $this->columns[$key]['reference_uniq_name_2'] = $this->columns[$key]['ref_field_1_1_db_name'];
                    $this->columns[$key]['reference_where_name_2'] = $this->table . '.' . $this->columns[$key]['ref_field_1_1_db_name'];
                } else if ($this->columns[$key]['type'] == '1-1-2') {
                    $this->columns[$key]['unique_name'] = $this->columns[$key]['ref_table_db2_name'] . '_' . $this->columns[$key]['ref_field_db2_name'];
                    $this->columns[$key]['where_name'] = $this->columns[$key]['ref_table_db2_name'] . '.' . $this->columns[$key]['ref_field_db2_name'];
                } else if ($this->columns[$key]['type'] == 'u') {
                    $this->columns[$key]['unique_name'] = /*$this->table . '_' . */$this->columns[$key]['db_name'];
                    $this->columns[$key]['where_name'] = $this->table1 . '.' . $this->columns[$key]['db_name'];
                } else {
                    $this->columns[$key]['unique_name'] = /*$this->table . '_' . */$this->columns[$key]['db_name'];
                    $this->columns[$key]['where_name'] = $this->table2 . '.' . $this->columns[$key]['db_name'];
                }
                
                // Convert columns to objects
                $this->columns[$key] = (object) $this->columns[$key];
                
                // Count filters
                if ($this->columns[$key]->allow_filter !== FALSE) {
                    $this->filter_nr ++;
                }
                $this->headers[$key] = $this->columns[$key]->header;
                // $this->columns_visible[$key] = TRUE;
                $this->columns_visible[] = $key;
            }
        }
        
        // Set limit and offset
        if ($this->allow_pagination) {
            $this->page_size = ($this->page_size == 'all') ? 'all' : (is_numeric($this->page_size) ? $this->page_size : 10);
            $this->limit = (is_numeric($this->page_size)) ? $this->page_size : NULL;
            // $this->offset = (is_numeric($this->offset)) ? $this->offset : 0;
            $this->offset = $this->limit * ($this->page - 1);
        } else {
            $this->page_size = 'all';
            $this->page = 1;
            $this->limit = NULL;
            $this->offset = 0;
        }
        
        // ---------------------------------------------------------------------
        
        // Set default commands
        if ($this->allow_add) {
            $defaults = array(
                'type' => 'dialog',
                'text' => lang('cg_add'),
                'name' => 'add',
                'icon' => 'circle-plus',
                'toolbar' => TRUE,
                'grid' => FALSE,
                'dialog_save' => lang('cg_save'),
                'dialog_cancel' => lang('cg_cancel')
            );
            $this->commands['add'] = isset($this->commands['add']) ? array_merge($defaults, $this->commands['add']) : $defaults;
        } else {
            unset($this->commands['add']);
        }
        if ($this->allow_edit) {
            $defaults = array(
                'type' => 'dialog',
                'text' => lang('cg_edit'),
                'name' => 'edit',
                'icon' => 'pencil',
                'dialog_save' => lang('cg_save'),
                'dialog_cancel' => lang('cg_cancel')
            );
            $this->commands['edit'] = isset($this->commands['edit']) ? array_merge($defaults, $this->commands['edit']) : $defaults;
        } else {
            unset($this->commands['edit']);
        }
        if ($this->allow_delete) {
            $defaults = array(
                'type' => 'post',
                'text' => lang('cg_delete'),
                'name' => 'delete',
                'icon' => 'trash',
                'toolbar' => TRUE,
                'multi' => TRUE,
                'confirm' => TRUE,
                'confirm_title' => lang('cg_confirm_delete_title'),
                'confirm_text' => lang('cg_confirm_delete'),
                'confirm_yes' => lang('cg_yes'),
                'confirm_no' => lang('cg_no')
            );
            $this->commands['delete'] = isset($this->commands['delete']) ? array_merge($defaults, $this->commands['delete']) : $defaults;
        } else {
            unset($this->commands['delete']);
        }
        
        // Init commands
        foreach ($this->commands as $key => $command) {
            $this->commands[$key] = array_merge($this->command_defaults, $command);
        }
        
        // Handle commands
        foreach ($this->commands as $key => $command) {
            // Peform command if posted
            if (($arg = $this->CI->input->post('cg_' . $this->id . '_command_' . $command['name'])) !== FALSE) {
                // Get arguments
                if (($arg === $command['text'] or $arg === '')) {
                    $arg = NULL;
                }
                // Get selected arguments if command can handle multiple arguments
                if ($command['multi']) {
                    if (is_array($item_ids = $this->CI->input->post('cg_' . $this->id . '_item_ids'))) {
                        // $arg = implode(':', $item_ids);
                        $arg = $item_ids;
                    }
                }
                if ($command['confirm']) {
                    if (is_null($arg) or $this->CI->input->post('cg_' . $this->id . '_dialog_no') !== FALSE) {
                        // Command was rejected
                        break;
                    } else if ($this->CI->input->post('cg_' . $this->id . '_dialog_yes') === FALSE) {
                        $this->dialog->visible = TRUE;
                        $this->dialog->class = 'cg-dialog-confirm';
                        $this->dialog->command = $command['name'];
                        $this->dialog->command_arg = $arg;
                        $this->dialog->title = $command['confirm_title'];
                        $this->dialog->yes = lang('cg_yes');
                        $this->dialog->no = lang('cg_no');
                        $this->dialog->content = $this->CI->load->view('carbo/carbo_confirm', array(
                            'text' => $command['confirm_text']
                        ), TRUE);
                        // Wait for confirmation, break command
                        break;
                    }
                }
                // Execute command
                $this->command = $command['name'];
                $this->command_arg = $arg;
                if ($command['url']) {
                    if ($this->is_ajax) {
                        $this->response->redirect = rtrim($command['url'], '/') . '/' . $arg;
                    } else {
                        redirect(rtrim($command['url'], '/') . '/' . $arg);
                    }
                    return FALSE;
                } elseif (method_exists($this->CI, $command['function'])) {
                    if ($command['type'] == 'dialog') {
                        if ($this->CI->input->post('cg_' . $this->id . '_dialog_no') !== FALSE) {
                            break;
                        }
                        
                        $validate = $this->CI->input->post('cg_' . $this->id . '_dialog_yes') !== FALSE;
                        $result = $this->CI->{$command['function']}($validate, $arg, $this);
                        
                        if ($result === TRUE) {
                            $this->render_table = TRUE;
                        } elseif ($this->CI->input->post('cg_' . $this->id . '_dialog_no') === FALSE) {
                            $this->render_table = ! $this->is_ajax;
                            $this->dialog->visible = TRUE;
                            $this->dialog->class = 'cg-dialog-form';
                            $this->dialog->command = $this->command;
                            $this->dialog->command_arg = $this->command_arg;
                            $this->dialog->title = is_null($arg) ? lang('cg_add') : lang('cg_edit');
                            $this->dialog->yes = lang('cg_save');
                            $this->dialog->no = lang('cg_cancel');
                            $this->dialog->content = $result;
                        }
                    } else {
                        $this->CI->{$command['function']}($arg, $command['filters']);
                    }
                } else {
                    switch ($command['name']) {
                        case 'add':
                            $this->form();
                            break;
                        
                        case 'edit':
                            $this->form($arg, $command['filters']);
                            break;
                        
                        case 'delete':
                            $this->delete($arg, $command['filters']);
                            break;
                        
                        // Custom command
                        default:
                            redirect(rtrim($command['url'], '/') . '/' . $arg);
                            return FALSE;
                    }
                }
                break;
            }
        }
        
        // ---------------------------------------------------------------------
        
        // Show columns visibility list
        if ($this->CI->input->post('cg_' . $this->id . '_columns') !== FALSE) {
            $this->show_col_list = TRUE;
        }
        
        // Init visible columns array
        if ($this->allow_columns) {
            if ($this->CI->input->post('cg_' . $this->id . '_columns_list') !== FALSE) {
                $this->columns_visible = $this->CI->input->post('cg_' . $this->id . '_columns_visible');
                $this->column_string = (count($this->columns_visible) == count($this->headers)) ? 'all' : (is_array($this->columns_visible) ? implode(':', $this->columns_visible) : 'none');
                if (! $this->is_ajax) {
                    // redirect($this->url . $this->limit . '/' . $this->offset . '/' . $this->column_string . '/' . $this->order_string . '/' . $this->filter_string);
                    redirect($this->url . $this->params_before . $this->page_size . '-' . $this->page . '-' . $this->column_string . '-' . $this->order_string . '-' . $this->filter_string . $this->params_after);
                    return FALSE;
                }
                $this->show_col_list = FALSE;
            } elseif ($this->column_string == 'none') {
                $this->columns_visible = array();
            } elseif ($this->column_string != 'all') {
                $this->columns_visible = explode(':', $this->column_string);
            }
        }
        
        $this->filter_by_site = ! empty($this->filter_site_string) ? $this->filter_site_string : '';
        $this->filter_site = $this->filter_by_site;
        
        if (isset($this->filter_date_string) && ! empty($this->filter_date_string)) {
            $this->filter_by_date = $this->filter_date_string;
            $this->filter_date = $this->filter_by_date;
            $this->filter_by_date_uri = $this->url . $this->params_before . $this->page_size . '-' . $this->page . '-' . $this->column_string . '-' . $this->order_string . '-' . $this->filter_string . $this->params_after . '-' . $this->filter_by_date . '-' . $this->filter_site_string;
        } else {
            $this->filter_by_date = 2;
            $this->filter_date = $this->filter_by_date;
            $this->filter_by_date_uri = $this->url . $this->params_before . $this->page_size . '-' . $this->page . '-' . $this->column_string . '-' . $this->order_string . '-' . $this->filter_string . $this->params_after . '-' . $this->filter_by_date . '-' . $this->filter_site_string;
        }
        
        // ---------------------------------------------------------------------
        
        // Handle page size change
        if ($this->CI->input->post('cg_' . $this->id . '_change_page_size') !== FALSE) {
            $this->page_size = $this->CI->input->post('cg_' . $this->id . '_page_size');
            $this->limit = (is_numeric($this->page_size)) ? $this->page_size : NULL;
            // redirect($this->url . $this->limit . '/' . $this->offset . '/' . $this->column_string . '/' . $this->order_string . '/' . $this->filter_string);
            redirect($this->url . $this->params_before . $this->page_size . '-' . $this->page . '-' . $this->column_string . '-' . $this->order_string . '-' . $this->filter_string . $this->params_after);
            return FALSE;
        }
        
        // ---------------------------------------------------------------------
        
        // Set filters
        if ($this->allow_filter) {
            if ($this->CI->input->post('cg_' . $this->id . '_apply_filter') !== FALSE) {
                $this->filter_string = '';
                foreach ($this->columns as $key => $column) {
                    if (($value = $this->CI->input->post('cg_' . $this->id . '_filter_' . $key)) !== FALSE && ($value !== '')) {
                        $op = $this->CI->input->post('cg_' . $this->id . '_filter_op_' . $key);
                        if ($op) {
                            $this->filters[$key]['field'] = $column->where_name;
                            $this->filters[$key]['operator'] = $op;
                            $this->filters[$key]['value'] = $this->parse_filter_value($column, $value);
                            $this->filter_string .= $key . ':' . $this->encode($value) . ':' . $op . '_';
                        }
                    }
                }
                
                $this->filter_string = $this->filter_string ? rtrim($this->filter_string, '_') : 'all';
                
                if (! $this->is_ajax) {
                    // redirect($this->url . $this->limit . '/0/' . $this->column_string . '/' . $this->order_string . '/' . $this->filter_string);
                    redirect($this->url . $this->params_before . $this->page_size . '-1-' . $this->column_string . '-' . $this->order_string . '-' . $this->filter_string . $this->params_after);
                    return FALSE;
                }
            } elseif ($this->filter_string != 'all') {
                $filters = explode('_', $this->filter_string);
                $filt = array();
                foreach ($filters as $f) {
                    $f = explode(':', $f);
                    if (array_key_exists($f[0], $this->headers) and isset($f[1]) and ($f[1] !== '')) {
                        $filt[$f[0]]['field'] = $this->columns[$f[0]]->where_name;
                        $filt[$f[0]]['value'] = $this->parse_filter_value($this->columns[$f[0]], $this->decode($f[1]));
                        $filt[$f[0]]['operator'] = isset($f[2]) ? $f[2] : 'eq';
                    }
                }
                $this->filters = $filt;
            } else {
                $this->filters = array();
            }
        } else {
            $this->filters = array();
        }
        // ---------------------------------------------------------------------
        
        // Set order
        if ($this->allow_sort) {
            if ($this->order_string !== NULL && $this->order_string !== 'none') {
                $order = explode('_', $this->order_string);
                $ord = array();
                foreach ($order as $o) {
                    $o = explode(':', $o);
                    if (array_key_exists($o[0], $this->headers)) {
                        if (! isset($o[1]) or ($o[1] != 'desc')) {
                            $ord[$o[0]] = 'ASC';
                        } else {
                            $ord[$o[0]] = 'DESC';
                        }
                        // Stop on first if multiple column sort is not allowed
                        if (! $this->allow_multisort)
                            break;
                    }
                }
                $this->order = $ord;
            }
        } else {
            $this->order = array();
        }
    }

    function getCustomFilterPaginationArgs()
    {
        $args_str = "";
        
        $uri_param = $this->uri_param;
        if ($uri_param) {
            $uri_param = explode('-', $uri_param);
            
            if (isset($uri_param[6]) && $uri_param[6] != "daterange" && $uri_param[6] != "lab")
                $args_str = '-' . $this->filter_site_string;
            if (isset($uri_param[6]) && $uri_param[6] == "daterange") {
                $args_str = '-daterange-' . $uri_param[7] . '-' . $uri_param[8];
            }
            
            if (isset($uri_param[6]) && $uri_param[6] == "lab")
                $args_str = '-lab-' . $this->filter_lab_string;
            else if (isset($uri_param[6]) && $uri_param[9] == "lab")
                $args_str = '-lab-' . $this->filter_lab_string;
            
            if (isset($uri_param[6]) && $uri_param[6] == "city")
                $this->filter_city = urldecode($uri_param[7]);
            else if (isset($uri_param[9]) && $uri_param[9] == "city")
                $this->filter_city = urldecode($uri_param[10]);
            else if (isset($uri_param[10]) && $uri_param[10] == "city")
                $this->filter_city = urldecode($uri_param[11]);
            
            if (isset($uri_param[6]) && $uri_param[6] == "status")
                $args_str = '-status-' . $this->filter_status_string;
            else if (isset($uri_param[9]) && $uri_param[9] == "status")
                $args_str = '-status-' . $this->filter_status_string;
            else if (isset($uri_param[10]) && $uri_param[10] == "status")
                $args_str = '-status-' . $this->filter_status_string;
            
            if (isset($uri_param[6]) && $uri_param[6] == "futureassign")
                $this->filter_futureassign = $uri_param[7];
            else if (isset($uri_param[9]) && $uri_param[9] == "futureassign")
                $this->filter_futureassign = $uri_param[10];
            else if (isset($uri_param[10]) && $uri_param[10] == "futureassign")
                $this->filter_futureassign = $uri_param[11];
            
            if (isset($uri_param[6]) && $uri_param[6] == "pendingassign")
                $this->filter_pendingassign = $uri_param[7];
            else if (isset($uri_param[9]) && $uri_param[9] == "pendingassign")
                $this->filter_pendingassign = $uri_param[10];
            else if (isset($uri_param[10]) && $uri_param[10] == "pendingassign")
                $this->filter_pendingassign = $uri_param[11];
            
            if (isset($uri_param[6]) && $uri_param[6] == "sitetype")
                $this->filter_sitetype = $uri_param[7];
            else if (isset($uri_param[9]) && $uri_param[9] == "sitetype")
                $this->filter_sitetype = $uri_param[10];
            else if (isset($uri_param[10]) && $uri_param[10] == "sitetype")
                $this->filter_sitetype = $uri_param[11];
        }
        // echo "here".$this->filter_lab_string."<br>";
        // die;
        return $args_str;
    }

    /**
     * Get data
     */
    function get_data()
    {
        $filters = array();
        foreach ($this->filters as $filter) {
            $filters[] = $filter;
        }
        foreach ($this->hard_filters as $key => $filter) {
            $f['field'] = $this->columns[$key]->where_name;
            $f['value'] = $filter['value'];
            $f['operator'] = isset($filter['operator']) ? $filter['operator'] : 'eq';
            $filters[] = $f;
        }
        
        if ($this->filter_pendingassign == 1)
            $this->total = $this->CI->service_requestmodel->getTotalPendingRequests();
        else
            $this->total = $this->CI->Carbo_model->count_items($this->table, $this->table_id_name, $this->columns, $filters, $this->filter_date, $this->filter_site, $this->filter_daterange, $this->filter_lab_string, $this->filter_trap, $this->filter_city, $this->filter_status_string, $this->table1_rel, $this->filter_service, $this->filter_sentinel, $this->filter_futureassign, $this->filter_pendingassign, $this->filter_sitetype, $this->filter_siteofinterest, $this->order, $this->filter_wanum);
        
        $this->data = $this->CI->Carbo_model->get_items($this->table, $this->table_id_name, $this->columns, NULL, $filters, $this->limit, $this->offset, $this->order, '', $this->filter_date, $this->table1_rel, $this->filter_site, $this->filter_daterange, $this->filter_lab_string, $this->filter_trap, $this->filter_city, $this->filter_status_string, $this->filter_service, $this->filter_sentinel, $this->filter_futureassign, $this->filter_pendingassign, $this->filter_sitetype, $this->filter_siteofinterest, $this->page, $this->filter_wanum);
        
        // print'<pre>';
        // print_r($this->total);
        // print'</pre>';
        // die;
        
        if ($this->table == "sites" || $this->table1 == "adultsurveillance") {
            $this->filter_siteofinterest_string = $this->filter_siteofinterest;
            foreach ($this->data as $k => $v) {
                if (! empty($this->filter_site)) {
                    $this->select_site_id = $v->idsite;
                    $this->select_site = $v->site;
                }
                if (! empty($this->filter_sitetype))
                    $this->filter_sitetype_string = $v->sitetypes_sitetype;
            }
        }
        if ($this->filter_pendingassign)
            $this->filter_pendingassign_string = $this->filter_pendingassign;
        
        if ($this->table == "servicerequests" && ! is_null($this->filter_city)) {
            foreach ($this->data as $k => $v) {
                $this->select_city_id = $v->city;
            }
            $this->select_city = $this->filter_city;
        }
    }

    /**
     * Get data for multiple Table
     * BY UNION
     */
    function get_data_1()
    {
        $filters = array();
        foreach ($this->filters as $filter) {
            $filters[] = $filter;
        }
        
        foreach ($this->hard_filters as $key => $filter) {
            $f['field'] = $this->columns[$key]->where_name;
            $f['value'] = $filter['value'];
            $f['operator'] = isset($filter['operator']) ? $filter['operator'] : 'eq';
            $filters[] = $f;
        }
        
        // $this->total = $this->CI->Carbo_model->count_items_1($this->table1, $this->table_id_1_name,$this->table2, $this->table_id_2_name, $this->columns, $filters);
        // $this->data = $this->CI->Carbo_model->get_items_1($this->table1, $this->table_id_1_name,$this->table2, $this->table_id_2_name, $this->columns, NULL, $filters, $this->limit, $this->offset, $this->order);
        
        $this->total = $this->CI->Carbo_model->count_items_1($this->table1, $this->table_id_1_name, $this->table2, $this->table_id_2_name, $this->columns, $filters, $this->table1_rel, $this->table2_rel, $this->filter_date, $this->page, $this->filter_daterange, $this->filter_service, $this->filter_adultkey);
        $this->sep_total = $this->CI->Carbo_model->count_items_sep($this->table1, $this->table_id_1_name, $this->table2, $this->table_id_2_name, $this->columns, $filters, $this->table1_rel, $this->table2_rel, $this->filter_date, $this->page, $this->filter_daterange, $this->filter_service, $this->filter_adultkey);
        $this->data = $this->CI->Carbo_model->get_items_1($this->table1, $this->table_id_1_name, $this->table2, $this->table_id_2_name, $this->columns, NULL, $filters, $this->limit, $this->offset, $this->order, '', $this->table1_rel, $this->table2_rel, $this->filter_date, $this->page, $this->total, $this->sep_total, $this->page_size, $this->filter_daterange, $this->filter_service, $this->filter_adultkey);
        
        // print'<pre>';
        // echo $this->page_size;
        // print_r($this->total);
        // die;
    }

    /**
     * Get data from for Map Management Added By Nitya
     * BY UNION
     */
    function get_data_map()
    {
        $filters = array();
        foreach ($this->filters as $filter) {
            $filters[] = $filter;
        }
        foreach ($this->hard_filters as $key => $filter) {
            $f['field'] = $this->columns[$key]->where_name;
            $f['value'] = $filter['value'];
            $f['operator'] = isset($filter['operator']) ? $filter['operator'] : 'eq';
            $filters[] = $f;
        }
        
        $this->total = $this->CI->Carbo_model->count_items_map($this->table, $this->table_id_name, $this->columns, $filters, $this->filter_date, $this->filter_daterange, $this->filter_by_type, $this->filter_site, '', $this->order);
        $this->data = $this->CI->Carbo_model->get_items_map($this->table, $this->table_id_name, $this->columns, NULL, $filters, $this->limit, $this->offset, $this->order, '', $this->filter_date, $this->filter_daterange, $this->filter_by_type, $this->filter_site, '', 'event', 'event', ''); // now getting events (getting only events data)
                                                                                                                                                                                                                                                                                               
        // $size = sizeof($this->data);
                                                                                                                                                                                                                                                                                               // $this->total = count($this->data);//Only when events data is showed in table
                                                                                                                                                                                                                                                                                               // if($this->offset > $size || $this->limit > $size) {//Only when events data is showed in table
                                                                                                                                                                                                                                                                                               // $end = ceil($size / $this->limit);
                                                                                                                                                                                                                                                                                               // $this->data = array_slice($this->data , ($end-1) * $this->limit , $this->limit);//Only when events data is showed in table
                                                                                                                                                                                                                                                                                               // }
                                                                                                                                                                                                                                                                                               // else
                                                                                                                                                                                                                                                                                               // $this->data = array_slice($this->data , $this->offset , $this->limit);//Only when events data is showed in table
        
        foreach ($this->data as $k => $v) {
            if (! empty($this->filter_site)) {
                $this->select_site_id = $v->idsite;
                $this->select_site = $v->site;
            }
            if (! empty($this->filter_sitetype))
                $this->filter_sitetype_string = $v->sitetypes_sitetype;
        }
    }

    /**
     * Render
     */
    function render($service_req = '')
    {
        if (! empty($service_req))
            $this->filter_service = $service_req;
        // Get data
        if ($this->render_table) {
            if (! isset($this->multiple)) {
                if (method_exists($this->CI, $this->get_data)) {
                    $this->CI->{$this->get_data}($this);
                } else {
                    $this->get_data();
                }
            } elseif ($this->multiple == 'map') {
                $this->get_data_map();
            } else {
                $this->get_data_1();
            }
        }
        
        // Calculate page numbers and pagination links
        if ($this->allow_pagination && $this->render_table) {
            
            $custom_filter_args = $this->getCustomFilterPaginationArgs();
            
            $limit = is_null($this->limit) ? $this->total : $this->limit;
            $this->page_max = $this->total ? ceil($this->total / $limit) : 1;
            $this->page_curr = ceil(($this->offset + 1) / $limit);
            $this->page_curr = ($this->page_curr > $this->page_max) ? $this->page_max : $this->page_curr;
            $this->page_curr = ($this->page_curr < 1) ? 1 : $this->page_curr;
            $this->page_start = (($this->page_curr - ceil($this->pagination_links / 2) + 1) < 1) ? 1 : ($this->page_curr - ceil($this->pagination_links / 2) + 1);
            $this->page_nr = ($this->page_start + $this->pagination_links <= $this->page_max) ? $this->page_start + $this->pagination_links : $this->page_max + 1;
            $this->offset = ($this->page_curr - 1) * $limit;
            $this->item_start = ($this->total > 0) ? $this->offset + 1 : 0;
            $this->item_end = ($this->offset + $limit > $this->total) ? $this->total : $this->offset + $limit;
            
            $grid_param = $this->page_size . '-1-' . $this->column_string . '-' . $this->order_string . '-' . $this->filter_string . '-' . $this->filter_by_date . $custom_filter_args;
            
            $this->first_link = $this->url . $this->params_before . $grid_param . $this->params_after;
            
            $grid_param = $this->page_size . '-' . ($this->page_curr - 1) . '-' . $this->column_string . '-' . $this->order_string . '-' . $this->filter_string . '-' . $this->filter_by_date . $custom_filter_args;
            $this->prev_link = $this->url . $this->params_before . $grid_param . $this->params_after;
            $grid_param = $this->page_size . '-' . ($this->page_curr + 1) . '-' . $this->column_string . '-' . $this->order_string . '-' . $this->filter_string . '-' . $this->filter_by_date . $custom_filter_args;
            $this->next_link = $this->url . $this->params_before . $grid_param . $this->params_after;
            $grid_param = $this->page_size . '-' . ($this->page_max) . '-' . $this->column_string . '-' . $this->order_string . '-' . $this->filter_string . '-' . $this->filter_by_date . $custom_filter_args;
            $this->last_link = $this->url . $this->params_before . $grid_param . $this->params_after;
            
            $this->page_start = ($this->page_nr > $this->pagination_links) ? ($this->page_nr - $this->pagination_links) : $this->page_start;
            
            for ($i = $this->page_start; $i < $this->page_nr; $i ++) {
                
                $grid_param = $this->page_size . '-' . ($i) . '-' . $this->column_string . '-' . $this->order_string . '-' . $this->filter_string . '-' . $this->filter_by_date . $custom_filter_args;
                $this->page_links[$i] = ($i == $this->page_curr) ? '' : ($this->url . $this->params_before . $grid_param . $this->params_after);
            }
        }
        
        // Export to PDF
        /*
         * if ($this->CI->input->post('export') !== FALSE)
         * {
         * $this->CI->load->plugin('dompdf');
         * $dompdf = new DOMPDF();
         * $html = $this->CI->load->view('carbogrid/datagrid_print', array('grid' => $this), TRUE);
         * //echo $html;
         * $dompdf->load_html($html);
         * $dompdf->render();
         * $dompdf->stream('datagrid.pdf');
         * }
         */
        
        if ($this->is_ajax) {
            if ($this->render_table) {
                $this->response = empty($this->response) ? (object) NULL : $this->response;
                $this->response->table = $this->CI->load->view('carbo/carbo_grid', array(
                    'grid' => $this
                ), TRUE);
            }
            
            if ($this->dialog->visible) {
                $this->response = empty($this->response) ? (object) NULL : $this->response;
                $this->response->dialog = $this->dialog->content;
            }
            // If form is posted via iframe (when uploading files), wrap json content between <textarea> tags (handled by the jquery form plugin)
            $output = '';
            if (! carbo_is_ajax())
                $output .= '<textarea>';
            $output .= json_encode($this->response);
            if (! carbo_is_ajax())
                $output .= '</textarea>';
            $this->CI->output->set_output($output);
            return TRUE;
        } else {
            // print'<pre>';
            // print_r($this);
            // die;
            return $this->CI->load->view('carbo/carbo_grid', array(
                'grid' => $this
            ), TRUE);
        }
    }

    /**
     * Form
     */
    function form($item_id = NULL, $filters = array())
    {
        if ($this->CI->input->post('cg_' . $this->id . '_dialog_no') !== FALSE) {
            $this->form = NULL;
            return TRUE;
        }
        
        $this->render_table = ! $this->is_ajax;
        
        $params = array(
            'id' => $this->id,
            'table' => $this->table,
            'table_id_name' => $this->table_id_name,
            'item_id' => $item_id,
            'is_ajax' => $this->is_ajax,
            'columns' => $this->columns,
            'filters' => $this->convert_filters($filters),
            'month_names' => $this->month_names,
            'month_names_short' => $this->month_names_short,
            'day_names' => $this->day_names,
            'day_names_short' => $this->day_names_short,
            'day_names_min' => $this->day_names_min,
            'nested' => TRUE
        );
        
        $this->CI->load->library('carboform', $params, 'cf_' . $this->id);
        
        $this->form = $this->CI->{'cf_' . $this->id};
        
        if ($this->form->run($this->CI->input->post('cg_' . $this->id . '_dialog_yes') !== FALSE) === TRUE) {
            $this->render_table = TRUE;
            return TRUE;
        }
        
        if ($this->CI->input->post('cg_' . $this->id . '_dialog_no') === FALSE) {
            $this->dialog->visible = TRUE;
            $this->dialog->class = 'cg-dialog-form';
            $this->dialog->command = $this->command;
            $this->dialog->command_arg = $this->command_arg;
            $this->dialog->title = is_null($item_id) ? lang('cg_add') : lang('cg_edit');
            $this->dialog->yes = lang('cg_save');
            $this->dialog->no = lang('cg_cancel');
            $this->dialog->content = $this->form->render();
        }
        
        return FALSE;
    }

    /**
     * Delete
     */
    function delete($item_ids, $filters = array())
    {
        $filt = $this->convert_filters($filters);
        $this->CI->Carbo_model->delete_items($this->table, $this->table_id_name, $item_ids, $filt);
    }

    /**
     * Create order url
     */
    function create_order_url($params, $text)
    {
        // $order = array_merge($this->order, $params['order']);
        // echo $this->allow_multisort."<br>";
        if ($this->allow_multisort) {
            $order = $this->order;
        } else {
            $order = array();
        }
        
        foreach ($params['order'] as $name => $dir) {
            $order[$name] = $dir;
        }
        $order_str = '';
        $i = 0;
        foreach ($order as $name => $dir) {
            if ($dir !== NULL) {
                $order_str .= '_' . $name . ':' . strtolower($dir);
            }
        }
        $order_str = ltrim($order_str, '_');
        
        $order_str = $order_str ? $order_str : 'none';
        
        $grid_param = $this->page_size . '-' . $this->page . '-' . $this->column_string . '-' . $order_str . '-' . $this->filter_string . '-' . $this->filter_by_date;
        
        return anchor($this->url . $this->params_before . $grid_param . $this->params_after, $text, 'data-order="' . $order_str . '" class="cg-sort" rel="nofollow"');
    }

    /**
     * Convert filters
     */
    function convert_filters($filters)
    {
        $filt = array();
        foreach ($filters as $key => $filter) {
            $f['field'] = $this->columns[$key]->where_name;
            $f['value'] = $filter['value'];
            $f['operator'] = isset($filter['operator']) ? $filter['operator'] : 'eq';
            $filt[] = $f;
        }
        return $filt;
    }

    /**
     * Check command
     */
    function check_command($command, $row)
    {
        $valid = TRUE;
        foreach ($command['filters'] as $key => $filter) {
            $field = $row->{$this->columns[$key]->unique_name};
            $value = $filter['value'];
            if (! isset($filter['operator'])) {
                $filter['operator'] = 'eq';
            }
            switch ($filter['operator']) {
                case 'noteq':
                    $valid = $field != $value;
                    break;
                case 'lt':
                    $valid = $field < $value;
                    break;
                case 'lte':
                    $valid = $field <= $value;
                    break;
                case 'gt':
                    $valid = $field > $value;
                    break;
                case 'gte':
                    $valid = $field >= $value;
                    break;
                case 'in':
                    $valid = (array_search($field, $value) !== FALSE);
                    break;
                case 'notin':
                    $valid = (array_search($field, $value) === FALSE);
                    break;
                case 'like':
                    $valid = (strpos($field, $value) !== FALSE);
                    break;
                case 'notlike':
                    $valid = (strpos($field, $value) === FALSE);
                    break;
                case 'starts':
                    $valid = (strpos($field, $value) === 0);
                    break;
                case 'ends':
                    $valid = (strpos($field, $value) === (strlen($field) - strlen($value)));
                    break;
                
                default:
                    $valid = $field == $value;
            }
            if (! $valid)
                return FALSE;
        }
        return $valid;
    }

    /**
     * Parse filter value
     */
    function parse_filter_value($column, $value)
    {
        switch ($column->type) {
            // Boolean
            // case 'boolean':
            // return;
            
            case 'date':
                return carbo_format_date($value, $column->date_format, 'Y-m-d');
            
            case 'datetime':
                return carbo_format_date($value, $column->date_format . ' ' . $column->time_format, 'Y-m-d H:i:s');
            
            case 'time':
                return carbo_format_date($value, $column->time_format, 'H:i:s');
            
            default:
                return $value;
        }
    }

    /**
     * Encode
     */
    function encode($string)
    {
        return strtr(base64_encode($string), '+/=', '%.~');
    }

    /**
     * Decode
     */
    function decode($string)
    {
        return base64_decode(strtr($string, '%.~', '+/='));
    }
}

/* End of file Carbogrid.php */
/* Location: ./application/libraries/Carbogrid.php */
