<?php if (!defined('BASEPATH')) exit('No direct script access allowed');
session_start();
class Common
{
    public $moduleNum = '';
    public $moduleName = '';
    public $idsite = '';
    public $idlocation = '';
    public $filter_date = '';
    public $filter_daterange = '';
    public $page = '';
    public $page_size = '';
    public $offset = '';
    
    
    /**
     * Constructor
    **/
    function __construct($params = array())
    {
        $this->CI = & get_instance();
        $this->CI->load->model('Carbo_model');
        $this->CI->load->model('treatment_model');
        $this->CI->load->model('adultsurveillance_model');
        $this->CI->load->model('larvalsurveillance_model');
        $this->CI->load->model('landingrate_model');
        $this->CI->load->model('weather_model');
        $this->CI->load->model('service_requestmodel');
        $this->CI->load->model('arbovirallab_model');
        $this->CI->load->model('corvidlab_model');
        $this->CI->load->model('sentinelChickenlab_model');
          
        $this->moduleNum = !empty($params['moduleNum']) ? $params['moduleNum'] : "";
        $this->idsite = !empty($params['idsite']) ? $params['idsite'] : "";
        $this->idlocation = !empty($params['idlocation']) ? $params['idlocation'] : "";
        $this->filter_date = !empty($params['filter_date']) ? $params['filter_date'] : "";
        $this->filter_daterange = !empty($params['filter_daterange']) ? $params['filter_daterange'] : "";
        $this->page = !empty($params['page']) ? $params['page'] : "1";
        $this->page_size = !empty($params['page_size']) ? $params['page_size'] : "";
        $this->orderby = !empty($params['orderby']) ? $params['orderby'] : "";
        
        // Set limit and offset
        $this->page_size = ($this->page_size == 'all') ? 'all' : (is_numeric($this->page_size) ? $this->page_size : 10);
        $this->page_size = (is_numeric($this->page_size)) ? $this->page_size : NULL;
        $this->offset = $this->page_size * ($this->page - 1);
    }
    
    /**
	 * Function to fetch site based on module
	 */
	public function getEventData() {
        $response = array();
        if(empty($this->moduleNum) || empty($this->idsite)){
            return $response;
        }
        
        $params = array (
			'id' => 'idadultsurveillance',
			'table' => 'adultsurveillance',
			'columns' => array('name' => 'site'),
            'filters' => array (
							0 => array (
									'value' => $this->idlocation
							) 
					)
        );
        
        $response = $this->CI->Carbo_model->get_items_map($params['table'], $params['id'], $params['columns'], '', $params['filters'], $this->page_size, $this->offset, $this->orderby, '', $this->filter_date, $this->filter_daterange, '', $this->idsite , '1');
        //print'<pre>';
//        print_r($response);
        $response = $this->filterByModule($response);
        
        return $response;
    }
    
    /**
	 * Function to fetch all records
	 */
	public function getAllEvents() {
        $response = array();
        $params = array (
			'id' => 'idadultsurveillance',
			'table' => 'adultsurveillance',
			'columns' => array('name' => 'site'),
            'filters' => array (
							0 => array (
									'value' => $this->idlocation
							) 
					)
        );
        
        $response = $this->CI->Carbo_model->get_items_map($params['table'], $params['id'], $params['columns'], '', $params['filters'], '', '', '', '', $this->filter_date, $this->filter_daterange, '', '','', '1', $this->dataForPDF, $this->dataForPDF_allSites);//no event filtration, getting their data, not placing pins
        $response = $this->filterDuplicated($response);
        return $response;
    }
    
    public function filterDuplicated($response)
    {
        if(!empty($response)){
            $tempArray = array();
            foreach($response as $key => $val){
                $obj = (object) array('idVal' => $val->id, 'idSiteVal' =>  $val->idsite);
                if(!in_array($obj, $tempArray))
                    array_push($tempArray, $obj);
                else
                    unset($response[$key]);
            }
        }
        return $response;
    }

    /**
	 * Function to filter the data based on module
	 */
	public function filterByModule($response = array()) {
        $result = array();
        if(empty($response)){
            return $result;
        }
        
        $this->moduleName = $this->getModuleName();
        $response = $this->orderByModule($response);
        if(!empty($response)){
            foreach($response as $key => $val){
                if($key == $this->moduleName){
                    $result = $val;
                    break;
                }
            }
        }
        
        return $result;
    }
    
    /**
	 * Function to fetch module name
	 */
	public function getModuleName() {
        switch($this->moduleNum){
            case '1':
                $this->moduleName = "mapSummaryAdultTrtmnt";
                break;
            case '2':
                $this->moduleName = "mapSummaryLarvalTrtmnt";
                break;
            case '3':
                $this->moduleName = "mapSummaryLanding";
                break;
            case '4':
                $this->moduleName = "mapSummaryWA";
                break;
            case '5':
                $this->moduleName = "mapSummaryRainfall";
                break;
            case '6':
                $this->moduleName = "mapSummaryAdultSurv";
                break;
            case '7':
                $this->moduleName = "mapSummaryLarvalSurv";
                break;
            case '8':
                $this->moduleName = "mapSummaryArboviral";
                break;
            case '9':
                $this->moduleName = "mapSummaryCorvid";
                break;
            case '10':
                $this->moduleName = "mapSummarySentinelLab";
                break;
        }
        return $this->moduleName;
    }
    
    /**
	 * Function to fetch all site based on module
	 */
	public function getAllEventsData() {
        $response = array();
        $response = $this->CI->Carbo_model->get_all_module_ids($this->idsite);
        $response = $this->orderByModule($response);
        return $response;
    }
    
    /**
	 * Function to order the data based on module
	 */
	public function orderByModule($response = array()) {
        if(empty($response)){
            return array();
        }
        
        $result = array();
        $result['adlttrtmnt'] = array();
        $result['lrvltrtmnt'] = array();
        $result['adultsurveillance'] = array();
        $result['larvalsurveillance'] = array();
        $result['landingrates'] = array();
        $result['rainfall'] = array();
        $result['workassgnmnts'] = array();      
        $result['arboviral'] = array();
        $result['corvid'] = array();
        $result['sentinellab'] = array();
        
        foreach($response as $key => $val){
            switch($val->module){
                case 'adlttrtmnt':
                    array_push($result['adlttrtmnt'], $val->id);
                    break;
                case 'lrvltrtmnt':
                    array_push($result['lrvltrtmnt'], $val->id);
                    break;
                case 'adultsurveillance':
                    array_push($result['adultsurveillance'], $val->id);
                    break;
                case 'larvalsurveillance':
                    array_push($result['larvalsurveillance'], $val->id);
                    break;
                case 'landingrates':
                    array_push($result['landingrates'], $val->id);
                    break;
                case 'rainfall':
                    array_push($result['rainfall'], $val->id);
                    break;
                case 'workassgnmnts':
                    array_push($result['workassgnmnts'], $val->id);
                    break;
                case 'arboviral':
                    array_push($result['arboviral'], $val->id);
                    break;
                case 'corvid':
                    array_push($result['corvid'], $val->id);
                    break;
                case 'sentinellab':
                    array_push($result['sentinellab'], $val->id);
                    break;
            }
        }
        //echo '<pre>';
//        print_r($result);
//        die;
        $result = $this->getDataByModule($result);
        
        return $result;
    }
    
    /**
	 * Function to fetch the data based on module
	 */
	public function getDataByModule($response = array()) {
        $result = array();
        if(empty($response)){
            return $result;
        }
        
        $result['mapSummaryAdultTrtmnt'] = array();
        $result['mapSummaryLarvalTrtmnt'] = array();
        $result['mapSummaryAdultSurv'] = array();
        $result['mapSummaryLarvalSurv'] = array();
        $result['mapSummaryLanding'] = array();
        $result['mapSummaryRainfall'] = array();
        $result['mapSummaryWA'] = array();
        $result['mapSummaryArboviral'] = array();
        $result['mapSummaryCorvid'] = array();
        $result['mapSummarySentinelLab'] = array();
        
        //print'<pre>';
        //print_r($response);
        
        foreach($response as $key => $val) {
            switch($key){
                case 'adlttrtmnt':
                    if(!empty($val))
                        $result['mapSummaryAdultTrtmnt'] = $this->CI->treatment_model->listTreatment($val, "adult", $this->idsite, '1');
                    break;
                case 'lrvltrtmnt':
                    if(!empty($val))
                        $result['mapSummaryLarvalTrtmnt'] = $this->CI->treatment_model->listTreatment($val, "larval", $this->idsite, '1');
                    break;
                case 'adultsurveillance':
                    if(!empty($val))
                        $result['mapSummaryAdultSurv'] = $this->CI->adultsurveillance_model->listAdultsurveillances($val, $this->idsite);
                    break;
                case 'larvalsurveillance':
                    if(!empty($val))
                        $result['mapSummaryLarvalSurv'] = $this->CI->larvalsurveillance_model->listLarvalsurveillances($val, $this->idsite);
                    break;
                case 'landingrates':
                    if(!empty($val))
                        $result['mapSummaryLanding'] = $this->CI->landingrate_model->listLandingRates($val, $this->idsite);
                    break;
                case 'rainfall':
                    if(!empty($val))
                        $result['mapSummaryRainfall'] = $this->CI->weather_model->listWeather($val, $this->idsite);
                    break;
                case 'workassgnmnts':
                    if(!empty($val))
                        $result['mapSummaryWA'] = $this->CI->service_requestmodel->listServiceRequest($val, $this->idsite);
                    break;
                case 'arboviral':
                    if(!empty($val))
                        $result['mapSummaryArboviral'] = $this->CI->arbovirallab_model->listArbovirallabs($val, $this->idsite);
                    break;
                case 'corvid':
                    if(!empty($val))
                        $result['mapSummaryCorvid'] = $this->CI->corvidlab_model->listCorvidlabs($val, $this->idsite);
                    break;
                case 'sentinellab':
                    if(!empty($val))
                        $result['mapSummarySentinelLab'] = $this->CI->sentinelChickenlab_model->listSentinelChickenlabs($val, $this->idsite);
                    break;
            }
        }
        //print_r($result);
//        die;
        return $result;
    }
}