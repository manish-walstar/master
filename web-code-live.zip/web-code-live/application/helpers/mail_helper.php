<?php

/**
 * @author Skysoft Incorporated
 * @copyright 2014
 */

if ( ! defined('BASEPATH')) exit('No direct script access allowed');


function sendlocalmail($to, $subject, $message, $name  ) {
    require_once('phpmail/class.phpmailer.php');
    
    $mail             = new PHPMailer();
    
    $body = $message;
    //$body = preg_replace("[\]",'',$body);
    $mail->IsSMTP(); // telling the class to use SMTP
    $mail->Host       = "mail.google.com"; // SMTP server
    $mail->SMTPDebug  = 0;                     // enables SMTP debug information (for testing)
                                           // 1 = errors and messages
                                           // 2 = messages only
    $mail->SMTPAuth   = true;                  // enable SMTP authentication
    $mail->SMTPSecure = "tls";                 // sets the prefix to the servier
    $mail->Host       = "smtp.gmail.com";      // sets GMAIL as the SMTP server
    $mail->Port       = 587;                   // set the SMTP port for the GMAIL server
    $mail->Username   = "amir.khan_c@proptiger.com";  // GMAIL username
    $mail->Password   = "amirkhan123";            // GMAIL password
    
    $mail->SetFrom('amir.khan_c@proptiger.com', $name);
    
    $mail->AddReplyTo("amir.khan_c@proptiger.com","Amir Khan");
    
    $mail->Subject    = $subject;
    
    $mail->AltBody    = "To view the message, please use an HTML compatible email viewer!"; // optional, comment out and test
    
    $mail->MsgHTML($body);
    
    $address = $to;
    $mail->AddAddress($address, "Amir Khan");
    
    //$mail->AddAttachment("images/phpmailer.gif");      // attachment
    //$mail->AddAttachment("images/phpmailer_mini.gif"); // attachment
    
    if(!$mail->Send()) {
    //echo "Mailer Error: " . $mail->ErrorInfo;
        return false;
    } 
    
    return true;

}
    

