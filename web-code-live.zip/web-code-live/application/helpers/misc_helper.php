<?php

if (!defined('BASEPATH'))
exit('No direct script access allowed');

function getBrowser($browser)
{
	$get = get_browser();
	if (!empty($browser) && $browser == $get->browser) 
		return true;
	else
		return false;
}

function get_browser_name()
{
    $user_agent = $_SERVER['HTTP_USER_AGENT'];    
    if (strpos($user_agent, 'Opera') || strpos($user_agent, 'OPR/')) return 'Opera';
    elseif (strpos($user_agent, 'Edge')) return 'Edge';
    elseif (strpos($user_agent, 'Chrome')) return 'Chrome';
    elseif (strpos($user_agent, 'Safari')) return 'Safari';
    elseif (strpos($user_agent, 'Firefox')) return 'Firefox';
    elseif (strpos($user_agent, 'MSIE') || strpos($user_agent, 'Trident/7')) return 'IE';
    
    return 'Other';
}

function postCurl($url, $postData)
{
	if (empty($postData) || empty($url))
		return null;

	$ch = curl_init();
	curl_setopt($ch, CURLOPT_URL, $url);
	curl_setopt($ch, CURLOPT_POST, 1);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $postData);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
	// print_r(curl_error($ch));
	$error = curl_error($ch);
	$response = curl_exec($ch);
	//$headers = curl_getinfo($ch);
	curl_close($ch);
	return $response;
	
}

function redirectUrl($url, $formAction){
    if(empty($url)) {
        return base_url();
    }
    
    $urlStatus = 'redirect';
    
    $urlData = explode("#", $url);
    $firstPartUrl = !empty($urlData) && isset($urlData[0]) ? $urlData[0] : '';
    $secondPartUrl = !empty($urlData) && isset($urlData[1]) ? $urlData[1] : '';
    //echo $url."<br>";
    preg_match('/(http|https)\:\/\/(.*)\?msg\=(.*)\#/', $url, $matches);
   	$urlData = getStatusAndFirstPartOfUrl($url, $firstPartUrl, $formAction, $matches);
    $firstPartUrl = $urlData[0];
	$status = $urlData[1];
    //echo $firstPartUrl."<br>".$status."<br>";
    $tempUrl = generateFinalUrl($firstPartUrl, $status, $secondPartUrl);
    //echo $tempUrl."<br>";
	if($url == $tempUrl && !empty($matches))
		$urlStatus = 'reload';	
    //echo $urlStatus;die;
	$response = array($tempUrl, $urlStatus);
	return $response;
}

function getStatusAndFirstPartOfUrl($url, $firstPartUrl, $formAction, $matches){
    $status = "";
    if(!empty($firstPartUrl) && !empty($formAction)) {
        switch($formAction){
            case 'success' :
                if(!empty($matches) && isset($matches[3])) {
                    $firstPartUrl = isset($matches[2]) && !empty($matches[2]) ? $matches[1]."://".$matches[2] : $firstPartUrl;
                    $status = 'success';
                }
				break;
    		case 'update' :
                if(!empty($matches) && isset($matches[3])) {
                    $firstPartUrl = isset($matches[2]) && !empty($matches[2]) ? $matches[1]."://".$matches[2] : $firstPartUrl;
                    $status = 'update';
                }
                break;
        }
        if($formAction != $status) {
    		$status = $formAction;  
    	}
    }
	
	return array($firstPartUrl, $status);
}


function generateFinalUrl($firstPartUrl, $status, $secondPartUrl){
    $tempUrl = "";
    if(!empty($secondPartUrl))
		$tempUrl = $firstPartUrl . '?msg=' . $status . '#' . $secondPartUrl;
	else
		$tempUrl = $firstPartUrl . '?msg=' . $status;	
	return $tempUrl;
}

function encryptStr($param = ''){
    if(empty($param)) {
        return null;
    }
    return base64_encode($param);
}


