<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');
if (!function_exists('create_pdf')) {

    function create_pdf($html_data, $file_name = "") {
        if ($file_name == "") {
            $file_name = 'report' . date('dMY');
        }
        
        require 'mpdf/mpdf.php';
        $mypdf = new mPDF();
       
        $mypdf->WriteHTML($html_data);
        
        $mypdf->Output($file_name, 'D');
    }
    
    function create_pdf_l($html_data, $file_name = "") {
        if ($file_name == "") {
            $file_name = 'report' . date('dMY');
        }
        
        require 'mpdf/mpdf.php';
        $mypdf = new mPDF();
        $mypdf->AddPage('L', // L - landscape, P - portrait
            '', '', '', '',
            10, // margin_left
            10, // margin right
            10, // margin top
            10, // margin bottom
            5, // margin header
            5); // margin footer
        $mypdf->WriteHTML($html_data);
        
        $mypdf->Output($file_name . 'pdf', 'D');
    }
    
    function return_pdf($html_data, $file_name = "") {
        if ($file_name == "") {
            $file_name = 'report' . date('dMY');
        }
        require 'mpdf/mpdf.php';
        $mypdf = new mPDF();
        $mypdf->WriteHTML($html_data);
        $mypdf->Output($file_name . 'pdf', 'F');
    }

}