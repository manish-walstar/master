<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Product_overview extends CI_Controller {
	
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public $idlocation = "";
	public function __construct() {
		parent::__construct ();
		
        $this->load->helper('language');
		$this->load->model ( 'product_model' );
		$this->load->model ( 'usermodel' );
		$this->load->model ( 'treatment_model' );
        
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		if ($this->session->userdata ( 'logged_in' )) {
			$this->idlocation = $this->session->userdata ( 'idlocation' );
		}
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			redirect ( base_url () . "product_overview/getproduct" );
		}
	}
	
	/**
	 * Function to display List Of Products
	 */
	public function getproduct($grid = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$columns = array (
					0 => array (
							'name' => $this->lang->line('prdct_ovrvw_nme'),
							'db_name' => 'productname',
							'header' => $this->lang->line('prdct_ovrvw_nme'),
							'group' => $this->lang->line('hm_prdct'),
							'required' => TRUE,
							'unique' => TRUE,
							'form_control' => 'text_long',
							'type' => 'string' 
					),
					1 => array (
							'name' => $this->lang->line('prdct_ovrvw_ptncy'),
							'db_name' => 'idpotency',
							'header' => $this->lang->line('prdct_ovrvw_ptncy'),
							'group' => $this->lang->line('hm_prdct'),
							'allow_filter' => TRUE,
							'ref_table_id_name' => 'idpotency',
							'ref_table_db_name' => 'productpotency',
							'ref_field_db_name' => 'potency',
							'ref_field_type' => 'int',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-n' 
					),
					2 => array (
							'name' => $this->lang->line('prdct_ovrvw_mnfctrr'),
							'db_name' => 'idmanufacturer',
							'header' => $this->lang->line('prdct_ovrvw_mnfctrr'),
							'group' => $this->lang->line('hm_prdct'),
							'ref_table_id_name' => 'idmanufacturer',
							'ref_table_db_name' => 'productmanufacturers',
							'ref_field_db_name' => 'manufacturer',
							'ref_field_type' => 'string',
							'required' => TRUE,
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-n' 
					),
					3 => array (
							'name' => $this->lang->line('prdct_ovrvw_prdct_sze'),
							'db_name' => 'idproductsize',
							'header' => $this->lang->line('prdct_ovrvw_prdct_sze'),
							'group' => $this->lang->line('hm_prdct'),
							'ref_table_id_name' => 'idproductsize',
							'ref_table_db_name' => 'productsizes',
							'ref_field_db_name' => 'productsize',
							'ref_field_type' => 'string',
							'required' => TRUE,
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-n' 
					),
					4 => array (
							'name' => $this->lang->line('prdct_ovrvw_pck_sze'),
							'db_name' => 'idpacksize',
							'header' => $this->lang->line('prdct_ovrvw_pck_sze'),
							'group' => $this->lang->line('hm_prdct'),
							'ref_table_id_name' => 'idpacksize',
							'ref_table_db_name' => 'packsizes',
							'ref_field_db_name' => 'packsize',
							'ref_field_type' => 'string',
							'required' => TRUE,
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-n' 
					),
					5 => array (
							'name' => $this->lang->line('prdct_ovrvw_on_hnd'),
							'db_name' => 'onhand',
							'header' => $this->lang->line('prdct_ovrvw_on_hnd'),
							'group' => $this->lang->line('hm_prdct'),
							'required' => TRUE,
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => 'string' 
					) 
			)
			;
			
			$commands ['delete'] ['toolbar'] = FALSE;
			$add_view = $this->load->view ( 'product_overview/view_product', '', true );
			$edit_view = $this->load->view ( 'product_overview/adjust_inventory', '', true );
			$params = array (
					'id' => 'idproduct',
					'table' => 'products',
					'url' => 'product_overview/getproduct',
					'uri_param' => $grid,
					'columns' => $columns,
					'order' => array (
							0 => 'asc' 
					),
					// 'columns_visible' => array(0,1,2,3,4),
					'filters' => array (
							0 => array (
									'value' => $this->idlocation 
							) 
					),
					'commands' => $commands,
					'ajax' => TRUE,
					'msc_url' => array (
							'excel_url' => base_url () . 'product_overview/toExcelAll',
							'pdf_url' => base_url () . 'product_overview/toPdfAll',
							'text' => 'ProductOverview' 
					),
					'add_view' => $add_view,
					'edit_view' => $edit_view 
			);
			
			$newdata = array (
					'url' => base_url () . $params ['url'] . '#' . $params ['id'] . '=' . $grid 
			);
			
			$this->session->set_userdata ( $newdata );
			
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
                    'page' => "product_overview",
					'title' => $this->lang->line('sidebar_mntnc_prdct_ovrvw'),
                    'app_lang' => $this->app_lang
			);
			$this->load->view ( 'header', $data_1 );

			$this->load->view ( 'left_sidebar', $data_1 );
			// Pass grid to the view
            $data = (object)array();
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			 $data->app_lang = $this->app_lang;
			// echo $data->total;
			// die;
			$this->load->view ( 'product_overview/product_overview', $data );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function toExcelAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$query ['data'] = $this->product_model->listProducts ();
			
			$this->load->view ( 'product_overview/excel_view', $query );
		}
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->helper ( 'pdf_helper' ); // Load helper
			$query ['data'] = $this->product_model->listProducts ();
			
			$data = $this->load->view ( 'product_overview/pdf_view', $query, true );
			// $data = file_get_contents("$data"); // Pass the url of html report
			create_pdf ( $data, $this->lang->line('hm_prdct') ); // Create pdf
		}
	}
	// code for view product
	public function viewproduct($id = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			
			redirect ( base_url () );
		} else {
			
			$id = $this->input->get_post ( 'id' );
			if (empty ( $id )) {
				echo "Some thing went wrong";
				exit ();
			}
			$flag = $this->product_model->viewProduct ( $id );
			$data = array ();
			if (! empty ( $flag )) {
				$data ['productname'] = $flag ['productname'];
				$data ['productcode'] = $flag ['productcode'];
				$data ['upccode'] = $flag ['upccode'];
				$data ['eparegistration'] = $flag ['eparegistration'];
				
				if (! empty ( $flag ['productlink'] ) && preg_match ( '/^www/', $flag ['productlink'], $matches ))
					$flag ['productlink'] = "http://" . $flag ['productlink'];
					
					// echo $flag['productlink'];
					// die;
				$data ['productid'] = $id;
				$data ['productlink'] = $flag ['productlink'];
				$data ['idcategory'] = $this->product_model->getProductCategory ( $flag ['idcategory'] );
				$data ['idpotency'] = $this->product_model->getProductPotency ( $flag ['idpotency'] );
				$data ['idformulation'] = $this->product_model->getProductFormulation ( $flag ['idformulation'] );
				$data ['idmanufacturer'] = $this->product_model->getProductManufacturer ( $flag ['idmanufacturer'] );
				$data ['idpacksize'] = $this->product_model->getProductPacksize ( $flag ['idpacksize'] );
				$data ['idproductsize'] = $this->product_model->getProductProductsize ( $flag ['idproductsize'] );
				$data ['productcost'] = $flag ['productcost'];
				$data ['iduomproductcost'] = $this->product_model->getProductCost ( $flag ['iduomproductcost'] );
				
				$data ['productpref'] = $this->product_model->getProductPref ( $id );
				$data ['uomfinishedmix'] = $this->product_model->getProductUnits ();
				$data ['uomtotalareatreated'] = $this->product_model->getproductTAreaTreated ();
				$data['app_lang'] = $this->app_lang;
			}
			$data['app_lang'] = $this->app_lang;
			$this->load->view ( 'product_overview/view_product', $data );
			// echo '<pre>';print_r($data);
			// die;
		}
	}
	
	// code for adjust inventory
	public function adjustinventory($id = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$id = $this->input->get_post ( 'id' );
			if (empty ( $id )) {
				echo $this->lang->line('err_msg_smthng_went_wrng');
				exit ();
			}
			
			$flag = $this->product_model->viewAdjustInventory ( $id );
			$prdct_history = $this->product_model->getProductHistory ( $id );
			
			if (empty ( $flag )) {
				$flag = array (
						'idproduct' => $id 
				);
			}
			
			$flag ['history'] = $prdct_history;
			$flag['app_lang'] = $this->app_lang;
			$this->load->view ( 'product_overview/adjust_inventory', $flag );
		}
	}
	public function saveadjustinventory($id = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$id = $this->input->get_post ( 'idproduct' );
			$data = $this->product_model->viewAdjustInventory ( $id );
			
			if (empty ( $id )) {
				$data ['msg'] = "error";
				$this->load->view ( 'product_overview/adjust_inventory', $data );
				exit ();
			}
			$data ['idproduct'] = $id;
			$this->form_validation->set_rules ( 'idtype', $this->lang->line('prdct_ovrvw_adjstmnt_type'), 'trim|required' );
			$this->form_validation->set_rules ( 'adjustamount', $this->lang->line('prdct_ovrvw_adjstmnt_amt'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'min_amount', $this->lang->line('prdct_ovrvw_minm_amt'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'max_amount', $this->lang->line('prdct_ovrvw_max_amt'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'notes', $this->lang->line('prdct_ovrvw_notes'), 'trim' );
			
			if ($this->form_validation->run () == FALSE) {
				$data ['msg'] = "error";
			} else {
				$id = json_decode ( base64_decode ( $this->session->userdata ( 'id' ) ) );
				$id_arr = explode ( "_", $id );
				$id = json_decode ( base64_decode ( $id_arr [0] ) );
				
				$userdet = $this->usermodel->getUserData ( $id );
				
				$flag = $this->product_model->saveAdjustInventory ( $userdet );
				
				if (! empty ( $flag ))
					$data ['msg'] = "success";
				else
					$data ['msg'] = "error";
			}
			$data['app_lang'] = $this->app_lang;
			$this->load->view ( 'product_overview/adjust_inventory', $data );
		}
	}
	
	/**
	 * Function to add Product Pref options
	 */
	public function addproductpref() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			if (! empty ( $_POST ['ratename'] )) {
				if ($this->input->get_post ( 'idproductpreference' )) {
					$flag = $this->product_model->updateProductpref ( $_POST );
					$data ['msg'] = "update";
				} else {
					$flag = $this->product_model->saveProductpref ( $_POST );
					$data ['msg'] = "success";
				}
				
				if (empty ( $flag ))
					$data ['msg'] = "error";
				$data['app_lang'] = $this->app_lang;
				$this->load->view ( 'product_overview/view_product', $data );
			}
		}
	}
	
	/**
	 * Function to fetch product prefernce
	 */
	public function getProductPreferences() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$idproduct = $this->input->post ( 'idproduct' );
			
			if (! empty ( $idproduct )) {
				$data = $this->product_model->getProductPref ( $idproduct );
				// print'<pre>';
				// print_r($data);
				// die;
				echo json_encode ( $data );
				exit ();
			} else {
				echo "error";
				exit ();
			}
		}
	}
}

/* End of file product_overview.php */
/* Location: ./application/controllers/product_overview.php */