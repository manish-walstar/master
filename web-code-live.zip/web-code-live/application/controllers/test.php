<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
header ( 'Access-Control-Allow-Origin: *' );
error_reporting ( - 1 );
class test extends CI_Controller {
function __construct() { 
         parent::__construct(); 
         $this->load->helper('url'); 
         $this->load->database(); 
      } 
  

	public function index (){
$this->load->helper ( 'pdf_helper' ); // Load helper
$query = $this->db->where('idoutfallinspection','58');
  $query = $this->db->get("outfallinspection"); 
         $data['records'] = $query->result(); 
			
         $this->load->helper('url'); 
      $data = $this->load->view ( 'test', $data, true );
create_pdf ( $data, 'Weather Outfall Inspection' ); // Create pdf
		}
	}





