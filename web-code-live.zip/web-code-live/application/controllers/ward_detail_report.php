<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Ward_Detail_Report extends CI_Controller {
  public $startdate;
	public $starttime;
	public $enddate;
	public $endtime;
	public $currentdate;
	public $currenttime;
	public $endtimestamp;
	public $starttimestamp;
	public $userinfo;
	public $app_lang;
  
  public function __construct() {
		parent::__construct ();
		$this->load->helper('language');
		$this->load->model('ward_report_model');
		$this->load->model('usermodel');
		$this->currentdate = date('m/d/Y');
		$this->currenttime = date("h:i:s a");
		
		$this->usermodel->set_access_session();
		
		if (!$this->usermodel->user_access('reports') && ! $this->usermodel->user_access('company_admin'))
			redirect(base_url());
		
		$this->app_lang = $this->session->userdata('app_lang');
		$this->lang->load("app", $this->app_lang); 
		$this->enddate = date('m/d/Y');
		$this->endtime = date('h:i:s');
		
		$this->startdate = date('Y-m-d');
		$this->starttime = date('h:i:s');
		
		$this->endtimestamp = strtotime(date('m/d/Y H:i:s'));
		
		$this->starttimestamp = strtotime(date('m/d/Y H:i:s', strtotime("-10 day")));

		if ($this->session->userdata('id'))
		{		 
			$id = $this->session->userdata('id');
			$id_arr = explode("_", json_decode(base64_decode($id)));			
			$id = json_decode(base64_decode($id_arr[0]));			
			$this->userinfo = $this->usermodel->getUserData($id);			
			$middlename = " ";
			if (isset($this->userinfo['middlename']))
				$middlename = !empty($this->userinfo['middlename']) ? " " . $this->userinfo['middlename'] . " " : " ";
			
			if (isset($this->userinfo['firstname']) || isset($this->userinfo['lastname']))
				$this->inspector = $this->userinfo['firstname'] . $middlename . $this->userinfo['lastname'];
			
		}
	}
  
  public function index() {
    if (!$this->session->userdata('logged_in')) {
			redirect(base_url());
		}
		else if($this->session->userdata('idlocation') != '57') {
			redirect(base_url());
		}
    else {
      redirect(base_url()."ward_detail_report/getreport");
    }
  }
  
  public function getreport() {
    if (!$this->session->userdata('logged_in')) {
			redirect(base_url());
		}
		else if($this->session->userdata('idlocation') != '57') {
			redirect(base_url());
		}
    else {
      $date = $this->input->post('date');
      $siteids = $this->input->post('siteids');
			
      $data = array();
			
			$loadFlag = false;
			
			if(empty($date) && empty($siteids)) $loadFlag = true;
      
      if(empty($date)) $date = date('m/d/Y');
      
      if(!empty($siteids)) 	$this->excludedSites = explode(',', $siteids);
			else $this->excludedSites = array();
      
      $result = array();
      $result = $this->ward_report_model->getReport($date, $this->excludedSites, $loadFlag);
			
			$data_1 = array (
				'username' => $this->session->userdata('username'),
				'logstatus' => "logout",
				'title' => 'Ward Detail Report',
				'page' => "ward_detail_report",
				'date' => $date,
				'data' => $result,
				'loadFlag' => $loadFlag
			);
			
			$this->load->view('header', $data_1);
			$this->load->view('left_sidebar', $data_1);
			$this->load->view('ward_detail_report/ward_detail_reports', $data_1);
			$this->load->view('footer');
    }
  }
	
	public function toPDFAll() {
		if (!$this->session->userdata('logged_in')) {
			redirect(base_url());
		}
		else if($this->session->userdata('idlocation') != '57') {
			redirect(base_url());
		}
		else {
			$this->load->helper ('pdf_helper');
			$data = $this->exportView();

			create_pdf_l($data, 'Ward Detail Report');
		}
	}
	
	public function exportView() {
		if (!$this->session->userdata('logged_in')) {
			redirect(base_url());
		}
		else if($this->session->userdata('idlocation') != '57') {
			redirect(base_url());
		}
    else {
      $date = $this->input->post('date');
      $siteids = $this->input->post('siteids');
			
      $data = array();
			
			$loadFlag = false;
			
			if(empty($date) && empty($siteids)) $loadFlag = true;
      
      if(empty($date)) $date = date('m/d/Y');
      
      if(!empty($siteids)) 	$this->excludedSites = explode(',', $siteids);
			else $this->excludedSites = array();
      
      $result = array();
      $result = $this->ward_report_model->getReport($date, $this->excludedSites, $loadFlag);
			
			$data_1 = array (
				'username' => $this->session->userdata('username'),
				'logstatus' => "logout",
				'title' => 'Ward Detail Report',
				'page' => "ward_detail_report",
				'date' => $date,
				'data' => $result,
				'loadFlag' => $loadFlag
			);
			
			$viewData = $this->load->view('ward_detail_report/pdf_view', $data_1, TRUE);
			
			return $viewData;
		}
	}
  
}