<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Trap extends CI_Controller {
	public $site_type = "";
	public $s_site_type = "";
	public $existing_site = "";
	public $s_existing_site = "";
	public $trap_type = "";
	public $s_trap_type = "";
	public $zones = "";
	public $s_zones = "";
	public $states = "";
	public $s_states = "";
	public $state_list = "";
	public $s_sites = "";
	public $statuses;
	public $idlocation = "";
	public $baittype;
	public $sitegroup = "";
	
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		
        $this->load->helper('language');
        $this->load->helper('misc');
		$this->load->model ( 'trap_model' );
		$this->load->model ( 'site_model' );
		$this->load->model ( 'treatment_model' );
		$this->load->model ( 'adultsurveillance_model' );
		$this->trap_type = $this->trap_model->getTraptypes ();
		$this->zones = $this->site_model->getZones ();
		$this->states = $this->site_model->getStates ();
		$this->site_type = $this->site_model->getSitetypes ();
		$this->existing_site = $this->site_model->getExisting_site ();
		$this->state_list = $this->site_model->getStatesList ();
		$this->statuses = $this->trap_model->getStatuses ();
		$this->iduomwatersize = $this->treatment_model->getTAreaTreated ();
		$this->baittype = $this->trap_model->getBaitType ();
		$this->sitegroup = $this->site_model->getSiteGroup ();
		
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		if ($this->session->userdata ( 'logged_in' )) {
			$this->idlocation = $this->session->userdata ( 'idlocation' );
		}
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			redirect ( base_url () . "trap/gettrap" );
		}
	}
	
	/**
	 * Function to add a new trap
	 */
	public function addtrap() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data = array (
					'site_type' => $this->site_type,
					'zones' => $this->zones,
					'states' => $this->states,
					'state_list' => $this->state_list,
					'trap_type' => $this->trap_type,
					'existing_site' => $this->existing_site,
					'sitegroup' => $this->sitegroup,
					'baittype' => $this->baittype,
                    'app_lang' => $this->app_lang 
			);
			
			$this->form_validation->set_rules ( 'trap_name', $this->lang->line('trap_mgmt_trap_nme'), 'trim|required|callback_trapCheck|xss_clean' );
			$this->form_validation->set_rules ( 'trap_type', $this->lang->line('trap_mgmt_trap_type'), 'trim|required' );
			$this->form_validation->set_rules ( 'site_name', $this->lang->line('whthr_snsr_site_nm'), 'trim|required' );
			$this->form_validation->set_rules ( 'site_type', $this->lang->line('trap_mgmt_site_type'), 'trim' );
			$this->form_validation->set_rules ( 'maplabel', $this->lang->line('site_mgmt_map_lbl'), 'trim' );
			$this->form_validation->set_rules ( 'street1', $this->lang->line('site_mgmt_street') . ' I', 'trim' );
			$this->form_validation->set_rules ( 'street2', $this->lang->line('site_mgmt_street') . ' II', 'trim' );
			$this->form_validation->set_rules ( 'city', $this->lang->line('site_mgmt_cty'), 'trim' );
			$this->form_validation->set_rules ( 'postal_code', $this->lang->line('site_mgmt_postl_cde'), 'trim' );
			$this->form_validation->set_rules ( 'latitude', $this->lang->line('site_mgmt_lat'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'longitude', $this->lang->line('site_mgmt_lng'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'zone', $this->lang->line('site_mgmt_zone'), 'trim' );
			$this->form_validation->set_rules ( 'active', $this->lang->line('trap_mgmt_active'), 'trim' );
			if ($this->form_validation->run () == FALSE) {
				$data['msg'] = "error";
			} else {
				$flag = $this->trap_model->addTrap ();
				
				if (! empty ( $flag )) {
					$data ['msg'] = "success";
                    $url = $this->session->userdata('url');
                    $urlData = redirectUrl($url, $data ['msg']);
                    $data ['url'] = $urlData[0];
                	$data ['urlStatus'] = $urlData[1];
                    $this->setUrl($urlData[0]);
				} else {
					$data ['msg'] = "error";
				}
				
				$this->load->view ( 'traps/add_trap', $data );
			}
		}
	}
	
	/**
	 * Add Shadowbox Popup
	 */
	public function addtrapview() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data = array (
					'site_type' => $this->site_type,
					'zones' => $this->zones,
					'states' => $this->states,
					'state_list' => $this->state_list,
					'trap_type' => $this->trap_type,
					'existing_site' => $this->existing_site,
					'sitegroup' => $this->sitegroup,
					'baittype' => $this->baittype,
                    'app_lang' => $this->app_lang 
			);
			$this->load->view ( 'traps/add_trap', $data );
		}
	}
	
	/*
	 * ADD NEW SITE FORM VIEW
	 */
	public function addsiteview() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->site_type = $this->site_model->getSitetypes ();
			$this->zones = $this->site_model->getZones ();
			$this->states = $this->site_model->getStates ();
			$this->state_list = $this->site_model->getStatesList ();
			$this->statuses = $this->site_model->getStatuses ();
			$address = $this->input->get ( 'address', TRUE );
			$cross_street = $this->input->get ( 'cross_street', TRUE );
			$city = $this->input->get ( 'city', TRUE );
			$mainphone = $this->input->get ( 'mainphone', TRUE );
			$latitude = $this->input->get ( 'latitude', TRUE );
			$longitude = $this->input->get ( 'longitude', TRUE );
			
			$data = array (
					'site_type' => $this->site_type,
					'zones' => $this->zones,
					'states' => $this->states,
					'state_list' => $this->state_list,
					'iduomwatersize' => $this->iduomwatersize,
					'googlezoom' => $this->session->userdata ( 'googlezoom' ),
					'sitegroup' => $this->sitegroup,
					'user_loc' => $this->adultsurveillance_model->getUserLoc (),
					'address' => $address,
					'cross_street' => $cross_street,
					'city' => $city,
					'mainphone' => $mainphone,
					'latitude' => $latitude,
					'longitude' => $longitude,
                    'app_lang' => $this->app_lang 
			);
			
			$this->load->view ( 'traps/add_site', $data );
		}
	}
	
	/**
	 */
	public function edittrapview() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$req = $this->input->get_post ( 'id' );
			
			$flag = $this->trap_model->getTrapData ( $req );
			$site_data = $this->site_model->getSiteData ( $flag ['idsite'] );
            
            $this->s_zones = $this->trap_model->getSelectedZones ( $site_data ['idzone'] );
			$this->s_sites = $this->site_model->getSelectedExistingSite ( $flag ['idsite'] );
			if ($flag) {
				$data = array (
                        's_sites' => $this->s_sites,
						'site_type' => $this->site_type,
						'zones' => $this->s_zones,
						'states' => $this->states,
						'trap_type' => $this->trap_type,
						'baittype' => $this->baittype,
						'trap_detail' => $flag,
						'state_list' => $this->state_list,
						'idsitetype' => $site_data ['idsitetype'],
						'idtraptype' => $flag ['idtraptype'],
						'idbaittype' => $flag ['idbaittype'],
						'latitude' => $flag ['latitude'],
						'longitude' => $flag ['longitude'],
                        'city' => $site_data ['city'],
                        'address1' => $site_data ['address1'],
                        'address2' => $site_data ['address2'],
                        'postalcode' => $site_data ['postalcode'],
                        'maplabel' => $site_data ['maplabel'],
                        'site' => $site_data ['site'],
                        'idstate' => $site_data ['idstate'],
                        'app_lang' => $this->app_lang
				);
				
				 //print'<pre>';
//				 print_r($data);
//				 die;
			}
			$this->load->view ( 'traps/edit_trap', $data );
		}
	}
	
	/**
	 * Function to check trap name existence
	 */
	public function trapCheck($str = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$str = $this->input->post ( 'trap_name' );
			
			$flag = $this->trap_model->trapExist ( $str );
			
			if ($flag) {
				$this->form_validation->set_message ( 'trapCheck', $this->lang->line('err_msg_trap_alrdy_exsts') );
				return false;
			} else {
				return true;
			}
		}
	}
	
	/**
	 * Function to get log and lat
	 */
	public function getLatiLongi() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data = array (
					'states' => $this->states 
			);
			
			$this->load->view ( 'traps/lati_longi', $data );
		}
	}
	
	/*
	 * Function to show map
	 */
	public function showmap() {
		$this->load->view ( 'traps/map' );
	}
	
	/**
	 * Function to get lati longi of map
	 */
	public function getmap() {
		$street = $this->input->post ( 'street_addr' );
		$street1 = $this->input->post ( 'street_addr1' );
		$city = $this->input->post ( 'city' );
		$state = $this->input->post ( 'state' );
		$postal_code = $this->input->post ( 'postal_code' );
		
		getMapData ( $street, $street1, $city, $state, $postal_code );
	}
	
	/**
	 * Function to save edit trap Values
	 */
	public function updatetrap() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data = array ();
			$req = $this->input->get_post ( 'idtrap' );
			if (empty ( $req )) {
				$data ['msg'] = "error";
				$this->load->view ( 'traps/edit_trap', $data );
			}
			
			$flag = $this->trap_model->getTrapData ( $req );
			$site_data = $this->site_model->getSiteData ( $flag ['idsite'] );
            $this->s_zones = $this->trap_model->getSelectedZones ( $site_data ['idzone'] );
			$this->s_sites = $this->site_model->getSelectedExistingSite ( $flag ['idsite'] );
			if ($flag) {
				$data = array (
                        's_sites' => $this->s_sites,
						'site_type' => $this->site_type,
						'zones' => $this->s_zones,
						'states' => $this->states,
						'trap_type' => $this->trap_type,
						'baittype' => $this->baittype,
						'trap_detail' => $flag,
						'state_list' => $this->state_list,
						'idsitetype' => $site_data ['idsitetype'],
						'idtraptype' => $flag ['idtraptype'],
						'idbaittype' => $flag ['idbaittype'],
						'latitude' => $flag ['latitude'],
						'longitude' => $flag ['longitude'],
                        'city' => $site_data ['city'],
                        'address1' => $site_data ['address1'],
                        'address2' => $site_data ['address2'],
                        'postalcode' => $site_data ['postalcode'],
                        'maplabel' => $site_data ['maplabel'],
                        'site' => $site_data ['site'],
                        'idstate' => $site_data ['idstate'],
                        'app_lang' => $this->app_lang
				);
			}
            
			$this->form_validation->set_rules ( 'trap_name', $this->lang->line('trap_mgmt_trap_nme'), 'trim|required' );
			$this->form_validation->set_rules ( 'trap_type', $this->lang->line('trap_mgmt_trap_type'), 'trim|required' );
			$this->form_validation->set_rules ( 'existing_site', $this->lang->line('whthr_snsr_site'), 'trim' );
			$this->form_validation->set_rules ( 'site_name', $this->lang->line('whthr_snsr_site_nm'), 'trim|required' );
			$this->form_validation->set_rules ( 'site_type', $this->lang->line('trap_mgmt_site_type'), 'trim' );
			$this->form_validation->set_rules ( 'maplabel', $this->lang->line('site_mgmt_map_lbl'), 'trim' );
			$this->form_validation->set_rules ( 'street1', $this->lang->line('site_mgmt_street') . ' I', 'trim' );
			$this->form_validation->set_rules ( 'street2', $this->lang->line('site_mgmt_street') . ' II', 'trim' );
			$this->form_validation->set_rules ( 'city', $this->lang->line('site_mgmt_cty'), 'trim' );
			$this->form_validation->set_rules ( 'postalcode', $this->lang->line('site_mgmt_postl_cde'), 'trim' );
			$this->form_validation->set_rules ( 'latitude', $this->lang->line('site_mgmt_lat'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'longitude', $this->lang->line('site_mgmt_lng'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'zone', $this->lang->line('site_mgmt_zone'), 'trim' );
			$this->form_validation->set_rules ( 'active', $this->lang->line('trap_mgmt_active'), 'trim' );
			
			if ($this->form_validation->run () == FALSE) {
				$data ['msg'] = "error";
			} else {
				$flag = $this->trap_model->updateTrap ();
				
				if (! empty ( $flag )) {
					$data ['msg'] = "update";
                    $url = $this->session->userdata('url');
                    $urlData = redirectUrl($url, $data ['msg']);
                    $data ['url'] = $urlData[0];
                	$data ['urlStatus'] = $urlData[1];
                    $this->setUrl($urlData[0]);
				} else {
					$data ['msg'] = "error";
				}
			}
			
			$this->load->view ( 'traps/edit_trap', $data );
		}
	}
	
	/**
	 * Function to delete trap
	 */
	public function deletetrap() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->trap_model->deletetrap ();
			
			$msg = "";
			
			if ($flag)
				$msg = "success";
			else
				$msg = "error";
			
			$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
			if (! empty ( $seturl [1] ))
				redirect ( $seturl [0] . "?del=" . $msg . "#" . $seturl [1] );
			else
				redirect ( $seturl [0] . "?del=" . $msg );
			// redirect(base_url().'trap/gettrap?del='.$msg);
		}
	}
	
	/**
	 * Function to activate trap
	 */
	public function activetrap() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->trap_model->activetrap ();
			
			$msg = "";
			
			if ($flag)
				$msg = "activated";
			else
				$msg = "error";
			
			redirect ( base_url () . "trap/gettrap?msg=" . $msg );
		}
	}
	
	/**
	 * Function to deactivate trap
	 */
	public function deactivetrap() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->trap_model->deactivetrap ();
			
			$msg = "";
			
			if ($flag)
				$msg = "deactivated";
			else
				$msg = "error";
			
			redirect ( base_url () . "trap/gettrap?msg=" . $msg );
		}
	}
	
	/**
	 * Function to display List Of traps
	 */
	public function gettrap($grid = '', $msg = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$columns = array (
				0 => array (
					'name' => $this->lang->line('whthr_snsr_site_nm'),
					'db_name' => 'idsite',
					'header' => $this->lang->line('whthr_snsr_site_nm'),
					'group' => $this->lang->line('whthr_snsr_site'),
					'form_control' => 'text_long',
					'ref_table_id_name' => 'idsite',
					'ref_table_db_name' => 'sites',
					'ref_field_db_name' => 'site',
					'type' => '1-n' 
				),
				6 => array (
					'name' => $this->lang->line('trap_mgmt_trap_nme'),
					'db_name' => 'trap',
					'header' => $this->lang->line('trap_mgmt_trap_nme'),
					'group' => 'Trap',
					'required' => TRUE,
					'unique' => TRUE,
					'form_control' => 'text_long',
					'type' => 'string' 
				),
				1 => array (
					'name' => $this->lang->line('trap_mgmt_trap_type'),
					'db_name' => 'idtraptype',
					'header' => $this->lang->line('trap_mgmt_trap_type'),
					'group' => 'Trap',
					'ref_table_id_name' => 'idtraptype',
					'ref_table_db_name' => 'traptypes',
					'ref_field_db_name' => 'traptype',
					'required' => TRUE,
					'form_control' => 'text_long',
					'type' => '1-n' 
				),
				2 => array (
					'name' => $this->lang->line('site_mgmt_cty_state'),
					'db_name' => 'idsite',
					'header' => $this->lang->line('site_mgmt_cty_state'),
					'group' => 'Trap',
					'ref_table_id_name' => 'idsite',
					'ref_table_db_name' => 'sites',
					'ref_field_db_name' => 'city',
					'ref_table_1_id_name' => 'idstate',
					'ref_table_1_db_name' => 'states',
					'ref_field_1_db_name' => 'statename',
					'ref_field_type' => 'string',
					'form_control' => 'text_long',
					'type' => '1-1-(1)-(2)' 
				),
				3 => array (
					'name' => $this->lang->line('site_mgmt_lat'),
					'db_name' => 'latitude',
					'header' => $this->lang->line('site_mgmt_lat'),
					'group' => 'Trap',
					'form_control' => 'text_long' 
				),
				4 => array (
					'name' => $this->lang->line('site_mgmt_lng'),
					'db_name' => 'longitude',
					'header' => $this->lang->line('site_mgmt_lng'),
					'group' => 'Trap',
					'form_control' => 'text_long' 
				),
				5 => array (
					'name' => $this->lang->line('trap_mgmt_loc_type'),
					'db_name' => 'idsite',
					'header' => $this->lang->line('trap_mgmt_loc_type'),
					'form_control' => 'text_long',
					'ref_table_id_name' => 'idsite',
					'ref_table_db_name' => 'sites',
					'ref_field_db_name' => 'idsitetype',
					'ref_table_id2_name' => 'idsitetype',
					'ref_table_db2_name' => 'sitetypes',
					'ref_field_db2_name' => 'sitetype',
					'ref_field_type' => 'string',
					'group' => 'Trap',
					'type' => '1-1-1' 
				),
				7 => array (
					'name' => $this->lang->line('mmbr_mgmt_is_actv'),
					'db_name' => 'active',
					'header' => $this->lang->line('mmbr_mgmt_is_actv'),
					'group' => 'Trap',
					'form_control' => 'checkbox',
					'type' => 'string' 
				)	 
			);
			
			$commands ['delete'] ['toolbar'] = FALSE;
			
			$data_1 = array (
					'zones' => $this->zones,
					'trap_type' => $this->trap_type,
					'existing_site' => $this->existing_site,
					'site_type' => $this->site_type,
					'states' => $this->states,
					'state_list' => $this->state_list 
			);
			
			$add_view = $this->load->view ( 'traps/add_trap', $data_1, TRUE );
			
			$edit_view = $this->load->view ( 'traps/edit_trap', '', TRUE );
			
			$params = array (
					'id' => 'idtrap',
					'table' => 'traps',
					'url' => 'trap/gettrap',
					'uri_param' => $grid,
					'columns' => $columns,
					'order' => array (
							6 => 'asc' 
					),
					// 'columns_visible' => array(0,1,2),
					'filters' => array (
							6 => array (
									'value' => $this->idlocation 
							) 
					),
					'commands' => $commands,
					'ajax' => TRUE,
					'msc_url' => array (
							'excel_url' => base_url () . 'trap/toExcelAll',
							'pdf_url' => base_url () . 'trap/toPdfAll',
							'text' => 'Trap' 
					),
					'add_view' => $add_view,
					'edit_view' => $edit_view 
			);
			$url = $this->session->userdata ( 'url' );
            
            $newdata = array (
					'url' => base_url () . $params ['url'] . '#' . $params ['id'] . '=' . $grid 
			);
			
			$this->session->set_userdata ( $newdata );
			
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'page' => "trap_management",
					'title' => $this->lang->line('sidebar_mntnc_trap_mgmt'),
                    'app_lang' => $this->app_lang 
			);
			$this->load->view ( 'header', $data_1 );
			
			$this->load->view ( 'left_sidebar', $data_1 );
			// Pass grid to the view
            $data = (object)array();
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			$data->msg = $msg;
			$data->statuses = $this->statuses;
			
			$this->load->view ( 'traps/traps', $data );
		}
	}
	public function traps_json($idlocation = false) {
		$traps_array = $this->trap_model->listTraps ( $idlocation );
		
		$t_arr = array ();
		
		if (! $traps_array)
			$traps_array = array ();
		
		foreach ( $traps_array as $trap ) {
			
			$t_arr [] = array (
					'post' => $trap 
			);
		}
		
		$traps = array (
				'posts' => $t_arr,
				'total_records' => count ( $t_arr ) 
		);
		
		echo json_encode ( $traps );
	}
	public function create_trap_json() {
		echo __FUNCTION__ . ' not yet implemented';
	}
	public function update_trap_json() {
		echo __FUNCTION__ . ' not yet implemented';
	}
	public function delete_trap_json() {
		echo __FUNCTION__ . ' not yet implemented';
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function toExcelAll() {
		$query ['data'] = $this->trap_model->listTraps ();
		// print'<pre>';
		// print_R($query['data']);
		// die;
		$this->load->view ( 'traps/excel_view', $query );
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
		$this->load->helper ( 'pdf_helper' ); // Load helper
		$query ['data'] = $this->trap_model->listTraps ();
		
		$data = $this->load->view ( 'traps/pdf_view', $query, true );
		// $data = file_get_contents(htmlentities($dd)); // Pass the url of html report
		
		create_pdf_l ( $data, "Traps" ); // Create pdf
	}
    
    /**
	 * Function to Convert Data into PDF
	 */
	public function setUrl($url) {
	   if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
            if(!empty($url)) {
                $this->session->set_userdata ( array ('url' => $url) );   
            } 
        }
	}
    
}

/* End of file trap.php */
/* Location: ./application/controllers/trap.php */
