<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
date_default_timezone_set('UTC');
class Group extends CI_Controller {

	/**
     *
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/user
	 *	- or -
	 * 		http://example.com/user/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('language');
        $this->load->model('group_model');
        
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
    }

    public function index()
    {
        if(!$this->session->userdata('logged_in'))
        {
            redirect(base_url());
        }
        else
        {
            redirect(base_url()."group/getgroupoption");
        }
    }
    
    /**
     * Function to Show Group Option 
     * Page
     */
    public function getgroupoption()
    {
        if(!$this->session->userdata('logged_in'))
        {
            redirect(base_url());
        }
        else
        {
            $data = array(
			   'username'  => $this->session->userdata('username'),
			   'logstatus' => "logout",
               'title' => $this->lang->line('sidebar_grp'),
               'page'  => "group"

			);
            $this->load->view('header',$data);
            $this->load->view('left_sidebar',$data);
            $this->load->view('groups/group_view');
            $this->load->view('footer');
        }
    }

    /**
     * Function to Show Add User Group Form
     */
    public function showaddgroup($id = '')
    {
		if(!$this->session->userdata('logged_in'))
        {
            redirect(base_url());
        }
        else
        {
            $data = array(
			   'username'  => $this->session->userdata('username'),
			   'logstatus' => "logout",
               'title' => 'user Group',
               'page'  => "group"

			);
			//$this->load->view('header',$data);

			//$this->load->view('left_sidebar',$data);

            if(isset($id) && !empty($id))
            {
                $this->flag = $this->group_model->getGroupData($id);
            }

            if(!empty($this->flag))
                $data = array_merge($data,$this->flag);

            $this->load->view('groups/add_group',$data);
        }
        //$this->load->view('footer');
	}
    
    /**
     * Function to Show Add Site Group Form
     */
    public function showaddsitegroup($id = '')
    {
		if(!$this->session->userdata('logged_in'))
        {
            redirect(base_url());
        }
        else
        {
            $data = array(
			   'username'  => $this->session->userdata('username'),
			   'logstatus' => "logout",
               'title' => $this->lang->line('grp_mgmt_site_grp'),
               'page'  => "group"

			);
			//$this->load->view('header',$data);

			//$this->load->view('left_sidebar',$data);

            if(isset($id) && !empty($id))
            {
                $this->flag = $this->group_model->getGroupData($id , 'site');
            }

            if(!empty($this->flag))
                $data = array_merge($data,$this->flag);

            $this->load->view('groups/add_sitegroup',$data);
        }
        //$this->load->view('footer');
	}

    /**
     * Function to add a new User Group
     */
    public function addgroup()
    {
        if(!$this->session->userdata('logged_in'))
        {
            redirect(base_url());
        }
        else
        {

            $data_1 = array(
			   'username'  => $this->session->userdata('username'),
			   'logstatus' => "logout",
               'title' => $this->lang->line('grp_mgmt_usr_grp'),
               'page'  => "group"

			);
            
            $req = $this->input->post('x_s_');
            $this->form_validation->set_rules('name', $this->lang->line('usr_grp_mgmt_usrgrpnme'), 'trim|required|xss_clean');
            $this->form_validation->set_rules('description', $this->lang->line('grp_mgmt_desc'), 'trim');

            

			if ($this->form_validation->run() == FALSE)
    		{
                $return = array(
                    'unsuccess_msg' => $this->lang->line('err_msg_smthng_went_wrng')
                );

                if(!empty($req))
                {
                    $this->flag = $this->group_model->getGroupData($req);
                }
                
                if(!empty($this->flag))
                    $data_1 = array_merge($data_1 , $this->flag);

                $this->load->view('groups/add_group',$data_1);
    		}
			else
    		{
    			$flag_1 = $this->group_model->addGroup($req);

                if(!empty($flag_1) && empty($req))
                {
                    $this->flag['msg'] = "success";
                    //echo $this->flag['msg'];
//                    die;
                    $this->load->view('groups/add_group',$this->flag);
                }
                else if(!empty($flag_1) && !empty($req))
                {
                    $this->flag['msg'] = "update";
                    //echo $this->flag['msg'];
//                    die;
                    $this->load->view('groups/add_group',$this->flag);
                }
				else
				{
					$return = array(
						'unsuccess_msg' => $this->lang->line('err_msg_smthng_went_wrng')
					);

                    if(!empty($this->flag))
                    {
                        $data_1 = array_merge($data_1 , $this->flag);
                    }

					$this->load->view('groups/add_group',$data_1);
				}
    		}
        }
        //$this->load->view('footer');
    }
    
    /**
     * Function to add a new Site Group
     */
    public function addsitegroup()
    {
        if(!$this->session->userdata('logged_in'))
        {
            redirect(base_url());
        }
        else
        {

            $data_1 = array(
			   'username'  => $this->session->userdata('username'),
			   'logstatus' => "logout",
               'title' => $this->lang->line('grp_mgmt_site_grp'),
               'page'  => "group"

			);
            
            $req = $this->input->post('x_s_');
            $this->form_validation->set_rules('name', $this->lang->line('site_grp_mgmt_name'), 'trim|required|xss_clean');
            $this->form_validation->set_rules('description', $this->lang->line('grp_mgmt_desc'), 'trim');

            

			if ($this->form_validation->run() == FALSE)
    		{
                $return = array(
                    'unsuccess_msg' => $this->lang->line('err_msg_smthng_went_wrng')
                );

                if(!empty($req))
                {
                    $this->flag = $this->group_model->getGroupData($req , 'site');
                }
                
                if(!empty($this->flag))
                    $data_1 = array_merge($data_1 , $this->flag);

                $this->load->view('groups/add_sitegroup',$data_1);
    		}
			else
    		{
    			$flag_1 = $this->group_model->addSiteGroup($req);

                if(!empty($flag_1) && empty($req))
                {
                    $this->flag['msg'] = "success";
                    //echo $this->flag['msg'];
//                    die;
                    $this->load->view('groups/add_sitegroup',$this->flag);
                }
                else if(!empty($flag_1) && !empty($req))
                {
                    $this->flag['msg'] = "update";
                    //echo $this->flag['msg'];
//                    die;
                    $this->load->view('groups/add_sitegroup',$this->flag);
                }
				else
				{
					$return = array(
						'unsuccess_msg' => $this->lang->line('err_msg_smthng_went_wrng')
					);

                    if(!empty($this->flag))
                    {
                        $data_1 = array_merge($data_1 , $this->flag);
                    }

					$this->load->view('groups/add_sitegroup',$data_1);
				}
    		}
        }
        //$this->load->view('footer');
    }

    /**
     * Function to show edit User Group
     */
    public function showEditGroup()
    {
        if(!$this->session->userdata('logged_in'))
        {
            redirect(base_url());
        }
        else
        {
            $req = $this->input->get('id',TRUE);

            if(empty($req))
                redirect(base_url()."group/getgroup");

            $this->showaddgroup($req);
        }
    }
    
    /**
     * Function to show edit Site Group
     */
    public function showEditSiteGroup()
    {
        if(!$this->session->userdata('logged_in'))
        {
            redirect(base_url());
        }
        else
        {
            $req = $this->input->get('id',TRUE);

            if(empty($req))
                redirect(base_url()."group/getsitegroup");

            $this->showaddsitegroup($req);
        }
    }
    
    
    /**
     * Function to check user group name existence
     */
    public function groupCheck($str = '')
	{
        if(!$this->session->userdata('logged_in'))
        {
            redirect(base_url());
        }
        else
        { 
            $str = $this->input->post('name');
            $id = $this->input->post('x_s_');
            $flag = $this->group_model->groupExist($str , '' , $id);
            
            if($flag)
            {
                echo "error";
            }
            else
            {
                echo "success";
            }
            die();
        }
        
	}
    
    /**
     * Function to check site group name existence
     */
    public function siteGroupCheck($str = '')
	{
        if(!$this->session->userdata('logged_in'))
        {
            redirect(base_url());
        }
        else
        { 
            $str = $this->input->post('name');
            $id = $this->input->post('x_s_');
            $flag = $this->group_model->groupExist($str , 'site' , $id);
            
            if($flag)
            {
                echo "error";
            }
            else
            {
                echo "success";
            }
            die();
        }
	}

    /**
     * Function to display List Of User Groups
     */
    public function getgroup($grid = '')
    {
        if(!$this->session->userdata('logged_in'))
        {
            redirect(base_url());
        }
        else
        {
            $msg = $this->input->get('msg');

            $columns = array(
                0 => array(
                    'name' => 'User Group ID',
                    'db_name' => 'idusergroup',
                    'header' => 'User Group ID',
                    'group' => $this->lang->line('grp_mgmt_usr_grp'),
                    'required' => TRUE,
                    'form_control' => 'text_long',
                    'type' => 'string'
                ),
                1 => array(
                    'name' => $this->lang->line('usr_grp_mgmt_usrgrpnme'),
                    'db_name' => 'usergroup',
                    'header' => $this->lang->line('usr_grp_mgmt_usrgrpnme'),
                    'group' => $this->lang->line('sidebar_grp'),
                    'required' => TRUE,
                    'form_control' => 'text_long',
                    'type' => 'string'
                ),
                2 => array(
                    'name' => $this->lang->line('usr_grp_mgmt_dscptn'),
                    'db_name' => 'description',
                    'header' => $this->lang->line('usr_grp_mgmt_dscptn'),
                    'group' => $this->lang->line('sidebar_grp'),
                    'form_control' => 'text_long',
                    'type' => 'string'
                )
            );

            $commands['delete']['toolbar'] = FALSE;

            $params = array(
                'id' => 'idusergroup',
                'table' => 'usergroups',
                'url' => 'group/getgroup',
                'uri_param' => $grid,
                'columns' => $columns,
                'order' => array(0 => 'desc'),
                //'filter_date' => !empty($filter_date)?$filter_date:'2',
                'filters' => array(0 => array('value' => $this->session->userdata('idlocation'))),
                'columns_visible' => array(1,2),
                'commands' => $commands,
                'ajax' => TRUE,
                'msc_url' => array(
                    'excel_url' => base_url().'group/toExcelAll',
                    'pdf_url' => base_url().'group/toPdfAll',
                    'add_url' => 'showaddgroup'
                )
            );
            $newdata = array();
            if(!empty($grid))
                $newdata = array(
                    'url' => base_url().$params['url'].'#'.$params['id'].'='.$grid
                );
            else
                $newdata = array(
                    'url' => base_url().$params['url']
                );
            
            $this->session->set_userdata($newdata);
            
            $this->load->library('carbogrid', $params);

            if ($this->carbogrid->is_ajax)
            {
                $this->carbogrid->render();
                return FALSE;
            }

            $data_1 = array(
    		   'username'  => $this->session->userdata('username'),
    		   'logstatus' => "logout",
               'title' => $this->lang->line('grp_mgmt_usr_grp'),
               'page'  => "group"
    		);

            $this->load->view('header',$data_1);
            $this->load->view('left_sidebar',$data_1);

            // Pass grid to the view
            $data->page = 'grid_single';
            $data->page_grid = $this->carbogrid->render();
            $data->msg = $msg;

            $this->load->view('groups/groups', $data);
        }
        $this->load->view('footer');
    }
    
    /**
     * Function to display List Of Site Groups
     */
    public function getsitegroup($grid = '')
    {
        if(!$this->session->userdata('logged_in'))
        {
            redirect(base_url());
        }
        else
        {
            $msg = $this->input->get('msg');

            $columns = array(
                0 => array(
                    'name' => $this->lang->line('grp_mgmt_site_grp_id'),
                    'db_name' => 'idsitegroup',
                    'header' => $this->lang->line('grp_mgmt_site_grp_id'),
                    'group' => $this->lang->line('grp_mgmt_site_grp'),
                    'required' => TRUE,
                    'form_control' => 'text_long',
                    'type' => 'string'
                ),
                1 => array(
                    'name' => $this->lang->line('site_grp_mgmt_name'),
                    'db_name' => 'sitegroup',
                    'header' => $this->lang->line('site_grp_mgmt_name'),
                    'group' => $this->lang->line('grp_mgmt_site_grp'),
                    'required' => TRUE,
                    'form_control' => 'text_long',
                    'type' => 'string'
                ),
                2 => array(
                    'name' => $this->lang->line('usr_grp_mgmt_dscptn'),
                    'db_name' => 'description',
                    'header' => $this->lang->line('usr_grp_mgmt_dscptn'),
                    'group' => $this->lang->line('sidebar_grp'),
                    'form_control' => 'text_long',
                    'type' => 'string'
                )
            );

            $commands['delete']['toolbar'] = FALSE;

            $params = array(
                'id' => 'idsitegroup',
                'table' => 'sitegroups',
                'url' => 'group/getsitegroup',
                'uri_param' => $grid,
                'columns' => $columns,
                'order' => array(0 => 'desc'),
                //'filter_date' => !empty($filter_date)?$filter_date:'2',
                'filters' => array(0 => array('value' => $this->session->userdata('idlocation'))),
                'columns_visible' => array(1,2),
                'commands' => $commands,
                'ajax' => TRUE,
                'msc_url' => array(
                    'excel_url' => base_url().'group/toExcelAllSite',
                    'pdf_url' => base_url().'group/toPdfAllSite',
                    'add_url' => 'showaddgroup'
                )
            );
            $newdata = array();
            if(!empty($grid))
                $newdata = array(
                    'url' => base_url().$params['url'].'#'.$params['id'].'='.$grid
                );
            else
                $newdata = array(
                    'url' => base_url().$params['url']
                );
            
            $this->session->set_userdata($newdata);
            
            $this->load->library('carbogrid', $params);

            if ($this->carbogrid->is_ajax)
            {
                $this->carbogrid->render();
                return FALSE;
            }

            $data_1 = array(
    		   'username'  => $this->session->userdata('username'),
    		   'logstatus' => "logout",
               'title' => $this->lang->line('grp_mgmt_site_grp'),
               'page'  => "group"
    		);

            $this->load->view('header',$data_1);
            $this->load->view('left_sidebar',$data_1);

            // Pass grid to the view
            $data->page = 'grid_single';
            $data->page_grid = $this->carbogrid->render();
            $data->msg = $msg;

            $this->load->view('groups/sitegroups', $data);
        }
        $this->load->view('footer');
    }

    /**
     * Function to delete Group
     */
    public function deleteGroup()
    {
        if(!$this->session->userdata('logged_in'))
        {
            redirect(base_url());
        }
        else
        {
            $req = $this->input->get('id',TRUE);
            $type = $this->input->get('type',TRUE);
            
            $seturl = explode("#",$this->session->userdata('url'));
            if(empty($req))
            {
                if(!empty($seturl[1]))
                    redirect($seturl[0]."#".$seturl[1]);
                else
                    redirect($seturl[0]);
            }
                //redirect(base_url()."group/getgroup");

            $flag_1 = $this->group_model->deleteGroup($req , $type);

            if($flag_1)
            {
                if(!empty($seturl[1]))
                    redirect($seturl[0]."?msg=delete#".$seturl[1]);
                else
                    redirect($seturl[0]."?msg=delete");
            }
            //redirect(base_url()."group/getgroup?msg=delete");
        }
    }


    /**
     * Function to Convert User Group Data into Excel Sheet
     */
    public function toExcelAll()
    {
        if(!$this->session->userdata('logged_in'))
        {
            redirect(base_url());
        }
        else
        {

            $query['data'] = $this->group_model->listGroup();

            //print'<pre>';
    //        print_r($query['data']);
    //        die;

            $this->load->view('groups/excel_view',$query);
        }
    }

    /**
     * Function to  Convert User Group Data into PDF
     */
    public function toPdfAll()
    {
        if(!$this->session->userdata('logged_in'))
        {
            redirect(base_url());
        }
        else
        {
            $this->load->helper('pdf_helper');   //  Load helper
            $query['data'] = $this->group_model->listGroup();
            $data = $this->load->view('groups/pdf_view',$query,true);

            create_pdf($data, $this->lang->line('grp_mgmt_rqsts')); //Create pdf
        }
    }
    
    /**
     * Function to Convert Site Group Data into Excel Sheet
     */
    public function toExcelAllSite()
    {
        if(!$this->session->userdata('logged_in'))
        {
            redirect(base_url());
        }
        else
        {

            $query['data'] = $this->group_model->listGroup('site');

            //print'<pre>';
    //        print_r($query['data']);
    //        die;

            $this->load->view('groups/excel_siteview',$query);
        }
    }

    /**
     * Function to  Convert Site Group Data into PDF
     */
    public function toPdfAllSite()
    {
        if(!$this->session->userdata('logged_in'))
        {
            redirect(base_url());
        }
        else
        {
            $this->load->helper('pdf_helper');   //  Load helper
            $query['data'] = $this->group_model->listGroup('site');
            $data = $this->load->view('groups/pdf_siteview',$query,true);

            create_pdf($data,$this->lang->line('grp_mgmt_site_grp')); //Create pdf
        }
    }






}

/* End of file group.php */
/* Location: ./application/controllers/group.php */
