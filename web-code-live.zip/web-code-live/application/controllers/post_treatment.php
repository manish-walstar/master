<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Post_treatment extends CI_Controller {
	public $inspector = "";
	public $sites = "";
	public $site = "";
	public $date;
	public $time;
	public $products;
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		
		$this->date = date ( 'm/d/Y' );
		$this->time = date ( 'h:i A' );
		
        $this->load->helper('language');
        
		$this->load->model ( 'treatment_model' );
		$this->load->model ( 'post_treatment_model' );
		$this->load->model ( 'larvalsurveillance_model' );
		$this->load->model ( 'site_model' );
		
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		$this->inspector = $this->larvalsurveillance_model->getInspectors ();
		$this->products = $this->treatment_model->getProducts ();
		
		$this->latitude = "";
		$this->longitude = "";
		$this->date_analysis = $this->date;
		$this->first_name = "";
		$this->last_name = "";
		$this->company_analysis = "";
		$this->technique_method = "";
		$this->results_analysis = "";
		$this->notes = "";
		$this->sample_taken = "";
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			redirect ( base_url () . "post_treatment/getpost_treatment" );
		}
	}
	
	/**
	 * Function to Show Add Post TX Visual Impact
	 */
	public function showaddpost_treatment($req = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = array ();
			$idtrtmnt = $this->input->get ( 'id' );
			$type = $this->input->get ( 'type' );
			
			$trtmnt = array ();
			
			if (empty ( $idtrtmnt ) && empty ( $req ))
				return "error";
			
			if (empty ( $type ))
				$type = "adult";
			
			if (empty ( $req )) {
				if ($type == "adult")
					$trtmnt = $this->treatment_model->getAdultTreatmentData ( $idtrtmnt );
				
				if ($type == "larva")
					$trtmnt = $this->treatment_model->getLarvalTreatmentData ( $idtrtmnt );
				
				if (! empty ( $trtmnt )) {
					$this->inspector = $this->larvalsurveillance_model->getSelectedInspectors ( $trtmnt ['idapplicator'] );
					$this->products = $this->treatment_model->getProducts ( $trtmnt ['idproduct'] );
					
					if (! empty ( $trtmnt ['date'] ))
						$this->date = date ( 'm/d/Y', strtotime ( $trtmnt ['date'] ) );
					
					if (! empty ( $trtmnt ['time'] ))
						$this->time = date ( 'h:i A', strtotime ( $trtmnt ['time'] ) );
					
					$this->sites = $this->site_model->getSelectedExistingSite ( $trtmnt ['idsite'] );
					$site_data = $this->site_model->getSiteData ( $trtmnt ['idsite'] );
					
					if (! empty ( $site_data ))
						$this->site = $site_data ['site'];
				}
			} else {
				$flag = $this->post_treatment_model->getPost_treatmentData ( $req );
				
				if (! empty ( $flag )) {
					$this->inspector = $this->larvalsurveillance_model->getSelectedInspectors ( $flag ['idinspector'] );
					$this->products = $this->treatment_model->getProducts ( $flag ['idproduct'] );
					$this->date = $flag ['date'];
					$this->time = $flag ['time'];
					$site_data = $this->site_model->getSiteData ( $flag ['idsite'] );
					$this->sites = $this->site_model->getSelectedExistingSite ( $flag ['idsite'] );
					if (! empty ( $site_data ))
						$this->site = $site_data ['site'];
				} else
					$this->inspector = $this->larvalsurveillance_model->getInspectors ();
			}
			
			$data_1 = array (
					'inspector' => $this->inspector,
					'date' => $this->date,
					'time' => $this->time,
					'sites' => $this->sites,
					'site' => $this->site,
					'flag' => $flag,
					'idtrtmnt' => $idtrtmnt,
					'type' => $type,
					'products' => $this->products,
					'req' => $req,
                    'app_lang' => $this->app_lang
			);
			
			// print'<pre>';
			// print_r($data_1);
			// die;
			$this->load->view ( 'post_treatments/addpost_treatment', $data_1 );
		}
	}
	
	/**
	 * Function to Show Add Post TX Water Quality
	 */
	public function showaddpost_treatment_wq($req = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = array ();
			$idtrtmnt = $this->input->get ( 'id' );
			$type = $this->input->get ( 'type' );
			
			$trtmnt = array ();
			
			if (empty ( $idtrtmnt ) && empty ( $req ))
				return "error";
			
			if (empty ( $type ))
				$type = "adult";
			
			if (empty ( $req )) {
				if ($type == "adult")
					$trtmnt = $this->treatment_model->getAdultTreatmentData ( $idtrtmnt );
				
				if ($type == "larva")
					$trtmnt = $this->treatment_model->getLarvalTreatmentData ( $idtrtmnt );
				
				if (! empty ( $trtmnt )) {
					$this->inspector = $this->larvalsurveillance_model->getSelectedInspectors ( $trtmnt ['idapplicator'] );
					
					if (! empty ( $trtmnt ['date'] ))
						$this->date = date ( 'm/d/Y', strtotime ( $trtmnt ['date'] ) );
					
					if (! empty ( $trtmnt ['time'] ))
						$this->time = date ( 'h:i A', strtotime ( $trtmnt ['time'] ) );
					
					if (! empty ( $trtmnt ['latitude'] ))
						$this->latitude = $trtmnt ['latitude'];
					
					if (! empty ( $trtmnt ['longitude'] ))
						$this->longitude = $trtmnt ['longitude'];
					
					$this->sites = $this->site_model->getSelectedExistingSite ( $trtmnt ['idsite'] );
					$this->date_analysis = $this->date;
					$this->first_name = "";
					$this->last_name = "";
					$this->company_analysis = "";
					$this->technique_method = "";
					$this->results_analysis = "";
					$this->notes = "";
					$this->sample_taken = "";
				}
			} else {
				$flag = $this->post_treatment_model->getPost_treatmentData ( $req );
				
				if (! empty ( $flag )) {
					$this->inspector = $this->larvalsurveillance_model->getSelectedInspectors ( $flag ['idinspector'] );
					$this->sites = $this->site_model->getSelectedExistingSite ( $flag ['idsite'] );
					
					$this->date = $flag ['date'];
					$this->time = $flag ['time'];
					
					$this->latitude = $flag ['latitude'];
					$this->longitude = $flag ['longitude'];
					$this->date_analysis = $flag ['date_analysis'];
					$this->first_name = $flag ['first_name'];
					$this->last_name = $flag ['last_name'];
					$this->company_analysis = $flag ['company_analysis'];
					$this->technique_method = $flag ['technique_method'];
					$this->results_analysis = $flag ['results_analysis'];
					$this->notes = $flag ['notes'];
					$this->sample_taken = $flag ['sample_taken'];
				} else
					$this->inspector = $this->larvalsurveillance_model->getInspectors ();
			}
			
			$data_1 = array (
					'date' => $this->date,
					'time' => $this->time,
					'inspector' => $this->inspector,
					'sites' => $this->sites,
					'latitude' => $this->latitude,
					'longitude' => $this->longitude,
					'date_analysis' => $this->date_analysis,
					'first_name' => $this->first_name,
					'last_name' => $this->last_name,
					'company_analysis' => $this->company_analysis,
					'technique_method' => $this->technique_method,
					'results_analysis' => $this->results_analysis,
					'notes' => $this->notes,
					'sample_taken' => $this->sample_taken,
					'idtrtmnt' => $idtrtmnt,
					'type' => $type,
					'req' => $req,
                    'app_lang' => $this->app_lang 
			);
			
			// print'<pre>';
			// print_r($data_1);
			// die;
			$this->load->view ( 'post_treatments/addpost_treatments_wq', $data_1 );
		}
	}
	
	/**
	 * Function to add a new post_treatment
	 */
	public function addpost_treatment() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data_1 = array (
					'inspector' => $this->inspector,
					'date' => $this->date,
					'time' => $this->time,
					'sites' => $this->sites,
					'site' => $this->site 
			);
			
			$this->form_validation->set_rules ( 'idinspector', $this->lang->line('whthr_snsr_inspctr'), 'trim' );
			$this->form_validation->set_rules ( 'date', $this->lang->line('lrvl_trtmnt_date'), 'trim' );
			$this->form_validation->set_rules ( 'time', $this->lang->line('cmn_time'), 'trim' );
			
			$req = $this->input->post ( 'id' );
			
			$idtrtmnt = $this->input->post ( 'idtrtmnt' );
			$type = $this->input->post ( 'type' );
			
			$data_1 ['idtrtmnt'] = $idtrtmnt;
			$data_1 ['type'] = $type;
			
			if (! empty ( $req )) {
				$data = $this->post_treatment_model->getPost_treatmentData ( $req );
				
				if (! empty ( $data )) {
					$this->inspector = $this->larvalsurveillance_model->getSelectedInspectors ( $data ['idinspector'] );
					$this->products = $this->treatment_model->getProducts ( $data ['idproduct'] );
					$this->date = $data ['date'];
					$this->time = $data ['time'];
					$site_data = $this->site_model->getSiteData ( $data ['idsite'] );
					$this->sites = $this->site_model->getSelectedExistingSite ( $data ['idsite'] );
					if (! empty ( $site_data ))
						$this->site = $site_data ['site'];
				} else {
					$this->inspector = $this->larvalsurveillance_model->getInspectors ();
					$this->products = $this->treatment_model->getProducts ();
				}
				
				$data_1 ['flag'] = $data;
				$data_1 ['req'] = $req;
			}
			
			if ($this->form_validation->run () == FALSE) {
				$data_1 ['msg'] = "error";
			} else {
				$flag = $this->post_treatment_model->addPost_treatment ( $req );
				// print'<pre>';
				// print_r($flag);
				
				if (! $flag) {
					$data_1 ['msg'] = "error";
				} else if (! empty ( $flag ) && ! empty ( $req )) {
					$data_1 ['msg'] = "update";
				} else if (! empty ( $flag )) {
					$data_1 ['msg'] = "success";
					$data_1 ['idpost'] = $flag;
				}
			}
			$data_1['app_lang'] = $this->app_lang;
			$this->load->view ( 'post_treatments/addpost_treatment', $data_1 );
		}
	}
	
	/**
	 * Function to add a new post_treatment water quality
	 */
	public function addpost_treatment_wq() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data_1 = array (
					'inspector' => $this->inspector,
					'date' => $this->date,
					'time' => $this->time,
					'sites' => $this->sites,
                    'app_lang' => $this->app_lang 
			);
			
			$this->form_validation->set_rules ( 'date_sample', $this->lang->line('advrs_impct_date_smpl_tkn'), 'trim' );
			$this->form_validation->set_rules ( 'time_sample', $this->lang->line('advrs_impct_time_smpl_tkn'), 'trim' );
			$this->form_validation->set_rules ( 'inspector', $this->lang->line('advrs_impct_smpl_tkn_by'), 'trim' );
			$this->form_validation->set_rules ( 'site_id', $this->lang->line('whthr_snsr_site'), 'trim' );
			$this->form_validation->set_rules ( 'latitude', $this->lang->line('site_mgmt_lat'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'longitude', $this->lang->line('site_mgmt_lng'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'date_analysis', $this->lang->line('advrs_impct_anlyss_prfrmd'), 'trim' );
			$this->form_validation->set_rules ( 'first_name', $this->lang->line('post_trtmnt_frst_name'), 'trim|alpha' );
			$this->form_validation->set_rules ( 'last_name', $this->lang->line('post_trtmnt_frst_name'), 'trim|alpha' );
			$this->form_validation->set_rules ( 'company_analysis', $this->lang->line('advrs_impct_mpny_prfrmng_anlyss'), 'trim' );
			$this->form_validation->set_rules ( 'technique_method', $this->lang->line('advrs_impct_anlytcl_tchnq'), 'trim' );
			$this->form_validation->set_rules ( 'results_analysis', $this->lang->line('advrs_impct_rslts_of_anlyss'), 'trim' );
			$this->form_validation->set_rules ( 'notes', $this->lang->line('prdct_ovrvw_notes'), 'trim' );
			$this->form_validation->set_rules ( 'sample_taken', $this->lang->line('advrs_impct_smpl_tkn'), 'trim' );
			
			$req = $this->input->post ( 'id' );
			
			$idtrtmnt = $this->input->post ( 'idtrtmnt' );
			$type = $this->input->post ( 'type' );
			
			$data_1 ['idtrtmnt'] = $idtrtmnt;
			$data_1 ['type'] = $type;
			
			if (! empty ( $req )) {
				$data = $this->post_treatment_model->getPost_treatmentData ( $req );
				
				if (! empty ( $data )) {
					$this->inspector = $this->larvalsurveillance_model->getSelectedInspectors ( $data ['idinspector'] );
					$this->products = $this->treatment_model->getProducts ( $data ['idproduct'] );
					$this->date = $data ['date'];
					$this->time = $data ['time'];
					$site_data = $this->site_model->getSiteData ( $data ['idsite'] );
					$this->sites = $this->site_model->getSelectedExistingSite ( $data ['idsite'] );
					if (! empty ( $site_data ))
						$this->site = $site_data ['site'];
				} else {
					$this->inspector = $this->larvalsurveillance_model->getInspectors ();
					$this->products = $this->treatment_model->getProducts ();
				}
				
				$data_1 ['flag'] = $data;
				$data_1 ['req'] = $req;
			}
			
			if ($this->form_validation->run () == FALSE) {
				$data_1 ['msg'] = "error";
			} else {
				
				$flag = $this->post_treatment_model->addPost_treatmentWQ ( $req );
				
				if (empty ( $flag )) {
					$data_1 ['msg'] = "error";
				} else if (! empty ( $flag ) && ! empty ( $req )) {
					$data_1 ['msg'] = "update";
				} else if (! empty ( $flag )) {
					$data_1 ['msg'] = "success";
					$data_1 ['idpost'] = $flag;
				}
			}
			
			$this->load->view ( 'post_treatments/addpost_treatments_wq', $data_1 );
		}
	}
	
	/**
	 * Function to show edit post_treatment visual impact
	 */
	public function showeditpost_treatment($Id = '', $msg = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get_post ( 'id' );
			
			if (empty ( $req ))
				$this->load->view ( 'post_treatments/addpost_treatment' );
			else
				$this->showaddpost_treatment ( $req );
		}
	}
	
	/**
	 * Function to show edit post_treatment water quality
	 */
	public function showeditpost_treatment_wq($Id = '', $msg = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get_post ( 'id' );
			
			if (empty ( $req ))
				$this->load->view ( 'post_treatments/addpost_treatments_wq' );
			else
				$this->showaddpost_treatment_wq ( $req );
		}
	}
	
	/**
	 * Function to delete post_treatment
	 */
	public function deletepost_treatment() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->post_treatment_model->deletepost_treatment ();
			
			$msg = "";
			
			if ($flag)
				$msg = "success";
			else
				$msg = "error";
			
			$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
			if (! empty ( $seturl [1] ))
				redirect ( $seturl [0] . "?del=" . $msg . "#" . $seturl [1] );
			else
				redirect ( $seturl [0] . "?del=" . $msg );
			
			// redirect(base_url().'post_treatment/getpost_treatment?del='.$msg);
		}
	}
	
	/**
	 * Function to display List Of post_treatments
	 */
	public function getpost_treatment($grid = '', $msg = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$columns = array (
					0 => array (
							'name' => $this->lang->line('advrs_impct_rprtng_dttm'),
							'db_name_1' => 'date',
							'db_name_2' => 'time',
							'header' => $this->lang->line('advrs_impct_rprtng_dttm'),
							'group' => $this->lang->line('post_trtmnt_hdng'),
							'required' => TRUE,
							'form_control' => 'text_long',
							'type' => '1+2' 
					),
					1 => array (
							'name' => $this->lang->line('whthr_snsr_site_nm'),
							'db_name' => 'idsite',
							'header' => $this->lang->line('whthr_snsr_site_nm'),
							'group' => $this->lang->line('post_trtmnt_hdng'),
							'ref_table_id_name' => 'idsite',
							'ref_table_db_name' => 'sites',
							'ref_field_db_name' => 'site',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-n' 
					),
					2 => array (
							'name' => $this->lang->line('adlt_trtmnt_applicator'),
							'db_name' => 'idinspector',
							'header' => $this->lang->line('whthr_snsr_inspctr'),
							'group' => $this->lang->line('post_trtmnt_hdng'),
							'ref_table_id_name' => 'iduser',
							'ref_table_db_name' => 'users',
							'ref_field_db_name' => 'firstname',
							'ref_field_2_db_name' => 'lastname',
							'ref_field_type' => 'string',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-1+2' 
					),
					3 => array (
							'name' => $this->lang->line('prdct_ovrvw_type'),
							'db_name' => 'post_inspection_type',
							'header' => $this->lang->line('prdct_ovrvw_type'),
							'group' => $this->lang->line('post_trtmnt_hdng'),
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => 'string' 
					) 
			);
			
			$params = array (
					'id' => 'idpost_treatment_inspect',
					'table' => 'post_treatment_inspection',
					'url' => 'post_treatment/getpost_treatment',
					'uri_param' => $grid,
					'columns' => $columns,
					'order' => array (
							0 => 'desc' 
					),
					'filters' => array (
							1 => array (
									'value' => $this->session->userdata ( 'idlocation' ) 
							) 
					),
					'msc_url' => array (
							'excel_url' => base_url () . 'post_treatment/toExcelAll',
							'pdf_url' => base_url () . 'post_treatment/toPdfAll',
							'text' => $this->lang->line('post_trtmnt_hdng') 
					) 
			);
			
			$newdata = array (
					'url' => base_url () . $params ['url'] . '#' . $params ['id'] . '=' . $grid 
			);
			
			$this->session->set_userdata ( $newdata );
			
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('post_trtmnt_hdng'),
					'page' => "post_treatment",
                    'app_lang' => $this->app_lang 
			);
			
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			
			// Pass grid to the view
            $data = (object)array();
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			$data->msg = $msg;
			
			$this->load->view ( 'post_treatments/post_treatments', $data );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to return Apprise View
	 */
	public function showBox() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$id = $this->input->get_post ( 'id' );
			$type = $this->input->get_post ( 'type' );
			
			$data = array (
					'id' => $id,
					'type' => $type 
			);
			
			$view = $this->load->view ( 'post_treatments/link_view', $data, TRUE );
			
			echo $view;
		}
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function toExcelAll() {
		$query ['data'] = $this->post_treatment_model->listPost_treatment ();
		// print'<pre>';
		// print_r($query['data']);
		// die;
		$this->load->view ( 'post_treatments/excel_view', $query );
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
		$this->load->helper ( 'pdf_helper' );
		$query ['data'] = $this->post_treatment_model->listPost_treatment ();
		
		$data = $this->load->view ( 'post_treatments/pdf_view', $query, true );
		
		create_pdf ( $data, str_Replace(' ', '', $this->lang->line('post_trtmnt_hdng')) ); // Create pdf
	}
}

/* End of file post_treatment.php */
/* Location: ./application/controllers/post_treatment.php */