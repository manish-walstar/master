<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Custom_report extends CI_Controller {
	public $startdate;
	public $starttime;
	public $enddate;
	public $endtime;
	public $currentdate;
	public $currenttime;
	public $endtimestamp;
	public $starttimestamp;
	public $userinfo;
	public $app_lang;
	
	
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		$this->load->helper('language');
		$this->load->model ( 'custom_report_model' );
		$this->load->model ( 'usermodel' );
		$this->load->model('mapmanagement_model');
		$this->currentdate = date ( 'm/d/Y' );
		$this->currenttime = date ( "h:i:s a" );
		
		$this->usermodel->set_access_session ();
		
		if (! $this->usermodel->user_access ( 'reports' ) && ! $this->usermodel->user_access ( 'company_admin' ))
			redirect ( base_url () );
		
		$this->app_lang = $this->session->userdata('app_lang');
		$this->lang->load("app",$this->app_lang); 
		$this->enddate = date ( 'm/d/Y' );
		$this->endtime = date ( 'h:i:s' );
		
		$this->startdate = date ( 'm/d/Y', strtotime ( "-30 day" ) );
		$this->starttime = date ( 'h:i:s' );
		
		$this->endtimestamp = strtotime ( date ( 'm/d/Y H:i:s' ) );
		
		$this->starttimestamp = strtotime ( date ( 'm/d/Y H:i:s', strtotime ( "-10 day" ) ) );

		if ($this->session->userdata ( 'id' ))
		{		 
			$id = $this->session->userdata ( 'id' );
			$id_arr = explode ( "_", json_decode ( base64_decode ( $id ) ) );			
			$id = json_decode ( base64_decode ( $id_arr [0] ) );			
			$this->userinfo = $this->usermodel->getUserData ( $id );			
			$middlename = " ";
			if (isset ( $this->userinfo ['middlename'] ))
				$middlename = ! empty ( $this->userinfo ['middlename'] ) ? " " . $this->userinfo ['middlename'] . " " : " ";
			
			if (isset ( $this->userinfo ['firstname'] ) || isset ( $this->userinfo ['lastname'] ))
				$this->inspector = $this->userinfo ['firstname'] . $middlename . $this->userinfo ['lastname'];
			
		}
	}
	
	public function index() {
		if (!$this->session->userdata('logged_in')) {
			redirect(base_url());
		}
		else if($this->session->userdata('idlocation') != '57') {
			redirect(base_url());
		}
		else {
			redirect ( base_url () . "custom_report/getcustomereport" );
		}
	}
	
	/**
	 * Renders custom chicago report.
	 */
	public function getcustomereport() {
		if (!$this->session->userdata('logged_in')) {
			redirect(base_url());
		}
		else if($this->session->userdata('idlocation') != '57') {
			redirect(base_url());
		}
		else {
			$startdate = $this->input->post ('startdate');
			$enddate = $this->input->post ('enddate');
			$siteids = $this->input->post('siteids');
			
			$loadFlag = false;
			
			if(empty($startdate) && empty($enddate) && empty($siteids)) $loadFlag = true;
		
			if (!empty($startdate) && !empty($enddate)) {
				$this->startdate = $startdate;					
				$this->enddate = $enddate;				
			}
			
			if(!empty($siteids)) 	$this->excludedSites = explode(',', $siteids);
			else $this->excludedSites = array();
			
			$location = $this->session->userdata('idlocation');
			
			$result = array();
			$result = $this->custom_report_model->getTreatedBasins($this->startdate, $this->enddate, $this->excludedSites, $loadFlag);

			$data_1 = array (
				'username' => $this->session->userdata ('username'),
				'logstatus' => "logout",
				'title' => 'Ward Summary Report',
				'page' => "custom_report",
				'startdate' => $this->startdate,
				'starttime' => date ( 'h:i:s A', strtotime ( $this->starttime ) ),
				'endtime' => date ( 'h:i:s A', strtotime ( $this->endtime ) ),
				'enddate' => $this->enddate,
				'currentdate' => $this->currentdate,
				'currenttime' => date ( "h:i:s A", strtotime ( $this->currenttime ) ),
				'data' => $result,
				'loadFlag' => $loadFlag
			);						

			$this->load->view ('header', $data_1);
			$this->load->view ('left_sidebar', $data_1);
			$this->load->view ('custom_reports/custom_reports', $data_1);
			$this->load->view ('footer');
		}		
	}
	
	/**
	 * Renders narrative report.
	 */
	public function getnarrativereport() {
		if (!$this->session->userdata('logged_in')) {
			redirect(base_url());
		}
		else if($this->session->userdata('idlocation') != '57') {
			redirect(base_url());
		}
		else {
			$date = $this->input->post('date');
			$data = array();
			$type = $this->input->post('report-type');
			
			$strsupervisorids = $this->input->post('supervisorids');
			if(!empty($strsupervisorids)) 	$supervisorIDs = explode(',', $strsupervisorids);
			else $supervisorIDs = array();
			
			if(empty($date)) $date = date('m/d/Y');
			
			if(empty($type)) $type = "1";
			
			$result = array();
			$result = $this->custom_report_model->getNarrativeReport($date, $supervisorIDs);
			
			// print_r($result);
			
			$data = array (
				'username' => $this->session->userdata ('username'),
				'logstatus' => "logout",
				'title' => 'Narrative Report',
				'page' => "narrative_report",
				'date' => $date,
				'type' => $type,
				'data' => $result
			);
			
			$this->load->view ('header', $data);
			$this->load->view ('left_sidebar', $data);
			$this->load->view ('custom_reports/narrative_reports', $data);
			$this->load->view ('footer');			
		}
	}
	
	/**
	 * Function to convert data into PDF
	 */
	public function toPDFAll() {
		if (!$this->session->userdata('logged_in')) {
			redirect(base_url());
		}
		else if($this->session->userdata('idlocation') != '57') {
			redirect(base_url());
		}
		else {
			$this->load->helper ('pdf_helper');
			$data = $this->exportView();

			create_pdf_l ($data, $this->lang->line('custom_report_hdng') );
		}
	}	
	
	/**
	 * Function to fetch the data
	 * and format it in order to return
	 */
	public function exportView() {
		if (!$this->session->userdata('logged_in')) {
			redirect(base_url());
		}
		else if($this->session->userdata('idlocation') != '57') {
			redirect(base_url());
		}
		else {
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			$ctime = $this->input->post ( 'current_time' );
			$this->currenttime = ! empty ( $ctime ) ? $ctime : $this->currenttime;
			$siteids = $this->input->post('siteids');
			
			if (! empty ( $startdate ) && ! empty ( $enddate )) {
				$this->startdate = $startdate;
				$this->enddate = $enddate;
			}
			
			if(!empty($siteids)) 	$this->excludedSites = explode(',', $siteids);
			else $this->excludedSites = array();
			
			$lcoation = $this->session->userdata('idlocation');
			$result = array();
			$result = $this->custom_report_model->getTreatedBasins($this->startdate, $this->enddate, $lcoation, $this->excludedSites);
			
			$data_1 = array (
				'username' => $this->session->userdata ( 'username' ),
				'logstatus' => "logout",
				'title' => 'Ward Detail Report',
				'page' => "custom_report",
				'startdate' => $this->startdate,
				'starttime' => date ( 'h:i:s A', strtotime ( $this->starttime ) ),
				'endtime' => date ( 'h:i:s A', strtotime ( $this->endtime ) ),
				'enddate' => $this->enddate,
				'currentdate' => $this->currentdate,
				'currenttime' => date ( "h:i:s A", strtotime ( $this->currenttime ) ),
				'data' => $result
			);
			
			$data = $this->load->view('custom_reports/pdf_view', $data_1, TRUE);
			
			return $data;
		}
	}
	
	/**
	 * Function to convert data into PDF
	 */
	public function toPDFAllNarrative() {
		if (!$this->session->userdata('logged_in')) {
			redirect(base_url());
		}
		else if($this->session->userdata('idlocation') != '57') {
			redirect(base_url());
		}
		else {
			$this->load->helper ('pdf_helper');
			$data = $this->exportViewNarrative ();

			create_pdf_l ($data, 'Narrative Report');
		}
	}
	
	public function toWORDAllNarrative() {
		if (!$this->session->userdata('logged_in')) {
			redirect(base_url());
		}
		else if($this->session->userdata('idlocation') != '57') {
			redirect(base_url());
		}
		else {
			header ( "Content-Type: application/vnd.ms-word" );
			header ( "Expires: 0" );
			header ( "Cache-Control:  must-revalidate, post-check=0, pre-check=0" );
			header ( "Content-disposition: attachment; filename=Narrative Report.doc" );						
			
			$data = $this->exportViewNarrative();
			
			echo $data;
			exit();
		}
	}
	
	/**
	 * Function to fetch the data
	 * and format it in order to return
	 */
	public function exportViewNarrative() {
		if (!$this->session->userdata('logged_in')) {
			redirect(base_url());
		}
		else if($this->session->userdata('idlocation') != '57') {
			redirect(base_url());
		}
		else {
			$date = $this->input->post('date');
			$data = array();
			$type = $this->input->post('report-type');			
			
			if(empty($date)) $date = date('m/d/Y');
			
			$strsupervisorids = $this->input->post('supervisorids');
			if(!empty($strsupervisorids)) 	$supervisorIDs = explode(',', $strsupervisorids);
			else $supervisorIDs = array();
			
			if(empty($type)) $type = "1";
			
			$result = array();
			$result = $this->custom_report_model->getNarrativeReport($date, $supervisorIDs);
			
			$data = array (
				'username' => $this->session->userdata ('username'),
				'logstatus' => "logout",
				'title' => 'Narrative Report',
				'page' => "narrative_report",
				'date' => $date,
				'type' => $type,
				'data' => $result
			);
			
			$data = $this->load->view ('custom_reports/pdf_view_narrative', $data, TRUE);
			
			return $data;
		}
	}
}

/* End of file custome_report.php */
/* Location: ./application/controllers/custom_report.php */