<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );

class Maintenance_inspection extends CI_Controller {
	public $idlocation;
	public $trap_name = "";
	public $inspector = "";
	public $temperature = "";
	public $humidity = "";
	public $windspeed = "";
	public $cloudcover = "";
	public $species = "";
	public $s_species = "";
	public $observed_time = "";
	public $observed_date = "";
	public $sitegroup = "";
	public $applicator="";
		public static $removedImages = array() ;
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		$this->load->helper('language');
		$this->load->model ( 'maintenanceinsp_model' );
		$this->load->model ( 'adultsurveillance_model' );
		$this->load->model ( 'zone_model' );
		$this->load->model ( 'site_model' );
		$this->load->model ( 'larvalsurveillance_model' );
        $this->applicator = $this->larvalsurveillance_model->getInspectors();
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);

		if ($this->session->userdata ( 'idlocation' ))
			$this->idlocation = $this->session->userdata ( 'idlocation' );
			
		
		$this->sites = $this->maintenanceinsp_model->getSitename ();
		$this->site_type = $this->site_model->getSitetypes ();
		$this->zones = $this->maintenanceinsp_model->getSelectedZonename ();
		$this->states = $this->site_model->getStates ();
		$this->state_list = $this->maintenanceinsp_model->getStatebyName ();
		$this->sitegroup = $this->site_model->getSiteGroup ();
		
		$this->observed_date = date ( 'm/d/Y' );
		$this->observed_time = date ( 'h:i:s A' );
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' ) || $this->session->userdata ( 'idlocation' ) != 61) {
			redirect ( base_url () );
		} else {
			
			redirect ( base_url () . "maintenance_inspection/getmaintenanceinspection" );
		}
	}
	
	/**
	 * Function to Show Add Member Form
	 */
	public function showaddmaintenanceinspection() {
		if (! $this->session->userdata ( 'logged_in' ) || $this->session->userdata ( 'idlocation' ) != 61) {
			redirect ( base_url () );
		} else {
			
            $mapFlag = $this->input->get_post ( 'mapFlag' );
            $mapSite = $this->input->get('idsite');
            $siteData = !empty($mapSite) ? $this->getSiteData($mapSite) : array();
            
			$data = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => "Maintenance Inspection",
					'applicator' => $this->applicator,
					'page' => "maintenance_inspection",
					'existing_site' => $this->maintenanceinsp_model->getSitename (),
					'site_type' => $this->site_model->getSitetypes (),
					'zone_name' => $this->maintenanceinsp_model->getSelectedZonename (),
					'state_name' => $this->site_model->getStates (),
					'state_list' => $this->maintenanceinsp_model->getStatebyName (),
					'observed_time' => $this->observed_time,
					'observed_date' => $this->observed_date,
                    'app_lang' => $this->app_lang,
                    'mapFlag' => $mapFlag
			);
            $mapData = $this->getAllEventsData($mapSite);
            $data = array_merge($data, $mapData);
            $data = !empty($siteData) ? array_merge($data, $siteData) : $data;
			
			$this->load->view ( 'maintenance_inspection/add_maintenanceinspection', $data );
		}
		// $this->load->view('footer');
	}

	public function showImg(){
			$src = $this->input->get('src');
			$data['source'] = $src;
			$this->load->view ( 'maintenance_inspection/showImage', $data );
	}

    
    /**
	 * Function to get Site Data based on idsite clicked by user on Map
	 */
    public function getSiteData($idsite = "") {
        if (! $this->session->userdata ( 'logged_in' ) || $this->session->userdata ( 'idlocation' ) != 61) {
			redirect ( base_url () );
		} else {
            $return = array();
            if(!empty($idsite)){
                $site_data = $this->site_model->getSiteData ( $idsite );
    			if (! empty ( $site_data )) {
    			 
                    $this->site_id = $this->maintenanceinsp_model->getSitename ( $idsite );
        			$this->site_type = $this->site_model->getSitetypes ();
        			$this->state_name = $this->site_model->getStates ();
                    $this->idzone = $this->maintenanceinsp_model->getSelectedZonename ( ! empty ( $site_data ['idzone'] ) ? $site_data ['idzone'] : '');
                    
                    $return ['existing_site'] = $this->site_id;
                    $return ['site'] = ! empty ( $site_data ['site'] ) ? $site_data ['site'] : '';
    				$return ['site_type'] = $this->site_type;
                    $return ['idsitetype'] = ! empty ( $site_data ['idsitetype'] ) ? $site_data ['idsitetype'] : '';
    				$return ['zone_name'] = $this->idzone;
                    $return ['maplabel'] = ! empty ( $site_data ['maplabel'] ) ? $site_data ['maplabel'] : '';;
    				$return ['address1'] = ! empty ( $site_data ['address1'] ) ? $site_data ['address1'] : '';
    				$return ['address2'] = ! empty ( $site_data ['address2'] ) ? $site_data ['address2'] : '';
    				$return ['city'] = ! empty ( $site_data ['city'] ) ? $site_data ['city'] : '';
    				$return ['state_name'] = $this->state_name;
                    $return ['idstate'] = ! empty ( $site_data ['idstate'] ) ? $site_data ['idstate'] : '';
    				$return ['postalcode'] = ! empty ( $site_data ['postalcode'] ) ? $site_data ['postalcode'] : '';
    				$return ['latitude'] = (! empty ( $site_data ['latitude'] ) && empty ( $return ['latitude'] )) ? $site_data ['latitude'] : '';
    				$return ['longitude'] = (! empty ( $site_data ['longitude'] ) && empty ( $return ['longitude'] )) ? $site_data ['longitude'] : '';
    			}
            }
            
            return $return;
        }
    }
	
	/**
	 * Function to add a new maintenanceinspection
	 */
	public function addmaintenanceinspection() {
		if (! $this->session->userdata ( 'logged_in' ) || $this->session->userdata ( 'idlocation' ) != 61) {
			redirect ( base_url () );
		} else {

			$data = $this->input->post('uploaddata');





			$this->inspector = $this->maintenanceinsp_model->getInspectors ();
			
			$this->form_validation->set_rules ( 'site', $this->lang->line('whthr_snsr_site_nm'), 'trim' );
			$this->form_validation->set_rules ( 'idsitetype', $this->lang->line('trap_mgmt_site_type'), 'trim' );
			$this->form_validation->set_rules ( 'idzone', 'Zone', 'trim' );
			
			$this->form_validation->set_rules ( 'latitude', $this->lang->line('site_mgmt_lat'), 'trim|required|numeric' );
			$this->form_validation->set_rules ( 'longitude', $this->lang->line('site_mgmt_lng'), 'trim|required|numeric' );
			$this->form_validation->set_rules ( 'idinspector', $this->lang->line('advrs_impct_inspctr_name'), 'trim|required' );
			
			$this->form_validation->set_rules ( 'observed_date', $this->lang->line('lnding_rte_obsrvd_dt'), 'trim|required' );
			$this->form_validation->set_rules ( 'observed_time', $this->lang->line('lnding_rte_obsrvd_tm'), 'trim|required' );
			$this->form_validation->set_rules ( 'owner_information', $this->lang->line('lnding_rte_obsrvd_dt'), 'trim|required' );
			$this->form_validation->set_rules ( 'parcel_number', $this->lang->line('lnding_rte_obsrvd_tm'), 'trim|required' );
			$this->form_validation->set_rules ( 'outfall_number', $this->lang->line('lnding_rte_obsrvd_dt'), 'trim|required' );
			$this->form_validation->set_rules ( 'local_contact', 'local contact required', 'trim|required' );
			$this->form_validation->set_rules ( 'last_observed_date', "last observed date required", 'trim|required' );
			
			$this->form_validation->set_rules ( 'maplabel', $this->lang->line('site_mgmt_map_lbl'), 'trim' );
			$this->form_validation->set_rules ( 'address1', $this->lang->line('site_mgmt_addrs_1'), 'trim' );
			$this->form_validation->set_rules ( 'address2', $this->lang->line('site_mgmt_addrs_2'), 'trim' );
			$this->form_validation->set_rules ( 'city', $this->lang->line('site_mgmt_cty'), 'trim' );
			$this->form_validation->set_rules ( 'postalcode', $this->lang->line('site_mgmt_postl_cde'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'comment', 'Comment', 'trim' );
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'page' => "maintenance_inspection",
					'idinspector' => $this->inspector,
					'sitegroup' => $this->sitegroup,
					'existing_site' => $this->maintenanceinsp_model->getSitename (),
					'site_type' => $this->site_model->getSitetypes (),
					'zone_name' => $this->maintenanceinsp_model->getSelectedZonename (),
					'state_name' => $this->site_model->getStates (),
					'state_list' => $this->maintenanceinsp_model->getStatebyName (),
					'observed_time' => $this->observed_time,
					'observed_date' => $this->observed_date,
                    'app_lang' => $this->app_lang 
			);
			
			if ($this->form_validation->run () == FALSE) {
				$data_1 ['msg'] = "error";
			} else {
				$flag =  $this->maintenanceinsp_model->addmaintenanceinspection ( $this->idlocation );
				//start of image uploading
				if(!empty($flag) && !empty($_FILES['userFiles']['name'])){
					$b=explode(',',$data);
							$a=$_FILES['userFiles']['name'];
							$filesCount = count($b);
							
					for($i = 0; $i < $filesCount; $i++){
						if(strpos( $data, (string)$_FILES['userFiles']['name'][$i] )){
							
							$timeStampData = microtime();
							list($msec, $sec) = explode(' ', $timeStampData);
							$msec = round($msec * 1000);
							$imgnumber = $sec . $msec;

							$_FILES['userFile']['name'] = $_FILES['userFiles']['name'][$i];
							$_FILES['userFile']['type'] = $_FILES['userFiles']['type'][$i];
							$_FILES['userFile']['tmp_name'] = $_FILES['userFiles']['tmp_name'][$i];
							$_FILES['userFile']['error'] = $_FILES['userFiles']['error'][$i];
							$_FILES['userFile']['size'] = $_FILES['userFiles']['size'][$i];
							$uploadPath = 'maintenanceinspectionimages/'.$flag.'/';
							if (!is_dir('maintenanceinspectionimages/'.$flag)) 
									mkdir('./maintenanceinspectionimages/' . $flag, 0777, TRUE);
							$config['upload_path'] = $uploadPath;
							$config['allowed_types'] = 'gif|jpg|png|jpeg|bmp';
							$config['file_name'] = "IMG_".$flag."_".$imgnumber;
							
							$this->load->library('upload', $config);
							$this->upload->initialize($config);
							if($this->upload->do_upload('userFile')){
								$type = explode( "." ,$_FILES['userFiles']['name'][$i]);
								$index = count($type) -1;
								$this->maintenanceinsp_model->saveImage($flag ,'maintenanceinspectionimages/'.$flag.'/'."IMG_".$flag."_".$imgnumber.".".$type[$index]);
								if($_FILES['userFile']['size'] > 512000){
									$config1['image_library'] = 'gd2';
									$config1['source_image'] = 'maintenanceinspectionimages/'.$flag.'/'."IMG_".$flag."_".$imgnumber.".".$type[$index];
									$config1['maintain_ratio'] = TRUE;
									$config1['width']         = 1000;
									$config1['height'] = 1000;
									$this->load->library('image_lib', $config1); 
									$this->image_lib->initialize($config1);
										if (!$this->image_lib->resize()) {
												echo $this->image_lib->display_errors();
										}
								}
							}
						}
					}
					
				}
				//end of image uploading
				if (! empty ( $flag ))
					$data_1 ['msg'] = "success";
				else
					$data_1 ['msg'] = "error";
			}
			
			$this->load->view ( 'maintenance_inspection/add_maintenanceinspection', $data_1 );
		}
	}
	
	/**
	 * Function to show edit maintenanceinspection
	 */
	public function showeditmaintenanceinspection() {
		if (! $this->session->userdata ( 'logged_in' ) || $this->session->userdata ( 'idlocation' ) != 61) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get_post ( 'id' );
			
            $mapFlag = $this->input->get_post ( 'mapFlag' );
            $mapSite = $this->input->get_post('idsite');
            
			if (empty ( $req ))
				echo "error";
			
			$flag = $this->maintenanceinsp_model->getmaintenanceinspection ( $req );
			
			$images = $this->maintenanceinsp_model->getImages($req);
			$this->site_id = $this->maintenanceinsp_model->getSitename ( $flag ['idsite'] );
			$this->zone_id = $this->maintenanceinsp_model->getzone ( $flag ['idsite'] );
			$this->site_type = $this->site_model->getSitetypes ();
			
			$sitedetails = $this->maintenanceinsp_model->getSiteDetails ( $flag ['idsite'] );
			$this->state_name = $this->site_model->getStates ();
      $this->idzone = $this->maintenanceinsp_model->getSelectedZonename ( ! empty ( $sitedetails ['idzone'] ) ? $sitedetails ['idzone'] : '');
			$this->inspector_name = $this->maintenanceinsp_model->getSelectedInspectors ( $flag ['idinspector'] );
			if (! empty ( $flag )) {
				$flag ['existing_site'] = $this->site_id;
				$flag ['site_type'] = $this->site_type;
				$flag ['idzone'] = $this->idzone;
				$flag ['address1'] = ! empty ( $sitedetails ['address1'] ) ? $sitedetails ['address1'] : '';
				$flag ['address2'] = ! empty ( $sitedetails ['address2'] ) ? $sitedetails ['address2'] : '';
				$flag ['city'] = ! empty ( $sitedetails ['city'] ) ? $sitedetails ['city'] : '';
				$flag ['state_name'] = $this->state_name;
				$flag ['postalcode'] = ! empty ( $sitedetails ['postalcode'] ) ? $sitedetails ['postalcode'] : '';
				$flag ['pdop'] = ! empty ( $sitedetails ['pdop'] ) ? $sitedetails ['pdop'] : '';
				$flag ['sitegroup'] = $this->sitegroup;
				$flag ['applicator'] = $this->inspector_name;
				$flag ['state_list'] = $this->maintenanceinsp_model->getStatebyName ();
				$flag ['images'] = $images;
                $flag ['idstate'] = !empty($sitedetails ['idstate']) ? $sitedetails ['idstate'] : '';
                $flag ['idsitetype'] = !empty($sitedetails ['idsitetype']) ? $sitedetails ['idsitetype'] : '';
                $flag ['app_lang'] = $this->app_lang;
                $mapSite = !empty($flag ['idsite']) ? $flag ['idsite'] : '';
			}
            $flag ['mapFlag'] = $mapFlag;
            $mapData = $this->getAllEventsData($mapSite);
            $flag = array_merge($flag, $mapData);
			$this->load->view ( 'maintenance_inspection/edit_maintenanceinspection', $flag );
		}
	}
	
	/**
	 * Function to save edit Adult Surveillance Values
	 */
	public function editmaintenanceinspection() {
		if (! $this->session->userdata ( 'logged_in' ) || $this->session->userdata ( 'idlocation' ) != 61) {
			redirect ( base_url () );
		} else {
			$id = $this->input->get_post ( 'idmaintenanceinspection' );
			if (empty ( $id )) {
				$flag ['msg'] = "error";
				$this->load->view ( 'maintenance_inspection/edit_maintenanceinspection', $flag );
			}
			$data = $this->input->post('uploaddata');
			$remove = $this->input->post('removedata');

			$flag = $this->maintenanceinsp_model->getmaintenanceinspection ( $id );
			$this->site_id = $this->maintenanceinsp_model->getSitename ( $flag ['idsite'] );
			$this->idsitetype = $this->site_model->getSitetypes ();
			$this->idzone = $this->maintenanceinsp_model->getSelectedZonename ( $flag ['idzone'] );
			$sitedetails = $this->maintenanceinsp_model->getSiteDetails ( $flag ['idsite'] );
			$this->state = $this->site_model->getStates ();
			$this->inspector_name = $this->maintenanceinsp_model->getSelectedInspectors ( $flag ['idinspector'] );
			
			if (! empty ( $flag )) {
				$flag ['images']=$this->maintenanceinsp_model->getImages($id);
				$flag ['existing_site'] = $this->site_id;
				$flag ['idsitetype'] = $this->idsitetype;
				$flag ['idzone'] = $this->idzone;
				$flag ['address1'] = ! empty ( $sitedetails ['address1'] ) ? $sitedetails ['address1'] : '';
				$flag ['address2'] = ! empty ( $sitedetails ['address2'] ) ? $sitedetails ['address2'] : '';
				$flag ['sitegroup'] = $this->sitegroup;
				$flag ['applicator'] = $this->inspector_name;
				$flag ['city'] = ! empty ( $sitedetails ['city'] ) ? $sitedetails ['city'] : '';
				$flag ['state'] = $this->state;
				$flag ['postalcode'] = ! empty ( $sitedetails ['postalcode'] ) ? $sitedetails ['postalcode'] : '';
				$flag ['latitude'] = ! empty ( $sitedetails ['latitude'] ) ? $sitedetails ['latitude'] : '';
				$flag ['longitude'] = ! empty ( $sitedetails ['longitude'] ) ? $sitedetails ['longitude'] : '';
				$flag ['pdop'] = ! empty ( $sitedetails ['pdop'] ) ? $sitedetails ['pdop'] : '';
				$flag ['state_list'] = $this->maintenanceinsp_model->getStatebyName ();
                $flag ['idstate'] = !empty($sitedetails ['idstate']) ? $sitedetails ['idstate'] : '';
			}
			 
			if (! $this->session->userdata ( 'logged_in' ) || $this->session->userdata ( 'idlocation' ) != 61) {
				$flag ['msg'] = "error";
			} else {
				$this->form_validation->set_rules ( 'site', $this->lang->line('whthr_snsr_site_nm'), 'trim' );
			$this->form_validation->set_rules ( 'idsitetype', $this->lang->line('trap_mgmt_site_type'), 'trim' );
			$this->form_validation->set_rules ( 'idzone', 'Zone', 'trim' );
			
			$this->form_validation->set_rules ( 'latitude', $this->lang->line('site_mgmt_lat'), 'trim|required|numeric' );
			$this->form_validation->set_rules ( 'longitude', $this->lang->line('site_mgmt_lng'), 'trim|required|numeric' );
			$this->form_validation->set_rules ( 'idinspector', $this->lang->line('advrs_impct_inspctr_name'), 'trim|required' );
			
			$this->form_validation->set_rules ( 'observed_date', $this->lang->line('lnding_rte_obsrvd_dt'), 'trim|required' );
			$this->form_validation->set_rules ( 'observed_time', $this->lang->line('lnding_rte_obsrvd_tm'), 'trim|required' );
			$this->form_validation->set_rules ( 'owner_information', $this->lang->line('lnding_rte_obsrvd_dt'), 'trim|required' );
			$this->form_validation->set_rules ( 'parcel_number', $this->lang->line('lnding_rte_obsrvd_tm'), 'trim|required' );
			$this->form_validation->set_rules ( 'outfall_number', 'invalid outfall ', 'trim|required' );
			$this->form_validation->set_rules ( 'local_contact', 'local contact required', 'trim|required' );
			$this->form_validation->set_rules ( 'last_observed_date', "last observed date required", 'trim|required' );
			
			$this->form_validation->set_rules ( 'maplabel', $this->lang->line('site_mgmt_map_lbl'), 'trim' );
			$this->form_validation->set_rules ( 'address1', $this->lang->line('site_mgmt_addrs_1'), 'trim' );
			$this->form_validation->set_rules ( 'address2', $this->lang->line('site_mgmt_addrs_2'), 'trim' );
			$this->form_validation->set_rules ( 'city', $this->lang->line('site_mgmt_cty'), 'trim' );
			$this->form_validation->set_rules ( 'postalcode', $this->lang->line('site_mgmt_postl_cde'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'comment', 'Comment', 'trim' );
			
				$req = $this->input->get_post ( 'idmaintenanceinspection' );
				
				if (empty ( $req ))
					$this->flag ['msg'] = "error";
				
				if ($this->form_validation->run () == FALSE)
					$flag ['msg'] = "error";
				else {
						$flag1 = $this->maintenanceinsp_model->updateMaintenanceinspection ( $req, $this->idlocation );
						if (! empty ( $flag1 ))
						$flag ['msg'] = "updated";
					else
						$flag ['msg'] = "error";
						
	//start of image uploading
						if(!empty($req) && !empty($_FILES['userFiles']['name'])&& $flag ['msg']!= "error"){
						$b=explode(',',$data);
							$a=$_FILES['userFiles']['name'];
							$filesCount = count($b);

									for($i=0; $i < $filesCount; $i++){
								if(strpos( $data, (string)$_FILES['userFiles']['name'][$i] )){
									
									$timeStampData = microtime();
									list($msec, $sec) = explode(' ', $timeStampData);
									$msec = round($msec * 1000);
									$imgnumber = $sec . $msec;
									$_FILES['userFile']['name'] = $_FILES['userFiles']['name'][$i];
									$_FILES['userFile']['type'] = $_FILES['userFiles']['type'][$i];
									$_FILES['userFile']['tmp_name'] = $_FILES['userFiles']['tmp_name'][$i];
									$_FILES['userFile']['error'] = $_FILES['userFiles']['error'][$i];
									$_FILES['userFile']['size'] = $_FILES['userFiles']['size'][$i];
									$uploadPath = 'maintenanceinspectionimages/'.$req.'/';
									if (!is_dir('maintenanceinspectionimages/'.$req)) 
											mkdir('./maintenanceinspectionimages/' . $req, 0777, TRUE);
									$config['upload_path'] = $uploadPath;
									$config['allowed_types'] = 'gif|jpg|png|jpeg|bmp';
									$config['file_name'] = "IMG_".$req."_".$imgnumber;
									$this->load->library('upload', $config);
									$this->upload->initialize($config);
									if($this->upload->do_upload('userFile')){
										$fileData = $this->upload->data();
										$type = explode( "." ,$_FILES['userFiles']['name'][$i]);
										$index = count($type) -1;
										$this->maintenanceinsp_model->saveImage($req ,'maintenanceinspectionimages/'.$req.'/'."IMG_".$req."_".$imgnumber.".".$type[$index]);
										if($_FILES['userFile']['size'] > 512000){
											$config1['image_library'] = 'gd2';
											$config1['source_image'] = 'maintenanceinspectionimages/'.$req.'/'."IMG_".$req."_".$imgnumber.".".$type[$index];
											$config1['maintain_ratio'] = TRUE;
											$config1['width']         = 1000;
											$config1['height'] = 1000;
											$this->load->library('image_lib', $config1); 
											$this->image_lib->initialize($config1);
												if (!$this->image_lib->resize()) {
														echo $this->image_lib->display_errors();
												}
										}
									}else{
										echo "error: " .$this->upload->display_errors('<p>', '</p>');
										$flag ['msg'] = "error";break;
									}
								}
							}
							
						}
					//end of image uploading
					if(!empty($remove) && !empty($req)&& $flag ['msg']!= "error"){
							$remove = str_replace(array("[" , "]" ,'"' ) , "" , $remove);
							$remove = explode(",", $remove);
							if(!empty($remove)){
								foreach($remove as $image){
									$deleted =$this->maintenanceinsp_model->removeImage($image);
										unlink($image);
								}
							}
						}
				}
			}
            $flag ['app_lang'] = $this->app_lang;
			$this->load->view ( 'maintenance_inspection/edit_maintenanceinspection', $flag );
		}
	}
	
	/**
	 * Function to delete maintenanceinspection
	 */
	public function deletemaintenanceinspection() {
		if (! $this->session->userdata ( 'logged_in' ) || $this->session->userdata ( 'idlocation' ) != 61) {
			redirect ( base_url () );
		} else {
			$flag = $this->maintenanceinsp_model->deleteMaintenanceinspection ();
			
			$msg = "";
			
			if ($flag){
				$msg = "success";
			}
			else
				$msg = "error";
			
			$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
			if (! empty ( $seturl [1] ))
				redirect ( $seturl [0] . "?del=" . $msg . "#" . $seturl [1] );
			else
				redirect ( $seturl [0] . "?del=" . $msg );
		}
	}
	
	/**
	 * Function to display List Of adultsurveillances
	 */
	public function getmaintenanceinspection($grid = '') {
		if (! $this->session->userdata ( 'logged_in' ) || $this->session->userdata ( 'idlocation' ) != 61) {
			redirect ( base_url () );
		} else {
			$filter_date = $this->input->post ( 'filter_date' );
			$msg = $this->input->get ( 'msg' );
			$columns = array (
					0 => array (
							'name' => $this->lang->line('whthr_snsr_site_nm'),
							'db_name' => 'idsite',
							'header' => $this->lang->line('whthr_snsr_site_nm'),
							'group' => 'maintenanceinspection',
							'ref_table_id_name' => 'idsite',
							'ref_table_db_name' => 'sites',
							'ref_field_db_name' => 'site',
							'ref_field_type' => 'string',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-n' 
					),
					
					1 => array (
							
							'name' => $this->lang->line('whthr_snsr_inspctr'),
							'db_name' => 'idinspector',
							'header' => $this->lang->line('whthr_snsr_inspctr'),
							'group' => 'outfallinspection',
							'ref_table_id_name' => 'iduser',
							'ref_table_db_name' => 'users',
							'ref_field_db_name' => 'firstname',
							'ref_field_2_db_name' => 'middlename',
							'ref_field_3_db_name' => 'lastname',
							'ref_field_type' => 'string',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-1+2+3'
					),
					2 => array (
							'name' => $this->lang->line('lnding_rte_obsrvd_dt'),
							'db_name_1' => 'observeddate',
							'db_name_2' => 'observedtime',
							'header' => $this->lang->line('lnding_rte_obsrvd_dt'),
							'group' => 'maintenanceinspection',
							'type' => '1+2'
					),
					3 => array (
							'name' => 'Parcel#',
							'db_name' => 'parcelnumber',
							'header' => 'Parcel #',
							'group' => 'maintenanceinspection',
							'form_control' => 'text_long' 
					),
					4 => array (
							'name' => 'Outfall#',
							'db_name' => 'outfallnumber',
							'header' => 'Outfall #',
							'group' => 'maintenanceinspection',
							'type' => 'string' 
					) 
			);
			$data_1 = array (
					'existing_site' => addslashes ( $this->maintenanceinsp_model->getSitename () ),
					'site_type' => $this->maintenanceinsp_model->getSelectedSitetype (),
					'zone_name' => $this->maintenanceinsp_model->getSelectedZonename (),
					'state_name' => $this->maintenanceinsp_model->getStatename (),
					'state_list' => $this->maintenanceinsp_model->getStatebyName (),
					'idinspector' => $this->maintenanceinsp_model->getInspectors (),
					'observed_time' => date_default_timezone_get (),
                    'app_lang' => $this->app_lang 
			);
			
			$commands ['delete'] ['toolbar'] = FALSE;
			$add_view = $this->load->view ( 'maintenance_inspection/add_maintenanceinspection', $data_1, TRUE );
			
			$data_1 = array (
					'state_list' => $this->maintenanceinsp_model->getStatebyName () 
			);
			$edit_view = $this->load->view ( 'maintenance_inspection/edit_maintenanceinspection', $data_1, TRUE );
			$params = array (
					'id' => 'idmaintenanceinspection',
					'table' => 'maintenanceinspection',
					'url' => 'maintenance_inspection/getmaintenanceinspection',
					'uri_param' => $grid,
					'order' => array (
							2 => 'desc' 
					),
					'columns' => $columns,
					'filter_date' => ! empty ( $filter_date ) ? $filter_date : '2',
					'filters' => array (
							0 => array (
									'value' => $this->idlocation 
							) 
					),
					// 'columns_visible' => array(0,1,2),
					'commands' => $commands,
					'ajax' => TRUE,
					'msc_url' => array (
							'excel_url' => base_url () . 'maintenance_inspection/toExcelAll',
							'pdf_url' => base_url () . 'maintenance_inspection/toPdfAll',
							'text' => 'Maintenance Inspection' 
					),
					'add_view' => $add_view,
					'edit_view' => $edit_view 
			);
			$newdata = array (
					'url' => base_url () . $params ['url'] . '#' . $params ['id'] . '=' . $grid 
			);
			
			$this->session->set_userdata ( $newdata );
			
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => "Maintenance Inspection",
					'page' => "maintenance_inspection",
                    'app_lang' => $this->app_lang
			);
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			
			// Pass grid to the view
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			$data->msg = $msg;
			$data->mapdata = base_url () . "maintenance_inspection/showmap";
			
			$this->load->view ( 'maintenance_inspection/inspection', $data );
		}
		$this->load->view ( 'footer' );
	}
	public function showmap() {
		$query ['data'] = $this->maintenanceinsp_model->getMapdata ();
		$query ['user_loc'] = $this->adultsurveillance_model->getUserLoc ();
		$query ['zone_loc'] = $this->zone_model->getZoneCord ();
		$query ['googlezoom'] = $this->session->userdata ( 'googlezoom' );
		$this->load->view ( 'maintenance_inspection/map_view', $query );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function getadultsurveillancedata() {
		$id = $this->input->post ( 'idadultsurveillance' );
		
		if (empty ( $id )) {
			echo "error";
			exit ();
		}
		
		$data = $this->adultsurveillance_model->getAdultsurveillanceData ( $id );
		
		echo json_encode ( $data );
	}
	
	
	

	public function removeImg(){
		 $condition = $this->input->post('cond');
		 $data = $this->input->post('data');
		if($condition ==1){
			array_push(Maintenance_inspection::$removedImages ,$data );
		}
		else
			Maintenance_inspection::$removedImages =[];
	}



	
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function toExcelAll() {
		if (! $this->session->userdata ( 'logged_in' ) || $this->session->userdata ( 'idlocation' ) != 61) {
			redirect ( base_url () );
		} else {
			$query ['data'] = $this->maintenanceinsp_model->listMaintenanceinspection ();
			$this->load->view ( 'maintenance_inspection/excel_view', $query );
		}
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
		if (! $this->session->userdata ( 'logged_in' ) || $this->session->userdata ( 'idlocation' ) != 61) {
			redirect ( base_url () );
		} else {
			$this->load->helper ( 'pdf_helper' ); // Load helper
			$query ['data'] = $this->maintenanceinsp_model->listMaintenanceinspection ();
			$data = $this->load->view ( 'maintenance_inspection/pdf_view', $query, true );
			create_pdf ( $data, 'Maintenance Inspection' ); // Create pdf
		}
	}
    
    /**
	 * Function to fetch all site data based on module
	 */
	public function getAllEventsData($idsite = "") {
        $params = array (
            'idsite' => $idsite,
            'idlocation' => $this->session->userdata('idlocation')
        );
        
        $this->load->library ( 'common', $params );
        
        $response = $this->common->getAllEventsData ();
        //print'<pre>';
//        print_r($response);
//        die;
        return $response;
    }

    public function convertintopdf() {
	if (! $this->session->userdata ( 'logged_in' ) || $this->session->userdata ( 'idlocation' ) != 61) {
			redirect ( base_url () );
		} else {
  $id =$this->input->get_post ( 'id' );

$this->load->database();
$this->load->helper ( 'pdf_helper' ); // Load helper
$this->db->select ( '*' );
		$this->db->from ( 'maintenanceinspection as m' );
		//$this->db->join ( 'mirimages AS i', ' m.idmaintenanceinspection =i.idmaintenanceinspection', 'LEFT' );
		$this->db->join ( 'users', ' m.idinspector=users.iduser ', 'LEFT' );
		$this->db->join ( 'sites AS s', 'm.idsite = s.idsite', 'LEFT' );
		$this->db->where ( 'm.isdeleted', '0' );
		//$this->db->where ( 'i.isdeleted', '0' );
		$this->db->where ( '`m`.`idmaintenanceinspection`', $id );
		$query = $this->db->get ();
        $data['records'] = $query->result();        
//         $this->db->select ( '`mirimages`.*' );
// 		$this->db->from ( 'mirimages' );
// 		$this->db->where ( '`mirimages`.`idmaintenanceinspection`', $id );
// 		$query = $this->db->get ();
// 	    $data['images'] = $query->result();
// $data=Array('images' => $images,'records'=>$records);
     
//      var_dump($images);
 
      $data = $this->load->view ( 'maintenance_inspection/maintenance_pdf_view', $data, true );
create_pdf ( $data, 'Maintenance Inspection' ); // Create pdf
}
		
	}
}

/* End of file maintenanceinspection.php */
/* Location: ./application/controllers/maintenanceinspection.php */