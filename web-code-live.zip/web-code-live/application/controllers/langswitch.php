<?php

/**
 * @author Skysoft Incorporated
 * @copyright 2015
 */

class LangSwitch extends CI_Controller
{
    public function __construct() {
        parent::__construct();
        $this->load->helper('url');
    }

    function switchLanguage($language = "") {
        $language = ($language != "") ? $language : "en";
        $this->session->set_userdata('app_lang', $language);
        redirect(base_url());
    }
}

?>