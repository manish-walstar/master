<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
/**
 * Truck
 *
 * @package
 *
 * @author Skysoft Incorporated
 * @copyright 2014
 * @version $Id$
 * @access public
 */
class Truck extends CI_Controller {
	public $idlocation = "";
	public $idtruck;
	public $vehicletypes;
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		$this->idsentinel = $this->input->get ( 'idsentinel' );
        
        $this->load->helper('language');
		$this->load->model ( 'truck_model' );
		$this->vehicletypes = $this->truck_model->getVehicles ();

        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		if ($this->session->userdata ( 'logged_in' )) {
			$this->idlocation = $this->session->userdata ( 'idlocation' );
		}
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			redirect ( base_url () . "truck/gettruck" );
		}
	}
	
	/**
	 * Function to add a new truck
	 */
	public function addtruck() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$idtruck = $this->input->post ( 'x_s_' );
			
			if (! empty ( $idtruck )) {
				$flag = $this->truck_model->getTruckData ( $idtruck );
			}
			
			$this->form_validation->set_rules ( 'name', $this->lang->line('fleet_trck_name'), 'trim|required' );
			$this->form_validation->set_rules ( 'vehicletype', $this->lang->line('fleet_vhcl_type'), 'trim|xss_clean' );
			$this->form_validation->set_rules ( 'make', $this->lang->line('fleet_make'), 'trim|xss_clean' );
			$this->form_validation->set_rules ( 'model', $this->lang->line('fleet_model'), 'trim|xss_clean' );
			$this->form_validation->set_rules ( 'modelyear', $this->lang->line('fleet_model_yr'), 'trim|xss_clean' );
			
			if ($this->form_validation->run () == FALSE) {
				$data ['msg'] = "error";
			} else {
				$flag = $this->truck_model->addtruck ( $idtruck );
				
				if (! empty ( $flag ) && empty ( $idtruck )) {
					$data ['msg'] = "success";
				} else if (! empty ( $flag ) && ! empty ( $idtruck )) {
					$data ['msg'] = "update";
				} else if (empty ( $flag )) {
					$data ['msg'] = "error";
				}
			}
            $data['app_lang'] = $this->app_lang;
            
			if (! empty ( $idtruck ))
				$this->load->view ( 'trucks/edit_truck', $data );
			else
				$this->load->view ( 'trucks/add_truck', $data );
		}
	}
	
	/**
	 */
	public function addtruckpop() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->idtruck = $this->input->get ( 'idtruck' );
			$data = array (
					'idtruck' => $this->idtruck,
					'vehicletypes' => $this->vehicletypes,
                    'app_lang' => $this->app_lang 
			);
			
			$this->load->view ( 'trucks/add_truck', $data );
		}
	}
	
	/**
	 */
	public function editpopuptruck() {
		if (! $this->session->userdata ( 'logged_in' ))
			redirect ( base_url () );
		else {
			$idtruck = $this->input->get_post ( 'id' );
			
			if (empty ( $idtruck )) {
				$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
				$grd = explode ( "=", $seturl [1] );
				if (! empty ( $grd [1] )) {
					redirect ( $seturl [0] . "#" . $seturl [1] );
				} else {
					redirect ( $seturl [0] );
				}
			}
			
			$data = $this->truck_model->getTruckData ( $idtruck );
			$data ['vehicletypes'] = $this->vehicletypes;
            $data['app_lang'] = $this->app_lang;
			$this->load->view ( 'trucks/edit_truck', $data );
		}
	}
	
	/**
	 * Function to delete truck
	 */
	public function deletetruck() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->truck_model->deleteTruck ();
			
			$msg = "";
			
			if ($flag)
				$msg = "success";
			else
				$msg = "error";
			
			$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
			$grd = explode ( "=", $seturl [1] );
			if (! empty ( $grd [1] )) {
				redirect ( $seturl [0] . "?del=" . $msg . "#" . $seturl [1] );
			} else {
				redirect ( $seturl [0] . "?del=" . $msg );
			}
			
			// redirect(base_url().'truck/gettruck?idsentinel='.$this->idsentinel.'&del='.$msg);
		}
	}
	
	/**
	 * Function to display List Of trucks
	 */
	public function gettruck($grid = '', $msg = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$columns = array (
					0 => array (
							'name' => $this->lang->line('prdct_ovrvw_nme'),
							'db_name' => 'name',
							'header' => $this->lang->line('prdct_ovrvw_nme'),
							'group' => 'Trucks',
							'form_control' => 'text_long' 
					),
					1 => array (
							'name' => $this->lang->line('fleet_vhcl_type'),
							'db_name' => 'vehicletype',
							'header' => $this->lang->line('fleet_vhcl_type'),
							'group' => 'Trucks',
							'ref_table_id_name' => 'idvehicletype',
							'ref_table_db_name' => 'vehicletypes',
							'ref_field_db_name' => 'vehicletype',
							'ref_field_type' => 'string',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-n' 
					),
					2 => array (
							'name' => $this->lang->line('fleet_make'),
							'db_name' => 'make',
							'header' => $this->lang->line('fleet_make'),
							'group' => 'Trucks',
							'required' => TRUE,
							'form_control' => 'text_long' 
					),
					3 => array (
							'name' => $this->lang->line('fleet_model'),
							'db_name' => 'model',
							'header' => $this->lang->line('fleet_model'),
							'group' => 'Trucks',
							'required' => TRUE,
							'form_control' => 'text_long' 
					),
					4 => array (
							'name' => $this->lang->line('fleet_model_yr'),
							'db_name' => 'modelyear',
							'header' => $this->lang->line('fleet_model_yr'),
							'group' => 'Trucks',
							'required' => TRUE,
							'form_control' => 'text_long' 
					) 
			);
			
			$commands ['delete'] ['toolbar'] = FALSE;
			
			$add_view = $this->load->view ( 'trucks/add_truck', '', TRUE );
			$edit_view = $this->load->view ( 'trucks/edit_truck', '', TRUE );
			$params = array (
					'id' => 'idtruck',
					'table' => 'trucks',
					'url' => 'truck/gettruck',
					'uri_param' => $grid,
					'columns' => $columns,
					// 'para' => $this->idsentinel,
					// 'columns_visible' => array(0,1),
					'order' => array (
							0 => 'desc' 
					),
					'filters' => array (
							0 => array (
									'value' => $this->idlocation 
							) 
					),
					'commands' => $commands,
					'ajax' => TRUE,
					'msc_url' => array (
							'excel_url' => base_url () . 'truck/toExcelAll',
							'pdf_url' => base_url () . 'truck/toPdfAll',
							'text' => 'Truck' 
					),
					'add_view' => $add_view,
					'edit_view' => $edit_view 
			);
			
			$newdata = array (
					'url' => base_url () . $params ['url'] . '#' . $params ['id'] . '=' . $grid 
			);
			
			$this->session->set_userdata ( $newdata );
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('fleet_hdng'),
					'page' => "truck_mngmnt",
                    'app_lang' => $this->app_lang 
			);
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			
			// Pass grid to the view
            $data = (object)array();
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			$data->msg = $msg;
			
			$this->load->view ( 'trucks/trucks', $data );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function toExcelAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$query ['data'] = $this->truck_model->listTrucks ();
			// print'<pre>';
			// print_r($query['data']);
			// die;
			$this->load->view ( 'trucks/excel_view', $query );
		}
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->helper ( 'pdf_helper' ); // Load helper
			$query ['data'] = $this->truck_model->listTrucks ();
			
			$data = $this->load->view ( 'trucks/pdf_view', $query, true );
			//
			// print'<pre>';
			// print_r($data);
			// die;
			
			create_pdf ( $data, $this->lang->line('fleet_trcks') ); // Create pdf
		}
	}
}

/* End of file truck.php */
/* Location: ./application/controllers/truck.php */