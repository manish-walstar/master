<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Webservice extends CI_Controller {
	public function __construct() {
		parent::__construct ();
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->model ( 'webservice_model' );
			$this->load->model ( 'arbovirallab_model', 'am' );
		}
	}
	public function chickenlab() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
            echo '<style>body {
                        background: url("../images/body-bg.png") repeat scroll 0 0 rgba(0, 0, 0, 0);
                    }</style>
                <div style="padding-top:40px;text-align: center">';		  
            $sentinel_chicken_lab_data = $this->webservice_model->chicken_sential_lab ();
			$arr_records = $response = array ();
			$send = 0;
			if (!empty($sentinel_chicken_lab_data)) {
				foreach ( $sentinel_chicken_lab_data as $key => $value ) {
					$year = date ( 'Y', strtotime ( $value ['datesubmitted'] ) );
					$collectionid = $value ['idsentinelchicken'];
					$collectiondate = $value ['datebled'];
					$collector = ''; // $value[''];
					
					$chicken_data = $this->webservice_model->get_chicken_data ( $collectionid );
					if ($chicken_data) {
						$flockatsite = $chicken_data ['idsite'];
						$site = $chicken_data ['idsite'];
					} else {
						$flockatsite = '';
						$site = '';
					}
					$bands = array ();
					$sample_data = $this->webservice_model->get_chicken_sample ( $collectionid );
					if ($sample_data) {
						foreach ( $sample_data as $key_sample => $value_sample ) {
							array_push ( $bands, $value_sample ['bandid'] );
						}
					}
					$comments = $value ['comments'];
					$iswholeblood = ''; // $value[''];
					$issubmissionform = ''; // $value[''];
					$arr_records = array (
							"site" => $site,
							"year" => $year,
							"collectionid" => $collectionid,
							"flockatsite" => $flockatsite,
							"collectiondate" => $collectiondate,
							"collector" => $collector,
							"bandset" => $bands,
							"comments" => $comments,
							"wholeblood" => $iswholeblood,
							"issubmissionform" => $issubmissionform 
					);
					
					$insert = array (
							"recordset" => array (
									array (
											"type" => "sentinel",
											"subtype" => "bleed",
											"record" => array (
													$arr_records 
											) 
									) 
							) 
					);
                    $result = $this->send_data ( $insert );
					if ($result) {
						$this->webservice_model->update_sent_chicken_sential_lab ($value ['idsentinelchickenlab'] );
						$send = 1;
					}
                    array_push($response, $result);
				}
                
                if(!empty($response)) {
                    $response = $this->collectAllMessages($response);                
                    if(!empty($response['Success'])) {
                        echo "<div><div>--------------------Success Message(s)--------------------</div>";
                        foreach($response['Success'] as $key => $val) {
                            echo "<div>".$val."</div>";
            			}
                        echo "</div>";
                    }
        			
                    if(!empty($response['Error'])) {
                        echo "<div><div>--------------------Error Message(s)--------------------</div>";
                        foreach($response['Error'] as $key => $val) {
                            echo "<div>".$val."</div>";
            			}
                        echo "</div>";
                    }
                    
                    if(!empty($response['Warning'])) {
                        echo "<div><div>--------------------Warning Message(s)--------------------</div>";
                        foreach($response['Warning'] as $key => $val) {
                            echo "<div>".$val."</div>";
            			}
                        echo "</div>";
                    }
                } else {
                    echo "<div>--------------------No message(s) returned--------------------</div>";
                }
			} else {
                echo "<div>--------------------No record(s) left to send--------------------</div>";
            }
            
			echo '</div>';
		}
	}
	public function sentinelflocks() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$chicken_data = $this->webservice_model->get_sentinel_chicken ();
			$arr_records = array ();
			$arr_records_1 = array ();
			foreach ( $chicken_data as $key => $value ) {
				$year = date ( 'Y', strtotime ( $value ['date'] ) );
				$site = $value ['idsite'];
				$sample_data = $this->webservice_model->get_chicken_sample ( $value ['idsentinelchicken'] );
				$bandid = $sample_data ['bandid'];
				$comments = '';
				$flockname = $value ['flockname'];
				$date = $value ['date'];
				$maplabel = $value ['maplabel'];
				$latitude = $value ['latitude'];
				$longitude = $value ['longitude'];
				$isdeleted = $value ['isdeleted'];
				$idlocation = $value ['idlocation'];
				$dateadded = $value ['dateadded'];
				$arr_records_1 = array (
						"year" => $year,
						"site" => $site,
						"bandid" => $bandid,
						"comments" => $comments,
						"flockname" => $flockname,
						"date" => $date,
						"maplabel" => $maplabel,
						"latitude" => $latitude,
						"longitutde" => $longitude,
						"isdeleted" => $isdeleted,
						"idlocation" => $idlocation,
						"dateadded" => $dateadded 
				);
				array_push ( $arr_records, $arr_records_1 );
			}
			
			$insert = array (
					"recordset" => array (
							array (
									"type" => "sentinel",
									"subtype" => "bleed",
									"record" => $arr_records 
							) 
					) 
			);
			$this->send_data ( $insert );
		}
	}
	public function sendSingleSite() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$id = $this->input->get ( 'id' );
			$this->webservice_model->sendSingleSite ( $id );
		}
	}
	public function sites($table = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$sites = $this->webservice_model->get_sites ( '', $table );
			$arr_records = array ();
			$tempSite = array ();
			if (! empty ( $sites )) {
				foreach ( $sites as $key => $value ) {
					$Site_Code = $value ['idsite'];
					$Site_Name = $value ['site'];
					if (empty ( $value ['latitude'] ) || $value ['latitude'] == '0.0000000000') {
						$latitude = $this->decToDms ( 28.7913728000 );
						$degLat = $latitude ['deg'];
						$minLat = $latitude ['min'];
						$secLat = $latitude ['sec'];
					} else {
						$latitude = $this->decToDms ( $value ['latitude'] );
						$degLat = $latitude ['deg'];
						$minLat = $latitude ['min'];
						$secLat = $latitude ['sec'];
					}
					
					if (empty ( $value ['longitude'] ) || $value ['longitude'] == '0.0000000000') {
						$longitude = $this->decToDms ( - 81.2268175000 );
						$degLng = $longitude ['deg'];
						$minLng = $longitude ['min'];
						$secLng = $longitude ['sec'];
					} else {
						$longitude = $this->decToDms ( $value ['longitude'] );
						$degLng = $longitude ['deg'];
						$minLng = $longitude ['min'];
						$secLng = $longitude ['sec'];
					}
					
					$elvation = '';
					$address1 = $value ['address1'];
					$address2 = $value ['address2'];
					$city = $value ['city'];
					$country = 'USA';
					$state = $value ['stateabbrev'];
					$county = 'Napa';
					$postalcode = $value ['postalcode'];
					$surroundings = $value ['sitetype'];
					$population = '';
					$comments = '';
					$usedranges = '';
					$availableranges = '';
					// echo "Addr1 ".$address1." <br>Addr2 ".$address2." <br>City ".$city." <br>Pos ".$postalcode." <br>State ".$state."<br>";
					// echo "<br>-----------------------------------------------------<br>";
					if (! empty ( $address1 ) && ! empty ( $city ) && ! empty ( $postalcode ) && ! empty ( $state )) {
						$arr_records_1 = array (
								"code" => $Site_Code,
								"name" => $Site_Name,
								"coordinates" => array (
										"latitude" => array (
												"degrees" => $degLat,
												"minutes" => $minLat,
												"seconds" => $secLat 
										),
										"longitude" => array (
												"degrees" => $degLng,
												"minutes" => $minLng,
												"seconds" => $secLng 
										) 
								),
								"elevation" => $elvation,
								"address" => array (
										array (
												"primary" => $address1 . ' ' . $address2 
										),
										array (
												"city" => $city 
										),
										array (
												"postal" => $postalcode 
										),
										array (
												"county" => $county 
										),
										array (
												"state" => $state 
										),
										array (
												"country" => $country 
										) 
								),
								"population" => $population,
								"comments" => $comments,
								"landusage" => $usedranges 
						);
						array_push ( $arr_records, $arr_records_1 );
						array_push ( $tempSite, $value ['idsite'] );
					}
				}
				
				if (! empty ( $arr_records )) {
					$insert = array (
							"recordset" => array (
									array (
											"type" => "site",
											"record" => $arr_records 
									) 
							) 
					);
					// print'<pre>';
					// print_r($insert);
					// die;
					$flag = $this->send_data ( $insert );
					if ($flag)
						$this->webservice_model->setImported ( 'sites', 'idsite', $tempSite );
				}
			}
		}
	}
	
	/**
	 * This function is called on click of
	 * Export Button on Arboviral lab
	 */
	public function importArboviral() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->sites ( 'arbovirallabs' );
			$as_data = $this->webservice_model->getArboviral ();
			$arr_records = array ();
			$insert = array ();
			$sendSite = array ();
			$sendSiteError = array ();
			
			// print'<pre>';
			// print_r($as_data);
			// die;
			if (! empty ( $as_data )) {
				foreach ( $as_data as $key => $value ) {
					$site_code = '';
					$arr_species = array (
							"genus" => $value->mosquitospecies,
							"species" => $value->genus 
					);
					if (empty ( $value->latitude ) || $value->latitude == '0.0000000000')
						$latitude = 28.7913728000;
					else
						$latitude = $value->latitude;
					
					if (empty ( $value->longitude ) || $value->longitude == '0.0000000000')
						$longitude = - 81.2268175000;
					else
						$longitude = $value->longitude;
					
					if (! empty ( $value->idsite ) && $this->webservice_model->chkSite ( $value->idsite )) {
						$sendSite = $this->webservice_model->sendSingleSite ( $value->idsite );
						$site_code = $sendSite ['SITE_CODE'];
						// echo " <br> In ChkSite $site_code <br>";
					} else if (! empty ( $value->idsite ) && $this->webservice_model->chkSentSite ( $value->idsite )) {
						$sendSite = $this->webservice_model->chkSentSite ( $value->idsite );
						$site_code = $sendSite;
						// echo " <br> In ChkSentSite $site_code <br>";
					}
					// die($site_code);
					if (! empty ( $sendSite->Error ) || ! empty ( $sendSite->Warning ))
						array_push ( $sendSiteError, $sendSite );
					
					if (! empty ( $value->labassayid ) && ! empty ( $value->collection_date ) && ($value->poolsize >= 1 && $value->poolsize <= 60))
						$arr_records_1 = array (
								"number" => $value->labassayid,
								"site" => $site_code,
								// "coordinates" => array(
								// "latitude" => $latitude,
								// "longitude" => $longitude
								// ),
								"trap" => ! empty ( $value->traptypeAcronym ) ? $value->traptypeAcronym : 'OTHER',
								"collectiondate" => $value->collection_date,
								"taxonomy" => $arr_species,
								"condition" => "mixed",
								"sex" => "f",
								"count" => $value->poolsize 
						);
						
						// print'<pre>';
						// echo "<br> ---------------------Value------------------------ <br>";
						// print_r($value);
						// echo "<br> ---------------------ARR RECORD 1------------------------ <br>";
						// print_r($arr_records_1);
						// echo "<br> ---------------------Site Error------------------------ <br>";
						// print_r($sendSiteError);
						
					// if(!empty($arr_records_1) && !empty($site_code))
						// array_push($arr_records, $arr_records_1);
					
					if (! empty ( $arr_records_1 )) {
						$insert = array (
								"recordset" => array (
										array (
												"type" => "arthro",
												"subtype" => "pool",
												"record" => array (
														0 => $arr_records_1 
												) 
										) 
								) 
						);
						// print'<pre>';
						// print_r($insert);
						$send = $this->send_data ( $insert );
						
						// print_r($send);
						// continue;
						if (! empty ( $send->Success ))
							$this->webservice_model->setImported ( 'arbovirallabs', 'idarbovirallab', array (
									0 => $value->idarbovirallab 
							) );
						
						if (! empty ( $send ))
							array_push ( $sendSiteError, $send );
					}
				}
			}
			// print'<pre>';
			// print_r($sendSiteError);
			// die("here");
			
			echo json_encode ( $sendSiteError );
			exit ();
		}
	}
	public function importLabAssay() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$import = array (
					"type" => "arthro",
					"subtype" => "pool",
					"filter" => array (
							"collectiondate" => array (
									"from" => date ( 'Y-m-d', strtotime ( "-6 month" ) ),
									"to" => date ( 'Y-01-01', strtotime ( "+1 year" ) ) 
							),
							"result" => 1 
					) 
			);
			
			$import = $this->webservice_model->get_data ( $import );
			// print'<pre>';
			// print_R($import);
			// die;
			$labAssayId = '';
			if (! empty ( $import->data )) {
				foreach ( $import->data as $key => $val ) {
					if (! empty ( $val->number ) && empty ( $labAssayId ))
						$labAssayId = $val->number;
					
					if (! empty ( $val->number ) && ! empty ( $labAssayId ) && $labAssayId < $val->number)
						$labAssayId = $val->number;
					
					// print'<pre>';
					// print_r($val->number);
					// echo " labAssayId ".$labAssayId."\n";
				}
			}
			
			if (empty ( $labAssayId ) || $labAssayId < $this->am->getLatestlabAssayId ()) {
				$labAssayId = $this->am->getLatestlabAssayId () + 1;
				echo $labAssayId;
			} else {
				echo $labAssayId + 1;
			}
		}
	}
	public function adultsurveillance() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$this->sites ( 'adultsurveillance' );
			$as_data = $this->webservice_model->adultsurveillance ();
			$arr_records = array ();
			$arr_records_1 = array ();
			$tempAdult = array ();
			$insert = array ();
			// print'<pre>';
			// print_r($as_data);
			// die;
			if (! empty ( $as_data )) {
				foreach ( $as_data as $key => $value ) {
					$site_code = "";
					$species = $this->webservice_model->get_adult_species_data ( $value->idadultsurveillance );
					$arr_species = array ();
					foreach ( $species as $value_species ) {
						array_push ( $arr_species, array (
								"taxonomy" => array (
										"genus" => $value_species->genus,
										"species" => $value_species->mosquitospecies 
								),
								"sex" => array (
										"female" => $value_species->countf,
										"male" => $value_species->countm 
								) 
						) );
					}
					
					$date1 = $value->pudate . ' ' . date ( 'H:i:s', strtotime ( $value->putime ) );
					$date2 = $value->setdate . ' ' . date ( 'H:i:s', strtotime ( $value->settime ) );
					$trapnight = dateDiff ( $date1, $date2 );
					
					if (! empty ( $value->idsite ) && $this->webservice_model->chkSite ( $value->idsite )) {
						$sendSite = $this->webservice_model->sendSingleSite ( $value->idsite );
						$site_code = $sendSite ['SITE_CODE'];
						// echo " <br> In ChkSite $site_code <br>";
					} else if (! empty ( $value->idsite ) && $this->webservice_model->chkSentSite ( $value->idsite )) {
						$sendSite = $this->webservice_model->chkSentSite ( $value->idsite );
						$site_code = $sendSite;
						// echo " <br> In ChkSentSite $site_code <br>";
					}
					if (! empty ( $sendSite->Error ) || ! empty ( $sendSite->Warning ))
						array_push ( $sendSiteError, $sendSite );
					
					$arr_records_1 = array (
							"site" => $site_code,
							// "coordinates" => array(
							// "latitude" => array(
							// "degrees" => $degLat,
							// "minutes" => $minLat,
							// "seconds" => $secLat
							// ),
							// "longitude" => array(
							// "degrees" => $degLng,
							// "minutes" => $minLng,
							// "seconds" => $secLng
							// )
							// ),
							"trap" => array (
									'type' => ! empty ( $value->traptypeAcronym ) ? $value->traptypeAcronym : 'NA',
									"nights" => ! empty ( $trapnight ) ? $trapnight : 0 
							),
							"collectiondate" => $value->pudate 
					);
					
					if (! empty ( $arr_species )){
                        $arr_records_1["countset"] = $arr_species;
					}
					if (! empty ( $value->comments )){
                        $arr_records_1["comments"] = $value->comments;
					}
					
					array_push ( $arr_records, $arr_records_1 );
					array_push ( $tempAdult, $value->idadultsurveillance );
				}
				
				if (! empty ( $arr_records )) {
					$insert = array (
							"recordset" => array (
									array (
											"type" => "arthro",
											"subtype" => "collection",
											"record" => $arr_records 
									) 
							) 
					);
				}
			}
			 //print'<pre>';
//			 print_r(json_encode($insert));
//			 die;
			// $this->load->view('webservices/webservice_loader');
			if (! empty ( $insert )) {
				$send = $this->send_data ( $insert );
				if (! empty ( $send ) && ! isset ( $send->Error ))
					$this->webservice_model->setImported ( 'adultsurveillance', 'idadultsurveillance', $tempAdult );
				$data ['send'] = $send;
				$data ['status'] = 'success';
				// print'<pre>';
				// print_r($send);
				// die;
			} else {
				$data ['send'] = 'All data has been exported';
				$data ['status'] = 'error';
			}
			
			$this->load->view ( 'webservices/webservice_result', $data );
		}
	}
	public function decToDms($dec) {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			// Converts decimal longitude / latitude to DMS
			// ( Degrees / minutes / seconds )
			
			// This is the piece of code which may appear to
			// be inefficient, but to avoid issues with floating
			// point math we extract the integer part and the float
			// part by using a string function.
			
			$vars = explode ( ".", $dec );
			$deg = $vars [0];
			$tempma = "0." . $vars [1];
			
			$tempma = $tempma * 3600;
			$min = floor ( $tempma / 60 );
			$sec = $tempma - ($min * 60);
			
			return array (
					"deg" => $deg,
					"min" => $min,
					"sec" => $sec 
			);
		}
	}
	public function send_data($insert) {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$url = "http://sandbox.calsurv.org/ws.php?module=core&ppf=import.ws&output=json&token=6ca8e375945200b059bb7cbdad7d51349ac16b72";
			$insert = json_decode ( json_encode ( $insert ), TRUE );
			//print '<pre>';
//			print_r ( json_encode ( $insert ) );
			// exit;
			$ch = curl_init ();
			curl_setopt ( $ch, CURLOPT_URL, $url );
			curl_setopt ( $ch, CURLOPT_POST, true );
			curl_setopt ( $ch, CURLOPT_POSTFIELDS, array (
					"insert" => json_encode ( $insert ) 
			) );
			curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
			curl_setopt ( $ch, CURLOPT_SSL_VERIFYHOST, 0 );
			curl_setopt ( $ch, CURLOPT_SSL_VERIFYPEER, 0 );
			$response = curl_exec ( $ch );
			$error_msg = curl_error ( $ch );
			curl_close ( $ch );
			$result = json_decode ( $response );
			// print'<pre>';
			// print_r($result);
			// print_r($error_msg);
			// if (isset($result->Success)) {
			// return true;
			// } else {
			// return false;
			return $result;
			// }
		}
	}
	public function chkSentSiteCtrl() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->webservice_model->chkSentSite ();
		}
	}
    
    public function collectAllMessages($messages) {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
            $response = array();
            $response['Error'] = array();
            $response['Success'] = array();
            $response['Warning'] = array();
            if(!empty($messages)) {
                foreach($messages as $key => $val) {
                    if(isset($val->Error)) {
                        array_push($response['Error'], $val->Error[0]);    
                    }
                    if(isset($val->Success)) {
                        array_push($response['Success'], $val->Success[0]);    
                    }
                    if(isset($val->Warning)) {
                        array_push($response['Warning'], $val->Warning[0]);    
                    }
                }    
            }  
			return $response;
		}
	}
}
?>