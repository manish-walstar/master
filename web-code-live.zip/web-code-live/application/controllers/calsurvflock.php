<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class CalSurvFlock extends CI_Controller {
	private $flockyear;
	private $flocks;
	private $flocksite;
	private $collectors;
	private $bands;
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		$this->load->helper('language');
		$this->load->model ( 'calsurvflock_model', 'cm' );
		$this->load->model ( 'sentinelchicken_model', 'sm' );
		$this->load->model ( 'sentinelchickenlab_model', 'slm' );
		$this->load->model ( 'adultsurveillance_model', 'am' );
		$this->load->model ( 'webservice_model', 'wm' );
		$this->load->model ( 'zone_model', 'zm' );
		
		$this->flocks = $this->cm->getFlocks ();
		$this->flockyear = $this->cm->getFlockYear ();
		$this->flocksite = json_encode ( $this->cm->getSites () );
		$this->collectors = $this->am->getInspectors ();
		
		if ($this->session->userdata ( 'logged_in' ))
			$this->idlocation = $this->session->userdata ( 'idlocation' );
        
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
			// $flag = true;
		$flag = $this->cm->checkCaGateway ();
		if (! $flag)
			redirect ( base_url () );
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' ))
			redirect ( base_url () );
		else {
			redirect ( base_url () . "calsurvflock/getcalsurvflock" );
		}
	}
	
	/**
	 * Function to initialize all the vars
	 */
	public function init() {
		$data = array (
				'flockyear' => $this->flockyear,
				'flocks' => $this->flocks,
				'flocksite' => $this->flocksite,
				'collectors' => $this->collectors,
                'app_lang' => $this->app_lang 
		);
		
		return $data;
	}
	
	/**
	 * Function to add a new cal surv flock
	 */
	public function addcalsurvflock() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$id = $this->input->get ( 'id', TRUE );
			$saveandclose = $this->input->post ( 'saveandclose' );
			$saveandsend = $this->input->post ( 'saveandsend' );
			
			if (empty ( $id ))
				$data = $this->init ();
			else
				$data = $this->updateData ( $id );
			
			$this->form_validation->set_rules ( 'flockyear', $this->lang->line('clsrv_flck_yr'), 'trim|required|integer' );
			$this->form_validation->set_rules ( 'flockid', $this->lang->line('sntnl_chkn_mgmt_flck_id'), 'trim|required|integer' );
			// $this->form_validation->set_rules('site', $this->lang->line('whthr_snsr_site'), 'trim|required');
			$this->form_validation->set_rules ( 'datebled', $this->lang->line('sntnl_chkn_mgmt_date_bled'), 'trim|required' );
			// $this->form_validation->set_rules('datesubmitted', $this->lang->line('sntnl_chkn_lab_date_sbmttd'), 'trim');
			// $this->form_validation->set_rules('dateresults', $this->lang->line('clsrv_flck_date_rslts'), 'trim');
			$this->form_validation->set_rules ( 'collector', $this->lang->line('clsrv_flck_cllctr'), 'trim' );
			
			if ($this->form_validation->run () == FALSE) {
				$this->load->view ( 'calsurvflocks/add_calsurvflock', $data );
			} else {
				$id = $this->input->post ( 'idcalsurvflock' );
				$flag = $this->cm->addCalSurvFlock ();
				// $flag = 1;
				
				$data ['msg'] = '';
				$data ['status'] = '';
				
				if (! empty ( $flag ) && ! empty ( $saveandclose )) {
					$data = $this->updateData ( $flag ['idcalsurv'] );
					$data ['msg'] = "saveandclose";
					$returnData = $this->getStatusMsg ( $id );
					$data = array_merge ( $data, $returnData );
				} else if (! empty ( $flag ) && ! empty ( $saveandsend )) {
					$data = $this->updateData ( $flag ['idcalsurv'] );
					$data ['msg'] = "saveandsend";
					$sendToGateway = $this->wm->sendSingleBand ( $flag );
					// echo $id;
					// print'<pre>';
					// print_r($sendToGateway);
					// die;
					// $sendToGateway = 1;
					$data ['camessage'] = $sendToGateway;
					$returnData = $this->getStatusMsg ( $id );
					$data = array_merge ( $data, $returnData );
				} else
					$data ['msg'] = "error";
                    
				$this->load->view ( 'calsurvflocks/add_calsurvflock', $data );
			}
		}
	}
	public function updateData($id = '') {
		if (empty ( $id ))
			return false;
		
		$calsurvdata = $this->cm->getCalSurvFlockData ( $id );
		
		$this->flockyear = $this->cm->getFlockYear ( $calsurvdata ['flockyear'] );
		$this->flocks = $this->cm->getFlocks ( $calsurvdata ['idsentinelchicken'] );
		// $this->flocksite = json_encode($this->cm->getSites('',$calsurvdata['idsite']));
		$this->collectors = $this->am->getSelectedInspectors ( $calsurvdata ['idcollector'] );
		$this->bands = $this->cm->getBands ( $calsurvdata ['idsentinelchicken'], $calsurvdata ['idcalsurv'] );
		
		$data = array (
				'flockyear' => $this->flockyear,
				'flocks' => $this->flocks,
				// 'flocksite' => $this->flocksite,
				'collectors' => $this->collectors,
				'bands' => $this->bands,
				'datebled' => ! empty ( $calsurvdata ['datebled'] ) ? date ( 'm/d/Y', strtotime ( $calsurvdata ['datebled'] ) ) : '',
				// 'datesubmitted' => !empty($calsurvdata['datesubmitted'])?date('m/d/Y' , strtotime($calsurvdata['datesubmitted'])):'',
				// 'dateresults' => !empty($calsurvdata['dateresults'])?date('m/d/Y' , strtotime($calsurvdata['dateresults'])):'',
				'comments' => $calsurvdata ['comments'],
				'iswholeblood' => $calsurvdata ['iswholeblood'],
				'issubmissionform' => $calsurvdata ['issubmissionform'],
				'idcalsurv' => $calsurvdata ['idcalsurv'],
                'idsite' => $calsurvdata ['idsite']
		);
		
		return $data;
	}
	public function getStatusMsg($id = '', $msg = '', $sendStat = '') {
		$data = array ();
		if (! empty ( $id ))
			$data ['status'] = "updated";
		else if (! empty ( $msg ) && ! empty ( $sendStat )) {
			$data = $this->init ();
			$data ['status'] = "succerror";
		} else if (! empty ( $msg )) {
			$data = $this->init ();
			$data ['status'] = "success";
		} else
			$data ['status'] = "success";
		
		return $data;
	}
	
	/**
	 * Function to delete calsurvflock
	 */
	public function deleteCalSurvFlock() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->cm->deleteCalSurvFlock ();
			
			$msg = "";
			
			if ($flag)
				$msg = "success";
			else
				$msg = "error";
			
			$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
			if (! empty ( $seturl [1] ))
				redirect ( $seturl [0] . "?del=" . $msg . "#" . $seturl [1] );
			else
				redirect ( $seturl [0] . "?del=" . $msg );
			// redirect(base_url().'calsurvflock/getcalsurvflock?del='.$msg);
		}
	}
	
	/**
	 * Function to send data to CA Gateway
	 */
	public function sendToGateway() {
		$calSurvIds = $this->input->get_post ( 'requestData' );
		
		if (! empty ( $calSurvIds )) {
			$responseData = array ();
			$calSurvIds = explode ( ',', $calSurvIds );
			foreach ( $calSurvIds as $val ) {
				if ($val == 'all')
					continue;
				
				$calSurvData = $this->cm->getCalSurvFlockBand ( $val );
                if(empty($calSurvData)) {
                    echo "sent";
					exit ();
                }
				$flag = $this->wm->sendSingleBand ( $calSurvData );
				// $flag = 1;
				// print'<pre>';
				// print_r($flag);
				// die;
				if (! empty ( $flag->Success )) {
					$temp ['date'] = ! empty ( $calSurvData ['datebled'] ) ? date ( 'm/d/Y', strtotime ( $calSurvData ['datebled'] ) ) : '';
					$temp ['status'] = true;
					$temp ['msg'] = $flag->Success;
					$this->slm->importFlock ( $calSurvData );
					array_push ( $responseData, $temp );
				}
				
				if (! empty ( $flag->Error )) {
					$temp ['date'] = ! empty ( $calSurvData ['datebled'] ) ? date ( 'm/d/Y', strtotime ( $calSurvData ['datebled'] ) ) : '';
					$temp ['status'] = false;
					$temp ['msg'] = $flag->Error;
					array_push ( $responseData, $temp );
				}
				
				if (! empty ( $flag->Warning )) {
					$temp ['date'] = ! empty ( $calSurvData ['datebled'] ) ? date ( 'm/d/Y', strtotime ( $calSurvData ['datebled'] ) ) : '';
					$temp ['status'] = 'warning';
					$temp ['msg'] = $flag->Warning;
					array_push ( $responseData, $temp );
				}
				if (empty ( $flag )) {
					echo "noresponse";
					exit ();
				}
				// else
				// {
				// echo "error";
				// exit();
				// }
			}
			// print'<pre>';
			// print_R($responseData);
			echo json_encode ( $responseData );
			exit ();
		} else {
			echo "error";
			exit ();
		}
	}
	public function makeUrl() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$url = $this->session->userdata ( 'url' );
			$seturl = '';
			if (! empty ( $url ))
				$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
			else
				return base_url ();
			
			if (! empty ( $seturl [0] ) && ! empty ( $seturl [1] )) {
				return $url;
			}
		}
	}
	
	/**
	 * Function to display List Of calsurvflocks
	 */
	public function getcalsurvflock($grid = '', $msg = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$newUrl = array ();
			$filter_date = $this->input->post ( 'filter_date' );
			$columns = array (
					0 => array (
							'name' => $this->lang->line('whthr_snsr_site'),
							'db_name' => 'idsite',
							'header' => $this->lang->line('whthr_snsr_site'),
							'group' => 'Cal Surv Flock',
							'ref_table_id_name' => 'idsite',
							'ref_table_db_name' => 'sites',
							'ref_field_db_name' => 'site',
							'required' => TRUE,
							'form_control' => 'text_long',
							'type' => '1-n' 
					),
					1 => array (
							'name' => $this->lang->line('clsrv_flck_cllctn_date'),
							'db_name' => 'datebled',
							'header' => $this->lang->line('clsrv_flck_cllctn_date'),
							'group' => 'Cal Surv Flock',
							'required' => TRUE,
							'form_control' => 'text_long',
							'type' => 'string' 
					),
					2 => array (
							'name' => $this->lang->line('clsrv_flck_date_snt_to_gw'),
							'db_name' => 'datesent',
							'header' => $this->lang->line('clsrv_flck_date_snt_to_gw'),
							'group' => 'Cal Surv Flock',
							'required' => TRUE,
							'form_control' => 'text_long',
							'type' => 'string' 
					),
					3 => array (
							'name' => $this->lang->line('clsrv_flck_cllctr'),
							'db_name' => 'idcollector',
							'header' => $this->lang->line('clsrv_flck_cllctr'),
							'group' => 'Cal Surv Flock',
							'ref_table_id_name' => 'iduser',
							'ref_table_db_name' => 'users',
							'ref_field_db_name' => 'firstname',
							'ref_field_2_db_name' => 'middlename',
							'ref_field_3_db_name' => 'lastname',
							'ref_field_type' => 'string',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-1+2+3' 
					) 
			);
			
			$commands ['delete'] ['toolbar'] = FALSE;
			
			$params = array (
					'id' => 'idcalsurv',
					'table' => 'calsurvflock',
					'url' => 'calsurvflock/getcalsurvflock',
					'uri_param' => $grid,
					'columns' => $columns,
					'order' => array (
							1 => 'desc' 
					),
					'filter_date' => ! empty ( $filter_date ) ? $filter_date : '2',
					'filters' => array (
							0 => array (
									'value' => $this->idlocation 
							) 
					),
					// 'columns_visible' => array(0,1,2),
					'commands' => $commands,
					'ajax' => TRUE,
					'msc_url' => array (
							'excel_url' => base_url () . 'calsurvflock/toExcelAll',
							'pdf_url' => base_url () . 'calsurvflock/toPdfAll',
							'text' => 'CalSurv Flock' 
					) 
			);
			
			if (! empty ( $grid )) {
				$newUrl = array (
						'url' => base_url () . $params ['url'] . '#' . $params ['id'] . '=' . $grid 
				);
			} else {
				$newUrl = array (
						'url' => base_url () . $params ['url'] 
				);
			}
			
			$this->session->set_userdata ( $newUrl );
			
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('labs_clsrv_flck_cllctn'),
					'page' => "arbovirallab",
                    'app_lang' => $this->app_lang 
			);
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			
			// Pass grid to the view
            $data = (object)array();
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			$data->url = $this->makeUrl ();
			$data->msg = $msg;
			$data->mapdata = base_url () . "calsurvflock/showmap";
			// $data->showbutton = $this->showExportBttn();
			
			$this->load->view ( 'calsurvflocks/calsurvflocks', $data );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to Display the Map
	 */
	public function showmap() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$query ['data'] = $this->cm->getMapdata ();
			$query ['user_loc'] = $this->am->getUserLoc ();
			$query ['zone_loc'] = $this->zm->getZoneCord ();
			$query ['googlezoom'] = $this->session->userdata ( 'googlezoom' );
			$this->load->view ( 'calsurvflocks/map_view', $query );
		}
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function getcalsurvflockdata() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$id = $this->input->post ( 'idcalsurvflock' );
			
			if (empty ( $id )) {
				echo "error";
				exit ();
			}
			
			$data = $this->calsurvflock_model->getSentinelChickenlabData ( $id );
			
			echo json_encode ( $data );
		}
	}
	
	/**
	 * Function to fetch the history
	 */
	public function getHistory() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$id = $this->input->get_post ( 'id' );
			
			if (empty ( $id ))
				redirect ( base_url () . "calsurvflock/getcalsurvflock" );
			
			$data ['data'] = $this->cm->getHistory ( $id );
			
			if (! empty ( $data ))
				$this->load->view ( 'calsurvflocks/history_view', $data );
			else {
				$this->load->view ( 'calsurvflocks/history_view', array (
						"msg" => "error" 
				) );
			}
			;
		}
	}
	
	/**
	 * Function to fetch the Site
	 * selected by Flock
	 */
	public function getSites() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$id = $this->input->post ( 'id' );
			$flag = json_encode ( $this->cm->getSites ( $id ) );
			
			if (empty ( $flag ))
				echo "error";
			else
				echo $flag;
			
			exit ();
		}
	}
	
	/**
	 * Function to fetch all the Chickens
	 * selected by Flock
	 */
	public function getBands() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$id = $this->input->post ( 'id' );
			$flag = json_encode ( $this->cm->getBands ( $id ) );
			
			if (empty ( $flag ))
				echo "error";
			else
				echo $flag;
			
			exit ();
		}
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			// $this->load->helper('pdf_helper'); // Load helper
			$calSurvIds = $this->input->get_post ( 'ids', TRUE );
			
			$responseData = array ();
			if (! empty ( $calSurvIds )) {
				$calSurvIds = explode ( ',', $calSurvIds );
				foreach ( $calSurvIds as $val ) {
					if ($val == 'all')
						continue;
					
					$calSurvData = $this->cm->getCalSurvFlockDataForPrint ( $val );
					array_push ( $responseData, $calSurvData );
				}
			}
			// print'<pre>';
			// print_r($responseData);
			// die;
			$query ['data'] = $responseData;
			$this->load->view ( 'calsurvflocks/pdf_view', $query );
			
			// print'<pre>';
			// print_r($data);
			// die;
			// create_pdf($data,"CalSurvFlocks"); //Create pdf
		}
	}
	
	/**
	 * Function to view page at on click popup
	 */
	public function showaddsentinel() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data_1 = array (
					'flock' => $this->flock,
					'assay' => $this->assay,
					'result' => $this->result,
					'virus_type' => $this->virus_type 
			);
			
			$this->load->view ( 'calsurvflocks/add_calsurvflock', $data_1 );
		}
	}
	public function exportFromGateway() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$id = $this->input->get_post ( 'id', TRUE );
			$calSurvData = $this->cm->getCalSurvFlockDataForExport ( $id );
			// print'<pre>';
			// print_r($calSurvData);
			// die;
			$export = array (
					"type" => "sentinel",
					"subtype" => "bleed",
					"filter" => array (
							"year" => array (
									0 => ! empty ( $calSurvData ['flockyear'] ) ? $calSurvData ['flockyear'] : '' 
							),
							"flock" => array (
									0 => ! empty ( $calSurvData ['idsite'] ) ? $calSurvData ['idsite'] : '' 
							),
							"results" => 1,
							"status" => "Confirmed" 
					) 
			);
			// print'<pre>';
			// print_r($export);
			// die;
			$this->wm->get_data ( $export );
		}
	}
}

/* End of file calsurvflock.php */
/* Location: ./application/controllers/calsurvflock.php */
