<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Arboviral_report extends CI_Controller {
	public $products;
	public $products2;
	public $products3;
	public $arboviral;
	public $sentinelchickenlab;
	public $startdate;
	public $starttime;
	public $enddate;
	public $endtime;
	public $currentdate;
	public $currenttime;
	public $endtimestamp;
	public $starttimestamp;
	public $userinfo;
    public $app_lang;
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		$this->load->helper('language');
		$this->load->model ( 'arboviral_report_model' );
		$this->load->model ( 'sentinelchickenlab_model' );
		$this->load->model ( 'usermodel' );
		$this->usermodel->set_access_session ();
		
		if (! $this->usermodel->user_access ( 'reports' ) && ! $this->usermodel->user_access ( 'company_admin' ))
			redirect ( base_url () );
            
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		$this->currentdate = date ( 'm/d/Y' );
		$this->currenttime = date ( "h:i:s A" );
		
		$this->enddate = date ( 'm/d/Y' );
		$this->endtime = date ( 'Hh:i:s A' );
		
		$this->startdate = date ( 'm/d/Y', strtotime ( "-30 day" ) );
		$this->starttime = date ( 'h:i:s A' );
		
		$this->endtimestamp = strtotime ( date ( 'm/d/Y H:i:s' ) );
		
		$this->starttimestamp = strtotime ( date ( 'm/d/Y H:i:s', strtotime ( "-30 day" ) ) );
		
		if ($this->session->userdata ( 'id' )) {
			$this->arboviral = $this->arboviral_report_model->getArboviral ( $this->startdate, $this->enddate );
			
			// print('<pre>');
			// print_r($this->arboviral);
			// die;
			
			$id = $this->session->userdata ( 'id' );
			$id_arr = explode ( "_", json_decode ( base64_decode ( $id ) ) );
			
			$id = json_decode ( base64_decode ( $id_arr [0] ) );
			
			$this->userinfo = $this->usermodel->getUserData ( $id );
			
			$middlename = " ";
			if (isset ( $this->userinfo ['middlename'] ))
				$middlename = ! empty ( $this->userinfo ['middlename'] ) ? " " . $this->userinfo ['middlename'] . " " : " ";
			
			if (isset ( $this->userinfo ['firstname'] ) || isset ( $this->userinfo ['lastname'] ))
				$this->inspector = $this->userinfo ['firstname'] . $middlename . $this->userinfo ['lastname'];
			
			$this->products = $this->arboviral_report_model->getArboviral ( $this->startdate, $this->enddate );
			
			$this->products2 = $this->arboviral_report_model->getSentinels_by_Flock ( $this->startdate, $this->enddate );
			$this->products3 = $this->arboviral_report_model->getWild_Bird_by_Date ( $this->startdate, $this->enddate );
			// die;
			
			// print('<pre>');
			// print_r($this->arboviral);
			// die;
		}
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			redirect ( base_url () . "arboviral_report/getarboviral" );
		}
	}
	
	/**
	 * Function to fetch All products
	 */
	public function getarboviral() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			
			$zone = $this->input->post ( 'zone' );
			$site = $this->input->post ( 'site' );
			$techs = $this->input->post ( 'techs' );
			$_species = $this->input->post ( 'species' );
			$_traptypes = $this->input->post ( 'traptypes' );
			
			$data_1 = array ();
			
			if (empty ( $startdate ) && empty ( $enddate )) {
				$data_1 = array (
						'username' => $this->session->userdata ( 'username' ),
						'logstatus' => "logout",
						'title' => "Arboviral Report",
						'page' => "arboviral_report",
						'startdate' => $this->startdate,
						'starttime' => date ( 'h:i:s A', strtotime ( $this->starttime ) ),
						'endtime' => date ( 'h:i:s A', strtotime ( $this->endtime ) ),
						'enddate' => $this->enddate,
						'inspector' => $this->inspector,
						'currentdate' => $this->currentdate,
						'currenttime' => date ( "h:i:s A", strtotime ( $this->currenttime ) ),
						'products' => $this->products,
						'products2' => $this->products2,
						'products3' => $this->products3 
				)
				;
			} else {
				// echo $startdate." ".$enddate;
				
				$this->startdate = $startdate;
				$this->enddate = $enddate;
				
				$this->arboviral = $this->arboviral_report_model->getArboviral ( $this->startdate, $this->enddate );
				// print('<pre>');
				// print_r($this->arboviral);
				// die;
				$middlename = " ";
				if (isset ( $this->userinfo ['middlename'] ))
					$middlename = ! empty ( $this->userinfo ['middlename'] ) ? " " . $this->userinfo ['middlename'] . " " : " ";
				
				if (isset ( $this->userinfo ['firstname'] ) || isset ( $this->userinfo ['lastname'] ))
					$this->inspector = $this->userinfo ['firstname'] . $middlename . $this->userinfo ['lastname'];
				
				$this->products = $this->arboviral_report_model->getArboviral ( $this->startdate, $this->enddate );
				$this->products2 = $this->arboviral_report_model->getSentinels_by_Flock ( $this->startdate, $this->enddate );
				$this->products3 = $this->arboviral_report_model->getWild_Bird_by_Date ( $this->startdate, $this->enddate );
				// print'<pre>';
				// print_r($startdate);
				// print_r($enddate);
				// echo $this->startdate." ".$this->starttime."<br>";
				// echo $this->enddate." ".$this->endtime;
				// die;
				
				$data_1 = array (
						'username' => $this->session->userdata ( 'username' ),
						'logstatus' => "logout",
						'title' => "Arboviral Report",
						'page' => "arboviral_report",
						'startdate' => $this->startdate,
						'starttime' => date ( 'h:i:s A', strtotime ( $this->starttime ) ),
						'endtime' => date ( 'h:i:s A', strtotime ( $this->endtime ) ),
						'enddate' => $this->enddate,
						'inspector' => $this->inspector,
						'currentdate' => $this->currentdate,
						'currenttime' => date ( "h:i:s A", strtotime ( $this->currenttime ) ),
						'products' => $this->products,
						'products2' => $this->products2,
						'products3' => $this->products3 
				);
			}
			
			// print('<pre>');
			// print_r($this->products);
			// die;
			$this->load->view ( 'header', $data_1 );
			
			$this->load->view ( 'left_sidebar', $data_1 );
			
			$this->load->view ( 'arboviral_reports/arboviral_reports', $data_1 );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to fetch the data
	 * and format it in order to return
	 */
	public function exportView() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			$ctime = $this->input->post ( 'current_time' );
			$this->currenttime = ! empty ( $ctime ) ? $ctime : $this->currenttime;
			
			if (! empty ( $startdate ) && ! empty ( $enddate )) {
				$this->startdate = $startdate;
				
				$this->enddate = $enddate;
			}
			
			$middlename = ! empty ( $this->userinfo ['middlename'] ) ? " " . $this->userinfo ['middlename'] . " " : " ";
			$this->inspector = $this->userinfo ['firstname'] . $middlename . $this->userinfo ['lastname'];
			$this->products = $this->arboviral_report_model->getArboviral ( $this->startdate, $this->enddate );
			$this->products2 = $this->arboviral_report_model->getSentinels_by_Flock ( $this->startdate, $this->enddate );
			$this->products3 = $this->arboviral_report_model->getWild_Bird_by_Date ( $this->startdate, $this->enddate );
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => "Arboviral Report",
					'page' => "arboviral",
					'startdate' => $this->startdate,
					'starttime' => date ( 'h:i:s A', strtotime ( $this->starttime ) ),
					'endtime' => date ( 'h:i:s A', strtotime ( $this->endtime ) ),
					'enddate' => $this->enddate,
					'inspector' => $this->inspector,
					'currentdate' => $this->currentdate,
					'currenttime' => date ( "h:i:s A", strtotime ( $this->currenttime ) ),
					'products' => $this->products,
					'products2' => $this->products2,
					'products3' => $this->products3 
			)
			;
			
			// print('<pre>');
			// print_r($data_1);
			// die;
			$data = $this->load->view ( 'arboviral_reports/pdf_view', $data_1, TRUE );
			// print'<pre>';
			// print_r($data);
			// die;
			//
			return $data;
		}
	}
	
	/**
	 * Function to convert data into PDF
	 */
	public function toPDFAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->helper ( 'pdf_helper' );
			$data = $this->exportView ();
			// print'<pre>';
			// print_r($data);
			// die;
			//
			create_pdf ( $data, str_replace(' ', '', $this->lang->line('arbvrl_actvty_rprt')));
		}
	}
	
	/**
	 * Function to convert data into Excel
	 */
	public function toEXCELAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$data = $this->exportView ();
			// print'<pre>';
			// print_r($data);
			// die;
			//
			header ( "Content-type: application/octet-stream" );
			header ( "Content-Disposition: attachment; filename=" . str_replace(' ', '', $this->lang->line('arbvrl_actvty_rprt')) . ".xls" );
			header ( "Pragma: no-cache" );
			header ( "Expires: 0" );
			
			echo $data;
			exit ();
		}
	}
	
	/**
	 * Function to convert data into Word
	 */
	public function toWORDAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			header ( "Content-Type: application/vnd.ms-word" );
			header ( "Expires: 0" );
			header ( "Cache-Control:  must-revalidate, post-check=0, pre-check=0" );
			header ( "Content-disposition: attachment; filename=\"" . str_replace(' ', '', $this->lang->line('arbvrl_actvty_rprt')) . ".doc\"" );
			
			// $query['data'] = $this->arbovirallab_model->listArbovirallabs();
			
			$data = $this->exportView ();
			
			echo $data;
			exit ();
		}
	}
	
	/**
	 * Function to return headers
	 */
	public function download_send_headers($filename) {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			header ( "Pragma: public" );
			header ( "Expires: 0" );
			header ( "Cache-Control: must-revalidate, post-check=0, pre-check=0" );
			header ( "Content-Type: application/force-download" );
			header ( "Content-Type: application/octet-stream" );
			header ( "Content-Type: application/download" );
			header ( "Content-Disposition: attachment;filename={$filename}" );
			header ( "Content-Transfer-Encoding: binary" );
		}
	}
	
	/**
	 * Function to convert Array into CSV
	 */
	public function array2csv(array &$array) {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			if (count ( $array ) == 0) {
				return null;
			}
			
			ob_start ();
			$df = fopen ( "php://output", 'w' );
			fputcsv ( $df, array_keys ( reset ( $array ) ) );
			foreach ( $array as $row ) {
				fputcsv ( $df, $row );
			}
			fclose ( $df );
			return ob_get_clean ();
		}
	}
	
	/**
	 * Function to convert data into CSV
	 */
	public function toCSVAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->dbutil ();
			
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			$ctime = $this->input->post ( 'current_time' );
			$this->currenttime = ! empty ( $ctime ) ? $ctime : $this->currenttime;
			
			if (! empty ( $startdate ) && ! empty ( $enddate )) {
				$this->startdate = $startdate;
				$this->enddate = $enddate;
			}
			
			$query = $this->arboviral_report_model->getXML ( $this->startdate, $this->enddate );
			
			$this->download_send_headers ( str_replace(' ', '', $this->lang->line('arbvrl_actvty_rprt')).".csv" );
			echo $this->dbutil->csv_from_result ( $query );
		}
	}
	
	/**
	 * Function to convert data into XML
	 * Format
	 */
	public function toXMLAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->dbutil ();
			
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			$ctime = $this->input->post ( 'current_time' );
			$this->currenttime = ! empty ( $ctime ) ? $ctime : $this->currenttime;
			
			if (! empty ( $startdate ) && ! empty ( $enddate )) {
				$this->startdate = $startdate;
				$this->enddate = $enddate;
			}
			
			$query = $this->arboviral_report_model->getXML ( $this->startdate, $this->enddate );
			
			$this->download_send_headers ( str_replace(' ', '', $this->lang->line('arbvrl_actvty_rprt')).".xml" );
			echo $this->dbutil->xml_from_result ( $query );
		}
	}
	
	/**
	 * Function to convert data into Image
	 */
	public function toIMAGEAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->helper ( 'pdf_helper' );
			$data = $this->exportView ();
			//
			return_pdf ( $data, "ArboviralActivity" ); // Create pdf
			
			exec ( "convert ArboviralActivitypdf.pdf ArboviralActivity.tif" );
			$this->download_send_headers ( str_replace(' ', '', $this->lang->line('arbvrl_actvty_rprt')).".tif" );
			echo file_get_contents ( str_replace(' ', '', $this->lang->line('arbvrl_actvty_rprt')) . ".tif" );
			unlink ( "temp/ArboviralActivitypdf.pdf" );
			unlink ( "temp/ArboviralActivity.tif" );
		}
	}
}

/* End of file arboviral_report.php */
/* Location: ./application/controllers/arboviral_report.php */