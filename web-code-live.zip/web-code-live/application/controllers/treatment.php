<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Treatment extends CI_Controller {
	public $idlocation;
	public $flag;
	/* Common Treatment Variables Start */
	public $sites;
	public $site_type;
	public $zones;
	public $states;
	public $applicator;
	public $application_method;
	public $product;
	public $formulation;
	public $application_rate_type;
	public $product_preferences;
	public $applicationrateuom;
	public $mixratio;
	public $finishedmix;
	public $ttl_prdct_applied;
	public $ttl_area_treated;
	public $date;
	public $time;
	public $sitegroup = "";
	public $justification;
    public $windspeed;
    public $winddirection;
	/* Common Treatment Variables End */
	
	/* Larvicide Treatment Variables Start */
	public $site_status;
	public $watertemp;
	public $larvacount;
	public $instar;
	public $species;
	public $s_species = "";
	public $weatherconditions;
	/* Larvicide Treatment Variables End */
	
	/* Adulticide Treatment Variables Start */
	public $system;
	public $dilutent;
	public $tempatstart;
	public $tempatend;
	public $humidity;
	public $cloudcover;
	public $flowratetypes;
	
	/* Adulticide Treatment Variables End */
	
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		
        $this->load->helper('language');
		$this->load->model ( 'treatment_model' );
		$this->load->model ( 'site_model' );
		$this->load->model ( 'larvalsurveillance_model' );
		$this->load->model ( 'adultsurveillance_model' );
		$this->load->model ( 'landingrate_model' );
		$this->load->model ( 'service_requestmodel' );
		$this->load->model ( 'monitor_model' );
		$this->load->model ( 'zone_model' );
		$this->load->model ( 'product_model' );
        $this->load->model ( 'membermodel' );
        
		
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		if ($this->session->userdata ( 'idlocation' ))
			$this->idlocation = $this->session->userdata ( 'idlocation' );
		
        /* Common Treatment Functions Start */
		$this->applicator = $this->larvalsurveillance_model->getInspectors ();
		$this->application_method = $this->treatment_model->getAppMethod ();
		$this->applicationrateuom = $this->treatment_model->getAppRate ();
		$this->application_rate_type = $this->treatment_model->getAppRateType ();
        $this->date = date ( 'm/d/Y' );
        $this->finishedmix = $this->treatment_model->getFinishedMix ();
		$this->formulation = $this->treatment_model->getFormulation ();
		$this->justification = $this->treatment_model->getTrtmentJustification ();
        $this->mixratio = $this->treatment_model->getMixRatio ();
        $this->product_preferences = $this->product_model->getProductPref ();
		$this->sitegroup = $this->site_model->getSiteGroup ();
		$this->sites = $this->site_model->getExisting_site ();
		$this->site_type = $this->site_model->getSitetypes ();
		$this->states = $this->site_model->getStates ();
        $this->time = date ( 'h:i:s A' );
		$this->ttl_area_treated = $this->treatment_model->getTAreaTreated ();
		$this->ttl_prdct_applied = $this->treatment_model->getTProductApp ();
        $this->winddirection = $this->treatment_model->getWindDirection ();
        $this->windspeed = $this->adultsurveillance_model->getWindspeed ();
        $this->zones = $this->site_model->getZones ();
		/* Common Treatment Functions End */
		
		/* Larvicide Treatment Function Start */
		
		$this->site_status = $this->larvalsurveillance_model->getSitestatus ();
		$this->watertemp = $this->larvalsurveillance_model->getWatertemprange ();
		$this->instar = $this->larvalsurveillance_model->getInstar ();
		$this->larvacount = $this->larvalsurveillance_model->getLarvaecount ();
		$this->species = $this->treatment_model->getSpecies ( $this->idlocation );
		$this->weatherconditions = $this->treatment_model->getWheatherCondtn ();
		$this->product_2 = $this->treatment_model->getProducts ( '', array (
				'2',
				'12' 
		) );
		/* Larvicide Treatment Function End */
		
		/* Adulticide Treatment Function Start */
		
		$this->system = $this->treatment_model->getSystem ();
		$this->dilutent = $this->treatment_model->getDilutent ();
		$this->tempatstart = $this->adultsurveillance_model->getTemprange ();
		$this->tempatend = $this->adultsurveillance_model->getTemprange ();
		$this->humidity = $this->adultsurveillance_model->getHumidityrange ();
		$this->cloudcover = $this->adultsurveillance_model->getCloudcoverage ();
		$this->flowratetypes = $this->treatment_model->getFlowRateType ();
		$this->product_1 = $this->treatment_model->getProducts ( '', '1' );
		
		// print'<pre>';
		// print_r($this->product_1);
		// die;
		/* Adulticide Treatment Function End */
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			redirect ( base_url () . "treatment/gettreatment" );
		}
	}
    
	/**
	 * Function to Show Add Larva Treatment Form
	 */
	public function showadd_larval_treatment($id = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => 'Treatment',
					'page' => "treatment",
                    'app_lang' => $this->app_lang 
			);
			
			if (isset ( $id ) && ! empty ( $id )) {
				$this->flag = $this->treatment_model->getLarvalTreatmentData ( $id );
				
				if (! empty ( $this->flag )) {
					/* Common Treatment Functions For Edit Fuunctionality Start */
					$this->date = ! empty ( $this->flag ['date'] ) ? $this->flag ['date'] : $this->date;
					$this->time = ! empty ( $this->flag ['time'] ) ? $this->flag ['time'] : $this->time;
					$this->sites = $this->site_model->getSelectedExistingSite ( $this->flag ['idsite'] );
					$this->site_type = $this->site_model->getSitetypes ();
					$this->states = $this->site_model->getSelectedSiteStates ( $this->flag ['idsite'] );
					$this->s_species = $this->treatment_model->getSelectedSpecies ( $this->flag ['idlarvaltreatment'] );
					$this->species = $this->treatment_model->getSpecies ( $this->idlocation );
					$this->applicator = $this->larvalsurveillance_model->getSelectedInspectors ( $this->flag ['idapplicator'] );
					$this->application_method = $this->treatment_model->getAppMethod ();
					$this->applicationrateuom = $this->treatment_model->getAppRate ();
					$this->application_rate_type = $this->treatment_model->getAppRateType ( $this->flag ['idapplicationratetype'] );
                    $this->windspeed = $this->adultsurveillance_model->getSelectedWindspeed ( $this->flag ['idwindspeed'] );
                    $this->winddirection = $this->treatment_model->getWindDirection ();
					$this->product_preferences = $this->product_model->getProductPref ( $this->flag ['idproduct'] );
					$this->product_2 = $this->treatment_model->getProducts ( $this->flag ['idproduct'], array (
							'2',
							'12' 
					) );
					$this->formulation = $this->treatment_model->getFormulation ();
					$this->mixratio = $this->treatment_model->getMixRatio ( $this->flag ['idmixratio'] );
					$this->finishedmix = $this->treatment_model->getFinishedMix ();
					$this->ttl_area_treated = $this->treatment_model->getTAreaTreated ();
					$this->ttl_prdct_applied = $this->treatment_model->getTProductApp ();
					$site_data = $this->site_model->getSiteData ( $this->flag ['idsite'] );
					/* Common Treatment Functions For Edit Fuunctionality End */
					
					/* Larvicide Treatment Function For Edit Fuunctionality Start */
					$this->site_status = $this->larvalsurveillance_model->getSelectedSitestatus ( $this->flag ['idsitestatus'] );
					$this->watertemp = $this->larvalsurveillance_model->getWatertemprange ( $this->flag ['idwatertemp'] );
					$this->instar = $this->larvalsurveillance_model->getInstar ( $this->flag ['idinstar'] );
					$this->larvacount = $this->treatment_model->getLarvaecount ( $this->flag ['idlarvaltreatment'] );
					$this->weatherconditions = $this->treatment_model->getWheatherCondtn ();
					/* Larvicide Treatment Function For Edit Fuunctionality End */
					
					if (! empty ( $site_data )) {
						$this->flag ['site_name'] = $site_data ['site'];
						$this->flag ['address1'] = $site_data ['address1'];
						$this->flag ['address2'] = $site_data ['address2'];
						$this->flag ['city'] = $site_data ['city'];
						$this->flag ['maplabel'] = $site_data ['maplabel'];
						$this->flag ['postalcode'] = $site_data ['postalcode'];
						
						if ($site_data ['water_of_us'] == '1')
							$this->flag ['sitecategory'] = 'water of the us';
						
						$this->flag ['landingrate_site'] = $site_data ['landingrate_site'];
						$this->flag ['larval_site'] = $site_data ['larval_site'];
						$this->flag ['adult_site'] = $site_data ['adult_site'];
						$this->flag ['apiary'] = $site_data ['apiary'];
						$this->flag ['contact_before_spray'] = $site_data ['contact_before_spray'];
						$this->flag ['organic_farm'] = $site_data ['organic_farm'];
						$this->flag ['nospray'] = $site_data ['nospray'];
						$this->flag ['water_of_us'] = $site_data ['water_of_us'];
						$this->flag ['endangered_species'] = $site_data ['endangered_species'];
                        $this->zones = $this->site_model->getSelectedZones ( $site_data ['idzone'] );
					}
				}
			}
			// add additional field such as service request
			$query_string = $this->input->server ( 'QUERY_STRING' );
			$common_field_name = substr ( $query_string, 0, strrpos ( $query_string, '=' ) );
			$monitor_key = $this->input->get ( 'monitor_id' );
			$service_req_id = $this->input->get_post ( 'service_req_id' );
			$adult_key = $this->input->get_post ( 'adult_key' );
            $mapFlag = $this->input->get_post ( 'mapFlag' );
            $mapSite = $this->input->get('idsite');
			if (! empty ( $service_req_id )) {
				$common_id = $service_req_id;
			} else if (! empty ( $adult_key )) {
				$common_id = $adult_key;
			} else if (! empty ( $monitor_key )) {
				$common_id = $monitor_key;
			}
            
            if(empty($mapFlag)){
                $this->load->view ( 'header', $data );
                $this->load->view ( 'left_sidebar', $data );   
            }
			
			if (isset ( $id ) && ! empty ( $id )) {
				$this->flag = $this->treatment_model->getLarvalTreatmentData ( $id );
				
				if (! empty ( $this->flag )) {
				    $mapSite = ! empty ( $this->flag ['idsite'] ) ? $this->flag ['idsite'] : '' ;
					$this->initializeLarvalFormData($this->flag);
				}
			}
            
            if (! empty ( $common_id )) {
				if (! empty ( $service_req_id )) {
					$this->flag = $this->service_requestmodel->getServiceRequestData ( $service_req_id );
				} else if (! empty ( $adult_key )) {
					$this->flag = $this->larvalsurveillance_model->getLarvalsurveillanceData ( $adult_key );
				} else if (! empty ( $monitor_key )) {
					$monitor_data = $this->monitor_model->getMonitorData ( $monitor_key );
					
                    if(!empty($monitor_data) && !empty($monitor_data['mission_type']) && ($monitor_data['mission_type'] == 'M4' || $monitor_data['mission_type'] == 'M4S')) {
                        $this->flag ['idapplicationmethod'] = '14';
                    }
					$this->flag ['idsystemtype'] = $this->monitor_model->getSystemType ( ! empty ( $monitor_data ['mission_type'] ) ? $monitor_data ['mission_type'] : '' );
					$this->system = $this->treatment_model->getSystem ( ! empty ( $this->flag ['idsystemtype'] ) ? $this->flag ['idsystemtype'] : '' );
					$this->flag ['time'] = date ( 'h:i:s A', strtotime ( ! empty ( $monitor_data ['end_time'] ) ? $monitor_data ['end_time'] : '' ) );
					$this->flag ['equipemtnid'] = ! empty ( $monitor_data ['vehicle_number'] ) ? $monitor_data ['vehicle_number'] : '';
					
					$this->flag ['applicationstartdate'] = ! empty ( $monitor_data ['applicationstartdate'] ) ? $monitor_data ['applicationstartdate'] : '';
					$this->flag ['applicationenddate'] = ! empty ( $monitor_data ['applicationenddate'] ) ? $monitor_data ['applicationenddate'] : '';
					$this->flag ['applicationrate'] = ! empty ( $monitor_data ['applicationrate'] ) ? $monitor_data ['applicationrate'] : '';
					$this->flag ['applicationstarttime'] = ! empty ( $monitor_data ['start_time'] ) ? $monitor_data ['start_time'] : '';
					$this->flag ['applicationendtime'] = ! empty ( $monitor_data ['end_time'] ) ? $monitor_data ['end_time'] : '';
					$this->flag ['totalareatreated'] = ! empty ( $monitor_data ['acreage_sprayed'] ) ? $monitor_data ['acreage_sprayed'] : '';
                    //GEOP-618: Convert Gallons into Ounces
					$this->flag ['totalproductapplied'] = ! empty ( $monitor_data ['gallons_sprayed'] ) ? $monitor_data ['gallons_sprayed'] : '';
					$this->flag ['idsite'] = ! empty ( $monitor_data ['idsite'] ) ? $monitor_data ['idsite'] : '';
                    $this->flag ['idproduct'] = ! empty ( $monitor_data ['idproduct'] ) ? $monitor_data ['idproduct'] : '';
                    $this->flag ['idproductpreferences'] = ! empty ( $monitor_data ['idapplicationratetype'] ) ? $monitor_data ['idapplicationratetype'] : '';
					$this->flag ['iduomtotalareatreated'] = "1";
					$this->flag ['iduomtotalproductapplied'] = "3";
                    $this->flag ['idapplicationrateuom'] = "2";
					$this->flag ['comments'] = ! empty ( $monitor_data ['comments'] ) ? $monitor_data ['comments'] : '';
                    
                    $this->ttl_prdct_applied = $this->treatment_model->getTProductApp ( $this->flag ['iduomtotalproductapplied'] );
					$this->ttl_area_treated = $this->treatment_model->getTAreaTreated ( $this->flag ['iduomtotalareatreated'] );
					$this->product_2 = $this->treatment_model->getProducts ( $this->flag ['idproduct'], array (
							'2',
							'12' 
					) );
                    $this->product_preferences = $this->product_model->getProductPref ( $this->flag ['idproduct'] );
					$this->applicationrateuom = $this->treatment_model->getAppRate ( '2' );
                    
                    $idapplicator = $this->membermodel->getUserIdByName ( ! empty ( $monitor_data ['operator_name'] ) ? $monitor_data ['operator_name'] : '' );
                    $this->applicator = $this->larvalsurveillance_model->getSelectedInspectors ( $idapplicator );
				}
				
				if (! empty ( $this->flag )) {
					$this->date = ! empty ( $this->flag ['date'] ) ? $this->flag ['date'] : $this->date;
					$this->time = ! empty ( $this->flag ['time'] ) ? $this->flag ['time'] : $this->time;
					
                    //This condition comes when we Schedule larvicide treatment via larvalsurvellance 
					if(isset($this->flag ['idlarvalsurveillance']) && !empty($this->flag ['idlarvalsurveillance']))
                    {
                        $this->s_species = $this->larvalsurveillance_model->getSelectedSpecies ( $this->flag ['idlarvalsurveillance'] );
                        $this->species = $this->larvalsurveillance_model->getSpecies ( $this->idlocation );
                    }
                    
                    $mapSite = ! empty ( $this->flag ['idsite'] ) ? $this->flag ['idsite'] : '' ;
					$this->site_type = $this->site_model->getSitetypes ();
                    $this->states = $this->site_model->getStates ();
					if (! empty ( $adult_key ) || ! empty ( $service_req_id ) || ! empty ( $monitor_key ))
						$this->flag ['common_id'] = $common_id;
                    
					$this->flag ['common_name'] = $common_field_name;
				}
			}
            
            $site_data = $this->site_model->getSiteData ( $mapSite );
			if (! empty ( $site_data )) {
				$this->flag ['site_name'] = $site_data ['site'];
				$this->flag ['address1'] = $site_data ['address1'];
				$this->flag ['address2'] = $site_data ['address2'];
				$this->flag ['city'] = $site_data ['city'];
				$this->flag ['maplabel'] = $site_data ['maplabel'];
				$this->flag ['postalcode'] = $site_data ['postalcode'];
				$this->flag ['idstate'] = $site_data ['idstate'];
                $this->flag ['idsitetype'] = $site_data ['idsitetype'];
				if ($site_data ['water_of_us'] == '1')
					$this->flag ['sitecategory'] = 'water of the us';
				
				$this->flag ['landingrate_site'] = $site_data ['landingrate_site'];
				$this->flag ['larval_site'] = $site_data ['larval_site'];
				$this->flag ['adult_site'] = $site_data ['adult_site'];
				$this->flag ['apiary'] = $site_data ['apiary'];
				$this->flag ['contact_before_spray'] = $site_data ['contact_before_spray'];
				$this->flag ['organic_farm'] = $site_data ['organic_farm'];
				$this->flag ['nospray'] = $site_data ['nospray'];
				$this->flag ['water_of_us'] = $site_data ['water_of_us'];
				$this->flag ['endangered_species'] = $site_data ['endangered_species'];
                $this->sites = $this->site_model->getSelectedExistingSite ( ! empty ( $site_data['idsite'] ) ? $site_data ['idsite'] : '' );
				$this->zones = $this->site_model->getSelectedZones ( ! empty ( $site_data ['idzone'] ) ? $site_data ['idzone'] : '' );
			}
			
			$return = array (
					'date' => $this->date,
					'time' => $this->time,
					'sites' => $this->sites,
					'site_type' => $this->site_type,
					'zones' => $this->zones,
					'states' => $this->states,
					'applicator' => $this->applicator,
					'instar' => $this->instar,
					'larvacount' => $this->larvacount,
					'species' => $this->species,
					's_species' => $this->s_species,
					'site_status' => $this->site_status,
					'sitegroup' => $this->sitegroup,
					'watertemp' => $this->watertemp,
					'weatherconditions' => $this->weatherconditions,
					'application_method' => $this->application_method,
					'application_rate_type' => $this->application_rate_type,
					'product_preferences' => $this->product_preferences,
					'applicationrateuom' => $this->applicationrateuom,
					'sitegroup' => $this->sitegroup,
                    'windspeed' => $this->windspeed,
					'winddirection' => $this->winddirection,
					'product' => $this->product_2,
					'formulation' => $this->formulation,
					'mixratio' => $this->mixratio,
					'uomfinishedmix' => $this->finishedmix,
					'uomtotalareatreated' => $this->ttl_area_treated,
					'uomtotalproductapplied' => $this->ttl_prdct_applied,
					'justification' => $this->justification,
                    'app_lang' => $this->app_lang,
                    'mapFlag' => $mapFlag
			);
			
			if (! empty ( $this->flag )) {
				$this->flag = array_merge ( $this->flag, $return );
			} else {
				$this->flag = $return;
			}
			
			$data_1 = array (
					'state_list' => $this->landingrate_model->getStatename () 
			);
			
			$this->flag ['location_view'] = $this->load->view ( 'treatment/location_view', $data_1, TRUE );
			$this->flag ['mapFlag'] = $mapFlag;
            $mapData = $this->getAllEventsData($mapSite);
            $this->flag = array_merge($this->flag, $mapData);  
            //print('<pre>');
//            print_r($this->flag);
//            die;
			$this->load->view ( 'treatment/add_larval_treatment', $this->flag );
		}
        
        if(empty($mapFlag)){
            $this->load->view ( 'footer' );  
        }
	}
	
	/**
	 * Function to Show Add Adulticide Treatment Form
	 */
	public function showadd_adult_treatment($id = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => 'Treatment',
					'page' => "treatment",
                    'app_lang' => $this->app_lang
			);
			
			if (isset ( $id ) && ! empty ( $id )) {
				$this->flag = $this->treatment_model->getAdultTreatmentData ( $id );
				
				// print'<pre>';
				// print_r($this->flag);
				// die;
				
				if (! empty ( $this->flag )) {
					/* Common Treatment Functions For Edit Fuunctionality Start */
					$this->date = $this->flag ['date'];
					$time1 = ! empty ( $this->flag ['time'] ) ? $this->flag ['time'] : "";
					// $this->time = $this->flag['time'];
					$this->sites = $this->site_model->getSelectedExistingSite ( $this->flag ['idsite'] );
					$this->site_type = $this->site_model->getSitetypes ();
					$this->states = $this->site_model->getStates ();
					$this->applicator = $this->larvalsurveillance_model->getSelectedInspectors ( $this->flag ['idapplicator'] );
					$this->application_method = $this->treatment_model->getAppMethod ( $this->flag ['idapplicationmethod'] );
					$this->applicationrateuom = $this->treatment_model->getAppRate ( $this->flag ['idapplicationrateuom'] );
					$this->application_rate_type = $this->treatment_model->getAppRateType ( $this->flag ['idapplicationratetype'] );
					$this->product_preferences = $this->product_model->getProductPref ( $this->flag ['idproduct'] );
					$this->product_1 = $this->treatment_model->getProducts ( $this->flag ['idproduct'], '1' );
					$this->formulation = $this->treatment_model->getFormulation ( $this->flag ['idformulation'] );
					$this->mixratio = $this->treatment_model->getMixRatio ( $this->flag ['idmixratio'] );
					$this->finishedmix = $this->treatment_model->getFinishedMix ( $this->flag ['iduomfinishedmix'] );
					$this->ttl_area_treated = $this->treatment_model->getTAreaTreated ( $this->flag ['iduomtotalareatreated'] );
					$this->ttl_prdct_applied = $this->treatment_model->getTProductApp ( $this->flag ['iduomtotalproductapplied'] );
					$site_data = $this->site_model->getSiteData ( $this->flag ['idsite'] );
					/* Common Treatment Functions For Edit Fuunctionality End */
					
					/* Adulticide Treatment Function For Edit Fuunctionality Start */
					$this->system = $this->treatment_model->getSystem ( $this->flag ['idsystemtype'] );
					$this->dilutent = $this->treatment_model->getDilutent ( $this->flag ['iddilutent'] );
					$this->tempatstart = $this->adultsurveillance_model->getSelectedTemprange ( $this->flag ['idtempatstart'] );
					$this->tempatend = $this->adultsurveillance_model->getSelectedTemprange ( $this->flag ['idtempatend'] );
					$this->windspeed = $this->adultsurveillance_model->getSelectedWindspeed ( $this->flag ['idwindspeed'] );
					$this->humidity = $this->adultsurveillance_model->getSelectedHumidityrange ( $this->flag ['idhumidityrange'] );
					$this->cloudcover = $this->adultsurveillance_model->getSelectedCloudcoverage ( $this->flag ['idcloudcover'] );
					$this->flowratetypes = $this->treatment_model->getFlowRateType ();
					$this->winddirection = $this->treatment_model->getWindDirection ( $this->flag ['idwinddirection'] );
					/* Adulticide Treatment Function For Edit Fuunctionality End */
					
					if (! empty ( $site_data )) {
						$this->flag ['site_name'] = $site_data ['site'];
						$this->flag ['address1'] = $site_data ['address1'];
						$this->flag ['address2'] = $site_data ['address2'];
						$this->flag ['city'] = $site_data ['city'];
						$this->flag ['maplabel'] = $site_data ['maplabel'];
						$this->flag ['postalcode'] = $site_data ['postalcode'];
						
						if ($site_data ['water_of_us'] == '1')
							$this->flag ['sitecategory'] = 'water of the us';
						
						$this->flag ['landingrate_site'] = $site_data ['landingrate_site'];
						$this->flag ['larval_site'] = $site_data ['larval_site'];
						$this->flag ['adult_site'] = $site_data ['adult_site'];
						$this->flag ['apiary'] = $site_data ['apiary'];
						$this->flag ['contact_before_spray'] = $site_data ['contact_before_spray'];
						$this->flag ['organic_farm'] = $site_data ['organic_farm'];
						$this->flag ['nospray'] = $site_data ['nospray'];
						$this->flag ['water_of_us'] = $site_data ['water_of_us'];
						$this->flag ['endangered_species'] = $site_data ['endangered_species'];
                        $this->zones = $this->site_model->getSelectedZones ( $site_data ['idzone'] );
					}
				}
			}
			// add additional field such as service request
			$query_string = $this->input->server ( 'QUERY_STRING' );
			$common_field_name = substr ( $query_string, 0, strrpos ( $query_string, '=' ) );
			$service_req_id = $this->input->get_post ( 'service_req_id' );
			$adult_key = $this->input->get_post ( 'adult_key' );
			$monitor_key = $this->input->get ( 'monitor_id' );
			$mapFlag = $this->input->get('mapFlag');
            $mapSite = $this->input->get('idsite');
			if (! empty ( $service_req_id )) {
				$common_id = $service_req_id;
			} else if (! empty ( $adult_key )) {
				$common_id = $adult_key;
			} else if (! empty ( $monitor_key )) {
				$common_id = $monitor_key;
			}
			
            if(empty($mapFlag)){
                $this->load->view ( 'header', $data );
                $this->load->view ( 'left_sidebar', $data );
            }
            
			if (isset ( $id ) && ! empty ( $id )) {
				$this->flag = $this->treatment_model->getAdultTreatmentData ( $id );
				if (! empty ( $this->flag )) {
				    $mapSite = $this->flag ['idsite'];
                    $this->initializeAdultFormData($this->flag);
				}
			}
			
			if (! empty ( $common_id )) {
				if (! empty ( $service_req_id )) {
					$this->flag = $this->service_requestmodel->getServiceRequestData ( $service_req_id );
				} else if (! empty ( $adult_key )) {
					$this->flag = $this->larvalsurveillance_model->getLarvalsurveillanceData ( $adult_key );
				} else if (! empty ( $monitor_key )) {
					$monitor_data = $this->monitor_model->getMonitorData ( $monitor_key );
					
                    if(!empty($monitor_data) && !empty($monitor_data['mission_type']) && ($monitor_data['mission_type'] == 'M4' || $monitor_data['mission_type'] == 'M4S')) {
                        $this->flag ['idapplicationmethod'] = '14';
                    }
					$this->flag ['idsystemtype'] = $this->monitor_model->getSystemType ( ! empty ( $monitor_data ['mission_type'] ) ? $monitor_data ['mission_type'] : '' );
					$this->system = $this->treatment_model->getSystem ( ! empty ( $this->flag ['idsystemtype'] ) ? $this->flag ['idsystemtype'] : '' );
					$this->flag ['time'] = date ( 'h:i:s A', strtotime ( ! empty ( $monitor_data ['end_time'] ) ? $monitor_data ['end_time'] : '' ) );
					$this->flag ['equipmentserial'] = ! empty ( $monitor_data ['vehicle_number'] ) ? $monitor_data ['vehicle_number'] : '';
					$this->date=$this->flag ['applicationstartdate'] = ! empty ( $monitor_data ['applicationstartdate'] ) ? $monitor_data ['applicationstartdate'] : '';
					$this->flag ['applicationenddate'] = ! empty ( $monitor_data ['applicationenddate'] ) ? $monitor_data ['applicationenddate'] : '';
					$time1=$this->flag ['applicationstarttime'] = ! empty ( $monitor_data ['start_time'] ) ? $monitor_data ['start_time'] : '';
					$this->flag ['applicationendtime'] = ! empty ( $monitor_data ['end_time'] ) ? $monitor_data ['end_time'] : '';
					$this->flag ['applicationrate'] = ! empty ( $monitor_data ['applicationrate'] ) ? $monitor_data ['applicationrate'] : '';
					$this->flag ['flowrate'] = ! empty ( $monitor_data ['flowrate'] ) ? $monitor_data ['flowrate'] : '';
					$this->flag ['totalareatreated'] = ! empty ( $monitor_data ['acreage_sprayed'] ) ? $monitor_data ['acreage_sprayed'] : '';
                    //GEOP-618: Convert Gallons into Ounces
					$this->flag ['totalproductapplied'] = ! empty ( $monitor_data ['gallons_sprayed'] ) ? $monitor_data ['gallons_sprayed'] : '';
					$this->flag ['iduomtotalareatreated'] = "1";
					$this->flag ['iduomtotalproductapplied'] = "3";
                    $this->flag ['idapplicationrateuom'] = "2";
					$this->flag ['idsite'] = ! empty ( $monitor_data ['idsite'] ) ? $monitor_data ['idsite'] : '';
                    $this->flag ['idproduct'] = ! empty ( $monitor_data ['idproduct'] ) ? $monitor_data ['idproduct'] : '';
                    $this->flag ['idproductpreferences'] = ! empty ( $monitor_data ['idapplicationratetype'] ) ? $monitor_data ['idapplicationratetype'] : '';
                    $this->flag ['comments'] = ! empty ( $monitor_data ['comments'] ) ? $monitor_data ['comments'] : '';
                    
                    $idapplicator = $this->membermodel->getUserIdByName ( ! empty ( $monitor_data ['operator_name'] ) ? $monitor_data ['operator_name'] : '' );
                    $this->applicator = $this->larvalsurveillance_model->getSelectedInspectors ( $idapplicator );
					$this->ttl_prdct_applied = $this->treatment_model->getTProductApp ( $this->flag ['iduomtotalproductapplied'] );
					$this->ttl_area_treated = $this->treatment_model->getTAreaTreated ( $this->flag ['iduomtotalareatreated'] );
					$this->product_1 = $this->treatment_model->getProducts ( $this->flag ['idproduct'], '1' );
                    $this->product_preferences = $this->product_model->getProductPref ( $this->flag ['idproduct'] );
                    
					$this->applicationrateuom = $this->treatment_model->getAppRate ( '2' );
					$this->flowratetypes = $this->treatment_model->getFlowRateType ( '4' );
				}
				
                $this->site_type = $this->site_model->getSitetypes ();
                $this->states = $this->site_model->getStates ();
				    
				$mapSite = !empty($this->flag ['idsite']) ? $this->flag ['idsite'] : "";
                if (! empty ( $adult_key ) || ! empty ( $service_req_id ) || ! empty ( $monitor_key ))
						$this->flag ['common_id'] = $common_id;
                        
				$this->flag ['common_name'] = $common_field_name;
			}
            
            $site_data = $this->site_model->getSiteData ( $mapSite );
			if (! empty ( $site_data )) {
				$this->flag ['site_name'] = $site_data ['site'];
				$this->flag ['address1'] = $site_data ['address1'];
				$this->flag ['address2'] = $site_data ['address2'];
				$this->flag ['city'] = $site_data ['city'];
				$this->flag ['maplabel'] = $site_data ['maplabel'];
				$this->flag ['postalcode'] = $site_data ['postalcode'];
				$this->flag ['idstate'] = $site_data ['idstate'];
				$this->flag ['latitude'] = $site_data ['latitude'];
				$this->flag ['longitude'] = $site_data ['longitude'];
                $this->flag ['idsitetype'] = $site_data ['idsitetype'];
				if ($site_data ['water_of_us'] == '1')
					$this->flag ['sitecategory'] = 'water of the us';
				
				$this->flag ['landingrate_site'] = $site_data ['landingrate_site'];
				$this->flag ['larval_site'] = $site_data ['larval_site'];
				$this->flag ['adult_site'] = $site_data ['adult_site'];
				$this->flag ['apiary'] = $site_data ['apiary'];
				$this->flag ['contact_before_spray'] = $site_data ['contact_before_spray'];
				$this->flag ['organic_farm'] = $site_data ['organic_farm'];
				$this->flag ['nospray'] = $site_data ['nospray'];
				$this->flag ['water_of_us'] = $site_data ['water_of_us'];
				$this->flag ['endangered_species'] = $site_data ['endangered_species'];
                $this->sites = $this->site_model->getSelectedExistingSite ( ! empty ( $site_data['idsite'] ) ? $site_data ['idsite'] : '' );
				$this->zones = $this->site_model->getSelectedZones ( ! empty ( $site_data ['idzone'] ) ? $site_data ['idzone'] : '' );				
			}
			
			$return = array (
					'date' => $this->date,
					'time' => date ( 'h:i:s A', strtotime ( $time1 ) ),
					'sites' => $this->sites,
					'site_type' => $this->site_type,
					'sitegroup' => $this->sitegroup,
					'zones' => $this->zones,
					'states' => $this->states,
					'applicator' => $this->applicator,
					'application_method' => $this->application_method,
					'application_rate_type' => $this->application_rate_type,
					'product_preferences' => $this->product_preferences,
					'applicationrateuom' => $this->applicationrateuom,
					'product' => $this->product_1,
					'formulation' => $this->formulation,
					'mixratio' => $this->mixratio,
					'uomfinishedmix' => $this->finishedmix,
					'uomtotalareatreated' => $this->ttl_area_treated,
					'uomtotalproductapplied' => $this->ttl_prdct_applied,
					'system' => $this->system,
					'dilutent' => $this->dilutent,
					'tempatstart' => $this->tempatstart,
					'tempatend' => $this->tempatend,
					'windspeed' => $this->windspeed,
					'humidity' => $this->humidity,
					'cloudcover' => $this->cloudcover,
					'flowratetypes' => $this->flowratetypes,
					'winddirection' => $this->winddirection,
					'justification' => $this->justification,
                    'app_lang' => $this->app_lang,
                    'mapFlag' => $mapFlag 
			);
			
			if (! empty ( $this->flag )) {
				$this->flag = array_merge ( $this->flag, $return );
			} else {
				$this->flag = $return;
			}
			
			$data_1 = array (
                'state_list' => $this->landingrate_model->getStateName () 
			);
			$this->flag ['location_view'] = $this->load->view ( 'treatment/location_view', $data_1, TRUE );
            
            $mapData = $this->getAllEventsData($mapSite);
            $this->flag = array_merge($this->flag, $mapData);
            
			$this->load->view ( 'treatment/add_adult_treatment', $this->flag );
		}
        
        if(empty($mapFlag)){
            $this->load->view ( 'footer' );
        }
	}
	
	/**
	 * Function to add a new Adult Treatment
	 */
	public function addadulttreatment() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => 'Treatment',
					'page' => "treatment",
                    'app_lang' => $this->app_lang 
			)
			;
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			
			$this->form_validation->set_rules ( 'date', $this->lang->line('adlt_trtmnt_date'), 'trim|required' );
			$this->form_validation->set_rules ( 'time', $this->lang->line('adlt_trtmnt_time'), 'trim|required' );
			$this->form_validation->set_rules ( 'site', $this->lang->line('whthr_snsr_site_nm'), 'trim' );
			$this->form_validation->set_rules ( 'idsitetype', $this->lang->line('trap_mgmt_site_type'), 'trim' );
			$this->form_validation->set_rules ( 'idzone', $this->lang->line('site_mgmt_zone'), 'trim' );
			$this->form_validation->set_rules ( 'latitude', $this->lang->line('site_mgmt_lat'), 'trim|numeric|required' );
			$this->form_validation->set_rules ( 'longitude', $this->lang->line('site_mgmt_lng'), 'trim|numeric|required' );
			
			$this->form_validation->set_rules ( 'equipmentserial', $this->lang->line('adlt_trtmnt_eqpmnt_srl'), 'trim' );
			$this->form_validation->set_rules ( 'odometerstart', $this->lang->line('adlt_trtmnt_odmtr_strt'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'odometerend', $this->lang->line('adlt_trtmnt_odmtr_end'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'applicationstartdate', $this->lang->line('application_start_date'), 'trim' );
			$this->form_validation->set_rules ( 'applicationstarttime', $this->lang->line('application_start_time'), 'trim' );
			
			$this->form_validation->set_rules ( 'applicationenddate', $this->lang->line('application_end_date'), 'trim' );
			$this->form_validation->set_rules ( 'applicationendtime', $this->lang->line('application_end_time'), 'trim' );
			
			$this->form_validation->set_rules ( 'tempatthreem', $this->lang->line('adlt_trtmnt_temp_min'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'tempattenm', $this->lang->line('adlt_trtmnt_temp_max'), 'trim|numeric' );
			
			$this->form_validation->set_rules ( 'applicationrate', $this->lang->line('adlt_trtmnt_app_rate'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'finishedmix', $this->lang->line('adlt_trtmnt_finished_mix'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'flowrate', $this->lang->line('adlt_trtmnt_flw_rate'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'comments', $this->lang->line('cmn_lbl_cmnts'), 'trim' );
			$this->form_validation->set_rules ( 'maplabel', $this->lang->line('site_mgmt_map_lbl'), 'trim' );
			
			$this->form_validation->set_rules ( 'address1', $this->lang->line('site_mgmt_addrs_1'), 'trim' );
			$this->form_validation->set_rules ( 'address2', $this->lang->line('site_mgmt_addrs_2'), 'trim' );
			$this->form_validation->set_rules ( 'city', $this->lang->line('site_mgmt_cty'), 'trim' );
			$this->form_validation->set_rules ( 'postalcode', $this->lang->line('site_mgmt_postl_cde'), 'trim|integer|max_length[10]' );
			
			$this->form_validation->set_rules ( 'totalproductapplied', $this->lang->line('adlt_trtmnt_ttl_prdct_appld'), 'trim|numeric|required' );
			$this->form_validation->set_rules ( 'totalareatreated', $this->lang->line('lrvl_trtmnt_ttl_area_trtd'), 'trim|numeric|required' );
			$this->form_validation->set_rules ( 'idapplicationmethod', $this->lang->line('trtmnts_mthd'), 'trim|required' );
			$this->form_validation->set_rules ( 'idproduct', $this->lang->line('hm_prdct'), 'trim|integer|required' );
			
			$req = $this->input->post ( 'treatment' );
			
			if ($this->form_validation->run () == FALSE) {
				$return = array (
						'unsuccess_msg' => "Something Went Wrong" 
				);
				
				if (! empty ( $req )) {
					$this->flag = $this->treatment_model->getAdultTreatmentData ( $req );
					
					// print'<pre>';
					// print_r($this->flag);
					// die;
					
					if (! empty ( $this->flag )) {
						/* Common Treatment Functions For Edit Fuunctionality Start */
						$this->date = $this->flag ['date'];
						$this->time = $this->flag ['time'];
						$this->sites = $this->site_model->getSelectedExistingSite ( $this->flag ['idsite'] );
						$this->site_type = $this->site_model->getSelected_sitetype ( $this->flag ['idsitetype'] );
						
						// $this->zones = $this->site_model->getSelectedSiteZones($this->flag['idsite']);
						$this->zones = $this->site_model->getSelectedZones ( $this->flag ['idzone'] );
						
						$this->states = $this->site_model->getSelectedSiteStates ( $this->flag ['idsite'] );
						
						$this->applicator = $this->larvalsurveillance_model->getSelectedInspectors ( $this->flag ['idapplicator'] );
						$this->application_method = $this->treatment_model->getAppMethod ( $this->flag ['idapplicationmethod'] );
						$this->applicationrateuom = $this->treatment_model->getAppRate ( $this->flag ['idapplicationrateuom'] );
						$this->application_rate_type = $this->treatment_model->getAppRateType ( $this->flag ['idapplicationratetype'] );
						$this->product_preferences = $this->product_model->getProductPref ( $this->flag ['idproduct'] );
						$this->product_1 = $this->treatment_model->getProducts ( $this->flag ['idproduct'], '1' );
						$this->formulation = $this->treatment_model->getFormulation ( $this->flag ['idformulation'] );
						$this->mixratio = $this->treatment_model->getMixRatio ( $this->flag ['idmixratio'] );
						$this->finishedmix = $this->treatment_model->getFinishedMix ( $this->flag ['iduomfinishedmix'] );
						$this->ttl_area_treated = $this->treatment_model->getTAreaTreated ( $this->flag ['iduomtotalareatreated'] );
						$this->ttl_prdct_applied = $this->treatment_model->getTProductApp ( $this->flag ['iduomtotalproductapplied'] );
						$site_data = $this->site_model->getSiteData ( $this->flag ['idsite'] );
						/* Common Treatment Functions For Edit Fuunctionality End */
						
						/* Adulticide Treatment Function For Edit Fuunctionality Start */
						$this->system = $this->treatment_model->getSystem ( $this->flag ['idsystemtype'] );
						$this->dilutent = $this->treatment_model->getDilutent ( $this->flag ['iddilutent'] );
						$this->tempatstart = $this->adultsurveillance_model->getSelectedTemprange ( $this->flag ['idtempatstart'] );
						$this->tempatend = $this->adultsurveillance_model->getSelectedTemprange ( $this->flag ['idtempatend'] );
						$this->windspeed = $this->adultsurveillance_model->getSelectedWindspeed ( $this->flag ['idwindspeed'] );
						$this->humidity = $this->adultsurveillance_model->getSelectedHumidityrange ( $this->flag ['idhumidityrange'] );
						$this->cloudcover = $this->adultsurveillance_model->getSelectedCloudcoverage ( $this->flag ['idcloudcover'] );
						$this->flowratetypes = $this->treatment_model->getFlowRateType ( $this->flag ['idflowratetypes'] );
						/* Adulticide Treatment Function For Edit Fuunctionality End */
						
						$site_data = $this->site_model->getSiteData ( $this->flag ['idsite'] );
						
						if (! empty ( $site_data )) {
							$this->flag ['site_name'] = $site_data ['site'];
							$this->flag ['address1'] = $site_data ['address1'];
							$this->flag ['address2'] = $site_data ['address2'];
							$this->flag ['city'] = $site_data ['city'];
							$this->flag ['maplabel'] = $site_data ['maplabel'];
							$this->flag ['postalcode'] = $site_data ['postalcode'];
						}
					}
				} else {
					/* Common Treatment Functions For Edit Fuunctionality Start */
					$this->date = $this->input->post ( 'date' );
					$this->time = $this->input->post ( 'time' );
					$this->sites = $this->site_model->getSelectedExistingSite ( $this->input->post ( 'site' ) );
					$this->site_type = $this->site_model->getSelected_sitetype ( $this->input->post ( 'idsitetype' ) );
					
					// $this->zones = $this->site_model->getSelectedSiteZones($this->flag['idsite']);
					$this->zones = $this->site_model->getSelectedZones ( $this->input->post ( 'idzone' ) );
					
					$this->states = $this->site_model->getSelectedSiteStates ( $this->input->post ( 'site' ) );
					
					$this->applicator = $this->larvalsurveillance_model->getSelectedInspectors ( $this->input->post ( 'idapplicator' ) );
					$this->application_method = $this->treatment_model->getAppMethod ( $this->input->post ( 'idapplicationmethod' ) );
					$this->applicationrateuom = $this->treatment_model->getAppRate ( $this->input->post ( 'idapplicationrateuom' ) );
					$this->application_rate_type = $this->treatment_model->getAppRateType ( $this->input->post ( 'idapplicationratetype' ) );
					$this->product_preferences = $this->product_model->getProductPref ( $this->input->post ( 'idproduct' ) );
					$this->product_1 = $this->treatment_model->getProducts ( $this->input->post ( 'idproduct' ), '1' );
					$this->formulation = $this->treatment_model->getFormulation ( $this->input->post ( 'idformulation' ) );
					$this->mixratio = $this->treatment_model->getMixRatio ( $this->input->post ( 'idmixratio' ) );
					$this->finishedmix = $this->treatment_model->getFinishedMix ( $this->input->post ( 'iduomfinishedmix' ) );
					$this->ttl_area_treated = $this->treatment_model->getTAreaTreated ( $this->input->post ( 'iduomtotalareatreated' ) );
					$this->ttl_prdct_applied = $this->treatment_model->getTProductApp ( $this->input->post ( 'iduomtotalproductapplied' ) );
					$site_data = $this->site_model->getSiteData ( $this->input->post ( 'idsite' ) );
					/* Common Treatment Functions For Edit Fuunctionality End */
					
					/* Adulticide Treatment Function For Edit Fuunctionality Start */
					$this->system = $this->treatment_model->getSystem ( $this->input->post ( 'idsystemtype' ) );
					$this->dilutent = $this->treatment_model->getDilutent ( $this->input->post ( 'iddilutent' ) );
					$this->tempatstart = $this->adultsurveillance_model->getSelectedTemprange ( $this->input->post ( 'idtempatstart' ) );
					$this->tempatend = $this->adultsurveillance_model->getSelectedTemprange ( $this->input->post ( 'idtempatend' ) );
					$this->windspeed = $this->adultsurveillance_model->getSelectedWindspeed ( $this->input->post ( 'idwindspeed' ) );
					$this->humidity = $this->adultsurveillance_model->getSelectedHumidityrange ( $this->input->post ( 'idhumidityrange' ) );
					$this->cloudcover = $this->adultsurveillance_model->getSelectedCloudcoverage ( $this->input->post ( 'idcloudcover' ) );
					$this->flowratetypes = $this->treatment_model->getFlowRateType ( $this->input->post ( 'idflowratetypes' ) );
					/* Adulticide Treatment Function For Edit Fuunctionality End */
					
					$site_data = $this->site_model->getSiteData ( $this->input->post ( 'site' ) );
					
					if (! empty ( $site_data )) {
						$this->flag ['site_name'] = $site_data ['site'];
						$this->flag ['address1'] = $site_data ['address1'];
						$this->flag ['address2'] = $site_data ['address2'];
						$this->flag ['city'] = $site_data ['city'];
						$this->flag ['maplabel'] = $site_data ['maplabel'];
						$this->flag ['postalcode'] = $site_data ['postalcode'];
					}
				}
				// code for list site when request come from larval surveilance
				
				$adult_key = $this->input->post ( 'adult_key' );
				$service_req_id = $this->input->post ( 'service_req_id' );
				$monitor_key = $this->input->post ( 'monitor_key' );
				
				$common_as_id = '';
				if (! empty ( $adult_key )) {
					$common_as_id = $adult_key;
				} else if (! empty ( $service_req_id )) {
					$common_as_id = $service_req_id;
				} else if (! empty ( $monitor_key )) {
					$common_as_id = $monitor_key;
				}
				
				if (! empty ( $common_as_id )) {
					if (! empty ( $adult_key )) {
						$this->flag = $this->larvalsurveillance_model->getLarvalsurveillanceData ( $adult_key );
					} else if (! empty ( $service_req_id )) {
						$this->flag = $this->service_requestmodel->getServiceRequestData ( $service_req_id );
					} else if (! empty ( $monitor_key )) {
						$monitor_data = $this->monitor_model->getMonitorData ( $monitor_key );
						if(!empty($monitor_data) && !empty($monitor_data['mission_type']) && ($monitor_data['mission_type'] == 'M4' || $monitor_data['mission_type'] == 'M4S')) {
                            $this->flag ['idapplicationmethod'] = '14';
                        }
						$this->flag ['idsystemtype'] = $this->monitor_model->getSystemType ( ! empty ( $monitor_data ['mission_type'] ) ? $monitor_data ['mission_type'] : '' );
					
    					$this->system = $this->treatment_model->getSystem ( ! empty ( $this->flag ['idsystemtype'] ) ? $this->flag ['idsystemtype'] : '' );
    					$this->flag ['time'] = date ( 'h:i:s A', strtotime ( ! empty ( $monitor_data ['end_time'] ) ? $monitor_data ['end_time'] : '' ) );
    					$this->flag ['equipmentserial'] = ! empty ( $monitor_data ['equipment_id'] ) ? $monitor_data ['equipment_id'] : '';
    					
    					$this->flag ['applicationstartdate'] = ! empty ( $monitor_data ['applicationstartdate'] ) ? $monitor_data ['applicationstartdate'] : '';
    					$this->flag ['applicationenddate'] = ! empty ( $monitor_data ['applicationenddate'] ) ? $monitor_data ['applicationenddate'] : '';
    					
    					$this->flag ['applicationstarttime'] = ! empty ( $monitor_data ['start_time'] ) ? $monitor_data ['start_time'] : '';
    					$this->flag ['applicationendtime'] = ! empty ( $monitor_data ['end_time'] ) ? $monitor_data ['end_time'] : '';
    					$this->flag ['applicationrate'] = ! empty ( $monitor_data ['applicationrate'] ) ? $monitor_data ['applicationrate'] : '';
    					$this->flag ['flowrate'] = ! empty ( $monitor_data ['flowrate'] ) ? $monitor_data ['flowrate'] : '';
    					$this->flag ['totalareatreated'] = ! empty ( $monitor_data ['acreage_sprayed'] ) ? $monitor_data ['acreage_sprayed'] : '';
    					$this->flag ['totalproductapplied'] = ! empty ( $monitor_data ['gallons_sprayed'] ) ? $monitor_data ['gallons_sprayed'] : '';
    					$this->flag ['iduomtotalareatreated'] = "1";
    					$this->flag ['iduomtotalproductapplied'] = "2";
    					$this->flag ['idsite'] = ! empty ( $monitor_data ['idsite'] ) ? $monitor_data ['idsite'] : '';
                        $this->flag ['idproduct'] = ! empty ( $monitor_data ['idproduct'] ) ? $monitor_data ['idproduct'] : '';
                        $this->flag ['idproductpreferences'] = ! empty ( $monitor_data ['idapplicationratetype'] ) ? $monitor_data ['idapplicationratetype'] : '';
                        
                        $idapplicator = $this->membermodel->getUserIdByName ( ! empty ( $monitor_data ['operator_name'] ) ? $monitor_data ['operator_name'] : '' );
                        $this->applicator = $this->larvalsurveillance_model->getSelectedInspectors ( $idapplicator );
    					$this->ttl_prdct_applied = $this->treatment_model->getTProductApp ( $this->flag ['iduomtotalproductapplied'] );
    					$this->ttl_area_treated = $this->treatment_model->getTAreaTreated ( $this->flag ['iduomtotalareatreated'] );
    					$this->product_1 = $this->treatment_model->getProducts ( $this->flag ['idproduct'], '1' );
                        $this->product_preferences = $this->product_model->getProductPref ( $this->flag ['idproduct'] );
                        
    					$this->applicationrateuom = $this->treatment_model->getAppRate ( '2' );
    					$this->flowratetypes = $this->treatment_model->getFlowRateType ( '4' );
					}
					
					if (! empty ( $this->flag )) {
						$this->date = $this->flag ['date'];
						$this->time = $this->flag ['time'];
						$this->sites = $this->site_model->getSelectedExistingSite ( $this->flag ['idsite'] );
						$this->site_type = $this->site_model->getSelected_sitetype ( $this->flag ['idsitetype'] );
						// $this->zones = $this->site_model->getSelectedSiteZones($this->flag['idsite']);
						$this->zones = $this->site_model->getSelectedZones ( $this->flag ['idzone'] );
						$this->states = $this->site_model->getSelectedSiteStates ( $this->flag ['idsite'] );
						$site_data = $this->site_model->getSiteData ( $this->flag ['idsite'] );
						if (! empty ( $site_data )) {
							$this->flag ['site_name'] = $site_data ['site'];
							$this->flag ['address1'] = $site_data ['address1'];
							$this->flag ['address2'] = $site_data ['address2'];
							$this->flag ['city'] = $site_data ['city'];
							$this->flag ['maplabel'] = $site_data ['maplabel'];
							$this->flag ['postalcode'] = $site_data ['postalcode'];
							
                            if (! empty ( $adult_key ))
								$this->flag ['common_id'] = $adult_key;
							else if (! empty ( $service_req_id ))
								$this->flag ['common_id'] = $service_req_id;
							else if (! empty ( $monitor_key ))
								$this->flag ['common_id'] = $common_as_id;
						}
					}
				}
				$return = array (
						'sites' => $this->sites,
						'site_type' => $this->site_type,
						'zones' => $this->zones,
						'states' => $this->states,
						'sitegroup' => $this->sitegroup,
						'applicator' => $this->applicator,
						'application_method' => $this->application_method,
						'application_rate_type' => $this->application_rate_type,
						'product_preferences' => $this->product_preferences,
						'applicationrateuom' => $this->applicationrateuom,
						'product' => $this->product_1,
						'formulation' => $this->formulation,
						'mixratio' => $this->mixratio,
						'uomfinishedmix' => $this->finishedmix,
						'uomtotalareatreated' => $this->ttl_area_treated,
						'uomtotalproductapplied' => $this->ttl_prdct_applied,
						'system' => $this->system,
						'dilutent' => $this->dilutent,
						'tempatstart' => $this->tempatstart,
						'tempatend' => $this->tempatend,
						'windspeed' => $this->windspeed,
						'humidity' => $this->humidity,
						'cloudcover' => $this->cloudcover,
						'flowratetypes' => $this->flowratetypes,
						'justification' => $this->justification,
                        'app_lang' => $this->app_lang 
				);
				
				if (! empty ( $this->flag ) && empty ( $common_as_id )) {
					$this->flag = array_merge ( $this->flag, $return );
				} else if (! empty ( $common_as_id )) {
					$this->flag = array_merge ( $this->flag, $return );
				} else {
					$this->flag = $return;
				}
				
				$this->load->view ( 'treatment/add_adult_treatment', $this->flag );
			} else {
				// print'<pre>';
				// print_r($this->session->userdata('url'));
				// die;
				$flag_1 = $this->treatment_model->addAdultTreatment ( $req );
				// $flag_1 = '';
				
				// redirect to service request page or larvalsurveillance page
				$service_req_id = $this->input->get_post ( 'service_req_id' );
				$adult_key = $this->input->get_post ( 'adult_key' );
				$monitor_id = $this->input->get_post ( 'monitor_id' );
				if (! empty ( $service_req_id ) || ! empty ( $adult_key )) {
					$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
					if (! empty ( $service_req_id ) && ! empty ( $flag_1 )) {
						// redirect(base_url()."service_request/getservice_request/?msg=success");
						if (! empty ( $seturl [1] ))
							redirect ( $seturl [0] . "?msg=success#" . $seturl [1] );
						else
							redirect ( $seturl [0] . "?msg=success" );
					} else if (! empty ( $adult_key ) && ! empty ( $flag_1 )) {
						if (! empty ( $seturl [1] ))
							redirect ( $seturl [0] . "?msg=success#" . $seturl [1] );
						else
							redirect ( $seturl [0] . "?msg=success" );
					}
				} else {
					if (! empty ( $flag_1 ) && empty ( $req ) && ! empty ( $monitor_id )) {
						$newdata = array (
								'url' => base_url () . 'treatment/gettreatment?msg=success' 
						);
						
						$this->session->set_userdata ( $newdata );
						redirect ( $newdata ['url'] );
					} else if (! empty ( $flag_1 ) && empty ( $req )) {
						$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
						if (! empty ( $seturl [1] ))
							redirect ( $seturl [0] . "?id=" . $flag_1 . "&msg=success#" . $seturl [1] );
						else
							redirect ( $seturl [0] . "?id=" . $flag_1 . "&msg=success" );
						// redirect(base_url()."treatment/gettreatment?id=".$flag_1);
					} else if (! empty ( $flag_1 ) && ! empty ( $req )) {
						$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
						if (! empty ( $seturl [1] ))
							redirect ( $seturl [0] . "?id=" . $flag_1 . "&msg=update#" . $seturl [1] );
						else
							redirect ( $seturl [0] . "?id=" . $flag_1 . "&msg=update" );
						// redirect(base_url()."treatment/gettreatment?id=".$flag_1."&msg=update");
					} else {
						$return = array (
								'msg' => "error" 
						);
						
						if (! empty ( $this->flag ))
							$this->flag = array_merge ( $flag, $return );
						else
							$this->flag = $return;
						
						$this->load->view ( 'treatment/add_adult_treatment', $this->flag );
					}
				}
			}
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to add a new Larva Treatment
	 */
	public function addlarvatreatment() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => 'Treatment',
					'page' => "treatment",
                    'app_lang' => $this->app_lang 
			)
			;
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			// print'<pre>';
			// print_r($_POST);
			// die;
			$sourcereduction = $this->input->post ( 'sourcereduction' );
			$site = $this->input->post ( 'site' );
			$idsitetype = $this->input->post ( 'idsitetype' );
			$idsitestatus = $this->input->post ( 'idsitestatus' );
			$idwatertemp = $this->input->post ( 'idwatertemp' );
			$idlarvaelcountrange = $this->input->post ( 'totalcount' );
			$idweatherconditions = $this->input->post ( 'idweatherconditions' );
			$larvaepresent = $this->input->post ( 'larvaepresent' );
			$idinstar = $this->input->post ( 'idinstar' );
			$idapplicator = $this->input->post ( 'idapplicator' );
			$idapplicationmethod = $this->input->post ( 'idapplicationmethod' );
			$idproduct = $this->input->post ( 'idproduct' );
			$idformulation = $this->input->post ( 'idformulation' );
			$idapplicationratetype = $this->input->post ( 'idapplicationratetype' );
			$idapplicationrateuom = $this->input->post ( 'idapplicationrateuom' );
			$idmixratio = $this->input->post ( 'idmixratio' );
			$iduomfinishedmix = $this->input->post ( 'iduomfinishedmix' );
			$totalproductapplied = $this->input->post ( 'totalproductapplied' );
			$iduomtotalproductapplied = $this->input->post ( 'iduomtotalproductapplied' );
			$totalareatreated = $this->input->post ( 'totalareatreated' );
			$iduomtotalareatreated = $this->input->post ( 'iduomtotalareatreated' );
			
			$sourcereduction = (! empty ( $sourcereduction ) && $sourcereduction == "on") ? 1 : 0;
			
			$this->form_validation->set_rules ( 'date', $this->lang->line('lrvl_trtmnt_date'), 'trim|required' );
			$this->form_validation->set_rules ( 'time', $this->lang->line('cmn_time'), 'trim|required' );
			$this->form_validation->set_rules ( 'idsite', $this->lang->line('whthr_snsr_site_nm'), 'trim' );
			$this->form_validation->set_rules ( 'idsitetype', $this->lang->line('trap_mgmt_site_type'), 'trim' );
			$this->form_validation->set_rules ( 'idzone', 'Zone', 'trim' );
			$this->form_validation->set_rules ( 'latitude', $this->lang->line('site_mgmt_lat'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'longitude', $this->lang->line('site_mgmt_lng'), 'trim|numeric' );
			
			$this->form_validation->set_rules ( 'equipemtnid', $this->lang->line('lrvl_trtmnt_eqpmntid'), 'trim|alpha_numeric' );
			$this->form_validation->set_rules ( 'finishedmix', 'Finishedmix', 'trim|numeric' );
			$this->form_validation->set_rules ( 'applicationrate', $this->lang->line('adlt_trtmnt_app_rate'), 'trim|numeric' );
			
			$this->form_validation->set_rules ( 'maplabel', $this->lang->line('site_mgmt_map_lbl'), 'trim' );
			
			$this->form_validation->set_rules ( 'address1', $this->lang->line('site_mgmt_addrs_1'), 'trim' );
			$this->form_validation->set_rules ( 'address2', $this->lang->line('site_mgmt_addrs_2'), 'trim' );
			$this->form_validation->set_rules ( 'city', $this->lang->line('site_mgmt_cty'), 'trim' );
			$this->form_validation->set_rules ( 'postalcode', $this->lang->line('site_mgmt_postl_cde'), 'trim|integer|max_length[10]' );
			
			$this->form_validation->set_rules ( 'sourcereduction', $this->lang->line('drpdwn_source_reduction'), 'trim' );
			$this->form_validation->set_rules ( 'sourcereductioncomments', $this->lang->line('lrvl_trtmnt_srcrdctn_cmnts'), 'trim' );
			
			$this->form_validation->set_rules ( 'comments', $this->lang->line('cmn_lbl_cmnts'), 'trim' );
			$this->form_validation->set_rules ( 'totalproductapplied', $this->lang->line('adlt_trtmnt_ttl_prdct_appld'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'totalareatreated', $this->lang->line('lrvl_trtmnt_ttl_area_trtd'), 'trim|numeric' );
			
			if (empty ( $sourcereduction )) {
				$this->form_validation->set_rules ( 'idproduct', $this->lang->line('hm_prdct'), 'trim|integer|required' );
				$this->form_validation->set_rules ( 'totalareatreated', $this->lang->line('lrvl_trtmnt_ttl_area_trtd'), 'trim|numeric|required' );
				$this->form_validation->set_rules ( 'idapplicationmethod', $this->lang->line('trtmnts_mthd'), 'trim|required' );
			}
			
			$this->form_validation->set_rules ( 'idapplicator', $this->lang->line('adlt_trtmnt_applicator'), 'trim|required' );
			
			$req = $this->input->post ( 'treatment' );
			$pti = $this->input->post ( 'post_trtmnt_inspection' );
			// echo $pti;die;
			if ($this->form_validation->run () == FALSE) {
				$return = array (
						'unsuccess_msg' => "Something Went Wrong" 
				);
				
				if (! empty ( $req )) {
					$this->flag = $this->treatment_model->getLarvalTreatmentData ( $req );
					
					// print'<pre>';
					// print_r($this->flag);
					// die;
					
					if (! empty ( $this->flag )) {
						$this->date = $this->flag ['date'];
						$this->time = $this->flag ['time'];
						$this->sites = $this->site_model->getSelectedExistingSite ( $this->flag ['idsite'] );
						$this->site_type = $this->site_model->getSelected_sitetype ( $this->flag ['idsitetype'] );
						// $this->zones = $this->site_model->getSelectedSiteZones($this->flag['idsite']);
						$this->zones = $this->site_model->getSelectedZones ( $this->flag ['idzone'] );
						$this->states = $this->site_model->getSelectedSiteStates ( $this->flag ['idsite'] );
						$this->site_status = $this->larvalsurveillance_model->getSelectedSitestatus ( $this->flag ['idsitestatus'] );
						$this->watertemp = $this->larvalsurveillance_model->getWatertemprange ( $this->flag ['idwatertemp'] );
						
						$this->instar = $this->larvalsurveillance_model->getInstar ( $this->flag ['idinstar'] );
						$this->larvacount = $this->larvalsurveillance_model->getLarvaecount ( $this->flag ['idlarvaelcountrange'] );
						$this->s_species = $this->treatment_model->getSelectedSpecies ( $this->flag ['idlarvaltreatment'] );
						$this->species = $this->treatment_model->getSpecies ( $this->idlocation );
						$this->applicator = $this->larvalsurveillance_model->getSelectedInspectors ( $this->flag ['idapplicator'] );
						
						$this->weatherconditions = $this->treatment_model->getWheatherCondtn ( $this->flag ['idweatherconditions'] );
						$this->application_method = $this->treatment_model->getAppMethod ( $this->flag ['idapplicationmethod'] );
						$this->applicationrateuom = $this->treatment_model->getAppRate ( $this->flag ['idapplicationrateuom'] );
						$this->application_rate_type = $this->treatment_model->getAppRateType ( $this->flag ['idapplicationratetype'] );
						$this->product_preferences = $this->product_model->getProductPref ( $this->flag ['idproduct'] );
						$this->product_2 = $this->treatment_model->getProducts ( $this->flag ['idproduct'], '2' );
						$this->formulation = $this->treatment_model->getFormulation ( $this->flag ['idformulation'] );
						$this->mixratio = $this->treatment_model->getMixRatio ( $this->flag ['idmixratio'] );
						$this->finishedmix = $this->treatment_model->getFinishedMix ( $this->flag ['iduomfinishedmix'] );
						$this->ttl_area_treated = $this->treatment_model->getTAreaTreated ( $this->flag ['iduomtotalareatreated'] );
						$this->ttl_prdct_applied = $this->treatment_model->getTProductApp ( $this->flag ['iduomtotalproductapplied'] );
						
						$site_data = $this->site_model->getSiteData ( $this->flag ['idsite'] );
						
						if (! empty ( $site_data )) {
							$this->flag ['site_name'] = $site_data ['site'];
							$this->flag ['address1'] = $site_data ['address1'];
							$this->flag ['address2'] = $site_data ['address2'];
							$this->flag ['city'] = $site_data ['city'];
							$this->flag ['maplabel'] = $site_data ['maplabel'];
							$this->flag ['postalcode'] = $site_data ['postalcode'];
						}
					}
				} else {
					$this->sites = $this->site_model->getSelectedExistingSite ( $site );
					$this->site_type = $this->site_model->getSelected_sitetype ( $idsitetype );
					$this->zones = $this->site_model->getSelectedSiteZones ( $site );
					$this->states = $this->site_model->getSelectedSiteStates ( $site );
					$this->site_status = $this->larvalsurveillance_model->getSelectedSitestatus ( $idsitestatus );
					$this->watertemp = $this->larvalsurveillance_model->getWatertemprange ( $idwatertemp );
					$this->instar = $this->larvalsurveillance_model->getInstar ( $idinstar );
					$this->larvacount = $this->larvalsurveillance_model->getLarvaecount ( $idlarvaelcountrange );
					
					$this->applicator = $this->larvalsurveillance_model->getSelectedInspectors ( $idapplicator );
					
					$this->weatherconditions = $this->treatment_model->getWheatherCondtn ( $idweatherconditions );
					$this->application_method = $this->treatment_model->getAppMethod ( $idapplicationmethod );
					$this->applicationrateuom = $this->treatment_model->getAppRate ( $idapplicationrateuom );
					$this->application_rate_type = $this->treatment_model->getAppRateType ( $idapplicationratetype );
					$this->product_preferences = $this->product_model->getProductPref ( $this->input->post ( 'idproduct' ) );
					$this->product = $this->treatment_model->getProducts ( $idproduct );
					$this->formulation = $this->treatment_model->getFormulation ( $idformulation );
					$this->mixratio = $this->treatment_model->getMixRatio ( $idmixratio );
					$this->finishedmix = $this->treatment_model->getFinishedMix ( $iduomfinishedmix );
					$this->ttl_area_treated = $this->treatment_model->getTAreaTreated ( $iduomtotalproductapplied );
					$this->ttl_prdct_applied = $this->treatment_model->getTProductApp ( $iduomtotalareatreated );
				}
				// add additional field such as service request
				$query_string = $this->input->server ( 'QUERY_STRING' );
				$common_field_name = substr ( $query_string, 0, strrpos ( $query_string, '=' ) );
				$service_req_id = $this->input->get_post ( 'service_req_id' );
				$adult_key = $this->input->get_post ( 'adult_key' );
				$monitor_key = $this->input->get_post ( 'monitor_key' );
				
				if (! empty ( $service_req_id )) {
					$common_id = $service_req_id;
				} else if (! empty ( $adult_key )) {
					$common_id = $adult_key;
				} else if (! empty ( $monitor_key )) {
					$common_id = $monitor_key;
				}
				
				if (! empty ( $common_id )) {
					if (! empty ( $service_req_id )) {
						$this->flag = $this->service_requestmodel->getServiceRequestData ( $service_req_id );
					} else if (! empty ( $adult_key )) {
						$this->flag = $this->larvalsurveillance_model->getLarvalsurveillanceData ( $adult_key );
					} else if (! empty ( $monitor_key )) {
						$monitor_data = $this->monitor_model->getMonitorData ( $monitor_key );
						if(!empty($monitor_data) && !empty($monitor_data['mission_type']) && ($monitor_data['mission_type'] == 'M4' || $monitor_data['mission_type'] == 'M4S')) {
                            $this->flag ['idapplicationmethod'] = '14';
                        }
						$this->flag ['idsystemtype'] = $this->monitor_model->getSystemType ( ! empty ( $monitor_data ['mission_type'] ) ? $monitor_data ['mission_type'] : '' );
    					$this->system = $this->treatment_model->getSystem ( ! empty ( $this->flag ['idsystemtype'] ) ? $this->flag ['idsystemtype'] : '' );
    					$this->flag ['time'] = date ( 'h:i:s A', strtotime ( ! empty ( $monitor_data ['end_time'] ) ? $monitor_data ['end_time'] : '' ) );
    					$this->flag ['equipmentserial'] = ! empty ( $monitor_data ['equipment_id'] ) ? $monitor_data ['equipment_id'] : '';
    					
    					$this->flag ['applicationstartdate'] = ! empty ( $monitor_data ['applicationstartdate'] ) ? $monitor_data ['applicationstartdate'] : '';
    					$this->flag ['applicationenddate'] = ! empty ( $monitor_data ['applicationenddate'] ) ? $monitor_data ['applicationenddate'] : '';
    					
    					$this->flag ['applicationstarttime'] = ! empty ( $monitor_data ['start_time'] ) ? $monitor_data ['start_time'] : '';
    					$this->flag ['applicationendtime'] = ! empty ( $monitor_data ['end_time'] ) ? $monitor_data ['end_time'] : '';
    					$this->flag ['totalareatreated'] = ! empty ( $monitor_data ['acreage_sprayed'] ) ? $monitor_data ['acreage_sprayed'] : '';
    					$this->flag ['totalproductapplied'] = ! empty ( $monitor_data ['gallons_sprayed'] ) ? $monitor_data ['gallons_sprayed'] : '';
    					$this->flag ['idsite'] = ! empty ( $monitor_data ['idsite'] ) ? $monitor_data ['idsite'] : '';
                        $this->flag ['idproduct'] = ! empty ( $monitor_data ['idproduct'] ) ? $monitor_data ['idproduct'] : '';
                        $this->flag ['idproductpreferences'] = ! empty ( $monitor_data ['idapplicationratetype'] ) ? $monitor_data ['idapplicationratetype'] : '';
    					$this->flag ['iduomtotalareatreated'] = "1";
    					$this->flag ['iduomtotalproductapplied'] = "2";
    					
    					$this->ttl_prdct_applied = $this->treatment_model->getTProductApp ( $this->flag ['iduomtotalproductapplied'] );
    					$this->ttl_area_treated = $this->treatment_model->getTAreaTreated ( $this->flag ['iduomtotalareatreated'] );
    					$this->product_2 = $this->treatment_model->getProducts ( $this->flag ['idproduct'], array (
    							'2',
    							'12' 
    					) );
                        $this->product_preferences = $this->product_model->getProductPref ( $this->flag ['idproduct'] );
    					$this->applicationrateuom = $this->treatment_model->getAppRate ( '2' );
                        
                        $idapplicator = $this->membermodel->getUserIdByName ( ! empty ( $monitor_data ['operator_name'] ) ? $monitor_data ['operator_name'] : '' );
                        $this->applicator = $this->larvalsurveillance_model->getSelectedInspectors ( $idapplicator );
					}
					
					if (! empty ( $this->flag )) {
						$this->date = $this->flag ['date'];
						$this->time = $this->flag ['time'];
						
						$this->sites = $this->site_model->getSelectedExistingSite ( $this->flag ['idsite'] );
						$this->site_type = $this->site_model->getSelected_sitetype ( $this->flag ['idsitetype'] );
						// $this->zones = $this->site_model->getSelectedSiteZones($this->flag['idsite']);
						$this->zones = $this->site_model->getSelectedZones ( $this->flag ['idzone'] );
						$this->states = $this->site_model->getSelectedSiteStates ( $this->flag ['idsite'] );
						$site_data = $this->site_model->getSiteData ( $this->flag ['idsite'] );
						if (! empty ( $site_data )) {
							$this->flag ['site_name'] = $site_data ['site'];
							$this->flag ['address1'] = $site_data ['address1'];
							$this->flag ['address2'] = $site_data ['address2'];
							$this->flag ['city'] = $site_data ['city'];
							$this->flag ['maplabel'] = $site_data ['maplabel'];
							$this->flag ['postalcode'] = $site_data ['postalcode'];
						}
						
						if (! empty ( $adult_key ))
							$this->flag ['adult_key'] = $common_id;
						else if (! empty ( $service_req_id ))
							$this->flag ['service_req_id'] = $common_id;
						else if (! empty ( $monitor_key ))
							$this->flag ['monitor_key'] = $common_id;
						
						$this->flag ['common_name'] = $common_field_name;
					}
				}
				$return = array (
						'sites' => $this->sites,
						'site_type' => $this->site_type,
						'zones' => $this->zones,
						'states' => $this->states,
						'sitegroup' => $this->sitegroup,
						'applicator' => $this->applicator,
						'instar' => $this->instar,
						'larvacount' => $this->larvacount,
						'species' => $this->species,
						's_species' => $this->s_species,
						'site_status' => $this->site_status,
						'watertemp' => $this->watertemp,
						'weatherconditions' => $this->weatherconditions,
						'application_method' => $this->application_method,
						'application_rate_type' => $this->application_rate_type,
						'product_preferences' => $this->product_preferences,
						'applicationrateuom' => $this->applicationrateuom,
						'product' => $this->product_2,
						'formulation' => $this->formulation,
						'mixratio' => $this->mixratio,
						'uomfinishedmix' => $this->finishedmix,
						'uomtotalareatreated' => $this->ttl_area_treated,
						'uomtotalproductapplied' => $this->ttl_prdct_applied,
						'totalproductapplied' => $totalproductapplied,
						'totalareatreated' => $totalareatreated,
						'sourcereduction' => $sourcereduction,
						'justification' => $this->justification,
                        'app_lang' => $this->app_lang 
				);
				
				if (! empty ( $this->flag )) {
					$this->flag = array_merge ( $this->flag, $return );
				} else {
					$this->flag = $return;
				}
				
				$this->load->view ( 'treatment/add_larval_treatment', $this->flag );
			} else {
				$flag_1 = $this->treatment_model->addLarvalTreatment ( $req );
				// $flag_1 = 73302;
				// print'<pre>';
				// print_r($flag_1);
				// die;
				// code for redirect page when come from service request or larvalsurveillance
				$service_req_id = $this->input->get_post ( 'service_req_id' );
				$adult_key = $this->input->get_post ( 'adult_key' );
				$monitor_id = $this->input->get_post ( 'monitor_id' );
				if ($flag_1 && empty ( $req ) && ! empty ( $monitor_id )) {
					$newdata = array (
							'url' => base_url () . 'treatment/gettreatment?msg=success' 
					);
					
					$this->session->set_userdata ( $newdata );
					redirect ( $newdata ['url'] );
				} else if (! empty ( $pti ) && ! empty ( $req )) {
					$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
					if (! empty ( $seturl [1] ))
						redirect ( $seturl [0] . "?id=" . $flag_1 . "&msg=update#" . $seturl [1] );
					else
						redirect ( $seturl [0] . "?id=" . $flag_1 . "&msg=update" );
				} else if (! empty ( $pti )) {
					$this->flag ['redirect'] = true;
					$this->flag ['id'] = $flag_1;
					$this->load->view ( 'treatment/add_larval_treatment', array (
							'data' => $this->flag 
					) );
				} else if (! empty ( $service_req_id ) || ! empty ( $adult_key )) {
					$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
					if (! empty ( $service_req_id )) {
						if (! empty ( $seturl [1] ))
							redirect ( $seturl [0] . "?msg=success#" . $seturl [1] );
						else
							redirect ( $seturl [0] . "?msg=success" );
						// redirect(base_url()."service_request/getservice_request?msg=success");
					}
					if (! empty ( $adult_key )) {
						if (! empty ( $seturl [1] ))
							redirect ( $seturl [0] . "?msg=success#" . $seturl [1] );
						else
							redirect ( $seturl [0] . "?msg=success" );
						// redirect(base_url()."larvalsurveillance/getlarvalsurveillance?msg=success");
					}
				} else {
					$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
					if ($flag_1 && empty ( $req )) {
						if (! empty ( $seturl [1] ))
							redirect ( $seturl [0] . "?id=" . $flag_1 . "#" . $seturl [1] );
						else
							redirect ( $seturl [0] . "?id=" . $flag_1 );
						// redirect(base_url()."treatment/gettreatment?id=".$flag_1);
					} else if ($flag_1 && ! empty ( $req )) {
						if (! empty ( $seturl [1] ))
							redirect ( $seturl [0] . "?id=" . $flag_1 . "&msg=update#" . $seturl [1] );
						else
							redirect ( $seturl [0] . "?id=" . $flag_1 . "&msg=update" );
						// redirect(base_url()."treatment/gettreatment?id=".$flag_1."&msg=update");
					} else {
						$return = array (
								'unsuccess_msg' => "Something Went Wrong" 
						);
						
						if (! empty ( $this->flag ))
							$this->flag = array_merge ( $flag, $return );
						else
							$this->flag = $return;
						
						$this->load->view ( 'treatment/add_larval_treatment', $this->flag );
					}
				}
			}
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to show edit Larva Treatment
	 */
	public function showedit_larval_treatment() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get ( 'id', TRUE );
			if (empty ( $req ))
				redirect ( base_url () . "treatment/gettreatment" );
			
			$this->showadd_larval_treatment ( $req );
		}
	}
	
	/**
	 * Function to show edit Adult Treatment
	 */
	public function showedit_adult_treatment() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get ( 'id', TRUE );
			if (empty ( $req ))
				redirect ( base_url () . "treatment/gettreatment" );
			
			$this->showadd_adult_treatment ( $req );
		}
	}
	
	/**
	 * Function to display Details of treatment that are
	 * filled up through Monitor Management
	 */
	// public function viewDetail($id = '')
	// {
	// if(!$this->session->userdata('logged_in'))
	// {
	// redirect(base_url());
	// }
	// else
	// {
	// $req = $this->input->get('id',TRUE);
	//
	// if(empty($req))
	// redirect(base_url()."treatment/gettreatment");
	//
	// $this->showadd_adult_treatment($req);
	// }
	// }
	
	/**
	 * Function to display List Of Treatments
	 */
	public function gettreatment($grid = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$id = $this->input->get ( 'id' );
			$id1 = $this->input->get ( 'msg' );
			$msg = "";
			
			if (! empty ( $id ) && empty ( $id1 )) {
				// $id = json_decode(base64_decode($id));
				if ($id > 0)
					$msg = "success";
			}
			if (isset ( $id1 ) && ! empty ( $id1 )) {
				if ($id1 == "update")
					$msg = "update";
				else if ($id1 == "delete")
					$msg = "delete";
			}
			$filter_date = $this->input->post ( 'filter_date' );
			$columns = array (
					0 => array (
							'name' => 'Water',
							'db_name' => 'iswaterofus',
							'header' => $this->lang->line('site_mgmt_is_wofus_qtn'),
							'group' => 'Treatment',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => 'string' 
					),
					1 => array (
							'name' => $this->lang->line('whthr_snsr_site_nm'),
							'db_name' => 'idsite',
							'header' => $this->lang->line('whthr_snsr_site_nm'),
							'group' => 'Treatment',
							'required' => TRUE,
							'unique' => TRUE,
							'form_control' => 'text_long',
							'ref_table_id_name' => 'idsite',
							'ref_table_db_name' => 'sites',
							'ref_field_db_name' => 'site',
							'form_control' => 'text_long',
							'type' => '1-n' 
					),
					2 => array (
							'name' => 'Zone',
							'db_name' => 'idsite',
							'header' => $this->lang->line('site_mgmt_zone'),
							'group' => 'Treatment',
							'form_control' => 'text_long',
							'required' => TRUE,
							'ref_table_id_name' => 'idsite',
							'ref_table_db_name' => 'sites',
							'ref_field_db_name' => 'idzone',
                            'ref_table_id2_name' => 'idzone',
							'ref_table_db2_name' => 'zones',
							'ref_field_db2_name' => 'zone',
							'form_control' => 'text_long',
							'type' => '1-1-1'
					),
					3 => array (
							'name' => $this->lang->line('prdct_ovrvw_type'),
							'db_name' => 'type',
							'header' => $this->lang->line('prdct_ovrvw_type'),
							'group' => 'Treatment',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => 'u' 
					),
					4 => array (
							'name' => $this->lang->line('lrvl_trtmnt_date'),
							'db_name' => 'date',
							'header' => $this->lang->line('lrvl_trtmnt_date'),
							'group' => 'Treatment',
							'form_control' => 'text_long',
							'required' => TRUE 
					),
					5 => array (
							'name' => $this->lang->line('trtmnts_applctr_name'),
							'db_name' => 'idapplicator',
							'header' => $this->lang->line('trtmnts_applctr_name'),
							'group' => 'Treatment',
							'ref_table_id_name' => 'iduser',
							'ref_table_db_name' => 'users',
							'ref_field_db_name' => 'firstname',
							'ref_field_2_db_name' => 'lastname',
							'ref_field_type' => 'string',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-1+2' 
					),
					6 => array (
							'db_name' => 'idsite',
							'header' => $this->lang->line('trap_mgmt_site_type'),
							'group' => 'Treatment',
							'form_control' => 'text_long',
							'required' => TRUE,
							'ref_table_id_name' => 'idsite',
							'ref_table_db_name' => 'sites',
							'ref_field_db_name' => 'idsitetype',
                            'ref_table_id2_name' => 'idsitetype',
							'ref_table_db2_name' => 'sitetypes',
							'ref_field_db2_name' => 'sitetype',
							'form_control' => 'text_long',
							'type' => '1-1-1'	
					),
					7 => array (
							'name' => $this->lang->line('adlt_trtmnt_system'),
							'db_name' => 'idsystemtype',
							'header' => $this->lang->line('adlt_trtmnt_system'),
							'group' => 'Treatment',
							'form_control' => 'text_long',
							'required' => TRUE,
							'ref_table_id_name' => 'idsystemtype',
							'ref_table_db_name' => 'systemtypes',
							'ref_field_db_name' => 'systemtype',
							'form_control' => 'text_long',
							'type' => '1-n' 
					)
					 
			);
			
			$commands ['delete'] ['toolbar'] = FALSE;
			
			$view = $this->load->view ( 'treatment/link_view', '', TRUE );
			// code for addtional request from service and larval
			$table1_rel = '';
			$table2_rel = '';
			
			$service_req_id = $this->input->get_post ( 'service_req_id' );
			$adult_key = $this->input->get_post ( 'adult_key' );
			if (! empty ( $service_req_id )) {
				$table1_rel = 'adulticidetreatmentsservice';
				$table2_rel = 'larvaltreatmentservice';
			} else if (! empty ( $adult_key )) {
				$table1_rel = 'adulticidetreatmentslarval';
				$table2_rel = 'larvaltreatmentlarval';
			}
			$params = array (
					'id' => 'idadulticidetreatment',
					'id1' => 'idadulticidetreatment',
					'id2' => 'idlarvaltreatment',
					'table' => 'adulticidetreatments',
					'table1' => 'adulticidetreatments',
					'table2' => 'larvaltreatments',
					'url' => 'treatment/gettreatment',
					'table1_rel' => $table1_rel,
					'table2_rel' => $table2_rel,
					'uri_param' => $grid,
					'multiple' => 1,
					'order' => array (
							4 => 'desc' 
					),
					'columns' => $columns,
					'filter_date' => ! empty ( $filter_date ) ? $filter_date : '2',
					'filters' => array (
							0 => array (
									'value' => $this->idlocation 
							) 
					),
					// 'columns_visible' => array(0,1,2,3,4,5,6),
					'commands' => $commands,
					'ajax' => TRUE,
					'msc_url' => array (
							'excel_url' => base_url () . 'treatment/toExcelAll',
							'pdf_url' => base_url () . 'treatment/toPdfAll',
							'text' => 'treatment' 
					) 
			);
			
			$newdata = array (
					'url' => base_url () . $params ['url'] . '#' . $params ['id'] . '=' . $grid 
			);
			
			$this->session->set_userdata ( $newdata );
			
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => 'Treatment',
					'page' => "treatment",
                    'app_lang' => $this->app_lang 
			);
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			
			// Pass grid to the view
            $data = (object)array();
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			$data->msg = $msg;
			$data->id = $id;
			$data->mapdata = base_url () . "treatment/showmap";
			$data->livemapdata = base_url () . "treatment/liveGpsMap";
			$data->add_view = $view;
			$this->load->view ( 'treatment/treatments', $data );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to display Map
	 */
	public function showmap() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data = $this->treatment_model->getMapdata ();
			$query ['data'] = ! empty ( $data ['result'] ) ? $data ['result'] : '';
			$query ['user_loc'] = $this->adultsurveillance_model->getUserLoc ();
			$query ['zone_loc'] = $this->zone_model->getZoneCord ();
			$query ['googlezoom'] = $this->session->userdata ( 'googlezoom' );
			$this->load->view ( 'treatment/map_view', $query );
		}
	}
	
	/**
	 * Function to display Live Gps Map
	 */
	public function liveGpsMap() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			if ($this->session->userdata ( 'live_gps' ) == '1') {
				$data ['key'] = $this->treatment_model->getEasiTrackAPIKey ();
				$this->load->view ( 'treatment/livegpsmap_view', $data );
			}
		}
	}
	
	/**
	 * Function to delete Larval Treatment
	 */
	public function deleteLarvalTreatment() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get ( 'id', TRUE );
			
			if (empty ( $req ))
				redirect ( base_url () . "treatment/gettreatment" );
			
			$flag_1 = $this->treatment_model->deleteLarvalTreatment ( $req );
			
			if ($flag_1)
				redirect ( base_url () . "treatment/gettreatment?id=" . $flag_1 . "&msg=delete" );
		}
	}
	
	/**
	 * Function to delete Adult Treatment
	 */
	public function deleteAdultTreatment() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get ( 'id', TRUE );
			
			if (empty ( $req ))
				redirect ( base_url () . "treatment/gettreatment" );
			
			$flag_1 = $this->treatment_model->deleteAdultTreatment ( $req );
			
			if ($flag_1)
				redirect ( base_url () . "treatment/gettreatment?id=" . $flag_1 . "&msg=delete" );
		}
	}
	
	/**
	 * Function to Show Selected Treatment Details
	 */
	public function viewDetail() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get ( 'id' );
			$type = $this->input->get ( 'type' );
			
			if (empty ( $req ))
				redirect ( base_url () . "treatment/gettreatment" );
			
			$flag_1 = "";
			
			if ($type == "larva")
				$flag_1 = $this->treatment_model->getLarvaTreatmentAllData ( $req );
			else if ($type == "adult")
				$flag_1 = $this->treatment_model->getAdultTreatmentAllData ( $req );
				
				// print'<pre>';
				// print_r($flag_1);
				// die;
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => 'Treatment',
					'page' => "treatment",
                    'app_lang' => $this->app_lang 
			);
			
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			
			if (! empty ( $flag_1 ))
				$this->load->view ( 'treatment/view_info', $flag_1 );
			else {
				$flag_1 = array (
						'value' => "null" 
				);
				$this->load->view ( 'treatment/view_info', $flag_1 );
			}
			
			$this->load->view ( 'footer' );
		}
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function toExcelAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$query ['data'] = $this->treatment_model->listTreatment ();
			
			$this->load->view ( 'treatment/excel_view', $query );
		}
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
		$this->load->helper ( 'pdf_helper' ); // Load helper
		
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$query ['data'] = $this->treatment_model->listTreatment ();
			
			$data = $this->load->view ( 'treatment/pdf_view', $query, true );
			// $data = file_get_contents(htmlentities($dd)); // Pass the url of html report
			// print'<pre>';
			// print_r($data);
			// die;
			
			create_pdf_l ( $data, $this->lang->line('sidebar_data_entry_trtmnts') ); // Create pdf
		}
	}
    
    /**
	 * Function to fetch all site data based on module
     * for Map Summary
	 */
	public function getAllEventsData($idsite = "") {
        $params = array (
            'idsite' => $idsite,
            'idlocation' => $this->session->userdata('idlocation')
        );
        
        $this->load->library ( 'common', $params );
        
        $response = $this->common->getAllEventsData ();
        //print'<pre>';
//        print_r($response);
//        die;
        return $response;
    }
    
    /**
	 * Function to initialize Larval data
	 */
	public function initializeLarvalFormData($flag = "") {
        if(empty($flag)){
            return;
        }
        /* Common Treatment Functions For Edit Fuunctionality Start */
		$this->date = ! empty ( $flag ['date'] ) ? $flag ['date'] : $this->date;
		$this->time = ! empty ( $flag ['time'] ) ? $flag ['time'] : $this->time;
		$this->sites = $this->site_model->getSelectedExistingSite ( $flag ['idsite'] );
		$this->site_type = $this->site_model->getSelected_sitetype ( $flag ['idsitetype'] );
		$this->states = $this->site_model->getSelectedSiteStates ( $flag ['idsite'] );
		$this->s_species = $this->treatment_model->getSelectedSpecies ( $flag ['idlarvaltreatment'] );
		$this->species = $this->treatment_model->getSpecies ( $this->idlocation );
		$this->applicator = $this->larvalsurveillance_model->getSelectedInspectors ( $flag ['idapplicator'] );
		$this->application_method = $this->treatment_model->getAppMethod ();
		$this->applicationrateuom = $this->treatment_model->getAppRate ();
		$this->application_rate_type = $this->treatment_model->getAppRateType ( $flag ['idapplicationratetype'] );
        $this->windspeed = $this->adultsurveillance_model->getSelectedWindspeed ( $flag ['idwindspeed'] );
        $this->winddirection = $this->treatment_model->getWindDirection ();
		$this->product_preferences = $this->product_model->getProductPref ( $flag ['idproduct'] );
		$this->product_2 = $this->treatment_model->getProducts ( $flag ['idproduct'], array (
				'2',
				'12' 
		) );
		$this->formulation = $this->treatment_model->getFormulation ();
		$this->mixratio = $this->treatment_model->getMixRatio ( $flag ['idmixratio'] );
		$this->finishedmix = $this->treatment_model->getFinishedMix ();
		$this->ttl_area_treated = $this->treatment_model->getTAreaTreated ();
		$this->ttl_prdct_applied = $this->treatment_model->getTProductApp ();
		/* Common Treatment Functions For Edit Fuunctionality End */
		
		/* Larvicide Treatment Function For Edit Fuunctionality Start */
		$this->site_status = $this->larvalsurveillance_model->getSelectedSitestatus ( $flag ['idsitestatus'] );
		$this->watertemp = $this->larvalsurveillance_model->getWatertemprange ( $flag ['idwatertemp'] );
		$this->instar = $this->larvalsurveillance_model->getInstar ( $flag ['idinstar'] );
		$this->larvacount = $this->treatment_model->getLarvaecount ( $flag ['idlarvaltreatment'] );
		$this->weatherconditions = $this->treatment_model->getWheatherCondtn ();
		/* Larvicide Treatment Function For Edit Fuunctionality End */
    }
    
    /**
	 * Function to initialize Adult data
	 */
	public function initializeAdultFormData($flag = "") {
        if(empty($flag)){
            return;
        }
        
        /* Common Treatment Functions For Edit Fuunctionality Start */
		$this->date = $flag ['date'];
		$this->sites = $this->site_model->getSelectedExistingSite ( $flag ['idsite'] );
		$this->site_type = $this->site_model->getSitetypes ();
		$this->states = $this->site_model->getStates ();
		$this->applicator = $this->larvalsurveillance_model->getSelectedInspectors ( $flag ['idapplicator'] );
		$this->application_method = $this->treatment_model->getAppMethod ( $flag ['idapplicationmethod'] );
		$this->applicationrateuom = $this->treatment_model->getAppRate ( $flag ['idapplicationrateuom'] );
		$this->application_rate_type = $this->treatment_model->getAppRateType ( $flag ['idapplicationratetype'] );
		$this->product_preferences = $this->product_model->getProductPref ( $flag ['idproduct'] );
		$this->product_1 = $this->treatment_model->getProducts ( $flag ['idproduct'], '1' );
		$this->formulation = $this->treatment_model->getFormulation ( $flag ['idformulation'] );
		$this->mixratio = $this->treatment_model->getMixRatio ( $flag ['idmixratio'] );
		$this->finishedmix = $this->treatment_model->getFinishedMix ( $flag ['iduomfinishedmix'] );
		$this->ttl_area_treated = $this->treatment_model->getTAreaTreated ( $flag ['iduomtotalareatreated'] );
		$this->ttl_prdct_applied = $this->treatment_model->getTProductApp ( $flag ['iduomtotalproductapplied'] );
		$site_data = $this->site_model->getSiteData ( $flag ['idsite'] );
		/* Common Treatment Functions For Edit Fuunctionality End */
		
		/* Adulticide Treatment Function For Edit Fuunctionality Start */
		$this->system = $this->treatment_model->getSystem ( $flag ['idsystemtype'] );
		$this->dilutent = $this->treatment_model->getDilutent ( $flag ['iddilutent'] );
		$this->tempatstart = $this->adultsurveillance_model->getSelectedTemprange ( $flag ['idtempatstart'] );
		$this->tempatend = $this->adultsurveillance_model->getSelectedTemprange ( $flag ['idtempatend'] );
		$this->windspeed = $this->adultsurveillance_model->getSelectedWindspeed ( $flag ['idwindspeed'] );
		$this->humidity = $this->adultsurveillance_model->getSelectedHumidityrange ( $flag ['idhumidityrange'] );
		$this->cloudcover = $this->adultsurveillance_model->getSelectedCloudcoverage ( $flag ['idcloudcover'] );
		$this->flowratetypes = $this->treatment_model->getFlowRateType ();
		$this->winddirection = $this->treatment_model->getWindDirection ( $flag ['idwinddirection'] );
		/* Adulticide Treatment Function For Edit Fuunctionality End */
    }
}

/* End of file treatment.php */
/* Location: ./application/con */