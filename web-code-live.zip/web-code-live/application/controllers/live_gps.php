<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Live_gps extends CI_Controller {
	
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		$this->load->helper('language');
		$this->load->model ( 'usermodel' );
		$this->load->model ( 'live_gps_model', 'lg' );
		$this->usermodel->set_access_session ();
		$idloc = $this->session->userdata ( 'live_gps' );
        
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		if (! $this->usermodel->user_access ( 'reports' ) && ! $this->usermodel->user_access ( 'company_admin' ) && empty ( $idloc ))
			redirect ( base_url () );
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			redirect ( base_url () . "live_gps/displayMap" );
		}
	}
	
	/**
	 * Function to display Live GPS Map
	 */
	public function displayMap() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$token = $this->lg->getUserToken ();
			if (! empty ( $token )) {
				$flag = $this->lg->authenticateUser ( $token );
				
				if ($flag) {
					echo "<script type='text/javascript'>
                            //window.open('http://gps.mygeopro.com/login.html?userGUID=$flag',".$this->lang->line('sidebar_fleet_livegps')." , 'fullscreen=1');
                            location.href = 'http://gps.mygeopro.com/login.html?userGUID=$flag';
                        </script>";
					
					// die;
				} else
					redirect ( base_url () . "user/dashboard" );
			} else
				redirect ( base_url () . "user/dashboard" );
		}
	}
}

/* End of file weather_sensor.php */
/* Location: ./application/controllers/weather_sensor.php */
