<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Site extends CI_Controller {
	public $site_type = "";
	public $zones = "";
	public $s_site_type = "";
	public $s_zones = "";
	public $states = "";
	public $s_states = "";
	public $state_list = "";
	public $statuses;
	public $idlocation = "";
	public $sitegroup = "";
    public $iduomwatersize;
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		
        $this->load->helper('language');
		$this->load->model ( 'site_model' );
		$this->load->model ( 'treatment_model' );
		$this->load->model ( 'adultsurveillance_model' );
		$this->site_type = $this->site_model->getSitetypes ();
		$this->zones = $this->site_model->getZones ();
		$this->states = $this->site_model->getStates ();
		$this->state_list = $this->site_model->getStatesList ();
		$this->statuses = $this->site_model->getStatuses ();
		$this->sitegroup = $this->site_model->getSiteGroup ();
		$this->iduomwatersize = $this->treatment_model->getTAreaTreated ();
        
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		if ($this->session->userdata ( 'logged_in' )) {
			$this->idlocation = $this->session->userdata ( 'idlocation' );
		}
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			redirect ( base_url () . "site/getsite" );
		}
	}
	
	/**
	 * Function to add a new site
	 */
	public function addsite() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->iduomwatersize = $this->treatment_model->getTAreaTreated ();
			$data = array (
					'site_type' => $this->site_type,
					'zones' => $this->zones,
					'states' => $this->states,
					'state_list' => $this->state_list,
					'sitegroup' => $this->sitegroup,
					'iduomwatersize' => $this->iduomwatersize,
                    'app_lang' => $this->app_lang
			);
			
			$this->form_validation->set_rules ( 'site_name', $this->lang->line('whthr_snsr_site_nm'), 'trim|required|callback_siteCheck|xss_clean' );
			$this->form_validation->set_rules ( 'site_type', $this->lang->line('trap_mgmt_site_type'), 'trim|required' );
			$this->form_validation->set_rules ( 'zone', 'Zone', 'trim|required' );
			$this->form_validation->set_rules ( 'maplabel', $this->lang->line('site_mgmt_map_lbl'), 'trim' );
			$this->form_validation->set_rules ( 'street1', $this->lang->line('site_mgmt_street') . ' I', 'trim' );
			$this->form_validation->set_rules ( 'street2', $this->lang->line('site_mgmt_street') . ' II', 'trim' );
			$this->form_validation->set_rules ( 'city', $this->lang->line('site_mgmt_cty'), 'trim' );
			$this->form_validation->set_rules ( 'state', $this->lang->line('site_mgmt_state'), 'trim' );
			$this->form_validation->set_rules ( 'postalcode', $this->lang->line('site_mgmt_postl_cde'), 'trim|integer' );
			$this->form_validation->set_rules ( 'latitude', $this->lang->line('site_mgmt_lat'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'longitude', $this->lang->line('site_mgmt_lng'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'manphone', $this->lang->line('site_mgmt_main_ph'), 'trim' );
			$this->form_validation->set_rules ( 'alternatephone', $this->lang->line('site_mgmt_alternt_ph'), 'trim' );
			$this->form_validation->set_rules ( 'faxnumber', $this->lang->line('cmn_lbl_fxnmbr'), 'trim' );
			$this->form_validation->set_rules ( 'active', 'Active', 'trim' );
			
			$this->form_validation->set_rules ( 'landingrate_site', $this->lang->line('site_mgmt_lndng_rate_site'), 'trim' );
			$this->form_validation->set_rules ( 'larval_site', $this->lang->line('site_mgmt_lrvl_srvlnc_site'), 'trim' );
			$this->form_validation->set_rules ( 'adult_site', $this->lang->line('site_mgmt_adlt_srvlnc_site'), 'trim' );
			$this->form_validation->set_rules ( 'apiary', $this->lang->line('site_mgmt_apiary'), 'trim' );
			$this->form_validation->set_rules ( 'contact_before_spray', $this->lang->line('site_mgmt_cntct_bfr_spryng'), 'trim' );
			$this->form_validation->set_rules ( 'organic_farm', $this->lang->line('site_mgmt_orgnc_frm'), 'trim' );
			$this->form_validation->set_rules ( 'nospray', $this->lang->line('site_mgmt_dnt_spry'), 'trim' );
			$this->form_validation->set_rules ( 'water_of_us', 'Is Water Of U.S?', 'trim' );
			$this->form_validation->set_rules ( 'watersize', $this->lang->line('site_mgmt_sz'), 'trim' );
			$this->form_validation->set_rules ( 'iduomwatersize', 'Id', 'trim' );
			$this->form_validation->set_rules ( 'endangered_species', $this->lang->line('site_mgmt_endngrd_spcs'), 'trim' );
			
			if ($this->form_validation->run () == FALSE) {
				$data ['msg'] = "error";
				$this->load->view ( 'sites/add_site', $data );
			} else {
				$flag = $this->site_model->addsite ();
				
				if (! empty ( $flag )) {
					$data ['msg'] = "success";
				} else {
					$data ['msg'] = "error";
				}
				
				$this->load->view ( 'sites/add_site', $data );
			}
		}
	}
	
	/*
	 *
	 *
	 * ADD form NEW
	 *
	 *
	 */
	public function addsiteview() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->site_type = $this->site_model->getSitetypes ();
			$this->zones = $this->site_model->getZones ();
			$this->states = $this->site_model->getStates ();
			$this->state_list = $this->site_model->getStatesList ();
			$this->statuses = $this->site_model->getStatuses ();
			$this->iduomwatersize = $this->treatment_model->getTAreaTreated ();
			$data = array (
					'site_type' => $this->site_type,
					'zones' => $this->zones,
					'states' => $this->states,
					'state_list' => $this->state_list,
					'sitegroup' => $this->sitegroup,
					'iduomwatersize' => $this->iduomwatersize,
					'googlezoom' => $this->session->userdata ( 'googlezoom' ),
					'user_loc' => $this->adultsurveillance_model->getUserLoc (),
                    'app_lang' => $this->app_lang,
                    'gplite' => $this->session->userdata('gplite')
			);
			$this->load->view ( 'sites/add_site', $data );
		}
	}

	public function showWards($grid = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$columns = array (
					0 => array (
							'name' => 'Ward', //$this->lang->line('whthr_snsr_site_nm'),
							'db_name' => 'site',
							'header' => 'Ward', //$this->lang->line('whthr_snsr_site_nm'),
							'group' => 'Ward', //$this->lang->line('whthr_snsr_site'),
							'unique' => TRUE,
							'form_control' => 'text_long',
							'type' => 'string' 
					),
					1 => array (
							'name' => 'ward_closed', //$this->lang->line('mmbr_mgmt_is_actv'),
							'header' => 'Status', //$this->lang->line('mmbr_mgmt_is_actv'),
							'group' => $this->lang->line('whthr_snsr_site'),
							'db_name' => 'idsite',
							'ref_table_id_name' => 'idsite',
							'ref_table_db_name' => 'wardsclosed',
							'ref_field_db_name' => 'idwardsclosed',							
							'ref_field_type' => 'string',
							'form_control' => 'text_long',
							'type' => '1-n' 
					) 
					 
			);
			
			$commands ['delete'] ['toolbar'] = FALSE;
				$params = array (
					'id' => 'idsite',
					'table' => 'sites',
					'table_id_1_name' => 'wardclosedId',
					'url' => 'site/showWards',
					'uri_param' => $grid,
					'columns' => $columns,
					'table1_rel' => 'wardsclosed',
					'order' => array (
							0 => 'asc' 
					),
					'filters' => array (
							0 => array (
									'value' => $this->idlocation 
							) 
					),
					'commands' => $commands,
					'ajax' => TRUE, 					 
					'sites' => $this->site_model->getwards () 
			);
			
			$newdata = array (
					'url' => base_url () . $params ['url'] . '#' . $params ['id'] . '=' . $grid 
			);
			
			$this->session->set_userdata ( $newdata );
			
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
		 
			 
			// Pass grid to the view
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			$data->wards = $this->site_model->getclosedwards ();
			
			
			$this->load->view ( 'sites/ward_management', $data );
		}
	}
 
	/**
	 * Function to activate ward
	 */
	public function activateWard() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->site_model->activateWard ();
			
			$msg = "";
			
			if ($flag)
				$msg = "activated";
			else
				$msg = "error";
			
		 	$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
			if (! empty ( $seturl [1] ))
				redirect ( $seturl [0] . "?del=" . $msg . "#" . $seturl [1] );
			else
				redirect ( $seturl [0] . "?del=" . $msg );
		}
	}

	/**
	 * Function to close ward
	 */
	public function showecloseward() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get_post ( 'id', TRUE );
			
			$result = $this->site_model->getward ($req);

			$data = array (
				'ward' => $result
			);
			$this->load->view ( 'sites/showecloseward', $data );
		}
	}

	/**
	 * Function to closed ward using Ajax
	 * Returns ID of newly added site
	 */
	public function addclosedwardAjax() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->site_model->addclosedwardAjax();
		}
	}

	
	/**
	 * Function to add a new site using Ajax
	 * Returns ID of newly added site
	 */
	public function addSiteUsingAjax() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->form_validation->set_rules ( 'site_name', $this->lang->line('whthr_snsr_site_nm'), 'trim|required|callback_siteCheckAjax' );
			$this->form_validation->set_rules ( 'site_type', $this->lang->line('trap_mgmt_site_type'), 'trim|required' );
			$this->form_validation->set_rules ( 'zone', 'Zone', 'trim|required' );
			$this->form_validation->set_rules ( 'maplabel', $this->lang->line('site_mgmt_map_lbl'), 'trim' );
			$this->form_validation->set_rules ( 'street1', $this->lang->line('site_mgmt_street'), 'trim' );
			$this->form_validation->set_rules ( 'city', $this->lang->line('site_mgmt_cty'), 'trim' );
			$this->form_validation->set_rules ( 'state', $this->lang->line('site_mgmt_state'), 'trim' );
			$this->form_validation->set_rules ( 'postalcode', $this->lang->line('site_mgmt_postl_cde'), 'trim' );
			$this->form_validation->set_rules ( 'latitude', $this->lang->line('site_mgmt_lat'), 'trim' );
			$this->form_validation->set_rules ( 'longitude', $this->lang->line('site_mgmt_lng'), 'trim' );
			$this->form_validation->set_rules ( 'pdop', 'PDOP', 'trim' );
			$this->form_validation->set_rules ( 'manphone', $this->lang->line('site_mgmt_main_ph'), 'trim' );
			$this->form_validation->set_rules ( 'alternatephone', $this->lang->line('site_mgmt_alternt_ph'), 'trim' );
			$this->form_validation->set_rules ( 'faxnumber', $this->lang->line('cmn_lbl_fxnmbr'), 'trim' );
			$this->form_validation->set_rules ( 'active', 'Active', 'trim' );
			
			if ($this->form_validation->run () == FALSE) {
				echo "error";
				die ();
			} else {
				$insert_id = $this->site_model->addSiteUsingAjax ();
				
				if ($insert_id)
					$msg = $insert_id;
				else
					$msg = "error";
				
				echo $msg;
				die ();
			}
		}
	}
	
	/**
	 * Function to show edit site
	 */
	public function showeditsite() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {

			$req = $this->input->get_post ( 'id', TRUE );
			
			$data = array (
					'site_type' => $this->site_type,
					'zones' => $this->zones,
					'states' => $this->states,
					'state_list' => $this->state_list,
					'sitegroup' => $this->sitegroup,
                    'app_lang' => $this->app_lang 
			);
			
			if (empty ( $req )) {
				$data ['msg'] = "error";
				$this->load->view ( 'sites/edit_site', $data );
			}
			
			$flag = $this->site_model->getSiteData ( $req );
			
			$this->s_zones = $this->site_model->getSelectedZones ( $flag ['idzone'] );
			$this->sitegroup = $this->site_model->getSiteGroup ();
			
			if ($flag) {
				$flag ['zones'] = $this->s_zones;
				$flag ['site_type'] = $this->site_type;
				$flag ['states'] = $this->states;
				$flag ['sitegroup'] = $this->sitegroup;
				$flag [idareatreated] = $flag ['iduomwatersize'];
				$flag ['iduomwatersize'] = $this->iduomwatersize;
				$flag ['googlezoom'] = $this->session->userdata ( 'googlezoom' );
				$flag ['user_loc'] = $this->adultsurveillance_model->getUserLoc ();
				$flag ['gplite'] = $this->session->userdata('gplite');
				$flag['error'] = 0;
			}
			
			$this->load->view ( 'sites/edit_site', $flag );
		}
	}
	/**
	 * Function to show map
	 */
	public function showmap() {
		$this->load->view ( 'sites/map' );
	}
	
	/**
	 * Function to check whether the Site
	 * is WATER OF THE US
	 */
	public function chkWaterOfUs() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$idsite = $this->input->post ( 'idsite' );
			
			if (empty ( $idsite )) {
				echo "error";
				exit ();
			}
			
			$flag = $this->site_model->isWaterOfUs ( $idsite );
			
			if ($flag)
				echo "true";
			else
				echo "error";
			
			exit ();
		}
	}
	
	/**
	 * Function to get Lati Longi
	 */
	public function getLatiLongi() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data = array (
					'states' => $this->states 
			);
			
			$this->load->view ( 'sites/lati_longi', $data );
		}
	}
	
	/**
	 * Function to check site name existence
	 */
	public function siteCheck($str = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$str = $this->input->post ( 'site_name' );
			
			$flag = $this->site_model->siteExist ( $str );
			
			if ($flag) {
				$this->form_validation->set_message ( 'siteCheck', $this->lang->line('err_msg_site_alrdy_exsts') );
				return false;
			} else {
				return true;
			}
		}
	}
	
	/**
	 * Function to check site name existence
	 * This function is called during Ajax process
	 */
	public function siteCheckAjax($str = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$str = $this->input->post ( 'site_name' );
			
			$flag = $this->site_model->siteExist ( $str );
			
			if ($flag) {
				$this->form_validation->set_message ( 'siteCheck', $this->lang->line('err_msg_site_alrdy_exsts') );
				echo $this->lang->line('err_msg_site_alrdy_exsts');
				die ();
			}
		}
	}
	
	/**
	 * Function to get lati longi of map
	 */
	public function getmap() {
		$street = $this->input->post ( 'street_addr' );
		$street1 = $this->input->post ( 'street_addr1' );
		$city = $this->input->post ( 'city' );
		$state = $this->input->post ( 'state' );
		$postal_code = $this->input->post ( 'postal_code' );
		
		getMapData ( $street, $street1, $city, $state, $postal_code );
	}
	/**
	 * Function to save edit site Values
	 */
	public function updatesite() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get_post ( 'idsite' );
			
			$flag = $this->site_model->getSiteData ( $req );
			
			$this->s_site_type = $this->site_model->getSelectedsitetype ( $flag ['idsitetype'] );
			$this->s_zones = $this->site_model->getSelectedZones ( $flag ['idzone'] );
			$this->s_states = $this->site_model->getSelectedStates ( $flag ['idstate'] );
			$this->iduomwatersize = $this->treatment_model->getTAreaTreated ( $flag ['iduomwatersize'] );
			if ($flag) {
				$flag ['zones'] = $this->s_zones;
				$flag ['site_type'] = $this->s_site_type;
				$flag ['states'] = $this->s_states;
				$flag ['iduomwatersize'] = $this->iduomwatersize;
			}
			
			$flag ['state_list'] = $this->state_list;
            $flag ['app_lang'] = $this->app_lang;
			
			$this->form_validation->set_rules ( 'site_name', $this->lang->line('whthr_snsr_site_nm'), 'trim|required' );
			$this->form_validation->set_rules ( 'site_type', $this->lang->line('trap_mgmt_site_type'), 'trim|required' );
			$this->form_validation->set_rules ( 'zone', 'Zone', 'trim|required' );
			$this->form_validation->set_rules ( 'maplabel', $this->lang->line('site_mgmt_map_lbl'), 'trim' );
			$this->form_validation->set_rules ( 'street1', $this->lang->line('site_mgmt_street') . ' I', 'trim' );
			$this->form_validation->set_rules ( 'street2', $this->lang->line('site_mgmt_street') . ' II', 'trim' );
			$this->form_validation->set_rules ( 'city', $this->lang->line('site_mgmt_cty'), 'trim' );
			$this->form_validation->set_rules ( 'state', $this->lang->line('site_mgmt_state'), 'trim' );
			$this->form_validation->set_rules ( 'postalcode', $this->lang->line('site_mgmt_postl_cde'), 'trim|integer' );
			$this->form_validation->set_rules ( 'latitude', $this->lang->line('site_mgmt_lat'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'longitude', $this->lang->line('site_mgmt_lng'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'manphone', $this->lang->line('site_mgmt_main_ph'), 'trim' );
			$this->form_validation->set_rules ( 'alternatephone', $this->lang->line('site_mgmt_alternt_ph'), 'trim' );
			$this->form_validation->set_rules ( 'faxnumber', $this->lang->line('cmn_lbl_fxnmbr'), 'trim' );
			$this->form_validation->set_rules ( 'active', 'Active', 'trim' );
			
			$this->form_validation->set_rules ( 'landingrate_site', $this->lang->line('site_mgmt_lndng_rate_site'), 'trim' );
			$this->form_validation->set_rules ( 'larval_site', $this->lang->line('site_mgmt_lrvl_srvlnc_site'), 'trim' );
			$this->form_validation->set_rules ( 'adult_site', $this->lang->line('site_mgmt_adlt_srvlnc_site'), 'trim' );
			$this->form_validation->set_rules ( 'apiary', $this->lang->line('site_mgmt_apiary'), 'trim' );
			$this->form_validation->set_rules ( 'contact_before_spray', $this->lang->line('site_mgmt_cntct_bfr_spryng'), 'trim' );
			$this->form_validation->set_rules ( 'organic_farm', $this->lang->line('site_mgmt_orgnc_frm'), 'trim' );
			$this->form_validation->set_rules ( 'nospray', $this->lang->line('site_mgmt_dnt_spry'), 'trim' );
			$this->form_validation->set_rules ( 'water_of_us', 'Is Water Of U.S?', 'trim' );
			$this->form_validation->set_rules ( 'watersize', $this->lang->line('site_mgmt_sz'), 'trim' );
			$this->form_validation->set_rules ( 'iduomwatersize', 'Id', 'trim' );
			$this->form_validation->set_rules ( 'endangered_species', $this->lang->line('site_mgmt_endngrd_spcs'), 'trim' );
			
			$str = $this->input->post ( 'site_name' );
			$siteId = $this->input->post('idsite');
			$siteExist = $this->site_model->checkSiteExist ( $str, $siteId );
			log_message('debug','Skysoft Debugging -------------->>>>>>>>>>>>>>>>>>>>>>>>>>>>>> site id is .................. ' .$siteId);
			log_message('debug','Skysoft Debugging -------------->>>>>>>>>>>>>>>>>>>>>>>>>>>>>> site Exist test .................. ' .$siteExist );
			if($siteExist) {
				$flag1 ['msg'] = "Site already exists";
				$flag1['error'] = 1;
				$this->load->view ( 'sites/edit_site', $flag1 );
				return;
			}			
			if ($this->form_validation->run () == FALSE) {
				$flag ['msg'] = "error";
				$flag1['error'] = 0;
				$this->load->view ( 'sites/edit_site', $flag );
			} else {
				$flag = $this->site_model->updateSite ();
				$flag1 = array ();
				if (! empty ( $flag )) {
					$flag1['error'] = 0;
					$flag1 ['msg'] = "update";
				} else {
					$flag1['error'] = 01;
					$flag1 ['msg'] = "error";
				}
				
				// print'<pre>';
				// print_r($data);
				// die;
				// $s = $this->session->userdata('url');
				// print'<pre>';
				// print_r($s);
				// die;
				$this->load->view ( 'sites/edit_site', $flag1 );
			}
		}
	}
	
	/**
	 * Function to delete site
	 */
	public function deletesite() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$flag = $this->site_model->deletesite ();
			
			$msg = "";
			
			if ($flag)
				$msg = "success";
			else
				$msg = "error";
			
			$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
			if (! empty ( $seturl [1] ))
				redirect ( $seturl [0] . "?del=" . $msg . "#" . $seturl [1] );
			else
				redirect ( $seturl [0] . "?del=" . $msg );
			
			// redirect(base_url().'site/getsite?del='.$msg);
		}
	}
	
	/**
	 * Function to activate site
	 */
	public function activesite() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->site_model->activesite ();
			
			$msg = "";
			
			if ($flag)
				$msg = "activated";
			else
				$msg = "error";
			
			redirect ( base_url () . "site/getsite?msg=" . $msg );
		}
	}
	
	/**
	 * Function to deactivate site
	 */
	public function deactivesite() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->site_model->deactivesite ();
			
			$msg = "";
			
			if ($flag)
				$msg = "deactivated";
			else
				$msg = "error";
			
			redirect ( base_url () . "site/getsite?msg=" . $msg );
		}
	}
	
	/**
	 * Function to display List Of sites
	 */
	public function getsite($grid = '', $msg = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$columns = array (
					0 => array (
							'name' => $this->lang->line('whthr_snsr_site_nm'),
							'db_name' => 'site',
							'header' => $this->lang->line('whthr_snsr_site_nm'),
							'group' => $this->lang->line('whthr_snsr_site'),
							'required' => TRUE,
							'unique' => TRUE,
							'form_control' => 'text_long',
							'type' => 'string' 
					),
					1 => array (
							'name' => $this->lang->line('trap_mgmt_site_type'),
							'db_name' => 'idsitetype',
							'header' => $this->lang->line('trap_mgmt_site_type'),
							'group' => $this->lang->line('whthr_snsr_site'),
							'required' => TRUE,
							'ref_table_id_name' => 'idsitetype',
							'ref_table_db_name' => 'sitetypes',
							'ref_field_db_name' => 'sitetype',
							'form_control' => 'text_long',
							'type' => '1-n' 
					),
					2 => array (
							'name' => $this->lang->line('site_mgmt_addrs_1'),
							'db_name' => 'address1',
							'header' => $this->lang->line('site_mgmt_addrs_1'),
							'group' => $this->lang->line('whthr_snsr_site'),
							'form_control' => 'text_long' 
					)
					// 'type' => '1-n'
					,
					3 => array (
							'name' => $this->lang->line('site_mgmt_zone'),
							'db_name' => 'idzone',
							'header' => $this->lang->line('site_mgmt_zone'),
							'group' => 'Zone',
							'allow_filter' => TRUE,
							'required' => TRUE,
							'ref_table_id_name' => 'idzone',
							'ref_table_db_name' => 'zones',
							'ref_field_db_name' => 'zone',
							'form_control' => 'dropdown',
							'type' => '1-n' 
					),
					4 => array (
							'name' => $this->lang->line('site_mgmt_cty'),
							'db_name' => 'city',
							'header' => $this->lang->line('site_mgmt_cty'),
							'group' => $this->lang->line('whthr_snsr_site'),
							'form_control' => 'text_long' 
					)
					// 'type' => '1-n'
					,
					5 => array (
							'name' => $this->lang->line('site_mgmt_state'),
							'db_name' => 'idstate',
							'header' => $this->lang->line('site_mgmt_state'),
							'group' => $this->lang->line('site_mgmt_state'),
							'ref_table_id_name' => 'idstate',
							'ref_table_db_name' => 'states',
							'ref_field_db_name' => 'statename',
							'form_control' => 'dropdown',
							'type' => '1-n' 
					),
					6 => array (
							'name' => $this->lang->line('site_mgmt_postal_code'),
							'db_name' => 'postalcode',
							'header' => $this->lang->line('site_mgmt_postal_code'),
							'group' => $this->lang->line('whthr_snsr_site'),
							'form_control' => 'text_long' 
					)
					// 'type' => '1-n'
					,
					7 => array (
							'name' => $this->lang->line('mmbr_mgmt_is_actv'),
							'db_name' => 'active',
							'header' => $this->lang->line('mmbr_mgmt_is_actv'),
							'group' => $this->lang->line('whthr_snsr_site'),
							'form_control' => 'checkbox' 
					)
					// 'type' => '1-n'
					 
			);
			
			$commands ['delete'] ['toolbar'] = FALSE;
			
			$data_1 = array (
					'zones' => $this->zones,
					'site_type' => $this->site_type,
					'states' => $this->states,
					'state_list' => $this->state_list,
                    'app_lang' => $this->app_lang 
			);
			
			$add_view = $this->load->view ( 'sites/add_site', $data_1, TRUE );
			
			$edit_view = $this->load->view ( 'sites/edit_site', '', TRUE );
			
			$params = array (
					'id' => 'idsite',
					'table' => 'sites',
					'url' => 'site/getsite',
					'uri_param' => $grid,
					'columns' => $columns,
					'order' => array (
							0 => 'asc' 
					),
					// 'columns_visible' => array(0,1,2),
					'filters' => array (
							0 => array (
									'value' => $this->idlocation 
							) 
					),
					'commands' => $commands,
					'ajax' => TRUE,
					'msc_url' => array (
							'excel_url' => base_url () . 'site/toExcelAll',
							'pdf_url' => base_url () . 'site/toPdfAll',
							'text' => $this->lang->line('whthr_snsr_site') 
					),
					'add_view' => $add_view,
					'edit_view' => $edit_view,
					'sites' => $this->site_model->getAllSite () 
			);
			
			$newdata = array ();
			if (! empty ( $grid ))
				$newdata = array (
						'url' => base_url () . $params ['url'] . '#' . $params ['id'] . '=' . urlencode ( $grid ) 
				);
			else
				$newdata = array (
						'url' => base_url () . $params ['url'] 
				);
			
			$this->session->set_userdata ( $newdata );
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_mntnc_site_mgmt'),
                    'app_lang' => $this->app_lang,
                    'page' => "site_management"
			);
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			// Pass grid to the view
            $data = (object)array();
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			$data->msg = $msg;
			$data->idlocation = $this->idlocation;
			$data->statuses = $this->statuses;
			
			
			$this->load->view ( 'sites/sites', $data );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to fetch the site
	 * entered during autosuggest
	 */
	public function getSelectedSiteList() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$result = array ();
			$char = $this->input->get ( 'chars' );
			
			if (empty ( $char )) {
				echo json_encode ( $result );
				exit ();
			} else {
				$result = $this->site_model->getSelectedSiteList ( $char );
				
				if (empty ( $data )) {
					echo json_encode ( $result );
					exit ();
				} else {
					echo json_encode ( $result );
					exit ();
				}
			}
		}
	}
	
	/**
	 * Function to fetch the site type
	 * entered during autosuggest
	 */
	public function getSelectedSiteTypeList() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$result = array ();
			$char = $this->input->get ( 'chars' );
			
			if (empty ( $char )) {
				echo json_encode ( $result );
				exit ();
			} else {
				$result = $this->site_model->getSelectedSiteTypeList ( $char );
				
				if (empty ( $data )) {
					echo json_encode ( $result );
					exit ();
				} else {
					echo json_encode ( $result );
					exit ();
				}
			}
		}
	}
	
	/**
	 * Function to fetch the site group
	 * entered during autosuggest
	 */
	public function getSelectedSiteGroupList() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$result = array ();
			$char = $this->input->get ( 'chars' );
			
			if (empty ( $char )) {
				echo json_encode ( $result );
				exit ();
			} else {
				$result = $this->site_model->getSelectedSiteGroupList ( $char );
				
				if (empty ( $data )) {
					echo json_encode ( $result );
					exit ();
				} else {
					echo json_encode ( $result );
					exit ();
				}
			}
		}
	}
	public function sites_json($idlocation = false) {
		$sites_array = $this->site_model->listSites ( $idlocation );
		
		$s_arr = array ();
		
		if (! $sites_array)
			$sites_array = array ();
		
		foreach ( $sites_array as $site ) {
			$s_arr [] = array (
					'post' => $site 
			);
		}
		
		$sites = array (
				'posts' => $s_arr,
				'total_records' => count ( $s_arr ) 
		);
		
		echo json_encode ( $sites );
	}
	public function create_site_json() {
		echo __FUNCTION__ . ' not yet implemented';
	}
	public function update_site_json() {
		echo __FUNCTION__ . ' not yet implemented';
	}
	public function delete_site_json() {
		echo __FUNCTION__ . ' not yet implemented';
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function getsitedata() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$id = $this->input->post ( 'idsite' );
			
			if (empty ( $id )) {
				echo "error";
				exit ();
			}
			
			$data = $this->site_model->getSiteData ( $id );
			
			echo json_encode ( $data );
		}
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function toExcelAll() {
		$query ['data'] = $this->site_model->listSites ();
		
		$this->load->view ( 'sites/excel_view', $query );
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
		$this->load->helper ( 'pdf_helper' ); // Load helper
		$query ['data'] = $this->site_model->listSites ();
		
		$data = $this->load->view ( 'sites/pdf_view', $query, true );
		// $data = file_get_contents(htmlentities($dd)); // Pass the url of html report
		
		create_pdf_l ( $data, $this->lang->line('adlt_srvlnc_sites') ); // Create pdf
	}
}

/* End of file site.php */
/* Location: ./application/controllers/site.php */
