<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Preference extends CI_Controller {
	public $universe;
	public $locationvectorspecies;
	public $locationmosquitospecies;
	public $data;
	public $idlocation;
    public $app_lang;
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 *
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
        $this->load->helper('language');
		$this->load->model ( 'preference_model' );

		if ($this->session->userdata ( 'logged_in' )) {
			$this->idlocation = $this->session->userdata ( 'idlocation' );

			$this->universe = $this->preference_model->getUniverse ( $this->idlocation );
			$this->locationvectorspecies = $this->preference_model->getLocationVectorSpecies ( $this->idlocation );
			$this->locationmosquitospecies = $this->preference_model->getLocationMosquitoSpecies ( $this->idlocation );
			$this->seasondates =  $this->preference_model->getSeasonDates ( $this->idlocation );

			$this->data = $this->preference_model->getPreferencesData ();

			// print'<pre>';
			// print_r($this->seasondates);
			// die;
		}

        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
	}

	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			redirect ( base_url () . "preference/preferences" );
		}
	}

	/**
	 * Function to fetch the preferences
	 */
	public function preferences() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_mntnc_prfrncs'),
					'page' => 'preferences',
                    'app_lang' => $this->app_lang
			)
			;
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );

			$data_1 = array ();
			$this->load->model('usermodel');
			$data_1 = array (
					'company_admin' => $this->usermodel->user_access('company_admin'),
					'universe' => $this->universe,
					'locationvectorspecies' => $this->locationvectorspecies,
					'locationmosquitospecies' => $this->locationmosquitospecies ,
					'seasondates' => $this->seasondates,
					'user_lock' => $this->usermodel->getUserLockControl($this->session->userdata ( 'idlocation' )),
					'wa_filtering' => $this->preference_model->getWAFiltering($this->session->userdata ( 'idlocation' )),
					'prefilled_user_dropdowns' => $this->preference_model->getPrefilled_user_dropdowns($this->session->userdata ( 'idlocation' ))
			);

			if (! empty ( $this->data )) {
				$this->data = array_merge ( $this->data, $data_1 );
			} else
				$this->data = $data_1;

			$this->load->view ( 'preference/preferences', $this->data );
		}

		$this->load->view ( 'footer' );
	}

	/**
	 * Function to save the preferences
	 */
	public function save_preferences() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			// print'<pre>';
			// print_r($_POST);
			// die;
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_mntnc_prfrncs'),
					'page' => 'preferences',
                    'app_lang' => $this->app_lang
			)
			;
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );

			$rainfallactive = $this->input->post ( 'rainfallactive' );
			$trapcountmosquitoactive = $this->input->post ( 'trapcountmosquitoactive' );
			$trapcountvectoractive = $this->input->post ( 'trapcountvectoractive' );
			$callsactive = $this->input->post ( 'callsactive' );
			$landingrateexceedsactive = $this->input->post ( 'landingrateexceedsactive' );

			$locationmosquitospecies = $this->input->post ( 'locationmosquitospecies' );
			$locationvectrorspecies = $this->input->post ( 'locationvectrorspecies' );
			$seasondates = $this->input->post ( 'season_date' );

			$state = 0;

			if (! empty ( $rainfallactive ) && $rainfallactive == "on") {
				$this->form_validation->set_rules ( 'rainfallexceeds', $this->lang->line('map_smmry_rnfll_amnt_in_24hrs'), 'trim|required|min_length[1]|max_length[3]' );
				$state = 1;
			}

			if (! empty ( $trapcountmosquitoactive ) && $trapcountmosquitoactive == "on") {
				$this->form_validation->set_rules ( 'trapcountmosquito', $this->lang->line('prfrncs_trap_cnt_msqto'), 'trim|required|min_length[1]|max_length[5]' );
				$state = 1;
			}

			if (! empty ( $trapcountvectoractive ) && $trapcountvectoractive == "on") {
				$this->form_validation->set_rules ( 'trapcountvector', $this->lang->line('prfrncs_trap_cnt_vctr'), 'trim|required|min_length[1]|max_length[5]' );
				$state = 1;
			}

			if (! empty ( $callsactive ) && $callsactive == "1") {
				$this->form_validation->set_rules ( 'callsexceed', 'Calls Exceed', 'trim|required|min_length[1]|max_length[3]' );
				$state = 1;
			}

			if (! empty ( $landingrateexceedsactive ) && $landingrateexceedsactive == "on") {
				$this->form_validation->set_rules ( 'landingrateexceeds', $this->lang->line('prfrncs_lndng_rte_excds'), 'trim|required|min_length[1]|max_length[3]' );
				$state = 1;
			}

			if (! empty ( $locationmosquitospecies ) || ! empty ( $locationvectrorspecies )) {
				$this->form_validation->set_rules ( 'locationvectorspecies', $this->lang->line('prfrncs_loc_vctr_spcs'), '' );
				$this->form_validation->set_rules ( 'locationmosquitospecies', $this->lang->line('prfrncs_loc_msqt_spcs'), '' );
				$state = 1;
			}

			if ($state == 1) {
				if ($this->form_validation->run () == FALSE) {

					$data_1 = array ();

					$data_1 = array (
							'universe' => $this->universe,
							'locationvectorspecies' => $this->locationvectorspecies,
							'locationmosquitospecies' => $this->locationmosquitospecies
					);

					if (! empty ( $this->data )) {
						$this->data = array_merge ( $this->data, $data_1 );
					} else
						$this->data = $data_1;

					$this->load->view ( 'preference/preferences', $this->data );
				} else {



					$flag = $this->preference_model->savePreference ( $this->idlocation );

					if (! empty ( $flag )) {
						redirect ( base_url () . "preference/preferences?msg=success" );
					} else {
						$data_1 = array ();

						$data_1 = array (
								'universe' => $this->universe,
								'locationvectorspecies' => $this->locationvectorspecies,
								'locationmosquitospecies' => $this->locationmosquitospecies,
								'msg' => "error"
						)
						;

						if (! empty ( $this->data )) {
							$this->data = array_merge ( $this->data, $data_1 );
						} else
							$this->data = $data_1;

						$this->load->view ( 'preference/preferences', $this->data );
					}
				}
			} else {
				$data = array (
						'universe' => $this->universe,
						'locationvectorspecies' => $this->locationvectorspecies,
						'locationmosquitospecies' => $this->locationmosquitospecies
				)
				;

				$this->load->view ( 'preference/preferences', $data );
			}
			$this->load->view ( 'footer' );
		}
	}

	/**
	 * Function to Move All
	 * the selected species based on direction
	 */
	public function moveall() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag_1 = "";

			$flag = $this->input->post ( 'flag' );

			$locationmosquitospecies = $this->input->post ( 'locationmosquitospecies' );

			$locationvectorspecies = $this->input->post ( 'locationvectorspecies' );

			if (isset ( $flag ) && ! empty ( $flag ) && $flag == "1")
				$flag_1 = $this->preference_model->movePreference ( 'mosquito_1', $this->idlocation );
			else if (isset ( $flag ) && ! empty ( $flag ) && $flag == "2")
				$flag_1 = $this->preference_model->movePreference ( 'vector_1', $this->idlocation );
			else {
				if (isset ( $locationmosquitospecies ) && ! empty ( $locationmosquitospecies )) {
					$flag_1 = $this->preference_model->movePreference ( 'mosquito', $this->idlocation );
				} else if (isset ( $locationvectorspecies ) && ! empty ( $locationvectorspecies ))
					$flag_1 = $this->preference_model->movePreference ( 'vector', $this->idlocation );
			}

			if (! empty ( $flag_1 ))
				echo $flag_1;
			else
				echo "error";
		}
	}

	public function addSeasonDate() {
		if (!$this->session->userdata('logged_in'))
			redirect (base_url());
		else if($this->session->userdata('idlocation') != '57')
			redirect(base_url());

		$year = $this->input->post('season_year');
		$month = $this->input->post('season_month');
		$day = $this->input->post('season_day');

		$resp = array('error' => 1, 'message' => '');

		if(empty($year) || empty($month) || empty($day)) {
			$resp['message'] = 'missing parameters.';
			echo json_encode($resp);
			return;
		}		

		$result = $this->preference_model->addSeasonDate($year, $month, $day);
		if($result == 0) $resp['error'] = 0;
		else if($result == 1) $resp['message'] = 'season date for given year exists already.';
		else $resp['message'] = 'error adding season date';

		echo json_encode($resp);
		return;
	}
	
	public function removeSeasonDate() {
		if (!$this->session->userdata('logged_in'))
			redirect (base_url());
		else if($this->session->userdata('idlocation') != '57')
			redirect(base_url());
			
		$year = $this->input->post('year');
		
		$resp = array('error' => 1, 'message' => '');
		
		if(empty($year)) {
			$resp['message'] = 'missing parameters.';
			echo json_encode($resp);
			return;
		}
		
		$result = $this->preference_model->removeSeasonDate($year);
		if($result == 0) $resp['error'] = 0;
		else $resp['message'] = 'error removing season date';

		echo json_encode($resp);
		return;
	}
}

/* End of file preferences.php */
/* Location: ./application/controllers/preferences.php */