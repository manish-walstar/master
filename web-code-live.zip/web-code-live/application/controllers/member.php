<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Member extends CI_Controller {
	public $salutations = "";
	public $suffixes = "";
	public $statuses;
	public $idlocation = "";
	public $susergroup;
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		
        $this->load->helper('language');
        
		$this->load->model ( 'membermodel' );
		$this->load->model ( 'usermodel' );
		
		$this->salutations = $this->membermodel->getSalutations ();
		$this->suffixes = $this->membermodel->getSuffixes ();
		$this->statuses = $this->membermodel->getStatuses ();
		$this->usergroup = $this->membermodel->getUserGroups ();
		
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		if ($this->session->userdata ( 'logged_in' )) {
			$this->idlocation = $this->session->userdata ( 'idlocation' );
		}
		
		$this->usermodel->set_access_session ();
		
		if ($this->usermodel->user_access ( 'company_admin' )) {
		} else {
			redirect ( base_url () );
		}
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			redirect ( base_url () . "member/getmember" );
		}
	}
	
	/**
	 * Function to Show Add Member Form
	 */
	public function showaddmember() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
                    'page' => "members",
					'title' => $this->lang->line('sidebar_mntnc_mmbr_mgmt'),
                    'app_lang' => $this->app_lang,
                    'gplite' => $this->session->userdata('gplite'),
			        'gplites' => $this->session->userdata('gplites'),
                    'salutations' => $this->salutations,
					'suffixes' => $this->suffixes,
					'usergroup' => $this->usergroup,
                    'app_lang' => $this->app_lang
			);
			$this->load->view ( 'header', $data );
			$this->load->view ( 'left_sidebar', $data );
			$this->load->view ( 'member/add_member', $data );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to add a new Member
	 */
	public function addmember() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
                    'page' => "members",
					'title' => $this->lang->line('sidebar_mntnc_mmbr_mgmt'),
                    'app_lang' => $this->app_lang,
                    'gplite' => $this->session->userdata('gplite'),
			        'gplites' => $this->session->userdata('gplites')
			)
			;
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			
			$this->form_validation->set_rules ( 'username', $this->lang->line('cmn_lbl_usrnme'), 'trim|required|callback_username_check|xss_clean' );
			$this->form_validation->set_rules ( 'email', 'Email', 'trim|required|valid_email|is_unique[users.email]' );
			$this->form_validation->set_rules ( 'firstname', $this->lang->line('cmn_lbl_frst_name'), 'required' );
			$this->form_validation->set_rules ( 'middlename', $this->lang->line('cmn_lbl_mddlnme'), 'trim|alpha_numeric' );
			$this->form_validation->set_rules ( 'lastname', $this->lang->line('cmn_lbl_lstnme'), 'required' );
			$this->form_validation->set_rules ( 'confirmpassword', $this->lang->line('mmbr_mgmt_cnfrm_psswrd'), 'trim|required' );
			$this->form_validation->set_rules ( 'password', $this->lang->line('cmn_lbl_psswrd'), 'trim|required|matches[confirmpassword]' );
			$this->form_validation->set_rules ( 'officephone', $this->lang->line('cmn_lbl_offcphn'), 'trim' );
			$this->form_validation->set_rules ( 'mobilephone', $this->lang->line('mmbr_mgmt_mbl_phn'), 'trim' );
			
			$this->form_validation->set_message ( 'is_unique', 'This email already exists' );

			if ($this->form_validation->run () == FALSE) {
				
				$return = array (
						'unsuccess_msg' => "Something Went Wrong",
						'salutations' => $this->salutations,
						'suffixes' => $this->suffixes,
						'usergroup' => $this->usergroup,
                        'app_lang' => $this->app_lang 
				);
				
				$this->load->view ( 'member/add_member', $return );
			} else {				
				$flag = $this->membermodel->addMember ( '', $this->idlocation );
				
				if ($flag) {					
					redirect ( base_url () . "member/getmember/?msg=success" );
				} else {
					$return = array (
							'unsuccess_msg' => "Something Went Wrong",
							'salutations' => $this->salutations,
							'suffixes' => $this->suffixes,
							'usergroup' => $this->usergroup,
                            'app_lang' => $this->app_lang
					);
					
					$this->load->view ( 'member/add_member', $return );
				}
			}
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to show edit Member
	 */
	public function showeditmember() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get ( 'id', TRUE );
			
			if (empty ( $req ))
				redirect ( base_url () . "member/getmember" );				
				
			$flag = $this->usermodel->getUserData ( $req );
			
			if ($flag) {
				$this->salutations = $this->membermodel->getSalutations ();
				$this->suffixes = $this->membermodel->getSuffixesSelected ( $flag ['idsuffix'] );
				$this->susergroup = $this->membermodel->getSelectedUserGroups ( $flag ['iduser'] );
				
				$flag ['salutations'] = $this->salutations;
				$flag ['suffixes'] = $this->suffixes;
				$flag ['usergroup'] = $this->usergroup;
				$flag ['susergroup'] = $this->susergroup;
                $flag ['gplite'] = $this->session->userdata('gplite');
                $flag ['gplites'] = $this->session->userdata('gplites');
				$data = array (
						'logstatus' => "logout",
                        'page' => "members",
						'username' => $this->session->userdata ( 'username' ),
						'title' => $this->lang->line('sidebar_mntnc_mmbr_mgmt'),
                        'app_lang' => $this->app_lang,
                        'gplite' => $this->session->userdata('gplite'),
				        'gplites' => $this->session->userdata('gplites')
				);
				
				$this->load->view ( 'header', $data );
				$this->load->view ( 'left_sidebar', $data );
				
				$this->load->view ( 'member/edit_member', $flag );
			} else
				redirect ( base_url () . "member/getmember" );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to save edit Member Values
	 */
	public function editmember() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$req = $this->input->post ( 'x_s_' );
			
			if (empty ( $req )) {
				$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
				
				if (! empty ( $seturl [1] ))
					redirect ( $seturl [0] . "#" . $seturl [1] );
				else
					redirect ( $seturl [0] );
			}
			
			$confpwd = $this->input->post ( 'confirmpassword' );
			$this->form_validation->set_rules ( 'username', $this->lang->line('cmn_lbl_usrnme'), 'trim|required|callback_username_check|xss_clean' );
			$this->form_validation->set_rules ( 'email', 'Email', 'trim|required|valid_email' );
			$this->form_validation->set_rules ( 'firstname', $this->lang->line('cmn_lbl_frst_name'), 'trim|required' );
			$this->form_validation->set_rules ( 'middlename', $this->lang->line('cmn_lbl_mddlnme'), 'trim' );
			$this->form_validation->set_rules ( 'lastname', $this->lang->line('cmn_lbl_lstnme'), 'trim|required' );
			$this->form_validation->set_rules ( 'confirmpassword', $this->lang->line('mmbr_mgmt_cnfrm_psswrd'), 'trim' );
			
			if (! empty ( $confpwd ))
				$this->form_validation->set_rules ( 'password', $this->lang->line('cmn_lbl_psswrd'), 'trim|matches[confirmpassword]' );
			$this->form_validation->set_rules ( 'officephone', $this->lang->line('cmn_lbl_offcphn'), 'trim' );
			$this->form_validation->set_rules ( 'mobilephone', $this->lang->line('mmbr_mgmt_mbl_phn'), 'trim' );
			$this->form_validation->set_rules ( 'faxnumber', $this->lang->line('cmn_lbl_fxnmbr'), 'trim' );
			
			if ($this->form_validation->run () == FALSE) {
				$flag = $this->usermodel->getUserData ( $req );
				
				if ($flag) {
					$this->salutations = $this->membermodel->getSalutationsSelected ( $flag ['idsalutation'] );
					$this->suffixes = $this->membermodel->getSuffixesSelected ( $flag ['idsuffix'] );
					$this->usergroup = $this->membermodel->getSelectedUserGroups ( $flag ['iduser'] );
					
					$flag ['salutations'] = $this->salutations;
					$flag ['suffixes'] = $this->suffixes;
					$flag ['usergroup'] = $this->usergroup;
					
					$data = array (
							'logstatus' => "logout",
							'username' => $this->session->userdata ( 'username' ),
							'unsuccess_msg' => $this->lang->line('err_msg_smthng_went_wrng'),
                            'page' => "members",
							'title' => $this->lang->line('sidebar_mntnc_mmbr_mgmt'),
                            'app_lang' => $this->app_lang,
                            'gplite' => $this->session->userdata('gplite'),
					        'gplites' => $this->session->userdata('gplites')
					);
					
					$this->load->view ( 'header', $data );
					$this->load->view ( 'left_sidebar', $data );
					$this->load->view ( 'member/edit_member', $flag );
				} else {
					$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
					
					if (! empty ( $seturl [1] ))
						redirect ( $seturl [0] . "#" . $seturl [1] );
					else
						redirect ( $seturl [0] );
				}
			} else {
				$flag_1 = $this->membermodel->addMember ( $req );
				
				if ($flag_1) {
					
					$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
					
					if (! empty ( $seturl [1] ))
						redirect ( $seturl [0] . "?msg=update#" . $seturl [1] );
					else
						redirect ( $seturl [0] . "?msg=update" );
					
				} else {
					$data = array (
							'logstatus' => "logout",
							'username' => $this->session->userdata ( 'username' ),
							'unsuccess_msg' => $this->lang->line('err_msg_smthng_went_wrng'),
							'page' => "members",
							'title' => $this->lang->line('sidebar_mntnc_mmbr_mgmt'),
                            'app_lang' => $this->app_lang 
					);
				}
				
				$flag = $this->usermodel->getUserData ( $req );
				
				if ($flag) {
					$this->salutations = $this->membermodel->getSalutationsSelected ( $flag ['idsalutation'] );
					$this->suffixes = $this->membermodel->getSuffixesSelected ( $flag ['idsuffix'] );
					$this->usergroup = $this->membermodel->getUserGroups ( $this->flag ['idusergroup'] );
					
					$flag ['salutations'] = $this->salutations;
					$flag ['suffixes'] = $this->suffixes;
					$flag ['usergroup'] = $this->usergroup;
                    $flag ['gplite'] = $this->session->userdata('gplite');
                    $flag ['gplites'] = $this->session->userdata('gplites');
					
					$this->load->view ( 'header', $data );
					$this->load->view ( 'left_sidebar', $data );
					$this->load->view ( 'member/edit_member', $flag );
				} else {
					$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
					
					if (! empty ( $seturl [1] ))
						redirect ( $seturl [0] . "#" . $seturl [1] );
					else
						redirect ( $seturl [0] );
				}
			}
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to check user name existence
	 */
	/* public function username_check($str = '') {
		$str = $this->input->post ( 'username' );
		$id = $this->input->post ( 'x_s_' );
		
		$flag = $this->membermodel->userExist ( $str, $id );
		
		if ($flag) {
			$this->form_validation->set_message ( 'username_check', $this->lang->line('err_msg_mmbr_alrdy_exsts') );
			return false;
		} else {
			return true;
		}
	} */
	
	/**
	 * Function to Display List of Members
	 */
	public function listallmember($grid = 'none') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'page' => "members",
					'title' => $this->lang->line('sidebar_mntnc_mmbr_mgmt'),
                    'app_lang' => $this->app_lang,
                    'list' => $this->membermodel->listMembers ()
			);
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			$this->load->view ( 'member/list_members', $data );
		}
	}
	
	/**
	 * Function to display List Of Members
	 */
	public function getmember($grid = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$columns = array (
					0 => array (
							'name' => $this->lang->line('mmbr_mgmt_nme'),
							'db_name_1' => 'firstname',
							'db_name_2' => 'lastname',
							'header' => $this->lang->line('mmbr_mgmt_nme'),
							'group' => 'User',
							'required' => TRUE,
							'unique' => TRUE,
							'form_control' => 'text_long',
							'type' => '1+2' 
					),
					1 => array (
							'name' => 'Email',
							'db_name' => 'email',
							'header' => $this->lang->line('mmbr_mgmt_email_addr'),
							'group' => 'User',
							'required' => TRUE,
							'form_control' => 'text_long',
							'required' => TRUE 
					)
					// 'type' => '1-n'
					,
					2 => array (
							'name' => $this->lang->line('mmbr_mgmt_is_actv'),
							'db_name' => 'is_active',
							'header' => $this->lang->line('mmbr_mgmt_is_actv'),
							'group' => 'User',
							'required' => TRUE,
							'form_control' => 'text_long',
							'required' => TRUE 
					)
					// 'type' => '1-n'
					,
					3 => array (
							'name' => $this->lang->line('sidebar_wrk_asgnmnt'),
							'db_name' => 'service_request',
							'header' => $this->lang->line('sidebar_wrk_asgnmnt'),
							'group' => 'User',
							'required' => TRUE,
							'form_control' => 'text_long',
							'required' => TRUE 
					)
					// 'type' => '1-n'
					,
					4 => array (
							'name' => $this->lang->line('mmbr_mgmt_srvlnce'),
							'db_name' => 'surveillance',
							'header' => $this->lang->line('mmbr_mgmt_srvlnce'),
							'group' => 'User',
							'required' => TRUE,
							'form_control' => 'text_long',
							'required' => TRUE 
					)
					// 'type' => '1-n'
					,
					5 => array (
							'name' => $this->lang->line('sidebar_data_entry_trtmnts'),
							'db_name' => 'treatments',
							'header' => $this->lang->line('sidebar_data_entry_trtmnts'),
							'group' => 'User',
							'required' => TRUE,
							'form_control' => 'text_long',
							'required' => TRUE 
					)
					// 'type' => '1-n'
					,
					6 => array (
							'name' => $this->lang->line('mmbr_mgmt_rprts'),
							'db_name' => 'reports',
							'header' => $this->lang->line('mmbr_mgmt_rprts'),
							'group' => 'User',
							'required' => TRUE,
							'form_control' => 'text_long',
							'required' => TRUE 
					)
					// 'type' => '1-n'
					,
					7 => array (
							'name' => $this->lang->line('mmbr_mgmt_cmpny_admn'),
							'db_name' => 'company_admin',
							'header' => $this->lang->line('mmbr_mgmt_cmpny_admn'),
							'group' => 'User',
							'required' => TRUE,
							'form_control' => 'text_long',
							'required' => TRUE 
					)
					// 'type' => '1-n'
					,
					8 => array (
							'name' => $this->lang->line('mmbr_mgmt_dvc_mngmnt'),
							'db_name' => 'device_managment',
							'header' => $this->lang->line('mmbr_mgmt_dvc_mngmnt'),
							'group' => 'User',
							'required' => TRUE,
							'form_control' => 'text_long',
							'required' => TRUE 
					)
					// 'type' => '1-n'
					 
			)
			;
			
			$commands ['delete'] ['toolbar'] = FALSE;
			
			$params = array (
					'id' => 'iduser',
					'table' => 'users',
					'url' => 'member/getmember',
					'uri_param' => $grid,
					'columns' => $columns,
					'order' => array (
							0 => 'asc' 
					),
					
					'filters' => array (
							0 => array (
									'value' => $this->idlocation 
							) 
					),
					'commands' => $commands,
					'ajax' => TRUE,
					'msc_url' => array (
							'excel_url' => base_url () . 'member/toExcelAll',
							'pdf_url' => base_url () . 'member/toPdfAll',
							'add_url' => 'showaddmember',
							'text' => 'Member' 
					) 
			);			
			
			$newdata = array (
					'url' => base_url () . $params ['url'] . '#' . $params ['id'] . '=' . $grid 
			);
			
			$this->session->set_userdata ( $newdata );
			
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_mntnc_mmbr_mgmt'),
                    'app_lang' => $this->app_lang,
                    'page' => "members"
			);
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			// Pass grid to the view
            $data = (object)array();
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			$data->statuses = $this->statuses;
			
			$this->load->view ( 'member/members', $data );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function toExcelAll() {
		$query ['data'] = $this->membermodel->ToExcelAll ();
		
		$this->load->view ( 'member/excel_view', $query );
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
		$this->load->helper ( 'pdf_helper' ); // Load helper
		$query ['data'] = $this->membermodel->ToExcelAll ();
		
		$data = $this->load->view ( 'member/pdf_view', $query, true );
		
		create_pdf_l ( $data, str_replace(' ', '', $this->lang->line('sidebar_mntnc_mmbr_mgmt')) ); // Create pdf
	}
	
	/**
	 * Function to activate Member
	 */
	public function activemember() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->membermodel->activeMember ();
			
			$msg = "";
			
			if ($flag)
				$msg = "activated";
			else
				$msg = "error";
			
			redirect ( base_url () . "member/getmember?msg=" . $msg );
		}
	}
	
	/**
	 * Function to deactivate Member
	 */
	public function deactivemember() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->membermodel->deactiveMember ();
			
			$msg = "";
			
			if ($flag)
				$msg = "deactivated";
			else
				$msg = "error";
			
			redirect ( base_url () . "member/getmember?msg=" . $msg );
		}
	}
}

/* End of file member.php */
/* Location: ./application/controllers/member.php */