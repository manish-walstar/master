<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Zone extends CI_Controller {
	public $salutations = "";
	public $suffixes = "";
	public $statuses;
	public $idlocation = "";
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		
        $this->load->helper('language');
		$this->load->model ( 'zone_model' );
		$this->statuses = $this->zone_model->getStatuses ();
		
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		if ($this->session->userdata ( 'logged_in' )) {
			$this->idlocation = $this->session->userdata ( 'idlocation' );
		}
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			redirect ( base_url () . "zone/getzone" );
		}
	}
	
	/**
	 * Function to add a new zone
	 */
	public function addzone() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->form_validation->set_rules ( 'zone_name', $this->lang->line('zone_mgmt_nme'), 'trim|required|callback_zoneCheck|xss_clean' );
			$this->form_validation->set_rules ( 'mileage', $this->lang->line('zone_mgmt_sqr_mlge'), 'trim|maxSize[10]' );
			$this->form_validation->set_rules ( 'zone_desc', $this->lang->line('zone_mgmt_desc'), 'trim|required' );
			
			if ($this->form_validation->run () == FALSE) {
				$this->load->view ( 'zones/add_zone' );
			} else {
				$flag = $this->zone_model->addzone ();
				$data = array ();
                $data ['app_lang'] = $this->app_lang;
				if (! empty ( $flag )) {
					$data = array (
							"msg" => "success" 
					);
				} else {
					$data = array (
							"msg" => "error" 
					);
				}
				
				$this->load->view ( 'zones/add_zone', $data );
			}
		}
	}
	
	/**
	 * Function to show edit zone
	 */
	public function addzoneview() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->model ( 'adultsurveillance_model' );
                        
			$data = array (
					'user_loc' => $this->adultsurveillance_model->getUserLoc (),
                    'app_lang' => $this->app_lang 
			);
			$this->load->view ( 'zones/add_zone', $data );
		}
	}
	
	/*
	 * pop up edit
	 */
	public function showeditpop() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get_post ( 'id' );
			$data = array ();
			
			if (empty ( $req ))
				redirect ( base_url () . "zone/getzone" );
				
				// $req = base64_encode(json_encode(base64_encode(json_encode($req))."_"."hsdfwvefjbjk"));
			
			$flag = $this->zone_model->getZoneData ( $req );
			$this->load->model ( 'adultsurveillance_model' );
			$data ['googlezoom'] = $this->session->userdata ( 'googlezoom' );
			$data ['user_loc'] = $this->adultsurveillance_model->getUserLoc ();
            $data ['app_lang'] = $this->app_lang;
			if (! empty ( $flag )) {
				$data ['detail'] = $flag;
			} else {
				$data ['detail'] = array (
						'active' => 0 
				);
			}
			$zoneCordsData = $this->zone_model->getZoneCords ( $req );
			if (! empty ( $zoneCordsData )) {
				$data ['zonecord'] = $zoneCordsData ['zonecord'];
			}
			$this->load->view ( 'zones/edit_zone', $data );
		}
	}
	
	/**
	 * Function to save edit zone Values
	 */
	public function updatezone() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data = array ();
			$req = $this->input->get_post ( 'idzone' );
			
			if (empty ( $req )) {
				$data = array (
						"msg" => "error" 
				);
				
				$this->load->view ( 'zones/edit_zone', $data );
			}
			
			$flag_1 = $this->zone_model->getZoneData ( $req );
			
			$this->form_validation->set_rules ( 'zone_name', $this->lang->line('zone_mgmt_nme'), 'trim|required' );
			$this->form_validation->set_rules ( 'mileage', $this->lang->line('zone_mgmt_sqr_mlge'), 'trim|numeric|maxSize[10]' );
			$this->form_validation->set_rules ( 'zone_desc', $this->lang->line('zone_mgmt_desc'), 'trim|required' );
			$this->form_validation->set_rules ( 'active', 'Active', 'trim' );
			
			$this->load->model ( 'adultsurveillance_model' );
			$data ['googlezoom'] = $this->session->userdata ( 'googlezoom' );
			$data ['user_loc'] = $this->adultsurveillance_model->getUserLoc ();
			$zoneCordsData = $this->zone_model->getZoneCords ( $req );
			if (! empty ( $zoneCordsData )) {
				$data ['zonecord'] = $zoneCordsData ['zonecord'];
			}
			
			if ($this->form_validation->run () == FALSE) {
				$data ['detail'] = $flag_1;
				$data ['msg'] = "error";
				$this->load->view ( 'zones/edit_zone', $data );
			} else {
				$flag = $this->zone_model->updateZone ();
				if (! empty ( $flag )) {
					$data ['detail'] = $flag_1;
					$data ['msg'] = "update";
				} else {
					$data ['detail'] = $flag_1;
					$data ['msg'] = "error";
				}
				
				// die;
				$this->load->view ( 'zones/edit_zone', $data );
			}
		}
	}
	
	/**
	 * Function to delete zone
	 */
	public function deletezone() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->zone_model->deleteZone ();
			
			$msg = "";
			
			if ($flag)
				$msg = "success";
			else
				$msg = "error";
			
			$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
			if (! empty ( $seturl [1] ))
				redirect ( $seturl [0] . "?del=" . $msg . "#" . $seturl [1] );
			else
				redirect ( $seturl [0] . "?del=" . $msg );
			// redirect(base_url().'zone/getzone?del='.$msg);
		}
	}
	
	/**
	 * Function to check zone name existence
	 */
	public function zoneCheck($str = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$str = $this->input->post ( 'zone_name' );
			
			$flag = $this->zone_model->zoneExist ( $str );
			
			if ($flag) {
				$this->form_validation->set_message ( 'zoneCheck', $this->lang->line('err_msg_zone_alrdy_exsts') );
				return false;
			} else {
				return true;
			}
		}
	}
	
	/**
	 * Function to activate zone
	 */
	public function activezone() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->zone_model->activeZone ();
			
			$msg = "";
			
			if ($flag)
				$msg = "activated";
			else
				$msg = "error";
			
			redirect ( base_url () . "zone/getzone?msg=" . $msg );
		}
	}
	
	/**
	 * Function to deactivate zone
	 */
	public function deactivezone() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->zone_model->deactiveZone ();
			
			$msg = "";
			
			if ($flag)
				$msg = "deactivated";
			else
				$msg = "error";
			
			redirect ( base_url () . "zone/getzone?msg=" . $msg );
		}
	}
	
	/**
	 * Function to display List Of zones
	 */
	public function getzone($grid = '', $msg = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$columns = array (
					0 => array (
							'name' => $this->lang->line('zone_mgmt_nme'),
							'db_name' => 'zone',
							'header' => $this->lang->line('zone_mgmt_nme'),
							'group' => ucfirst(strtolower($this->lang->line('zone_mgmt_hdng'))),
							'required' => TRUE,
							'unique' => TRUE,
							'form_control' => 'text_long',
							'type' => 'string' 
					),
					1 => array (
							'name' => $this->lang->line('zone_mgmt_desc'),
							'db_name' => 'description',
							'header' => $this->lang->line('zone_mgmt_desc'),
							'group' => 'Zone',
							'required' => TRUE,
							'form_control' => 'text_long',
							'required' => TRUE 
					)
					// 'type' => '1-n'
					,
					
					2 => array (
							'name' => $this->lang->line('mmbr_mgmt_is_actv'),
							'db_name' => 'active',
							'header' => $this->lang->line('mmbr_mgmt_is_actv'),
							'group' => 'Zone',
							'required' => TRUE,
							'form_control' => 'text_long',
							'required' => TRUE 
					)
					// 'type' => '1-n'
					 
			);
			
			$commands ['delete'] ['toolbar'] = FALSE;
			$add_view = $this->load->view ( 'zones/add_zone', '', TRUE );
			$edit_view = $this->load->view ( 'zones/edit_zone', '', TRUE );
			$params = array (
					'id' => 'idzone',
					'table' => 'zones',
					'url' => 'zone/getzone',
					'uri_param' => $grid,
					'columns' => $columns,
					'order' => array (
							0 => 'asc' 
					),
					// 'columns_visible' => array(0,1),
					'filters' => array (
							0 => array (
									'value' => $this->idlocation 
							) 
					),
					'commands' => $commands,
					'ajax' => TRUE,
					'msc_url' => array (
							'excel_url' => base_url () . 'zone/toExcelAll',
							'pdf_url' => base_url () . 'zone/toPdfAll',
							'text' => 'Zone' 
					),
					'add_view' => $add_view,
					'edit_view' => $edit_view 
			);
			
			$newdata = array (
					'url' => base_url () . $params ['url'] . '#' . $params ['id'] . '=' . $grid 
			);
			
			$this->session->set_userdata ( $newdata );
			
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_mntnc_zone_mgmt'),
                    'page' => "zone_management",
                    'app_lang' => $this->app_lang
			);
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			// Pass grid to the view
            $data = (object)array();
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			$data->msg = $msg;
			$data->statuses = $this->statuses;
			
			$this->load->view ( 'zones/zones', $data );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function toExcelAll() {
		$query ['data'] = $this->zone_model->listZones ();
		
		$this->load->view ( 'zones/excel_view', $query );
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
		$this->load->helper ( 'pdf_helper' ); // Load helper
		$query ['data'] = $this->zone_model->listZones ();
		
		$data = $this->load->view ( 'zones/pdf_view', $query, true );
		// $data = file_get_contents(htmlentities($dd)); // Pass the url of html report
		
		create_pdf ( $data, $this->lang->line('site_mgmt_zones') ); // Create pdf
	}
}

/* End of file zone.php */
/* Location: ./application/controllers/zone.php */