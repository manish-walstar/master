<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Lighttrap_report extends CI_Controller {
	public $product_list;
	public $startdate;
	public $enddate;
	public $month_yearofuse;
	public $location_data;
	public $atvalues;
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		
        $this->load->helper('language');
		$this->load->model ( 'lighttrap_report_model' );
		$this->load->model ( 'usermodel' );
		
		$this->usermodel->set_access_session ();
		
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		if (! $this->usermodel->user_access ( 'reports' ) && ! $this->usermodel->user_access ( 'company_admin' ))
			redirect ( base_url () );
		
		$id = $this->session->userdata ( 'id' );
		$id_arr = explode ( "_", json_decode ( base64_decode ( $id ) ) );
		
		$id = json_decode ( base64_decode ( $id_arr [0] ) );
		
		$this->userinfo = $this->usermodel->getUserData ( $id );
		
		$middlename = " ";
		if (isset ( $this->userinfo ['middlename'] ))
			$middlename = ! empty ( $this->userinfo ['middlename'] ) ? " " . $this->userinfo ['middlename'] . " " : " ";
		
		if (isset ( $this->userinfo ['firstname'] ) || isset ( $this->userinfo ['lastname'] ))
			$this->inspector = $this->userinfo ['firstname'] . $middlename . $this->userinfo ['lastname'];
		
		$this->enddate = date ( 'm/d/Y' );
		$this->startdate = date ( 'm/d/Y', strtotime ( "-30 day" ) );
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			redirect ( base_url () . "lighttrap_report/getlighttrap_report" );
		}
	}
	
	/**
	 * Function to fetch All Lighttrap
	 * in current daterange
	 */
	public function getlighttrap_report() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			
			$data_1 = array ();
			if (empty ( $startdate ) || empty ( $enddate )) {
				$data = $this->lighttrap_report_model->getLighttrap ( $this->startdate, $this->enddate );
				$data_1 = array (
						'username' => $this->session->userdata ( 'username' ),
						'logstatus' => "logout",
						'title' => $this->lang->line('sidebar_rprtng_plus_lght_trap_rprt'),
						'page' => "lighttrap_report",
						'startdate' => $this->startdate,
						'enddate' => $this->enddate,
						'inspector' => $this->inspector 
				);
				$data_1 = array_merge ( $data_1, $data );
			} else {
				if (! empty ( $startdate ) && ! empty ( $enddate )) {
					$startdate_arr = explode ( "/", $startdate );
					$enddate_arr = explode ( "/", $enddate );
					$this->startdate = $startdate;
					$this->enddate = $enddate;
				}
				
				$data = $this->lighttrap_report_model->getLighttrap ( $this->startdate, $this->enddate );
				$data_1 = array (
						'username' => $this->session->userdata ( 'username' ),
						'logstatus' => "logout",
						'title' => $this->lang->line('sidebar_rprtng_plus_lght_trap_rprt'),
						'page' => "lighttrap_report",
						'startdate' => $this->startdate,
						'enddate' => $this->enddate,
						'inspector' => $this->inspector 
				);
				$data_1 = array_merge ( $data_1, $data );
			}
			 //print'<pre>';
//			 print_r($data_1);
//			 die;
            $data_1['app_lang'] = $this->app_lang;
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			$this->load->view ( 'lighttrap_reports/lighttrap_reports', $data_1 );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to fetch the data
	 * and format it in order to return
	 */
	public function exportView() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			
			$data_1 = array ();
			if (empty ( $startdate ) || empty ( $enddate )) {
				$data = $this->lighttrap_report_model->getLighttrap ( $this->startdate, $this->enddate );
				$data_1 = array (
						'username' => $this->session->userdata ( 'username' ),
						'logstatus' => "logout",
						'title' => $this->lang->line('sidebar_rprtng_plus_lght_trap_rprt'),
						'page' => "lighttrap_report",
						'startdate' => $this->startdate,
						'enddate' => $this->enddate,
						'inspector' => $this->inspector,
                        'app_lang' => $this->app_lang
				);
				$data_1 = array_merge ( $data_1, $data );
			} else {
				if (! empty ( $startdate ) && ! empty ( $enddate )) {
					$startdate_arr = explode ( "/", $startdate );
					$enddate_arr = explode ( "/", $enddate );
					$this->startdate = $startdate;
					$this->enddate = $enddate;
				}
				
				$data = $this->lighttrap_report_model->getLighttrap ( $this->startdate, $this->enddate );
				$data_1 = array (
						'username' => $this->session->userdata ( 'username' ),
						'logstatus' => "logout",
						'title' => $this->lang->line('sidebar_rprtng_plus_lght_trap_rprt'),
						'page' => "lighttrap_report",
						'startdate' => $this->startdate,
						'enddate' => $this->enddate,
						'inspector' => $this->inspector,
                        'app_lang' => $this->app_lang 
				);
				$data_1 = array_merge ( $data_1, $data );
			}
			$data = $this->load->view ( 'lighttrap_reports/pdf_view', $data_1, TRUE );
			return $data;
		}
	}
	
	/**
	 * Function to convert data into PDF
	 */
	public function toPDFAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->helper ( 'pdf_helper' );
			
			$data = $this->exportView ();
			// print'<pre>';
			// print_r($data);
			// die;
			
			create_pdf_l ( $data, $this->lang->line('lght_trap_rprt_subhdng') );
		}
	}
	
	/**
	 * Function to convert data into Excel
	 */
	public function toEXCELAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$data = $this->exportView ();
			// print'<pre>';
			// print_r($data);
			// die;
			header ( "Content-type: application/octet-stream" );
			header ( "Content-Disposition: attachment; filename=". str_replace(' ', '', $this->lang->line('lght_trap_rprt_subhdng')).".xls" );
			header ( "Pragma: no-cache" );
			header ( "Expires: 0" );
			
			echo $data;
			exit ();
		}
	}
}

/* End of file lighttrap_report.php */
/* Location: ./application/controllers/lighttrap_report.php */