<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Service_request extends CI_Controller {
	public $site_type = "";
	public $zones = "";
	public $s_site_type = "";
	public $s_zones = "";
	public $states = "";
	public $idstate = "";
	public $s_states = "";
	public $site_data = "";
	public $flag = array ();
	public $idlocation;
	public $opendate;
	public $opentime;
	public $closedate;
	public $closetime;
	public $disp_new;
	public $sitegroup = "";
	public $applicator;
	public $usergroup;
	/**
	 *
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
        
		$this->load->helper('language');
		$this->load->model ( 'service_requestmodel' );
		$this->load->model ( 'adultsurveillance_model' );
		$this->load->model ( 'site_model' );
		$this->load->model ( 'larvalsurveillance_model' );
		$this->load->model ( 'landingrate_model' );
		$this->load->model ( 'treatment_model' );
		$this->load->model ( 'post_treatment_model' );
		$this->load->model ( 'usermodel' );
		$this->load->model ( 'zone_model' );
		$this->sites = $this->site_model->getExisting_site ();
		// $this->applicatorname = $this->site_model->getExisting_site();
		$this->applicator = $this->larvalsurveillance_model->getInspectors ();
		$this->usergroup = $this->larvalsurveillance_model->getUserGroups ();
		// $this->usergroup = $this->larvalsurveillance_model->getInspectors();
		
		$this->site_type = $this->site_model->getSitetypes ();
		$this->zones = $this->site_model->getZones ();
		$this->states = $this->site_model->getStates ();
		$this->disp_new = $this->service_requestmodel->getDispositions ();
		$this->sitegroup = $this->site_model->getSiteGroup ();
		
		// $this->applicator = $this->service_requestmodel->getInspectors();
		
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		if ($this->session->userdata ( 'idlocation' ))
			$this->idlocation = $this->session->userdata ( 'idlocation' );
		
		$this->usermodel->set_access_session ();
		if ($this->usermodel->user_access ( 'service_request' ) || $this->usermodel->user_access ( 'company_admin' )) {
		} else {
			redirect ( base_url () );
		}
		$this->opendate = date ( 'm/d/Y' );
		$this->closedate = $this->opendate;
		// $this->opentime = date('h:i:s A');
		$this->closetime = $this->opentime;
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			redirect ( base_url () . "service_request/getservice_request" );
		}
	}
	
	/**
	 * Function to Show Add Service_request Form
	 */
	public function showaddservice_request($id = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_data_entry_wrk_asgnmnts'),
					'page' => "service_request" 
			);
			
            /**
			 * When the user clicks the marker on the Map Summary of the site
			 */
            $mapFlag = $this->input->get('mapFlag');
            $optIdSite = $this->input->get('idsite');
			/**
			 * When the user gets the success / update msg
			 * on submitting the Post Treatment
			 * @idptva Primary Id of Post Treatment
			 */
			$idposttrtment = $this->input->get_post ( 'idposttrtment' );
			$datapt = $this->post_treatment_model->getPost_treatmentData ( $idposttrtment );
			
			/**
			 * This section calls when the user clicks
			 * Adverse Effect Inspection
			 */
			$idtrt = $this->input->get_post ( 'idtrt' );
			$type = $this->input->get_post ( 'type' );
			$datatrt = array ();
			if (! empty ( $idtrt )) {
				switch ($type) {
					case 'adult' :
						$datatrt = $this->treatment_model->getAdultTreatmentData ( $idtrt );
						break;
					case 'larval' :
						$datatrt = $this->treatment_model->getLarvalTreatmentData ( $idtrt );
						break;
					case 'pti_larval' :
						$datatrt = $this->treatment_model->getLarvalTreatmentData ( $idtrt );
						break;
				}
			}
			
			if (isset ( $id ) && ! empty ( $id )) {
				$this->flag = $this->service_requestmodel->getServiceRequestData ( $id );
				
				if (! empty ( $this->flag )) {
					$this->sites = $this->site_model->getSelectedExistingSite ( $this->flag ['idsite'] );
					$this->site_type = $this->site_model->getSitetypes ();
					$this->applicator = $this->larvalsurveillance_model->getSelectedInspectors ( $this->flag ['idapplicator'] );
					$this->usergroup = $this->larvalsurveillance_model->getSelectedGroups ( $this->flag ['idusergroup'] );					
					$this->states = $this->site_model->getStates ( );
					$disp_arr = $this->service_requestmodel->getSelectedDispositions ( $this->flag ['idservicerequest'] );
					$this->flag ['disp_arr'] = $disp_arr;
					$comments = '';
					if (! empty ( $this->flag ['comments'] )) {
						$comments = explode ( "$", $this->flag ['comments'] );
						$comments = implode ( "<br>------------------------<br>", $comments );
					}
					unset ( $this->flag ['comments'] );
					$this->flag ['past_comments'] = $comments;
                    $optIdSite = $this->flag['idsite'];
                    if ($this->flag ['isapproved'] == '0') {
        				$this->flag ['address1'] = $this->flag ['address'];
        			}
				}
			}
			
			$return = array (
					'sites' => $this->sites,
					// 'applicatorname'=> $this->applicatorname,
					'applicator' => $this->applicator,
					'usergroup' => $this->usergroup,
					'site_type' => $this->site_type,
					'zones' => $this->zones,
					'states' => $this->states,
					'sitegroup' => $this->sitegroup,
					'disp_new' => $this->disp_new,
                    'idsitetype' => !empty($this->flag ['idsitetype']) ? $this->flag ['idsitetype'] : '',
			);
			
			//When the user clicks Add New
            if (empty ( $datatrt ) && empty ( $datapt )) {
				$return ['opendate'] = $this->opendate;
				$return ['closedate'] = $this->closedate;
				// $return['opentime'] = $this->opentime;
				$return ['closetime'] = $this->closetime;
			} else if (! empty ( $datatrt )) {//When the user selects treatment type
				$ptype = '';
				if (! empty ( $idtrt )) {
					$ptype = $type;
					switch ($type) {
						case 'adult' :
							$return ['opendate'] = date ( 'm/d/Y', strtotime ( $datatrt ['date'] ) );
							break;
						case 'larval' :
							$return ['opendate'] = date ( 'm/d/Y', strtotime ( $datatrt ['date'] ) );
							break;
						case 'pti_larval' :
							$return ['opendate'] = date ( 'm/d/Y', strtotime ( $datatrt ['post_trtmnt_date'] ) );
							$type = 'larval';
							break;
					}
				}
				$return ['closedate'] = '';
				$return ['opentime'] = $datatrt ['time'];
				$return ['closetime'] = '';
				$return ['idtrt'] = $idtrt;
				$return ['ptype'] = $ptype;
				$return ['trttype'] = $type;
				$return ['comments'] = ! empty ( $datatrt ['comments'] ) ? $datatrt ['comments'] : '';
				if (! empty ( $datatrt ['idapplicator'] )) {
					$this->applicator = $this->larvalsurveillance_model->getSelectedInspectors ( $datatrt ['idapplicator'] );
					$return ['applicator'] = $this->applicator;
				}
                $optIdSite = $datatrt ['idsite'];
				
			} else if (! empty ( $datapt )) {//When the user open Post Treatment Record
				$return ['opendate'] = date ( 'm/d/Y', strtotime ( $datapt ['date'] ) );
				$return ['opentime'] = $datapt ['time'];
				$return ['idtrt'] = $datapt ['idtreatment'];
				$return ['ptype'] = $datapt ['post_inspection_type'];
				$return ['firstname'] = $datapt ['first_name'];
				$return ['lastname'] = $datapt ['last_name'];
				$return ['description'] = (! empty ( $datapt ['notes'] )) ? $datapt ['notes'] : '';
                $optIdSite = $datapt ['idsite'];
                $this->applicator = $this->larvalsurveillance_model->getSelectedInspectors ( $datapt ['idinspector'] );
                $return ['applicator'] = $this->applicator;
			}
            
            if(!empty($optIdSite)){
                $site_data = $this->site_model->getSiteData ( $optIdSite );
    			if (! empty ( $site_data )) {
                    $this->sites = $this->site_model->getSelectedExistingSite ( $site_data ['idsite'] );
    				$this->zones = $this->site_model->getSelectedZones ( $site_data ['idzone'] );
    				$this->site_type = $this->site_model->getSitetypes ( );
    				$return ['idsite'] = $site_data ['idsite'];
    				$return ['sitename'] = $site_data ['site'];
    				$return ['address1'] = $site_data ['address1'];
    				$return ['address2'] = $site_data ['address2'];
    				$return ['city'] = $site_data ['city'];
    				$return ['maplabel'] = $site_data ['maplabel'];
    				$return ['postalcode'] = $site_data ['postalcode'];
    				//$return ['mainphone'] = ! empty ( $site_data ['manphone'] ) ? $site_data ['manphone'] : '';
    				//$return ['altphone'] = ! empty ( $site_data ['alternatephone'] ) ? $site_data ['alternatephone'] : '';
    				//$return ['faxphone'] = ! empty ( $site_data ['faxnumber'] ) ? $site_data ['faxnumber'] : '';
    				//$return ['latitude'] = (! empty ( $site_data ['latitude'] ) && empty ( $return ['latitude'] )) ? $site_data ['latitude'] : '';
    				//$return ['longitude'] = (! empty ( $site_data ['longitude'] ) && empty ( $return ['longitude'] )) ? $site_data ['longitude'] : '';
                    $return ['idstate'] = !empty($site_data ['idstate']) ? $site_data ['idstate'] : '';
                    $return ['sites'] = $this->sites;
    				$return ['zones'] = $this->zones;
    				$return ['site_type'] = $this->site_type;
                    $return ['idsitetype'] = $this->flag['idsitetype'] = !empty($site_data ['idsitetype']) ? $site_data ['idsitetype'] : '';
                    $return ['sitetype'] = !empty($site_data ['sitetype']) ? $site_data ['sitetype'] : '';
    			}
            }
            
			if (! empty ( $this->flag )) {
				$this->flag['disp_new'] = $this->disp_new;
				$this->flag = array_merge ( $return , $this->flag);
			} else {
                $this->flag = $return;
			}
			
			$data_1 = array (
					'state_list' => $this->landingrate_model->getStateName () 
			);
			$this->flag ['location_view'] = $this->load->view ( 'treatment/location_view', $data_1, TRUE );
            $this->flag ['idlocation'] = $this->session->userdata('idlocation');
            
            $this->flag ['mapFlag'] = $mapFlag;
			if(!empty($optIdSite)){
                $mapData = $this->getAllEventsData($optIdSite);
				$this->flag = array_merge($this->flag, $mapData);
			}
			if( (isset($this->flag ['description']) && $this->flag ['idlocation'] == 36 && $this->flag ['isapproved'] == '0') 
					&& ($this->flag ['description'] == 'Yes' || $this->flag ['description'] == 'yes' || $this->flag ['description'] == 'YES' 
					|| $this->flag ['description'] == 'No' || $this->flag ['description'] == 'NO' || $this->flag ['description'] == 'no' )){
					$this->flag ['description'] = $this->lang->line('ser_req_ca_pwa_technician_status') . $this->flag ['description'];
			}
			$this->load->view ( 'service_requests/add_service_request', $this->flag );
			
		}

	}
	
	/**
	 * Function to add a new Service_request
	 */
	public function addservice_request() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_wrk_asgnmnt'),
					'page' => "service_request" 
			)
			;
			// $this->load->view('header',$data_1);
			// $this->load->view('left_sidebar',$data_1);
			
			$this->form_validation->set_rules ( 'opendate', $this->lang->line('wrk_asgnmnts_open_date'), 'trim|required' );
			$this->form_validation->set_rules ( 'opentime', $this->lang->line('srvc_rqst_open_time'), 'trim|required' );
			$this->form_validation->set_rules ( 'closedate', $this->lang->line('wrk_asgnmnts_close_date'), 'trim' );
			$this->form_validation->set_rules ( 'closetime', $this->lang->line('wrk_asgnmnts_close_time'), 'trim' );
			$this->form_validation->set_rules ( 'firstname', $this->lang->line('cmn_lbl_frst_name'), 'trim|required' );
			$this->form_validation->set_rules ( 'lastname', $this->lang->line('cmn_lbl_lstnme'), 'trim|required' );
			$this->form_validation->set_rules ( 'sitename', $this->lang->line('whthr_snsr_site_nm'), 'trim' );
			$this->form_validation->set_rules ( 'idsitetype', $this->lang->line('trap_mgmt_site_type'), 'trim' );
			$this->form_validation->set_rules ( 'idzone', 'Zone', 'trim' );
			$this->form_validation->set_rules ( 'address1', $this->lang->line('site_mgmt_street'), 'trim' );
			$this->form_validation->set_rules ( 'address2', $this->lang->line('site_mgmt_street'), 'trim' );
			$this->form_validation->set_rules ( 'city', $this->lang->line('site_mgmt_cty'), 'trim' );
			$this->form_validation->set_rules ( 'idstate', $this->lang->line('site_mgmt_state'), 'trim' );
			$this->form_validation->set_rules ( 'postalcode', $this->lang->line('site_mgmt_postl_cde'), 'trim' );
			$this->form_validation->set_rules ( 'latitude', $this->lang->line('site_mgmt_lat'), 'trim|required|numeric' );
			$this->form_validation->set_rules ( 'longitude', $this->lang->line('site_mgmt_lng'), 'trim|required|numeric' );
			$this->form_validation->set_rules ( 'mainphone', $this->lang->line('site_mgmt_main_ph'), 'trim' );
			$this->form_validation->set_rules ( 'altphone', $this->lang->line('site_mgmt_alternt_ph'), 'trim' );
			$this->form_validation->set_rules ( 'faxphone', $this->lang->line('site_mgmt_fx_ph'), 'trim' );
			$this->form_validation->set_rules ( 'description', $this->lang->line('usr_grp_mgmt_dscptn'), 'trim' );
			$this->form_validation->set_rules ( 'comments', $this->lang->line('cmn_lbl_cmnts'), 'trim' );
			$this->form_validation->set_rules ( 'idapplicator', $this->lang->line('adlt_trtmnt_applicator'), 'trim' );
			
			/*
			 * $idapplicator = $this->input->post('idapplicator');
			 * $this->form_validation->set_rules('idapplicator', $this->lang->line('adlt_trtmnt_applicator'), 'trim|required');
			 * $this->applicator = $this->larvalsurveillance_model->getSelectedInspectors($this->flag['idapplicator']);
			 */
			
			$req = $this->input->post ( 'x_s_' );
			
			if ($this->form_validation->run () == FALSE) {
				$return = array (
						'unsuccess_msg' => "Something Went Wrong" 
				);
				
				if (! empty ( $req )) {
					$this->flag = $this->service_requestmodel->getServiceRequestData ( $req );
					
					if (! empty ( $this->flag )) {
						$this->sites = $this->site_model->getSelectedExistingSite ( $this->flag ['idsite'] );
						// $this->applicatorname = $this->site_model->getSelectedExistingSite($this->flag['idsite']);
						$this->applicator = $this->larvalsurveillance_model->getSelectedInspectors ( $this->flag ['idapplicator'] );
						$this->usergroup = $this->larvalsurveillance_model->getSelectedGroups ( $this->flag ['idusergroup'] );
						
						$this->site_type = $this->site_model->getSelected_sitetype ( $this->flag ['idsitetype'] );
						$this->zones = $this->site_model->getSelectedSiteZones ( $this->flag ['idzone'] );
						$this->states = $this->site_model->getSelectedSiteStates ( $this->flag ['idsite'] );
						$site_data = $this->site_model->getSiteData ( $this->flag ['idsite'] );
						$disp_arr = $this->service_requestmodel->getSelectedDispositions ( $this->flag ['idservicerequest'] );
						$this->flag ['disp_arr'] = $disp_arr;
						if (! empty ( $site_data )) {
							$this->flag ['address1'] = $site_data ['address1'];
							$this->flag ['address2'] = $site_data ['address2'];
							$this->flag ['city'] = $site_data ['city'];
							$this->flag ['maplabel'] = $site_data ['maplabel'];
							$this->flag ['postalcode'] = $site_data ['postalcode'];
							$this->flag ['latitude'] = $site_data ['latitude'];
							$this->flag ['longitude'] = $site_data ['longitude'];
							// $this->flag['idsitegroup'] = $site_data['idsitegroup'];
						}
					}
				}
				
				if (! empty ( $this->flag ))
					$this->flag = array_merge ( $this->flag, $return );
				else {
					$return = array (
							'sites' => $this->sites,
							// 'applicatorname' => $this->applicatorname,
							'applicator' => $this->applicator,
							'usergroup' => $this->usergroup,
							'site_type' => $this->site_type,
							'zones' => $this->zones,
							'states' => $this->states,
							'opendate' => $this->opendate,
							'closedate' => $this->closedate,
							'sitegroup' => $this->sitegroup,
							// 'opentime' => $this->opentime,
							'closetime' => $this->closetime 
					);
					
					$this->flag = $return;
				}
				
				$data_1 = array (
						'state_list' => $this->landingrate_model->getStateName () 
				);
				$this->flag ['location_view'] = $this->load->view ( 'treatment/location_view', $data_1, TRUE );
				$this->load->view ( 'service_requests/add_service_request', $this->flag );
			} else {
				
				$flag_1 = $this->service_requestmodel->addService_request ( $req );
				
				if (! empty ( $flag_1 ) && empty ( $req )) {
					$this->flag ['msg'] = "success";
					// echo $this->flag['msg'];
					// die;
					$this->load->view ( 'service_requests/add_service_request', $this->flag );
				} else if (! empty ( $flag_1 ) && ! empty ( $req )) {
					$this->flag ['msg'] = "update";
					// echo $this->flag['msg'];
					// die;
					$this->load->view ( 'service_requests/add_service_request', $this->flag );
				} else {
					$return = array (
							'unsuccess_msg' => "Something Went Wrong" 
					);
					
					if (! empty ( $this->flag )) {
						$this->flag = array_merge ( $this->flag, $return );
					} else {
						$return ['opendate'] = $this->opendate;
						$return ['closedate'] = "NULL";
						// $return['opentime'] = $this->opentime;
						$return ['closetime'] = "NULL";
						$this->flag = $return;
					}
					
					$data_1 = array (
							'state_list' => $this->landingrate_model->getStateName () 
					);
					$this->flag ['location_view'] = $this->load->view ( 'treatment/location_view', $data_1, TRUE );
					
					$this->load->view ( 'service_requests/add_service_request', $this->flag );
				}
			}
		}
		// $this->load->view('footer');
	}
	
	/**
	 * Function to show edit Service_request
	 */
	public function showeditservice_request() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get ( 'id', TRUE );
			if (empty ( $req )) {
				$url = $this->session->userdata ( 'url' );
				if (! empty ( $url )){
					redirect ( $url );
				}else{
					redirect ( base_url () . "service_request/getservice_request" );
				}
					
			}
			$this->showaddservice_request ( $req );
		}
	}
	
	/**
	 * Function to display List Of Service_requests
	 */
	public function getservice_request($grid = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$filter_date = $this->input->post ( 'filter_date' );
			$collieradmin_pendingassignment = 0;
			$msg = $this->input->get ( 'msg' );
			//if($this->session->userdata ( 'idlocation' ) == 36 && $this->session->userdata ( 'username' ) == 'collieradmin'){
			if($this->session->userdata ( 'idlocation' ) == 36){
				$myArray = explode('-', $grid);
				$iterator = 0;
				foreach ($myArray as $value){
					if($iterator == 1){
						$iterator = 2;
						if($value == 1)
							$collieradmin_pendingassignment = 1;
					}
					if($value == 'pendingassign')
						$iterator = 1;
				}
			}
			if(!$collieradmin_pendingassignment){
				$columns = array (
					0 => array (
							'name' => $this->lang->line('wrk_asgnmnts_wanum'),
							'db_name' => 'idservicerequest',
							'header' => $this->lang->line('wrk_asgnmnts_wanum'),
							'group' => 'Service',
							'required' => TRUE,
							'unique' => TRUE,
							'form_control' => 'text_long',
							'type' => 'string' 
					),
					 9 => array (
							'name' => $this->lang->line('whthr_snsr_site_nm'),
							'db_name' => 'sitename',
							'header' => $this->lang->line('whthr_snsr_site_nm'),
							'group' => 'Service',
							'required' => TRUE,
							'form_control' => 'text_long',
							'required' => TRUE 
					) ,
					
					1 => array (
							'name' => $this->lang->line('whthr_snsr_site_nm'),
							'db_name' => 'idsite',
							'header' => $this->lang->line('whthr_snsr_site_nm'),
							'group' => 'Service',
							'required' => TRUE,
							'unique' => TRUE,
							'form_control' => 'text_long',
							'ref_table_id_name' => 'idsite',
							'ref_table_db_name' => 'sites',
							'ref_field_db_name' => 'site',
							'form_control' => 'text_long',
							'type' => '1-n'
					)
					
					// 'type' => '1-n'
					,
					2 => array (
							'name' => $this->lang->line('wrk_asgnmnts_open_date'),
							'db_name' => 'opendate',
							'header' => $this->lang->line('wrk_asgnmnts_open_date'),
							'group' => 'Service',
							'required' => TRUE,
							'form_control' => 'text_long',
							'required' => TRUE 
					)
					// 'type' => '1-n'
					,
					3 => array (
							'name' => $this->lang->line('wrk_asgnmnts_close_date'),
							'db_name' => 'closedate',
							'header' => $this->lang->line('wrk_asgnmnts_close_date'),
							'group' => 'Service',
							'required' => TRUE,
							'form_control' => 'text_long',
							'required' => TRUE 
					)
					// 'type' => '1-n'
					,
					4 => array (
							'name' => $this->lang->line('prdct_ovrvw_nme'),
							'db_name_1' => 'firstname',
							'db_name_2' => 'lastname',
							'header' => $this->lang->line('wrk_asgnmnts_caller'),
							'group' => 'Service',
							'required' => TRUE,
							'form_control' => 'text_long',
							'type' => '1+2' 
					),
					5 => array (
							'name' => $this->lang->line('lrvl_srvlnc_addrs'),
							'db_name' => 'idsite',
							'header' => $this->lang->line('lrvl_srvlnc_addrs'),
							'group' => 'Service',
							'ref_table_id_name' => 'idsite',
							'ref_table_db_name' => 'sites',
							'ref_field_db_name' => 'address1',
							'ref_field_1_db_name' => 'address2',
							'ref_field_2_db_name' => 'city',
							'ref_table_1_id_name' => 'idstate',
							'ref_table_1_db_name' => 'states',
							'ref_field_1_1_db_name' => 'statename',
							'ref_field_type' => 'string',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-(1+2+3)-1-1' 
					),
					6 => array (
							'name' => $this->lang->line('site_mgmt_cty'),
							'db_name' => 'idsite',
							'header' => $this->lang->line('site_mgmt_cty'),
							'group' => 'Service',
							'ref_table_id_name' => 'idsite',
							'ref_table_db_name' => 'sites',
							'ref_field_db_name' => 'city',
							'ref_field_type' => 'string',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-n' 
					),
					7 => array (
							'name' => 'Dispostion',
							'db_name' => 'idservicerequest',
							'group' => 'Service',
							'ref_table_id_name' => 'idservicerequest',
							'ref_table_db_name' => 'servicerequestsdetail',
							'ref_table_1_id_name' => 'iddispositions',
							'ref_table_1_db_name' => 'dispositions',
							'ref_field_db_name' => 'disposition',
							'header' => $this->lang->line('wrk_asgnmnts_wanum_dspstns'),
							'required' => TRUE,
							'allow_sort' => FALSE,
							'form_control' => 'text_long',
							'type' => 'dispositionjoin' 
					),
					8 => array (
							'name' => $this->lang->line('adlt_trtmnt_applicator'),
							'db_name' => 'idapplicator',
							'header' => $this->lang->line('wrk_asgnmnts_assgndto'),
							'group' => 'Service',
							'ref_table_id_name' => 'iduser',
							'ref_table_db_name' => 'users',
							'ref_field_db_name' => 'firstname',
							'ref_field_2_db_name' => 'middlename',
							'ref_field_3_db_name' => 'lastname',
							'ref_field_type' => 'string',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-1+2+3' 
					) 
				)
				;
				
				$commands ['delete'] ['toolbar'] = FALSE;
				
				$params = array (
						'id' => 'idservicerequest',
						'table' => 'servicerequests',
						'url' => 'service_request/getservice_request',
						'uri_param' => $grid,
						'columns' => $columns,
						'order' => array (
								2 => 'desc' 
						),
						'filter_date' => ! empty ( $filter_date ) ? $filter_date : '2',
						'filters' => array (
								0 => array (
										'value' => $this->idlocation 
								) 
						),
						'columns_visible' => array (
								0,
								1,
								2,
								3,
								4,
								5,
								6,
								7,
								8 
						),
						'commands' => $commands,
						'ajax' => TRUE,
						'iscollieradmin' => FALSE,
						'msc_url' => array (
								'excel_url' => base_url () . 'service_request/toExcelAll',
								'pdf_url' => base_url () . 'service_request/toPdfAll',
								'add_url' => 'showaddservice_request' 
						),
						'ttlprs' => $this->ttlPendingRequests (),
						'city' => $this->service_requestmodel->getAllCity () 
				);
			}
			else{
				//open date, service requester name, service request address, service request comments
				$columns = array (
					0 => array (
							'name' => $this->lang->line('wrk_asgnmnts_wanum'),
							'db_name' => 'idservicerequest',
							'header' => $this->lang->line('wrk_asgnmnts_wanum'),
							'group' => 'Service',
							'required' => TRUE,
							'unique' => TRUE,
							'form_control' => 'text_long',
							'type' => 'string' 
					),
					1 => array (
							'name' => $this->lang->line('wrk_asgnmnts_open_date'),
							'db_name' => 'opendate',
							'header' => $this->lang->line('wrk_asgnmnts_open_date'),
							'group' => 'Service',
							'required' => TRUE,
							'form_control' => 'text_long',
							'required' => TRUE 
					)
					
					// 'type' => '1-n'
					,
					2 => array (
							'name' => $this->lang->line('prdct_ovrvw_nme'),
							'db_name_1' => 'firstname',
							'db_name_2' => 'lastname',
							'header' => $this->lang->line('ser_req_name'),
							'group' => 'Service',
							'required' => TRUE,
							'form_control' => 'text_long',
							'type' => '1+2' 
					),
					// IA
					3 => array (
							'name' => $this->lang->line('lrvl_srvlnc_addrs'),
							'db_name' => 'address',
							'header' => $this->lang->line('ser_req_add'),
							'group' => 'Service',
							'ref_field_type' => 'string',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-(1+2+3)-1-1-PWA-CA' 
					),
					// IA
					4 => array (
							'name' => $this->lang->line('ser_req_ca_pwa_technician'),
							'db_name' => 'description',
							'header' => $this->lang->line('ser_req_ca_pwa_technician'),
							'group' => 'Service',
							'ref_field_type' => 'string',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-(1+2+3)-1-1-PWA-CA-COMM' 
					)  
				)
				;
				
				$commands ['delete'] ['toolbar'] = FALSE;
				
				$params = array (
						'id' => 'idservicerequest',
						'table' => 'servicerequests',
						'url' => 'service_request/getservice_request',
						'uri_param' => $grid,
						'columns' => $columns,
						'order' => array (
								2 => 'desc' 
						),
						'filter_date' => ! empty ( $filter_date ) ? $filter_date : '2',
						'filters' => array (
								0 => array (
										'value' => $this->idlocation 
								) 
						),
						'columns_visible' => array (
								0,
								1,
								2,
								3,
								4
						),
						'commands' => $commands,
						'ajax' => TRUE,
						'iscollieradmin' => TRUE,
						'msc_url' => array (
								'excel_url' => base_url () . 'service_request/toExcelAll',
								'pdf_url' => base_url () . 'service_request/toPdfAll',
								'add_url' => 'showaddservice_request' 
						),
						'ttlprs' => $this->ttlPendingRequests (),
						'city' => $this->service_requestmodel->getAllCity () 
				);
			}
			
			
			$newdata = array ();
			if (! empty ( $grid )) {
				$newdata = array (
						'url' => base_url () . $params ['url'] . '#' . $params ['id'] . '=' . $grid 
				);
			} else {
				$newdata = array (
						'url' => base_url () . $params ['url'] 
				);
			}
			
			$this->session->set_userdata ( $newdata );
			
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_wrk_asgnmnt'),
                    'page' => "service_request" 
			);
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			// Pass grid to the view
            $data = (object)array();
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			$data->msg = $msg;
			$data->ttlprs = $this->ttlPendingRequests ();
			$data->mapdata = base_url () . "service_request/showmap";
			// echo $grid->filter_pendingassign_string;
			$this->load->view ( 'service_requests/service_requests', $data );

		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to display Map
	 */
	public function showmap() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data = $this->service_requestmodel->getMapdata ();
			$query ['data'] = ! empty ( $data ['result'] ) ? $data ['result'] : '';
			$query ['user_loc'] = $this->adultsurveillance_model->getUserLoc ();
			$query ['zone_loc'] = $this->zone_model->getZoneCord ();
			$query ['googlezoom'] = $this->session->userdata ( 'googlezoom' );
			$this->load->view ( 'service_requests/map_view', $query );
		}
	}
	
	/**
	 * Function to calculate total
	 * pending SRs
	 */
	public function ttlPendingRequests() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$ttlsrs = $this->service_requestmodel->getTotalPendingRequests ();
			return $ttlsrs;
		}
	}
	
	/**
	 * Function to delete Service Request
	 */
	public function deleteservice() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get ( 'id', TRUE );
			$del = $this->input->get ( 'flag', TRUE );
			$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
			
			if (empty ( $req )) {
				if (! empty ( $seturl [1] ))
					redirect ( $seturl [0] . "#" . $seturl [1] );
				else
					redirect ( $seturl [0] );
			}
			// redirect(base_url()."service_request/getservice_request");
			$flag_1 = $this->service_requestmodel->deleteService ( $req, $del );
			
			if ($flag_1)
				$msg = "delete";
			else
				$msg = "error";
			
			if (! empty ( $seturl [1] ))
				redirect ( $seturl [0] . "?msg=" . $msg . "#" . $seturl [1] );
			else
				redirect ( $seturl [0] . "?msg=" . $msg );
			
			// redirect(base_url()."service_request/getservice_request?msg=delete");
		}
	}
	
	/**
	 * Function to show Close Date POPUP
	 */
	public function showclosebox() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get ( 'data', TRUE );
			$arrids = json_decode ( base64_decode ( $req ) );
			// print'<pre>';
			// print_r($arrids);
			// die;
			if (empty ( $req ))
				redirect ( base_url () . "service_request/getservice_request?msg=error" );
			
			$data ['arrids'] = $req;
			$isCollierAdmin = 0;
			//if($this->session->userdata ( 'idlocation' ) == 36 && $this->session->userdata ( 'username' ) == 'collieradmin'){
			if($this->session->userdata ( 'idlocation' ) == 36){
				$isCollierAdmin = 1;
			}
			$data ['isCollierAdmin'] = $isCollierAdmin;
			$this->load->view ( 'service_requests/closedate_view', $data );
		}
	}
	
	/**
	 * Function to fetch City List
	 */
	public function getCityList() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$result = array ();
			$char = $this->input->get ( 'chars' );
			
			if (empty ( $char )) {
				echo json_encode ( $result );
				exit ();
			} else {
				$result = $this->service_requestmodel->getCityList ( $char );
				
				if (empty ( $data )) {
					echo json_encode ( $result );
					exit ();
				} else {
					echo json_encode ( $result );
					exit ();
				}
			}
		}
	}
	
	/**
	 * Function to Close Work Assignments Date
	 */
	public function closeservice_request() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->post ( 'arrids' );
			$closedate = $this->input->post ( 'closedate' );
			$closetime = $this->input->post ( 'closetime' );
			
			$data ['arrids'] = $req;
			$date ['closedate'] = $closedate;
			$date ['closetime'] = $closetime;
			
			if (empty ( $req ))
				$this->load->view ( 'service_requests/closedate_view', $data );
			
			$flag_1 = $this->service_requestmodel->closeService ();
			
			if (! $flag_1)
				$this->load->view ( 'service_requests/closedate_view', $data );
			
			$this->load->view ( 'service_requests/closedate_view', array (
					'msg' => 'closed',
					'seturl' => explode ( "#", $this->session->userdata ( 'url' ) ) 
			) );
		}
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function toExcelAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$query ['data'] = $this->service_requestmodel->listServiceRequest ();
			
			// print'<pre>';
			// print_r($query['data']);
			// die;
			
			$this->load->view ( 'service_requests/excel_view', $query );
		}
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->helper ( 'pdf_helper' ); // Load helper
			$query ['data'] = $this->service_requestmodel->listServiceRequest ();
			
			$data = $this->load->view ( 'service_requests/pdf_view', $query, true );
			/*
			 * print'<pre>';
			 * print_r($data);
			 * die;
			 */
			// $data = file_get_contents(htmlentities($dd)); // Pass the url of html report
			
			create_pdf_l ( $data, $this->lang->line('sidebar_data_entry_wrk_asgnmnts') ); // Create pdf
		}
	}
	
	/**
	 * Function to read data submitted from
	 * Sutter Yuba website
	 */
	public function saveServiceRequestData() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->service_requestmodel->saveServiceRequestData ();
			$data = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'page' => "service_request",
					'title' => $this->lang->line('sidebar_wrk_asgnmnt') 
			);
			// $this->load->view('header',$data);
			// $this->load->view('left_sidebar',$data);
			if ($flag)
				$data ['msg'] = "success";
			else
				$data ['msg'] = "error";
			
			$this->load->view ( 'service_requests/pending_service_requests', $data );
			// $this->load->view('footer');
		}
	}
	
	/**
	 * Function to Show Add Service_request Form
	 */
	public function showPendingServiceRequestData($id = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_data_entry_wrk_asgnmnts'),
					'page' => "service_request" 
			);
			$this->load->view ( 'service_requests/pending_service_requests', $this->flag );
		}
	}
    
    /**
	 * Function to fetch all site data based on module
     * for Map Summary
	 */
	public function getAllEventsData($idsite = "") {
        $params = array (
            'idsite' => $idsite,
            'idlocation' => $this->session->userdata('idlocation')
        );
        
        $this->load->library ( 'common', $params );
        
        $response = $this->common->getAllEventsData ();
        //print'<pre>';
//        print_r($response);
//        die;
        return $response;
    }

	/**
	 * This function is a demo to Show Service Request Form
	 * filled from Third party
	 */
	public function showServiceRequestAddedFromThirdParty($id = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->view ( 'service_requests/service_requests_third_party' );
		}
	}
}

/* End of file service_request.php */
/* Location: ./application/controllers/service_request.php */