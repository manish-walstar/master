<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Map_management extends CI_Controller {
	
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
        
		$this->load->helper('language');
        
		$this->load->model ( 'mapmanagement_model' );
		$this->load->model ( 'adultsurveillance_model' );
		$this->load->model ( 'larvalsurveillance_model' );
		$this->load->model ( 'treatment_model' );
		$this->load->model ( 'service_requestmodel' );
        $this->load->model ( 'site_model' );
        $this->load->model ( 'zone_model' );
        $this->load->model ( 'preference_model' );
        $this->load->model ( 'carbo_model' );
        $this->load->model ( 'common_model' );
        
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
        $this->columns = array (
    			0 => array (
    					'name' => $this->lang->line('whthr_snsr_site'),
    					'db_name' => 'site',
    					'header' => $this->lang->line('whthr_snsr_site'),
    					'group' => $this->lang->line('cmn_lbl_map'),
    					'required' => TRUE,
    					'unique' => TRUE,
    					'form_control' => 'text_long',
    					'type' => 'u' 
    			),
    			1 => array (
    					'name' => $this->lang->line('prdct_ovrvw_type'),
    					'db_name' => 'type',
    					'header' => $this->lang->line('prdct_ovrvw_type'),
    					'group' => $this->lang->line('cmn_lbl_map'),
    					'required' => TRUE,
    					'form_control' => 'text_long',
    					'type' => 'u' 
    			),
    			2 => array (
    					'name' => $this->lang->line('lrvl_srvlnc_addrs'),
    					'db_name' => 'addrs',
    					'header' => $this->lang->line('lrvl_srvlnc_addrs'),
    					'group' => $this->lang->line('cmn_lbl_map'),
    					'required' => TRUE,
    					'form_control' => 'text_long',
    					'type' => 'u' 
    			),
                3 => array (
    					'name' => $this->lang->line('lrvl_trtmnt_date'),
    					'db_name' => 'eventdate',
    					'header' => $this->lang->line('lrvl_trtmnt_date'),
    					'group' => $this->lang->line('cmn_lbl_map'),
    					'required' => TRUE,
    					'type' => 'u' 
    			),
    			4 => array (
    					'name' => "Module",
    					'db_name' => 'module',
    					'header' => "Module",
    					'group' => $this->lang->line('cmn_lbl_map'),
    					'required' => TRUE,
    					'form_control' => 'text_long',
    					'type' => 'u' 
    			)
    	);
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			redirect ( base_url () . "map_management/getmapsummary" );
		}
	}
	
	/**
	 * Function to display List Of Monitor management
	 */
	public function getmapsummary($grid = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$filter_date = $this->input->post ( 'filter_date' );
			
			$commands ['delete'] ['toolbar'] = FALSE;
			$add_view = $this->load->view ( 'map_management/map_summary', '', true );
			
			$params = array (
					'id' => 'idadultsurveillance',
					'table' => 'adultsurveillance',
					'url' => 'map_management/getmapsummary',
					'table1' => 'adultsurveillance',
					'uri_param' => $grid,
					'columns' => $this->columns,
					'multiple' => 'map',
					'order' => array (
							1 => 'desc' 
					),
					'filters' => array (
							0 => array (
									'value' => $this->session->userdata ( 'idlocation' ) 
							) 
					),
					'filter_date' => ! empty ( $filter_date ) ? $filter_date : '',
					'columns_visible' => array (
							0,
							1,
							2,
							3 
					),
					'commands' => $commands,
					'ajax' => TRUE,
					'msc_url' => array (
							'excel_url' => base_url () . 'map_management/toExcelAll',
							'pdf_url' => base_url () . 'map_management/toPdfAll',
							'text' => 'MapManagement' 
					),
					'add_view' => $add_view 
			);
			
			$newdata = array (
					'url' => base_url () . $params ['url'] . '#' . $params ['id'] . '=' . $grid 
			);
			
			$this->session->set_userdata ( $newdata );
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_data_entry_map_smmry'),
					'page' => 'map_management',
                    'app_lang' => $this->app_lang 
			);
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			// Pass grid to the view
            $data = (object)array();
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			$data->mapdata = base_url () . "map_management/showmap?filter_date=" . ($filter_date ? $filter_date : '2') . "&page_size=10&page=1&orderby=1:DESC";
			$this->load->view ( 'map_management/map_summary', $data );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function toExcelAll() {
        $query = array();
        $query['data'] = $this->getReportData ('Excel');
        $query['data'] = $query['data']['result'];
		$this->load->view ( 'map_management/excel_view', $query );
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
        $this->load->helper ( 'pdf_helper' ); // Load helper
        $query = array();
        $query['data'] = $this->getReportData ('PDF');
        $query['data'] = $query['data']['result'];
        $data = $this->load->view ( 'map_management/pdf_view', $query, true );
		
		// $data = file_get_contents("$data"); // Pass the url of html report
		create_pdf ( $data, str_Replace(' ', '', $this->lang->line('sidebar_data_entry_map_smmry')) ); // Create pdf
	}
    
    public function getReportData($is_pdf="") {
        $allSites = $this->input->get_post('allSites');
        $selectedType = $this->input->get_post('selectedType');
        $filterDate = $this->input->get_post('filterDate');
        $site = $this->input->get_post('site');
        $filter_date = $this->input->get_post('filter_date');
        $frmdate = $this->input->get_post('frmdate');
        $todate = $this->input->get_post('todate');
        $page = $this->input->get_post('page');
        $page_size = $this->input->get_post('page_size');
        $filter_type = $this->input->get ( 'type' );
        $orderbystring = $this->input->get ( 'orderby' );
        
        $frmdate = !empty($frmdate) ? substr($frmdate,0,2) . '/' . substr($frmdate,2,2) . '/' . substr($frmdate,4,4): '';
        $todate = !empty($todate) ? substr($todate,0,2) . '/' . substr($todate,2,2) . '/' . substr($todate,4,4): '';
        $filter_daterange = array($frmdate, $todate);
        
        $orderby = $this->common_model->getOrderBy($orderbystring);
        
        $page_size = ($page_size == 'all') ? 'all' : (is_numeric($page_size) ? $page_size : 10);
        $limit = (is_numeric($page_size)) ? $page_size : NULL;        
        $offset = $limit * ($page - 1);
        
        $filters = array (
            array (
                'value' => $this->session->userdata('idlocation')
			)
        );
        
        // echo "<br/>is_pdf:  $is_pdf";
        // echo "<br/>allSites:  $allSites";
        // echo "<br/>selectedType:  $selectedType";
        // echo "<br/>filterDate:  $filterDate";
        $result = array();
        if(!empty($is_pdf))
        {
           /* if($allSites)
            {
                $result['result'] = $this->carbo_model->get_items_map ('adultsurveillance', 'idadultsurveillance', $this->columns, '', $filters, '', $offset, $orderby, '', !empty($filterDate)?$filterDate:$filter_date, $filter_daterange,      $selectedType      , '','', '', '', 'dataForPDF_allSites'); 
                // getting all events neglecting pin types 
            }
            else
            {*/
                $result['result'] = $this->carbo_model->get_items_map ('adultsurveillance', 'idadultsurveillance', $this->columns, '', $filters, $limit, $offset, $orderby, '', !empty($filterDate)?$filterDate:$filter_date, $filter_daterange, $selectedType, '','', 'event', 'dataForPDF'); 
                // getting data for pdf with specific pin type
           // }
        }
        else
        {
            $result['result'] = $this->carbo_model->get_items_map ('adultsurveillance', 'idadultsurveillance', $this->columns, '', $filters, $limit, $offset, $orderby, '', $filter_date, $filter_daterange, $filter_type , '','', 'event',   ''); // getting events
        }
         //echo "<pre>";
         //print_r($result['result']);
        // die;
        $result['filter_date'] = $filter_date;
        $result['filter_daterange'] = $filter_daterange;
        $result['page'] = $page;
        $result['page_size'] = $page_size;
        $result['orderby'] = $orderbystring;
        
        return $result;
        
    }
	
	/**
	 * Function to Show Map
	 */
	public function showmap() {
        $reportData = $this->getReportData ();
        $query = $this->mapmanagement_model->getMapData ($reportData);
        
		$query ['googlezoom'] = $this->session->userdata ( 'googlezoom' );
		$query ['prefData'] = $this->preference_model->getPreferencesData ();
		$query ['user_loc'] = $this->adultsurveillance_model->getUserLoc ();
             
		$treatment = $this->treatment_model->getMapData ();
		$query ['treatment'] = !empty($treatment) && isset($treatment ['result']) ? $treatment ['result'] : array();
        
		/** 
         * On clicking AllSite or selecting a site from Search Site 
         * a param is added 'allsite' based on which
         * respective sites are fetched and pupulated
         * In case of All Sites: All Sites are fetched
         * In case of Search Site: Respective site is fetched
         * 
        */
        $allsite = $this->input->get('allsite');
        $site = $this->input->get('site');
        $allEvents = $this->getAllEvents();
        if(!empty($allsite)){
            $allsiteData = $this->site_model->getAllSiteData ();
        } else if(!empty($site)){
            $allsiteData = $this->site_model->getAllSiteData ($site);            
        }
        
        $allsiteData = $this->getEventCountInSite ($allsiteData, $allEvents);
        $query ['allsite'] = $allsiteData;
        
        $filter_type = $this->input->get ( 'type' );
        $query ['filter_type'] = $filter_type;
        
        $query ['zone_loc'] = $this->zone_model->getZoneCord ();
        $query ['idlocation'] = $this->session->userdata ( 'idlocation' );
        $this->load->view ( 'map_management/map_view', $query );
	}
    
    /**
	 * Function to count how many Event Occured in each Site
	 */
	public function getEventCountInSite($siteArr = "", $eventArr = "") {
        if(empty($siteArr) || empty($eventArr)){
            return array();
        }
        //For Testng
        //$siteArr = array($siteArr['121']);
        array_walk($eventArr, function(&$val, $key){$val=array_count_values($val);});
        
        $eventCount = array();
        $getCountPerEvent = function(&$val,$key,&$idsite) use(&$eventCount){
            //echo "<br> This is Val<br>";
//            print'<pre>';
//            print_r($val);
            $eventCount[$key] = 0;
            //echo "<br> 1. This is eventCount<br>";
//            print_r($eventCount);
            if(!empty($val)){
                foreach($val as $subKey => $subVal){
                    if($subKey == $idsite){
                        $eventCount[$key] +=  $subVal;
                        //echo "<br> 2. This is eventCount<br>";
//                        print_r($eventCount);
                        break;
                    }
                }
            }
        };
        $siteFinalArr = array();
        foreach($siteArr as $ksite => $vsite){
            array_walk($eventArr, $getCountPerEvent, $vsite['idsite']);
            $vsite['adlttrtmnt'] = !empty($eventCount) && isset($eventCount['adlttrtmnt']) ? $eventCount['adlttrtmnt'] : 0;
            $vsite['lrvltrtmnt'] = !empty($eventCount) && isset($eventCount['lrvltrtmnt']) ? $eventCount['lrvltrtmnt'] : 0;
            $vsite['adultsurveillance'] = !empty($eventCount) && isset($eventCount['adultsurveillance']) ? $eventCount['adultsurveillance'] : 0;
            $vsite['larvalsurveillance'] = !empty($eventCount) && isset($eventCount['larvalsurveillance']) ? $eventCount['larvalsurveillance'] : 0;
            $vsite['landingrates'] = !empty($eventCount) && isset($eventCount['landingrates']) ? $eventCount['landingrates'] : 0;
            $vsite['rainfall'] = !empty($eventCount) && isset($eventCount['rainfall']) ? $eventCount['rainfall'] : 0;
            $vsite['workassgnmnts'] = !empty($eventCount) && isset($eventCount['workassgnmnts']) ? $eventCount['workassgnmnts'] : 0;
            $vsite['arboviral'] = !empty($eventCount) && isset($eventCount['arboviral']) ? $eventCount['arboviral'] : 0;
            $vsite['corvid'] = !empty($eventCount) && isset($eventCount['corvid']) ? $eventCount['corvid'] : 0;
            $vsite['sentinellab'] = !empty($eventCount) && isset($eventCount['sentinellab']) ? $eventCount['sentinellab'] : 0;
            $siteFinalArr[$ksite] = $vsite;
        }
        
        return $siteFinalArr;
    }
    
    /**
	 * Function to fetch site based on module
	 */
	public function getEventData() {
        $params = $this->setParams();
        
        $this->load->library ( 'common', $params );
        $response = $this->common->getEventData ();
        
        echo json_encode($response);
        die;
    }
    
    /**
	 * Function to fetch all events
	 */
	public function getAllEvents() {
        $data = array();
        $data['adlttrtmnt'] = array();
        $data['lrvltrtmnt'] = array();
        $data['adultsurveillance'] = array();
        $data['larvalsurveillance'] = array();
        $data['workassgnmnts'] = array();
        $data['landingrates'] = array();
        $data['rainfall'] = array();
        $data['arboviral'] = array();
        $data['corvid'] = array();
        $data['sentinellab'] = array();
        
        $params = $this->setParams();
        
        $this->load->library ( 'common', $params );
        $result = $this->common->getAllEvents ();
        
        if(!empty($result))
		foreach ( $result as $key => $val ) {
            switch($val->module){
                case 'adlttrtmnt':
                    array_push($data['adlttrtmnt'], $val->idsite);
                    break;
                case 'lrvltrtmnt':
                    array_push($data['lrvltrtmnt'], $val->idsite);
                    break;
                case 'adultsurveillance':
                    array_push($data['adultsurveillance'], $val->idsite);
                    break;
                case 'larvalsurveillance':
                    array_push($data['larvalsurveillance'], $val->idsite);
                    break;
                case 'landingrates':
                    array_push($data['landingrates'], $val->idsite);
                    break;
                case 'rainfall':
                    array_push($data['rainfall'], $val->idsite);
                    break;
                case 'workassgnmnts':
                    array_push($data['workassgnmnts'], $val->idsite);
                    break;
                case 'arboviral':
                    array_push($data['arboviral'], $val->idsite);
                    break;
                case 'corvid':
                    array_push($data['corvid'], $val->idsite);
                    break;
                case 'sentinellab':
                    array_push($data['sentinellab'], $val->idsite);
                    break;
            }
        }
        return $data;
    }
    
    public function setParams() {
        $moduleNum = $this->input->get_post('moduleNum');
        $idsite = $this->input->get_post('idsite');
        $idlocation = $this->input->get_post('idlocation');
        $filter_date = $this->input->get_post('filter_date');
        $filter_daterange = $this->input->get_post('filter_daterange');
        $page = $this->input->get_post('page');
        $page_size = $this->input->get_post('page_size');
        $orderby = $this->input->get_post('orderby');
        
        $idlocation = $idlocation ? $idlocation : $this->session->userdata('idlocation');
        $orderby = $this->mapmanagement_model->getOrderBy($orderby);
        
        $params = array (
			'moduleNum' => $moduleNum,
            'idsite' => $idsite,
            'idlocation' => $idlocation,
            'filter_date' => $filter_date,
            'filter_daterange' => $filter_daterange,
            'page' => $page,
            'page_size' => $page_size,
            'orderby' => $orderby
        );
        
        return $params;
    }
    
}

