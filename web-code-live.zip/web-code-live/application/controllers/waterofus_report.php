<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Waterofus_report extends CI_Controller {
	public $product_list;
	public $startdate;
	public $enddate;
	public $month_yearofuse;
	public $location_data;
	public $atvalues;
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		
        $this->load->helper('language');
		$this->load->model ( 'waterofus_report_model' );
		$this->load->model ( 'usermodel' );
		
		$this->usermodel->set_access_session ();
		
		if (! $this->usermodel->user_access ( 'reports' ) && ! $this->usermodel->user_access ( 'company_admin' ))
			redirect ( base_url () );
		
		$id = $this->session->userdata ( 'id' );
		$id_arr = explode ( "_", json_decode ( base64_decode ( $id ) ) );
		
		$id = json_decode ( base64_decode ( $id_arr [0] ) );
		
		$this->userinfo = $this->usermodel->getUserData ( $id );
		
		$middlename = " ";
		if (isset ( $this->userinfo ['middlename'] ))
			$middlename = ! empty ( $this->userinfo ['middlename'] ) ? " " . $this->userinfo ['middlename'] . " " : " ";
		
		if (isset ( $this->userinfo ['firstname'] ) || isset ( $this->userinfo ['lastname'] ))
			$this->inspector = $this->userinfo ['firstname'] . $middlename . $this->userinfo ['lastname'];
		
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		$this->enddate = date ( 'm/d/Y' );
		$this->startdate = date ( 'm/d/Y', strtotime ( "-30 day" ) );
		$this->month_yearofuse = date ( 'M' ) . " " . date ( 'Y' );
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			redirect ( base_url () . "waterofus_report/getwaterofus_report" );
		}
	}
	
	/**
	 * Function to fetch All Waterofus
	 * in current daterange
	 */
	public function getwaterofus_report() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			
			$data_1 = array ();
			if (empty ( $startdate ) || empty ( $enddate )) {
				$data = $this->waterofus_report_model->getWaterofus ( $this->startdate, $this->enddate );
				$data_1 = array (
						'username' => $this->session->userdata ( 'username' ),
						'logstatus' => "logout",
						'title' => $this->lang->line('sidebar_rprtng_plus_wofus_rprt'),
						'page' => "waterofus_report",
						'startdate' => $this->startdate,
						'enddate' => $this->enddate,
						'month_yearofuse' => $this->month_yearofuse,
						'data' => $data,
						 'app_lang' => $this->app_lang
						
				);
			} else {
				if (! empty ( $startdate ) && ! empty ( $enddate )) {
					$startdate_arr = explode ( "/", $startdate );
					$enddate_arr = explode ( "/", $enddate );
					$this->startdate = $startdate;
					$this->enddate = $enddate;
					$this->month_yearofuse = ! empty ( $startdate ) ? date ( 'M', strtotime ( $startdate_arr [2] . "-" . $startdate_arr [0] . "-" . $startdate_arr [1] ) ) . " " . date ( 'Y', strtotime ( $enddate_arr [2] . "-" . $enddate_arr [0] . "-" . $enddate_arr [1] ) ) : '';
				}
				
				$id = $this->session->userdata ( 'id' );
				$id_arr = explode ( "_", json_decode ( base64_decode ( $id ) ) );
				$id = json_decode ( base64_decode ( $id_arr [0] ) );
				$this->userinfo = $this->usermodel->getUserData ( $id );
				
				$middlename = " ";
				if (isset ( $this->userinfo ['middlename'] ))
					$middlename = ! empty ( $this->userinfo ['middlename'] ) ? " " . $this->userinfo ['middlename'] . " " : " ";
				
				if (isset ( $this->userinfo ['firstname'] ) || isset ( $this->userinfo ['lastname'] ))
					$this->inspector = $this->userinfo ['firstname'] . $middlename . $this->userinfo ['lastname'];
				
				$data = $this->waterofus_report_model->getWaterofus ( $this->startdate, $this->enddate );
				$data_1 = array (
						'username' => $this->session->userdata ( 'username' ),
						'logstatus' => "logout",
						'title' => $this->lang->line('sidebar_rprtng_plus_wofus_rprt'),
						'page' => "waterofus_report",
						'startdate' => $this->startdate,
						'enddate' => $this->enddate,
						'month_yearofuse' => $this->month_yearofuse,
						'data' => $data,
						 'app_lang' => $this->app_lang
				);
			}
			
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			$this->load->view ( 'waterofus_reports/waterofus_reports', $data_1 );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to fetch the data
	 * and format it in order to return
	 */
	public function exportView() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			
			if (! empty ( $startdate ) && ! empty ( $enddate )) {
				$this->startdate = $startdate;
				$this->enddate = $enddate;
			}
			
			$data = $this->waterofus_report_model->getWaterofus ( $this->startdate, $this->enddate );
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('pstcde_usg_hdng'),
					'page' => "waterofus_report",
					'startdate' => $this->startdate,
					'enddate' => $this->enddate,
					'month_yearofuse' => $this->month_yearofuse,
					'data' => $data,
					 'app_lang' => $this->app_lang
			);
			$data = $this->load->view ( 'waterofus_reports/pdf_view', $data_1, TRUE );
			return $data;
		}
	}
	
	/**
	 * Function to convert data into PDF
	 */
	public function toPDFAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->helper ( 'pdf_helper' );
			
			$data = $this->exportView ();
			// print'<pre>';
			// print_r($data);
			// die;
			
			create_pdf_l ( $data, "WaterOfUsReport" );
		}
	}
	
	/**
	 * Function to convert data into Excel
	 */
	public function toEXCELAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$data = $this->exportView ();
			// print'<pre>';
			// print_r($data);
			// die;
			header ( "Content-type: application/octet-stream" );
			header ( "Content-Disposition: attachment; filename=WatersOftheUsReport.xls" );
			header ( "Pragma: no-cache" );
			header ( "Expires: 0" );
			
			echo $data;
			exit ();
		}
	}
}

/* End of file waterofus_report.php */
/* Location: ./application/controllers/waterofus_report.php */