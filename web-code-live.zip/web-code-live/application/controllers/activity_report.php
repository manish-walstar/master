<?php
ini_set('error_reporting', E_ALL);
ini_set('display_errors',1);
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
	 error_reporting(0);
date_default_timezone_set ( 'UTC' );
class Activity_report extends CI_Controller {
	public $products;
	public $activity_report;
	public $product_list;
	public $startdate;
	public $starttime;
	public $enddate;
	public $endtime;
	public $inspector;
	public $currentdate;
	public $currenttime;
	public $endtimestamp;
	public $starttimestamp;
	public $userinfo;
	public $zones;
	public $zone = "";
	public $sites;
	public $site = "";
	public $states;
	public $state = "";
    public $app_lang;
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		$this->load->helper('language');
		$this->load->model ( 'activity_report_model' );
		$this->load->model ( 'site_model' );
		$this->currentdate = date ( 'm/d/Y' );
		$this->currenttime = date ( "H:i:s a" );
		
		$this->load->model ( 'usermodel' );
		$this->usermodel->set_access_session ();
		
		if (! $this->usermodel->user_access ( 'reports' ) && ! $this->usermodel->user_access ( 'company_admin' ))
			redirect ( base_url () );
		
		$this->enddate = date ( 'm/d/Y' );
		$this->endtime = date ( 'H:i:s' );
		
		$this->startdate = date ( 'm/d/Y', strtotime ( "-10 day" ) );
		$this->starttime = date ( 'H:i:s' );
		
		$this->endtimestamp = strtotime ( date ( 'm/d/Y H:i:s' ) );
		
		$this->starttimestamp = strtotime ( date ( 'm/d/Y H:i:s', strtotime ( "-10 day" ) ) );
		
		if ($this->session->userdata ( 'id' )) {
			// echo $this->session->userdata('id');
			// die;
			// $this->activity_report = $this->activity_report_model->getActivity($this->startdate,$this->enddate);
			// print('<pre>');
			// print_r($this->activity_report);
			// die;
			$id = $this->session->userdata ( 'id' );
			// echo $id;
			// die;
			$id_arr = explode ( "_", json_decode ( base64_decode ( $id ) ) );
			
			$id = json_decode ( base64_decode ( $id_arr [0] ) );
			
			$this->userinfo = $this->usermodel->getUserData ( $id );
			// echo "<pre>";
			// print_r($this->userinfo);
			// die;
			
			$middlename = " ";
			if (isset ( $this->userinfo ['middlename'] ))
				$middlename = ! empty ( $this->userinfo ['middlename'] ) ? " " . $this->userinfo ['middlename'] . " " : " ";
			
			if (isset ( $this->userinfo ['firstname'] ) || isset ( $this->userinfo ['lastname'] ))
				$this->inspector = $this->userinfo ['firstname'] . $middlename . $this->userinfo ['lastname'];
			$this->zones = $this->site_model->getZones ();
			$this->sites = $this->site_model->getSelectedExistingSite ();
			$this->states = $this->site_model->getStatesList ();
		}
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			redirect ( base_url () . "activity_report/getresult" );
		}
	}
	
	/**
	 * Function to fetch the data
	 * and format it in order to return
	 */
	public function exportView() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			$this->zones = $this->site_model->getZones ();
			$this->sites = $this->site_model->getSelectedExistingSite ();
			$this->states = $this->site_model->getStatesList ();
			$zone_radio = 0;
			$state_radio = 0;
			$site_radio = 0;
			if (empty ( $startdate ) && empty ( $enddate )) {
				$startdate = $this->startdate;
				$enddate = $this->enddate;
			} else {
				$this->startdate = $startdate;
				$this->enddate = $enddate;
			}
			
			$this->activity_report = $this->activity_report_model->getActivity ( $startdate, $enddate );
			$report = $this->activity_report;
			
			// echo "<pre>";
			// print_r($report);
			// die;
			
			$state_ckeck = $this->input->post ( 'state_hid' );
			$site_check = $this->input->post ( 'site_hid' );
			$zone_check = $this->input->post ( 'zone_hid' );
			$miles = "";
			$add1 = "";
			$add2 = "";
			if (! empty ( $site_check ) && $site_check == 'no') {
				$site_radio = 1;
				$this->site = $this->input->post ( 'site' );
				$this->sites = $this->site_model->getSelectedExistingSite ( $this->site );
				$map_view = 1;
				$miles = $this->input->post ( 'text_site' );
				$site_temp = $this->input->post ( 'site' );
				// echo $site_temp;
				// die;
				
				$temp_laglng = $this->activity_report_model->getLatLongSite ( $site_temp );
				// echo "<pre>";
				// print_r($temp_laglng);
				// die;
				// $temp_laglng = $this->activity_report_model->getLatLong($site_temp);
				
				$final = array ();
				$return_data = '';
				$map_final = array ();
				if (count ( $report ['adult'] ) > 0) {
					$adult_inner = array ();
					$i = 0;
					
					// echo "<pre>";
					// print_r($report['larval_inspection']);
					// die;
					//
					foreach ( $report ['adult'] as $row ) {
						
						if (! empty ( $row ['location'] )) {
							$temp11 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp11 [0] ) ? $temp11 [0] : '';
							$t2 = ! empty ( $temp11 [1] ) ? $temp11 [1] : '';
							$result = $this->activity_report_model->is_within_10_miles ( $t1, $t2, $temp_laglng ['lat'], $temp_laglng ['long'], $miles );
							if ($result == 1) {
								// print_r($report['adult']);
								$final ['adult'] [] = $row;
								// print_r($row);
								// //$adult_inner[$i]['lat'] = $temp[0];
								// $adult_inner[$i]['lng'] = $temp[1];
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
							$i ++;
						}
					}
					// echo "<pre>";
					// print_r($return_data);
					// die;
					
					$map_final [] = $adult_inner;
				}
				
				if (count ( $report ['larveltrtment'] ) > 0) {
					$larveltrtment_inner = array ();
					$i = 0;
					
					$temp1 = array ();
					foreach ( $report ['larveltrtment'] as $row ) {
						if (! empty ( $row ['location'] )) {
							$temp1 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp1 [0] ) ? $temp1 [0] : '';
							$t2 = ! empty ( $temp1 [1] ) ? $temp1 [1] : '';
							// echo $t1." ".$t2."<br>" .$getlat." ".$getlong."<br>";
							// die;
							$result = $this->activity_report_model->is_within_10_miles ( $t1, $t2, $temp_laglng ['lat'], $temp_laglng ['long'], $miles );
							// echo $result.'<br />';
							// die;
							if ($result == 1) {
								$final ['larveltrtment'] [] = $row;
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
							$i ++;
						}
					}
					
					$map_final [] = $larveltrtment_inner;
				}
				
				if (count ( $report ['larvel'] ) > 0) {
					$larvel_inner = array ();
					$i = 0;
					
					foreach ( $report ['larvel'] as $row ) {
						if (! empty ( $row ['location'] )) {
							$temp22 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp22 [0] ) ? $temp22 [0] : '';
							$t2 = ! empty ( $temp22 [1] ) ? $temp22 [1] : '';
							$result = $this->activity_report_model->is_within_10_miles ( $t1, $t2, $temp_laglng ['lat'], $temp_laglng ['long'], $miles );
							if ($result == 1) {
								// print_r($report['larvel']);
								$final ['larvel'] [] = $row;
								// echo $temp[0].' %'.$temp[1];
								// $larvel_inner[$i]['lat'] = $temp[0];
								// $larvel_inner[$i]['lng'] = $temp[1];
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
						}
					}
					$map_final [] = $larvel_inner;
					// echo "<pre>";
					// print_r($map_final);
					// die;
				}
				
				// print_r($final['larvel']);
				if (count ( $report ['lab'] ) > 0) {
					$lab_inner = array ();
					foreach ( $report ['lab'] as $row ) {
						
						if (! empty ( $row ['location'] )) {
							
							$temp33 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp33 [0] ) ? $temp33 [0] : '';
							$t2 = ! empty ( $temp33 [1] ) ? $temp33 [1] : '';
							$result = $this->activity_report_model->is_within_10_miles ( $t1, $t2, $temp_laglng ['lat'], $temp_laglng ['long'], $miles );
							if ($result == 1) {
								// print_r($report['lab']);
								$final ['lab'] [] = $row;
								// print_r($row);
								$lab_inner [] ['lat'] = $t1;
								$lab_inner [] ['lng'] = $t2;
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
						}
					}
					$map_final [] = $lab_inner;
				}
				
				// print_r($final['lab']);
				if (count ( $report ['service'] ) > 0) {
					$service_inner = array ();
					foreach ( $report ['service'] as $row ) {
						
						if (! empty ( $row ['location'] )) {
							
							$temp44 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp44 [0] ) ? $temp44 [0] : '';
							$t2 = ! empty ( $temp44 [1] ) ? $temp44 [1] : '';
							
							$result = $this->activity_report_model->is_within_10_miles ( $t1, $t2, $temp_laglng ['lat'], $temp_laglng ['long'], $miles );
							if ($result == 1) {
								// print_r($report['service']);
								$final ['service'] [] = $row;
								
								$service_inner [] ['lat'] = $t1;
								$service_inner [] ['lng'] = $t2;
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
						}
						// print_r($final['service']);
					}
					$map_final [] = $service_inner;
				}
				
				if (count ( $report ['treatment'] ) > 0) {
					$treatment_inner = array ();
					$i = 0;
					foreach ( $report ['treatment'] as $row ) {
						// echo $row['location'];
						if (! empty ( $row ['location'] )) {
							
							$temp55 = explode ( ' ', $row ['location'] );
							// echo '<pre>';
							// print_r($temp);
							$t1 = ! empty ( $temp55 [0] ) ? $temp55 [0] : '';
							$t2 = ! empty ( $temp55 [1] ) ? $temp55 [1] : '';
							$result = $this->activity_report_model->is_within_10_miles ( $t1, $t2, $temp_laglng ['lat'], $temp_laglng ['long'], $miles );
							if ($result == 1) {
								// print_r($temp);
								// echo $temp[0].'<br>';
								// print_r($report['treatment']);
								$final ['treatment'] [] = $row;
								// echo $temp[0].' %'.$temp[1];
								// print_r($row);
								// $treatment_inner[$i]['lat'] = $temp[0];
								// $treatment_inner[$i]['lng'] = $temp[1];
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
							$i ++;
						}
						// print_r($final['treatment']);
					}
					$map_final [] = $treatment_inner;
				}
				
				// exit;
				$return_data = rtrim ( $return_data, ',' );
				$temp_map = json_encode ( $map_final );
			} elseif (! empty ( $zone_check ) && $zone_check == 'no') {
				$zone_radio = 1;
				$zone_temp = 'zone';
				$map_view = 1;
				$this->zone = $this->input->post ( 'zone' );
				$this->zones = $this->site_model->getZones ( $this->zone );
				// echo $this->zones;
				// die;
				$addr = '';
				$city = '';
				$sttname = '';
				$this->activity_report = $this->activity_report_model->getActivityByZone ( $startdate, $enddate, $this->zone );
				$report = $this->activity_report;
				$final = array ();
				// $return_data = '{"lat":"40.633125","lng":"-89.398528","data":"test"},';
				$return_data = '';
				// echo "<pre>";
				// print_r($report['adult']);
				// die;
				$map_final = array ();
				if (count ( $report ['adult'] ) > 0) {
					$adult_inner = array ();
					$i = 0;
					$temp6 = array ();
					foreach ( $report ['adult'] as $row ) {
						if (! empty ( $row ['location'] )) {
							$temp6 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp6 [0] ) ? $temp6 [0] : '';
							$t2 = ! empty ( $temp6 [1] ) ? $temp6 [1] : '';
							$result = 1;
							if ($result == 1) {
								$final ['adult'] [] = $row;
								// $adult_inner[$i]['lat'] = $temp[0];
								// $adult_inner[$i]['lng'] = $temp[1];
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
							$i ++;
						}
					}
					
					$map_final [] = $adult_inner;
				}
				
				if (count ( $report ['larveltrtment'] ) > 0) {
					$larvel_inner = array ();
					$i = 0;
					$temp7 = array ();
					foreach ( $report ['larveltrtment'] as $row ) {
						if (! empty ( $row ['location'] )) {
							$temp7 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp7 [0] ) ? $temp7 [0] : '';
							$t2 = ! empty ( $temp7 [1] ) ? $temp7 [1] : '';
							
							// $result = $this->activity_report_model->is_within_10_miles($temp[0], $temp[1],$temp_laglng['lat'],$temp_laglng['long'],$miles);
							$result = 1;
							if ($result == 1) {
								$final ['larveltrtment'] [] = $row;
								// $larvel_inner[$i]['lat'] = $temp[0];
								// $larvel_inner[$i]['lng'] = $temp[1];
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
						}
					}
					$map_final [] = $larvel_inner;
				}
				
				if (count ( $report ['larvel'] ) > 0) {
					$larvel_inner = array ();
					$i = 0;
					$temp7 = array ();
					foreach ( $report ['larvel'] as $row ) {
						if (! empty ( $row ['location'] )) {
							$temp7 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp7 [0] ) ? $temp7 [0] : '';
							$t2 = ! empty ( $temp7 [1] ) ? $temp7 [1] : '';
							
							// $result = $this->activity_report_model->is_within_10_miles($temp[0], $temp[1],$temp_laglng['lat'],$temp_laglng['long'],$miles);
							$result = 1;
							if ($result == 1) {
								$final ['larvel'] [] = $row;
								// $larvel_inner[$i]['lat'] = $temp[0];
								// $larvel_inner[$i]['lng'] = $temp[1];
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
						}
					}
					$map_final [] = $larvel_inner;
				}
				
				// print_r($final['larvel']);
				if (count ( $report ['lab'] ) > 0) {
					$lab_inner = array ();
					$temp8 = array ();
					foreach ( $report ['lab'] as $row ) {
						if (! empty ( $row ['location'] )) {
							
							$temp8 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp8 [0] ) ? $temp8 [0] : '';
							$t2 = ! empty ( $temp8 [1] ) ? $temp8 [1] : '';
							
							// $result = $this->activity_report_model->is_within_10_miles($temp[0], $temp[1],$temp_laglng['lat'],$temp_laglng['long'],$miles);
							$result = 1;
							if ($result == 1) {
								$final ['lab'] [] = $row;
								$lab_inner [] ['lat'] = ! empty ( $temp [0] ) ? $temp [0] : '';
								$lab_inner [] ['lng'] = ! empty ( $temp [1] ) ? $temp [1] : '';
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
						}
					}
					$map_final [] = $lab_inner;
				}
				
				// print_r($final['lab']);
				if (count ( $report ['service'] ) > 0) {
					$service_inner = array ();
					$temp9 = array ();
					foreach ( $report ['service'] as $row ) {
						if (! empty ( $row ['location'] )) {
							$temp9 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp9 [0] ) ? $temp9 [0] : '';
							$t2 = ! empty ( $temp9 [1] ) ? $temp9 [1] : '';
							
							// $result = $this->activity_report_model->is_within_10_miles($temp[0], $temp[1],$temp_laglng['lat'],$temp_laglng['long'],$miles);
							$result = 1;
							if ($result == 1) {
								$final ['service'] [] = $row;
								// $service_inner[]['lat'] = $temp[0];
								// $service_inner[]['lng'] = $temp[1];
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
						}
						// print_r($final['service']);
					}
					$map_final [] = $service_inner;
				}
				
				if (count ( $report ['treatment'] ) > 0) {
					$treatment_inner = array ();
					$i = 0;
					$temp99 = array ();
					foreach ( $report ['treatment'] as $row ) {
						
						$temp99 = explode ( ' ', $row ['location'] );
						$t1 = ! empty ( $temp99 [0] ) ? $temp99 [0] : '';
						$t2 = ! empty ( $temp99 [1] ) ? $temp99 [1] : '';
						
						// $result = $this->activity_report_model->is_within_10_miles($temp[0], $temp[1],$temp_laglng['lat'],$temp_laglng['long'],$miles);
						$result = 1;
						if ($result == 1) {
							$final ['treatment'] [] = $row;
							// $treatment_inner[$i]['lat'] = $temp[0];
							// $treatment_inner[$i]['lng'] = $temp[1];
							$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
							$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
							$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
							$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
						}
						// print_r($final['treatment']);
						$i ++;
					}
					$map_final [] = $treatment_inner;
				}
				
				// exit;
				$return_data = rtrim ( $return_data, ',' );
				$temp_map = json_encode ( $map_final );
			} else {
				
				$state_radio = 1;
				$map_view = 1;
				$state_temp = $this->input->post ( 'state' );
				$this->state = $this->input->post ( 'state' );
				$this->states = $this->site_model->getStatesList ( $this->state );
				$miles = $this->input->post ( 'text_state' );
				$add = $this->input->post ( 'street_addr' );
				$add1 = $add;
				$add .= ',' . $this->input->post ( 'city_addr' );
				$add2 = $this->input->post ( 'city_addr' );
				$add .= ',' . $this->input->post ( 'state' );
				
				// echo $add;
				// die;
				
				$temp_laglng = $this->activity_report_model->getLatLong ( $add );
				$getlat = $temp_laglng ['lati'];
				$getlong = $temp_laglng ['longi'];
				
				// echo $getlong." ".$getlat;
				// die;
				
				$this->states = $this->site_model->getStatesList ( $state_temp );
				$final = array ();
				$return_data = '';
				$map_final = array ();
				if (count ( $report ['adult'] ) > 0) {
					$adult_inner = array ();
					$i = 0;
					// echo $temp_laglng['lati'];
					// echo "<pre>";
					// print_r($report['adult']);
					// die;
					$temp1 = array ();
					foreach ( $report ['adult'] as $row ) {
						if (! empty ( $row ['location'] )) {
							$temp1 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp1 [0] ) ? $temp1 [0] : '';
							$t2 = ! empty ( $temp1 [1] ) ? $temp1 [1] : '';
							// echo $t1." ".$t2."<br>" .$getlat." ".$getlong."<br>";
							// die;
							$result = $this->activity_report_model->is_within_10_miles ( $t1, $t2, $getlat, $getlong, $miles );
							// echo $result.'<br />';
							// die;
							if ($result == 1) {
								$final ['adult'] [] = $row;
								// $adult_inner[$i]['lat'] = $temp[0];
								// $adult_inner[$i]['lng'] = $temp[1];
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
							$i ++;
						}
					}
					
					$map_final [] = $adult_inner;
					// echo "<pre>";
					// print_r($return_data);
					// die;
				}
				
				if (count ( $report ['larvel'] ) > 0) {
					$larvel_inner = array ();
					$i = 0;
					$temp2 = array ();
					foreach ( $report ['larvel'] as $row ) {
						if (! empty ( $row ['location'] )) {
							
							$temp2 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp2 [0] ) ? $temp2 [0] : '';
							$t2 = ! empty ( $temp2 [1] ) ? $temp2 [1] : '';
							
							// echo $t1." ".$t2."<br>" .$getlat." ".$getlong."<br>";
							$result = $this->activity_report_model->is_within_10_miles ( $t1, $t2, $getlat, $getlong, $miles );
							// echo $result;
							// die;
							if ($result == 1) {
								$final ['larvel'] [] = $row;
								// $larvel_inner[$i]['lat'] = $temp[0];
								// $larvel_inner[$i]['lng'] = $temp[1];
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
						}
					}
					// echo $return_data;
					// die;
					$map_final [] = $larvel_inner;
				}
				
				// print_r($final['larvel']);
				if (count ( $report ['lab'] ) > 0) {
					$lab_inner = array ();
					$temp3 = array ();
					foreach ( $report ['lab'] as $row ) {
						if (! empty ( $row ['location'] )) {
							
							$temp3 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp3 [0] ) ? $temp3 [0] : '';
							$t2 = ! empty ( $temp3 [1] ) ? $temp3 [1] : '';
							// echo $t1." ".$t2."<br>" .$getlat." ".$getlong."<br>";
							$result = $this->activity_report_model->is_within_10_miles ( $t1, $t2, $getlat, $getlong, $miles );
							if ($result == 1) {
								$final ['lab'] [] = $row;
								// $lab_inner[]['lat'] = $temp[0];
								// $lab_inner[]['lng'] = $temp[1];
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
						}
					}
					$map_final [] = $lab_inner;
				}
				
				// print_r($final['lab']);
				if (count ( $report ['service'] ) > 0) {
					$service_inner = array ();
					$i = 0;
					$temp4 = array ();
					
					foreach ( $report ['service'] as $row ) {
						// echo "<pre>";
						// print_r($row['location']);
						// die;
						if (! empty ( $row ['location'] )) {
							
							$temp4 = explode ( " ", $row ['location'] );
							$t1 = ! empty ( $temp4 [0] ) ? $temp4 [0] : '';
							$t2 = ! empty ( $temp4 [1] ) ? $temp4 [1] : '';
							
							if (! empty ( $temp4 )) {
								$result = $this->activity_report_model->is_within_10_miles ( $t1, $t2, $getlat, $getlong, $miles );
								if ($result == 1) {
									$final ['service'] [] = $row;
									// $service_inner[]['lat'] = $temp[0];
									// $service_inner[]['lng'] = $temp[1];
									$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
									$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
									$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
									$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
								}
							}
						}
						$i ++;
						// print_r($final['service']);
					}
					$map_final [] = $service_inner;
				}
				
				if (count ( $report ['treatment'] ) > 0) {
					$treatment_inner = array ();
					$i = 0;
					$temp5 = array ();
					foreach ( $report ['treatment'] as $row ) {
						if (! empty ( $row ['location'] )) {
							
							$temp5 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp5 [0] ) ? $temp5 [0] : '';
							$t2 = ! empty ( $temp5 [1] ) ? $temp5 [1] : '';
							// echo $t1." ".$t2."<br>" .$getlat." ".$getlong."<br>";
							
							$result = $this->activity_report_model->is_within_10_miles ( $t1, $t2, $getlat, $getlong, $miles );
							if ($result == 1) {
								$final ['treatment'] [] = $row;
								// $treatment_inner[$i]['lat'] = $temp[0];
								// $treatment_inner[$i]['lng'] = $temp[1];
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
							// print_r($final['treatment']);
							$i ++;
						}
					}
					$map_final [] = $treatment_inner;
				}
				
				// exit;
				$return_data = rtrim ( $return_data, ',' );
				$temp_map = json_encode ( $map_final );
			}
			
			return $final;
		}
	}
	
	/**
	 * Function to convert data into Excel
	 */
	public function toExcelAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$query ['final'] = $this->exportView ();
			// print'<pre>';
			// print_r($query['final']);
			// die;
			$this->load->view ( 'activity_reports/excel_view', $query );
		}
	}
	public function getresult() {		
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {

			 $startdate = $this->input->post ( 'startdate' );
			 $enddate = $this->input->post ( 'enddate' );

      
			$this->zones = $this->site_model->getZones ();
			$this->sites = $this->site_model->getSelectedExistingSite ();
			$this->states = $this->site_model->getStatesList ();
			$zone_radio = 0;
			$state_radio = 0;
			$site_radio = 0;
			if (empty ( $startdate ) && empty ( $enddate )) {
				$startdate = $this->startdate;
				$enddate = $this->enddate;
			} else {
				$this->startdate = $startdate;
				$this->enddate = $enddate;
			}
			
			$this->activity_report = $this->activity_report_model->getActivity ( $startdate, $enddate );
			$report = $this->activity_report;
			
			$state_ckeck = $this->input->post ( 'state_hid' );
			$site_check = $this->input->post ( 'site_hid' );
			$zone_check = $this->input->post ( 'zone_hid' );
			$miles = "";
			$add1 = "";
			$add2 = "";
			if (! empty ( $site_check ) && $site_check == 'no') {
				$site_radio = 1;
				$this->site = $this->input->post ( 'site' );
				$this->sites = $this->site_model->getSelectedExistingSite ( $this->site );
				$map_view = 1;
				$miles = $this->input->post ( 'text_site' );
				$site_temp = $this->input->post ( 'site' );
				$temp_laglng = $this->activity_report_model->getLatLongSite ( $site_temp );
				
				$final = array ();
				$return_data = '';
				if (count ( $report ['adult'] ) > 0) {
					$i = 0;
					foreach ( $report ['adult'] as $row ) {
						if (! empty ( $row ['location'] )) {
							$temp11 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp11 [0] ) ? $temp11 [0] : '';
							$t2 = ! empty ( $temp11 [1] ) ? $temp11 [1] : '';
							$result = $this->activity_report_model->is_within_10_miles ( $t1, $t2, $temp_laglng ['lat'], $temp_laglng ['long'], $miles );
							if ($result == 1) {
								$final ['adult'] [] = $row;
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
							$i ++;
						}
					}
				}
				
				if (count ( $report ['larveltrtment'] ) >= 0) {
					$i = 0;
					foreach ( $report ['larveltrtment'] as $row ) {
						if (! empty ( $row ['location'] )) {
							$temp22 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp22 [0] ) ? $temp22 [0] : '';
							$t2 = ! empty ( $temp22 [1] ) ? $temp22 [1] : '';
							$result = $this->activity_report_model->is_within_10_miles ( $t1, $t2, $temp_laglng ['lat'], $temp_laglng ['long'], $miles );
							if ($result == 1) {
								$final ['larveltrtment'] [] = $row;
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
						}
					}
				}
				
				if (count ( $report ['larvel'] ) > 0) {
					$i = 0;
					foreach ( $report ['larvel'] as $row ) {
						if (! empty ( $row ['location'] )) {
							$temp22 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp22 [0] ) ? $temp22 [0] : '';
							$t2 = ! empty ( $temp22 [1] ) ? $temp22 [1] : '';
							$result = $this->activity_report_model->is_within_10_miles ( $t1, $t2, $temp_laglng ['lat'], $temp_laglng ['long'], $miles );
							if ($result == 1) {
								$final ['larvel'] [] = $row;
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
						}
					}
				}
				
				if (count ( $report ['lab'] ) > 0) {
					foreach ( $report ['lab'] as $row ) {
						if (! empty ( $row ['location'] )) {
							$temp33 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp33 [0] ) ? $temp33 [0] : '';
							$t2 = ! empty ( $temp33 [1] ) ? $temp33 [1] : '';
							$result = $this->activity_report_model->is_within_10_miles ( $t1, $t2, $temp_laglng ['lat'], $temp_laglng ['long'], $miles );
							if ($result == 1) {
								$final ['lab'] [] = $row;
								$lab_inner [] ['lat'] = $t1;
								$lab_inner [] ['lng'] = $t2;
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
						}
					}
				}
				
				if (count ( $report ['service'] ) > 0) {
					foreach ( $report ['service'] as $row ) {
						if (! empty ( $row ['location'] )) {
							$temp44 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp44 [0] ) ? $temp44 [0] : '';
							$t2 = ! empty ( $temp44 [1] ) ? $temp44 [1] : '';
							
							$result = $this->activity_report_model->is_within_10_miles ( $t1, $t2, $temp_laglng ['lat'], $temp_laglng ['long'], $miles );
							if ($result == 1) {
								$final ['service'] [] = $row;
								$service_inner [] ['lat'] = $t1;
								$service_inner [] ['lng'] = $t2;
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
						}
					}
				}
				
				if (count ( $report ['treatment'] ) > 0) {
					$i = 0;
					foreach ( $report ['treatment'] as $row ) {
						if (! empty ( $row ['location'] )) {
							$temp55 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp55 [0] ) ? $temp55 [0] : '';
							$t2 = ! empty ( $temp55 [1] ) ? $temp55 [1] : '';
							$result = $this->activity_report_model->is_within_10_miles ( $t1, $t2, $temp_laglng ['lat'], $temp_laglng ['long'], $miles );
							if ($result == 1) {
								$final ['treatment'] [] = $row;
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
							$i ++;
						}
					}
				}
				
				$return_data = rtrim ( $return_data, ',' );
			} elseif (! empty ( $zone_check ) && $zone_check == 'no') {
				$zone_radio = 1;
				$zone_temp = 'zone';
				$map_view = 1;
				$this->zone = $this->input->post ( 'zone' );
				$this->zones = $this->site_model->getZones ( $this->zone );
				$addr = '';
				$city = '';
				$sttname = '';
				$this->activity_report = $this->activity_report_model->getActivityByZone ( $startdate, $enddate, $this->zone );
				$report = $this->activity_report;
				$final = array ();
				$return_data = '';
				$map_final = array ();
				
				if (count ( $report ['adult'] ) > 0) {
					$adult_inner = array ();
					$i = 0;
					$temp6 = array ();
					foreach ( $report ['adult'] as $row ) {
						if (! empty ( $row ['location'] )) {
							$temp6 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp6 [0] ) ? $temp6 [0] : '';
							$t2 = ! empty ( $temp6 [1] ) ? $temp6 [1] : '';
							$result = 1;
							if ($result == 1) {
								$final ['adult'] [] = $row;
								// $adult_inner[$i]['lat'] = $temp[0];
								// $adult_inner[$i]['lng'] = $temp[1];
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
							$i ++;
						}
					}
				}
				
				if (count ( $report ['larveltrtment'] ) > 0) {
					$larvel_inner = array ();
					$i = 0;
					$temp7 = array ();
					foreach ( $report ['larveltrtment'] as $row ) {
						if (! empty ( $row ['location'] )) {
							$temp7 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp7 [0] ) ? $temp7 [0] : '';
							$t2 = ! empty ( $temp7 [1] ) ? $temp7 [1] : '';
							
							// $result = $this->activity_report_model->is_within_10_miles($temp[0], $temp[1],$temp_laglng['lat'],$temp_laglng['long'],$miles);
							$result = 1;
							if ($result == 1) {
								$final ['larveltrtment'] [] = $row;
								// $larvel_inner[$i]['lat'] = $temp[0];
								// $larvel_inner[$i]['lng'] = $temp[1];
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
						}
					}
					$map_final [] = $larvel_inner;
				}
				
				if (count ( $report ['larvel'] ) > 0) {
					$larvel_inner = array ();
					$i = 0;
					$temp7 = array ();
					foreach ( $report ['larvel'] as $row ) {
						if (! empty ( $row ['location'] )) {
							$temp7 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp7 [0] ) ? $temp7 [0] : '';
							$t2 = ! empty ( $temp7 [1] ) ? $temp7 [1] : '';
							
							// $result = $this->activity_report_model->is_within_10_miles($temp[0], $temp[1],$temp_laglng['lat'],$temp_laglng['long'],$miles);
							$result = 1;
							if ($result == 1) {
								$final ['larvel'] [] = $row;
								// $larvel_inner[$i]['lat'] = $temp[0];
								// $larvel_inner[$i]['lng'] = $temp[1];
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
						}
					}
					$map_final [] = $larvel_inner;
				}
				
				// print_r($final['larvel']);
				if (count ( $report ['lab'] ) > 0) {
					$lab_inner = array ();
					$temp8 = array ();
					foreach ( $report ['lab'] as $row ) {
						if (! empty ( $row ['location'] )) {
							
							$temp8 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp8 [0] ) ? $temp8 [0] : '';
							$t2 = ! empty ( $temp8 [1] ) ? $temp8 [1] : '';
							
							// $result = $this->activity_report_model->is_within_10_miles($temp[0], $temp[1],$temp_laglng['lat'],$temp_laglng['long'],$miles);
							$result = 1;
							if ($result == 1) {
								$final ['lab'] [] = $row;
								$lab_inner [] ['lat'] = ! empty ( $temp [0] ) ? $temp [0] : '';
								$lab_inner [] ['lng'] = ! empty ( $temp [1] ) ? $temp [1] : '';
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
						}
					}
					$map_final [] = $lab_inner;
				}
				
				// print_r($final['lab']);
				if (count ( $report ['service'] ) > 0) {
					$service_inner = array ();
					$temp9 = array ();
					foreach ( $report ['service'] as $row ) {
						if (! empty ( $row ['location'] )) {
							$temp9 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp9 [0] ) ? $temp9 [0] : '';
							$t2 = ! empty ( $temp9 [1] ) ? $temp9 [1] : '';
							
							// $result = $this->activity_report_model->is_within_10_miles($temp[0], $temp[1],$temp_laglng['lat'],$temp_laglng['long'],$miles);
							$result = 1;
							if ($result == 1) {
								$final ['service'] [] = $row;
								// $service_inner[]['lat'] = $temp[0];
								// $service_inner[]['lng'] = $temp[1];
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
						}
						// print_r($final['service']);
					}
					$map_final [] = $service_inner;
				}
				
				if (count ( $report ['treatment'] ) > 0) {
					$treatment_inner = array ();
					$i = 0;
					$temp99 = array ();
					foreach ( $report ['treatment'] as $row ) {
						
						$temp99 = explode ( ' ', $row ['location'] );
						$t1 = ! empty ( $temp99 [0] ) ? $temp99 [0] : '';
						$t2 = ! empty ( $temp99 [1] ) ? $temp99 [1] : '';
						
						// $result = $this->activity_report_model->is_within_10_miles($temp[0], $temp[1],$temp_laglng['lat'],$temp_laglng['long'],$miles);
						$result = 1;
						if ($result == 1) {
							$final ['treatment'] [] = $row;
							// $treatment_inner[$i]['lat'] = $temp[0];
							// $treatment_inner[$i]['lng'] = $temp[1];
							$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
							$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
							$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
							$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
						}
						// print_r($final['treatment']);
						$i ++;
					}
					$map_final [] = $treatment_inner;
				}
				
				// exit;
				$return_data = rtrim ( $return_data, ',' );
				$temp_map = json_encode ( $map_final );
			} else {
				
				$state_radio = 1;
				$map_view = 1;
				$state_temp = $this->input->post ( 'state' );
				$this->state = $this->input->post ( 'state' );
				$this->states = $this->site_model->getStatesList ( $this->state );
				$miles = $this->input->post ( 'text_state' );
				$add = $this->input->post ( 'street_addr' );
				$add1 = $add;
				$add .= ',' . $this->input->post ( 'city_addr' );
				$add2 = $this->input->post ( 'city_addr' );
				$add .= ',' . $this->input->post ( 'state' );
				
				// echo $add;
				// die;
				
				$temp_laglng = $this->activity_report_model->getLatLong ( $add );
				$getlat = $temp_laglng ['lati'];
				$getlong = $temp_laglng ['longi'];
				
				// echo $getlong." ".$getlat;
				// die;
				
				$this->states = $this->site_model->getStatesList ( $state_temp );
				$final = array ();
				$return_data = '';
				$map_final = array ();
				if (count ( $report ['adult'] ) > 0) {
					$adult_inner = array ();
					$i = 0;
					// echo $temp_laglng['lati'];
					// echo "<pre>";
					// print_r($report['adult']);
					// die;
					$temp1 = array ();
					foreach ( $report ['adult'] as $row ) {
						if (! empty ( $row ['location'] )) {
							$temp1 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp1 [0] ) ? $temp1 [0] : '';
							$t2 = ! empty ( $temp1 [1] ) ? $temp1 [1] : '';
							// echo $t1." ".$t2."<br>" .$getlat." ".$getlong."<br>";
							// die;
							$result = $this->activity_report_model->is_within_10_miles ( $t1, $t2, $getlat, $getlong, $miles );
							// echo $result.'<br />';
							// die;
							if ($result == 1) {
								$final ['adult'] [] = $row;
								// $adult_inner[$i]['lat'] = $temp[0];
								// $adult_inner[$i]['lng'] = $temp[1];
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
							$i ++;
						}
					}
					
					$map_final [] = $adult_inner;
					// echo "<pre>";
					// print_r($return_data);
					// die;
				}
				
				if (count ( $report ['larveltrtment'] ) > 0) {
					$larveltrtment_inner = array ();
					$i = 0;
					
					$temp1 = array ();
					foreach ( $report ['larveltrtment'] as $row ) {
						if (! empty ( $row ['location'] )) {
							$temp1 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp1 [0] ) ? $temp1 [0] : '';
							$t2 = ! empty ( $temp1 [1] ) ? $temp1 [1] : '';
							// echo $t1." ".$t2."<br>" .$getlat." ".$getlong."<br>";
							// die;
							$result = $this->activity_report_model->is_within_10_miles ( $t1, $t2, $getlat, $getlong, $miles );
							// echo $result.'<br />';
							// die;
							if ($result == 1) {
								$final ['larveltrtment'] [] = $row;
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
							$i ++;
						}
					}
					
					$map_final [] = $larveltrtment_inner;
				}
				
				if (count ( $report ['larvel'] ) > 0) {
					$larvel_inner = array ();
					$i = 0;
					$temp2 = array ();
					foreach ( $report ['larvel'] as $row ) {
						if (! empty ( $row ['location'] )) {
							
							$temp2 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp2 [0] ) ? $temp2 [0] : '';
							$t2 = ! empty ( $temp2 [1] ) ? $temp2 [1] : '';
							
							// echo $t1." ".$t2."<br>" .$getlat." ".$getlong."<br>";
							$result = $this->activity_report_model->is_within_10_miles ( $t1, $t2, $getlat, $getlong, $miles );
							// echo $result;
							// die;
							if ($result == 1) {
								$final ['larvel'] [] = $row;
								// $larvel_inner[$i]['lat'] = $temp[0];
								// $larvel_inner[$i]['lng'] = $temp[1];
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
						}
					}
					// echo $return_data;
					// die;
					$map_final [] = $larvel_inner;
				}
				
				// print_r($final['larvel']);
				if (count ( $report ['lab'] ) > 0) {
					$lab_inner = array ();
					$temp3 = array ();
					foreach ( $report ['lab'] as $row ) {
						if (! empty ( $row ['location'] )) {
							
							$temp3 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp3 [0] ) ? $temp3 [0] : '';
							$t2 = ! empty ( $temp3 [1] ) ? $temp3 [1] : '';
							// echo $t1." ".$t2."<br>" .$getlat." ".$getlong."<br>";
							$result = $this->activity_report_model->is_within_10_miles ( $t1, $t2, $getlat, $getlong, $miles );
							if ($result == 1) {
								$final ['lab'] [] = $row;
								// $lab_inner[]['lat'] = $temp[0];
								// $lab_inner[]['lng'] = $temp[1];
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
						}
					}
					$map_final [] = $lab_inner;
				}
				
				// print_r($final['lab']);
				if (count ( $report ['service'] ) > 0) {
					$service_inner = array ();
					$i = 0;
					$temp4 = array ();
					
					foreach ( $report ['service'] as $row ) {
						// echo "<pre>";
						// print_r($row['location']);
						// die;
						if (! empty ( $row ['location'] )) {
							
							$temp4 = explode ( " ", $row ['location'] );
							$t1 = ! empty ( $temp4 [0] ) ? $temp4 [0] : '';
							$t2 = ! empty ( $temp4 [1] ) ? $temp4 [1] : '';
							
							if (! empty ( $temp4 )) {
								$result = $this->activity_report_model->is_within_10_miles ( $t1, $t2, $getlat, $getlong, $miles );
								if ($result == 1) {
									$final ['service'] [] = $row;
									// $service_inner[]['lat'] = $temp[0];
									// $service_inner[]['lng'] = $temp[1];
									$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
									$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
									$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
									$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
								}
							}
						}
						$i ++;
						// print_r($final['service']);
					}
					$map_final [] = $service_inner;
				}
				
				if (count ( $report ['treatment'] ) > 0) {
					$treatment_inner = array ();
					$i = 0;
					$temp5 = array ();
					foreach ( $report ['treatment'] as $row ) {
						if (! empty ( $row ['location'] )) {
							
							$temp5 = explode ( ' ', $row ['location'] );
							$t1 = ! empty ( $temp5 [0] ) ? $temp5 [0] : '';
							$t2 = ! empty ( $temp5 [1] ) ? $temp5 [1] : '';
							// echo $t1." ".$t2."<br>" .$getlat." ".$getlong."<br>";
							
							$result = $this->activity_report_model->is_within_10_miles ( $t1, $t2, $getlat, $getlong, $miles );
							if ($result == 1) {
								$final ['treatment'] [] = $row;
								// $treatment_inner[$i]['lat'] = $temp[0];
								// $treatment_inner[$i]['lng'] = $temp[1];
								$addr = ! empty ( $row ["address1"] ) ? $row ["address1"] : '';
								$city = ! empty ( $row ["city"] ) ? $row ["city"] : '';
								$sttname = ! empty ( $row ["statename"] ) ? $row ["statename"] : '';
								$return_data .= '{"lat":"' . $t1 . '","lng":"' . $t2 . '","data":"' . $row ["site"] . '","address":"' . $addr . '","city":"' . $city . '","statename":"' . $sttname . '"},';
							}
							// print_r($final['treatment']);
							$i ++;
						}
					}
					$map_final [] = $treatment_inner;
				}
				
				// exit;
				$return_data = rtrim ( $return_data, ',' );
				$temp_map = json_encode ( $map_final );
			}
			
			// echo '<pre>';
			// print_r($final);exit;
			
			// echo $return_data;
			// die;
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_rprtng_actvty_near_poi'),
					'page' => "activity",
					'startdate' => date ( "m/d/Y", strtotime ( $this->startdate ) ),
					'starttime' => date ( 'h:i:s A', strtotime ( $this->starttime ) ),
					'endtime' => date ( 'h:i:s A', strtotime ( $this->endtime ) ),
					'enddate' => date ( "m/d/Y", strtotime ( $this->enddate ) ),
					'inspector' => $this->inspector,
					'currentdate' => $this->currentdate,
					'currenttime' => date ( "h:i:s A", strtotime ( $this->currenttime ) ),
					'final' => $final,
					'map' => $return_data,
					'report' => $report,
					'zones' => $this->zones,
					'sites' => $this->sites,
					'states' => $this->states,
					'map_view' => $map_view,
					'street_addr' => $add1,
					'city_addr' => $add2,
					'miles' => $miles,
					'state_radio' => $state_radio,
					'site_radio' => $site_radio,
					'zone_radio' => $zone_radio,
                    'app_lang' => $this->app_lang  
			)
			;
			
			// print'<pre>';
			// print_r($data_1);
			// die;
			$this->load->view ( 'header', $data_1 );
			
			$this->load->view ( 'left_sidebar', $data_1 );
			
			$this->load->view ( 'activity_reports/activity_reports', $data_1 );
		}
	}
}

/* End of file adulttreatment_report.php */
/* Location: ./application/controllers/adulttreatment_report.php */