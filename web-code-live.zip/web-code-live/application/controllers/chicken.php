<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Chicken extends CI_Controller {
	public $flockname;
	public $idsentinel;
	public $idlocation = "";
	public $dateinstalled;
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
        $this->load->helper('language');
		$this->idsentinel = $this->input->get ( 'idsentinel' );
		$this->load->model ( 'chicken_model' );
		
		if ($this->session->userdata ( 'logged_in' )) {
			$this->idlocation = $this->session->userdata ( 'idlocation' );
		}
		$this->dateinstalled = date ( 'm/d/Y' );
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			redirect ( base_url () . "chicken/getchicken" );
		}
	}
	
	/**
	 * Function to add a new chicken
	 */
	public function addchicken() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$idscs = $this->input->post ( 'x_s_' );
			
			$this->idsentinel = $this->input->post ( 'sentinel' );
			$data = array (
					'dateinstalled' => $this->dateinstalled,
					'idsentinel' => $this->idsentinel,
                    'app_lang' => $this->app_lang
			);
			
			if (! empty ( $idscs )) {
				$flag = $this->chicken_model->getChickenData ( $idscs );
				$data['detail'] = $flag;
			}
			
			$this->form_validation->set_rules ( 'bandid', $this->lang->line('sntl_chkn_mgmt_bnd_id'), 'trim|required' );
			$this->form_validation->set_rules ( 'dateinstalled', $this->lang->line('whthr_snsr_dte_instlld'), 'trim|required' );
			
			if ($this->form_validation->run () == FALSE) {
				$data ['msg'] = "error";
			} else {
				$flag = $this->chicken_model->addchicken ( $idscs );
				
				if (! empty ( $flag ) && empty ( $idscs )) {
					$data ['msg'] = "success";
				} else if (! empty ( $flag ) && ! empty ( $idscs )) {
					$data ['msg'] = "update";
				} else {
					$data ['msg'] = "error";
				}
				
				// $seturl = explode("#",$this->session->userdata('url'));
				//
				// if(!empty($flag) && empty($idscs))
				// {
				// if(!empty($seturl[1]))
				// $data['msg'] = $seturl[0]."?msg=success#".$seturl[1];
				// else
				// $data['msg'] = $seturl[0]."?msg=success";
				// }
				// else if(!empty($flag) && !empty($idscs))
				// {
				// if(!empty($seturl[1]))
				// $data['msg'] = $seturl[0]."?msg=update#".$seturl[1];
				// else
				// $data['msg'] = $seturl[0]."?msg=update";
				// }
				// else
				// {
				// $data['msg'] = "error";
				// }
			}
			if (! empty ( $idscs ))
				$this->load->view ( 'chickens/edit_chicken', $data );
			else
				$this->load->view ( 'chickens/add_chicken', $data );
		}
	}
	
	/**
	 */
	public function addchickenpop() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->idsentinel = $this->input->get ( 'idsentinel' );
			$data = array (
					'idsentinel' => $this->idsentinel,
					'dateinstalled' => $this->dateinstalled,
                    'app_lang' => $this->app_lang
			);
			
			$this->load->view ( 'chickens/add_chicken', $data );
		}
	}
	
	/**
	 */
	public function editpopupchicken() {
		if (! $this->session->userdata ( 'logged_in' ))
			redirect ( base_url () );
		else {
			$idscs = $this->input->get_post ( 'id' );
			$idsentinel = $this->input->get_post ( 'idsentinel' );
			if (empty ( $idscs ) && empty ( $idsentinel ))
				redirect ( base_url () . "chicken/getchicken" );
			
			$flag = $this->chicken_model->getChickenData ( $idscs );
			$data = array (
					'detail' => $flag,
					'idsentinel' => $idsentinel,
                    'app_lang' => $this->app_lang 
			);
			$this->load->view ( 'chickens/edit_chicken', $data );
		}
	}
	
	/**
	 * Function to delete chicken
	 */
	public function deletechicken() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->chicken_model->deleteChicken ();
			
			$msg = "";
			
			if ($flag)
				$msg = "success";
			else
				$msg = "error";
			
			$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
			if (! empty ( $seturl [1] ))
				redirect ( $seturl [0] . "?idsentinel=" . $this->idsentinel . "&del=" . $msg . "#" . $seturl [1] );
			else
				redirect ( $seturl [0] . "?idsentinel=" . $this->idsentinel . "del=" . $msg );
			// redirect(base_url().'chicken/getchicken?idsentinel='.$this->idsentinel.'&del='.$msg);
		}
	}
	
	/**
	 * Function to display List Of chickens
	 */
	public function getchicken($grid = '', $msg = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			if (! empty ( $this->idsentinel ))
				$this->flockname = $this->chicken_model->getFlockName ( $this->idsentinel );
			else{
				$uri_param = explode('-', $grid);
				if (isset($uri_param[6]) && $uri_param[6] == "sentinel")
					$this->idsentinel = $uri_param[7];
				else if (isset($uri_param[9]) && $uri_param[9] == "sentinel")
					$this->idsentinel = $uri_param[10];  
				else if (isset($uri_param[10]) && $uri_param[10] == "sentinel")
					$this->idsentinel = $uri_param[11]; 
				
				$this->flockname = $this->chicken_model->getFlockName ( $this->idsentinel );
			}
			
			$columns = array (
					0 => array (
							'name' => $this->lang->line('sntl_chkn_mgmt_smpl_id'),
							'db_name' => 'idscs',
							'header' => $this->lang->line('sntl_chkn_mgmt_smpl_id'),
							'group' => $this->lang->line('sntnl_chkn_mgmt_chkns'),
							'ref_table_id_name' => 'idsentinelchicken',
							'ref_table_id_val' => $this->idsentinel,
							'ref_table_db_name' => 'sentinelchicken',
							'required' => TRUE,
							'unique' => TRUE,
							'form_control' => 'text_long',
							'type' => 'n-1' 
					),
					1 => array (
							'name' => $this->lang->line('sntl_chkn_mgmt_bnd_id'),
							'db_name' => 'bandid',
							'header' => $this->lang->line('sntl_chkn_mgmt_bnd_id'),
							'group' => $this->lang->line('sntnl_chkn_mgmt_chkns'),
							'ref_table_id_name' => 'idsentinelchicken',
							'ref_table_id_val' => $this->idsentinel,
							'ref_table_db_name' => 'sentinelchicken',
							'required' => TRUE,
							'form_control' => 'text_long',
							'type' => 'n-1' 
					),
					2 => array (
							'name' => $this->lang->line('whthr_snsr_dte_instlld'),
							'db_name' => 'dateinstalled',
							'header' => $this->lang->line('whthr_snsr_dte_instlld'),
							'group' => $this->lang->line('sntnl_chkn_mgmt_chkns'),
							'ref_table_id_name' => 'idsentinelchicken',
							'ref_table_id_val' => $this->idsentinel,
							'ref_table_db_name' => 'sentinelchicken',
							'required' => TRUE,
							'form_control' => 'text_long',
							'type' => 'n-1' 
					) 
			);
			
			$commands ['delete'] ['toolbar'] = FALSE;
			
			$data_1 = array (
					'idsentinel' => $this->idsentinel,
                    'app_lang' => $this->app_lang
			);
			
			$add_view = $this->load->view ( 'chickens/add_chicken', $data_1, TRUE );
			$edit_view = $this->load->view ( 'chickens/edit_chicken', '', TRUE );
			$params = array (
					'id' => 'idscs',
					'table' => 'sentinelchickensamples',
					'url' => 'chicken/getchicken',
					'uri_param' => $grid,
					'columns' => $columns,
					'para' => $this->idsentinel,
					// 'columns_visible' => array(0,1),
					'order' => array (
							0 => 'desc' 
					),
					'filters' => array (
							0 => array (
									'value' => $this->idlocation 
							) 
					),
					'commands' => $commands,
					'ajax' => TRUE,
					'msc_url' => array (
							'excel_url' => base_url () . 'chicken/toExcelAll',
							'pdf_url' => base_url () . 'chicken/toPdfAll',
							'text' => 'Chicken' 
					),
					'add_view' => $add_view,
					'edit_view' => $edit_view 
			);
			
			$newdata = array (
					'url' => base_url () . $params ['url'] . "?idsentinel=" . $this->idsentinel . '#' . $params ['id'] . '=' . $grid 
			);
			
			$this->session->set_userdata ( $newdata );
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => 'Chicken Management',
					'page' => "sentinel_chkn_mgmt",
                    'app_lang' => $this->app_lang 
			);
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			
			// Pass grid to the view
            $data = (object)array();
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			$data->msg = $msg;
			$data->idsentinel = $this->idsentinel;
			
			if (! empty ( $this->flockname )) {
				$data->flockname = $this->flockname;
			}
			
			$this->load->view ( 'chickens/chickens', $data );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function toExcelAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$query ['data'] = $this->chicken_model->listChickens ( $this->idsentinel );
			// print'<pre>';
			// print_r($query['data']);
			// die;
			$this->load->view ( 'chickens/excel_view', $query );
		}
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->helper ( 'pdf_helper' ); // Load helper
			$query ['data'] = $this->chicken_model->listChickens ( $this->idsentinel );
			
			$data = $this->load->view ( 'chickens/pdf_view', $query, true );
			// $data = file_get_contents(htmlentities($dd)); // Pass the url of html report
			
			create_pdf ( $data, $this->lang->line('sntl_chkn_sample_pdf') ); // Create pdf
		}
	}
}

/* End of file chicken.php */
/* Location: ./application/controllers/chicken.php */