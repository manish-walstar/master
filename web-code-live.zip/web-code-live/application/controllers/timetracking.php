<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Timetracking extends CI_Controller {
	public $products;
	public $product_list;
	public $startdate;
	public $starttime;
	public $enddate;
	public $endtime;
	public $inspector;
	public $currentdate;
	public $currenttime;
	public $zones;
	public $zone = "";
	public $sites;
	public $site = "";
	public $species;
	public $_species = "";
	public $_techs = "";
	public $techs;
	public $traptypes;
	public $_traptypes = "";
	public $endtimestamp;
	public $starttimestamp;
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		$this->load->helper('language');
		$this->load->model ( 'site_model' );
		$this->load->model ( 'arbovirallab_model' );
		$this->load->model ( 'usermodel' );
		$this->load->model('timetracking_report_model');
        
		$this->usermodel->set_access_session ();
		
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		if (! $this->usermodel->user_access ( 'reports' ) && ! $this->usermodel->user_access ( 'company_admin' ))
			redirect ( base_url () );
		
		$id = $this->session->userdata ( 'id' );
		$id_arr = explode ( "_", json_decode ( base64_decode ( $id ) ) );
		
		$id = json_decode ( base64_decode ( $id_arr [0] ) );
		
		$this->userinfo = $this->usermodel->getUserData ( $id );
		
		$middlename = " ";
		if (isset ( $this->userinfo ['middlename'] ))
			$middlename = ! empty ( $this->userinfo ['middlename'] ) ? " " . $this->userinfo ['middlename'] . " " : " ";
		
		if (isset ( $this->userinfo ['firstname'] ) || isset ( $this->userinfo ['lastname'] ))
			$this->inspector = $this->userinfo ['firstname'] . $middlename . $this->userinfo ['lastname'];
		
		$this->currentdate = date ( 'm/d/Y' );
		$this->currenttime = date ( "h:i:s A" );
		
		$this->enddate = date ( 'm/d/Y' );
		$this->endtime = date ( 'h:i:s A' );
		
		$this->startdate = date ( 'm/d/Y', strtotime ( "-1 day" ) );
		$this->starttime = date ( 'h:i:s A' );
		
		$this->endtimestamp = strtotime ( date ( 'm/d/Y H:i:s' ) );
		
		$this->starttimestamp = strtotime ( date ( 'm/d/Y H:i:s', strtotime ( "-1 day" ) ) );
	}

	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			redirect ( base_url () . "timetracking/getReport" );
		}
	}
	
	/**
	 * Function to fetch All products
	 */
	public function getReport() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->billRate = 80;
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			$this->site = $this->input->post ( 'site' );
			$this->groupSite = $this->input->post('siteGroup');
			$this->usersDropdown = $this->input->post('usersDropdown');
			log_message('debug','Skysoft Debugging --->> Site is ....... '.$this->site);
			log_message('debug','Skysoft Debugging --->> Site Group is ....... '.$this->groupSite);
			log_message('debug','Skysoft Debugging --->> Select User is .............................. '.print_r($this->usersDropdown,1));
			if(!empty($this->groupSite)){
				$this->sites =  $this->site_model->getSitesOfGroupSite($this->groupSite, $this->site);
			} else {
				$this->sites =  $this->site_model->getSelectedExistingSites($this->site);			
			}
			$this->users = $this->timetracking_report_model->getUsersOfReport($this->usersDropdown);
			$data_1 = array ();
	
			if (empty ( $startdate ) || empty ( $enddate )) {
				$this->siteGroups = $this->site_model->getUserSiteGroup($this->groupSite);
				//log_message('debug','Skysoft Debugging -------------->>>>>site groups are ....... '.print_r($this->siteGroups,1));
				$this->products = $this->timetracking_report_model->getTimeTrackingReport($this->startdate, $this->enddate, $this->site, $this->groupSite,$this->usersDropdown);
			} else {
				$startdate_arr = explode ( " ", $startdate );
				$enddate_arr = explode ( " ", $enddate );
				$this->startdate = date ( 'm/d/Y', strtotime ( $startdate_arr [0] ) );
				$this->enddate = date ( 'm/d/Y', strtotime ( $enddate_arr [0] ) );
				$this->products = $this->timetracking_report_model->getTimeTrackingReport($this->startdate, $this->enddate, $this->site, $this->groupSite,$this->usersDropdown);
			}
			$this->siteGroups = $this->site_model->getUserSiteGroup($this->groupSite);
			//log_message('debug','Skysoft Debugging -------------->>>>>site groups are ....... '.print_r($this->siteGroups,1));
			$products_size = sizeof($this->products);
			for ($i = 0; $i < $products_size; $i++ ) {
				$this->products[$i]->siteName = $this->products[$i]->idsite . " " .$this->products[$i]->site;
				$startDateTemp = $this->products[$i]->startDateAndTime;
				$endDateTemp = $this->products[$i]->endDateAndTime;
				if( $startDateTemp != '0000-00-00 00:00:00' && $endDateTemp != '0000-00-00 00:00:00') {
					$startDateTime = explode ( " ", $startDateTemp);
					$this->products[$i]->startDate = $startDateTime[0];
					$this->products[$i]->startTime = $startDateTime[1];
					$endDateTime = explode(" ", $endDateTemp);
					$this->products[$i]->endDate = $endDateTime[0];
					$this->products[$i]->endTime = $endDateTime[1];
					$this->products[$i]->onSiteMins = $this->timeDifference($startDateTemp, $endDateTemp);
					//log_message('debug','Skysoft Debugging -------------->>>>>>>>>>>>>>>>>>>>>>>>>>>>>>time difference is  ............. '.$this->products[$i]->onSiteMins);
					$this->products[$i]->billAmount = $this->billCalculate($this->products[$i]->onSiteMins, $this->billRate);
				} else {
					log_message('debug','Skysoft Debugging -------------->>>>>date is empty here ....... ');
					$this->products[$i]->startDate = $startDateTemp;
					$this->products[$i]->startTime = 0;
					$this->products[$i]->endTime = $endDateTemp;
					$this->products[$i]->endDate = 0;
					$this->products[$i]->onSiteMins = 0;
					$this->products[$i]->billAmount = 0.00;
				}
			}
			$data_1 = array (
				'username' => $this->session->userdata ( 'username' ),
			    'firstname' => $this->session->userdata ( 'firstname' ),
			    'lastname' => $this->session->userdata ( 'lastname' ),
				'logstatus' => "logout",
				'title' => $this->lang->line('sidebar_timetracking'),
				'page' => "timetracking_report",
				'startdate' => date ( "m/d/Y", strtotime ( $this->startdate ) ),
				'starttime' => date ( 'g:i A', strtotime ( $this->starttime ) ),
				'endtime' => date ( 'g:i A', strtotime ( $this->endtime ) ),
				'enddate' => date ( "m/d/Y", strtotime ( $this->enddate ) ),
				'inspector' => $this->inspector,
				'currentdate' => $this->currentdate,
				'currenttime' => date ( "h:i:s A", strtotime ( $this->currenttime ) ),
				'products' => $this->products,
				'selectedGroupSite' => $this->groupSite,
				'selectedSiteID' => $this->site,
				'users' => $this->users,
				'sites' => $this->sites,
				'siteGroup' => $this->siteGroups,
				'billRate' => $this->billRate,
			);
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			$this->load->view ( 'timetracking/timetracking_reports', $data_1 );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to fetch the data
	 * and format it in order to return
	 */
	public function billCalculate($time, $rate) 
	{
		$times = explode(':', $time);
		$billAmount = 0.00;
		if(sizeof($times) == 3) {
			$hours = (float)$times[0];
			$billAmount += $hours * $rate;
			$minutes = (float)$times[1];
			$minutes = $minutes/60;
			$billAmount += $minutes * $rate;
			$seconds = (float)$times[2];
			$seconds = $seconds/3600;
			$billAmount += $seconds * $rate;
			$billAmount = round($billAmount,2);
		}
		return $billAmount;

	}

	public function exportView() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			log_message('debug','Skysoft Debugging -------------->>>>>export view is called....................... ....... ');
			$this->billRate = 80;
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			$this->site = $this->input->post ( 'site' );
			$this->groupSite = $this->input->post('siteGroup');
			$this->usersDropdown = $this->input->post('usersDropdown');
			log_message('debug','Skysoft Debugging -------------->>>>>site value is ....... '.$this->site);
			log_message('debug','Skysoft Debugging -------------->>>>>site groups value ....... '.$this->groupSite);
			$data_1 = array ();
			if (empty ( $startdate ) || empty ( $enddate )) {
				$this->sites = $this->site_model->getSelectedExistingSite ();
				$this->products = $this->timetracking_report_model->getTimeTrackingReport($this->startdate, $this->enddate, $this->site,$this->groupSite,$this->usersDropdown);
			} else {
				$startdate_arr = explode ( " ", $startdate );
				$enddate_arr = explode ( " ", $enddate );
				$this->startdate = date ( 'm/d/Y', strtotime ( $startdate_arr [0] ) );
				$this->enddate = date ( 'm/d/Y', strtotime ( $enddate_arr [0] ) );
				$this->products = $this->timetracking_report_model->getTimeTrackingReport($this->startdate, $this->enddate, $this->site,$this->groupSite,$this->usersDropdown);
			}
			$this->sites = $this->site_model->getSelectedExistingSite ( $this->site );
			$products_size = sizeof($this->products);
			for ($i = 0; $i < $products_size; $i++ ) {
				$this->products[$i]->siteName = $this->products[$i]->idsite . " " .$this->products[$i]->site;
				$startDateTemp = $this->products[$i]->startDateAndTime;
				$endDateTemp = $this->products[$i]->endDateAndTime;
				if( $startDateTemp != '0000-00-00 00:00:00' && $endDateTemp != '0000-00-00 00:00:00') {
					$startDateTime = explode ( " ", $startDateTemp);
					$this->products[$i]->startDate = $startDateTime[0];
					$this->products[$i]->startTime = $startDateTime[1];
					$endDateTime = explode(" ", $endDateTemp);
					$this->products[$i]->endDate = $endDateTime[0];
					$this->products[$i]->endTime = $endDateTime[1];
					$this->products[$i]->onSiteMins = $this->timeDifference($startDateTemp, $endDateTemp);
					$this->products[$i]->billAmount = $this->billCalculate($this->products[$i]->onSiteMins, $this->billRate);
				} else {
					$this->products[$i]->startDate = $startDateTemp;
					$this->products[$i]->startTime = 0;
					$this->products[$i]->endTime = $endDateTemp;
					$this->products[$i]->endDate = 0;
					$this->products[$i]->onSiteMins = 0;
				}
			}
			$data_1 = array (
				'username' => $this->session->userdata ( 'username' ),
			    'firstname' => $this->session->userdata ( 'firstname' ),
			    'lastname' => $this->session->userdata ( 'lastname' ),
				'logstatus' => "logout",
				'title' => $this->lang->line('sidebar_timetracking'),
				'page' => "timetracking_report",
				'startdate' => date ( "m/d/Y", strtotime ( $this->startdate ) ),
				'starttime' => date ( 'g:i A', strtotime ( $this->starttime ) ),
				'endtime' => date ( 'g:i A', strtotime ( $this->endtime ) ),
				'enddate' => date ( "m/d/Y", strtotime ( $this->enddate ) ),
				'inspector' => $this->inspector,
				'currentdate' => $this->currentdate,
				'currenttime' => date ( "h:i:s A", strtotime ( $this->currenttime ) ),
				'products' => $this->products,
				'sites' => $this->sites,
				'billRate' => $this->billRate,
			);
			$data = $this->load->view ( 'timetracking/reports', $data_1, TRUE );
			return $data;
		}
	}
	
	public function getSitesOfGroupSite() {
		$siteGroupId = $this->uri->segment(3);
		$id = '';
		$sites = $this->site_model->getSitesOfGroupSite($siteGroupId, $id);
		//log_message('debug','Skysoft Debugging -------------->>>>>site groups id is ......... '.$siteGroupId);
		//log_message('debug','Skysoft Debugging -------------->>>>>site sites are  ......... '.print_r($sites,1));
		echo json_encode($sites);
        return;
	}

	public function getUserSites() {
		$id='';
		$sites = $this->site_model->getSelectedExistingSites();
		echo json_encode($sites);
		return;
	}

	/**
	 * Function to convert data into PDF
	 */
	public function toPDFAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->helper ( 'pdf_helper' );
			$data = $this->exportView ();
			create_pdf_l ( $data, "TimeTrackingReport" );
		}
	}
	
	/**
	 * Function to convert data into Excel
	 */
	public function toEXCELAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$data = $this->exportView ();
			// print'<pre>';
			// print_r($data);
			// die;
			//
			header ( "Content-type: application/octet-stream" );
			header ( "Content-Disposition: attachment; filename=".$this->lang->line('sidebar_timetracking').".xls" );
			header ( "Pragma: no-cache" );
			header ( "Expires: 0" );
			
			echo $data;
			exit ();
		}
	}

	public function timeDifference($startTime, $endTime) {
		$time1 = strtotime($startTime);
		$time2 = strtotime($endTime);
		if ($time2 < $time1) 
		{ 
			$time2 = $time2 + 86400;
		} 
		return date("H:i:s", strtotime("1980-01-01 00:00:00") + ($time2 - $time1));
	}
	
}

/* End of file larvalsurveillance_report.php */
/* Location: ./application/controllers/larvalsurveillance_report.php */