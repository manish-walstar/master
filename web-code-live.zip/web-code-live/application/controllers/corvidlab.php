<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Corvidlab extends CI_Controller {
	public $trap_name = "";
	public $date_selected = "";
	public $species = "";
	public $assay = "";
	public $result = "";
	public $labtechnician = "";
	public $virus_type = "";
	public $trap_count = "";
	public $idlocation = "";
	public $sitegroup = "";
	
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		$this->load->helper('language');
		$this->load->model ( 'corvidlab_model' );
		$this->load->model ( 'landingrate_model' );
		$this->load->model ( 'site_model' );
		$this->load->model ( 'arbovirallab_model' );
		$this->load->model ( 'adultsurveillance_model' );
		$this->load->model ( 'zone_model' );
		$this->load->model ( 'calsurvflock_model', 'cm' );
		
		$this->species = $this->corvidlab_model->getAvianSpecies ();
		$this->assay = $this->arbovirallab_model->getAssay ();
		$this->result = $this->arbovirallab_model->getArbovirallabResult ();
		$this->virus_type = $this->arbovirallab_model->getDetectedVirus ();
		$this->sitegroup = $this->site_model->getSiteGroup ();
		
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		if ($this->session->userdata ( 'logged_in' )) {
			$this->idlocation = $this->session->userdata ( 'idlocation' );
		}
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			redirect ( base_url () . "corvidlab/getcorvidlab" );
		}
	}
	
	/**
	 * Function to add a new corvidlab
	 */
	public function addcorvidlab() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$id = $this->input->post ( 'id' );
			
			$this->form_validation->set_rules ( 'datecollected', $this->lang->line('arbvrl_actvty_date_cllctd'), 'trim|required' );
			$this->form_validation->set_rules ( 'idsite', $this->lang->line('whthr_snsr_site_nm'), 'trim' );
			$this->form_validation->set_rules ( 'idsitetype', $this->lang->line('trap_mgmt_site_type'), 'trim' );
			$this->form_validation->set_rules ( 'idzone', 'Zone', 'trim' );
			$this->form_validation->set_rules ( 'latitude', $this->lang->line('site_mgmt_lat'), 'trim|required' );
			$this->form_validation->set_rules ( 'longitude', $this->lang->line('site_mgmt_lng'), 'trim|required' );
			$this->form_validation->set_rules ( 'collectedby_first', $this->lang->line('cmn_lbl_frst_name'), 'trim|required' );
			$this->form_validation->set_rules ( 'collectedby_last', $this->lang->line('cmn_lbl_lstnme'), 'trim|required' );
			$this->form_validation->set_rules ( 'avian_species', $this->lang->line('corvd_labs_avn_spcs'), 'trim|required' );
			$this->form_validation->set_rules ( 'assay_type', $this->lang->line('arbvrl_lab_asy_prfmnd'), 'trim|required' );
			
			if ($this->form_validation->run () == FALSE) {
				echo "error";
			} else {
				$flag = $this->corvidlab_model->addCorvidlab ( $id );
				$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
				$msg = "";
				
				if ($flag) {
					if (! empty ( $seturl [1] ))
						echo $seturl [0] . "?msg=saved#" . $seturl [1];
					else
						echo $seturl [0] . "?msg=saved";
					
					exit ();
					$msg = "Your data was successfully saved";
				} else
					$msg = "error";
				
				echo $msg;
			}
		}
	}
	
	/**
	 * Function to show edit corvidlab
	 */
	public function showeditcorvidlab($Id = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get_post ( 'id' );
            $mapFlag = $this->input->get_post('mapFlag');
            $mapSite = $this->input->get_post('idsite');
			
			if (empty ( $req ))
				echo "error";
			
			$flag = $this->corvidlab_model->getCorvidlabData ( $req );
            
			if ($flag) {
				$site_data = $this->site_model->getSiteData ( $flag ['idsite'] );
				$mapSite = $flag ['idsite'];
				if (! empty ( $site_data )) {
					$flag ['site'] = $site_data ['site'];
					$flag ['address1'] = $site_data ['address1'];
					$flag ['address2'] = $site_data ['address2'];
					$flag ['city'] = $site_data ['city'];
					$flag ['postalcode'] = $site_data ['postalcode'];
					$flag ['statename'] = $site_data ['states_statename'];
                    $flag ['idstate'] = $site_data ['idstate'];
					$flag ['zone_name'] = $this->landingrate_model->getSelectedZonename ( $site_data ['idzone'] );
					// $flag['idsitegroup'] = !empty($site_data['idsitegroup'])?$site_data['idsitegroup']:'';
				}
				
				$flag ['species'] = $this->species;
				$flag ['assay'] = $this->assay;
				$flag ['lab_result'] = $this->result;
				$flag ['existing_site'] = $this->landingrate_model->getSitename ( $flag ['idsite'] );
				$flag ['site_type'] = $this->site_model->getSitetypes ();
				$flag ['state_name'] = $this->site_model->getStates ();
				$flag ['virus_type'] = $this->virus_type;
				$flag ['sitegroup'] = $this->sitegroup;
				$flag ['idzone'] = $site_data ['idzone'];
                $flag ['idstate'] = $site_data ['idstate'];
                $flag ['idsitetype'] = $site_data ['idsitetype'];
                
				$flag ['show_sample'] = '';
				$flag ['show_virus'] = 'class="hide"';
				$flag ['show_ramp'] = 'class="hide"';
				$flag ['show_confirm'] = 'class="hide"';
				$flag ['show_result'] = 'class="hide"';
				
				if ($flag ['idassaytype'] == "1") {
					$flag ['show_virus'] = "";
					$flag ['show_ramp'] = "";
					$flag ['show_confirm'] = "";
					$flag ['show_result'] = "";
				} else if ($flag ['idassaytype'] == "2") {
					$flag ['show_virus'] = "";
					$flag ['show_confirm'] = "";
					$flag ['show_result'] = "";
					$flag ['show_ramp'] = 'class="hide"';
				} else {
					$flag ['show_virus'] = "";
					$flag ['show_ramp'] = 'class="hide"';
					$flag ['show_confirm'] = 'class="hide"';
					$flag ['show_result'] = 'class="hide"';
				}
				
				if ($flag ['rtprcconfirm'] == "1")
					$flag ['confirm'] = "checked='true'";
				
				if ($flag ['resultscorresspond'] == "1")
					$flag ['result'] = "checked='true'";
				//print'<pre>';
//              print_r($flag);
//              die;
				$flag['mapFlag'] = $mapFlag;
                $mapData = $this->getAllEventsData($mapSite);
                $flag = array_merge($flag, $mapData);
				$this->load->view ( 'corvidlabs/edit_corvidlab', $flag );
			}
		}
	}
	/**
	 * Function to save edit Adult Surveillance Values
	 */
	public function editcorvidlab() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->form_validation->set_rules ( 'labassayid', 'Assay ID', 'trim|required' );
			$this->form_validation->set_rules ( 'poolsize', $this->lang->line('data_export_poolsize'), 'trim|required' );
			$this->form_validation->set_rules ( 'species', $this->lang->line('lnding_rte_spcies'), 'trim|required' );
			$this->form_validation->set_rules ( 'testdate', $this->lang->line('arbvrl_labs_testdate'), 'trim|required' );
			$this->form_validation->set_rules ( 'assay_type', $this->lang->line('arbvrl_lab_asy_prfmnd'), 'trim|required' );
			
			if ($this->form_validation->run () == FALSE) {
				echo "error";
			} else {
				
				$flag = $this->corvidlab_model->updateCorvidlab ();
				$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
				$msg = "";
				
				if ($flag) {
					if (! empty ( $seturl [1] ))
						echo $seturl [0] . "?msg=success#" . $seturl [1];
					else
						echo $seturl [0] . "?msg=success";
					
					exit ();
					$msg = "Your data was successfully updated";
				} else
					$msg = "error";
				
				echo $msg;
			}
		}
	}
	
	/**
	 * Function to delete corvidlab
	 */
	public function deletecorvidlab() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->corvidlab_model->deleteCorvidlab ();
			
			$msg = "";
			
			if ($flag)
				$msg = "success";
			else
				$msg = "error";
			
			$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
			if (! empty ( $seturl [1] ))
				redirect ( $seturl [0] . "?del=" . $msg . "#" . $seturl [1] );
			else
				redirect ( $seturl [0] . "?del=" . $msg );
			// redirect(base_url().'corvidlab/getcorvidlab?del='.$msg);
		}
	}
	
	/**
	 * Function to display List Of corvidlabs
	 */
	public function getcorvidlab($grid = '', $msg = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$filter_date = $this->input->post ( 'filter_date' );
			$columns = array (
					0 => array (
							'name' => $this->lang->line('sntl_chkn_mgmt_smpl_id'),
							'db_name' => 'idcorvidlab',
							'header' => $this->lang->line('sntl_chkn_mgmt_smpl_id'),
							'group' => $this->lang->line('labs_corvd_lab'),
							'form_control' => 'text_long',
							'required' => TRUE 
					)
					// 'type' => '1-n'
					,
					1 => array (
							'name' => $this->lang->line('arbvrl_actvty_date_cllctd'),
							'db_name' => 'datecollected',
							'header' => $this->lang->line('arbvrl_actvty_date_cllctd'),
							'group' => $this->lang->line('labs_corvd_lab')
							
					)
					// 'type' => '1-1-1'
					,
					2 => array (
							'name' => $this->lang->line('corvd_lab_loc'),
							'db_name' => 'idsite',
							'header' => $this->lang->line('corvd_lab_loc'),
							'group' => 'Lab',
							'ref_table_id_name' => 'idsite',
							'ref_table_db_name' => 'sites',
							'ref_field_db_name' => 'site',
							'required' => TRUE,
							'type' => '1-n'
							
					),
					3 => array (
							'name' => $this->lang->line('lrvl_srvlnc_addrs'),
							'db_name' => 'idsite',
							'header' => $this->lang->line('lrvl_srvlnc_addrs'),
							'group' => $this->lang->line('labs_corvd_lab'),
							'ref_table_id_name' => 'idsite',
							'ref_table_db_name' => 'sites',
							'ref_field_db_name' => 'address1',
							'ref_field_2_db_name' => 'address2',
							'ref_field_type' => 'string',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-1+2'
							
					),
					4 => array (
							'name' => $this->lang->line('site_mgmt_cty'),
							'db_name' => 'idsite',
							'header' => $this->lang->line('site_mgmt_cty'),
							'group' => $this->lang->line('labs_corvd_lab'),
							'ref_table_id_name' => 'idsite',
							'ref_table_db_name' => 'sites',
							'ref_field_db_name' => 'city',
							'required' => TRUE,
							'form_control' => 'text_long',
							'type' => '1-n'
							
					),
					5 => array (
							'name' => $this->lang->line('site_mgmt_state'),
							'db_name' => 'idsite',
							'header' => $this->lang->line('site_mgmt_state'),
							'group' => $this->lang->line('labs_corvd_lab'),
							'ref_table_id_name' => 'idsite',
							'ref_table_db_name' => 'sites',
							'ref_field_db_name' => 'idstate',
							'ref_table_id2_name' => 'idstate',
							'ref_table_db2_name' => 'states',
							'ref_field_db2_name' => 'statename',
							'ref_field_type' => 'string',
							'required' => TRUE,
							'form_control' => 'text_long',
							'type' => '1-1-1'
					),
					6 => array (
							'name' => $this->lang->line('data_export_cllctd_by'),
							'db_name_1' => 'collectedbyfirst',
							'db_name_2' => 'collectedbylast',
							'header' => $this->lang->line('data_export_cllctd_by'),
							'group' => $this->lang->line('labs_corvd_lab'),
							'form_control' => 'text_long',
							'type' => '1+2'
					),
					7 => array (
							'name' => $this->lang->line('corvd_labs_avn_spcs'),
							'db_name' => 'idavianspecies',
							'header' => $this->lang->line('corvd_labs_avn_spcs'),
							'group' => $this->lang->line('labs_corvd_lab'),
							'ref_table_id_name' => 'idavianspecies',
							'ref_table_db_name' => 'avianspecies',
							'ref_field_db_name' => 'avianspecies',
							'required' => TRUE,
							'form_control' => 'text_long',
							'type' => '1-n'
					),
					8 => array (
							'name' => $this->lang->line('arbvrl_lab_asy_prfmnd'),
							'db_name' => 'idassaytype',
							'header' => $this->lang->line('arbvrl_lab_asy_prfmnd'),
							'group' => $this->lang->line('labs_corvd_lab'),
							'ref_table_id_name' => 'idassaytype',
							'ref_table_db_name' => 'assaytypes',
							'ref_field_db_name' => 'assaytype',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-n'
					),
					9 => array (
							'name' => $this->lang->line('sntl_chkn_mgmt_rslt'),
							'db_name' => 'idlabresult',
							'header' => $this->lang->line('sntl_chkn_mgmt_rslt'),
							'group' => $this->lang->line('labs_corvd_lab'),
							'ref_table_id_name' => 'idlabresult',
							'ref_table_db_name' => 'labresults',
							'ref_field_db_name' => 'labresult',
							'required' => TRUE,
							'form_control' => 'text_long',
							'type' => '1-n'
					) 
			)
			;
			
			$commands ['delete'] ['toolbar'] = FALSE;
			
			$params = array (
					'id' => 'idcorvidlab',
					'table' => 'corvidlabs',
					'url' => 'corvidlab/getcorvidlab',
					'uri_param' => $grid,
					'columns' => $columns,
					'order' => array (
							1 => 'desc' 
					),
					'filter_date' => ! empty ( $filter_date ) ? $filter_date : '2',
					'filters' => array (
							0 => array (
									'value' => $this->idlocation 
							) 
					),
					// 'columns_visible' => array(0,1,2),
					'commands' => $commands,
					'ajax' => TRUE,
					'msc_url' => array (
							'excel_url' => base_url () . 'corvidlab/toExcelAll',
							'pdf_url' => base_url () . 'corvidlab/toPdfAll',
							'text' => 'Corvidlab' 
					) 
			);
			
			$newdata = array (
					'url' => base_url () . $params ['url'] . '#' . $params ['id'] . '=' . $grid 
			);
			
			$this->session->set_userdata ( $newdata );
			
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('labs_corvd_labs'),
					'page' => "arbovirallab",
					'flag' => $this->cm->checkCaGateway () 
			);
			
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			
			// Pass grid to the view
            $data = (object)array();
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			$data->msg = $msg;
			$data->mapdata = base_url () . "corvidlab/showmap";
			
			$this->load->view ( 'corvidlabs/corvidlabs', $data );
		}
		$this->load->view ( 'footer' );
	}
	public function showmap() {
		$query ['data'] = $this->corvidlab_model->getMapdata ();
		$query ['user_loc'] = $this->adultsurveillance_model->getUserLoc ();
		$query ['zone_loc'] = $this->zone_model->getZoneCord ();
		$query ['googlezoom'] = $this->session->userdata ( 'googlezoom' );
		$this->load->view ( 'corvidlabs/map_view', $query );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function getcorvidlabdata() { 
		$id = $this->input->post ( 'idcorvidlab' );
		
		if (empty ( $id )) {
			echo "error";
			exit ();
		}
		
		$data = $this->corvidlab_model->getCorvidlabData ( $id );
		
		echo json_encode ( $data );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function collectedSpecies() {
		$req = $this->input->get_post ( 'x_s_' );
		
		if (empty ( $req ))
			redirect ( base_url () . "corvidlab/getcorvidlab" );
		
		$query ['data'] = $this->corvidlab_model->getSpeciesCount ( $req );
		
		$this->load->view ( 'corvidlabs/allspecies_view', $query );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function toExcelAll() {
		$query ['data'] = $this->corvidlab_model->listCorvidlabs ();
		// print'<pre>';
		// print_r($query['data']);
		// die;
		$this->load->view ( 'corvidlabs/excel_view', $query );
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
		$this->load->helper ( 'pdf_helper' ); // Load helper
		$query ['data'] = $this->corvidlab_model->listCorvidlabs ();
		
		$data = $this->load->view ( 'corvidlabs/pdf_view', $query, true );
		// $data = file_get_contents(htmlentities($dd)); // Pass the url of html report
		
		create_pdf_l ( $data, $this->lang->line('labs_corvd_lab_pdf_name') ); // Create pdf
	}
	
	/**
	 * Function to view page at on click popup
	 */
	public function showaddarboviral() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
            $mapFlag = $this->input->get_post ( 'mapFlag' );
            $idsite = $this->input->get('idsite');
            
            $data = array (
					'species' => $this->species,
					'assay' => $this->assay,
					'result' => $this->result,
					'virus_type' => $this->virus_type,
					'sitegroup' => $this->sitegroup,
					'existing_site' => $this->landingrate_model->getSitename (),
					'site_type' => $this->site_model->getSitetypes (),
					'zone_name' => $this->landingrate_model->getSelectedZonename (),
					'state_name' => $this->site_model->getStates (),
                    'mapFlag' => $mapFlag
			);
            
            $site_data = $this->site_model->getSiteData ( $idsite );
			if (! empty ( $site_data )) {
				$data ['site'] = $site_data ['site'];
				$data ['address1'] = $site_data ['address1'];
				$data ['address2'] = $site_data ['address2'];
				$data ['city'] = $site_data ['city'];
				$data ['postalcode'] = $site_data ['postalcode'];
				$data ['statename'] = $site_data ['states_statename'];
                $data ['maplabel'] = ! empty ( $site_data ['maplabel'] ) ? $site_data ['maplabel'] : '';
				$data ['address1'] = ! empty ( $site_data ['address1'] ) ? $site_data ['address1'] : '';
				$data ['address2'] = ! empty ( $site_data ['address2'] ) ? $site_data ['address2'] : '';
				$data ['city'] = ! empty ( $site_data ['city'] ) ? $site_data ['city'] : '';
				$data ['latitude'] = ! empty ( $site_data ['latitude'] ) ? $site_data ['latitude'] : '';
				$data ['longitude'] = ! empty ( $site_data ['longitude'] ) ? $site_data ['longitude'] : '';
                $data ['existing_site'] = $this->landingrate_model->getSitename ( $site_data ['idsite'] );
    			$data ['idsitetype'] = $site_data ['idsitetype'];
                $data ['idstate'] = $site_data ['idstate'];
    			$data ['zone_name'] = $this->landingrate_model->getSelectedZonename ( $site_data ['idzone'] );
			}
			
			$eventData = $this->getAllEventsData($idsite);
            $data = array_merge($data, $eventData);
			$add_view = $this->load->view ( 'corvidlabs/add_corvidlab', $data );
		}
	}
    
    /**
     * Function to fetch all site data based on module
     */
    public function getAllEventsData($idsite = "")
    {
        $params = array('idsite' => $idsite, 'idlocation' => $this->session->userdata('idlocation'));

        $this->load->library('common', $params);

        $response = $this->common->getAllEventsData();
        //print'<pre>';
        //        print_r($response);
        //        die;
        return $response;
    }
    
    /**
	 * Function to fetch all site data based on module
	 */
	public function initSiteRelatedData($idsite = "") {
        if(empty($idsite)){
            return;
        }
        $this->site_name = $this->larvalsurveillance_model->getSitename ( $idsite );
		$this->site_details = $this->larvalsurveillance_model->getSelectedSitedetails ( $idsite );
        $this->exc_site = $this->site_model->getSelectedExistingSite ( $idsite );
        $this->zone_name = $this->larvalsurveillance_model->getSelectedZonename ( $this->site_details ['idzone'] );
    }
}

/* End of file corvidlab.php */
/* Location: ./application/controllers/corvidlab.php */