<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Disposition extends CI_Controller {
	public $idlocation = "";
	public $flag = "";
	
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		$this->load->helper('language');
		$this->load->model ( 'disposition_model' );
		$this->statuses = $this->disposition_model->getStatuses ();
		
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
                
		if ($this->session->userdata ( 'logged_in' )) {
			$this->idlocation = $this->session->userdata ( 'idlocation' );
		}
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			redirect ( base_url () . "disposition/getdisposition" );
		}
	}
	
	/**
	 * Function to add a new disposition
	 */
	public function adddisposition() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->form_validation->set_rules ( 'disposition', $this->lang->line('dspstns_hdng'), 'trim|required' );
			$this->form_validation->set_rules ( 'state', $this->lang->line('mmbr_mgmt_is_actv'), 'trim' );
			
			$req = $this->input->post ( 'iddispositions' );
			
			if (! empty ( $req ))
				$this->flag = $this->disposition_model->getDispositionData ( $req );
			
			if ($this->form_validation->run () == FALSE) {
				$this->load->view ( 'dispositions/add_disposition', $this->flag );
			} else {
				$flag_1 = $this->disposition_model->adddisposition ( $req );
				
				if (! empty ( $flag_1 ) && empty ( $req ))
					$this->flag ['msg'] = "success";
				else if (! empty ( $flag_1 ) && ! empty ( $req ))
					$this->flag ['msg'] = "update";
				else
					$this->flag ['msg'] = "error";
				$this->flag['app_lang'] = $this->app_lang;
				$this->load->view ( 'dispositions/add_disposition', $this->flag );
			}
		}
	}
	
	/**
	 * Function to show edit disposition
	 */
	public function adddispositionview() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
            $data['app_lang'] = $this->app_lang;
			$this->load->view ( 'dispositions/add_disposition', $data);
		}
	}
	
	/*
	 * pop up edit
	 */
	public function showeditpop() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get_post ( 'id' );
			$data = array ();
			
			if (empty ( $req ))
				redirect ( base_url () . "disposition/getdisposition" );
			
			$flag = $this->disposition_model->getDispositionData ( $req );
			$flag['app_lang'] = $this->app_lang;
			// print'<pre>';
			// print_r($flag);
			// die;
			$this->load->view ( 'dispositions/add_disposition', $flag );
		}
	}
	
	/**
	 * Function to delete disposition
	 */
	public function deletedisposition() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->disposition_model->deleteDisposition ();
			
			$msg = "";
			
			if ($flag)
				$msg = "success";
			else
				$msg = "error";
			
			redirect ( base_url () . 'disposition/getdisposition?del=' . $msg );
		}
	}
	
	/**
	 * Function to activate disposition
	 */
	public function activedisposition() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->disposition_model->activeDisposition ();
			
			$msg = "";
			
			if ($flag)
				$msg = "activated";
			else
				$msg = "error";
			
			redirect ( base_url () . "disposition/getdisposition?msg=" . $msg );
		}
	}
	
	/**
	 * Function to deactivate disposition
	 */
	public function deactivedisposition() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->disposition_model->deactiveDisposition ();
			
			$msg = "";
			
			if ($flag)
				$msg = "deactivated";
			else
				$msg = "error";
			
			redirect ( base_url () . "disposition/getdisposition?msg=" . $msg );
		}
	}
	
	/**
	 * Function to display List Of dispositions
	 */
	public function getdisposition($grid = '', $msg = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$columns = array (
					0 => array (
							'name' => $this->lang->line('dspstns_name'),
							'db_name' => 'disposition',
							'header' => $this->lang->line('dspstns_name'),
							'group' => $this->lang->line('sidebar_mntnc_dspstns'),
							'required' => TRUE,
							'unique' => TRUE,
							'form_control' => 'text_long',
							'type' => 'string' 
					),
					1 => array (
							'name' => $this->lang->line('mmbr_mgmt_is_actv'),
							'db_name' => 'state',
							'header' => $this->lang->line('mmbr_mgmt_is_actv'),
							'group' => $this->lang->line('dspstns_hdng'),
							'required' => TRUE,
							'form_control' => 'text_long',
							'required' => TRUE 
					)
					// 'type' => '1-n'
					 
			);
			
			$params = array (
					'id' => 'iddispositions',
					'table' => 'dispositions',
					'url' => 'disposition/getdisposition',
					'uri_param' => $grid,
					'columns' => $columns,
					'order' => array (
							0 => 'asc' 
					),
					'filters' => array (
							0 => array (
									'value' => $this->idlocation 
							) 
					),
					'msc_url' => array (
							'excel_url' => base_url () . 'disposition/toExcelAll',
							'pdf_url' => base_url () . 'disposition/toPdfAll',
							'text' => $this->lang->line('dspstns_hdng') 
					) 
			);
			$newdata = array (
					'url' => base_url () . $params ['url'] . '#' . $params ['id'] . '=' . $grid 
			);
			
			$this->session->set_userdata ( $newdata );
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('dspstns_hdng'),
					'page' => "disposition",
                    'app_lang' => $this->app_lang 
			);
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			
			// Pass grid to the view
            $data = (object)array();
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			$data->msg = $msg;
			$data->statuses = $this->statuses;
			
			$this->load->view ( 'dispositions/dispositions', $data );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function toExcelAll() {
		$query ['data'] = $this->disposition_model->listDispositions ();
		
		$this->load->view ( 'dispositions/excel_view', $query );
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
		$this->load->helper ( 'pdf_helper' ); // Load helper
		$query ['data'] = $this->disposition_model->listDispositions ();
		
		$data = $this->load->view ( 'dispositions/pdf_view', $query, true );
		// print'<pre>';
		// print_r($data);
		// die;
		create_pdf ( $data, $this->lang->line('sidebar_mntnc_dspstns') ); // Create pdf
	}
	
	/**
	 * Function to check disposition existence
	 * This function is called during Ajax process
	 */
	public function checkDuplicate($str = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$str = $this->input->post ( 'disposition' );
			
			$flag = $this->disposition_model->disExist ( $str );
			
			if ($flag) {
				$this->form_validation->set_message ( 'disCheck', $this->lang->line('err_msg_dspstns_alrdy_exsts') );
				echo $this->lang->line('err_msg_dspstns_alrdy_exsts');
				die ();
			}
		}
	}
}

/* End of file disposition.php */
/* Location: ./application/controllers/disposition.php */