<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Arbovirallab extends CI_Controller {
	public $trap_name = "";
	public $date_selected = "";
	public $species = "";
	public $assay = "";
	public $result = "";
	public $labtechnician = "";
	public $virus_type = "";
	public $trap_count = "";
	public $idlocation = "";
	public $app_lang;
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 *
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		$this->load->helper('language');
		$this->load->model ( 'arbovirallab_model' );
		$this->load->model ( 'adultsurveillance_model' );
		$this->load->model ( 'trap_model' );
		$this->load->model ( 'zone_model' );
        $this->load->model ( 'treatment_model' );
        
        if ($this->session->userdata ( 'idlocation' ))
			$this->idlocation = $this->session->userdata ( 'idlocation' );
            
		$this->trap_name = $this->adultsurveillance_model->getFilteredTrapname ();
		$this->species = $this->treatment_model->getSpecies ( $this->idlocation );
		$this->assay = $this->arbovirallab_model->getAssay ();
		$this->result = $this->arbovirallab_model->getArbovirallabResult ();
		$this->virus_type = $this->arbovirallab_model->getDetectedVirus ();
		$this->arbovirallabtechnician = $this->arbovirallab_model->getArbovirallabtechnician ();
		
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			redirect ( base_url () . "arbovirallab/getarbovirallab" );
		}
	}
	
	/**
	 * Function to add a new arbovirallab
	 */
	public function addarbovirallab() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->form_validation->set_rules ( 'labassayid', 'Assay ID', 'trim|callback_arboCheck|xss_clean' );
			$this->form_validation->set_rules ( 'idtrap', $this->lang->line('trap_mgmt_trap_nme'), 'trim|required' );
			$this->form_validation->set_rules ( 'dateselected', $this->lang->line('arbvrl_actvty_date_cllctd'), 'trim|required' );
			$this->form_validation->set_rules ( 'poolsize', $this->lang->line('data_export_poolsize'), 'trim|required' );
			$this->form_validation->set_rules ( 'species', $this->lang->line('lnding_rte_spcies'), 'trim|required' );
			
			if ($this->form_validation->run () == FALSE) {
				echo "error";
				die ();
			} else {
				
				$flag = $this->arbovirallab_model->addArbovirallab ();
				$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
				$msg = "";
				
				if ($flag) {
					if (! empty ( $seturl [1] ))
						echo $seturl [0] . "?msg=saved#" . $seturl [1];
					else
						echo $seturl [0] . "?msg=saved";
					
					exit ();
					$msg = "Your data was successfully saved";
				} else
					$msg = "error";
				
				echo $msg;
			}
		}
	}
	
	/**
	 * Function to show edit arbovirallab
	 */
	public function showeditarbovirallab($Id = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get_post ( 'id' );
            $mapFlag = $this->input->get_post('mapFlag');
            $mapSite = $this->input->get_post('idsite');
			
			if (empty ( $req ))
				echo "error";
			
			$flag = $this->arbovirallab_model->getArbovirallabData ( $req );
            
			$this->trap_name = $this->arbovirallab_model->getSelectedTrapname ( $flag ['idtrap'] );
			$this->species = $this->treatment_model->getSpecies ( $this->idlocation );
            $this->assay = $this->arbovirallab_model->getAssay();
            $this->result = $this->arbovirallab_model->getArbovirallabResult();
            $this->arbovirallabtechnician = $this->arbovirallab_model->getSelectedArbovirallabtechnician($flag['idlabtechnician']);
            $this->virus_type = $this->arbovirallab_model->getDetectedVirus();
    		$this->date_selected = $this->arbovirallab_model->getSelectedTrapInfo($flag['idtrap'],$flag['idadultsurveillance']);
			$this->trap_count = $this->arbovirallab_model->getSelectedTrapCount ( $flag ['idadultsurveillance'] );
			
			if ($flag) {
				$flag ['trap_name'] = $this->trap_name;
				$flag ['species'] = $this->species;
                $flag['assay_type'] = $this->assay;
                $flag['lab_result'] = $this->result;
                $flag['lab_technician'] = $this->arbovirallabtechnician;
				$flag ['date_selected'] = !empty($this->date_selected) && isset($this->date_selected[0]['pudate']) ? $this->date_selected[0]['pudate'] : '';
				$flag ['trap_count'] = !empty($this->trap_count) && isset($this->trap_count[0]['count']) ? $this->trap_count[0]['count'] : '';;
				$flag['virus_type'] = $this->virus_type;
				$flag ['id'] = base64_encode ( json_encode ( $req ) );
                $mapSite = $this->arbovirallab_model->getIdSite ($req);				
			}
            $flag['mapFlag'] = $mapFlag;
            $flag['app_lang'] = $this->app_lang;
            
            $mapData = $this->getAllEventsData($mapSite);
            $flag = array_merge($flag, $mapData);
            
            $this->load->view ( 'arbovirallabs/edit_arbovirallab', $flag );
		}
	}
	/**
	 * Function to save edit Adult Surveillance Values
	 */
	public function editarbovirallab() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->form_validation->set_rules ( 'idassay', 'idassay', 'trim' );
			$this->form_validation->set_rules ( 'poolsize', 'poolsize', 'trim|required' );
			$this->form_validation->set_rules ( 'species', 'species', 'trim|required' );
			$this->form_validation->set_rules ( 'testdate', 'testdate', 'trim' );
			// $this->form_validation->set_rules('assay_type', $this->lang->line('arbvrl_lab_asy_prfmnd'), 'trim|required');
			
			if ($this->form_validation->run () == FALSE) {
				$errors = $this->form_validation->error_array ();
				echo current ( $errors );
			} else {
				$flag = $this->arbovirallab_model->updateArbovirallab ();
				
				$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
				if ($flag) {
					if (! empty ( $seturl [1] ))
						echo $seturl [0] . "?msg=updated#" . $seturl [1];
					else
						echo $seturl [0] . "?msg=updated";
				} else
					echo "error";
			}
		}
	}
	
	/**
	 * Function to get Trap Info
	 */
	public function getChangeTrapInfo() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->arbovirallab_model->getTrapInfo ();
			
			if (empty ( $flag ))
				echo null;
			
			echo json_encode ( $flag );
			die ();
		}
	}
	
	/**
	 * Function to check arbo lab existence
	 */
	public function arboCheck($str = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$str = $this->input->post ( 'labassayid' );
			
			$flag = $this->arbovirallab_model->arboExist ( $str );
			
			if ($flag) {
				$this->form_validation->set_message ( 'arboCheck', $this->lang->line('err_msg_abvrllab_alrdy_exsts') );
				echo $this->lang->line('err_msg_abvrllab_alrdy_exsts');
				die ();
				return false;
			} else {
				return true;
			}
		}
	}
	
	/**
	 * Function to get Total Trap Count
	 * This function runs when date is selected from
	 * dropdown
	 */
	public function getChangeTrapCount() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->arbovirallab_model->getTrapCount ();
			
			if (empty ( $flag ))
				echo null;
			
			echo $flag;
			die ();
		}
	}
	
	/**
	 * Function to delete arbovirallab
	 */
	public function deletearbovirallab() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->arbovirallab_model->deletearbovirallab ();
			
			$msg = "";
			
			if ($flag)
				$msg = "success";
			else
				$msg = "error";
			
			$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
			if (! empty ( $seturl [1] ))
				redirect ( $seturl [0] . "?del=" . $msg . "#" . $seturl [1] );
			else
				redirect ( $seturl [0] . "?del=" . $msg );
			
			// redirect(base_url().'arbovirallab/getarbovirallab?del='.$msg);
		}
	}
	
	/**
	 * Function to display List Of arbovirallabs
	 */
	public function getarbovirallab($grid = '', $msg = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$redirect_by = $this->input->get ( 'redirect_by' );
			$adultid = $this->input->get ( 'id' );
			$filter_date = $this->input->post ( 'filter_date' );
			$columns = array (
					0 => array (
						'name' => $this->lang->line('arbvrl_labs_labassyid'),
						'db_name' => 'labassayid',
						'header' => $this->lang->line('arbvrl_labs_labassyid'),
						'group' => 'Lab',
						'form_control' => 'text_long',
						'required' => TRUE 
					),
				    1 => array (
						'name' => $this->lang->line('arbvrl_actvty_date_cllctd'),
						'db_name' => 'idadultsurveillance',
						'header' => $this->lang->line('arbvrl_actvty_date_cllctd'),
						'group' => 'Lab',
						'ref_table_id_name' => 'idadultsurveillance',
						'ref_table_db_name' => 'adultsurveillance',
						'ref_field_db_name' => 'pudate',
						'type' => '1-n' 
					),
					2 => array (
						'name' => $this->lang->line('arbvrl_labs_trap'),
						'db_name' => 'idtrap',
						'header' => $this->lang->line('arbvrl_labs_trap'),
						'group' => 'Lab',
						'ref_table_id_name' => 'idtrap',
						'ref_table_db_name' => 'traps',
						'ref_field_db_name' => 'trap',
						'type' => '1-n' 
					),
					3 => array (
						'name' => $this->lang->line('lnding_rte_spcies'),
						'db_name' => 'idmosquitospecies',
						'header' => $this->lang->line('lnding_rte_spcies'),
						'group' => 'Lab',
						'ref_table_id_name' => 'idmosquitospecies',
						'ref_table_db_name' => 'mosquitospecies',
						'ref_field_db_name' => 'idgenus',
						'ref_table_id2_name' => 'idgenus',
						'ref_table_db2_name' => 'genuses',
						'ref_field_db2_name' => 'genus',
						'form_control' => 'dropdown',
						'type' => '1-1-1' 
					),
                    4 => array(
                        'name' => $this->lang->line('arbvrl_lab_asy_prfmnd'),
                        'db_name' => 'idassaytype',
                        'header' => $this->lang->line('arbvrl_lab_asy_prfmnd'),
                        'group' => 'Lab',
                        'ref_table_id_name' => 'idassaytype',
                        'ref_table_db_name' => 'assaytypes',
                        'ref_field_db_name' => 'assaytype',
                        'form_control' => 'text_long',
                        'required' => TRUE,
                        'type' => '1-n'
                        ),
                    5 => array(
                        'name' => $this->lang->line('sntl_chkn_mgmt_rslt'),
                        'db_name' => 'idlabresult',
                        'header' => $this->lang->line('sntl_chkn_mgmt_rslt'),
                        'group' => 'Lab',
                        'ref_table_id_name' => 'idlabresult',
                        'ref_table_db_name' => 'labresults',
                        'ref_field_db_name' => 'labresult',
                        'required' => TRUE,
                        'form_control' => 'text_long',
                        'type' => '1-n'
                        ),
                    6 => array(
                        'name' => $this->lang->line('arbvrl_labs_labtech'),
                        'db_name' => 'idlabtechnician',
                        'header' => $this->lang->line('arbvrl_labs_labtech'),
                        'group' => 'Lab',
                        'ref_table_id_name' => 'iduser',
                        'ref_table_db_name' => 'users',
                        'ref_field_db_name' => 'firstname',
                        'ref_field_2_db_name' => 'middlename',
                        'ref_field_3_db_name' => 'lastname',
                        'ref_field_type' => 'string',
                        'form_control' => 'text_long',
                        'required' => TRUE,
                        'type' => '1-1+2+3'
                    ),
					 7 => array(
   					 'name' => "testdate",
   					 'db_name' => 'testdate',
   					 'header' => "testdate",
   					 'group' => 'Lab'
				    )
                    //,
//                    7 => array(
//    					 'name' => $this->lang->line('arbvrl_actvty_date_tstd'),
//    					 'db_name' => 'testdate',
//    					 'header' => $this->lang->line('arbvrl_actvty_date_tstd'),
//    					 'group' => 'Lab'
//    					 //'type' => '1-1-1'
//				    ),
                
            );
			
			$commands ['delete'] ['toolbar'] = FALSE;
			$columnByLocation = array();
            
            //If location is 37 i.e. for Sutter 
            if($this->session->userdata('idlocation') == '37')
            {
                $columnByLocation = array(0,1,2,3);
            }
            else
            {
                $columnByLocation = array(0,1,2,3,4,5,6);
            }
            
			$params = array (
					'id' => 'idarbovirallab',
					'table' => 'arbovirallabs',
					'url' => 'arbovirallab/getarbovirallab',
					'uri_param' => $grid,
					'columns' => $columns,
					'order' => array (
							1 => 'desc' 
					),
					'filter_date' => ! empty ( $filter_date ) ? $filter_date : '2',
					'filters' => array (
							0 => array (
									'value' => $this->idlocation 
							) 
					),
					'columns_visible' => $columnByLocation,
					'commands' => $commands,
					'ajax' => TRUE,
					'msc_url' => array (
							'excel_url' => base_url () . 'arbovirallab/toExcelAll',
							'pdf_url' => base_url () . 'arbovirallab/toPdfAll',
							'text' => 'Arboviralarbovirallab' 
					) 
			);
			
			if (! empty ( $grid )) {
				$newdata = array (
						'url' => base_url () . $params ['url'] . '#' . $params ['id'] . '=' . urlencode ( $grid ) 
				);
			} else {
				$newdata = array (
						'url' => base_url () . $params ['url'] 
				);
			}
			
			$this->session->set_userdata ( $newdata );
			
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_data_entry_labs'),
                    'page' => "arbovirallab",
                    'app_lang' => $this->app_lang
			);
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			
			// Pass grid to the view
            $data = (object)array();
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			$data->msg = $msg;
			$data->mapdata = base_url () . "arbovirallab/showmap";
			$data->redirect_by = ! empty ( $redirect_by ) ? $adultid : '';
			
			$this->load->view ( 'arbovirallabs/arbovirallabs', $data );
		}
		$this->load->view ( 'footer' );
	}
	public function showmap() {
		$query ['data'] = $this->arbovirallab_model->getMapdata ();
		$query ['user_loc'] = $this->adultsurveillance_model->getUserLoc ();
		$query ['zone_loc'] = $this->zone_model->getZoneCord ();
		$query ['googlezoom'] = $this->session->userdata ( 'googlezoom' );
		$this->load->view ( 'arbovirallabs/map_view', $query );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function getarbovirallabdata() {
		$id = $this->input->post ( 'idarbovirallab' );
		
		if (empty ( $id )) {
			echo "error";
			exit ();
		}
		
		$data = $this->arbovirallab_model->getArbovirallabData ( $id );
		
		echo json_encode ( $data );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function history() {
		$req = $this->input->get_post ( 'x_s_' );
		
		if (empty ( $req ))
			redirect ( base_url () . "arbovirallab/getarbovirallab" );
		
		$data1 = $this->arbovirallab_model->getHistory ( $req );
		
		$id = $data1 [0] ['idarbovirallab'];
		$total_count = 0;
		$i = 0;
		foreach ( $data1 as $key => $val ) {
			echo $val ['idarbovirallab'] . " " . $id . "<br>";
			if ($val ['idarbovirallab'] == $id) {
				$total_count += $val ['count'];
				$data [$i] [] = $val;
			} else {
				$data [$i] ['total'] = $total_count;
				$total_count = 0;
				$i ++;
				$data [$i] [] = $val;
				$id = $val ['idarbovirallab'];
				$total_count += $val ['count'];
			}
			$data [$i] ['total'] = $total_count;
		}
		// $data2 = $this->arbovirallab_model->getSpeciesCountbydate($req);
		
		$this->load->view ( 'arbovirallabs/history_view', $data );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function collectedSpecies() {
		$req = $this->input->get_post ( 'x_s_' );
		
		if (empty ( $req ))
			redirect ( base_url () . "arbovirallab/getarbovirallab" );
		
		$query ['data'] = $this->arbovirallab_model->getSpeciesCount ( $req );
		
		$this->load->view ( 'arbovirallabs/allspecies_view', $query );
	}
	
	/**
	 * Function to generate pools report
	 */
	public function getPoolsReport() {
		$this->load->helper ( 'pdf_helper' ); // Load helper
		
		$requestData = $this->input->get ( 'requestData' );
		$requestData = ! empty ( $requestData ) ? json_decode ( $requestData, TRUE ) : '';
		// print'<pre>';
		// print_r($requestData);
		// die;
		$query ['data'] = $this->arbovirallab_model->getPoolsReport ( $requestData );
		$query ['location'] = $this->arbovirallab_model->getLocationData ();
		$query ['location'] = ! empty ( $query ['location'] [0] ) ? $query ['location'] [0] : '';
		$data = $this->load->view ( 'arbovirallabs/pools_report_view', $query, true );
		// print'<pre>';
		// print_r($data);
		// die;
		create_pdf_l ( $data, $this->lang->line('arbvrl_lab_pools_rprt')); // Create pdf
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function toExcelAll() {
		$query ['data'] = $this->arbovirallab_model->listArbovirallabs ();
		
		$this->load->view ( 'arbovirallabs/excel_view', $query );
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
		$this->load->helper ( 'pdf_helper' ); // Load helper
		$query ['data'] = $this->arbovirallab_model->listArbovirallabs ();
		
		$data = $this->load->view ( 'arbovirallabs/pdf_view', $query, true );
		// $data = file_get_contents(htmlentities($dd)); // Pass the url of html report
		
		create_pdf_l ( $data, $this->lang->line('sidebar_data_entry_labs') ); // Create pdf
	}
	public function toXMLAll() {
		$data = $this->arbovirallab_model->listArbovirallabs ();
		$string = '<?xml version="1.0" encoding="utf-8"?><Tablix1><Textbox324 Textbox66="03/25/2013 - 04/01/2013" Textbox188="McLean Mosquito Abatement" /></Tablix1>';
		
		$xml = new SimpleXMLElement ( $string );
		Header ( 'Content-type: text/xml' );
		header ( 'Content-type: text/xml' );
		header ( 'Content-Disposition: attachment; filename="'.$this->lang->line('arbvrl_lab_pools_rprt').'.xml"' );
		
		echo $xml->asXML ();
	}
	public function toCsvAll() {
		$data = $this->arbovirallab_model->listArbovirallabs ();
		$this->download_send_headers ( "data_export_" . date ( "Y-m-d" ) . ".csv" );
		echo $this->array2csv ( $data );
	}
	public function toImageAll() {
		$image = new Imagick ();
		$image->readimageblob ( $blob );
		echo '<img src="data:image/png;base64,' . base64_encode ( $image->getimageblob () );
	}
	public function array2csv(array &$array) {
		if (count ( $array ) == 0) {
			return null;
		}
		ob_start ();
		$df = fopen ( "php://output", 'w' );
		fputcsv ( $df, array_keys ( reset ( $array ) ) );
		foreach ( $array as $row ) {
			fputcsv ( $df, $row );
		}
		fclose ( $df );
		return ob_get_clean ();
	}
	public function download_send_headers($filename) {
		header ( "Pragma: public" );
		header ( "Expires: 0" );
		header ( "Cache-Control: must-revalidate, post-check=0, pre-check=0" );
		header ( "Content-Type: application/force-download" );
		header ( "Content-Type: application/octet-stream" );
		header ( "Content-Type: application/download" );
		header ( "Content-Disposition: attachment;filename={$filename}" );
		header ( "Content-Transfer-Encoding: binary" );
	}
	public function toWordAll() {
		header ( "Content-Type: application/vnd.ms-word" );
		header ( "Expires: 0" );
		header ( "Cache-Control:  must-revalidate, post-check=0, pre-check=0" );
		header ( "Content-disposition: attachment; filename=\"mydocument_name.doc\"" );
		
		// $query['data'] = $this->arbovirallab_model->listArbovirallabs();
		
		$output = $this->getUrlData ( base_url () . "arbovirallab/getarbovirallab" );
		
		echo $output;
		exit ();
	}
	public function toWordAll_html() {
		$this->load->helper ( 'htmltodoc_helper' );
		
		create_htmltodoc ( base_url () . "arbovirallab/getarbovirallab", str_replace(' ', '', $this->lang->line('arbvrl_labs_rprt')) );
	}
	public function image() {
		$this->load->helper ( 'pdf_helper' ); // Load helper
		
		$query ['data'] = $this->arbovirallab_model->listArbovirallabs ();
		
		$data = $this->load->view ( 'arbovirallabs/pdf_view', $query, true );
		// $data = file_get_contents(htmlentities($dd)); // Pass the url of html report
		
		$pdf = return_pdf ( $data, str_replace(' ', '', $this->lang->line('arbvrl_labs_rprt')) ); // Create pdf
		
		$im = new imagick ( $pdf );
		$im->setImageFormat ( "jpg" );
		$img_name = time () . '.jpg';
		$im->setSize ( 800, 600 );
		$im->writeImage ( $img_name );
		$im->clear ();
		$im->destroy ();
		// imagedestroy($image);
	}
	public function mhtml() {
		// $data = file_get_contents("http://localhost/geopro/arbovirallab/toPdfAll");
		$filename = "test.html";
		
		// save the file...
		// $fh = fopen($filename,"w");
		// fwrite($fh,$data);
		// fclose($fh);
		//
		$data = file_get_contents ( $filename );
		
		$fileSize = filesize ( $filename );
		
		// Output headers.
		
		header ( "Content-Type: text/html" );
		header ( "Content-Length: " . $fileSize );
		header ( "Content-Disposition: attachment; filename=" . $filename );
		echo "<a href='" . base_url () . "test.html'>aa</a>";
		// Output file.
		readfile ( $filename );
		
		// echo $data;
	}
	
	/**
	 * Function to view page at on click popup
	 */
	public function showaddarboviral() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$adultid = $this->input->get ( 'adultid' );
			$mapFlag = $this->input->get_post ( 'mapFlag' );
            $idSite = $this->input->get('idsite');
            
			$adultdata = array ();
			$dateselected = "";
			$ttl_cmnt = "";
			$testdate = "";
			$comments = "";
			if (! empty ( $adultid ))
				$adultdata = $this->adultsurveillance_model->getAdultsurveillanceData ( $adultid );
			
			if (! empty ( $adultdata )) {
				$trapdet = $this->trap_model->getTrapData ( $adultdata ['idtrap'] );
				$this->trap_name = $this->arbovirallab_model->getTrapname ( $adultdata ['idtrap'] );
				$data = $this->arbovirallab_model->getTrapInfo ( $adultdata ['idtrap'] );
				$dateselected = (! empty ( $data ['str'] ) && isset ( $data ['str'] )) ? $data ['str'] : '';
				$ttl_cmnt = $this->arbovirallab_model->getSelectedTrapCount ( $adultid );
				$this->arbovirallabtechnician = $this->arbovirallab_model->getSelectedArbovirallabtechnician ( $adultdata ['idinspector'] );
				$testdate = date ( 'm/d/Y', strtotime ( $adultdata ['pudate'] ) );
				$comments = ! empty ( $adultdata ['comments'] ) ? $adultdata ['comments'] : '';
			}
			
			$data_1 = array (
					'trap_name' => $this->trap_name,
					'dateselected' => $dateselected,
					'ttl_cmnt' => ! empty ( $ttl_cmnt ) ? $ttl_cmnt : '0',
					'species' => $this->species,
					'comments' => $comments ,
                    'app_lang' => $this->app_lang
			);
            if($this->session->userdata('idlocation') != $this->session->userdata('sutterIdLocation')){
                $data_2 = array (
					 'testdate' => $testdate,
        			 'assay' => $this->assay,
        			 'result' => $this->result,
        			 'labtechnician' => $this->arbovirallabtechnician,
        			 'virus_type' => $this->virus_type 
    			);
                $data_1 = array_merge($data_1, $data_2);
            }			
			$data_1['mapFlag'] = $mapFlag;
            
            $eventData = $this->getAllEventsData($idSite);
            $data_1 = array_merge($data_1, $eventData);
            //print'<pre>';
//            print_r($data_1);
//            die;
			$this->load->view ( 'arbovirallabs/add_arbovirallab', $data_1 );
		}
	}
    
    /**
     * Function to fetch all site data based on module
     */
    public function getAllEventsData($idsite = "")
    {
        $params = array('idsite' => $idsite, 'idlocation' => $this->session->userdata('idlocation'));

        $this->load->library('common', $params);

        $response = $this->common->getAllEventsData();
        //print'<pre>';
        //        print_r($response);
        //        die;
        return $response;
    }
}

/* End of file arbovirallab.php */
/* Location: ./application/controllers/arbovirallab.php */