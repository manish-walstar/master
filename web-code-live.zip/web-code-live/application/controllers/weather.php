<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');
date_default_timezone_set('UTC');
class Weather extends CI_Controller
{
    public $temperature = "";
    public $humidity = "";
    public $windspeed = "";
    public $cloudcover = "";
    public $hightide_date = "";
    public $lowtide_date = "";
    public $hightide_time = "";
    public $lowtide_time = "";
    public $idlocation;
    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * http://example.com/user
     * - or -
     * http://example.com/user/index
     * - or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * 
     * @see http://codeigniter.com/user_guide/general/urls.html
     */
    public function __construct()
    {
        parent::__construct();

        $this->load->helper('language');
        $this->load->model('weather_model');
        $this->load->model('adultsurveillance_model');
        $this->load->model('zone_model');
        $this->load->model('treatment_model');

        if ($this->session->userdata('idlocation'))
            $this->idlocation = $this->session->userdata('idlocation');

        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app", $this->app_lang);

        $this->hightide_date = date('m/d/Y');
        $this->lowtide_date = date('m/d/Y');

        $this->hightide_time = date('h:i:s A');
        $this->lowtide_time = date('h:i:s A');
    }
    public function index()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect(base_url());
        } else {

            redirect(base_url() . "weather/getweather");
        }
    }

    /**
     * Function to Show Add Member Form
     */
    public function showaddlandingrate()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect(base_url());
        } else {

            $this->inspector = $this->landingrate_model->getInspectors();
            $this->trap_name = $this->landingrate_model->getTrapname();
            $this->temperature = $this->landingrate_model->getTemprange();
            $this->humidity = $this->landingrate_model->getHumidityrange();
            $this->windspeed = $this->landingrate_model->getWindspeed();
            $this->cloudcover = $this->landingrate_model->getCloudcoverage();
            $this->species = $this->landingrate_model->getSpecies();

            $data_1 = array(
                'username' => $this->session->userdata('username'),
                'logstatus' => "logout",
                'title' => $this->lang->line('lnding_rate_hdng'),
                'page' => "landingrate",
                'trap_name' => $this->trap_name,
                'inspector' => $this->inspector,
                'temprange' => $this->temperature,
                'humidity' => $this->humidity,
                'windspeed' => $this->windspeed,
                'cloudcover' => $this->cloudcover,
                'species' => $this->species,
                'app_lang' => $this->app_lang);

            $this->load->view('header', $data_1);
            $this->load->view('left_sidebar', $data_1);
            $this->load->view('landingrates/add_landingrate', $data_1);
        }
        $this->load->view('footer');
    }

    /**
     * Function to add a new landingrate
     */
    public function addweather()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect(base_url());
        } else {
            $data_1 = array(
                'sensor_name' => $this->weather_model->getSensorname(),
                'weatherconditions' => $this->treatment_model->getWheatherCondtn(),
                'temp_range' => $this->weather_model->getTemprange(),
                'humidity' => $this->weather_model->getHumidityrange(),
                'wind_speed' => $this->weather_model->getSelectedWindspeed(),
                'cloud_cover' => $this->weather_model->getCloudcoverage(),
                'hightide_date' => $this->hightide_date,
                'lowtide_date' => $this->lowtide_date,
                'hightide_time' => date('h:i A', time()),
                'lowtide_time' => date('h:i A', time()),
                'app_lang' => $this->app_lang);

            $this->form_validation->set_rules('sensor_name', $this->lang->line('whthr_snsr_name'),
                'trim|required');
            $this->form_validation->set_rules('date', $this->lang->line('whthr_date_name'),
                'trim|required');
            $this->form_validation->set_rules('rainfall', 'Rain Fall', 'trim|required');
            $this->form_validation->set_rules('winddegree', 'Wind Degree', 'trim|numeric');
            $this->form_validation->set_rules('hightide_height', $this->lang->line('data_export_hghtd_height'),
                'trim');
            $this->form_validation->set_rules('hightide_date', $this->lang->line('high_tide_date'),
                'trim');
            $this->form_validation->set_rules('hightide_time', $this->lang->line('high_tide_time'),
                'trim');
            $this->form_validation->set_rules('lowtide_height', $this->lang->line('data_export_lwtd_height'),
                'trim');
            $this->form_validation->set_rules('lowtide_date', $this->lang->line('data_export_lwtd_date'),
                'trim');
            $this->form_validation->set_rules('lowtide_time', $this->lang->line('whthr_lwtde_time'),
                'trim');

            if ($this->form_validation->run() == false) {
                $data_1['msg'] = "error";
            } else {

                $flag = $this->weather_model->addweather();

                if ($flag)
                    $data_1['msg'] = "success";
                else
                    $data_1['msg'] = "error";
            }
            $this->load->view('weathers/add_weather', $data_1);
        }
    }

    /**
     * Function to show edit landing rate
     */
    public function showeditweather()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect(base_url());
        } else {
            $req = $this->input->get_post('id');
            $mapFlag = $this->input->get_post('mapFlag');
            $mapSite = "";
            if (!empty($req)) {

                $flag = $this->weather_model->getWeather($req);
                $mapSite = $this->weather_model->getIdSite($req);
                $this->sensor_name = $this->weather_model->getSensorname($flag['idweathersensor']);
                $this->weatherconditions = $this->treatment_model->getWheatherCondtn($flag['idweatherconditions']);
                $this->temp_range = $this->weather_model->getTemprange($flag['idtemprange']);
                $this->humidity = $this->weather_model->getHumidityrange($flag['idhumidityrange']);
                $this->wind_speed = $this->weather_model->getSelectedWindspeed($flag['idwindspeed']);
                $this->cloud_cover = $this->weather_model->getCloudcoverage($flag['idcloudcoverage']);

                if ($flag) {
                    $flag['sensor_name'] = $this->sensor_name;
                    $flag['weatherconditions'] = $this->weatherconditions;
                    $flag['cloud_cover'] = $this->cloud_cover;
                    $flag['wind_speed'] = $this->wind_speed;
                    $flag['temp_range'] = $this->temp_range;
                    $flag['idhumidityrange'] = $this->humidity;
                }

                $flag['app_lang'] = $this->app_lang;
                $flag['mapFlag'] = $mapFlag;
                $mapData = $this->getAllEventsData($mapSite);
                $flag = array_merge($flag, $mapData);
                $this->load->view('weathers/edit_weather', $flag);
            }
        }
    }

    /**
     * Function to save edit Adult Surveillance Values
     */
    public function editweather()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect(base_url());
        }

        $id = $this->input->get_post('id');
        $flag['msg'] = '';
        if (empty($id)) {
            $flag['msg'] = "error";
        } else {
            $flag = $this->weather_model->getWeather($id);

            $this->sensor_name = $this->weather_model->getSensorname($flag['idweathersensor']);
            $this->weatherconditions = $this->treatment_model->getWheatherCondtn($flag['idweatherconditions']);
            $this->temp_range = $this->weather_model->getTemprange($flag['idtemprange']);
            $this->humidity = $this->weather_model->getHumidityrange($flag['idhumidityrange']);
            $this->wind_speed = $this->weather_model->getSelectedWindspeed($flag['idwindspeed']);
            $this->cloud_cover = $this->weather_model->getCloudcoverage($flag['idcloudcoverage']);

            if ($flag) {
                $flag['sensor_name'] = $this->sensor_name;
                $flag['weatherconditions'] = $this->weatherconditions;
                $flag['cloud_cover'] = $this->cloud_cover;
                $flag['wind_speed'] = $this->wind_speed;
                $flag['temp_range'] = $this->temp_range;
                $flag['idhumidityrange'] = $this->humidity;
            }
            $this->form_validation->set_rules('sensor_name', $this->lang->line('whthr_snsr_name'),
                'trim|required');
            $this->form_validation->set_rules('date', $this->lang->line('whthr_date_name'),
                'trim|required');
            $this->form_validation->set_rules('rainfall', 'Rail Fall', 'trim|required');
            $this->form_validation->set_rules('winddegree', 'Wind Degree', 'trim|numeric');
            $this->form_validation->set_rules('hightide_height', $this->lang->line('data_export_hghtd_height'),
                'trim');
            $this->form_validation->set_rules('hightide_date', $this->lang->line('high_tide_date'),
                'trim');
            $this->form_validation->set_rules('hightide_time', $this->lang->line('high_tide_time'),
                'trim');
            $this->form_validation->set_rules('lowtide_height', $this->lang->line('data_export_lwtd_height'),
                'trim');
            $this->form_validation->set_rules('lowtide_date', $this->lang->line('data_export_lwtd_date'),
                'trim');
            $this->form_validation->set_rules('lowtide_time', $this->lang->line('whthr_lwtde_time'),
                'trim');

            if ($this->form_validation->run() == false) {
                $flag['msg'] = "error";
            } else {
                $flags = $this->weather_model->updateWeather($id);

                if ($flags)
                    $flag['msg'] = "update";
                else
                    $flag['msg'] = "error";
            }
            $flag['app_lang'] = $this->app_lang;
            $this->load->view('weathers/edit_weather', $flag);
        }
    }

    /**
     * Function to delete landingrate
     */
    public function deleteweather()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect(base_url());
        } else {
            $flag = $this->weather_model->deleteweather();

            $msg = "";

            if ($flag)
                $msg = "success";
            else
                $msg = "error";
            $seturl = explode("#", $this->session->userdata('url'));
            if (!empty($seturl[1]))
                redirect($seturl[0] . "?del=" . $msg . "#" . $seturl[1]);
            else
                redirect($seturl[0] . "?del=" . $msg);
            // redirect(base_url().'weather/getweather?del='.$msg);
        }
    }

    /**
     * Function to display List Of adultsurveillances
     */
    public function getweather($grid = '', $msg = '')
    {
        if (!$this->session->userdata('logged_in')) {
            redirect(base_url());
        } else {
            $filter_date = $this->input->post('filter_date');
            $columns = array(
                0 => array(
                    'name' => $this->lang->line('prdct_ovrvw_nme'),
                    'db_name' => 'sensor_name',
                    'header' => $this->lang->line('prdct_ovrvw_nme'),
                    'group' => 'weather',
                    'ref_field_type' => 'string',
                    'form_control' => 'text_long',
                    'required' => true),
                1 => array(
                    'name' => $this->lang->line('wthr_date'),
                    'db_name' => 'date',
                    'header' => $this->lang->line('wthr_date'),
                    'group' => 'weather',
                    'ref_field_type' => 'string',
                    'form_control' => 'text_long',
                    'required' => true),
                2 => array(
                    'name' => $this->lang->line('data_export_wthr_cndtn'),
                    'db_name' => 'idweatherconditions',
                    'header' => $this->lang->line('data_export_wthr_cndtn'),
                    'group' => 'weather',
                    'ref_table_db_name' => 'weatherconditions',
                    'ref_table_id_name' => 'idweathercondition',
                    'ref_field_db_name' => 'weathercondition',
                    'ref_field_type' => 'string',
                    'form_control' => 'text_long',
                    'required' => true,
                    'type' => '1-n'),
                3 => array(
                    'name' => $this->lang->line('data_export_rnfll'),
                    'db_name' => 'rainfall',
                    'header' => $this->lang->line('data_export_rnfll'),
                    'group' => 'weather',
                    'ref_field_type' => 'string',
                    'form_control' => 'text_long',
                    'required' => true),
                4 => array(
                    'name' => $this->lang->line('wthr_data_wind'),
                    'db_name' => 'winddegree',
                    'header' => $this->lang->line('wthr_data_wind'),
                    'group' => 'weather',
                    'ref_table_db_name' => 'windspeeds',
                    'ref_table_id_name' => 'idwindspeed',
                    'ref_field_db_name' => 'windspeed',
                    'ref_field_type' => 'string',
                    'form_control' => 'text_long',
                    'required' => true,
                    'strconcat' => array(
                        '&deg;',
                        '@',
                        $this->lang->line('cmn_unt_mph')),
                    'type' => '1-(1)-2'),
                5 => array(
                    'name' => $this->lang->line('wthr_ambnt_tmp'),
                    'db_name' => 'idtemprange',
                    'header' => $this->lang->line('wthr_ambnt_tmp'),
                    'group' => 'weather',
                    'ref_table_db_name' => 'tempranges',
                    'ref_table_id_name' => 'idtemprange',
                    'ref_field_db_name' => 'temprange',
                    'ref_field_type' => 'string',
                    'form_control' => 'text_long',
                    'required' => true,
                    'type' => '1-n'),
                6 => array(
                    'name' => $this->lang->line('adlt_srvlnc_humdity'),
                    'db_name' => 'idhumidityrange',
                    'header' => $this->lang->line('adlt_srvlnc_humdity'),
                    'ref_table_db_name' => 'humidityranges',
                    'ref_table_id_name' => 'idhumidityrange',
                    'ref_field_db_name' => 'humidityrange',
                    'ref_field_type' => 'string',
                    'form_control' => 'text_long',
                    'required' => true,
                    'type' => '1-n'));

            $commands['delete']['toolbar'] = false;

            $params = array(
                'id' => 'idweather',
                'table' => 'weather',
                'url' => 'weather/getweather',
                'uri_param' => $grid,
                'columns' => $columns,
                'order' => array(1 => 'desc'),
                'filter_date' => !empty($filter_date) ? $filter_date : '2',
                'filters' => array(0 => array('value' => $this->idlocation)),
                // 'columns_visible' => array(0,1,2),
                'commands' => $commands,
                'ajax' => true,
                'msc_url' => array(
                    'excel_url' => base_url() . 'landingrate/toExcelAll',
                    'pdf_url' => base_url() . 'landingrate/toPdfAll',
                    'text' => 'Weather'));

            $newdata = array('url' => base_url() . $params['url'] . '#' . $params['id'] .
                    '=' . $grid);

            $this->session->set_userdata($newdata);

            $this->load->library('carbogrid', $params);

            if ($this->carbogrid->is_ajax) {
                $this->carbogrid->render();
                return false;
            }

            $data_1 = array(
                'username' => $this->session->userdata('username'),
                'logstatus' => "logout",
                'title' => $this->lang->line('wthr_data'),
                'page' => "weather",
                'app_lang' => $this->app_lang);
            $this->load->view('header', $data_1);
            $this->load->view('left_sidebar', $data_1);

            // Pass grid to the view
            $data = (object)array();
            $data->page = 'grid_single';
            $data->page_grid = $this->carbogrid->render();
            $data->msg = $msg;
            $data->mapdata = base_url() . "weather/showmap";

            $this->load->view('weathers/weathers', $data);
        }
        $this->load->view('footer');
    }
    public function showmap()
    {
        $query['data'] = $this->weather_model->getMapdata();
        // print'<pre>';
        // print_r($query['data']);
        // die;
        $query['user_loc'] = $this->adultsurveillance_model->getUserLoc();
        $query['zone_loc'] = $this->zone_model->getZoneCord();
        $query['googlezoom'] = $this->session->userdata('googlezoom');
        $this->load->view('weathers/map_view', $query);
    }

    /**
     * Function to Convert Data into Excel Sheet
     */
    public function getadultsurveillancedata()
    {
        $id = $this->input->post('idadultsurveillance');

        if (empty($id)) {
            echo "error";
            exit();
        }

        $data = $this->adultsurveillance_model->getAdultsurveillanceData($id);

        echo json_encode($data);
    }

    /**
     * Function to Convert Data into Excel Sheet
     */
    public function history()
    {
        $req = $this->input->get_post('x_s_');

        if (empty($req))
            redirect(base_url() . "landingrate/getlandingrate");

        $data1 = $this->adultsurveillance_model->getHistory($req);

        $id = $data1[0]['idadultsurveillance'];
        $total_count = 0;
        $i = 0;
        foreach ($data1 as $key => $val) {
            echo $val['idadultsurveillance'] . " " . $id . "<br>";
            if ($val['idadultsurveillance'] == $id) {
                $total_count += $val['count'];
                $data[$i][] = $val;
            } else {
                $data[$i]['total'] = $total_count;
                $total_count = 0;
                $i++;
                $data[$i][] = $val;
                $id = $val['idadultsurveillance'];
                $total_count += $val['count'];
            }
            $data[$i]['total'] = $total_count;
        }
        // $data2 = $this->adultsurveillance_model->getSpeciesCountbydate($req);

        $this->load->view('adultsurveillances/history_view', $data);
    }

    /**
     * Function to Convert Data into Excel Sheet
     */
    public function toExcelAll()
    {
        $query['data'] = $this->weather_model->listWeather();

        $this->load->view('weathers/excel_view', $query);
    }

    /**
     * Function to Convert Data into PDF
     */
    public function toPdfAll()
    {
        $this->load->helper('pdf_helper'); // Load helper
        $query['data'] = $this->weather_model->listWeather();
        // echo '<pre>';print_r($query['data']);die;
        $data = $this->load->view('weathers/pdf_view', $query, true);
        // $data = file_get_contents(htmlentities($dd)); // Pass the url of html report

        create_pdf($data, $this->lang->line('sidebar_data_entry_wthr')); // Create pdf
    }

    /**
     * Function to view page at on click popup
     */
    public function showaddweather()
    {
        if (!$this->session->userdata('logged_in')) {
            redirect(base_url());
        } else {
            $mapFlag = $this->input->get_post('mapFlag');
            $mapSite = $this->input->get_post('idsite');
            $data = array(
                'sensor_name' => $this->weather_model->getSensorname(),
                'weatherconditions' => $this->treatment_model->getWheatherCondtn(),
                'temp_range' => $this->weather_model->getTemprange(),
                'humidity' => $this->weather_model->getHumidityrange(),
                'wind_speed' => $this->weather_model->getSelectedWindspeed(),
                'cloud_cover' => $this->weather_model->getCloudcoverage(),
                'hightide_date' => $this->hightide_date,
                'lowtide_date' => $this->lowtide_date,
                'hightide_time' => date('h:i:s A'),
                'lowtide_time' => date('h:i:s A'),
                'app_lang' => $this->app_lang
            );
            
            $mapData = $this->getAllEventsData($mapSite);
            $data = array_merge($data, $mapData);

            $this->load->view('weathers/add_weather', $data);
        }
    }

    /**
     * Function to fetch all site data based on module
     */
    public function getAllEventsData($idsite = "")
    {
        $params = array('idsite' => $idsite, 'idlocation' => $this->session->userdata('idlocation'));

        $this->load->library('common', $params);

        $response = $this->common->getAllEventsData();
        //print'<pre>';
        //        print_r($response);
        //        die;
        return $response;
    }
}

/* End of file landingrate.php */
/* Location: ./application/controllers/landingrate.php */
