<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Sentinelchicken extends CI_Controller {
	public $existing_site = "";
	public $site_type = "";
	public $zone_name = "";
	public $state_name = "";
	public $state_list;
	public $idlocation = "";
	public $sitegroup = "";
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
        $this->load->helper('language');
		$this->load->model ( 'sentinelchicken_model' );
		$this->load->model ( 'site_model' );
		$this->load->model ( 'adultsurveillance_model' );
		$this->state_list = $this->site_model->getStatesList ();
		$this->sitegroup = $this->site_model->getSiteGroup ();
		
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		if ($this->session->userdata ( 'logged_in' )) {
			$this->idlocation = $this->session->userdata ( 'idlocation' );
		}
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			redirect ( base_url () . "sentinelchicken/getsentinelchicken" );
		}
	}
	public function getLatiLongi() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data = array (
					'states' => $this->state_list 
			);
			
			$this->load->view ( 'traps/lati_longi', $data );
		}
	}
	
	/**
	 * Function to add a new sentinelchicken
	 */
	public function addsentinelchicken() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->site_type = $this->site_model->getSitetypes ();
			$this->zone_name = $this->site_model->getZones ();
			$this->state_name = $this->site_model->getStates ();
			$this->state_list = $this->site_model->getStatesList ();
			$this->existing_site = $this->site_model->getExisting_site ();
			$this->statuses = $this->site_model->getStatuses ();
			
			$data = array (
					'site_type' => $this->site_type,
					'zone_name' => $this->zone_name,
					'state_name' => $this->state_name,
					'state_list' => $this->state_list,
					'existing_site' => $this->existing_site,
					'sitegroup' => $this->sitegroup 
			);
			
			$this->form_validation->set_rules ( 'flockname', $this->lang->line('sntnl_chkn_mgmt_flck_nme'), 'trim|required|callback_flockCheck|xss_clean' );
			$this->form_validation->set_rules ( 'site_id', $this->lang->line('whthr_snsr_site_nm'), 'trim|required' );
			$this->form_validation->set_rules ( 'idsitetype', $this->lang->line('trap_mgmt_site_type'), 'trim' );
			$this->form_validation->set_rules ( 'idzone', $this->lang->line('zone_mgmt_nme'), 'trim' );
			
			$this->form_validation->set_rules ( 'maplabel', $this->lang->line('site_mgmt_map_lbl'), 'trim' );
			$this->form_validation->set_rules ( 'address1', $this->lang->line('site_mgmt_street') . ' I', 'trim' );
			$this->form_validation->set_rules ( 'address2', $this->lang->line('site_mgmt_street') . 'II', 'trim' );
			$this->form_validation->set_rules ( 'city', $this->lang->line('site_mgmt_cty'), 'trim' );
			
			$this->form_validation->set_rules ( 'latitude', $this->lang->line('site_mgmt_lat'), 'trim|required|numeric' );
			$this->form_validation->set_rules ( 'longitude', $this->lang->line('site_mgmt_lng'), 'trim|required|numeric' );
			$this->form_validation->set_rules ( 'postalcode', $this->lang->line('site_mgmt_postl_cde'), 'trim|numeric' );
			if ($this->form_validation->run () == FALSE) {
				$data ['msg'] = "error";
                $data ['errmsg'] = validation_errors();
			} else {
				$flag = $this->sentinelchicken_model->addsentinelchicken ();
				
				if (! empty ( $flag )) {
					$data ['msg'] = "success";
				} else {
					$data ['msg'] = "error";
				}
			}
			
			$this->load->view ( 'sentinelchickens/add_sentinelchicken', $data );
		}
	}
	
	/**
	 * Function to get popup add view
	 */
	public function addsentinelchickenpop() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->site_type = $this->site_model->getSitetypes ();
			$this->zone_name = $this->site_model->getZones ();
			$this->state_name = $this->site_model->getStates ();
			$this->state_list = $this->site_model->getStatesList ();
			$this->existing_site = $this->site_model->getExisting_site ();
			$this->statuses = $this->site_model->getStatuses ();
			$data = array (
					'site_type' => $this->site_type,
					'zone_name' => $this->zone_name,
					'state_name' => $this->state_name,
					'state_list' => $this->state_list,
					'sitegroup' => $this->sitegroup,
					'existing_site' => $this->existing_site 
			);
			$this->load->view ( 'sentinelchickens/add_sentinelchicken', $data );
		}
	}
	
	/**
	 * Function to check flock name existence
	 * This function has been called on server side Validation
	 */
	public function flockCheck($str = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$str = $this->input->post ( 'flockname' );
			
			$flag = $this->sentinelchicken_model->flockExist ( $str );
			
			if ($flag) {
				$this->form_validation->set_message ( 'flockCheck', $this->lang->line('err_msg_flock_alrdy_exsts') );
				return false;
			} else {
				return true;
			}
		}
	}
	
	/**
	 * Function to check flock name existence
	 * This function is been called on Client Side Validation
	 */
	public function flockCheckClient($str = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$str = $this->input->post ( 'flockname' );
			$flag = $this->sentinelchicken_model->flockExist ( $str );
			
			if ($flag) {
				echo "error";
			} else {
				echo "success";
			}
			exit ();
		}
	}
	
	/*
	 * 8
	 *
	 *
	 */
	public function showeditpop() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get_post ( 'id' );
			$data = array ();
			$flag = $this->sentinelchicken_model->getSentinelchicken ( $req );
			$sitedetails = $this->sentinelchicken_model->getSiteDetails ( $flag ['idsite'] );
			$this->site_type = $this->sentinelchicken_model->getSelectedSitetype ( $sitedetails ['idsitetype'] );
			$this->zone_name = $this->sentinelchicken_model->getSelectedZonename ( $sitedetails ['idzone'] );
			$this->state_list = $this->site_model->getStatesList ();
			
			$this->exc_site = $this->site_model->getSelectedExistingSite ( $flag ['idsite'] );
			
			if ($flag) {
                $flag = array_merge($flag, $sitedetails);
                
				$data = array (
						'exc_site' => $this->exc_site,
						'site_type' => $this->site_type,
						'address1' => $sitedetails ['address1'],
						'address2' => $sitedetails ['address2'],
						'city' => $sitedetails ['city'],
						'state_name' => $this->state_name,
						'postalcode' => $sitedetails ['postalcode'],
						'latitude' => $flag ['latitude'],
						'longitude' => $flag ['longitude'],
						'detail' => $flag,
						'id' => $req,
						'zone_name' => $this->zone_name,
						'state_list' => $this->state_list,
                        'idstate' => !empty($sitedetails ['idstate']) ? $sitedetails ['idstate'] : 0
				);
			}
            
			$this->load->view ( 'sentinelchickens/edit_sentinelchicken', $data );
		}
	}
	
	/**
	 * Function to save edit Adult Surveillance Values
	 */
	public function editsentinelchicken() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$req = $this->input->post ( 'sentinel_id' );
			
			if (empty ( $req )) {
				$data ['msg'] = "error";
				$this->load->view ( 'sentinelchickens/edit_sentinelchicken', $data );
			}
			
			$flag = $this->sentinelchicken_model->getSentinelchicken ( $req );
			$sitedetails = $this->sentinelchicken_model->getSiteDetails ( $flag ['idsite'] );
			$this->site_type = $this->sentinelchicken_model->getSelectedSitetype ( $sitedetails ['idsitetype'] );
			$this->zone_name = $this->sentinelchicken_model->getSelectedZonename ( $sitedetails ['idzone'] );
			$this->state_name = $this->sentinelchicken_model->getStatename ( $sitedetails ['idstate'] );
			$this->state_list = $this->site_model->getStatesList ();
			
			$this->exc_site = $this->site_model->getSelectedExistingSite ( $flag ['idsite'] );
			
			if ($flag) {
                $flag = array_merge($flag, $sitedetails);
                
				$data = array (
						'exc_site' => $this->exc_site,
						'site_type' => $this->site_type,
						'address1' => $sitedetails ['address1'],
						'address2' => $sitedetails ['address2'],
						'city' => $sitedetails ['city'],
						'state_name' => $this->state_name,
						'postalcode' => $sitedetails ['postalcode'],
						'latitude' => $flag ['latitude'],
						'longitude' => $flag ['longitude'],
						'detail' => $flag,
						'id' => $req,
						'zone_name' => $this->zone_name,
						'state_list' => $this->state_list
				);
			}
            
			$this->form_validation->set_rules ( 'flockname', $this->lang->line('sntnl_chkn_mgmt_flck_nme'), 'trim|required' );
			$this->form_validation->set_rules ( 'site_id', $this->lang->line('whthr_snsr_site_nm'), 'trim|required' );
			$this->form_validation->set_rules ( 'idsitetype', $this->lang->line('trap_mgmt_site_type'), 'trim' );
			$this->form_validation->set_rules ( 'idzone', $this->lang->line('zone_mgmt_nme'), 'trim' );
			$this->form_validation->set_rules ( 'latitude', $this->lang->line('site_mgmt_lat'), 'trim|required|numeric' );
			$this->form_validation->set_rules ( 'longitude', $this->lang->line('site_mgmt_lng'), 'trim|required|numeric' );
			$this->form_validation->set_rules ( 'postalcode', $this->lang->line('site_mgmt_postl_cde'), 'trim|numeric' );
			
			if ($this->form_validation->run () == FALSE) {
				$data ['msg'] = "error";
                $data ['errmsg'] = validation_errors();
			} else {
				$flag_1 = $this->sentinelchicken_model->updateSentinelchicken ( $req );
				
				if (! empty ( $flag_1 )) {
					$data ['msg'] = "update";
				} else {
					$data ['msg'] = "error";
				}
			}
			
			$this->load->view ( 'sentinelchickens/edit_sentinelchicken', $data );
		}
	}
	
	/**
	 * Function to delete landingrate
	 */
	public function deletsentinelchicken() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->sentinelchicken_model->deletesentinelchicken ();
			
			$msg = "";
			
			if ($flag)
				$msg = "success";
			else
				$msg = "error";
			
			$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
			if (! empty ( $seturl [1] ))
				redirect ( $seturl [0] . "?del=" . $msg . "#" . $seturl [1] );
			else
				redirect ( $seturl [0] . "?del=" . $msg );
			// redirect(base_url()."sentinelchicken/getsentinelchicken?del=".$msg);
		}
	}
	
	/**
	 * Function to display List Of adultsurveillances
	 */
	public function getsentinelchicken($grid = '', $msg = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$columns = array (
					2 => array (
							'name' => $this->lang->line('whthr_snsr_site_nm'),
							'db_name' => 'idsite',
							'header' => $this->lang->line('whthr_snsr_site_nm'),
							'group' => 'sentinelchicken',
							'ref_table_id_name' => 'idsite',
							'ref_table_db_name' => 'sites',
							'ref_field_db_name' => 'site',
							'ref_field_type' => 'string',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-n' 
					),
					1 => array (
							'name' => $this->lang->line('sntnl_chkn_mgmt_flck_nme'),
							'db_name' => 'flockname',
							'header' => $this->lang->line('sntnl_chkn_mgmt_flck_nme'),
							'group' => 'sentinelchicken',
							'form_control' => 'text_long',
							'required' => TRUE 
					),
					
					0 => array (
							'name' => $this->lang->line('sntnl_chkn_mgmt_flck_id'),
							'db_name' => 'idsentinelchicken',
							'header' => $this->lang->line('sntnl_chkn_mgmt_flck_id'),
							'group' => 'sentinelchicken',
							'form_control' => 'text_long',
							'required' => TRUE 
					),
					3 => array (
							'name' => 'date',
							'db_name' => 'date',
							'header' => $this->lang->line('sntnl_chkn_mgmt_dte_crtd'),
							'group' => 'sentinelchicken' 
					) 
			);
			$data_1 = array (
					'existing_site' => $this->sentinelchicken_model->getSitename (),
					'site_type' => $this->sentinelchicken_model->getSelectedSitetype (),
					'zone_name' => $this->sentinelchicken_model->getSelectedZonename (),
					'state_name' => $this->sentinelchicken_model->getStatename (),
					'state_list' => $this->state_list 
			);
			
			$commands ['delete'] ['toolbar'] = FALSE;
			$add_view = $this->load->view ( 'sentinelchickens/add_sentinelchicken', $data_1, TRUE );
			$edit_view = $this->load->view ( 'sentinelchickens/edit_sentinelchicken', '', TRUE );
			$params = array (
					'id' => 'idsentinelchicken',
					'table' => 'sentinelchicken',
					'url' => 'sentinelchicken/getsentinelchicken',
					'uri_param' => $grid,
					'columns' => $columns,
					// 'columns_visible' => array(0,1,2),
					'filters' => array (
							0 => array (
									'value' => $this->idlocation 
							) 
					),
					'commands' => $commands,
					'ajax' => TRUE,
					'msc_url' => array (
							'excel_url' => base_url () . 'sentinelchicken/toExcelAll',
							'pdf_url' => base_url () . 'sentinelchicken/toPdfAll',
							'text' => $this->lang->line('data_exprt_sntnl') 
					),
					'add_view' => $add_view,
					'edit_view' => $edit_view 
			);
			
			$newdata = array (
					'url' => base_url () . $params ['url'] . '#' . $params ['id'] . '=' . $grid 
			);
			
			$this->session->set_userdata ( $newdata );
			
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_mntnc_sntnl_chiken_mgmt') 
			);
			$this->load->view ( 'header', $data_1 );
			
			$data_1 = array (
					'logstatus' => "logout",
					'page' => "sentinel_chkn_mgmt" 
			);
			
			$this->load->view ( 'left_sidebar', $data_1 );
			
			// Pass grid to the view
            $data = (object)array();
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			$data->msg = $msg;
			// $data->mapdata = base_url()."landingrate/showmap";
			
			$this->load->view ( 'sentinelchickens/sentinelchickens', $data );
		}
		$this->load->view ( 'footer' );
	}
	public function sentinelchickens_json($idlocation = false) {
		$scs_array = $this->sentinelchicken_model->listSentinelchicken ( $idlocation );
		
		$s_arr = array ();
		
		if (! $scs_array)
			$scs_array = array ();
		
		foreach ( $scs_array as $schk ) {
			$s_arr [] = array (
					'post' => $schk 
			);
		}
		
		$scs = array (
				'posts' => $s_arr,
				'total_records' => count ( $s_arr ) 
		);
		
		echo json_encode ( $scs );
	}
	public function create_sentinelchicken_json() {
		echo __FUNCTION__ . ' not yet implemented';
	}
	public function update_sentinelchicken_json() {
		echo __FUNCTION__ . ' not yet implemented';
	}
	public function delete_sentinelchicken_json() {
		echo __FUNCTION__ . ' not yet implemented';
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function history() {
		$req = $this->input->get_post ( 'x_s_' );
		
		if (empty ( $req ))
			redirect ( base_url () . "landingrate/getlandingrate" );
		
		$data1 = $this->adultsurveillance_model->getHistory ( $req );
		
		$id = $data1 [0] ['idadultsurveillance'];
		$total_count = 0;
		$i = 0;
		foreach ( $data1 as $key => $val ) {
			echo $val ['idadultsurveillance'] . " " . $id . "<br>";
			if ($val ['idadultsurveillance'] == $id) {
				$total_count += $val ['count'];
				$data [$i] [] = $val;
			} else {
				$data [$i] ['total'] = $total_count;
				$total_count = 0;
				$i ++;
				$data [$i] [] = $val;
				$id = $val ['idadultsurveillance'];
				$total_count += $val ['count'];
			}
			$data [$i] ['total'] = $total_count;
		}
		// $data2 = $this->adultsurveillance_model->getSpeciesCountbydate($req);
		
		$this->load->view ( 'adultsurveillances/history_view', $data );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function toExcelAll() {
		$query ['data'] = $this->sentinelchicken_model->listSentinelchicken ();
		
		$this->load->view ( 'sentinelchickens/excel_view', $query );
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
		$this->load->helper ( 'pdf_helper' ); // Load helper
		$query ['data'] = $this->sentinelchicken_model->listSentinelchicken ();
		$data = $this->load->view ( 'sentinelchickens/pdf_view', $query, true );
		// $data = file_get_contents(htmlentities($dd)); // Pass the url of html report
		
		create_pdf ( $data, $this->lang->line('sntl_chkn_pdf') ); // Create pdf
	}
}

/* End of file sentinelchicken.php */
/* Location: ./application/controllers/sentinelchicken.php */
