<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
header ( 'Access-Control-Allow-Origin: *' );
error_reporting ( - 1 );
class Page extends CI_Controller {
	
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/index.php/user
	 * - or -
	 * http://example.com/index.php/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
        $this->load->helper('language');
		$this->load->model ( 'page_model' );
        
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
	}
	
	/**
	 * Function to display
	 * contact us page
	 */
	public function contactus() {
		if (! $this->session->userdata ( 'logged_in' )) {
			$data = array (
					'logstatus' => "login",
					'page' => "contactus",
					'title' => $this->lang->line('sidebar_cntct_us') 
			);
			$this->load->view ( 'header', $data );
			$this->load->view ( 'left_sidebar', $data );
		} else {
			$data = array (
					'logstatus' => "logout",
					'username' => $this->session->userdata ( 'username' ),
					'page' => "contactus",
					'title' => $this->lang->line('sidebar_cntct_us') 
			);
			$this->load->view ( 'header', $data );
			$this->load->view ( 'left_sidebar', $data );
		}
		
		$this->load->view ( 'page/contact_us' );
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to display
	 * About Geo Pro page
	 */
	public function aboutgeopro() {
		if (! $this->session->userdata ( 'logged_in' )) {
			$data = array (
					'logstatus' => "login",
					'username' => "",
					'page' => "aboutgeopro",
					'title' => 'About GeoPro' 
			);
			$this->load->view ( 'header', $data );
			$this->load->view ( 'left_sidebar', $data );
		} else {
			$data = array (
					'logstatus' => "logout",
					'username' => $this->session->userdata ( 'username' ),
					'page' => "aboutgeopro",
					'title' => 'About GeoPro' 
			);
			$this->load->view ( 'header', $data );
			$this->load->view ( 'left_sidebar', $data );
		}
		
		$this->load->view ( 'page/aboutgeopro' );
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to display
	 * FAQ Page
	 */
	public function faq() {
		if (! $this->session->userdata ( 'logged_in' )) {
			$data = array (
					'logstatus' => "login",
					'username' => "",
					'page' => "faq",
					'title' => 'FAQ' 
			);
			$this->load->view ( 'header', $data );
			$this->load->view ( 'left_sidebar', $data );
		} else {
			$data = array (
					'logstatus' => "logout",
					'username' => $this->session->userdata ( 'username' ),
					'page' => "faq",
					'title' => 'FAQ' 
			);
			
			$this->load->view ( 'header', $data );
			$this->load->view ( 'left_sidebar', $data );
		}
		
		$this->load->view ( 'page/faq' );
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to display
	 * Support Center Page
	 */
	public function support() {
		$this->page_model->loginSupport ();
	}
	
	/**
	 * Function to display
	 * Training Center page
	 */
	public function trainingcenter() {
		if (! $this->session->userdata ( 'logged_in' )) {
			$data = array (
					'logstatus' => "login",
					'username' => "",
					'page' => "trainingcenter",
					'title' => 'Training Center' 
			);
			$this->load->view ( 'header', $data );
			$this->load->view ( 'left_sidebar', $data );
		} else {
			$data = array (
					'logstatus' => "logout",
					'username' => $this->session->userdata ( 'username' ),
					'page' => "trainingcenter",
					'title' => 'Training Center' 
			);
			$this->load->view ( 'header', $data );
			$this->load->view ( 'left_sidebar', $data );
		}
		
		$this->load->view ( 'page/trainingcenter' );
		$this->load->view ( 'footer' );
	}
	/*
	 * Function to display
	 * Training Center page under Maintainence Menu
	 */
	public function training_center() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data = array (
					'logstatus' => "logout",
					'username' => $this->session->userdata ( 'username' ),
					'page' => "training_center",
					'title' => 'Training Center' 
			);
			$this->load->view ( 'header', $data );
			$this->load->view ( 'left_sidebar', $data );
			$this->load->view ( 'page/training_center' );
			$this->load->view ( 'footer' );
		}
	}
	
	/**
	 * Function to remove dots from site
	 * list read through excel
	 */
	public function removeDotsFromSite() {
		$file = $this->input->get ( 'file' );
		if (empty ( $file ))
			die ( "Sorry No file provided" );
		$file = "Saint Lucie Sites with dot characters--11Jun2015.xlsx";
		$sites = $this->readExcel ( "misc/" . $file );
		print '<pre>';
		// print_r($sites);
		// die;
		
		if (! empty ( $sites ['values'] )) {
			echo "<b style='background-color:lightgreen;'>..........Export data started..........</b><br><br>";
			foreach ( $sites ['values'] as $key => $val ) {
				if (! empty ( $val ['A'] ) && ! empty ( $val ['B'] )) {
					$this->db->select ( 's.idsite, s.address1' );
					$this->db->from ( 'sites AS s' );
					$this->db->where ( 's.site', $val ['A'] );
					$query = $this->db->get ();
					$sitename = $val ['B'];
					
					if ($query->num_rows () > 0) {
						$site = $query->row ();
						
						if ($query->num_rows () > 1) {
							echo "<b style='background-color:pink;'>Site : \"" . $val ['A'] . "\" already exists </b><br>";
							continue;
						}
						if (! empty ( $site->idsite )) {
							$data ['site'] = $val ['B'];
							$data ['address1'] = (! empty ( $val ['D'] ) && ! empty ( $site->address1 )) ? $val ['D'] : $site->address1;
							
							$db_debug = $this->db->db_debug; // save setting
							$this->db->db_debug = FALSE;
							
							$this->db->where ( 'idsite', $site->idsite );
							$this->db->update ( 'sites', $data );
							$status = $this->db->affected_rows ();
							$this->db->db_debug = $db_debug;
							if ($status == '-1') {
								echo "<b style='background-color:pink;'>A site with this name : \"" . $val ['B'] . "\" already exists </b><br>";
								continue;
							}
							
							echo "Site : <b style='background-color:lightgreen;'>" . $val ['A'] . "</b> has been updated to --> Site : <b style='background-color:yellow;'>" . $val ['B'] . "</b><br>";
						}
					} else {
						echo "<b style='background-color:lightgreen;'>" . $sitename . "</b> <b style='background-color:yellow;'>Already Updated</b> <br>";
					}
				}
			}
			echo "<br><b style='background-color:lightgreen;'>..........Export data finished..........</b><br>";
		} else {
			echo "No Data Present in Excel...<br>";
		}
	}
    
    /**
	 * Function to convert kml coords to lat lng
	 */
    function convertKMLToJSON($kml){
        if(!$kml){
            return '{}';
        }
        $kml = simplexml_load_string($kml);
        
        $kml  = preg_replace('/(\-\d+\.\d+)/i', '{lng:$1', $kml->outerBoundaryIs->LinearRing->coordinates);
        $kml  = preg_replace('/\,(\d+\.\d+)/i', ',lat:$1', $kml);
        $kml  = preg_replace('/(\,0)/i', '},', $kml);
        $kml  = trim($kml, ',');
        return !empty($kml)?$kml:'{}';
    }
    
    /**
	 * Function to convert kml coords to lat lng
     * in which both lat and lng are positive
	 */
    function convertPosKMLToJSON($kml){
        if(!$kml){
            return '{}';
        }
        $kml = simplexml_load_string($kml);
        
        $kml  = preg_replace('/(\d+\.\d+\,)/i', '{lng:$1', $kml->outerBoundaryIs->LinearRing->coordinates);
        $kml  = preg_replace('/\,(\d+\.\d+)/i', ',lat:$1', $kml);
        $kml  = preg_replace('/(\s)/i', '},', $kml);
        $kml  = trim($kml, ',')."}";
        return !empty($kml)?$kml:'{}';
    }
    
    /**
	 * Function to import zone from csv file
	 */
	public function importZone() {
        $this->load->helper('misc_helper');
		$file = "Mosquito_control_service_areas.csv";
		$zones = $this->readExcel ( "misc/" . $file );
		print '<pre>';
        //print_r($zones);
//        die;
		
		if (! empty ( $zones ['values'] )) {
			echo "<b style='background-color:lightgreen;'>..........Import Zone & ZoneCord started..........</b><br><br>";
            $i = 1;
			foreach ( $zones ['values'] as $key => $val ) {
				if (! empty ( $val ['D'] ) && ! empty ( $val ['A'] )) {
				    echo "<b style='background-color:pink;'>[$i] Searching for Zone : \"" . $val ['D'] . "\" ...... </b><br><br>";
					$this->db->select ( 'z.idzone, z.zone' );
					$this->db->from ( 'zones AS z' );
					$this->db->where ( 'z.zone', $val ['D'] );
					$query = $this->db->get ();
                    $zonecord = $this->convertKMLToJSON($val ['A']);
                    
					if ($query->num_rows () > 0) {
						echo "<b style='background-color:pink;'>[$i] This Zone : \"" . $val ['D'] . "\" already exists </b><br><br>";
                    } else {
                        $data = array();
                        $idzone = 0;
                        echo "<b style='background-color:lightgreen;'>[$i]  Creating Zone : \"" . $val ['D'] . "\" in database </b><br>";
                        $data ['zone'] = $val ['D'];
                        $data ['idlocation'] = 55;
                        $data ['isdeleted'] = '0';
                        
                        $db_debug = $this->db->db_debug; //save setting
                        $this->db->db_debug = FALSE; //disable debugging for queries
                        $this->db->insert ( 'zones', $data );
                        $dberror = $this->db->_error_message();
                        //check for errors, etc
                        $this->db->db_debug = $db_debug; //restore setting
                        
                        $idzone = $this->db->insert_id();
                        //$idzone = 1;
                        if($idzone){
                            echo "<b style='background-color:lightgreen;'>[$i] Zone : \"" . $val ['D'] . "\" created Successfully!!! </b><br><br>";
                            $data = array();
                            $idzoncord  = 0;
                            $data['idzone'] = $idzone;
                            $data['zonecord'] = trim($zonecord, ',');
                            
                            $db_debug = $this->db->db_debug; //save setting
                            $this->db->db_debug = FALSE; //disable debugging for queries
                            $this->db->insert ( 'zonecords', $data );
                            //echo $this->db->insert_string('zonecords', $data);
                            $dberror = $this->db->_error_message();
                            //check for errors, etc
                            $this->db->db_debug = $db_debug; //restore setting
                            $idzoncord = $this->db->insert_id();
                            //$idzoncord = 1;
                            if($idzoncord){
                                echo "<b style='background-color:lightgreen;'>[$i] Zone Cord: \"" . $val ['D'] . "\" created Successfully!!! </b><br><br>";
                            } else{
                                echo "<b style='background-color:pink;'>[$i] There is some technical issue in saving Coordinates of Zone  : \"" . $val ['D'] . "\" </b><br><br>";
                                echo "<b style='background-color:pink;'>[$i] Reason : \"" . wordwrap($dberror, 30, '\n') . "\" </b><br><br>";
                            }
                        } else{
                            echo "<b style='background-color:pink;'>[$i] There is some technical issue in creating Zone : \"" . $val ['D'] . "\" </b><br><br>";
                            echo "<b style='background-color:pink;'>[$i] Reason : \"" . wordwrap($dberror, 30, '\n') . "\" </b><br><br>";
                        }
                    }
				}
                $i++;
			}
			echo "<br><b style='background-color:lightgreen;'>..........Importing Zones & ZoneCord finished..........</b><br>";
		} else {
			echo "No Data Present in SHP...<br>";
		}
	}
	
	/**
	 * Function to rename sites
	 */
	public function renameSite() {
		$file = "EBRPMARC--Site Name Conversion Table--Rev01.xlsx";
		$sites = $this->readExcel ( "misc/" . $file );
		print '<pre>';
		
		if (! empty ( $sites ['values'] )) {
			echo "Export data started...<br>";
			foreach ( $sites ['values'] as $key => $val ) {
				if ($val ['C'] != 'Do Not Change') {
					$this->db->select ( 's.idsite' );
					$this->db->from ( 'sites AS s' );
					$this->db->join ( 'zones AS z', 's.idzone = z.idzone', 'INNER' );
					$this->db->where ( 's.site', $val ['B'] );
					$this->db->where ( 'z.zone', $val ['A'] );
					$query = $this->db->get ();
					
					if ($query->num_rows () > 0) {
						// print_r($query->row());
						$site = $query->row ();
						
						if (! empty ( $site->idsite )) {
							$data ['site'] = $val ['C'];
							$this->db->where ( 'idsite', $site->idsite );
							$this->db->update ( 'sites', $data );
							echo "Site : " . $val ['B'] . " has been updated to --> Site : " . $val ['C'] . "<br>";
						}
					}
				}
			}
			echo "Export data finished...<br>";
		} else {
			echo "No Data Present in Excel...<br>";
		}
	}
	
	/**
	 * Function to read Excel File
	 */
	public function readExcel($file) {
		if (empty ( $file ))
			return null;
			// load the excel library
		$this->load->library ( 'excel' );
		// read file from path
		$objPHPExcel = PHPExcel_IOFactory::load ( $file );
		// get only the Cell Collection
		$cell_collection = $objPHPExcel->getActiveSheet ()->getCellCollection ();
		// extract to a PHP readable array format
		foreach ( $cell_collection as $cell ) {
			$column = $objPHPExcel->getActiveSheet ()->getCell ( $cell )->getColumn ();
			$row = $objPHPExcel->getActiveSheet ()->getCell ( $cell )->getRow ();
			$data_value = $objPHPExcel->getActiveSheet ()->getCell ( $cell )->getValue ();
			// header will/should be in row 1 only. of course this can be modified to suit your need.
			if ($row == 1) {
				$header [$row] [$column] = $data_value;
			} else {
				$arr_data [$row] [$column] = $data_value;
			}
		}
		// send the data in an array format
		$data ['header'] = $header;
		$data ['values'] = $arr_data;
		// print'<pre>';
		// print_r($data);
		// die;
		return $data;
	}
    
    /**
	 * Function to fetch all the texts from db and 
     * save it into Excel File
	 */
    public function getDataFromDB() {
        $data = $this->page_model->getDataFromDB();
        $this->writeExcel($data);
        print'<pre>';
        print_r($data);
        die;
	}
    
    /**
	 * Function to write into Excel File
	 */
	public function writeExcel($data) {
        if(empty($data)){
            return false;
        }
       
		$fileType = 'Excel2007';
        $fileName =  "misc/translation.xlsx";
        
		// load the excel library
		$this->load->library ( 'excel' );
        $objPHPExcel = new PHPExcel();
        $i = 1;
        foreach($data as $key => $val){
            $objPHPExcel->setActiveSheetIndex(0)
                        ->setCellValue('A'. $i, $key)
                        ->setCellValue('B'. $i, $val);
            $i++;   
        }
        
        // Write the file
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, $fileType);
        $objWriter->save($fileName);
	}
	
	/**
	 * Function to generate CAPTCHAs
	 */
	public function generateCaptcha() {
		$this->load->helper ( 'captcha' );
		$vals = array (
				'img_path' => './captcha/',
				'img_url' => base_url () . 'captcha/',
				'font_path' => './captcha/times_new_yorker.ttf',
				'img_width' => '150',
				'img_height' => 30,
				'expiration' => 7200 
		);
		
		$cap = create_captcha ( $vals );
		$this->session->set_userdata ( 'captcha_code', $cap ['word'] );
		echo json_encode ( array (
				'img_src' => base_url () . 'captcha/' . $cap ['time'] . '.jpg',
				'captcha_code' => $cap ['word'],
				'misc' => base64_encode ( $cap ['word'] ) 
		) );
		exit ();
	}
	
	/**
	 * Function to read data submitted from
	 * Sutter Yuba website
	 */
	public function saveServiceRequestData() {
		$url = $this->input->get_post ( 'url' );
		
		$originalurl = array("http://www.sutter-yubamvcd.org/" , "http://www.cmcd.org/", "http://localhost/test/");
        $service_requesturl = array("service-request-form", "serv_req/", "service_request.htm");
        $thankyou_url = array("request-submitted", "", "");
		
        
		if (! empty ( $url )) {
            for($i=0; $i<3; $i++){
                if($url == $originalurl[$i].$service_requesturl[$i]){
                    $flag = $this->page_model->saveServiceRequestData ($i);
			
        			if (! empty ( $flag ) && is_array ( $flag ) && $flag ['captcha'] == 'nocaptcha')
        				echo json_encode ( $flag );
        			else if ($flag == 'sent') {
        				echo json_encode ( array (
        						'redirect' => $originalurl[$i] . $thankyou_url[$i]
        				) );
        			} else if ($flag == 'nsent') {
        				echo json_encode ( array (
        						'nsent' => true,
        						'redirect' => $originalurl[$i] . $thankyou_url[$i]
        				) );
        			} else
        				echo json_encode ( array (
        						"error" => "error" 
        				) );
                    break;
                }
            }
		} else
			echo json_encode ( array (
					"error" => "error" 
			) );
		exit ();
	}
    
    /**
	 * Function to fetch all the file 
     * from a dir
	 */
	public function getFiles($dir = '') {
        $dir = !empty($dir) ? $dir : 'misc/Shapes/';
        $files = array();
        $data = scandir($dir);
        foreach($data as $val){
            if($val != "." && $val !== "..") {
                array_push($files, $val);
            }
        }
        return $files;
	}
    
    /**
	 * Function to import site from csv file
	 
	public function importSites() {
        $this->load->helper('misc_helper');
        $path = 'misc/Shapes/';
        
        $sites = $this->readExcel ( $path . 'TestS.xls' );
        print '<pre>';
        print_r($sites);
        die;
		$files = $this->getFiles($path);
        if(!empty($files)) {
            $cntr = 0;
            echo "<b style='background-color:lightgreen;'>..........Import Site & SiteCord started..........</b><br><br>";
            foreach($files as $kf => $file){
                $cntr++;
                $sites = $this->readExcel ( $path . $file );
                list($sitename, $ext) = explode('.', $file);
                if(empty($sitename)){
                    $sitename = $cntr;
                }
                $sitename = "Site-".$sitename;
                $this->insertSite($sites['values'], $sitename, $cntr);
                //$this->getSiteCoords($sites['values']);
        		//print '<pre>';
//                print_r($sites);
                die;
            }
        }
		//die;
	}*/
    
    public function importSites() {
        $this->load->helper('misc_helper');
        $path = 'misc/';
        
        $sites = $this->readExcel ( $path . 'Boundaries-Wards-2015-.xls' );
        
		$i = 0;
        echo "<b style='background-color:lightgreen;'>..........Importing Site & SiteCord started..........</b><br><br>";
        foreach($sites['values'] as $site){
            $i++;
            $sitename = "Spray Zone ".$site['A'];
            if (! empty ( $site )) {
    			echo "<b style='background-color:pink;'>[$i] Searching for Site : \"" . $sitename . "\" ...... </b><br><br>";
    			$this->db->select ( 's.idsite, s.site' );
    			$this->db->from ( 'sites AS s' );
    			$this->db->where ( 's.site', $sitename );
    			$this->db->where ( 's.idlocation', '56' );
    			$query = $this->db->get ();
                
    			if ($query->num_rows () > 0) {
    				echo "<b style='background-color:pink;'>[$i] This Site : \"" . $sitename . "\" already exists </b><br><br>";
                } else {
                    $data = array();
                    $idsite = 0;
                    echo "<b style='background-color:lightgreen;'>[$i]  Creating Site : \"" . $sitename . "\" in database </b><br>";
                    $data ['site'] = $sitename;
                    $data ['idlocation'] = 56;
                    $data ['idstate'] = 53;
                    $data ['idsitetype'] = 76;
                    $data ['idzone'] = 3802;
                    $data ['isdeleted'] = '0';
                    $data ['sitecord'] = $this->convertPosKMLToJSON($site['B']);
                    
                    //print'<pre>';
//                    print_r($data);
//                    print'</pre>';
                    
                    $this->db->trans_start();
                    $db_debug = $this->db->db_debug; //save setting
                    $this->db->db_debug = FALSE; //disable debugging for queries
                    $this->db->insert ( 'sites', $data );
                    $idsite = $this->db->insert_id();
                    $dberror = $this->db->_error_message();
                    //check for errors, etc
                    $this->db->db_debug = $db_debug; //restore setting
                    $this->db->trans_complete();
                    
                    
                    //$idsite = 1;
                    if($idsite){
                        echo "<b style='background-color:lightgreen;'>[$i] Site : \"$sitename\" created Successfully!!! </b><br><br>";
                    } else{
                        echo "<b style='background-color:pink;'>[$i] There is some technical issue in creating this Site : \"$sitename\" </b><br><br>";
                        echo "<b style='background-color:pink;'>[$i] Reason : \"" . wordwrap($dberror, 30, '\n') . "\" </b><br><br>";
                    }
                }
    		} else {
    			echo "No Data Present in SHP...<br>";
    		}
        }
        echo "<br><b style='background-color:lightgreen;'>..........Importing Site & SiteCord finished..........</b><br>";
	}
    
    /**
	 * Function to insert site into db
	 */
    public function getSiteCoords($site = ''){
        $str = '';
        if (! empty ( $site )) {
			foreach ( $site as $key => $val ) {
				//$str .= "{lat:". $val['B'] . ", lng:" . $val['C'] . "},";
                
                $val = trim($val, ',,"');
                list($lat, $lng) = explode(',', $val);
                $str .= "{lat:". $lat . ", lng:" . $lng . "},";
            }
            $str = trim($str, ',');
        }
        
        return $str;
    }
    
    /**
	 * Function to insert site into db
	 */
    public function insertSite($site = '', $sitename = '', $i){
        if (! empty ( $site ) && ! empty ( $sitename )) {
			echo "<b style='background-color:pink;'>[$i] Searching for Site : \"" . $sitename . "\" ...... </b><br><br>";
			$this->db->select ( 's.idsite, s.site' );
			$this->db->from ( 'sites AS s' );
			$this->db->where ( 's.site', $sitename );
			
			$query = $this->db->get ();
            
			if ($query->num_rows () > 0) {
				echo "<b style='background-color:pink;'>[$i] This Site : \"" . $sitename . "\" already exists </b><br><br>";
            } else {
                $data = array();
                $idsite = 0;
                echo "<b style='background-color:lightgreen;'>[$i]  Creating Site : \"" . $sitename . "\" in database </b><br>";
                $data ['site'] = $sitename;
                $data ['idlocation'] = 56;
                $data ['isdeleted'] = '0';
                $data ['sitecord'] = $this->getSiteCoords($site);
                
                print'<pre>';
                print_r($data);
                print'</pre>';
                
                $this->db->trans_start();
                $db_debug = $this->db->db_debug; //save setting
                $this->db->db_debug = FALSE; //disable debugging for queries
                $this->db->insert ( 'sites', $data );
                $dberror = $this->db->_error_message();
                //check for errors, etc
                $this->db->db_debug = $db_debug; //restore setting
                $this->db->trans_complete();
                $idsite = $this->db->insert_id();
                
                //$idsite = 1;
                if($idsite){
                    echo "<b style='background-color:lightgreen;'>[$i] Site : \"$sitename\" created Successfully!!! </b><br><br>";
                } else{
                    echo "<b style='background-color:pink;'>[$i] There is some technical issue in creating this Site : \"$sitename\" </b><br><br>";
                    echo "<b style='background-color:pink;'>[$i] Reason : \"" . wordwrap($dberror, 30, '\n') . "\" </b><br><br>";
                }
            }
            echo "<br><b style='background-color:lightgreen;'>..........Importing Site & SiteCord finished..........</b><br>";
		} else {
			echo "No Data Present in SHP...<br>";
		}
    }
    
    public function readAndSaveLatiLongi() {
        $this->load->helper('misc_helper');
        $path = 'misc/';
        
        $data = $this->readExcel ( $path . 'Alamosa20170203165531.xlsx' );
        $arr = array();
        $c = 1;
        print'<pre>';
        foreach($data['values'] as $gps){
            echo " Zone $c: ".$gps['C']. "<br>";
            if(!empty($gps['D'])) {
                $latilongi = $gps['D'];
                $latilongi = trim($latilongi, ',');
                $latilongi  = '['.preg_replace('/lat\:(\d+\.\d+)\,\slng\:([-]\d+\.\d+)/i', '"lat":$1, "lng":$2', $latilongi).']';
                $latilongi = json_decode($latilongi, true);
                if(!empty($latilongi)) {
                    $i = 0;
                    foreach($latilongi as $ll) {
                        $arr["'". $gps['C'] . "'"][$i]["lat"] = $ll['lat'];
                        $arr["'". $gps['C'] . "'"][$i]["lng"] = $ll['lng'];
                        $i++;
                    }
                }
            }
            $c++;
        }
        
        $fileName =  "$path/latilongi.xlsx";
        $fileType = 'Excel2007';
        
		// load the excel library
		$this->load->library ( 'excel' );
        $objPHPExcel = new PHPExcel();
        $i = 1;
        foreach($arr as $key => $val){
            $objPHPExcel->setActiveSheetIndex(0)
                        ->setCellValue('A'. $i, trim($key, "'"));
            foreach($val as $k => $v){
                $objPHPExcel->setActiveSheetIndex(0)
                            ->setCellValue('B'. $i, $v['lat'])
                            ->setCellValue('C'. $i, $v['lng']);
                $i++;
            }
        }
        
        // Write the file
        $objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, $fileType);
        $objWriter->save($fileName);
    }
    
    public function createKMLFromCSV () {
        $this->load->helper('misc_helper');
        $path = 'misc/';
        
        $data = $this->readExcel ( $path . 'Alamosa20170203165531.xlsx' );
        $c = 1;
        print'<pre>';
        foreach($data['values'] as $gps){
            echo " Zone $c: ".$gps['C']. "<br>";
            if(!empty($gps['D'])) {
                $latilongi = $gps['D'];
                $latilongi = trim($latilongi, ',');
                $latilongi  = '['.preg_replace('/lat\:(\d+\.\d+)\,\slng\:([-]\d+\.\d+)/i', '"lat":$1, "lng":$2', $latilongi).']';
                $latilongi = json_decode($latilongi, true);
                if(!empty($latilongi)) {
                    $i = 0;
                    $coord = '';
                    foreach($latilongi as $ll) {
                        $coord .= $ll['lng'].",".$ll['lat'].",0\n";
                    }
                    
                    $kml = '<?xml version="1.0" encoding="UTF-8"?>
                            <kml xmlns="http://www.opengis.net/kml/2.2">
                              <Document>
                                <Placemark>
                                  <name>'.$gps['C'].'</name>
                                  <Polygon>
                                    <outerBoundaryIs>
                                      <LinearRing>
                                        <coordinates>
                                          '.$coord.'
                                        </coordinates>
                                      </LinearRing>
                                    </outerBoundaryIs>
                                  </Polygon>
                                </Placemark>
                              </Document>
                            </kml>
                            ';
                    $fileName =  "$path/Zone$c.kml";
                    $fh = fopen($fileName, 'w+');
                    fwrite($fh, $kml, strlen($kml));
                    fclose($fh);
                }
            }
            $c++;
        }
    }
    
    public function createCsvFromKml () {
        $this->load->helper('misc_helper');
        $path = 'misc/';
        $zones = $this->readExcel ( $path . 'ZONES.csv' );         
        unset($zones['values'][2]);
        
        $file = $path . "/MosquitoZones.kml";
        $file = simplexml_load_file($file);    
        $file = (array)$file->Document->Folder;
        
        $c = $i = 1;
        print'<pre>';
        echo "<br>..........Iterating Zone Excel Start..........<br>";
        foreach($zones['values'] as $zrec){
            $zoneModel = array();
            $zone = explode(" ", $zrec['B']);
            $zoneModel ['zone'] = $zone[1];
    		$zoneModel ['active'] = $zrec['C'];
    		$zoneModel ['squaremileage'] = $zrec['D'];
    		$zoneModel ['description'] = $zrec['E'];
    		$zoneModel ['idlocation'] = $zrec['F'];
            echo "<br>[DEBUG] Zone $c Found : $zone[1] <br>";
            print_r($zoneModel);
            
            $this->db->where ( 'zone', $zone[1] );
    		$this->db->from ( 'zones' );
    		if ($this->db->count_all_results () > 0) {
                echo "<br> This zone already exists : $zone[1] <br>";
            } else {
                echo "<br>[DEBUG] Inserting Zone: $zone[1] <br>";
                $this->db->insert ( 'zones', $zoneModel );
                $rows = $this->db->affected_rows ();
                //$rows = 1; //Testing
                if (!empty ( $rows )) {
                    $i++;
                    echo "<br>[DEBUG] Zone: $zone[1] Inserted <br>";
                    $zonecorddata = array();
                    $zonecord = "";
                    $zonecorddata ['idzone'] = $this->db->insert_id ();//$zrec['A'];//Testing
                    
                    echo "<br>[DEBUG] Searching for Zone Coords <br>";
                    foreach($file['Placemark'] as $key=>$val) {
                        $zoneName = $val->ExtendedData->SchemaData->SimpleData[0];
                        if($zone[1] == $zoneName) {    
                            echo "<br>[DEBUG] Zone Coords Found <br>";
                            $zonecord = (array)$val->Polygon->outerBoundaryIs->LinearRing->coordinates;
                            $zonecord = trim($zonecord[0], ',');
                            $zonecord  = preg_replace('/([-]\d+\.\d+)\,(\d+\.\d+)\s/i', '{lat:$2, lng:$1},', $zonecord);
                            $zonecord = trim($zonecord, ',');
                            //print_r($zonecord);
                            //print_r($val);
                            break;
                        }    
                    }
                    
                    if(!empty($zonecord)) {
                        $zonecorddata ['zonecord'] = $zonecord;
                        print_r($zonecorddata);
                        $this->db->insert ( 'zonecords', $zonecorddata );  
                        echo "<br>[DEBUG] Zone Coords Inserted <br>"; 
                    }
                }   
            }
            $c++;
        }
        echo "<br>[DEBUG] Total Zone Found: $c <br>";
        echo "<br>[DEBUG] Total Zone Inserted: $i <br>";
        echo "<br>..........Iterating Zone Excel END..........<br>";
    }
    
}

/* End of file page.php */
/* Location: ./application/controllers/page.php */