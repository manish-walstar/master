<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class SentinelChickenLab extends CI_Controller {
	public $flock;
	public $sample;
	public $assay;
	public $result;
	public $virus_type = "";
	public $idlocation = "";
	
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		
        $this->load->helper('language');
		$this->load->model ( 'sentinelchickenlab_model' );
		$this->load->model ( 'arbovirallab_model' );
		$this->load->model ( 'adultsurveillance_model' );
		$this->load->model ( 'zone_model' );
		$this->load->model ( 'calsurvflock_model', 'cm' );
		
		$this->flock = $this->sentinelchickenlab_model->getFlocks ();
		$this->assay = $this->arbovirallab_model->getAssay ();
		$this->result = $this->arbovirallab_model->getArbovirallabResult ();
		$this->virus_type = $this->arbovirallab_model->getDetectedVirus ();
        
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		if ($this->session->userdata ( 'logged_in' )) {
			$this->idlocation = $this->session->userdata ( 'idlocation' );
		}
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			redirect ( base_url () . "sentinelchickenlab/getsentinelchickenlab" );
		}
	}
	
	/**
	 * Function to add a new sentinelchickenlab
	 */
	public function addsentinelchickenlab() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$id = $this->input->post ( 'id' );
			
			$assay_type = $this->input->post ( 'assay_type' );
			
			$this->form_validation->set_rules ( 'flockid', $this->lang->line('sntnl_chkn_mgmt_flck_id'), 'trim|required|integer' );
			// $this->form_validation->set_rules('sampleid', $this->lang->line('sntl_chkn_mgmt_smpl_id'), 'trim|required|integer');
			$this->form_validation->set_rules ( 'datebled', $this->lang->line('sntnl_chkn_mgmt_date_bled'), 'trim|required' );
			$this->form_validation->set_rules ( 'datesubmitted', $this->lang->line('sntnl_chkn_lab_date_sbmttd'), 'trim' );
			$this->form_validation->set_rules ( 'dateresults', $this->lang->line('clsrv_flck_date_rslts'), 'trim' );
			$this->form_validation->set_rules ( 'assay_type', $this->lang->line('arbvrl_lab_asy_prfmnd'), 'trim|required' );
			
			if (isset ( $assay_type ) && ! empty ( $assay_type ) && $assay_type == "1")
				$this->form_validation->set_rules ( 'rampunits', $this->lang->line('data_export_rmpunts'), 'trim|required' );
			
			$this->form_validation->set_rules ( 'detected_virus', $this->lang->line('arbvrl_lab_dtctd_vrs'), 'trim|required' );
			
			if ($this->form_validation->run () == FALSE) {
				echo "error";
			} else {
				
				$flag = $this->sentinelchickenlab_model->addSentinelChickenlab ( $id );
				
				$msg = "";
				
				$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
				if (! empty ( $flag ) && ! empty ( $id )) {
					if (! empty ( $seturl [1] ))
						echo $seturl [0] . "?msg=success#" . $seturl [1];
					else
						echo $seturl [0] . "?msg=success";
				} else if (! empty ( $flag )) {
					if (! empty ( $seturl [1] ))
						echo $seturl [0] . "?msg=saved#" . $seturl [1];
					else
						echo $seturl [0] . "?msg=saved";
				} else
					$msg = "error";
				
				echo $msg;
			}
		}
	}
	
	/**
	 * Function to show edit sentinelchickenlab
	 */
	public function showeditsentinelchickenlab() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get_post ( 'id' );
            $mapFlag = $this->input->get_post('mapFlag');
            $mapSite = $this->input->get('idsite');
			
			if (empty ( $req )) {
				echo "error";
				exit ();
			}
            
			$flag = $this->sentinelchickenlab_model->getSentinelChickenlabData ( $req );
            
			$this->flock = $this->sentinelchickenlab_model->getFlocks ( $flag ['idsentinelchicken'] );
			$this->sample = $this->sentinelchickenlab_model->getSamples ( $flag ['idsentinelchicken'], $flag ['idsample'] );
			$this->assay = $this->arbovirallab_model->getSelectedAssay ( $flag ['idassaytype'] );
			$this->result = $this->arbovirallab_model->getSelectedArbovirallabResult ( $flag ['idlabresult'] );
			$this->virus_type = $this->arbovirallab_model->getSelectedVirusType ( $flag ['idvirustype'] );
			
			if ($flag) {
				$flag ['flock'] = $this->flock;
				$flag ['sample'] = $this->sample;
				$flag ['assay_type'] = $this->assay;
				$flag ['lab_result'] = $this->result;
				$flag ['virus_type'] = $this->virus_type;
                $mapSite = $this->sentinelchickenlab_model->getIdSite ($req);
			}
			$flag ['show_sample'] = '';
			$flag ['show_virus'] = 'class="hide"';
			$flag ['show_ramp'] = 'class="hide"';
			$flag ['show_confirm'] = 'class="hide"';
			$flag ['show_result'] = 'class="hide"';
			
			if ($flag ['idassaytype'] == "1") {
				$flag ['show_virus'] = "";
				$flag ['show_ramp'] = "";
				$flag ['show_confirm'] = "";
				$flag ['show_result'] = "";
			} else if ($flag ['idassaytype'] == "2") {
				$flag ['show_virus'] = "";
				$flag ['show_confirm'] = "";
				$flag ['show_result'] = "";
				$flag ['show_ramp'] = 'class="hide"';
			} else {
				$flag ['show_virus'] = "";
				$flag ['show_ramp'] = 'class="hide"';
				$flag ['show_confirm'] = 'class="hide"';
				$flag ['show_result'] = 'class="hide"';
			}
			
			if ($flag ['confirmedrtpcr'] == "1")
				$flag ['confirm'] = "checked='true'";
			
			if ($flag ['resultscorrespond'] == "1")
				$flag ['result'] = "checked='true'";
			
            $flag['mapFlag'] = $mapFlag;
            $mapData = $this->getAllEventsData($mapSite);
            $flag = array_merge($flag, $mapData);
            //print'<pre>';
//            print_r($flag);
//            die;
			$this->load->view ( 'sentinelchickenlabs/edit_sentinelchickenlab', $flag );
		}
	}
	
	/**
	 * Function to delete sentinelchickenlab
	 */
	public function deletesentinelchickenlab() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->sentinelchickenlab_model->deleteSentinelChickenlab ();
			
			$msg = "";
			
			if ($flag)
				$msg = "success";
			else
				$msg = "error";
			
			$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
			if (! empty ( $seturl [1] ))
				redirect ( $seturl [0] . "?del=" . $msg . "#" . $seturl [1] );
			else
				redirect ( $seturl [0] . "?del=" . $msg );
			// redirect(base_url().'sentinelchickenlab/getsentinelchickenlab?del='.$msg);
		}
	}
	
	/**
	 * Function to display List Of sentinelchickenlabs
	 */
	public function getsentinelchickenlab($grid = '', $msg = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$filter_date = $this->input->post ( 'filter_date' );
			$columns = array (
					0 => array (
							'name' => $this->lang->line('sntnl_chkn_mgmt_flck_id'),
							'db_name' => 'idsentinelchicken',
							'header' => $this->lang->line('sntnl_chkn_mgmt_flck_id'),
							'group' => $this->lang->line('labs_sntnl_chkn_labs'),
							'ref_table_id_name' => 'idsentinelchicken',
							'ref_table_db_name' => 'sentinelchicken',
							'ref_field_db_name' => 'flockname',
							'required' => TRUE,
							'form_control' => 'text_long',
							'type' => '1-n' 
					),
					1 => array (
							'name' => $this->lang->line('sntnl_chkn_mgmt_smpl_name'),
							'db_name' => 'idsample',
							'header' => $this->lang->line('sntnl_chkn_mgmt_smpl_name'),
							'group' => $this->lang->line('labs_sntnl_chkn_labs'),
							'ref_table_id_name' => 'idscs',
							'ref_table_db_name' => 'sentinelchickensamples',
							'ref_field_db_name' => 'bandid',
							'required' => TRUE,
							'form_control' => 'text_long',
							'type' => '1-n' 
					),
					2 => array (
							'name' => $this->lang->line('sntnl_chkn_mgmt_date_bled'),
							'db_name' => 'datebled',
							'header' => $this->lang->line('sntnl_chkn_mgmt_date_bled'),
							'group' => $this->lang->line('labs_sntnl_chkn_labs') 
					)
					// 'type' => '1-1-1'
					,
					3 => array (
							'name' => $this->lang->line('sntnl_chkn_lab_date_sbmttd'),
							'db_name' => 'datesubmitted',
							'header' => $this->lang->line('sntnl_chkn_lab_date_sbmttd'),
							'group' => $this->lang->line('labs_sntnl_chkn_labs') 
					)
					// 'type' => 'string'
					,
					4 => array (
							'name' => $this->lang->line('sntnl_chkn_mgmt_date_rslts_rcvd'),
							'db_name' => 'dateresults',
							'header' => $this->lang->line('sntnl_chkn_mgmt_date_rslts_rcvd'),
							'group' => $this->lang->line('labs_sntnl_chkn_labs') 
					)
					// 'type' => 'string'
					,
					5 => array (
							'name' => $this->lang->line('sntl_chkn_mgmt_rslt'),
							'db_name' => 'idlabresult',
							'header' => $this->lang->line('sntl_chkn_mgmt_rslt'),
							'group' => $this->lang->line('labs_sntnl_chkn_labs'),
							'ref_table_id_name' => 'idlabresult',
							'ref_table_db_name' => 'labresults',
							'ref_field_db_name' => 'labresult',
							'required' => TRUE,
							'form_control' => 'text_long',
							'type' => '1-n' 
					),
					6 => array (
							'name' => $this->lang->line('arbvrl_lab_dtctd_vrs'),
							'db_name' => 'idvirustype',
							'header' => $this->lang->line('arbvrl_lab_dtctd_vrs'),
							'group' => $this->lang->line('labs_sntnl_chkn_labs'),
							'ref_table_id_name' => 'idvirustype',
							'ref_table_db_name' => 'virustypes',
							'ref_field_db_name' => 'virustypes',
							'required' => TRUE,
							'form_control' => 'text_long',
							'type' => '1-n' 
					) 
			);
			
			$commands ['delete'] ['toolbar'] = FALSE;
			
			$params = array (
					'id' => 'idsentinelchickenlab',
					'table' => 'sentinelchickenlabs',
					'url' => 'sentinelchickenlab/getsentinelchickenlab',
					'uri_param' => $grid,
					'columns' => $columns,
					'order' => array (
							2 => 'desc' 
					),
					'filter_date' => ! empty ( $filter_date ) ? $filter_date : '2',
					'filters' => array (
							0 => array (
									'value' => $this->idlocation 
							) 
					),
					// 'columns_visible' => array(0,1,2),
					'commands' => $commands,
					'ajax' => TRUE,
					'msc_url' => array (
							'excel_url' => base_url () . 'sentinelchickenlab/toExcelAll',
							'pdf_url' => base_url () . 'sentinelchickenlab/toPdfAll',
							'text' => $this->lang->line('labs_sntnl_chkn_labs') 
					) 
			);
			
			$newdata = array (
					'url' => base_url () . $params ['url'] . '#' . $params ['id'] . '=' . $grid 
			);
			
			$this->session->set_userdata ( $newdata );
			
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('labs_sntnl_chkn_labs'),
					'page' => "arbovirallab",
					'flag' => $this->cm->checkCaGateway () 
			);
			
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			
			// Pass grid to the view
            $data = (object)array();
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			$data->msg = $msg;
			$data->mapdata = base_url () . "sentinelchickenlab/showmap";
			$data->showbutton = $this->showExportBttn ();
			
			$this->load->view ( 'sentinelchickenlabs/sentinelchickenlabs', $data );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to Display the Map
	 */
	public function showmap() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$query ['data'] = $this->sentinelchickenlab_model->getMapdata ();
			$query ['user_loc'] = $this->adultsurveillance_model->getUserLoc ();
			$query ['zone_loc'] = $this->zone_model->getZoneCord ();
			$query ['googlezoom'] = $this->session->userdata ( 'googlezoom' );
			$this->load->view ( 'sentinelchickenlabs/map_view', $query );
		}
	}
	
	/**
	 * Function to Display the Export Button
	 * for CA state
	 */
	public function showExportBttn() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->sentinelchickenlab_model->showExportBttn ();
			return $flag;
		}
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function getsentinelchickenlabdata() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$id = $this->input->post ( 'idsentinelchickenlab' );
			
			if (empty ( $id )) {
				echo "error";
				exit ();
			}
			
			$data = $this->sentinelchickenlab_model->getSentinelChickenlabData ( $id );
			
			echo json_encode ( $data );
		}
	}
	
	/**
	 * Function to fetch the history
	 */
	public function getHistory() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$id = $this->input->get_post ( 'id' );
			
			if (empty ( $id ))
				redirect ( base_url () . "sentinelchickenlab/getsentinelchickenlab" );
			
			$data = $this->sentinelchickenlab_model->getHistory ( $id );
			
			// print'<pre>';
			// print_r($data);
			// die;
			//
			if (! empty ( $data ))
				$this->load->view ( 'sentinelchickenlabs/history_view', array('data' => $data) );
			else {
				$this->load->view ( 'sentinelchickenlabs/history_view', array (
						"msg" => "error" 
				) );
			}
			;
		}
	}
	
	/**
	 * Function to fetch the Sample
	 * selected by Flock
	 */
	public function getSamples() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$id = $this->input->post ( 'id' );
			
			if (empty ( $id ))
				return null;
			
			$flag = $this->sentinelchickenlab_model->getSamples ( $id );
			
			if (empty ( $flag ))
				echo "error";
			else
				echo json_encode($flag);
			
			exit ();
		}
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function toExcelAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$query ['data'] = $this->sentinelchickenlab_model->listSentinelChickenlabs ();
			// print'<pre>';
			// print_r($query['data']);
			// die;
			$this->load->view ( 'sentinelchickenlabs/excel_view', $query );
		}
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->helper ( 'pdf_helper' ); // Load helper
			$query ['data'] = $this->sentinelchickenlab_model->listSentinelChickenlabs ();
			
			$data = $this->load->view ( 'sentinelchickenlabs/pdf_view', $query, true );
			// $data = file_get_contents(htmlentities($dd)); // Pass the url of html report
			
			create_pdf ( $data, $this->lang->line('sntl_chkn_labs_pdf') ); // Create pdf
		}
	}
	
	/**
	 * Function to view page at on click popup
	 */
	public function showaddsentinel() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
            $idsite = $this->input->get('idsite');
			$data = array (
					'flock' => $this->flock,
					'assay' => $this->assay,
					'result' => $this->result,
					'virus_type' => $this->virus_type 
			);
			
            $eventData = $this->getAllEventsData($idsite);
            $data = array_merge($data, $eventData);
            
			$this->load->view ( 'sentinelchickenlabs/add_sentinelchickenlab', $data );
		}
	}
    
    /**
     * Function to fetch all site data based on module
     */
    public function getAllEventsData($idsite = "")
    {
        $params = array('idsite' => $idsite, 'idlocation' => $this->session->userdata('idlocation'));

        $this->load->library('common', $params);

        $response = $this->common->getAllEventsData();
        //print'<pre>';
        //        print_r($response);
        //        die;
        return $response;
    }
}

/* End of file sentinelchickenlab.php */
/* Location: ./application/controllers/sentinelchickenlab.php */