<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class User extends CI_Controller {
	
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/index.php/user
	 * - or -
	 * http://example.com/index.php/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public $salutations = "";
	public $suffixes = "";
	public $id;
    public $app_lang;
    public $checkAcceptanceFlag;
    public $errorMsg = "";
            
	public function __construct() {
		parent::__construct ();
        
		$this->load->model ( 'usermodel' );
		$this->load->model ( 'product_model' );
		$this->load->library ( 'form_validation' );
		$this->load->model ( 'membermodel' );
		$this->load->model ( 'adultsurveillance_model' );
		$this->load->model ( 'mapmanagement_model' );
		$this->load->helper('language');
        
		if ($this->session->userdata ( 'logged_in' )) {
            $this->id = $this->getUserId();	
		}
        
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
        $this->errorMsg = json_encode ( array ('response' => 'fail') );
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			$data = array (
					'logstatus' => "login",
					'username' => "",
					'page' => "login",
					'title' => $this->lang->line('login_main_hdng'),
                    'app_lang' => $this->app_lang
			);
			$this->load->view ( 'header', $data );
			$this->load->view ( 'left_sidebar', $data );
			$this->load->view ( 'user/user_login' );
		} else {
			redirect ( base_url () ."user/dashboard" );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to check whether
	 * the user is login or not
	 * if not then show login screen
	 * else show home screen
	 */
	public function dashboard() {
		if (! $this->session->userdata ( 'logged_in' )) {
			$this->form_validation->set_rules ( 'username', $this->lang->line('cmn_lbl_usrnme'), 'trim|required' );
			$this->form_validation->set_rules ( 'password', $this->lang->line('cmn_lbl_psswrd'), 'trim|required' );
            
			if ($this->form_validation->run () == FALSE) {
				$this->showLoginError();
			} else {
				$flag = $this->usermodel->process ();
                $username = $this->input->post ( 'username' );
                
				if (!empty ( $flag )) {
				    
					$this->checkAcceptanceFlag = $this->usermodel->checkAcceptance ($flag ['iduser']);

                    if(!$this->checkAcceptanceFlag) {
                        $this->showAcceptance($flag['iduser']);
                    }
                    else {
                        $this->setSession($flag['iduser'], $username);
                        $this->prepareDashoard();
                    }
				} else {
					$this->showLoginError();
				}
			}
		} else {
            $this->checkAcceptanceFlag = $this->usermodel->checkAcceptance ($this->id);
            $this->prepareDashoard();
		}
		
		$this->load->view ( 'footer' );
	}
    
    /**
	 * Function to show login error
	 */
	public function showLoginError() {
        $data = array (
				'logstatus' => "login",
				'page' => "login",
				'title' => ucwords(strtolower($this->lang->line('lgn_hdng'))),
                'app_lang' => $this->app_lang,
                'message' => "_wrong"
		);
        
		$this->load->view ( 'header', $data );
		$this->load->view ( 'left_sidebar', $data );
		$this->load->view ( 'user/user_login', $data );
    }
    
    /**
	 * Function to prepare all the data of dashoboard
	 */
	public function prepareDashoard() {
        if (! $this->session->userdata ( 'logged_in' ) || !$this->checkAcceptanceFlag) {
			redirect ( base_url () );
		} else {
            $this->usermodel->set_access_session ();
			$mapdata = $this->showmap ();
			$larva = $this->usermodel->getLarvaeCountRange ();
			$survilance = $this->usermodel->getSurveillanceMapData ();
			$servicemapdata = $this->usermodel->getServiceRequestMapData ();
			$adjustinventory = $this->adjustinventory ();
            
            $data = array (
                    'logstatus' => "logout",
					'username' => $this->session->userdata ( 'username' ),
                    'page' => "dashboard",
					'title' => $this->lang->line('hm_dshbrd_title'),
					'mapdata' => $mapdata,
					'larva' => $larva,
					'survilance' => $survilance,
					'servicemapdata' => $servicemapdata,
					'adjustinventory' => $adjustinventory,
					'app_lang' => $this->app_lang,
                    'gplite' => $this->session->userdata('gplite'),
                    'gplites' => $this->session->userdata('gplites'),
                    'gtadmin' => $this->session->userdata('gtadmin'),
                    'gtlocation' => $this->session->userdata('gtlocation'),
                    'gturl' => $this->session->userdata('gturl')
			);
            
			$this->load->view ( 'header', $data );
			$this->load->view ( 'left_sidebar', $data );
			$this->load->view ( 'user/home', $data );
		}
    }
    
    /**
	 * Function to store the info in session
	 */
	public function setSession($iduser = '', $username = '') {
        if (empty ( $iduser ) && empty ( $username )) {
			redirect ( base_url () );
		}
        
        if ($this->session->userdata ( 'logged_in' )) {
			return;
		}
        
        $idlocation = $this->usermodel->getLocation ( $iduser );
        $sutterIdLocation = $this->usermodel->getLocation('1228');
		$ismenu = '';
		$live_gps = '';
		$cagateway = '';
		$chngBgLoc = array('1', '55');
        $this->app_lang = '';
        
		if (empty ( $idlocation ))
			$idlocation = "";
		else {
			$ismenu = $this->usermodel->getLocationMenu ( $idlocation );
			$zoom = $this->usermodel->getzoom ( $idlocation );
			$locationData = $this->usermodel->getLocationDetail ( $idlocation );
			$live_gps = ! empty ( $locationData ['live_gps'] ) ? $locationData ['live_gps'] : '';
			$cagateway = ! empty ( $locationData ['cagateway'] ) ? $locationData ['cagateway'] : '';
            $this->app_lang = ! empty ( $locationData ['language'] ) && $locationData ['language'] == '1' ? 'en' : 'tr';
            $userData = $this->usermodel->getUserData ( $iduser );
            $gplite = (!empty($userData) && isset($userData['gplite'])) ? $userData['gplite'] : '0';
            $gplites = (!empty($userData) && isset($userData['gplites'])) ? $userData['gplites'] : '0';
            $gtlocation = ! empty ( $locationData ['gtlocation'] ) ? $locationData ['gtlocation'] : '0';
            $gtadmin = ! empty ( $userData ['geotracker_admin'] ) ? $userData ['geotracker_admin'] : '0';
            $gturl = $this->generateGTUrl($locationData, $userData);
            $idStateByLoc = ! empty ( $locationData ['idstate'] ) ? $locationData ['idstate'] : '0';
		}
		
		$newdata = array (
				'username' => $username,
				'id' => base64_encode ( json_encode ( base64_encode ( json_encode ( $iduser ) ) . "_" . "X%^jkdfkjd&*(*(^*^*&^&*^*hjGHJGYGUUGIUrterttrdghvjhuy" ) ),
				'idlocation' => $idlocation,
				'logged_in' => TRUE,
				'ismenu' => $ismenu,
				'live_gps' => $live_gps,
				'cagateway' => $cagateway,
				'googlezoom' => $zoom,
                'sutterIdLocation' => $sutterIdLocation,
                'chngBgLoc' => $chngBgLoc,
                'app_lang' => $this->app_lang,
                'gplite' => $gplite,
		        'gplites' => $gplites,
                'gtadmin' => $gtadmin,
                'gtlocation' => $gtlocation,
                'gturl' => $gturl,
                'idStateByLoc' => $idStateByLoc
		);
		$this->session->set_userdata ( $newdata );
    }
	   
	public function showmap() {
		$query ['data'] = $this->usermodel->getMapdata ();
		$query ['user_loc'] = $this->adultsurveillance_model->getUserLoc ();
		$query ['googlezoom'] = $this->mapmanagement_model->getzoom ();
		
		$map = $this->load->view ( 'user/map_view', $query, TRUE );
		return $map;
	}
	
	// to add function for adjustinventory at dashboard
	public function adjustinventory() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->product_model->listAdjustInventory ();

			if (! empty ( $flag ))
				return $flag;
			else
				return false;
		}
	}
	/**
	 * Function to display
	 * the user profile
	 */
	public function profile() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->usermodel->getUserData ( $this->id );
			
			if ($flag) {
				$data = array (
						'logstatus' => "logout",
						'username' => $this->session->userdata ( 'username' ),
						'page' => $this->lang->line('hm_profile'),
						'title' => $this->lang->line('hm_profile'),
                        'app_lang' => $this->app_lang 
				);
				
				$this->load->view ( 'header', $data );
				$this->load->view ( 'left_sidebar', $data );
				
				$this->salutations = $this->membermodel->getSalutations ();
				$this->suffixes = $this->membermodel->getSuffixesSelected ( $flag ['idsuffix'] );
				
				$flag ['salutations'] = $this->salutations;
				$flag ['suffixes'] = $this->suffixes;
				
				$this->load->view ( 'user/profile', $flag );
			} else
				redirect ( base_url () );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to check User existence
	 * By checking Email ID
	 */
	public function user_check($str = '') {
		$str = $this->input->post ( 'email' );
		$flag = $this->usermodel->userExist ( $str );
		
		if (! $flag) {
			$this->form_validation->set_message ( 'user_check', "'".$this->lang->line('err_msg_mmbr_email_dsnt_exsts')."'" );
			return false;
		} else {
			return true;
		}
	}
	
	/**
	 * Function Forgot Password
	 */
	public function chkforgotpassword() {
		$this->form_validation->set_rules ( 'email', 'Email', 'trim|required|valid_email|callback_user_check|xss_clean' );
		
		if ($this->form_validation->run () == FALSE) {
			$data = array (
					'logstatus' => "login",
					'title' => $this->lang->line('frgt_pwd'),
                    'app_lang' => $this->app_lang
			);
			$this->load->view ( 'header', $data );
			$this->load->view ( 'left_sidebar', $data );
			$this->load->view ( 'user/forgotpassword' );
		} else {
			$this->load->helper ( 'mail_helper' ); // Load helper
			$flag = $this->usermodel->sendForgotmail ();
			
			if ($flag) {
				$data = array (
						'logstatus' => "login",
						'title' => $this->lang->line('frgt_pwd'),
                        'app_lang' => $this->app_lang 
				);
				$this->load->view ( 'header', $data );
				$this->load->view ( 'left_sidebar', $data );
				
				$data = array (
						'success_msg' => $this->lang->line('succ_msg_email_sent') 
				);
				
				$this->load->view ( 'user/forgotpassword', $data );
			} else {
				$data = array (
						'logstatus' => "login",
						'title' => $this->lang->line('frgt_pwd'),
                        'app_lang' => $this->app_lang 
				);
				$this->load->view ( 'header', $data );
				$this->load->view ( 'left_sidebar', $data );
				
				$data = array (
						'unsuccess_msg' => $this->lang->line('succ_msg_profile_updtd')
				);
				
				$this->load->view ( 'user/forgotpassword', $data );
			}
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function Forgot Password
	 */
	public function forgotpassword() {
		$data = array (
				'logstatus' => "login",
				'page' => "",
				'title' => $this->lang->line('frgt_pwd'),
                'app_lang' => $this->app_lang 
		);
		$this->load->view ( 'header', $data );
		$this->load->view ( 'left_sidebar', $data );
		
		$this->load->view ( 'user/forgotpassword' );
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to edit Profile
	 */
	public function editprofile() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->form_validation->set_rules ( 'username', $this->lang->line('cmn_lbl_usrnme'), 'trim|required|xss_clean' );
			$this->form_validation->set_rules ( 'email', 'Email', 'trim|required|valid_email' );
			$this->form_validation->set_rules ( 'crrnt_password', $this->lang->line('usr_mgmt_crrnt_pwd'), 'trim|xss_clean' );
			$this->form_validation->set_rules ( 'password', $this->lang->line('usr_mgmt_new_pwd'), 'trim|matches[passconf]|xss_clean' );
			$this->form_validation->set_rules ( 'passconf', $this->lang->line('usr_mgmt_pwd_conf'), 'trim|xss_clean' );
			$this->form_validation->set_rules ( 'firstname', $this->lang->line('cmn_lbl_frst_name'), 'trim|required' );
			$this->form_validation->set_rules ( 'middlename', $this->lang->line('cmn_lbl_mddlnme'), 'trim' );
			$this->form_validation->set_rules ( 'lastname', $this->lang->line('cmn_lbl_lstnme'), 'trim|required' );
			
			if ($this->form_validation->run () == FALSE) {
				$flag = $this->usermodel->getUserData ( $this->id );
				
				if (! empty ( $flag )) {
					$data = array (
							'logstatus' => "logout",
							'username' => $this->session->userdata ( 'username' ),
							'unsuccess_msg' =>$this->lang->line('err_msg_smthng_went_wrng'),
							'page' => $this->lang->line('hm_profile'),
							'title' => $this->lang->line('mmbr_mgmt_edt_profile'),
                            'app_lang' => $this->app_lang 
					);
					
					$this->load->view ( 'header', $data );
					$this->load->view ( 'left_sidebar', $data );
					
					$this->salutations = $this->membermodel->getSalutationsSelected ( $flag ['idsalutation'] );
					$this->suffixes = $this->membermodel->getSuffixesSelected ( $flag ['idsuffix'] );
					
					$flag ['salutations'] = $this->salutations;
					$flag ['suffixes'] = $this->suffixes;
					
					$this->load->view ( 'user/profile', $flag );
				} else
					redirect ( base_url () );
			} else {
				$flag_1 = $this->usermodel->updateUserData ( $this->session->userdata ( 'id' ) );
				
				if (! empty ( $flag_1 )) {
					$data = array (
							'logstatus' => "logout",
							'username' => $this->session->userdata ( 'username' ),
							'success_msg' => $this->lang->line('succ_msg_profile_updtd'),
							'page' => $this->lang->line('hm_profile'),
							'title' => $this->lang->line('mmbr_mgmt_edt_profile'),
                            'app_lang' => $this->app_lang 
					);
				} else {
					$data = array (
							'logstatus' => "logout",
							'username' => $this->session->userdata ( 'username' ),
							'unsuccess_msg' => "Something Went Wrong",
							'page' => $this->lang->line('hm_profile'),
							'title' => $this->lang->line('mmbr_mgmt_edt_profile'),
                            'app_lang' => $this->app_lang
					);
				}
				
				$flag = $this->usermodel->getUserData ( $this->id );
				
				if ($flag) {
					$this->salutations = $this->membermodel->getSalutationsSelected ( $flag ['idsalutation'] );
					$this->suffixes = $this->membermodel->getSuffixesSelected ( $flag ['idsuffix'] );
					
					$flag ['salutations'] = $this->salutations;
					$flag ['suffixes'] = $this->suffixes;
				}
				
				$this->load->view ( 'header', $data );
				$this->load->view ( 'left_sidebar', $data );
				
				$this->load->view ( 'user/profile', $flag );
			}
		}
		$this->load->view ( 'footer' );
	}
    
    /**
	 * Function to Allow user to Accept 
	 */
	public function acceptance() {
    	$acceptanceFlag = $this->input->post('accept');
		if (!empty($acceptanceFlag) && $acceptanceFlag == "Accept") {
            $data = array(
                'iduser' => $this->getUserId()
            );
            $flag = $this->usermodel->saveAcceptance($data);
            
            if ($flag) {
                $this->checkAcceptanceFlag = true;
                $this->prepareDashoard();
            } else {
                redirect ( base_url () ."user/logout?notify=2");   
            }
        } else {
            redirect ( base_url () ."user/logout?notify=2");   
        }		
	}
    
    /**
	 * Function to show User Acceptance 
	 */
	public function showAcceptance($iduser = '') {
        $userData = $this->usermodel->getUserData ( $iduser );
        $idlocation = $this->usermodel->getLocation ( $iduser );
        $locationData = $this->usermodel->getLocationDetail ( $idlocation );
        $name = !empty($userData['middlename']) ? $userData['firstname']." ".$userData['middlename']." ".$userData['lastname'] : $userData['firstname']." ".$userData['lastname'];
        
        $newdata = array (
				'id' => base64_encode ( json_encode ( base64_encode ( json_encode ( $iduser ) ) . "_" . "X%^jkdfkjd&*(*(^*^*&^&*^*hjGHJGYGUUGIUrterttrdghvjhuy" ) )
		);
		$this->session->set_userdata ( $newdata );
        
        $data = array(
            'userName' => $name,
            'email' => $userData['email'],
            'companyName' => $locationData['location']
        );
                    
        $this->load->view ( 'user/acceptance_view', $data );		
	}
	
	/**
	 * Function to logout
	 * the user from current session
	 */
	public function logout() {
		$message = array ();
        $notification = $this->input->get ( 'notify' );
		if ($this->session->userdata ( 'logged_in' )) {
			$data = array (
					'username' => $this->session->userdata ( 'username' ),
					'id' => $this->session->userdata ( 'id' ),
					'logged_in' => $this->session->userdata ( 'logged_in' ),
					'idlocation' => $this->session->userdata ( 'idlocation' ),
    				'logged_in' => FALSE,
    				'ismenu' => $this->session->userdata ( 'ismenu' ),
    				'live_gps' => $this->session->userdata ( 'live_gps' ),
    				'cagateway' => $this->session->userdata ( 'cagateway' ),
    				'googlezoom' => $this->session->userdata ( 'googlezoom' ),
                    'sutterIdLocation' => $this->session->userdata ( 'sutterIdLocation' ),
                    'chngBgLoc' => $this->session->userdata ( 'chngBgLoc' ),
                    'app_lang' => $this->session->userdata ( 'app_lang' ),
                    'gplite' => $this->session->userdata ( 'gplite' ),
			        'gplites' => $this->session->userdata ( 'gplites' )
			);
            $this->session->unset_userdata ( $data );
			$this->session->sess_destroy();
            
			$message = array (
					'message' => "_logout" 
			);
		}
        
        if ( !empty($notification) ) {
            $message = array (
					'message' => "_cancelled" 
			);
        }
		$data = array (
				'logstatus' => "login",
				'title' => $this->lang->line('hdr_logout'),
                'app_lang' => $this->app_lang
		);
		$this->load->view ( 'header', $data );
		$this->load->view ( 'left_sidebar', $data );
		$this->load->view ( 'user/user_login', $message );
		$this->load->view ( 'footer' );
	}

    /**
	 * Function to check if user is allowed
     * to perform any action or not
     * @param itemId, tableName, idField
     * @return "allowed" or "not allowed"
	 */
	public function isAllowedToChange(){
		if (! $this->session->userdata ( 'logged_in' )) {
			echo "not allowed";
			die ();
		}
        
        $itemId = $this->input->post ( 'itemId' );
		$tableName = $this->input->post ( 'tableName' );
		$idFieldName = $this->input->post ( 'idField' );		

		$locked = $this->usermodel->getUserLockStatus();
		$user_access = $this->usermodel->user_access('company_admin');
		$checkIsSameUser = $this->usermodel->checkIsSameUser ($itemId , $tableName , $idFieldName);
		if(!$locked){
			echo true;
		} else if($user_access || $checkIsSameUser){
			echo true;
		}
		else {
			echo false;
		}
        die ();
	}
	
    /**
	 * Function to get user if
     * from Session
	 */
	public function getUserId() {
        $encid = $this->session->userdata ( 'id' );
        $encid = explode ( "_", json_encode ( base64_decode ( $encid ) ) );
        return json_decode ( base64_decode ( $encid [0] ) );
    }
    
    private function generateGTUrl($locationData = array(), $userdData = array()) {
        if(empty($locationData) || empty($userdData)) {
            return null;
        }
        
        $username = !empty($userdData) && isset($userdData['username']) ? encryptStr($userdData['username']) : "";
        $password = !empty($userdData) && isset($userdData['encrypted_password']) ? encryptStr($userdData['encrypted_password']) : "";
        $locationid = !empty($locationData) && isset($locationData['idlocation']) ? encryptStr($locationData['idlocation']) : "";
        $guid = !empty($locationData) && isset($locationData['GUID']) ? encryptStr($locationData['GUID']) : "";
        
        $queryString = "username=$username&password=$password&locationid=$locationid&guid=$guid";
        
        $gturl = HTTPS_PROTOCOL.":".URL_SEPARATER.URL_SEPARATER.GEO_TRACKER_DOMAIN.URL_SEPARATER.GEO_TRACKER_WEBSERVICE.URL_SEPARATER.GEO_TRACKER_WEBSERVICE_METHOD.URL_SEPARATER.GEO_TRACKER_WEBSERVICE_METHOD_LOGIN."?".$queryString;
        
        return $gturl;
    }
	/* ---------- MOBILE FUNCTIONS START----- */
	
	/**
	 * Function to check whether
	 * the user is loggedin or not
	 * if not then return false
	 * else return user data
	 */
	public function login() {
		$data = $this->input->post ( NULL, TRUE );        
		// print'<pre>';
		// print_r($data);
		// die;
		
		if (empty ( $data ['username'] ) || empty ( $data ['password'] )) {
			echo $this->errorMsg;
			exit ();
		}
		
		$flag = $this->usermodel->process ( $data );
		
		if ($flag) {
            $checkAcceptanceFlag = $this->usermodel->checkAcceptance ($flag ['iduser']);
            $start_sess = $this->usermodel->loginentry ( $flag ['iduser'] );
			
			if (! $start_sess) {
				echo $this->errorMsg;
				exit ();
			}
          
            if(!$checkAcceptanceFlag) {
                $flag = $this->mShowUserAcceptance($flag);
            }
          
            echo json_encode ( array (
					'response' => 'success',
					'data' => $flag 
			) );
			exit ();        
		}
        echo $this->errorMsg;
		exit ();
	}
	
	/**
	 * Function to check whether
	 * the user is login or not
	 * if not then return false
	 * else return user data
	 */
	public function mlogout() {
		$data = $this->input->post ( NULL, TRUE );
		
		// print'<pre>';
		// print_r($data);
		// die;
		
		if (empty ( $data ['iduser'] )) {
			echo $this->errorMsg;
			exit ();
		}
		
		$flag = $this->usermodel->mlogoutentry ( $data ['iduser'] );
		
		if ($flag) {
			echo json_encode ( array (
					'response' => 'success' 
			) );
		} else {
			echo $this->errorMsg;
		}
        exit ();
	}
    
    /**
	 * Function to show User Acceptance
     * for mobile users 
	 */
	public function mShowUserAcceptance($userData = array()) {
        if (empty($userData)) {
			return array();
        }
        
        $idlocation = $this->usermodel->getLocation ( $userData['iduser'] );
        $locationData = $this->usermodel->getLocationDetail ( $idlocation );
        $name = !empty($userData['middlename']) ? $userData['firstname']." ".$userData['middlename']." ".$userData['lastname'] : $userData['firstname']." ".$userData['lastname'];
        $userData['fullname'] = $name;
        $userData['companyname'] = !empty($locationData) && isset($locationData['location']) ? $locationData['location'] : "";
        $userData['securityToken'] = $securityToken = generateRandomString();
        $tokenData = array(
                'iduser' => $userData['iduser'],
                'securityToken' => $securityToken
            );
        $savedToken = $this->usermodel->saveToken ( $tokenData );
        if ($savedToken) {
            $userData['securityToken'] = $savedToken;
            return $userData;
        }
        
        return array();	
	}
    
    /**
	 * Function to perform Action on User Acceptance 
     * for mobile users
	 */
	public function mUserAcceptance() {
        $data = $this->input->post ( NULL, TRUE );
        //For testing
        //$data = json_encode(array('accept' => 1, 'iduser' => 7, 'token' => 'nuiMJIZp0F'));
        if (empty($data)) {
			echo $this->errorMsg;
            exit ();
        }
        $data = json_decode(json_encode($data));
        $securityToken = $this->usermodel->getToken($data->iduser);
        
		if (!empty($data->accept) && $data->accept == 1 && $data->token == $securityToken ) {
            $saveData = array(
                'iduser' => $data->iduser
            );
            $checkAcceptanceFlag = $this->usermodel->checkAcceptance ($data->iduser);
            if ($checkAcceptanceFlag) {
                echo json_encode ( array (
    					'response' => 'success' 
    			) );
                exit ();
            } else {
                $flag = $this->usermodel->saveAcceptance($saveData); 
                if (!empty($flag)) {
                    echo json_encode ( array (
        					'response' => 'success' 
        			) );
                    exit ();
                }
            }
        }	
        
        echo $this->errorMsg;
        exit ();	
	}

	public function tabletTracking() {
		//setting user data
		$this->usermodel->set_access_session ();
		$mapdata = $this->showmap ();
		$larva = $this->usermodel->getLarvaeCountRange ();
		$survilance = $this->usermodel->getSurveillanceMapData ();
		$servicemapdata = $this->usermodel->getServiceRequestMapData ();
		$adjustinventory = $this->adjustinventory ();
		
		$data = array (
				'logstatus' => "logout",
				'username' => $this->session->userdata ( 'username' ),
				'page' => "dashboard",
				'title' => $this->lang->line('hm_dshbrd_title'),
				'mapdata' => $mapdata,
				'larva' => $larva,
				'survilance' => $survilance,
				'servicemapdata' => $servicemapdata,
				'adjustinventory' => $adjustinventory,
				'app_lang' => $this->app_lang,
				'gplite' => $this->session->userdata('gplite'),
		        'gplites' => $this->session->userdata('gplites'),
				'gtadmin' => $this->session->userdata('gtadmin'),
				'gtlocation' => $this->session->userdata('gtlocation'),
				'gturl' => $this->session->userdata('gturl')
		);
		header('X-Frame-Options: GOFORIT'); 
		$a = base_url();
		header('X-Frame-Options: ALLOW-FROM '.$a);
		$this->load->view ( 'header', $data );
		$this->load->view ( 'left_sidebar', $data );
		$this->load->view('mugla_map');
		$this->load->view ( 'footer' );
	}
	
	public function tabletTrackingWV() {
	    //setting user data
	    $this->usermodel->set_access_session ();
	    $mapdata = $this->showmap ();
	    $larva = $this->usermodel->getLarvaeCountRange ();
	    $survilance = $this->usermodel->getSurveillanceMapData ();
	    $servicemapdata = $this->usermodel->getServiceRequestMapData ();
	    $adjustinventory = $this->adjustinventory ();
	    $data = array (
	        'logstatus' => "logout",
	        'username' => $this->session->userdata ( 'username' ),
	        'page' => "dashboard",
	        'title' => $this->lang->line('hm_dshbrd_title'),
	        'mapdata' => $mapdata,
	        'larva' => $larva,
	        'survilance' => $survilance,
	        'servicemapdata' => $servicemapdata,
	        'adjustinventory' => $adjustinventory,
	        'app_lang' => $this->app_lang,
	        'gplite' => $this->session->userdata('gplite'),
	        'gtadmin' => $this->session->userdata('gtadmin'),
	        'gtlocation' => $this->session->userdata('gtlocation'),
	        'gturl' => $this->session->userdata('gturl')
	    );
	    header('X-Frame-Options: GOFORIT');
	    $a = base_url();
	    header('X-Frame-Options: ALLOW-FROM '.$a);
	    $this->load->view ( 'header', $data );
	    $this->load->view ( 'left_sidebar', $data );
	    $this->load->view('westvalley_map');
	    $this->load->view ( 'footer' );
	}
}
/* End of file user.php */
/* Location: ./application/controllers/user.php */