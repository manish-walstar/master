<?php
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Reporting extends CI_Controller {
	public $products;
	public $adult_surveillance;
	public $startdate;
	public $starttime;
	public $enddate;
	public $endtime;
	public $inspector;
	public $currentdate;
	public $currenttime;
	public $zones;
	public $zone = "";
	public $sites;
	public $site = "";
	public $existing_report;
	public $columns;
	public $all_fields;
	public $all_fields_1;
	public $report_type;
	public $report_name;
	public $columns_1;
	public $column_name;
	public $allsite;
	public $allzone;
	
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		
        $this->load->helper('language');
        
		$this->load->model ( 'reporting_model' );
		$this->load->model ( 'site_model' );
		$this->load->model ( 'zone_model' );
		$this->load->model ( 'arbovirallab_model' );
		$this->load->model ( 'usermodel' );
		$this->usermodel->set_access_session ();
		
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		if (! $this->usermodel->user_access ( 'reports' ) && ! $this->usermodel->user_access ( 'company_admin' ))
			redirect ( base_url () );
		
		$this->currentdate = date ( 'm/d/Y' );
		$this->currenttime = date ( "h:i:s A" );
		
		$this->enddate = date ( 'm/d/Y' );
		$this->endtime = date ( 'h:i:s A' );
		
		$this->startdate = date ( 'm/d/Y', strtotime ( "-30 day" ) );
		$this->starttime = date ( 'h:i:s A' );
		
		$this->zones = $this->zone_model->listZones ();
		$this->sites = $this->site_model->listSites ();
		
		$this->existing_report = $this->reporting_model->getExistingReport ();
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			redirect ( base_url () . "reporting/getreporting" );
		}
	}
	
	/**
	 * Function to fetch Existing Reports
	 */
	public function getexistingreporting() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data = $this->reporting_model->getExistingReportData ();
			
			// print'<pre>';
			// print_r($data);
			// die;
			echo json_encode ( $data );
			exit ();
		}
	}
	
	/**
	 * Function to delete report
	 */
	public function deletereport() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data = $this->reporting_model->deleteReportData ();
			
			if (! empty ( $data ))
				redirect ( base_url () . "reporting/getreporting?msg=del" );
			else
				redirect ( base_url () . "reporting/getreporting?msg=ndel" );
		}
	}
	
	/**
	 * Function to fetch All products
	 */
	public function getreporting() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			// print_r($this->input->post('no_action'));
			// print'<pre>';
			// print_r($_POST);
			
			$allsitechk = 0;
			$allzonechk = 0;
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			$all_fields_1 = $this->input->get_post ( 'all_fields_1' );
			$msg = $this->input->get ( 'msg' );
			$exs_report = $this->input->post ( 'existing_report' );
			$this->report_type = $this->input->post ( 'report_type' );
			$this->report_name = $this->input->post ( 'report_name' );
			$this->columns_1 = $this->input->post ( 'columns' );
			$this->columns = $this->input->post ( 'column_2' );
			$this->allzone = $this->input->post ( 'idzone' );
			$this->allsite = $this->input->post ( 'idsite' );
			$this->column_name = $this->input->post ( 'column_name' );
			$this->all_fields = $all_fields_1;
			$action_name = $this->input->post ( 'action_name' );
			$action = $this->input->post ( 'action' );
			$type = $this->input->post ( 'type' );
			$save = $this->input->post ( 'save' );
			// echo $type;die;
			$service = $this->input->post ( 'service' );
			// $type = $service;
			$no_action = 0;
			$surveillance = 0;
			$inspection = 0;
			$treatment = 0;
			
			// echo $this->input->post('report_type')." ".$this->report_type."<br>";die;
			
			if ($this->input->post ( 'no_action' ) == 'no_action') {
				$no_action = 1;
			}
			if ($this->input->post ( 'inspection' ) == 'inspection') {
				$inspection = 1;
			}
			if ($this->input->post ( 'surveillance' ) == 'surveillance') {
				$surveillance = 1;
			}
			if ($this->input->post ( 'treatment' ) == 'treatment') {
				$treatment = 1;
			}
			
			if (! empty ( $this->column_name )) {
				$this->column_name = explode ( ",", $this->column_name );
			}
			
			if (! empty ( $this->columns )) {
				$this->columns = urldecode(base64_decode ( $this->columns ));
				$this->columns = str_replace ( ",", "", $this->columns );
			}
            
            if (! empty ( $this->all_fields )) {
				$this->all_fields = urldecode(base64_decode ( $this->all_fields ));
			}
			
			if (! empty ( $action ))
				$action = explode ( ",", $action );
			
			$data_1 = array ();
			
			if (! empty ( $this->allsite )) {
				if (! empty ( $this->allsite [0] ) && $this->allsite [0] == 'on')
					$allsitechk = 1;
				foreach ( $this->sites as $k => $v ) {
					if (in_array ( $v ['idsite'], $this->allsite )) {
						$this->sites [$k] ['chk'] = "1";
					}
				}
			}
			
			if (! empty ( $this->allzone )) {
				if (! empty ( $this->allzone [0] ) && $this->allzone [0] == 'on')
					$allzonechk = 1;
				foreach ( $this->zones as $k => $v ) {
					if (in_array ( $v ['idzone'], $this->allzone )) {
						$this->zones [$k] ['chk'] = "1";
					}
				}
			}
			
			if (! empty ( $msg )) {
				$id = $this->session->userdata ( 'id' );
				$id_arr = explode ( "_", json_decode ( base64_decode ( $id ) ) );
				
				$id = json_decode ( base64_decode ( $id_arr [0] ) );
				
				$this->userinfo = $this->usermodel->getUserData ( $id );
				
				$middlename = " ";
				if (isset ( $this->userinfo ['middlename'] ))
					$middlename = ! empty ( $this->userinfo ['middlename'] ) ? " " . $this->userinfo ['middlename'] . " " : " ";
				
				if (isset ( $this->userinfo ['firstname'] ) || isset ( $this->userinfo ['lastname'] ))
					$this->inspector = $this->userinfo ['firstname'] . $middlename . $this->userinfo ['lastname'];
				
				$this->products = $this->reporting_model->getReporting ( $this->startdate, $this->enddate, $this->report_type, $this->report_name, $this->allsite, $this->allzone, $service );
				
				// print('<pre>');
				// print_r($this->products);
				// die;
				
				$data_1 = array (
						'username' => $this->session->userdata ( 'username' ),
						'logstatus' => "logout",
						'title' => $this->lang->line('sidebar_rprtng_wzrd'),
						'page' => "reporting",
						'startdate' => $this->startdate,
						'starttime' => date ( 'h:i:s A', strtotime ( $this->starttime ) ),
						'endtime' => date ( 'h:i:s A', strtotime ( $this->endtime ) ),
						'enddate' => $this->enddate,
						'inspector' => $this->inspector,
						'currentdate' => $this->currentdate,
						'currenttime' => date ( "h:i:s A", strtotime ( $this->currenttime ) ),
						'zones' => $this->zones,
						'sites' => $this->sites,
						'existing_report' => $this->existing_report,
						'columns' => $this->columns,
						'all_fields' => $this->all_fields,
						'report_name' => $this->report_name,
						'report_type' => $this->report_type,
						'action_name' => $action_name,
						'action' => $action,
						'allsitechk' => $allsitechk,
						'allzonechk' => $allzonechk,
						'type' => $type,
                        'app_lang' => $this->app_lang
				);
				
				if ($msg == "del")
					$data_1 ['succ_msg'] = "Report has been deleted successfully!!!";
				else if ($msg == "ndel")
					$data_1 ['error_msg'] = $this->lang->line('err_msg_wrng_while_dltng') ."!";
				else
					$data_1 ['error_msg'] = "You must select at least one field to be on the report!";
			} else if (empty ( $startdate ) || empty ( $enddate )) {
				$action = array (
						"no_action",
						"inspection",
						"surveillance",
						"treatment" 
				);
				$id = $this->session->userdata ( 'id' );
				$id_arr = explode ( "_", json_decode ( base64_decode ( $id ) ) );
				$id = json_decode ( base64_decode ( $id_arr [0] ) );
				$this->userinfo = $this->usermodel->getUserData ( $id );
				$middlename = " ";
				if (isset ( $this->userinfo ['middlename'] ))
					$middlename = ! empty ( $this->userinfo ['middlename'] ) ? " " . $this->userinfo ['middlename'] . " " : " ";
				
				if (isset ( $this->userinfo ['firstname'] ) || isset ( $this->userinfo ['lastname'] ))
					$this->inspector = $this->userinfo ['firstname'] . $middlename . $this->userinfo ['lastname'];
				
				$this->products = $this->reporting_model->getReporting ( $this->startdate, $this->enddate, $this->report_type, $this->report_name, $this->allsite, $this->allzone, $service, $no_action, $surveillance, $inspection, $treatment );
				
				// print('<pre>');
				// print_r($this->products);
				// die;
				$data_1 = array (
						'username' => $this->session->userdata ( 'username' ),
						'logstatus' => "logout",
						'title' => $this->lang->line('sidebar_rprtng_wzrd'),
						'page' => "reporting",
						'startdate' => $this->startdate,
						'starttime' => date ( 'h:i:s A', strtotime ( $this->starttime ) ),
						'endtime' => date ( 'h:i:s A', strtotime ( $this->endtime ) ),
						'enddate' => $this->enddate,
						'inspector' => $this->inspector,
						'currentdate' => $this->currentdate,
						'currenttime' => date ( "h:i:s A", strtotime ( $this->currenttime ) ),
						'zones' => $this->zones,
						'sites' => $this->sites,
						'columns' => $this->columns,
						'all_fields' => $this->all_fields,
						'report_name' => $this->report_name,
						'report_type' => $this->report_type,
						'existing_report' => $this->existing_report,
						'action_name' => $action_name,
						'action' => $action,
						'allsitechk' => $allsitechk,
						'allzonechk' => $allzonechk,
						'type' => $type,
                        'app_lang' => $this->app_lang 
				);
			} else {
				// print'<pre>';
				// print_r($_POST);
				// die;
				// echo base64_decode($_POST['allzone'])."<br/>";
				// echo base64_decode($_POST['allsite']);
				// die;
				if (empty ( $this->columns )) {
					redirect ( base_url () . "reporting/getreporting?msg=_x_z_z_x" );
				}
				
				$this->startdate = $startdate;
				$this->enddate = $enddate;
				
				$id = $this->session->userdata ( 'id' );
				
				$id_arr = explode ( "_", json_decode ( base64_decode ( $id ) ) );
				
				$id = json_decode ( base64_decode ( $id_arr [0] ) );
				
				$this->userinfo = $this->usermodel->getUserData ( $id );
				
				$middlename = " ";
				if (isset ( $this->userinfo ['middlename'] ))
					$middlename = ! empty ( $this->userinfo ['middlename'] ) ? " " . $this->userinfo ['middlename'] . " " : " ";
				
				if (isset ( $this->userinfo ['firstname'] ) || isset ( $this->userinfo ['lastname'] ))
					$this->inspector = $this->userinfo ['firstname'] . $middlename . $this->userinfo ['lastname'];
					// echo $this->startdate."<br>".$this->enddate."<br>".$this->report_type."<br>".$this->report_name."<br>".$this->allsite."<br>".$this->allzone."<br>".$service."<br>";
					// die;
				$this->products = $this->reporting_model->getReporting ( $this->startdate, $this->enddate, $this->report_type, $this->report_name, $this->allsite, $this->allzone, $service, $no_action, $surveillance, $inspection, $treatment );
				
				$this->existing_report = $this->reporting_model->getExistingReport ();
				$succ_msg = '';
				if (! empty ( $this->products ['msg'] ) && $this->products ['msg'] == "success")
					$succ_msg = $this->lang->line('succ_msg_rprt_saved_scsflly');
				else if (! empty ( $this->products ['msg'] ) && $this->products ['msg'] == "updated")
					$succ_msg = "Your report has been updated successfully";
				
				$data_1 = array (
						'username' => $this->session->userdata ( 'username' ),
						'logstatus' => "logout",
						'title' => $this->lang->line('sidebar_rprtng_wzrd'),
						'page' => "reporting",
						'startdate' => $this->startdate,
						'starttime' => date ( 'h:i:s A', strtotime ( $this->starttime ) ),
						'endtime' => date ( 'h:i:s A', strtotime ( $this->endtime ) ),
						'enddate' => $this->enddate,
						'inspector' => $this->inspector,
						'currentdate' => $this->currentdate,
						'currenttime' => date ( "h:i:s A", strtotime ( $this->currenttime ) ),
						'columns' => $this->columns,
						'zones' => $this->zones,
						'sites' => $this->sites,
						'columns_1' => $this->columns_1,
						'column_name' => $this->column_name,
						'all_fields_1' => $all_fields_1,
						'all_fields' => $this->all_fields,
						'report_name' => $this->report_name,
						'report_type' => $this->report_type,
						'existing_report' => $this->existing_report,
						'products' => $this->products,
						'action_name' => $action_name,
						'action' => $action,
						'allsitechk' => $allsitechk,
						'allzonechk' => $allzonechk,
						'type' => $type,
						'succ_msg' => $succ_msg,
                        'app_lang' => $this->app_lang 
				);
			}
			
			// print('<pre>');
			// print_r($data_1);
			// die;
			// //print_r($this->all_fields);
			// if(!empty($this->all_fields))
			// {
			// //print_r(base64_decode($this->all_fields));
			// $temp = base64_decode($this->all_fields);
			// $temp = str_replace(",","",$temp);
			// //$this->all_fields = $temp->data_json;
			//
			// }
			// print_r($temp);
			
			$this->load->view ( 'header', $data_1 );
			
			$this->load->view ( 'left_sidebar', $data_1 );
			
			$this->load->view ( 'reportings/reportings', $data_1 );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to fetch Larval Columns
	 */
	public function getlarvalcolumn($case = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$str = '<option value="zone">' . $this->lang->line('site_mgmt_zone') . '</option>
            		<option value="site">'. $this->lang->line('whthr_snsr_site') . '</option>
            		<option value="sitetype">'. $this->lang->line('trap_mgmt_site_type') . '</option>
            		<option value="sitestatus">'. $this->lang->line('lrvl_srvlnc_site_stts') . '</option>
            		<option value="date">'. $this->lang->line('data_exprt_schdld_date') . '</option>
            		<option value="larvaepresent">'. $this->lang->line('lrvl_srvlnc_larvae_presnt') . '</option>
            		<option value="totalcount">'. $this->lang->line('lrvl_srvlnc_larvae_cnt') . '</option>
            		<option value="species">'. $this->lang->line('lnding_rte_spcies') . '</option>
            		<option value="subspecies">'. $this->lang->line('data_exprt_subspcs') . '</option>
            		<option value="inspector">' . $this->lang->line('whthr_snsr_inspctr') . '</option>
            		<option value="officephone">'. $this->lang->line('data_exprt_inspctr_phn') . '</option>
            		<option value="requested_by">'. $this->lang->line('data_export_rqstdby') . '</option>
            		<option value="requested_by_phn">'. $this->lang->line('data_exprt_reqby_phn') . '</option>
            		<option value="habitat">'. $this->lang->line('data_exprt_habtt') . '</option>
            		<option value="instar">'. $this->lang->line('lrvl_srvlnc_instar') . '</option>
            		<option value="watertemprange">' . $this->lang->line('data_exprt_water_temp') . '</option>
            		<option value="comments">'. $this->lang->line('cmn_lbl_cmnts') . '</option>
            		<option value="address1">'. $this->lang->line('site_mgmt_addrs_1') . '</option>
            		<option value="address2">'. $this->lang->line('site_mgmt_addrs_2') . '</option>
            		<option value="city">'. $this->lang->line('site_mgmt_cty') . '</option>
            		<option value="statename">'. $this->lang->line('site_mgmt_state') . '</option>
            		<option value="postalcode">'. $this->lang->line('site_mgmt_postal_code') . '</option>
            		<option value="latitude">'. $this->lang->line('site_mgmt_lat') . '</option>
            		<option value="longitude">'. $this->lang->line('site_mgmt_lng') . '</option>';
			
			if (! empty ( $case )) {
				return $str;
			} else {
				echo json_encode ( array (
						'data_json' => $str 
				) );
				exit ();
			}
		}
	}
	
	/**
	 * Function to fetch Adult Columns
	 */
	public function getadultcolumn($case = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$str = '<option value="zone">' . $this->lang->line('site_mgmt_zone') . '</option>
            		<option value="site">'. $this->lang->line('whthr_snsr_site') . '</option>
            		<option value="setdate">'. $this->lang->line('adlt_srvlnc_set_date') . '</option>
            		<option value="pudate">'. $this->lang->line('data_export_pckup_date') . '</option>
            		<option value="trap">'. $this->lang->line('trap_mgmt_trap_nme') . '</option>
            		<option value="traptype">' . $this->lang->line('trap_mgmt_trap_type') . '</option>
            		<option value="baittype">'. $this->lang->line('trap_mgmt_bait_type') . '</option>
            		<option value="speciescount">'. $this->lang->line('data_exprt_spcs_cnts') . '</option>
            		<option value="eggraftcount">'. $this->lang->line('data_exprt_egg_raft_cnt') . '</option>
            		<option value="temprange">'. $this->lang->line('adlt_srvlnc_temp') . '</option>
            		<option value="humidityrange">'. $this->lang->line('adlt_srvlnc_humdity') . '</option>
            		<option value="windspeed">'. $this->lang->line('adlt_srvlnc_wnd_spd') . '</option>
            		<option value="cloudcoverage">'. $this->lang->line('adlt_srvlnc_cloud_cvr') . '</option>
            		<option value="comments">'. $this->lang->line('cmn_lbl_cmnts') . '</option>
            		<option value="inspector">'. $this->lang->line('whthr_snsr_inspctr') . '</option>
            		<option value="officephone">'. $this->lang->line('data_exprt_inspctr_phn') . '</option>
            		<option value="address1">'. $this->lang->line('site_mgmt_addrs_1') . '</option>
            		<option value="address2">'. $this->lang->line('site_mgmt_addrs_2') . '</option>
            		<option value="city">'. $this->lang->line('site_mgmt_cty') . '</option>
            		<option value="statename">'. $this->lang->line('site_mgmt_state') . '</option>
            		<option value="postalcode">'. $this->lang->line('site_mgmt_postal_code') . '</option>
            		<option value="latitude">'. $this->lang->line('site_mgmt_lat') . '</option>
            		<option value="longitude">'. $this->lang->line('site_mgmt_lng') . '</option>';
			
			if (! empty ( $case )) {
				return $str;
			} else {
				echo json_encode ( array (
						'data_json' => $str 
				) );
				exit ();
			}
		}
	}
	
	/**
	 * Function to fetch Landing Columns
	 */
	public function getlandingcolumn($case = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$str = '<option value="zone">' . $this->lang->line('site_mgmt_zone') . '</option>
            		<option value="site">'. $this->lang->line('whthr_snsr_site') . '</option>
            		<option value="observeddate">'. $this->lang->line('data_exprt_date_obsrvd') . '</option>
            		<option value="countobserved">'. $this->lang->line('lnding_rte_cnt_obsrvd') . '</option>
            		<option value="speciescount">'. $this->lang->line('data_exprt_spcs_cnts') . '</option>
            		<option value="durationsmin">'. $this->lang->line('data_exprt_drtn_min') . '</option>
            		<option value="durations">'. $this->lang->line('data_exprt_drtn_val') . '</option>
            		<option value="temprange">'. $this->lang->line('adlt_srvlnc_temp') . '</option>
            		<option value="humidityrange">'. $this->lang->line('adlt_srvlnc_humdity') . '</option>
            		<option value="windspeed">'. $this->lang->line('adlt_srvlnc_wnd_spd') . '</option>
            		<option value="cloudcoverage">'. $this->lang->line('adlt_srvlnc_cloud_cvr') . '</option>
            		<option value="comments">'. $this->lang->line('cmn_lbl_cmnts') . '</option>
            		<option value="inspector">'. $this->lang->line('whthr_snsr_inspctr') . '</option>
            		<option value="officephone">'. $this->lang->line('data_exprt_inspctr_phn') . '</option>
            		<option value="address1">'. $this->lang->line('site_mgmt_addrs_1') . '</option>
            		<option value="address2">'. $this->lang->line('site_mgmt_addrs_2') . '</option>
            		<option value="city">'. $this->lang->line('site_mgmt_cty') . '</option>
            		<option value="statename">'. $this->lang->line('site_mgmt_state') . '</option>
            		<option value="postalcode">'. $this->lang->line('site_mgmt_postal_code') . '</option>
            		<option value="latitude">'. $this->lang->line('site_mgmt_lat') . '</option>
            		<option value="longitude">'. $this->lang->line('site_mgmt_lng') . '</option>';
			
			if (! empty ( $case )) {
				return $str;
			} else {
				echo json_encode ( array (
						'data_json' => $str 
				) );
				exit ();
			}
		}
	}
	
	/**
	 * Function to fetch Arboviral Lab Columns
	 */
	public function getarboviralcolumn($case = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$str = '<option value="zone">' . $this->lang->line('site_mgmt_zone') . '</option>
            		<option value="site">'. $this->lang->line('whthr_snsr_site') . '</option>
            		<option value="testdate">'. $this->lang->line('arbvrl_labs_testdate') . '</option>
            		<option value="poolsize">'. $this->lang->line('data_export_poolsize') . '</option>
            		<option value="assaytype">'. $this->lang->line('data_exprt_assy_type') . '</option>
            		<option value="positiveresult">'. $this->lang->line('data_export_pstv_rslt') . '</option>
            		<option value="rampunits">'. $this->lang->line('data_export_rmpunts') . '</option>
            		<option value="rtprcconfirm">'. $this->lang->line('data_export_rtprc_cnfrmd') . '</option>
            		<option value="resultscorresspond">'. $this->lang->line('data_export_rslts_crrspnd') . '</option>
            		<option value="technician">'. $this->lang->line('data_exprt_tchncn') . '</option>
            		<option value="virustypes">' . $this->lang->line('arbvrl_actvty_virus') . '</option>
            		<option value="setdate">'. $this->lang->line('adlt_srvlnc_set_dt_tm') . '</option>
            		<option value="pudate">'. $this->lang->line('data_export_pckup_date_time') . '</option>
            		<option value="eggraftcount">'. $this->lang->line('data_exprt_egg_raft_cnt') . '</option>
            		<option value="collectedcount">'. $this->lang->line('data_export_cllctd_cnt') . '</option>
            		<option value="inspector">'. $this->lang->line('whthr_snsr_inspctr') . '</option>
            		<option value="species">'. $this->lang->line('lnding_rte_spcies') . '</option>
            		<option value="subspecies">'. $this->lang->line('data_exprt_subspcs') . '</option>
            		<option value="trap">'. $this->lang->line('trap_mgmt_trap_nme') . '</option>
            		<option value="traptype">' . $this->lang->line('trap_mgmt_trap_type') . '</option>
            		<option value="baittype">'. $this->lang->line('trap_mgmt_bait_type') . '</option>
            		<option value="temprange">'. $this->lang->line('adlt_srvlnc_temp') . '</option>
            		<option value="humidityrange">'. $this->lang->line('adlt_srvlnc_humdity') . '</option>
            		<option value="windspeed">'. $this->lang->line('adlt_srvlnc_wnd_spd') . '</option>
            		<option value="cloudcoverage">'. $this->lang->line('adlt_srvlnc_cloud_cvr') . '</option>
            		<option value="trapresult">'. $this->lang->line('data_export_trap_rslts') . '</option>
            		<option value="comments">'. $this->lang->line('cmn_lbl_cmnts') . '</option>
            		<option value="address1">'. $this->lang->line('site_mgmt_addrs_1') . '</option>
            		<option value="address2">'. $this->lang->line('site_mgmt_addrs_2') . '</option>
            		<option value="city">'. $this->lang->line('site_mgmt_cty') . '</option>
            		<option value="statename">'. $this->lang->line('site_mgmt_state') . '</option>
            		<option value="postalcode">'. $this->lang->line('site_mgmt_postal_code') . '</option>
            		<option value="latitude">'. $this->lang->line('site_mgmt_lat') . '</option>
            		<option value="longitude">'. $this->lang->line('site_mgmt_lng') . '</option>';
			
			if (! empty ( $case )) {
				return $str;
			} else {
				echo json_encode ( array (
						'data_json' => $str 
				) );
				exit ();
			}
		}
	}
	
	/**
	 * Function to fetch Corvid Lab Columns
	 */
	public function getcorvidcolumn($case = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$str = '<option value="zone">' . $this->lang->line('site_mgmt_zone') . '</option>
            		<option value="site">'. $this->lang->line('whthr_snsr_site') . '</option>
            		<option value="datecollected">'. $this->lang->line('arbvrl_actvty_date_cllctd') . '</option>
            		<option value="collected_by">'. $this->lang->line('data_export_cllctd_by') . '</option>
            		<option value="avianspecies">'. $this->lang->line('lnding_rte_spcies') . '</option>
            		<option value="positiveresult">'. $this->lang->line('sntl_chkn_mgmt_rslt') . '</option>
            		<option value="rampunits">'. $this->lang->line('data_export_rmpunts') . '</option>
            		<option value="rtprcconfirm">'. $this->lang->line('data_export_rtprc_cnfrmd') . '</option>
            		<option value="resultscorresspond">'. $this->lang->line('data_export_rslts_crrspnd') . '</option>
            		<option value="virustypes">' . $this->lang->line('arbvrl_actvty_virus') . '</option>
            		<option value="assaytype">'. $this->lang->line('data_exprt_assy_type') . '</option>
            		<option value="comments">'. $this->lang->line('cmn_lbl_cmnts') . '</option>
            		<option value="address1">'. $this->lang->line('site_mgmt_addrs_1') . '</option>
            		<option value="address2">'. $this->lang->line('site_mgmt_addrs_2') . '</option>
            		<option value="city">'. $this->lang->line('site_mgmt_cty') . '</option>
                    <option value="statename">'. $this->lang->line('site_mgmt_state') . '</option>
            		<option value="postalcode">'. $this->lang->line('site_mgmt_postal_code') . '</option>
            		<option value="latitude">'. $this->lang->line('site_mgmt_lat') . '</option>
            		<option value="longitude">'. $this->lang->line('site_mgmt_lng') . '</option>';
			
			if (! empty ( $case )) {
				return $str;
			} else {
				echo json_encode ( array (
						'data_json' => $str 
				) );
				exit ();
			}
		}
	}
	
	/**
	 * Function to fetch Sentinel Lab Columns
	 */
	public function getsentinelcolumn($case = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$str = '<option value="zone">' . $this->lang->line('site_mgmt_zone') . '</option>
            		<option value="site">'. $this->lang->line('whthr_snsr_site') . '</option>
            		<option value="flockname">'. $this->lang->line('sntnl_chkn_mgmt_flck_nme') . '</option>
            		<option value="samplename">'. $this->lang->line('sntnl_chkn_mgmt_smpl_name') . '</option>
            		<option value="datebled">'. $this->lang->line('sntnl_chkn_mgmt_date_bled') . '</option>
            		<option value="datesubmitted">'. $this->lang->line('data_export_tst_sbmt_date') . '</option>
            		<option value="result">'. $this->lang->line('sntl_chkn_mgmt_rslt') . '</option>
            		<option value="dateresults">'. $this->lang->line('data_export_rslts_rcvd_date') . '</option>
            		<option value="rampunits">'. $this->lang->line('data_export_rmpunts') . '</option>
            		<option value="confirmedrtpcr">'. $this->lang->line('data_export_rtprc_cnfrmd') . '</option>
            		<option value="resultscorrespond">'. $this->lang->line('data_export_rslts_crrspnd') . '</option>
            		<option value="virustypes">' . $this->lang->line('arbvrl_actvty_virus') . '</option>
            		<option value="assaytype">'. $this->lang->line('data_exprt_assy_type') . '</option>
            		<option value="comments">'. $this->lang->line('cmn_lbl_cmnts') . '</option>
            		<option value="address1">'. $this->lang->line('site_mgmt_addrs_1') . '</option>
            		<option value="address2">'. $this->lang->line('site_mgmt_addrs_2') . '</option>
            		<option value="city">'. $this->lang->line('site_mgmt_cty') . '</option>
            		<option value="statename">'. $this->lang->line('site_mgmt_state') . '</option>
            		<option value="postalcode">'. $this->lang->line('site_mgmt_postal_code') . '</option>
            		<option value="latitude">'. $this->lang->line('site_mgmt_lat') . '</option>
            		<option value="longitude">'. $this->lang->line('site_mgmt_lng') . '</option';
			
			if (! empty ( $case )) {
				return $str;
			} else {
				echo json_encode ( array (
						'data_json' => $str 
				) );
				exit ();
			}
		}
	}
	
	/**
	 * Function to fetch Service Requests Columns
	 */
	public function getservicecolumn($case = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
            
			$str = '<option value="zone">' . $this->lang->line('site_mgmt_zone') . '</option>
            		<option value="site">'. $this->lang->line('whthr_snsr_site') . '</option>
            		<option value="description">'. $this->lang->line('usr_grp_mgmt_dscptn') . '</option>
            		<option value="requested_by">'. $this->lang->line('rprtng_wzrd_entrdby') . '</option>
                    <option value="firstname">'. $this->lang->line('rprtng_wzrd_cllr_frstname') . '</option>
                    <option value="lastname">'. $this->lang->line('rprtng_wzrd_cllr_lstname') . '</option>
                    <option value="applicator">'. $this->lang->line('wrk_asgnmnts_assgndto') . '</option>
            		<option value="opendate">'. $this->lang->line('wrk_asgnmnts_open_date') . '</option>
            		<option value="closedate">'. $this->lang->line('wrk_asgnmnts_close_date') . '</option>
            		<!--<option value="notes">'. $this->lang->line('prdct_ovrvw_past_cmnts') . '</option>-->
            		<option value="action">'. $this->lang->line('dspstns_hdng') . '</option>
            		<option value="inspection">'. $this->lang->line('data_exprt_inspctn') . '</option>
            		<option value="surveillance">'. $this->lang->line('mmbr_mgmt_srvlnce') . '</option>
            		<option value="treatment">'. $this->lang->line('trtmnts_hdng') . '</option>
            		<option value="address1">'. $this->lang->line('site_mgmt_addrs_1') . '</option>
            		<option value="address2">'. $this->lang->line('site_mgmt_addrs_2') . '</option>
            		<option value="city">'. $this->lang->line('site_mgmt_cty') . '</option>
            		<option value="statename">'. $this->lang->line('site_mgmt_state') . '</option>
            		<option value="postalcode">'. $this->lang->line('site_mgmt_postal_code') . '</option>
            		<option value="latitude">'. $this->lang->line('site_mgmt_lat') . '</option>
            		<option value="longitude">'. $this->lang->line('site_mgmt_lng') . '</option>
                    <option value="comments">'. $this->lang->line('cmn_lbl_cmnts') . '</option>';
			
            if($this->session->userdata('idlocation') == '36' || $this->session->userdata('idlocation') == '1'){
                $str .= '<option value="wasource">' . $this->lang->line('arbvrl_actvty_virus') . '</option>';
            }
            
			if (! empty ( $case )) {
				return $str;
			} else {
				echo json_encode ( array (
						'data_json' => $str 
				) );
				exit ();
			}
		}
	}
	
	/**
	 * Function to fetch Adult Treatment Columns
	 */
	public function gettrtadultcolumn($case = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$str = '<option value="zone">' . $this->lang->line('site_mgmt_zone') . '</option>
            		<option value="site">'. $this->lang->line('whthr_snsr_site') . '</option>
                    <option value="sitegroup">'. $this->lang->line('grp_mgmt_site_grp') . '</option>
            		<option value="date">' . $this->lang->line('trtmnts_datetime') . '</option>
            		<option value="applicationrate">'. $this->lang->line('adlt_trtmnt_app_rate') . '</option>
            		<option value="applicationrateuom">'. $this->lang->line('data_exprt_app_area_unt') . '</option>
            		<option value="applicationstartdate">'. $this->lang->line('adlt_trtmnt_app_start_dttm') . '</option>
            		<option value="applicationenddate">'. $this->lang->line('adlt_trtmnt_app_end_dttm') . '</option>
            		<option value="areaname">'. $this->lang->line('data_export_area_name') . '</option>
            		<option value="totalareatreated">'. $this->lang->line('adlt_trtmnt_area_trtd') . '</option>
            		<option value="unitarea">'. $this->lang->line('data_exprt_area_unts') . '</option>
                    <option value="applicationmethod">'. $this->lang->line('adlt_trtmnt_app_methd') . '</option>
            		<option value="applicationratetype">'. $this->lang->line('adlt_trtmnt_app_rate_type') . '</option>
            		<option value="totalproductapplied">' . $this->lang->line('adlt_trtmnt_ttl_prdct_appld') . '</option>
                    <option value="unitproduct">'. $this->lang->line('rprtng_wzrd_prdct_unt') . '</option>
            		<option value="odometerstart">'. $this->lang->line('adlt_trtmnt_odmtr_strt') . '</option>
            		<option value="odometerend">'. $this->lang->line('adlt_trtmnt_odmtr_end') . '</option>
                    <option value="finishedmix">'. $this->lang->line('adlt_trtmnt_finished_mix') . '</option>
                    <option value="unitfinishedmix">'. $this->lang->line('data_export_fnshd_mxunt') . '</option>
            		<option value="flowrate">'. $this->lang->line('adlt_trtmnt_flw_rate') . '</option>
                    <option value="fl">'. $this->lang->line('data_export_flw_rate_type') . '</option>
            		<option value="equipmentserial">'. $this->lang->line('data_export_eqpmnt_srl_num') . '</option>
            		<option value="systemtype">' . $this->lang->line('data_export_trtmnt_systm') . '</option>
            		<option value="justification">' . $this->lang->line('drpdwn_treatment_justification') . '</option>
            		<option value="adult">'. $this->lang->line('data_export_adlt') . '</option>
            		<option value="aerial">'. $this->lang->line('data_export_arl') .'</option>
            		<option value="larval">'. $this->lang->line('lrvl_srvlnc_lrvl') . '</option>
            		<option value="applicator">'. $this->lang->line('adlt_trtmnt_applicator') . '</option>
            		<option value="applicatorphn">'. $this->lang->line('data_export_applctr_phn') . '</option>
            		<option value="productname">'. $this->lang->line('data_export_prdct_name') . '</option>
            		<option value="productcode">'. $this->lang->line('prdct_ovrvw_prdct_cde') . '</option>
            		<option value="productlink">' . $this->lang->line('data_export_url') . '</option>
            		<option value="formulation">'. $this->lang->line('data_export_prdct_frmltn') . '</option>
            		<option value="packsize">'. $this->lang->line('prdct_ovrvw_pck_sze') . '</option>
            		<option value="productsize">'. $this->lang->line('prdct_ovrvw_prdct_sze') . '</option>
            		<option value="potency">'. $this->lang->line('data_export_prdct_ptncy') . '</option>
                    <option value="onhand">'. $this->lang->line('data_export_prdct_qty') . '</option>
            		<option value="dilutent">'. $this->lang->line('drpdwn_dilutent') . '</option>
            		<option value="mixratio">'. $this->lang->line('adlt_trtmnt_mix_ratio') . '</option>
            		<option value="manufacturer">'. $this->lang->line('prdct_ovrvw_mnfctrr') . '</option>
            		<option value="humidityrange">'. $this->lang->line('adlt_srvlnc_humdity') . '</option>
            		<option value="cloudcoverage">'. $this->lang->line('adlt_srvlnc_cloud_cvr') . '</option>
					<option value="windspeed">'. $this->lang->line('adlt_srvlnc_wnd_spd') . '</option>
					<option value="winddirection"> ' . $this->lang->line('adlt_trtmnt_wnd_drctn') . '</option>
            		<option value="tempstart">'. $this->lang->line('data_export_temp_strt') . '</option>
            		<option value="tempend">'. $this->lang->line('data_export_temp_strt') . '</option>
            		<option value="comments">'. $this->lang->line('cmn_lbl_cmnts') . '</option>
            		<option value="address1">'. $this->lang->line('site_mgmt_addrs_1') . '</option>
            		<option value="address2">'. $this->lang->line('site_mgmt_addrs_2') . '</option>
            		<option value="city">'. $this->lang->line('site_mgmt_cty') . '</option>
            		<option value="statename">'. $this->lang->line('site_mgmt_state') . '</option>
            		<option value="postalcode">'. $this->lang->line('site_mgmt_postal_code') . '</option>
            		<option value="latitude">'. $this->lang->line('site_mgmt_lat') . '</option>
            		<option value="longitude">'. $this->lang->line('site_mgmt_lng') . '</option>
                    <option value="pti">'. $this->lang->line('lrvl_trtmnt_pti') . '</option>
            		<option value="ptidate">'. $this->lang->line('lrvl_trtmnts_pti_date') . '</option>';
			
			if (! empty ( $case )) {
				return $str;
			} else {
				echo json_encode ( array (
						'data_json' => $str 
				) );
				exit ();
			}
		}
	}
	
	/**
	 * Function to fetch Larval Treatment Columns
	 */
	public function gettrtlarvalcolumn($case = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$str = '<option value="zone">' . $this->lang->line('site_mgmt_zone') . '</option>
            		<option value="site">'. $this->lang->line('whthr_snsr_site') . '</option>
                    <option value="sitegroup">'. $this->lang->line('grp_mgmt_site_grp') . '</option>
            		<option value="sitetype">'. $this->lang->line('trap_mgmt_site_type') . '</option>
            		<option value="sitestatus">'. $this->lang->line('lrvl_srvlnc_site_stts') . '</option>
            		<option value="date">' . $this->lang->line('trtmnts_datetime') . '</option>
                    <option value="applicationmethod">'. $this->lang->line('adlt_trtmnt_app_methd') . '</option>
            		<option value="applicationrate">'. $this->lang->line('adlt_trtmnt_app_rate') . '</option>
                    <option value="applicationrateuom">'. $this->lang->line('data_exprt_app_area_unt') . '</option>
            		<option value="totalareatreated">'. $this->lang->line('lrvl_trtmnt_ttl_area_trtd') . '</option>
                    <option value="unitarea">'. $this->lang->line('data_exprt_area_unts') . '</option>
            		<option value="totalproductapplied">' . $this->lang->line('adlt_trtmnt_ttl_prdct_appld') . '</option>
                    <option value="unitproduct">'. $this->lang->line('rprtng_wzrd_prdct_unt') . '</option>
            		<option value="equipemtnid">'. $this->lang->line('lrvl_trtmnt_eqpmntid') . '</option>
            		<option value="larvaepresent">'. $this->lang->line('lrvl_srvlnc_larvae_presnt') . '</option>
            		<option value="totalcount">'. $this->lang->line('lrvl_srvlnc_larvae_cnt') . '</option>
            		<option value="watertemprange">' . $this->lang->line('data_exprt_water_temp') . '</option>
					<option value="windspeed">'. $this->lang->line('adlt_srvlnc_wnd_spd') . '</option>
					<option value="winddirection"> ' . $this->lang->line('adlt_trtmnt_wnd_drctn') . '</option>
            		<option value="followup">'. $this->lang->line('data_export_fllwup') . '</option>
            		<option value="sample">'. $this->lang->line('data_export_smpl') . '</option>
            		<option value="sourcereduction">'. $this->lang->line('drpdwn_source_reduction') . '</option>
            		<option value="sourcereductioncomments">'. $this->lang->line('lrvl_trtmnt_srcrdctn_cmnts') . '</option>
            		<option value="weathercondition">' . $this->lang->line('data_export_wthr_cndtn') . '</option>
            		<option value="instar">'. $this->lang->line('lrvl_srvlnc_instar') . '</option>
                    <option value="justification">' . $this->lang->line('drpdwn_treatment_justification') . '</option>
            		<option value="adult">'. $this->lang->line('data_export_adlt') . '</option>
            		<option value="aerial">'. $this->lang->line('data_export_arl') .'</option>
            		<option value="larval">'. $this->lang->line('lrvl_srvlnc_lrvl') . '</option>
            		<option value="applicator">'. $this->lang->line('adlt_trtmnt_applicator') . '</option>
            		<option value="applicatorphn">'. $this->lang->line('data_export_applctr_phn') . '</option>
            		<option value="areaname">'. $this->lang->line('data_export_area_name') . '</option>
            		<option value="applicationratetype">'. $this->lang->line('adlt_trtmnt_app_rate_type') . '</option>
            		<option value="productname">'. $this->lang->line('data_export_prdct_name') . '</option>
            		<option value="productcode">'. $this->lang->line('prdct_ovrvw_prdct_cde') . '</option>
            		<option value="productlink">' . $this->lang->line('data_export_url') . '</option>
            		<option value="formulation">'. $this->lang->line('data_export_prdct_frmltn') . '</option>
            		<option value="onhand">'. $this->lang->line('data_export_prdct_qty') . '</option>
            		<option value="packsize">'. $this->lang->line('prdct_ovrvw_pck_sze') . '</option>
            		<option value="productsize">'. $this->lang->line('prdct_ovrvw_prdct_sze') . '</option>
            		<option value="productpotency">'. $this->lang->line('rprtng_wzrd_prdct_ptncy_name') . '</option>
            		<option value="manufacturer">'. $this->lang->line('prdct_ovrvw_mnfctrr') . '</option>
            		<option value="mixratio">'. $this->lang->line('adlt_trtmnt_mix_ratio') . '</option>
            		<option value="systemtype">' . $this->lang->line('data_export_trtmnt_systm') . '</option>
            		<option value="species">'. $this->lang->line('lnding_rte_spcies') . '</option>
            		<option value="subspecies">'. $this->lang->line('data_exprt_subspcs') . '</option>
            		<option value="habitat">'. $this->lang->line('data_exprt_habtt') . '</option>
            		<option value="comments">'. $this->lang->line('cmn_lbl_cmnts') . '</option>
            		<option value="finishedmix">'. $this->lang->line('adlt_trtmnt_finished_mix') . '</option>
                    <option value="unitfinishedmix">'. $this->lang->line('data_export_fnshd_mxunt') . '</option>
            		<option value="address1">'. $this->lang->line('site_mgmt_addrs_1') . '</option>
            		<option value="address2">'. $this->lang->line('site_mgmt_addrs_2') . '</option>
            		<option value="city">'. $this->lang->line('site_mgmt_cty') . '</option>
            		<option value="statename">'. $this->lang->line('site_mgmt_state') . '</option>
            		<option value="postalcode">'. $this->lang->line('site_mgmt_postal_code') . '</option>
            		<option value="latitude">'. $this->lang->line('site_mgmt_lat') . '</option>
            		<option value="longitude">'. $this->lang->line('site_mgmt_lng') . '</option>
                    <option value="post_trtmnt_inspection">'. $this->lang->line('lrvl_trtmnt_pti') . '</option>
            		<option value="post_trtmnt_date">'. $this->lang->line('lrvl_trtmnts_pti_date') . '</option>';
			
			if (! empty ( $case )) {
				return $str;
			} else {
				echo json_encode ( array (
						'data_json' => $str 
				) );
				exit ();
			}
		}
	}
	
	/**
	 * Function to fetch Weather Collection Columns
	 */
	public function getweathercolumn($case = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$str = '<option value="sensor_name">'. $this->lang->line('data_exprt_snsr') . '</option>
            		<option value="weathersensor">' . $this->lang->line('prdct_ovrvw_type') . '</option>
            		<option value="date">' . $this->lang->line('data_export_obsrvtn_dttm') . '</option>
            		<option value="rainfall">'. $this->lang->line('data_export_rnfll') . '</option>
            		<option value="weathercondition">' . $this->lang->line('data_export_wthr_cndtn') . '</option>
            		
            		<option value="windspeed">'. $this->lang->line('adlt_srvlnc_wnd_spd') . '</option>
            		<option value="winddegree">'. $this->lang->line('data_export_dgrs') . '</option>
            		<option value="temprange">'. $this->lang->line('adlt_srvlnc_temp') . '</option>
            		<option value="humidityrange">'. $this->lang->line('adlt_srvlnc_humdity') . '</option>
            		<option value="cloudcoverage">'. $this->lang->line('adlt_srvlnc_cloud_cvr') . '</option>
            		<option value="hightide_date">'. $this->lang->line('data_export_hghtde_dttm') . '</option>
            		<option value="hightide_height">'. $this->lang->line('data_export_hghtd_ht') . '</option>
            		<option value="lowtide_date">'. $this->lang->line('data_export_lwtd_dttm') . '</option>
            		<option value="lowtide_height">'. $this->lang->line('data_export_lwtd_ht') . '</option>';
			
			if (! empty ( $case )) {
				return $str;
			} else {
				echo json_encode ( array (
						'data_json' => $str 
				) );
				exit ();
			}
		}
	}

	/**
	 * Function to fetch Maintenance Inspection Columns
	 */
	public function getmaintenanceinspectioncolumn($case = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$str = '<option value="zone">' . $this->lang->line('site_mgmt_zone') . '</option>
            		<option value="site">'. $this->lang->line('whthr_snsr_site') . '</option>
                    <option value="observeddate">'. $this->lang->line('maintainence_inspection_observeddate') . '</option>
            		<option value="observedtime">'. $this->lang->line('maintainence_inspection_observedtime') . '</option>
            		<option value="observeddatetime">'. $this->lang->line('maintainence_inspection_observeddatetime') . '</option>
            		<option value="idinspector">' . $this->lang->line('maintainence_inspection_idinspector') . '</option>
					<option value="reinspection">'. $this->lang->line('maintainence_inspection_reinspection') . '</option>
					<option value="parcelnumber">' . $this->lang->line('outfall_parcelnumber') . '</option>
            		<option value="lastdateobserved">'. $this->lang->line('maintainence_inspection_lastdateobserved') . '</option>
                    <option value="lasttimeobserved">'. $this->lang->line('maintainence_inspection_lasttimeobserved') . '</option>
            		<option value="ownerinformation">'. $this->lang->line('maintainence_inspection_ownerinformation') . '</option>
                    <option value="outfallnumber">'. $this->lang->line('maintainence_inspection_outfallnumber') . '</option>
            		<option value="watershed">' . $this->lang->line('maintainence_inspection_watershed') . '</option>
                    <option value="localcontact">'. $this->lang->line('maintainence_inspection_localcontact') . '</option>
            		<option value="arcms4outfall">'. $this->lang->line('maintainence_inspection_arcms4outfall') . '</option>
            		<option value="maplabel">'. $this->lang->line('maintainence_inspection_maplabel') . '</option>
            		<option value="comments">'. $this->lang->line('maintainence_inspection_comments') . '</option>
            		<option value="installed_flag">' . $this->lang->line('maintainence_inspection_installed_flag') . '</option>
					<option value="installed_notes">'. $this->lang->line('maintainence_inspection_installed_notes') . '</option>
					<option value="intact_flag"> ' . $this->lang->line('maintainence_inspection_intact_flag') . '</option>
            		<option value="intact_notes">'. $this->lang->line('maintainence_inspection_intact_notes') . '</option>
            		<option value="locked_flag">'. $this->lang->line('maintainence_inspection_locked_flag') . '</option>
            		<option value="locked_notes">'. $this->lang->line('maintainence_inspection_locked_notes') . '</option>
            		<option value="overgrown_flag">'. $this->lang->line('maintainence_inspection_overgrown_flag') . '</option>
            		<option value="overgrown_notes">' . $this->lang->line('maintainence_inspection_overgrown_notes') . '</option>
            		<option value="surfaceerosion_flag">'. $this->lang->line('maintainence_inspection_surfaceerosion_flag') . '</option>
                    <option value="surfaceerosion_notes">' . $this->lang->line('maintainence_inspection_surfaceerosion_notes') . '</option>
            		<option value="stagnatewater_flag">'. $this->lang->line('maintainence_inspection_stagnatewater_flag') . '</option>
            		<option value="stagnatewater_notes">'. $this->lang->line('maintainence_inspection_stagnatewater_notes') .'</option>
            		<option value="trashdebrisfree_flag">'. $this->lang->line('maintainence_inspection_trashdebrisfree_flag') . '</option>
            		<option value="trashdebrisfree_notes">'. $this->lang->line('maintainence_inspection_trashdebrisfree_notes') . '</option>
					<option value="banksintact_flag">'. $this->lang->line('maintainence_inspection_banksintact_flag') . '</option>
					<option value="banksintact_notes">' . $this->lang->line('maintainence_inspection_banksintact_notes') . '</option>
					<option value="damcracking_flag">'. $this->lang->line('maintainence_inspection_damcracking_flag') . '</option>
            		<option value="damcracking_notes">'. $this->lang->line('maintainence_inspection_damcracking_notes') . '</option>
            		<option value="channelizedflow_flag">'. $this->lang->line('maintainence_inspection_channelizedflow_flag') . '</option>
            		<option value="channelizedflow_notes">'. $this->lang->line('maintainence_inspection_channelizedflow_notes') . '</option>
            		<option value="controlstructureintact_flag">'. $this->lang->line('maintainence_inspection_controlstructureintact_flag') . '</option>
            		<option value="controlstructureintact_notes">'. $this->lang->line('maintainence_inspection_controlstructureintact_notes') . '</option>
            		<option value="trashaccumulation_flag">'. $this->lang->line('maintainence_inspection_trashaccumulation_flag') . '</option>
            		<option value="trashaccumulation_notes">'. $this->lang->line('maintainence_inspection_trashaccumulation_notes') . '</option>
            		<option value="emergencyspillway_flag">'. $this->lang->line('maintainence_inspection_emergencyspillway_flag') . '</option>
            		<option value="emergencyspillway_notes">'. $this->lang->line('maintainence_inspection_emergencyspillway_notes') . '</option>
            		<option value="outflowstructureintact_flag">'. $this->lang->line('maintainence_inspection_outflowstructureintact_flag') . '</option>
            		<option value="outflowstructureintact_notes">' . $this->lang->line('maintainence_inspection_outflowstructureintact_notes') . '</option>
            		<option value="outflowstructurefunctional_flag">'. $this->lang->line('maintainence_inspection_outflowstructurefunctional_flag') . '</option>
            		<option value="outflowstructurefunctional_notes">'. $this->lang->line('maintainence_inspection_outflowstructurefunctional_notes') . '</option>
            		<option value="dischargeoutletaccessible">'. $this->lang->line('maintainence_inspection_dischargeoutletaccessible') . '</option>
            		<option value="outletcontrolpresent">'. $this->lang->line('maintainence_inspection_outletcontrolpresent') . '</option>
            		<option value="dischargepipediameter">'. $this->lang->line('maintainence_inspection_dischargepipediameter') . '</option>
                    <option value="dischargepipematerial">'. $this->lang->line('maintainence_inspection_dischargepipematerial') . '</option>';
			
			if (! empty ( $case )) {
				return $str;
			} else {
				echo json_encode ( array (
						'data_json' => $str 
				) );
				exit ();
			}
		}
	}

	/**
	 * Function to fetch Maintenance Inspection Columns
	 */
	 public function getoutfallinspectioncolumn($case = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$str = '<option value="zone">' . $this->lang->line('site_mgmt_zone') . '</option>
            		<option value="site">'. $this->lang->line('whthr_snsr_site') . '</option> 
            		<option value="date">' . $this->lang->line('wthr_date') . '</option>
                    <option value="time">'. $this->lang->line('cmn_time') . '</option>
            		<option value="observeddatetime">'. $this->lang->line('rprtng_wzrd_date_obsrvd') . '</option>
                    <option value="weather">'. $this->lang->line('sidebar_data_entry_wthr') . '</option>
            		<option value="lastraintime">'. $this->lang->line('outfall_lastraintime') . '</option>
                    <option value="lastrainquantity">'. $this->lang->line('outfall_last_rain_quantity') . '</option>
            		<option value="parcelnumber">' . $this->lang->line('outfall_parcelnumber') . '</option>
                    <option value="outfallnumber">'. $this->lang->line('outfall_outfallnumber') . '</option>
            		<option value="watershed">'. $this->lang->line('outfall_watershed') . '</option>
            		<option value="localwatersheduses">'. $this->lang->line('outfall_localwatersheduses') . '</option>
            		<option value="outfalldimensions">' . $this->lang->line('outfall_localwateroutfalldimensions') . '</option>
					<option value="dischargeobserved">'. $this->lang->line('outfall_dischargeobserved') . '</option>
					<option value="color"> ' . $this->lang->line('outfall_color') . '</option>
            		<option value="odor">'. $this->lang->line('outfall_odor') . '</option>
            		<option value="oilsheen">'. $this->lang->line('outfall_oilsheen') . '</option>
            		<option value="floatingsolids">'. $this->lang->line('outfall_floatingsolids') . '</option>
            		<option value="suspendedsolids">'. $this->lang->line('outfall_suspendedsolids') . '</option>
            		<option value="staining">' . $this->lang->line('outfall_staining') . '</option>
            		<option value="flora">'. $this->lang->line('outfall_flora') . '</option>
                    <option value="fauna">' . $this->lang->line('outfall_fauna') . '</option>
            		<option value="structuralcondition">'. $this->lang->line('outfall_structuralcondition') . '</option>
            		<option value="approxvelocity">'. $this->lang->line('outfall_approxvelocity') .'</option>
            		<option value="waterdepthinpipe">'. $this->lang->line('outfall_waterdepthinpipe') . '</option>
            		<option value="watertemperature">'. $this->lang->line('outfall_watertemperature') . '</option>
            		<option value="conductivity">'. $this->lang->line('outfall_conductivity') . '</option>
            		<option value="ph">'. $this->lang->line('outfall_ph') . '</option>
            		<option value="turbidity">'. $this->lang->line('outfall_turbidity') . '</option>
            		<option value="flouride">'. $this->lang->line('outfall_flouride') . '</option>
            		<option value="detergents">'. $this->lang->line('outfall_detergents') . '</option>
            		<option value="samplecollected">' . $this->lang->line('outfall_samplecollected') . '</option>
            		<option value="laboratoryanalyses">'. $this->lang->line('outfall_laboratoryanalyses') . '</option>
            		<option value="maplabel">'. $this->lang->line('outfall_maplabel') . '</option>';
			
			if (! empty ( $case )) {
				return $str;
			} else {
				echo json_encode ( array (
						'data_json' => $str 
				) );
				exit ();
			}
		}
	}
	
	/**
	 * Function to convert data into Excel
	 */
	public function toEXCELAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			// print'<pre>';
			// print_r($_POST);
			// die;
			
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			$all_fields_1 = $this->input->get_post ( 'all_fields_1' );
			$msg = $this->input->get ( 'msg' );
			$exs_report = $this->input->post ( 'existing_report' );
			$this->report_type = $this->input->post ( 'report_type' );
			$this->report_name = $this->input->post ( 'report_name' );
			$this->columns_1 = $this->input->post ( 'columns' );
			$this->columns = $this->input->post ( 'column_2' );
			$this->allzone = $this->input->post ( 'idzone' );
			$this->allsite = $this->input->post ( 'idsite' );
			$this->column_name = $this->input->post ( 'column_name' );
			$this->all_fields = $all_fields_1;
			$action_name = $this->input->post ( 'action_name' );
			$action = $this->input->post ( 'action' );
			$type = $this->input->post ( 'type' );
			$save = $this->input->post ( 'save' );
			// echo $type;die;
			
			if (! empty ( $this->column_name )) {
				$this->column_name = explode ( ",", $this->column_name );
			}
			
			if (! empty ( $this->columns )) {
				$this->columns = urldecode(base64_decode ( $this->columns ));
				$this->columns = str_replace ( ",", "", $this->columns );
			}
			
			if (! empty ( $action ))
				$action = explode ( ",", $action );
			
			$data_1 = array ();
			// echo $startdate." ".$enddate;
			// print'<pre>';
			// print_r($_POST);
			// die;
			
			if (! empty ( $this->allsite )) {
				foreach ( $this->sites as $k => $v ) {
					if (in_array ( $v ['idsite'], $this->allsite )) {
						$this->sites [$k] ['chk'] = "1";
					}
				}
			}
			
			if (! empty ( $this->allzone )) {
				foreach ( $this->zones as $k => $v ) {
					if (in_array ( $v ['idzone'], $this->allzone )) {
						$this->zones [$k] ['chk'] = "1";
					}
				}
			}
			
			if (! empty ( $startdate ))
				$this->startdate = $startdate;
			
			if (! empty ( $enddate ))
				$this->enddate = $enddate;
			
			$this->products = $this->reporting_model->getReporting ( $this->startdate, $this->enddate, $this->report_type, $this->report_name, $this->allsite, $this->allzone );
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_rprtng_wzrd'),
					'page' => "reporting",
					'startdate' => $this->startdate,
					'starttime' => date ( 'h:i:s A', strtotime ( $this->starttime ) ),
					'endtime' => date ( 'h:i:s A', strtotime ( $this->endtime ) ),
					'enddate' => $this->enddate,
					'inspector' => $this->inspector,
					'currentdate' => $this->currentdate,
					'currenttime' => date ( "h:i:s A", strtotime ( $this->currenttime ) ),
					'columns_1' => $this->columns_1,
					'report_name' => $this->report_name,
					'report_type' => $this->report_type,
					'all_fields' => $this->all_fields,
					'column_name' => $this->column_name,
					'products' => $this->products 
			);
			
			// print'<pre>';
			// print_r($data_1);
			// die;
			$data_1 = $this->load->view ( 'reportings/pdf_view', $data_1, TRUE );
			// print'<pre>';
			// print_r($data_1);
			// die;
			
			$filename = ! empty ( $this->report_name ) ? str_replace ( " ", "_", $this->report_name ) . ".xls" : $this->lang->line('rprtng_wzrd_rprt') . ".xls";
			
			// print'<pre>';
			// print_r($data_1);
			// die;
			
			header ( "Content-type: application/octet-stream" );
			header ( "Content-Disposition: attachment; filename=" . $filename );
			header ( "Pragma: no-cache" );
			header ( "Expires: 0" );
			
			echo $data_1;
			exit ();
		}
	}
}

/* End of file reporting.php */
/* Location: ./application/controllers/reporting.php */