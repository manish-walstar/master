<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Adulttreatment_report extends CI_Controller {
	public $products;
	public $adult_treatment;
	public $product_list;
	public $startdate;
	public $starttime;
	public $enddate;
	public $endtime;
	public $inspector;
	public $currentdate;
	public $currenttime;
	public $endtimestamp;
	public $starttimestamp;
	public $userinfo;
    public $app_lang;
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		$this->load->helper('language');
		$this->load->model ( 'adulttreatment_report_model' );
		$this->load->model ( 'usermodel' );
		$this->currentdate = date ( 'm/d/Y' );
		$this->currenttime = date ( "h:i:s a" );
		
		$this->usermodel->set_access_session ();
		
		if (! $this->usermodel->user_access ( 'reports' ) && ! $this->usermodel->user_access ( 'company_admin' ))
			redirect ( base_url () );
		
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		$this->enddate = date ( 'm/d/Y' );
		$this->endtime = date ( 'h:i:s' );
		
		$this->startdate = date ( 'm/d/Y', strtotime ( "-30 day" ) );
		$this->starttime = date ( 'h:i:s' );
		
		$this->endtimestamp = strtotime ( date ( 'm/d/Y H:i:s' ) );
		
		$this->starttimestamp = strtotime ( date ( 'm/d/Y H:i:s', strtotime ( "-10 day" ) ) );
		
		if ($this->session->userdata ( 'id' )) {
			$this->adult_treatment = $this->adulttreatment_report_model->getAdultTreatment ( $this->startdate, $this->enddate );
			// print('<pre>');
			// print_r($this->adult_treatment);
			// die;
			$id = $this->session->userdata ( 'id' );
			$id_arr = explode ( "_", json_decode ( base64_decode ( $id ) ) );
			
			$id = json_decode ( base64_decode ( $id_arr [0] ) );
			
			$this->userinfo = $this->usermodel->getUserData ( $id );
			
			$middlename = " ";
			if (isset ( $this->userinfo ['middlename'] ))
				$middlename = ! empty ( $this->userinfo ['middlename'] ) ? " " . $this->userinfo ['middlename'] . " " : " ";
			
			if (isset ( $this->userinfo ['firstname'] ) || isset ( $this->userinfo ['lastname'] ))
				$this->inspector = $this->userinfo ['firstname'] . $middlename . $this->userinfo ['lastname'];
			
			$this->products = $this->adulttreatment_report_model->getProducts ( $this->startdate, $this->enddate );
			$this->product_list = $this->adulttreatment_report_model->getProducts_I ( $this->startdate, $this->enddate );
			// die;
			
			// print('<pre>');
			// print_r($this->adult_treatment);
			// die;
		}
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			redirect ( base_url () . "adulttreatment_report/getadulttreatment" );
		}
	}
	
	/**
	 * Function to fetch All products
	 */
	public function getadulttreatment() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			
			// echo
			$data_1 = array ();
			
			if (empty ( $startdate ) && empty ( $enddate )) {
				$data_1 = array (
						'username' => $this->session->userdata ( 'username' ),
						'logstatus' => "logout",
						'title' => $this->lang->line('adlt_trtmnt_rprt_hdng'),
						'page' => "adulttreatment",
						'startdate' => $this->startdate,
						'starttime' => date ( 'h:i:s A', strtotime ( $this->starttime ) ),
						'endtime' => date ( 'h:i:s A', strtotime ( $this->endtime ) ),
						'enddate' => $this->enddate,
						'inspector' => $this->inspector,
						'currentdate' => $this->currentdate,
						'currenttime' => date ( "h:i:s A", strtotime ( $this->currenttime ) ),
						'products' => $this->products,
						'product_list' => $this->product_list 
				);
			} else {
				// echo $startdate." ".$enddate;
				
				// $startdate_arr = explode(" ",$startdate);
				// $enddate_arr = explode(" ",$enddate);
				//
				// $this->startdate = date('m/d/Y',strtotime($startdate_arr[0]));
				//
				// $this->enddate = date('m/d/Y',strtotime($enddate_arr[0]));
				//
				// $this->endtimestamp = strtotime($enddate);
				//
				// $this->starttimestamp = strtotime($startdate);
				
				if (! empty ( $startdate ) && ! empty ( $enddate )) {
					$this->startdate = $startdate;
					
					$this->enddate = $enddate;
				}
				
				// echo $this->startdate." ".$this->enddate;
				
				$this->products = $this->adulttreatment_report_model->getProducts ( $this->startdate, $this->enddate );
				$this->product_list = $this->adulttreatment_report_model->getProducts_I ( $this->startdate, $this->enddate );
				
				// print('<pre>');
				// print_r($this->products);
				// print_r($this->product_list);
				// die;
				// print'<pre>';
				// print_r($startdate);
				// print_r($enddate);
				// echo $this->startdate." ".$this->starttime."<br>";
				// echo $this->enddate." ".$this->endtime;
				// die;
				
				$data_1 = array (
						'username' => $this->session->userdata ( 'username' ),
						'logstatus' => "logout",
						'title' => $this->lang->line('adlt_trtmnt_rprt_hdng'),
						'page' => "adulttreatment",
						'startdate' => $this->startdate,
						'starttime' => date ( 'h:i:s A', strtotime ( $this->starttime ) ),
						'endtime' => date ( 'h:i:s A', strtotime ( $this->endtime ) ),
						'enddate' => $this->enddate,
						'inspector' => $this->inspector,
						'currentdate' => $this->currentdate,
						'currenttime' => date ( "h:i:s A", strtotime ( $this->currenttime ) ),
						'products' => $this->products,
						'product_list' => $this->product_list 
				);
			}
			 //print('<pre>');
//			 print_r($data_1);
//			 print_r($this->products);
//			 die;
			
			$this->load->view ( 'header', $data_1 );
			
			$this->load->view ( 'left_sidebar', $data_1 );
			
			$this->load->view ( 'adulttreatment_reports/adulttreatment_reports', $data_1 );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to fetch the data
	 * and format it in order to return
	 */
	public function exportView() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			$ctime = $this->input->post ( 'current_time' );
			
			$this->currenttime = ! empty ( $ctime ) ? $ctime : $this->currenttime;
			
			$data_1 = array ();
			
			if (! empty ( $startdate ) && ! empty ( $enddate )) {
				$this->startdate = $startdate;
				
				$this->enddate = $enddate;
			}
			
			$this->products = $this->adulttreatment_report_model->getProducts ( $this->startdate, $this->enddate );
			$this->product_list = $this->adulttreatment_report_model->getProducts_I ( $this->startdate, $this->enddate );
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('adlt_trtmnt_rprt_hdng'),
					'page' => "adulttreatment",
					'startdate' => $this->startdate,
					'starttime' => date ( 'h:i:s A', strtotime ( $this->starttime ) ),
					'endtime' => date ( 'h:i:s A', strtotime ( $this->endtime ) ),
					'enddate' => $this->enddate,
					'inspector' => $this->inspector,
					'currentdate' => $this->currentdate,
					'currenttime' => date ( "h:i:s A", strtotime ( $this->currenttime ) ),
					'products' => $this->products,
					'product_list' => $this->product_list 
			);
			
			// print('<pre>');
			// print_r($data_1);
			// die;
			$data = $this->load->view ( 'adulttreatment_reports/pdf_view', $data_1, TRUE );
			// print'<pre>';
			// print_r($data);
			// die;
			//
			return $data;
		}
	}
	
	/**
	 * Function to return Query
	 * that fetches data
	 */
	public function returnViewQuery() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			
			if (! empty ( $startdate ) && ! empty ( $enddate )) {
				$this->startdate = $startdate;
				$this->enddate = $enddate;
			}
			
			$query = $this->adulttreatment_report_model->getAdultTreatmentQuery ( $this->startdate, $this->enddate );
			
			return $query;
		}
	}
	
	/**
	 * Function to convert data into PDF
	 */
	public function toPDFAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->helper ( 'pdf_helper' );
			$data = $this->exportView ();
			// print'<pre>';
			// print_r($data);
			// die;
			//
			create_pdf_l ( $data, $this->lang->line('adlt_trtmnt_hdng') );
		}
	}
	
	/**
	 * Function to convert data into Excel
	 */
	public function toEXCELAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$data = $this->exportView ();
			// print'<pre>';
			// print_r($data);
			// die;
			//
			header ( "Content-type: application/octet-stream" );
			header ( "Content-Disposition: attachment; filename=".$this->lang->line('adlt_trtmnt_hdng').".xls" );
			header ( "Pragma: no-cache" );
			header ( "Expires: 0" );
			
			echo $data;
			exit ();
		}
	}
	
	/**
	 * Function to convert data into Word
	 */
	public function toWORDAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			header ( "Content-Type: application/vnd.ms-word" );
			header ( "Expires: 0" );
			header ( "Cache-Control:  must-revalidate, post-check=0, pre-check=0" );
			header ( "Content-disposition: attachment; filename=".$this->lang->line('adlt_trtmnt_hdng').".doc" );
			
			// $query['data'] = $this->arbovirallab_model->listArbovirallabs();
			
			$data = $this->exportView ();
			
			echo $data;
			exit ();
		}
	}
	
	/**
	 * Function to convert data into XML
	 * Format
	 */
	public function toXMLAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->dbutil ();
			
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			$ctime = $this->input->post ( 'current_time' );
			$this->currenttime = ! empty ( $ctime ) ? $ctime : $this->currenttime;
			
			if (! empty ( $startdate ) && ! empty ( $enddate )) {
				$this->startdate = $startdate;
				$this->enddate = $enddate;
			}
			
			$query = $this->adulttreatment_report_model->getXML ( $this->startdate, $this->enddate );
			
			$this->download_send_headers ( $this->lang->line('adlt_trtmnt_hdng').".xml" );
			echo $this->dbutil->xml_from_result ( $query );
		}
	}
	
	/**
	 * Function to return headers
	 */
	public function download_send_headers($filename) {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			header ( "Pragma: public" );
			header ( "Expires: 0" );
			header ( "Cache-Control: must-revalidate, post-check=0, pre-check=0" );
			header ( "Content-Type: application/force-download" );
			header ( "Content-Type: application/octet-stream" );
			header ( "Content-Type: application/download" );
			header ( "Content-Disposition: attachment;filename={$filename}" );
			header ( "Content-Transfer-Encoding: binary" );
		}
	}
	
	/**
	 * Function to convert Array into CSV
	 */
	public function array2csv(array &$array) {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			if (count ( $array ) == 0) {
				return null;
			}
			// print'<pre>';
			// print_r($array);
			// die;
			ob_start ();
			$df = fopen ( "php://output", 'w' );
			fputcsv ( $df, array_keys ( reset ( $array ) ) );
			foreach ( $array as $row ) {
				fputcsv ( $df, $row );
			}
			fclose ( $df );
			return ob_get_clean ();
		}
	}
	
	/**
	 * Function to convert data into CSV
	 */
	public function toCSVAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			$ctime = $this->input->post ( 'current_time' );
			$this->currenttime = ! empty ( $ctime ) ? $ctime : $this->currenttime;
			
			$id = $this->session->userdata ( 'id' );
			$id_arr = explode ( "_", json_decode ( base64_decode ( $id ) ) );
			
			$id = json_decode ( base64_decode ( $id_arr [0] ) );
			
			$this->userinfo = $this->usermodel->getUserData ( $id );
			
			$middlename = " ";
			if (isset ( $this->userinfo ['middlename'] ))
				$middlename = ! empty ( $this->userinfo ['middlename'] ) ? " " . $this->userinfo ['middlename'] . " " : " ";
			
			if (isset ( $this->userinfo ['firstname'] ) || isset ( $this->userinfo ['lastname'] ))
				$this->inspector = $this->userinfo ['firstname'] . $middlename . $this->userinfo ['lastname'];
			
			if (! empty ( $startdate ) && ! empty ( $enddate )) {
				$this->startdate = $startdate;
				$this->enddate = $enddate;
			}
			// echo $this->startdate." ".$this->enddate;
			// die;
			$this->products = $this->adulttreatment_report_model->getProducts ( $this->startdate, $this->enddate );
			// $this->product_list = $this->adulttreatment_report_model->getProducts_I($this->startdate,$this->enddate);
			
			$temp_arr = array ();
			$i = 0;
			
			foreach ( $this->products as $k => $v ) {
				$acres = 0.00;
				$sqft = 0.00;
				$basins = 0.00;
				$miles = 0.00;
				$treatment = 0;
				
				$temp_arr [$i] ['Product'] = $v ['productname'];
				$temp_arr [$i] ['Qty'] = $v ['qty'];
				$temp_arr [$i] ['UOM'] = $v ['uom'];
				
				if ($v ['units'] == "Acres") {
					$temp_arr [$i] ['Acres'] = $v ['area'];
					$temp_arr [$i] ['Sq. Ft'] = 0.00;
					$temp_arr [$i] ['Basins'] = 0.0;
					$temp_arr [$i] ['Miles'] = 0.00;
					$acres += floatval ( $v ['area'] );
				} else if ($v ['units'] == "Sq. Ft.") {
					$temp_arr [$i] ['Acres'] = 0.00;
					$temp_arr [$i] ['Sq. Ft'] = $v ['area'];
					$temp_arr [$i] ['Basins'] = 0.00;
					$temp_arr [$i] ['Miles'] = 0.00;
					$sqft += floatval ( $v ['area'] );
				} else if ($v ['units'] == "Basins") {
					$temp_arr [$i] ['Acres'] = 0.00;
					$temp_arr [$i] ['Sq. Ft'] = 0.00;
					$temp_arr [$i] ['Basins'] = $v ['area'];
					$temp_arr [$i] ['Miles'] = 0.00;
					$basins += floatval ( $v ['area'] );
				} else if ($v ['units'] == "Miles") {
					$temp_arr [$i] ['Acres'] = 0.00;
					$temp_arr [$i] ['Sq. Ft'] = 0.00;
					$temp_arr [$i] ['Basins'] = 0.00;
					$temp_arr [$i] ['Miles'] = $v ['area'];
					$miles += floatval ( $v ['area'] );
				}
				
				$temp_arr [$i] ['# of Trtmts'] = "";
				$i ++;
			}
			
			// print'<pre>';
			// print_r($data_1);
			// die;
			$this->download_send_headers ( $this->lang->line('adlt_trtmnt_hdng').".csv" );
			echo $this->array2csv ( $temp_arr );
		}
	}
	
	/**
	 * Function to convert data into Image
	 */
	public function toIMAGEAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->helper ( 'pdf_helper' );
			$data = $this->exportView ();
			// print'<pre>';
			// print_r($data);
			// die;
			
			return_pdf ( $data, $this->lang->line('adlt_trtmnt_hdng') ); // Create pdf
			
			exec ( "convert AdultTreatmentpdf.pdf ".$this->lang->line('adlt_trtmnt_hdng').".tif" );
			$this->download_send_headers ( $this->lang->line('adlt_trtmnt_hdng').".tif" );
			echo file_get_contents ( $this->lang->line('adlt_trtmnt_hdng').".tif" );
			unlink ( "temp/AdultTreatmentpdf.pdf" );
			unlink ( "temp/".$this->lang->line('adlt_trtmnt_hdng').".tif" );
		}
	}
}

/* End of file adulttreatment_report.php */
/* Location: ./application/controllers/adulttreatment_report.php */