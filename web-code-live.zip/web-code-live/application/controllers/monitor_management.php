<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Monitor_management extends CI_Controller {
	
	/** 
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		
        $this->load->helper('language');
		$this->load->model ( 'monitor_model' );
        
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			redirect ( base_url () . "monitor_management/getmonitor" );
		}
	}
	
	/**
	 * Function to display List Of Monitor management
	 */
	public function getmonitor($grid = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$columns = array (
					0 => array (
							'name' => $this->lang->line('mntr_mgmt_missn_type'),
							'db_name' => 'mission_type',
							'header' => $this->lang->line('prdct_ovrvw_type'),
							'group' => 'monitormgmt',
							'required' => TRUE,
							'unique' => TRUE,
							'form_control' => 'text_long',
							'type' => 'string' 
					),
					1 => array (
							'name' => $this->lang->line('mntr_mgmt_missn_num'),
							'db_name' => 'mission_number',
							'header' => $this->lang->line('mntr_mgmt_missn') ." #",
							'group' => 'monitormgmt',
							'required' => TRUE,
							'form_control' => 'text_short' 
					),
					2 => array (
							'name' => $this->lang->line('mntr_mgmt_trp_num'),
							'db_name' => 'trip_number',
							'header' => $this->lang->line('mntr_mgmt_trp') . ' #',
							'group' => 'monitormgmt',
							'required' => TRUE,
							'form_control' => 'text_short' 
					),
					3 => array (
							'name' => $this->lang->line('mntr_mgmt_oprtr_name'),
							'db_name' => 'operator_name',
							'header' => $this->lang->line('mntr_mgmt_oprtr'),
							'group' => 'monitormgmt',
							'required' => TRUE,
							'form_control' => 'text_long' 
					),
					4 => array (
							'name' => $this->lang->line('lrvl_trtmnt_eqpmntid'),
							'db_name' => 'equipment_id',
							'header' => $this->lang->line('mntr_mgmt_eq_id'),
							'group' => 'monitormgmt',
							'required' => TRUE,
							'unique' => TRUE,
							'form_control' => 'text_long',
							'type' => 'string' 
					),
					5 => array (
							'name' => $this->lang->line('mntr_mgmt_rte'),
							'db_name' => 'route',
							'header' => $this->lang->line('mntr_mgmt_rte'),
							'group' => 'monitormgmt',
							'required' => TRUE,
							'form_control' => 'text_short' 
					),
					6 => array (
							'name' => $this->lang->line('mntr_mgmt_strt_dt'),
							'db_name' => 'applicationstartdate',
							'header' => $this->lang->line('mntr_mgmt_strt_dt'),
							'group' => 'monitormgmt',
							'required' => TRUE,
							'form_control' => 'text_short' 
					),
					7 => array (
							'name' => $this->lang->line('mntr_mgmt_strt_tm'),
							'db_name' => 'start_time',
							'header' => $this->lang->line('mntr_mgmt_strt_tm'),
							'group' => 'monitormgmt',
							'required' => TRUE,
							'form_control' => 'text_short' 
					),
					8 => array (
							'name' => $this->lang->line('mntr_mgmt_end_date'),
							'db_name' => 'applicationenddate',
							'header' => $this->lang->line('mntr_mgmt_end_date'),
							'group' => 'monitormgmt',
							'required' => TRUE,
							'form_control' => 'text_short' 
					),
					9 => array (
							'name' => $this->lang->line('mntr_mgmt_end_time'),
							'db_name' => 'end_time',
							'header' => $this->lang->line('mntr_mgmt_end_time'),
							'group' => 'monitormgmt',
							'required' => TRUE,
							'form_control' => 'text_short' 
					),
					10 => array (
							'name' => $this->lang->line('mntr_mgmt_spry_on_time'),
							'db_name' => 'spray_on_time',
							'header' => $this->lang->line('mntr_mgmt_spry_on_time'),
							'group' => 'monitormgmt',
							'required' => TRUE,
							'unique' => TRUE,
							'form_control' => 'text_long',
							'type' => 'string' 
					),
					11 => array (
							'name' => $this->lang->line('mntr_mgmt_spry_off_time'),
							'db_name' => 'spray_off_time',
							'header' => $this->lang->line('mntr_mgmt_spry_off_time'),
							'group' => 'monitormgmt',
							'required' => TRUE,
							'form_control' => 'text_short' 
					),
					12 => array (
							'name' => $this->lang->line('mntr_mgmt_tm_on'),
							'db_name' => 'time_on',
							'header' => $this->lang->line('mntr_mgmt_tm_on'),
							'group' => 'monitormgmt',
							'required' => TRUE,
							'form_control' => 'text_short' 
					),
					13 => array (
							'name' => $this->lang->line('mntr_mgmt_dist_trvld'),
							'db_name' => 'distance_traveled',
							'header' => $this->lang->line('mntr_mgmt_dist_trvld'),
							'group' => 'monitormgmt',
							'required' => TRUE,
							'form_control' => 'text_short' 
					),
					14 => array (
							'name' => $this->lang->line('mntr_mgmt_dist_spryd'),
							'db_name' => 'distance_sprayed',
							'header' => $this->lang->line('mntr_mgmt_dist_spryd'),
							'group' => 'monitormgmt',
							'required' => TRUE,
							'unique' => TRUE,
							'form_control' => 'text_long',
							'type' => 'string' 
					),
					15 => array (
							'name' => $this->lang->line('mntr_mgmt_acrge_spryd'),
							'db_name' => 'acreage_sprayed',
							'header' => $this->lang->line('mntr_mgmt_acrge_spryd'),
							'group' => 'monitormgmt',
							'required' => TRUE,
							'form_control' => 'text_short' 
					),
					16 => array (
							'name' => $this->lang->line('mntr_mgmt_galns_spryd'),
							'db_name' => 'gallons_sprayed',
							'header' => $this->lang->line('mntr_mgmt_galns_spryd'),
							'group' => 'monitormgmt',
							'required' => TRUE,
							'form_control' => 'text_short' 
					),
					17 => array (
							'name' => 'Avg Spray Speed',
							'db_name' => 'avg_spray_speed',
							'header' => $this->lang->line('mntr_mgmt_avg_spry_spd'),
							'group' => 'monitormgmt',
							'required' => TRUE,
							'form_control' => 'text_short' 
					),
					18 => array (
							'name' => 'Max Speed',
							'db_name' => 'max_speed',
							'header' => 'Max Speed',
							'group' => 'monitormgmt',
							'required' => TRUE,
							'unique' => TRUE,
							'form_control' => 'text_long',
							'type' => 'string' 
					),
					19 => array (
							'name' => 'Max Flow',
							'db_name' => 'max_flow',
							'header' => 'Max Flow',
							'group' => 'monitormgmt',
							'required' => TRUE,
							'form_control' => 'text_short' 
					),
					20 => array (
							'name' => $this->lang->line('mntr_mgmt_guid'),
							'db_name' => 'GUID',
							'header' => $this->lang->line('mntr_mgmt_guid'),
							'group' => 'monitormgmt',
							'required' => TRUE,
							'form_control' => 'text_short' 
					) 
			);
			
			$commands ['delete'] ['toolbar'] = FALSE;
			
			$params = array (
					'id' => 'idmonitor',
					'table' => 'monitormgmt',
					'url' => 'monitor_management/getmonitor',
					'uri_param' => $grid,
					'columns' => $columns,
					'columns_visible' => array (
							0,
							1,
							2,
							3,
							4,
							5,
							6,
							7,
							8,
							9,
							//10,
							//11,
							12,
							13,
							14,
							15,
							16,
							17 
					),
					'filters' => array (
							0 => array (
									'value' => $this->session->userdata ( 'idlocation' ) 
							) 
					),
					'order' => array (
							6 => 'desc' 
					),
					'commands' => $commands,
					'ajax' => TRUE,
					'usermonitor' => $this->getUserMonitor (),
					'msc_url' => array (
							'excel_url' => base_url () . 'monitor_management/toExcelAll',
							'pdf_url' => base_url () . 'monitor_management/toPdfAll' 
					) 
			);
			
			$newdata = array (
					'url' => base_url () . $params ['url'] . '#' . $params ['id'] . '=' . $grid 
			);
			
			$this->session->set_userdata ( $newdata );
			
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidbr_data_entry_montr_mgmt'),
					'guid' => $this->getGUID () ,
					'app_lang' => $this->app_lang
			);
			$this->load->view ( 'header', $data_1 );
			
			$data_1 = array (
					'logstatus' => "logout",
					'page' => "monitor_management" ,
					'app_lang' => $this->app_lang
			);
			
			$this->load->view ( 'left_sidebar', $data_1 );
			// Pass grid to the view
            $data = (object)array();
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			$data->app_lang = $this->app_lang;
			 
			$a=$data->usermonitor;
			// print'<pre>';
			// print_r($a);
			// die;
			// echo $data->total;
			// die;
			$this->load->view ( 'monitor_managements/monitor_management', $data );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to fetch GUID
	 * for loggedin user
	 */
	public function getGuid() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data = $this->monitor_model->getGuid ();
			
			if (! empty ( $data ))
				return $data;
			else
				return '';
		}
	}
	
	/**
	 * Function to fetch monitor not imported by
	 * loggedin user
	 */
	public function getUserMonitor() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data = $this->monitor_model->userMonitor ();
			
			if (! empty ( $data ))
				return $data;
			else
				return false;
		}
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function toExcelAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$query ['data'] = $this->monitor_model->listMonitor ();
			$query ['guid'] = $this->getGUID ();
			$query ['app_lang'] = $this->app_lang;
			$this->load->view ( 'monitor_managements/excel_view', $query );
		}
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->helper ( 'pdf_helper' ); // Load helper
			$query ['data'] = $this->monitor_model->listMonitor ();
			$query ['guid'] = $this->getGUID ();
			$query ['app_lang'] = $this->app_lang;
			
			$data = $this->load->view ( 'monitor_managements/pdf_view', $query, true );
			// print'<pre>';
			// print_r($data);
			// die;
			// $data = file_get_contents("$data"); // Pass the url of html report
			
			create_pdf ( $data, "Monitor_Management" ); // Create pdf
		}
	}
	public function deletemoniter() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$id = $this->input->get ( 'id' );
			
			$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
			if (empty ( $id )) {
				if (! empty ( $seturl [1] ))
					redirect ( $seturl [0] . "?del=error#" . $seturl [1] );
				else
					redirect ( $seturl [0] . "?del=error" );
			} else if (! empty ( $id )) {
				$flg = $this->monitor_model->getMonitorData ( $id );
				
				if (empty ( $flg )) {
					if (! empty ( $seturl [1] ))
						redirect ( $seturl [0] . "?del=error#" . $seturl [1] );
					else
						redirect ( $seturl [0] . "?del=error" );
				}
				// redirect(base_url().'monitor_management/getmonitor?del=error');
			}
			
			$flag = $this->monitor_model->deleteMonitor ();
			
			$msg = "";
			
			if ($flag)
				$msg = "success";
			else
				$msg = "error";
			
			$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
			
			if (! empty ( $seturl [1] ))
				redirect ( $seturl [0] . "?del=" . $msg . "#" . $seturl [1] );
			else
				redirect ( $seturl [0] . "?del=" . $msg );
		}
	}
}

/* End of file monitor_management.php */
/* Location: ./application/controllers/monitor_management.php */