<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Landingrate extends CI_Controller {
	public $idlocation;
	public $site_type = "";
	public $trap_name = "";
	public $inspector = "";
	public $temperature = "";
	public $humidity = "";
	public $windspeed = "";
	public $cloudcover = "";
	public $species = "";
	public $s_species = "";
	public $observed_time = "";
	public $observed_date = "";
	public $sitegroup = "";
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		$this->load->helper('language');
		$this->load->model ( 'landingrate_model' );
		$this->load->model ( 'adultsurveillance_model' );
		$this->load->model ( 'zone_model' );
		$this->load->model ( 'site_model' );
        
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		if ($this->session->userdata ( 'idlocation' ))
			$this->idlocation = $this->session->userdata ( 'idlocation' );
		
		$this->sites = $this->landingrate_model->getSitename ();
		$this->site_type = $this->site_model->getSitetypes ();
		$this->zones = $this->landingrate_model->getSelectedZonename ();
		$this->states = $this->site_model->getStates ();
		$this->state_list = $this->landingrate_model->getStatebyName ();
		$this->sitegroup = $this->site_model->getSiteGroup ();
		
		$this->observed_date = date ( 'm/d/Y' );
		$this->observed_time = date ( 'h:i:s A' );
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			redirect ( base_url () . "landingrate/getlandingrate" );
		}
	}
	
	/**
	 * Function to Show Add Member Form
	 */
	public function showaddlandingrate() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->inspector = $this->landingrate_model->getInspectors ();
			$this->trap_name = $this->landingrate_model->getTrapname ();
			$this->temperature = $this->landingrate_model->getTemprange ();
			$this->humidity = $this->landingrate_model->getHumidityrange ();
			$this->windspeed = $this->landingrate_model->getWindspeed ();
			$this->cloudcover = $this->landingrate_model->getCloudcoverage ();
			$this->species = $this->landingrate_model->getSpecies ( $this->idlocation );
			
            $mapFlag = $this->input->get_post ( 'mapFlag' );
            $mapSite = $this->input->get('idsite');
            $siteData = !empty($mapSite) ? $this->getSiteData($mapSite) : array();
            
			$data = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('lnding_rate_hdng'),
					'page' => "landingrate",
					'trap_name' => $this->trap_name,
					'inspector' => $this->inspector,
					'temprange' => $this->temperature,
					'humidity' => $this->humidity,
					'windspeed' => $this->windspeed,
					'cloudcover' => $this->cloudcover,
					'sitegroup' => $this->sitegroup,
					'species' => $this->species,
					'existing_site' => $this->landingrate_model->getSitename (),
					'site_type' => $this->site_model->getSitetypes (),
					'zone_name' => $this->landingrate_model->getSelectedZonename (),
					'state_name' => $this->site_model->getStates (),
					'state_list' => $this->landingrate_model->getStatebyName (),
					'duration' => $this->landingrate_model->getDuration (),
					'species_name' => $this->landingrate_model->getSpecies ( $this->idlocation ),
					'observed_time' => $this->observed_time,
					'observed_date' => $this->observed_date,
                    'app_lang' => $this->app_lang,
                    'mapFlag' => $mapFlag
			);
            $mapData = $this->getAllEventsData($mapSite);
            $data = array_merge($data, $mapData);
            $data = !empty($siteData) ? array_merge($data, $siteData) : $data;
			
			$this->load->view ( 'landingrates/add_landingrate', $data );
		}
		// $this->load->view('footer');
	}
    
    /**
	 * Function to get Site Data based on idsite clicked by user on Map
	 */
    public function getSiteData($idsite = "") {
        if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
            $return = array();
            if(!empty($idsite)){
                $site_data = $this->site_model->getSiteData ( $idsite );
    			if (! empty ( $site_data )) {
    			 
                    $this->site_id = $this->landingrate_model->getSitename ( $idsite );
        			$this->site_type = $this->site_model->getSitetypes ();
        			$this->state_name = $this->site_model->getStates ();
                    $this->idzone = $this->landingrate_model->getSelectedZonename ( ! empty ( $site_data ['idzone'] ) ? $site_data ['idzone'] : '');
                    
                    $return ['existing_site'] = $this->site_id;
                    $return ['site'] = ! empty ( $site_data ['site'] ) ? $site_data ['site'] : '';
    				$return ['site_type'] = $this->site_type;
                    $return ['idsitetype'] = ! empty ( $site_data ['idsitetype'] ) ? $site_data ['idsitetype'] : '';
    				$return ['zone_name'] = $this->idzone;
                    $return ['maplabel'] = ! empty ( $site_data ['maplabel'] ) ? $site_data ['maplabel'] : '';;
    				$return ['address1'] = ! empty ( $site_data ['address1'] ) ? $site_data ['address1'] : '';
    				$return ['address2'] = ! empty ( $site_data ['address2'] ) ? $site_data ['address2'] : '';
    				$return ['city'] = ! empty ( $site_data ['city'] ) ? $site_data ['city'] : '';
    				$return ['state_name'] = $this->state_name;
                    $return ['idstate'] = ! empty ( $site_data ['idstate'] ) ? $site_data ['idstate'] : '';
    				$return ['postalcode'] = ! empty ( $site_data ['postalcode'] ) ? $site_data ['postalcode'] : '';
    				$return ['latitude'] = (! empty ( $site_data ['latitude'] ) && empty ( $return ['latitude'] )) ? $site_data ['latitude'] : '';
    				$return ['longitude'] = (! empty ( $site_data ['longitude'] ) && empty ( $return ['longitude'] )) ? $site_data ['longitude'] : '';
    			}
            }
            
            return $return;
        }
    }
	
	/**
	 * Function to add a new landingrate
	 */
	public function addlandingrate() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->inspector = $this->landingrate_model->getInspectors ();
			$this->trap_name = $this->landingrate_model->getTrapname ();
			$this->temperature = $this->landingrate_model->getTemprange ();
			$this->humidity = $this->landingrate_model->getHumidityrange ();
			$this->windspeed = $this->landingrate_model->getWindspeed ();
			$this->cloudcover = $this->landingrate_model->getCloudcoverage ();
			$this->species = $this->adultsurveillance_model->getSpecies ( $this->idlocation );
			
			$this->form_validation->set_rules ( 'site', $this->lang->line('whthr_snsr_site_nm'), 'trim' );
			$this->form_validation->set_rules ( 'idsitetype', $this->lang->line('trap_mgmt_site_type'), 'trim' );
			$this->form_validation->set_rules ( 'idzone', 'Zone', 'trim' );
			
			$this->form_validation->set_rules ( 'latitude', $this->lang->line('site_mgmt_lat'), 'trim|required|numeric' );
			$this->form_validation->set_rules ( 'longitude', $this->lang->line('site_mgmt_lng'), 'trim|required|numeric' );
			$this->form_validation->set_rules ( 'inspector_name', $this->lang->line('advrs_impct_inspctr_name'), 'trim|required' );
			
			$this->form_validation->set_rules ( 'observed_date', $this->lang->line('lnding_rte_obsrvd_dt'), 'trim|required' );
			$this->form_validation->set_rules ( 'observed_time', $this->lang->line('lnding_rte_obsrvd_tm'), 'trim|required' );
			$this->form_validation->set_rules ( 'duration', $this->lang->line('data_exprt_drtn_val'), 'trim|required' );
			
			$this->form_validation->set_rules ( 'count_observed', $this->lang->line('lnding_rte_cnt_obsrvd'), 'trim|numeric|required' );
			
			$this->form_validation->set_rules ( 'maplabel', $this->lang->line('site_mgmt_map_lbl'), 'trim' );
			$this->form_validation->set_rules ( 'address1', $this->lang->line('site_mgmt_addrs_1'), 'trim' );
			$this->form_validation->set_rules ( 'address2', $this->lang->line('site_mgmt_addrs_2'), 'trim' );
			$this->form_validation->set_rules ( 'city', $this->lang->line('site_mgmt_cty'), 'trim' );
			$this->form_validation->set_rules ( 'postalcode', $this->lang->line('site_mgmt_postl_cde'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'comment', 'Comment', 'trim' );
			$this->form_validation->set_rules ( 'totalcount', $this->lang->line('lnding_rte_cnt_cllctd'), 'trim|numeric' );
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('lnding_rate_hdng'),
					'page' => "landingrate",
					'trap_name' => $this->trap_name,
					'inspector' => $this->inspector,
					'temprange' => $this->temperature,
					'humidity' => $this->humidity,
					'windspeed' => $this->windspeed,
					'cloudcover' => $this->cloudcover,
					'species' => $this->species,
					'sitegroup' => $this->sitegroup,
					'existing_site' => $this->landingrate_model->getSitename (),
					'site_type' => $this->site_model->getSitetypes (),
					'zone_name' => $this->landingrate_model->getSelectedZonename (),
					'state_name' => $this->site_model->getStates (),
					'state_list' => $this->landingrate_model->getStatebyName (),
					'duration' => $this->landingrate_model->getDuration (),
					'observed_time' => $this->observed_time,
					'observed_date' => $this->observed_date,
                    'app_lang' => $this->app_lang 
			);
			
			if ($this->form_validation->run () == FALSE) {
				$data_1 ['msg'] = "error";
			} else {
				$flag = $this->landingrate_model->addlandingrate ( $this->idlocation );
				
				if (! empty ( $flag ))
					$data_1 ['msg'] = "success";
				else
					$data_1 ['msg'] = "error";
			}
			
			// print'<pre>';
			// print_r($data_1);
			// die;
			$this->load->view ( 'landingrates/add_landingrate', $data_1 );
		}
	}
	
	/**
	 * Function to show edit landing rate
	 */
	public function showeditlandingrate() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get_post ( 'id' );
			
            $mapFlag = $this->input->get_post ( 'mapFlag' );
            $mapSite = $this->input->get_post('idsite');
            
			if (empty ( $req ))
				echo "error";
			
			$flag = $this->landingrate_model->getLandingRate ( $req );
			
			$this->temp_range = $this->landingrate_model->getTemprange ( $flag ['idtemprange'] );
			$this->humidity_name = $this->landingrate_model->getHumidityrange ( $flag ['idhumidityrange'] );
			$this->wind_speed = $this->landingrate_model->getSelectedWindspeed ( $flag ['idwindspeed'] );
			$this->cloud_cover = $this->landingrate_model->getSelectedCloudcoverage ( $flag ['idcloudcoverage'] );
			$this->site_id = $this->landingrate_model->getSitename ( $flag ['idsite'] );
			$this->zone_id = $this->landingrate_model->getzone ( $flag ['idsite'] );
			$this->site_type = $this->site_model->getSitetypes ();
			
			$sitedetails = $this->landingrate_model->getSiteDetails ( $flag ['idsite'] );
			$this->state_name = $this->site_model->getStates ();
            $this->idzone = $this->landingrate_model->getSelectedZonename ( ! empty ( $sitedetails ['idzone'] ) ? $sitedetails ['idzone'] : '');
			$this->duration = $this->landingrate_model->getDuration ( $flag ['idduration'] );
			$this->inspector_name = $this->landingrate_model->getSelectedInspectors ( $flag ['idinspector'] );
			$this->species = $this->landingrate_model->getSpecies ( $this->idlocation );
			$this->selected_species = $this->landingrate_model->getSelectedSpecies ( $flag ['idlandingrate'] );
			$this->species_total = $this->landingrate_model->getSpeciesTotalCount ( $flag ['idlandingrate'] );
			
			if (! empty ( $flag )) {
				$flag ['temp_range'] = $this->temp_range;
				$flag ['humidity_name'] = $this->humidity_name;
				$flag ['wind_speed'] = $this->wind_speed;
				$flag ['cloud_cover'] = $this->cloud_cover;
				$flag ['site_id'] = $this->site_id;
				$flag ['site_type'] = $this->site_type;
				$flag ['idzone'] = $this->idzone;
				$flag ['address1'] = ! empty ( $sitedetails ['address1'] ) ? $sitedetails ['address1'] : '';
				$flag ['address2'] = ! empty ( $sitedetails ['address2'] ) ? $sitedetails ['address2'] : '';
				$flag ['city'] = ! empty ( $sitedetails ['city'] ) ? $sitedetails ['city'] : '';
				$flag ['state_name'] = $this->state_name;
				$flag ['postalcode'] = ! empty ( $sitedetails ['postalcode'] ) ? $sitedetails ['postalcode'] : '';
				$flag ['pdop'] = ! empty ( $sitedetails ['pdop'] ) ? $sitedetails ['pdop'] : '';
				$flag ['sitegroup'] = $this->sitegroup;
				$flag ['duration'] = $this->duration;
				$flag ['inspector_name'] = $this->inspector_name;
				$flag ['species'] = $this->species;
				$flag ['selected_species'] = $this->selected_species;
				$flag ['species_total'] = $this->species_total;
				$flag ['state_list'] = $this->landingrate_model->getStatebyName ();
                $flag ['idstate'] = !empty($sitedetails ['idstate']) ? $sitedetails ['idstate'] : '';
                $flag ['idsitetype'] = !empty($sitedetails ['idsitetype']) ? $sitedetails ['idsitetype'] : '';
                $flag ['app_lang'] = $this->app_lang;
                $mapSite = !empty($flag ['idsite']) ? $flag ['idsite'] : '';
			}
			
            $flag ['mapFlag'] = $mapFlag;
            $mapData = $this->getAllEventsData($mapSite);
            $flag = array_merge($flag, $mapData);
			$this->load->view ( 'landingrates/edit_landingrate', $flag );
		}
	}
	
	/**
	 * Function to save edit Adult Surveillance Values
	 */
	public function editlandingrate() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$id = $this->input->get_post ( 'idlandingrate' );
			if (empty ( $id )) {
				$flag ['msg'] = "error";
				$this->load->view ( 'landingrates/edit_landingrate', $flag );
			}
			
			$flag = $this->landingrate_model->getLandingRate ( $id );
			$this->temp_range = $this->landingrate_model->getTemprange ( $flag ['idtemprange'] );
			$this->humidity_name = $this->landingrate_model->getHumidityrange ( $flag ['idhumidityrange'] );
			$this->wind_speed = $this->landingrate_model->getSelectedWindspeed ( $flag ['idwindspeed'] );
			$this->cloud_cover = $this->landingrate_model->getSelectedCloudcoverage ( $flag ['idcloudcoverage'] );
			$this->site_id = $this->landingrate_model->getSitename ( $flag ['idsite'] );
			$this->idsitetype = $this->site_model->getSitetypes ();
			$this->idzone = $this->landingrate_model->getSelectedZonename ( $flag ['idzone'] );
			$sitedetails = $this->landingrate_model->getSiteDetails ( $flag ['idsite'] );
			$this->state = $this->site_model->getStates ();
			$this->duration = $this->landingrate_model->getDuration ( $flag ['idduration'] );
			$this->inspector_name = $this->landingrate_model->getSelectedInspectors ( $flag ['idinspector'] );
			$this->species = $this->landingrate_model->getSpecies ( $this->idlocation );
			$this->selected_species = $this->landingrate_model->getSelectedSpecies ( $flag ['idlandingrate'] );
			$this->species_total = $this->landingrate_model->getSpeciesTotalCount ( $flag ['idlandingrate'] );
			
			if (! empty ( $flag )) {
				$flag ['temp_range'] = $this->temp_range;
				$flag ['humidity_name'] = $this->humidity_name;
				$flag ['wind_speed'] = $this->wind_speed;
				$flag ['cloud_cover'] = $this->cloud_cover;
				$flag ['site_id'] = $this->site_id;
				$flag ['idsitetype'] = $this->idsitetype;
				$flag ['idzone'] = $this->idzone;
				$flag ['address1'] = ! empty ( $sitedetails ['address1'] ) ? $sitedetails ['address1'] : '';
				$flag ['address2'] = ! empty ( $sitedetails ['address2'] ) ? $sitedetails ['address2'] : '';
				$flag ['sitegroup'] = $this->sitegroup;
				$flag ['city'] = ! empty ( $sitedetails ['city'] ) ? $sitedetails ['city'] : '';
				$flag ['state'] = $this->state;
				$flag ['postalcode'] = ! empty ( $sitedetails ['postalcode'] ) ? $sitedetails ['postalcode'] : '';
				$flag ['latitude'] = ! empty ( $sitedetails ['latitude'] ) ? $sitedetails ['latitude'] : '';
				$flag ['longitude'] = ! empty ( $sitedetails ['longitude'] ) ? $sitedetails ['longitude'] : '';
				$flag ['pdop'] = ! empty ( $sitedetails ['pdop'] ) ? $sitedetails ['pdop'] : '';
				$flag ['duration'] = $this->duration;
				$flag ['inspector_name'] = $this->inspector_name;
				$flag ['species'] = $this->species;
				$flag ['selected_species'] = $this->selected_species;
				$flag ['species_total'] = $this->species_total;
				$flag ['state_list'] = $this->landingrate_model->getStatebyName ();
                $flag ['idstate'] = !empty($sitedetails ['idstate']) ? $sitedetails ['idstate'] : '';
			}
			
			if (! $this->session->userdata ( 'logged_in' )) {
				$flag ['msg'] = "error";
			} else {
				$this->form_validation->set_rules ( 'site', $this->lang->line('whthr_snsr_site_nm'), 'trim' );
				$this->form_validation->set_rules ( 'idsitetype', $this->lang->line('trap_mgmt_site_type'), 'trim' );
				$this->form_validation->set_rules ( 'idzone', 'Zone', 'trim' );
				
				$this->form_validation->set_rules ( 'latitude', $this->lang->line('site_mgmt_lat'), 'trim|numeric|required|numeric' );
				$this->form_validation->set_rules ( 'longitude', $this->lang->line('site_mgmt_lng'), 'trim|numeric|required|numeric' );
				$this->form_validation->set_rules ( 'inspector_name', $this->lang->line('advrs_impct_inspctr_name'), 'trim|required' );
				
				$this->form_validation->set_rules ( 'observed_date', $this->lang->line('lnding_rte_obsrvd_dt'), 'trim|required' );
				$this->form_validation->set_rules ( 'observed_time', $this->lang->line('lnding_rte_obsrvd_tm'), 'trim|required' );
				$this->form_validation->set_rules ( 'duration', $this->lang->line('data_exprt_drtn_val'), 'trim|numeric|required' );
				
				$this->form_validation->set_rules ( 'count_observed', $this->lang->line('lnding_rte_cnt_obsrvd'), 'trim|numeric|required' );
				
				$this->form_validation->set_rules ( 'maplabel', $this->lang->line('site_mgmt_map_lbl'), 'trim' );
				$this->form_validation->set_rules ( 'address1', $this->lang->line('site_mgmt_addrs_1'), 'trim' );
				$this->form_validation->set_rules ( 'address2', $this->lang->line('site_mgmt_addrs_2'), 'trim' );
				$this->form_validation->set_rules ( 'city', $this->lang->line('site_mgmt_cty'), 'trim' );
				$this->form_validation->set_rules ( 'postalcode', $this->lang->line('site_mgmt_postl_cde'), 'trim|numeric' );
				$this->form_validation->set_rules ( 'comment', 'Comment', 'trim' );
				$this->form_validation->set_rules ( 'totalcount', $this->lang->line('lnding_rte_cnt_cllctd'), 'trim|numeric' );
				
				$req = $this->input->get_post ( 'idlandingrate' );
				
				if (empty ( $req ))
					$this->flag ['msg'] = "error";
				
				if ($this->form_validation->run () == FALSE)
					$flag ['msg'] = "error";
				else {
					$flag1 = $this->landingrate_model->updateLandingrate ( $req, $this->idlocation );
					
					if (! empty ( $flag1 ))
						$flag ['msg'] = "updated";
					else
						$flag ['msg'] = "error";
				}
			}
            $flag ['app_lang'] = $this->app_lang;
			$this->load->view ( 'landingrates/edit_landingrate', $flag );
		}
	}
	
	/**
	 * Function to delete landingrate
	 */
	public function deletelandingrate() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->landingrate_model->deleteLandingrate ();
			
			$msg = "";
			
			if ($flag)
				$msg = "success";
			else
				$msg = "error";
			
			$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
			if (! empty ( $seturl [1] ))
				redirect ( $seturl [0] . "?del=" . $msg . "#" . $seturl [1] );
			else
				redirect ( $seturl [0] . "?del=" . $msg );
		}
	}
	
	/**
	 * Function to display List Of adultsurveillances
	 */
	public function getlandingrate($grid = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$filter_date = $this->input->post ( 'filter_date' );
			$msg = $this->input->get ( 'msg' );
			$columns = array (
					0 => array (
							'name' => $this->lang->line('whthr_snsr_site_nm'),
							'db_name' => 'idsite',
							'header' => $this->lang->line('whthr_snsr_site_nm'),
							'group' => 'landingrates',
							'ref_table_id_name' => 'idsite',
							'ref_table_db_name' => 'sites',
							'ref_field_db_name' => 'site',
							'ref_field_type' => 'string',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-n' 
					),
					
					1 => array (
							'name' => $this->lang->line('zone_mgmt_nme'),
							'db_name' => 'idsite',
							'header' => $this->lang->line('zone_mgmt_nme'),
							'group' => 'landingrates',
							'ref_table_id_name' => 'idsite',
							'ref_table_db_name' => 'sites',
							'ref_field_db_name' => 'idzone',
							'ref_table_id2_name' => 'idzone',
							'ref_table_db2_name' => 'zones',
							'ref_field_db2_name' => 'zone',
							'form_control' => 'text_long',
							'type' => '1-1-1'
					),
					2 => array (
							'name' => $this->lang->line('lnding_rte_obsrvd_dt'),
							'db_name_1' => 'observeddate',
							'db_name_2' => 'observedtime',
							'header' => $this->lang->line('lnding_rte_obsrvd_dt'),
							'group' => 'landingrates',
							'type' => '1+2' 
					),
					3 => array (
							'name' => $this->lang->line('lnding_rte_cnt_obsrvd'),
							'db_name' => 'countobserved',
							'header' => $this->lang->line('lnding_rte_cnt_obsrvd'),
							'group' => 'landingrates',
							'form_control' => 'text_long' 
					),
					4 => array (
							'name' => $this->lang->line('lnding_rte_cnt_cllctd'),
							'db_name' => 'countscollected',
							'header' => $this->lang->line('lnding_rte_cnt_cllctd'),
							'group' => 'landingrates',
							'type' => 'string' 
					) 
			);
			$data_1 = array (
					'temp_range' => $this->landingrate_model->getTemprange (),
					'humidity' => $this->landingrate_model->getHumidityrange (),
					'wind_speed' => $this->landingrate_model->getWindspeed (),
					'cloud_cover' => $this->landingrate_model->getCloudcoverage (),
					'existing_site' => addslashes ( $this->landingrate_model->getSitename () ),
					'site_type' => $this->landingrate_model->getSelectedSitetype (),
					'zone_name' => $this->landingrate_model->getSelectedZonename (),
					'state_name' => $this->landingrate_model->getStatename (),
					'state_list' => $this->landingrate_model->getStatebyName (),
					'duration' => $this->landingrate_model->getDuration (),
					'inspector_name' => $this->landingrate_model->getInspectors (),
					'species_name' => $this->landingrate_model->getSpecies ( $this->idlocation ),
					// 'observed_time' => date('h:i A', time()+3600)
					'observed_time' => date_default_timezone_get (),
                    'app_lang' => $this->app_lang 
			);
			
			$commands ['delete'] ['toolbar'] = FALSE;
			$add_view = $this->load->view ( 'landingrates/add_landingrate', $data_1, TRUE );
			
			$data_1 = array (
					'species_name' => $this->landingrate_model->getSpecies ( $this->idlocation ) 
			);
			$count_view = $this->load->view ( 'landingrates/allspecies_view', '', TRUE );
			$data_1 = array (
					'state_list' => $this->landingrate_model->getStatebyName () 
			);
			$edit_view = $this->load->view ( 'landingrates/edit_landingrate', $data_1, TRUE );
			$params = array (
					'id' => 'idlandingrate',
					'table' => 'landingrates',
					'url' => 'landingrate/getlandingrate',
					'uri_param' => $grid,
					'order' => array (
							2 => 'desc' 
					),
					'columns' => $columns,
					'filter_date' => ! empty ( $filter_date ) ? $filter_date : '2',
					'filters' => array (
							0 => array (
									'value' => $this->idlocation 
							) 
					),
					// 'columns_visible' => array(0,1,2),
					'commands' => $commands,
					'ajax' => TRUE,
					'msc_url' => array (
							'excel_url' => base_url () . 'landingrate/toExcelAll',
							'pdf_url' => base_url () . 'landingrate/toPdfAll',
							'text' => $this->lang->line('lnding_rate_lbl') 
					),
					'add_view' => $add_view,
					'count_view' => $count_view,
					'edit_view' => $edit_view 
			);
			$newdata = array (
					'url' => base_url () . $params ['url'] . '#' . $params ['id'] . '=' . $grid 
			);
			
			$this->session->set_userdata ( $newdata );
			
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_data_entry_lnding_rates'),
					'page' => "landingrate",
                    'app_lang' => $this->app_lang
			);
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			
			// Pass grid to the view
            $data = (object)array();
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			$data->msg = $msg;
			$data->mapdata = base_url () . "landingrate/showmap";
			
			$this->load->view ( 'landingrates/landingrates', $data );
		}
		$this->load->view ( 'footer' );
	}
	public function showmap() {
		$query ['data'] = $this->landingrate_model->getMapdata ();
		$query ['user_loc'] = $this->adultsurveillance_model->getUserLoc ();
		$query ['zone_loc'] = $this->zone_model->getZoneCord ();
		$query ['googlezoom'] = $this->session->userdata ( 'googlezoom' );
		// print'<pre>';
		// print_r($query);
		// die;
		$this->load->view ( 'landingrates/map_view', $query );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function getadultsurveillancedata() {
		$id = $this->input->post ( 'idadultsurveillance' );
		
		if (empty ( $id )) {
			echo "error";
			exit ();
		}
		
		$data = $this->adultsurveillance_model->getAdultsurveillanceData ( $id );
		
		echo json_encode ( $data );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function history() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get_post ( 'x_s_' );
			
			if (empty ( $req ))
				redirect ( base_url () . "landingrate/getlandingrate" );
			
			$data1 = $this->adultsurveillance_model->getHistory ( $req );
			
			$id = $data1 [0] ['idadultsurveillance'];
			$total_count = 0;
			$i = 0;
			foreach ( $data1 as $key => $val ) {
				echo $val ['idadultsurveillance'] . " " . $id . "<br>";
				if ($val ['idadultsurveillance'] == $id) {
					$total_count += $val ['count'];
					$data [$i] [] = $val;
				} else {
					$data [$i] ['total'] = $total_count;
					$total_count = 0;
					$i ++;
					$data [$i] [] = $val;
					$id = $val ['idadultsurveillance'];
					$total_count += $val ['count'];
				}
				$data [$i] ['total'] = $total_count;
			}
			// $data2 = $this->adultsurveillance_model->getSpeciesCountbydate($req);
			$data ['app_lang'] = $this->app_lang;
			$this->load->view ( 'adultsurveillances/history_view', $data );
		}
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function collectedSpecies() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get_post ( 'id' );
			
			if (empty ( $req ))
				redirect ( base_url () . "landingrate/getlandingrate" );
			
			$query = $this->landingrate_model->getLandCltSpecies ( $req );
			// print'<pre>';
			// print_r($query);
			// die;
			$str = '';
			foreach ( $query as $key => $val ) {
				$s = ! empty ( $val [0] ) ? $val [0] : '0';
				$c = ! empty ( $val [1] ) ? $val [1] : '0';
				$str .= '<tr><td>(' . lang( 'spcs_' . removeSpecialChars($val [2]) ) . ')' . lang( 'spcs_' . removeSpecialChars($s) ) . '</td><td></td><td>' . $c . '</td></tr>';
			}
			$data = array (
					'data' => $str,
                    'app_lang' => $this->app_lang
			);
			// echo '<pre>';
			// print_r($data);
			// die;
			$this->load->view ( 'landingrates/allspecies_view', $data );
		}
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function toExcelAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$query ['data'] = $this->landingrate_model->listLandingRates ();
			$this->load->view ( 'landingrates/excel_view', $query );
		}
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->helper ( 'pdf_helper' ); // Load helper
			$query ['data'] = $this->landingrate_model->listLandingRates ();
			$data = $this->load->view ( 'landingrates/pdf_view', $query, true );
			create_pdf ( $data, $this->lang->line('lnding_rate_excel_lbl') ); // Create pdf
		}
	}
    
    /**
	 * Function to fetch all site data based on module
	 */
	public function getAllEventsData($idsite = "") {
        $params = array (
            'idsite' => $idsite,
            'idlocation' => $this->session->userdata('idlocation')
        );
        
        $this->load->library ( 'common', $params );
        
        $response = $this->common->getAllEventsData ();
        //print'<pre>';
//        print_r($response);
//        die;
        return $response;
    }
}

/* End of file landingrate.php */
/* Location: ./application/controllers/landingrate.php */