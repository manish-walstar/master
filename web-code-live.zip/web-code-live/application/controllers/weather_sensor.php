<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Weather_sensor extends CI_Controller {
	public $weather_sensor_type = "";
	public $zones = "";
	public $states = "";
	public $state_list = "";
	public $idinspector = "";
	public $site_type;
	public $existing_site = "";
	public $statuses;
	public $idlocation = "";
	public $dateinstalled;
	public $iduomwatersize = "";
	public $sitegroup = "";
	
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		$this->load->helper('language');
		$this->load->model ( 'weather_sensor_model' );
		$this->load->model ( 'larvalsurveillance_model' );
		$this->load->model ( 'site_model' );
		$this->load->model ( 'treatment_model' );
		$this->load->model ( 'adultsurveillance_model' );
		$this->weather_sensor_type = $this->weather_sensor_model->getWeather_sensortypes ();
		$this->zones = $this->site_model->getZones ();
		$this->states = $this->site_model->getStates ();
		$this->state_list = $this->site_model->getStates ();
		$this->idinspector = $this->larvalsurveillance_model->getInspectors ();
		$this->site_type = $this->site_model->getSitetypes ();
		$this->existing_site = $this->site_model->getExisting_site ();
		$this->statuses = $this->weather_sensor_model->getStatuses ();
		$this->dateinstalled = date ( 'm/d/Y' );
		$this->iduomwatersize = $this->treatment_model->getTAreaTreated ();
		$this->sitegroup = $this->site_model->getSiteGroup ();
        
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
		
		if ($this->session->userdata ( 'logged_in' )) {
			$this->idlocation = $this->session->userdata ( 'idlocation' );
		}
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			redirect ( base_url () . "weather_sensor/getweather_sensor" );
		}
	}
	/*
	 * ADD NEW SITE FORM VIEW
	 */
	public function addsiteview() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->site_type = $this->site_model->getSitetypes ();
			$this->zones = $this->site_model->getZones ();
			$this->states = $this->site_model->getStates ();
			$this->state_list = $this->site_model->getStatesList ();
			$this->statuses = $this->site_model->getStatuses ();
			$data = array (
					'site_type' => $this->site_type,
					'zones' => $this->zones,
					'states' => $this->states,
					'state_list' => $this->state_list,
					'sitegroup' => $this->sitegroup,
					'iduomwatersize' => $this->iduomwatersize,
					'googlezoom' => $this->session->userdata ( 'googlezoom' ),
					'user_loc' => $this->adultsurveillance_model->getUserLoc (),
                    'app_lang' => $this->app_lang
			);
			$this->load->view ( 'weather_sensors/add_site', $data );
		}
	}
	
	/**
	 * Function to add a new weather_sensor
	 */
	public function addweather_sensor() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->weather_sensor_type = $this->weather_sensor_model->getWeather_sensortypes ();
			$this->zones = $this->site_model->getZones ();
			$this->states = $this->site_model->getStates ();
			$this->state_list = $this->site_model->getStatesList ();
			$this->idinspector = $this->larvalsurveillance_model->getInspectors ();
			$this->site_type = $this->site_model->getSitetypes ();
			$this->existing_site = $this->site_model->getExisting_site ();
			$this->statuses = $this->weather_sensor_model->getStatuses ();
			$data = array (
					'sensor_type' => $this->weather_sensor_type,
					'idinspector' => $this->idinspector,
					'existing_site' => $this->existing_site,
					'site_type' => $this->site_type,
					'zones' => $this->zones,
					'states' => $this->states,
					'state_list' => $this->state_list,
					'sitegroup' => $this->sitegroup,
                    'app_lang' => $this->app_lang 
			);
			$this->dateinstalled = $this->input->post ( 'dateinstalled' );
			
			if (empty ( $this->dateinstalled ))
				$this->dateinstalled = date ( 'm/d/Y' );
			$data ['dateinstalled'] = $this->dateinstalled;
			
			$this->form_validation->set_rules ( 'sensor_name', $this->lang->line('whthr_snsr_name'), 'trim|required|callback_sensorCheck|xss_clean' );
			$this->form_validation->set_rules ( 'sensor_type', $this->lang->line('whthr_snsr_type'), 'trim|required' );
			$this->form_validation->set_rules ( 'dateinstalled', $this->lang->line('whthr_snsr_dte_instlld'), 'trim|required' );
			$this->form_validation->set_rules ( 'idinspector', $this->lang->line('advrs_impct_inspctr_name'), 'trim|required' );
			$this->form_validation->set_rules ( 'site_name', $this->lang->line('whthr_snsr_site_nm'), 'trim' );
			$this->form_validation->set_rules ( 'site_type', $this->lang->line('trap_mgmt_site_type'), 'trim' );
			$this->form_validation->set_rules ( 'zone', 'Zone', 'trim' );
			
			$this->form_validation->set_rules ( 'avgrainperyear', $this->lang->line('whthr_snsr_avg_rnfll_pr_yr'), 'trim' );
			$this->form_validation->set_rules ( 'street1', $this->lang->line('site_mgmt_street') .' I', 'trim' );
			$this->form_validation->set_rules ( 'street2', $this->lang->line('site_mgmt_street') . ' II', 'trim' );
			$this->form_validation->set_rules ( 'city', $this->lang->line('site_mgmt_cty'), 'trim' );
			$this->form_validation->set_rules ( 'idstate', $this->lang->line('site_mgmt_state'), 'trim' );
			$this->form_validation->set_rules ( 'postal_code', $this->lang->line('site_mgmt_postl_cde'), 'trim' );
			$this->form_validation->set_rules ( 'latitude', $this->lang->line('site_mgmt_lat'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'longitude', $this->lang->line('site_mgmt_lng'), 'trim|numeric' );
			
			if ($this->form_validation->run () == FALSE) {
				$data ['msg'] = "error";
			} else {
				$flag = $this->weather_sensor_model->addWeather_sensor ();
				
				if (! empty ( $flag ))
					$data ['msg'] = "success";
				else
					$data ['msg'] = "error";
			}
			$this->load->view ( 'weather_sensors/add_weather_sensor', $data );
		}
	}
	
	/**
	 * Function to show popup add view
	 */
	public function addweathersensorpop() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->weather_sensor_type = $this->weather_sensor_model->getWeather_sensortypes ();
			$this->zones = $this->site_model->getZones ();
			$this->states = $this->site_model->getStates ();
			$this->state_list = $this->site_model->getStatesList ();
			$this->idinspector = $this->larvalsurveillance_model->getInspectors ();
			$this->site_type = $this->site_model->getSitetypes ();
			$this->existing_site = $this->site_model->getExisting_site ();
			$this->statuses = $this->weather_sensor_model->getStatuses ();
			$data = array (
					'sensor_type' => $this->weather_sensor_type,
					'idinspector' => $this->idinspector,
					'existing_site' => $this->existing_site,
					'site_type' => $this->site_type,
					'zones' => $this->zones,
					'states' => $this->states,
					'state_list' => $this->state_list,
					'sitegroup' => $this->sitegroup,
					'dateinstalled' => $this->dateinstalled,
                    'app_lang' => $this->app_lang 
			);
			
			$this->load->view ( 'weather_sensors/add_weather_sensor', $data );
		}
	}
	/**
	 * Function for pop up edit
	 */
	public function showeditpop() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$data = array ();
			$req = $this->input->get ( 'id' );
			
			if (empty ( $req )) {
				$data ['msg'] = "error";
			}
			
			$flag = $this->weather_sensor_model->getWeather_sensorData ( $req );
			
			$this->weather_sensor_type = $this->weather_sensor_model->getWeather_sensortypes ( $flag ['idsensortype'] );
			
			$this->zones = $this->site_model->getSelectedZones ( $flag ['idzone'] );
			$this->state_list = $this->site_model->getStatesList ();
			$this->idinspector = $this->larvalsurveillance_model->getSelectedInspectors ( $flag ['idinspector'] );
			$this->existing_site = $this->site_model->getExisting_site ( $flag ['idsite'] );
			$this->exc_site = $this->site_model->getSelectedExistingSite ( $flag ['idsite'] );
			
			if ($flag) {
				$data = array (
						'exc_site' => $this->exc_site,
						'weather_sensor_type' => $this->weather_sensor_type,
						'zones' => $this->zones,
						'states' => $this->states,
						'state_list' => $this->state_list,
						'idinspector' => $this->idinspector,
						'site_type' => $this->site_type,
						'existing_site' => $this->existing_site,
						// 'idsitegroup' => $flag['idsitegroup'],
						'sitegroup' => $this->sitegroup,
						'detail' => $flag 
				);
			}
            $data['app_lang'] = $this->app_lang;
			$this->load->view ( 'weather_sensors/edit_weather_sensor', $data );
		}
	}
	
	/**
	 * Function to save edit weather_sensor Values
	 */
	public function updateweather_sensor() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$data = array ();
			$req = $this->input->post ( 'id' );
			
			if (empty ( $req )) {
				$data ['msg'] = "error";
				$this->load->view ( 'weather_sensors/edit_weather_sensor', $data );
				exit ();
			}
			
			$flag = $this->weather_sensor_model->getWeather_sensorData ( $req );
			
			$this->weather_sensor_type = $this->weather_sensor_model->getWeather_sensortypes ( $flag ['idsensortype'] );
			
			$this->zones = $this->site_model->getSelectedZones ( $flag ['idzone'] );
			$this->states = $this->site_model->getSelectedSiteStates ( $flag ['idsite'] );
			$this->state_list = $this->site_model->getStatesList ();
			$this->idinspector = $this->larvalsurveillance_model->getSelectedInspectors ( $flag ['idinspector'] );
			$this->site_type = $this->site_model->getSelected_sitetype ( $flag ['idsitetype'] );
			$this->existing_site = $this->site_model->getExisting_site ( $flag ['idsite'] );
			
			if (! empty ( $flag )) {
				$data = array (
						'weather_sensor_type' => $this->weather_sensor_type,
						'zones' => $this->zones,
						'states' => $this->states,
						'state_list' => $this->state_list,
						'idinspector' => $this->idinspector,
						'site_type' => $this->site_type,
						'existing_site' => $this->existing_site,
						// 'idsitegroup' => $flag['idsitegroup'],
						'sitegroup' => $this->sitegroup,
						'detail' => $flag 
				);
			}
			$data['app_lang'] = $this->app_lang;
			$this->form_validation->set_rules ( 'sensor_name', $this->lang->line('whthr_snsr_name'), 'trim|required' );
			$this->form_validation->set_rules ( 'sensor_type', $this->lang->line('whthr_snsr_type'), 'trim|required' );
			$this->form_validation->set_rules ( 'dateinstalled', $this->lang->line('whthr_snsr_dte_instlld'), 'trim|required' );
			$this->form_validation->set_rules ( 'idinspector', $this->lang->line('advrs_impct_inspctr_name'), 'trim|required' );
			$this->form_validation->set_rules ( 'site_name', $this->lang->line('whthr_snsr_site_nm'), 'trim' );
			$this->form_validation->set_rules ( 'site_type', $this->lang->line('trap_mgmt_site_type'), 'trim' );
			$this->form_validation->set_rules ( 'zone', 'Zone', 'trim' );
			
			$this->form_validation->set_rules ( 'avgrainperyear', $this->lang->line('whthr_snsr_avg_rnfll_pr_yr'), 'trim' );
			
			$this->form_validation->set_rules ( 'city', $this->lang->line('site_mgmt_cty'), 'trim' );
			$this->form_validation->set_rules ( 'idstate', $this->lang->line('site_mgmt_state'), 'trim' );
			$this->form_validation->set_rules ( 'postalcode', $this->lang->line('site_mgmt_postl_cde'), 'trim' );
			$this->form_validation->set_rules ( 'latitude', $this->lang->line('site_mgmt_lat'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'longitude', $this->lang->line('site_mgmt_lng'), 'trim|numeric' );
			$this->form_validation->set_rules ( 'pdop', 'PDOP', 'trim' );
			
			if ($this->form_validation->run () == FALSE) {
				$data ['msg'] = "error";
			} else {
				$flag = $this->weather_sensor_model->addWeather_sensor ();
				
				if (! empty ( $flag ))
					$data ['msg'] = "update";
				else
					$data ['msg'] = "error";
			}
			
			$this->load->view ( 'weather_sensors/edit_weather_sensor', $data );
		}
	}
	
	/**
	 * Function to check weather sensor name existence
	 */
	public function sensorCheck($str = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$str = $this->input->post ( 'sensor_name' );
			
			$flag = $this->weather_sensor_model->sensorExist ( $str );
			
			if ($flag) {
				$this->form_validation->set_message ( 'sensorCheck', $this->lang->line('err_msg_wthr_snsr_alrdy_exsts') );
				return false;
			} else {
				return true;
			}
		}
	}
	
	/**
	 * Function to show map
	 */
	public function showmap() {
		$this->load->view ( 'weather_sensors/map' );
	}
	
	/**
	 * Function to get lati longi data
	 * with the help of curl
	 * from GOOGLE API URL
	 */
	public function getData($address = '') {
		if (empty ( $address ))
			return null;
		
		$url = "https://maps.googleapis.com/maps/api/geocode/json?address=$address";
		$ch = curl_init ();
		curl_setopt ( $ch, CURLOPT_URL, $url );
		curl_setopt ( $ch, CURLOPT_RETURNTRANSFER, 1 );
		curl_setopt ( $ch, CURLOPT_PROXYPORT, 3128 );
		curl_setopt ( $ch, CURLOPT_SSL_VERIFYHOST, 0 );
		curl_setopt ( $ch, CURLOPT_SSL_VERIFYPEER, 0 );
		$response = curl_exec ( $ch );
		curl_close ( $ch );
		$result = json_decode ( $response );
		
		return $result;
	}
	
	/**
	 * Function to get lati longi of map
	 */
	public function getmap() {
		$street = $this->input->post ( 'street_addr' );
		$street1 = $this->input->post ( 'street_addr1' );
		$city = $this->input->post ( 'city' );
		$state = $this->input->post ( 'state' );
		$postal_code = $this->input->post ( 'postal_code' );
		
		if ($state)
			$address = urlencode ( $street ) . "+" . urlencode ( $street1 ) . "+" . urlencode ( $city ) . "+" . urlencode ( $state ) . "+" . urlencode ( $postal_code );
		else
			$address = urlencode ( $street ) . "+" . urlencode ( $street1 ) . "+" . urlencode ( $city ) . "+" . urlencode ( $postal_code );
			// file_get_contents($url);
			
		// $curlData = file_get_contents($url);
			
		// $address = json_decode($curlData);
		
		$i = 0;
		while ( $i < 5 ) {
			$response = $this->getData ( $address );
			
			if (! empty ( $response->results )) {
				$lati = $response->results [0]->geometry->location->lat;
				$longi = $response->results [0]->geometry->location->lng;
				
				$data = array (
						'lati' => $lati,
						'longi' => $longi 
				);
				
				echo json_encode ( $data );
				exit ();
			}
			
			if ($i == 0) {
				$pattern = '/' . $street . "\+" . '/';
				$address = preg_replace ( $pattern, '', $address );
			} else if ($i == 1) {
				$pattern = '/' . $street1 . "\+" . '/';
				$address = preg_replace ( $pattern, '', $address );
			} else if ($i == 2) {
				$pattern = '/' . $city . "\+" . '/';
				$address = preg_replace ( $pattern, '', $address );
			} else if ($i == 3) {
				if ($state)
					$pattern = '/' . $state . "\+" . '/';
				else
					$pattern = '/' . $state . "\+" . '/';
				
				$address = preg_replace ( $pattern, '', $address );
			} else {
				echo json_encode ( $this->lang->line('trtmnt_no_data_avlbl') );
				exit ();
			}
			
			$i ++;
		}
	}
	
	/**
	 * Function to delete weather_sensor
	 */
	public function deleteweather_sensor() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->weather_sensor_model->deleteweather_sensor ();
			
			$msg = "";
			
			if ($flag)
				$msg = "success";
			else
				$msg = "error";
			
			$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
			if (! empty ( $seturl [1] ))
				redirect ( $seturl [0] . "?del=" . $msg . "#" . $seturl [1] );
			else
				redirect ( $seturl [0] . "?del=" . $msg );
			// redirect(base_url().'weather_sensor/getweather_sensor?del='.$msg);
		}
	}
	
	/**
	 * Function to activate weather_sensor
	 */
	public function activeweather_sensor() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->weather_sensor_model->activeweather_sensor ();
			
			$msg = "";
			
			if ($flag)
				$msg = "activated";
			else
				$msg = "error";
			
			redirect ( base_url () . "weather_sensor/getweather_sensor?msg=" . $msg );
		}
	}
	
	/**
	 * Function to deactivate weather_sensor
	 */
	public function deactiveweather_sensor() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->weather_sensor_model->deactiveweather_sensor ();
			
			$msg = "";
			
			if ($flag)
				$msg = "deactivated";
			else
				$msg = "error";
			
			redirect ( base_url () . "weather_sensor/getweather_sensor?msg=" . $msg );
		}
	}
	
	/**
	 * Function to display List Of weather_sensors
	 */
	public function getweather_sensor($grid = '', $msg = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$columns = array (
					0 => array (
							'name' => $this->lang->line('prdct_ovrvw_nme'),
							'db_name' => 'weathersensor',
							'header' => $this->lang->line('whthr_snsr_name'),
							'group' => 'Weather_sensor',
							'required' => TRUE,
							'unique' => TRUE,
							'form_control' => 'text_long',
							'type' => 'string' 
					),
					1 => array (
							'name' => $this->lang->line('whthr_snsr_type'),
							'db_name' => 'idsensortype',
							'header' => $this->lang->line('whthr_snsr_type'),
							'group' => 'Weather_sensor',
							'required' => TRUE,
							'ref_table_id_name' => 'idweathersensortype',
							'ref_table_db_name' => 'weathersensortypes',
							'ref_field_db_name' => 'weathersensortype',
							'form_control' => 'text_long',
							'type' => '1-n' 
					),
					2 => array (
							'name' => $this->lang->line('whthr_snsr_site_nm'),
							'db_name' => 'idsite',
							'header' => $this->lang->line('whthr_snsr_site_nm'),
							'group' => 'Weather_sensor',
							'required' => TRUE,
							'unique' => TRUE,
							'form_control' => 'text_long',
							'ref_table_id_name' => 'idsite',
							'ref_table_db_name' => 'sites',
							'ref_field_db_name' => 'site',
							'form_control' => 'text_long',
							'type' => '1-n'
 					),
					3 => array (
							'name' => $this->lang->line('site_mgmt_zone'),
							'db_name' => 'idzone',
							'header' => $this->lang->line('site_mgmt_zone'),
							'group' => 'Weather_sensor',
							'ref_table_id_name' => 'idsite',
							'ref_table_db_name' => 'sites',
							'ref_field_db_name' => 'idzone',
                            'ref_table_id2_name' => 'idzone',
							'ref_table_db2_name' => 'zones',
							'ref_field_db2_name' => 'zone',
							'form_control' => 'text_long',
							'type' => '1-1-1'
					),
					4 => array (
							'name' => $this->lang->line('whthr_snsr_dte_instlld'),
							'db_name' => 'dateinstalled',
							'header' => $this->lang->line('whthr_snsr_dte_instlld'),
							'group' => 'Weather_sensor',
							'form_control' => 'text_long',
							'allow_filter' => TRUE 
					),
					5 => array (
							'name' => $this->lang->line('whthr_snsr_avg_1_yr_rnfll'),
							'db_name' => 'avgrainperyear',
							'header' => $this->lang->line('whthr_snsr_avg_1yr_rnfll'),
							'group' => 'Weather_sensor',
							'form_control' => 'dropdown',
							'allow_filter' => TRUE 
					),
					6 => array (
							'name' => $this->lang->line('mmbr_mgmt_is_actv'),
							'db_name' => 'active',
							'header' => $this->lang->line('mmbr_mgmt_is_actv'),
							'group' => 'Weather_sensor',
							'form_control' => 'checkbox' 
					)					 
			);
			
			$commands ['delete'] ['toolbar'] = FALSE;
			
			$data_1 = array (
					'zones' => $this->zones,
					'sensor_type' => $this->weather_sensor_type,
					'states' => $this->states,
					'state_list' => $this->state_list,
					'idinspector' => $this->idinspector,
					'site_type' => $this->site_type,
					'existing_site' => $this->existing_site,
                    'app_lang' => $this->app_lang 
			);
			
			// print'<pre>';
			// print_r($data_1);
			// die;
			$add_view = $this->load->view ( 'weather_sensors/add_weather_sensor', $data_1, TRUE );
			
			$edit_view = $this->load->view ( 'weather_sensors/edit_weather_sensor', '', TRUE );
			
			$params = array (
					'id' => 'idweathersensor',
					'table' => 'weathersensors',
					'url' => 'weather_sensor/getweather_sensor',
					'uri_param' => $grid,
					'columns' => $columns,
					'order' => array (
							0 => 'asc' 
					),
					// 'columns_visible' => array(0,1,2),
					'filters' => array (
							0 => array (
									'value' => $this->idlocation 
							) 
					),
					'commands' => $commands,
					'ajax' => TRUE,
					'msc_url' => array (
							'excel_url' => base_url () . 'weather_sensor/toExcelAll',
							'pdf_url' => base_url () . 'weather_sensor/toPdfAll',
							'text' => 'Weather_sensor' 
					),
					'add_view' => $add_view,
					'edit_view' => $edit_view 
			)
			;
			
			$newdata = array (
					'url' => base_url () . $params ['url'] . '#' . $params ['id'] . '=' . $grid 
			);
			
			$this->session->set_userdata ( $newdata );
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'page' => "weather_sensor",
					'title' => $this->lang->line('wthr_snsrs_hdng'),
                    'app_lang' => $this->app_lang 
			);
			$this->load->view ( 'header', $data_1 );
			
			$this->load->view ( 'left_sidebar', $data_1 );
			// Pass grid to the view
            $data = (object)array();
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			$data->msg = $msg;
			$data->statuses = $this->statuses;
			
			$this->load->view ( 'weather_sensors/weather_sensors', $data );
		}
		$this->load->view ( 'footer' );
	}
	public function weather_sensors_json($idlocation = false) {
		$ws_array = $this->weather_sensor_model->listWeather_sensors ( $idlocation );
		
		$w_arr = array ();
		
		if (! $ws_array)
			$ws_array = array ();
		
		foreach ( $ws_array as $wsens ) {
			$w_arr = array (
					'post' => $wsens 
			);
		}
		
		$ws = array (
				'posts' => $w_arr,
				'total_records' => count ( $w_arr ) 
		);
		
		echo json_encode ( $ws );
	}
	public function create_weather_sensor_json() {
		echo __FUNCTION__ . ' not yet implemented';
	}
	public function update_weather_sensor_json() {
		echo __FUNCTION__ . ' not yet implemented';
	}
	public function delete_weather_sensor_json() {
		echo __FUNCTION__ . ' not yet implemented';
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function toExcelAll() {
		$query ['data'] = $this->weather_sensor_model->listWeather_sensors ();
		
		$this->load->view ( 'weather_sensors/excel_view', $query );
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
		$this->load->helper ( 'pdf_helper' ); // Load helper
		$query ['data'] = $this->weather_sensor_model->listWeather_sensors ();
		
		$data = $this->load->view ( 'weather_sensors/pdf_view', $query, true );
		// $data = file_get_contents(htmlentities($dd)); // Pass the url of html report
		
		create_pdf ( $data, "Weather_sensors" ); // Create pdf
	}
}

/* End of file weather_sensor.php */
/* Location: ./application/controllers/weather_sensor.php */
