<?php
ini_set('error_reporting', E_ALL);
ini_set('display_errors',1);
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Dataexport_report extends CI_Controller {
	public $products;
	public $arboviral;
	public $startdate;
	public $starttime;
	public $enddate;
	public $endtime;
	public $currentdate;
	public $currenttime;
	public $endtimestamp;
	public $starttimestamp;
	public $userinfo;
	public $datatype;
	public $options;
	public $sub;
	
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		$this->load->helper('language');
		$this->load->model ( 'dataexport_report_model' );
		$this->load->model ( 'usermodel' );
		
		$this->currentdate = date ( 'm/d/Y' );
		$this->currenttime = date ( "H:i:s a" );
		
		$this->enddate = date ( 'm/d/Y' );
		$this->endtime = date ( 'H:i:s' );
		
		$this->startdate = date ( 'm/d/Y', strtotime ( "-30 day" ) );
		$this->starttime = date ( 'H:i:s' );
		
		$this->endtimestamp = strtotime ( date ( 'm/d/Y H:i:s' ) );
		
		$this->starttimestamp = strtotime ( date ( 'm/d/Y H:i:s', strtotime ( "-30 day" ) ) );
		
		if ($this->session->userdata ( 'id' )) {
			$id = $this->session->userdata ( 'id' );
			$id_arr = explode ( "_", json_decode ( base64_decode ( $id ) ) );
			
			$id = json_decode ( base64_decode ( $id_arr [0] ) );
			
			$this->userinfo = $this->usermodel->getUserData ( $id );
			
			$middlename = " ";
			if (isset ( $this->userinfo ['middlename'] ))
				$middlename = ! empty ( $this->userinfo ['middlename'] ) ? " " . $this->userinfo ['middlename'] . " " : " ";
			
			if (isset ( $this->userinfo ['firstname'] ) || isset ( $this->userinfo ['lastname'] ))
				$this->inspector = $this->userinfo ['firstname'] . $middlename . $this->userinfo ['lastname'];
			
			// $this->products = $this->dataexport_report_model->getDataexport($this->startdate,$this->enddate,'');
			
			// die;
			
			// print('<pre>');
			// print_r($this->products);
			// die;
		}
		$this->load->model ( 'usermodel' );
		$this->usermodel->set_access_session ();
        
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
                        
		if ($this->usermodel->user_access ( 'reports' ) || $this->usermodel->user_access ( 'company_admin' )) {
		} else {
			redirect ( base_url () );
		}
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			redirect ( base_url () . "dataexport_report/getdataexport" );
		}
	}
	
	/**
	 * Function to fetch All products
	 */
	public function getdataexport() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			$this->datatype = $this->input->post ( 'datatype' );
			$this->options = $this->input->post ( 'option' );
			$this->sub = $this->input->post ( 'sub' );
			$act = $this->input->post ( 'action_name' );
			
			$this->action = ! empty ( $act ) ? explode ( ',', $act ) : '';
			
			// print'<pre>';
			// print_r($this->input->post());
			// die;
			
			$data_1 = array ();
			
			if (! empty ( $startdate ) && ! empty ( $enddate )) {
				$this->startdate = $startdate;
				$this->enddate = $enddate;
			}
			
			$middlename = " ";
			if (isset ( $this->userinfo ['middlename'] ))
				$middlename = ! empty ( $this->userinfo ['middlename'] ) ? " " . $this->userinfo ['middlename'] . " " : " ";
			
			if (isset ( $this->userinfo ['firstname'] ) || isset ( $this->userinfo ['lastname'] ))
				$this->inspector = $this->userinfo ['firstname'] . $middlename . $this->userinfo ['lastname'];
			
			$this->products = $this->dataexport_report_model->getDataexport ( $startdate, $enddate, $this->datatype, $this->options, $this->sub, $act );
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_rprtng_data_exprt'),
					'page' => "dataexport_report",
					'startdate' => $this->startdate,
					'starttime' => date ( 'h:i:s A', strtotime ( $this->starttime ) ),
					'endtime' => date ( 'h:i:s A', strtotime ( $this->endtime ) ),
					'enddate' => $this->enddate,
					'inspector' => $this->inspector,
					'currentdate' => $this->currentdate,
					'currenttime' => date ( "h:i:s A", strtotime ( $this->currenttime ) ),
					'products' => $this->products,
					'tab' => $this->datatype,
					'options' => $this->options,
					'sub' => $this->sub,
					'action' => $this->action,
                    'app_lang' => $this->app_lang 
			);
			
			$this->load->view ( 'header', $data_1 );
			
			$this->load->view ( 'left_sidebar', $data_1 );
			
			$this->load->view ( 'dataexport_reports/dataexport_reports', $data_1 );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to fetch the data
	 * and format it in order to return
	 */
	public function exportView($startdate, $enddate, $datatype, $options, $sub, $action) {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$middlename = ! empty ( $this->userinfo ['middlename'] ) ? " " . $this->userinfo ['middlename'] . " " : " ";
			$this->inspector = $this->userinfo ['firstname'] . $middlename . $this->userinfo ['lastname'];
			// echo $this->startdate;
			// echo $this->enddate;
			
			$this->products = $this->dataexport_report_model->getDataexport ( $startdate, $enddate, $datatype, $options, $sub, $action);
			// print_r($this->products); exit;
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_rprtng_data_exprt'),
					'page' => "dataexport_report",
					'startdate' => $this->startdate,
					'starttime' => date ( 'h:i:s A', strtotime ( $this->starttime ) ),
					'endtime' => date ( 'h:i:s A', strtotime ( $this->endtime ) ),
					'enddate' => $this->enddate,
					'inspector' => $this->inspector,
					'currentdate' => $this->currentdate,
					'currenttime' => date ( "h:i:s A", strtotime ( $this->currenttime ) ),
					'products' => $this->products,
					'tab' => $datatype,
					'options' => $options,
					'sub' => $sub,
                    'app_lang' => $this->app_lang
			);
			
			// print('<pre>');
			// print_r($data_1);
			// die;
			$data = $this->load->view ( 'dataexport_reports/pdf_view', $data_1, TRUE );
			// print'<pre>';
			// print_r($data);
			// die;
			//
			return $data;
		}
	}
	
	/**
	 * Function to convert data into Excel
	 */
	public function toEXCELAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->startdate = $this->input->post ( 'startdate' );
			$this->enddate = $this->input->post ( 'enddate' );
			$this->datatype = $this->input->post ( 'datatype' );
			$this->options = $this->input->post ( 'options' );
			$act = $this->input->post ( 'sub' );
            $this->action = ! empty ( $act ) ? explode ( ',', $act ) : '';
            
			$data = $this->exportView ( $this->startdate, $this->enddate, $this->datatype, $this->options, $act, $this->action );
			// print'<pre>';
			// print_r($data);
			// die;
			//
			header ( "Content-type: application/octet-stream" );
			header ( "Content-Disposition: attachment; filename=" . str_replace(' ', '', $this->lang->line('sidebar_rprtng_data_exprt')) . ".xls" );
			header ( "Pragma: no-cache" );
			header ( "Expires: 0" );
			
			echo $data;
			exit ();
		}
	}
}

/* End of file dataexport_report.php */
/* Location: ./application/controllers/dataexport_report.php */