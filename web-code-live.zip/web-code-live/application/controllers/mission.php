<?php
if (! defined ( 'BASEPATH' ))
    exit ( 'No direct script access allowed' );
    date_default_timezone_set ( 'UTC' );
    class Mission extends CI_Controller {
        
        /**
         * Index Page for this controller.
         *
         * Maps to the following URL
         * http://example.com/user
         * - or -
         * http://example.com/user/index
         * - or -
         * Since this controller is set as the default controller in
         * config/routes.php, it's displayed at http://example.com/
         *
         * So any other public methods not prefixed with an underscore will
         * map to /index.php/welcome/<method_name>
         *
         * @see http://codeigniter.com/user_guide/general/urls.html
         */
        public function __construct() {
            parent::__construct ();
            $this->load->model ( 'usermodel' );
            $this->load->library ( 'form_validation' );
            $this->load->helper('language');
            $this->load->model ( 'skytrackermission_model' );
            
            
            $this->app_lang = $this->session->userdata('app_lang');
            $this->lang->load("app",$this->app_lang);
            
            $this->errorMsg = json_encode ( array ('response' => 'fail') );
            $this->load->helper('language');
            
            $this->app_lang = $this->session->userdata('app_lang');
            $this->lang->load("app",$this->app_lang);
            
            if ($this->session->userdata ( 'idlocation' ))
                $this->idlocation = $this->session->userdata ( 'idlocation' );
                
                $this->usermodel->set_access_session ();
        }
        
        public function index() {
            if (! $this->session->userdata ( 'logged_in' )) {
                redirect ( base_url () );
            } else {
                redirect ( base_url () . "mission/getmissiontracker" );
            }
        }
        
        /**
         * Function to display Mission Tracker
         */
        public function getmissiontracker($grid = '') {
            if (! $this->session->userdata ( 'logged_in' )) {
                redirect ( base_url () );
            } else {
                
                $filter_date = $this->input->post ( 'filter_date' );
                
                $msg = $this->input->get ( 'msg' );
                
                $columns = array (
                    0 => array (
                        'name' => $this->lang->line('mission_id'),
                        'db_name' => 'idmissiontracker',
                        'header' => $this->lang->line('mission_id'),
                        'group' => 'Mission',
                        'required' => TRUE,
                        'unique' => TRUE,
                        'form_control' => 'text_long',
                        'type' => 'string'
                    ),
                    1 => array (
                        'name' => $this->lang->line('mmbr_mgmt_pilot'),
                        'db_name' => 'idmissiontracker',
                        'header' => $this->lang->line('mmbr_mgmt_pilot'),
                        'group' => 'Mission',
                        'ref_table_id_name' => 'idmission',
                        'ref_table_db_name' => 'missionpilot',
                        'ref_field_db_name' => 'name',
                        'ref_field_type' => 'string',
                        'form_control' => 'text_long',
                        'required' => TRUE,
                        'type' => '1-1+2+3-mission'
                    ),
                    2 => array (
                        'name' => $this->lang->line('mission_start_date'),
                        'db_name' => 'startdate',
                        'header' => $this->lang->line('mission_start_date'),
                        'group' => 'Mission',
                        'form_control' => 'text_long',
                        'type' => 'string'
                    ),
                    3 => array (
                        'name' => $this->lang->line('mission_treatment_start'),
                        'db_name' => 'treatmentStartDate',
                        'header' => $this->lang->line('mission_treatment_start'),
                        'group' => 'Mission',
                        'form_control' => 'text_long',
                        'type' => 'string'
                    ),
                    4 => array (
                        'name' => $this->lang->line('mission_chemical_name'),
                        'db_name' => 'idmissiontracker',
                        'header' => $this->lang->line('mission_chemical_name'),
                        'group' => 'Mission',
                        'ref_table_id_name' => 'idmission',
                        'ref_table_db_name' => 'missionchemical',
                        'ref_field_db_name' => 'chemicalname',
                        'required' => TRUE,
                        'form_control' => 'text_long',
                        'type' => 'string',
                        'type' => '1-1+2+3-mission'
                    )
                )
                ;
                
                $commands ['delete'] ['toolbar'] = FALSE;
                
                $params = array (
                    'id' => 'idmissiontracker',
                    'table' => 'missionskytracker',
                    'url' => 'mission/getmissiontracker',
                    'uri_param' => $grid,
                    'columns' => $columns,
                    'order' => array (
                        0 => 'desc'
                    ),
                    'columns_visible' => array (
                        0,
                        1,
                        2,
                        3,
                        4
                        
                    ),
                    'commands' => $commands,
                    'ajax' => TRUE
                );
                
                $newdata = array ();
                if (! empty ( $grid )) {
                    $newdata = array (
                        'url' => base_url () . $params ['url'] . '#' . $params ['id'] . '=' . $grid
                    );
                } else {
                    $newdata = array (
                        'url' => base_url () . $params ['url']
                    );
                }
                
                $this->session->set_userdata ( $newdata );
                
                $this->load->library ( 'carbogrid', $params );
                
                if ($this->carbogrid->is_ajax) {
                    $this->carbogrid->render ();
                    return FALSE;
                }
                
                $data_1 = array (
                    'username' => $this->session->userdata ( 'username' ),
                    'logstatus' => "logout",
                    'title' => $this->lang->line('mission_tracker'),
                    'page' => "mission"
                );
                $this->load->view ( 'header', $data_1 );
                $this->load->view ( 'left_sidebar', $data_1 );
                // Pass grid to the view
                $data->page = 'grid_single';
                $data->page_grid = $this->carbogrid->render ();
                $data->msg = $msg;
                $this->load->view ( 'mission/mission', $data );
                
            }
            $this->load->view ( 'footer' );
        }
        
        /**
         * Function to parse mission tracker data
         *
         */
        public function parsemissiontracker() {
            $useragent = $this->input->get('useragent');
            if(isset($useragent) && $useragent == 'GHBn876MK36'){
                $this->load->library ( 'excel' );
                $retVal = array ();
                $this->load->helper('misc_helper');
                $path = '';
                
                $dirMissions = 'mmshell/ftp';
                $skyTrackerMission = scandir($dirMissions);
                
                $index = 0;
                foreach($skyTrackerMission as $missions)
                {
                    try{
                        if($missions != "." && $missions != ".." && $missions != basename(__FILE__))
                        {
                            log_message('debug','Skysoft Debugging -------------->>>>> $missions : '.print_r($missions,1));
                            $missionbasepath = $dirMissions.'/'.$missions;

                            $stringData = file_get_contents($missionbasepath."/Mission.json");
                            $jsonData = json_decode($stringData, true);

                            $flight_array = $this->readExcel ( $missionbasepath .'/FlightDataLog.csv' );
                            if(isset($flight_array['values'])){
                                log_message('debug','Skysoft Debugging -------------->>>>> Filghtdatalog.csv file read : ');
                                $mission_id = $this->skytrackermission_model->addSkyTrackerMission($flight_array,$jsonData);
                                
                                $dir    = $missionbasepath.'/SprayBlockGroups';
                                $sprayBlocks = scandir($dir);
                                //log_message('debug','Skysoft Debugging -------------->>>>> $files1'.print_r($sprayBlocks,1));
                                foreach($sprayBlocks as $sprayDirs)
                                {
                                    if($sprayDirs != "." && $sprayDirs != ".." && $sprayDirs != basename(__FILE__))
                                    {
                                        log_message('debug','Skysoft Debugging -------------->>>>> $sprayDirs'.print_r($sprayDirs,1));
                                        $stringSprayBlockGroup = file_get_contents($missionbasepath."/SprayBlockGroups/".$sprayDirs."/SprayBlockGroup.json");
                                        $jsonSprayBlockGroup = json_decode($stringSprayBlockGroup, true);
                                        $mission_spray_block_id = $this->skytrackermission_model->addMissionSprayBlockGroup($jsonSprayBlockGroup, $mission_id);
                                        
                                        $sprayGroupBlocks = scandir($dir."/".$sprayDirs);
                                        foreach($sprayGroupBlocks as $sprayGroupDirs)
                                        {
                                            if($sprayGroupDirs != "." && $sprayGroupDirs != ".." && $sprayGroupDirs != basename(__FILE__) && $sprayGroupDirs != "SprayBlockGroup.json")
                                            {
                                                log_message('debug','Skysoft Debugging -------------->>>>> $sprayDirs : '.print_r($sprayGroupDirs,1));
                                                $path = $missionbasepath."/SprayBlockGroups/".$sprayDirs. "/".$sprayGroupDirs."/";
                                                $temp_files = scandir($path);
                                                natsort($temp_files);
                                                $block_groups = array();
                                                foreach($temp_files as $file)
                                                {
                                                    if($file != "." && $file != ".." && $file != basename(__FILE__))
                                                    {
                                                        $info = pathinfo($file);
                                                        $file_name =  basename($info['basename']);
                                                        $stringSprayBlock = file_get_contents($path.$file_name);
                                                        $spray_block_array = json_decode($stringSprayBlock, true);
                                                        
                                                        $block = array();
                                                        $block['idsprayblockgroup'] = $mission_spray_block_id;
                                                        $block['type'] = $spray_block_array['type'];
                                                        $block['geometry'] = json_encode($spray_block_array['geometry']);
                                                        $block['properties'] = json_encode($spray_block_array['properties']);
                                                        
                                                        array_push($block_groups, $block);
                                                        
                                                    }
                                                }
                                                $this->skytrackermission_model->addMissionSprayBlock($block_groups, $flight_array);
                                            }
                                        }
                                    }
                                }
                                
                                $stringChemical = file_get_contents($missionbasepath."/Chemical.json");
                                $jsonChemical = json_decode($stringChemical, true);
                                $this->skytrackermission_model->addMissionChemical($jsonChemical, $mission_id);
                                
                                $stringAircraft = file_get_contents($missionbasepath."/Aircraft.json");
                                $jsonAircraft = json_decode($stringAircraft, true);
                                $this->skytrackermission_model->addMissionAircraft($jsonAircraft, $mission_id);
                                
                                $stringPilot = file_get_contents($missionbasepath."/Pilot.json");
                                $jsonPilot = json_decode($stringPilot, true);
                                $this->skytrackermission_model->addMissionPilot($jsonPilot, $mission_id);
                                
                                $retVal["".$index.""] = $missions;
                                $index = $index + 1;
                            }
                            else{
                                log_message('debug','Skysoft Debugging -------------->>>>> $missions could not read flight data log csv file: '.print_r($flight_array,1));
                            }
                        }
                    }catch(Exception $e){
                        log_message('debug','Skysoft Debugging -------------->>>>> $missions : '.print_r($missions,1));
                    }
                }
                
                $retVal["total"] = "".$index."";
                $retVal['success'] = 'true';
                echo json_encode( $retVal);
            }
        }
        
        function recursiveDelete($dirPath, $deleteParent = true){
            foreach(new RecursiveIteratorIterator(new RecursiveDirectoryIterator($dirPath, FilesystemIterator::SKIP_DOTS), RecursiveIteratorIterator::CHILD_FIRST) as $path) {
                $path->isFile() ? unlink($path->getPathname()) : rmdir($path->getPathname());
            }
            if($deleteParent) rmdir($dirPath);
        }
        
        /**
         * Function to read Excel File
         */
        public function readExcel($file) {
            if (empty ( $file ))
                return null;
                // load the excel library
                
                // read file from path
                log_message('debug','readExcel file : '.$file);
                $objPHPExcel = PHPExcel_IOFactory::load ( $file );
                // get only the Cell Collection
                $cell_collection = $objPHPExcel->getActiveSheet ()->getCellCollection ();
                // extract to a PHP readable array format
                log_message('debug','readExcel start');
                foreach ( $cell_collection as $cell ) {
                    $column = $objPHPExcel->getActiveSheet ()->getCell ( $cell )->getColumn ();
                    $row = $objPHPExcel->getActiveSheet ()->getCell ( $cell )->getRow ();
                    $data_value = $objPHPExcel->getActiveSheet ()->getCell ( $cell )->getValue ();
                    // header will/should be in row 1 only. of course this can be modified to suit your need.
                    // if ($row == 1) {
                    // $header [$row-1] [$column] = $data_value;
                        // } else {
                        // No header in mission csv files
                            $arr_data [$row-1] [$column] = $data_value;
                            // }
                        }
                        log_message('debug','readExcel end ');
                        // send the data in an array format
                        //$data ['header'] = $header;
                        $data = array ();
                        if(isset($arr_data))
                            $data ['values'] = $arr_data;
                            // print'<pre>';
                            // print_r($data);
                            // die;
                            return $data;
                }
                
                /**
                 * Function to Show Selected Mission Details
                 */
                public function viewDetail() {
                    if (! $this->session->userdata ( 'logged_in' )) {
                        redirect ( base_url () );
                    } else {
                        $req = $this->input->get ( 'id' );
                        
                        if (empty ( $req ))
                            redirect ( base_url () . "mission/getmissiontracker" );
                            
                            $data_1 = array (
                                'username' => $this->session->userdata ( 'username' ),
                                'logstatus' => "logout",
                                'title' => 'Mission',
                                'page' => "mission",
                                'app_lang' => $this->app_lang
                            );
                            
                            $this->load->view ( 'header', $data_1 );
                            $this->load->view ( 'left_sidebar', $data_1 );
                            
                            $mission_data = $this->skytrackermission_model->getMission($req);
                            
                            $flag_1['mission'] = $mission_data;
                            if (! empty ( $flag_1 ))
                                $this->load->view ( 'mission/view_info', $flag_1 );
                                else {
                                    $flag_1 = array (
                                        'value' => "null"
                                    );
                                    $this->load->view ( 'mission/view_info', $flag_1 );
                                }
                                
                                
                                $this->load->view ( 'footer' );
                    }
                }
                
                /**
                 * Function to save user comment on mission map
                 */
                public function savecomment() {
                    if (! $this->session->userdata ( 'logged_in' )) {
                        redirect ( base_url () );
                    } else {
                        $params = $this->setParams();
                        
                        $mission_data = $this->skytrackermission_model->addMissionComment($params);
                        if (! empty ( $mission_data ) && $mission_data > 0){
                            $params['comentId'] = $mission_data;
                            echo json_encode($params);
                        }
                        else
                            echo json_encode( array ('error' => 1));
                            die;
                    }
                    
                }
                
                /**
                 * Function to save user comment on mission map
                 */
                public function editcomment(){
                    if (! $this->session->userdata ( 'logged_in' )) {
                        redirect ( base_url () );
                    } else {
                        $params = $this->setEditParams();
                        
                        $mission_data = $this->skytrackermission_model->editcomment($params);
                        if (! empty ( $mission_data ) && $mission_data != false){
                            echo json_encode($params);
                        }
                        else
                            echo json_encode( array ('error' => 1));
                            die;
                    }
                }
                
                public function setParams() {
                    $lat = $this->input->get_post('lat');
                    $lng = $this->input->get_post('lng');
                    $comment = $this->input->get_post('comment');
                    $idMission = $this->input->get_post('idMission');
                    
                    $params = array (
                        'lat' => $lat,
                        'lng' => $lng,
                        'comment' => $comment,
                        'idMission' => $idMission,
                        'error' => 0
                    );
                    
                    return $params;
                }
                
                public function setEditParams() {
                    $comentId = $this->input->get_post('comentId');
                    $comment = $this->input->get_post('comment');
                    
                    $params = array (
                        'comentId' => $comentId,
                        'comment' => $comment,
                        'error' => 0
                    );
                    
                    return $params;
                }
                
                /**
                 * Function to Save image for PDF report
                 */
                public function uploadReportImage() {
                    
                    if (! $this->session->userdata ( 'logged_in' )) {
                        redirect ( base_url () );
                    } else {
                        $img =$this->input->get_post ( 'source' );
                        $imgName =$this->input->get_post ( 'imageName' );
                        
                        $data = base64_decode(preg_replace('#^data:image/\w+;base64,#i', '', $img));
                        file_put_contents("tempmissionImages/".$imgName, $data );
                    }
                }
                
                /**
                 * Function to Convert Data into PDF
                 */
                public function convertintopdf() {
                    
                    if (! $this->session->userdata ( 'logged_in' )) {
                        redirect ( base_url () );
                    } else {
                        $this->load->helper ( 'pdf_helper' );
                        $imgName =$this->input->get_post ( 'imageName' );
                        $idMission =$this->input->get_post ( 'idMission' );
                        $mission_data = $this->skytrackermission_model->getMission($idMission);
                        
                        
                        $data['imagepath'] = "tempmissionImages/".$imgName;
                        $data['mission'] = $mission_data;
                        $data = $this->load->view ( 'mission/missionpdfreport', $data, true );
                        create_pdf ( $data, 'Sky Tracker Mission Report' ); // Create pdf
                        
                    }
                }
                
                /**
                 * Delete create image for report
                 */
                public function deleteReportImage(){
                    if (! $this->session->userdata ( 'logged_in' ) ) {
                        redirect ( base_url () );
                    } else {
                        $imgName =$this->input->get_post ( 'imageName' );
                        unlink( $imgName);
                    }
                }
                
                /**
                 * Function to delete user comment on mission map
                 */
                public function deletecomment(){
                    if (! $this->session->userdata ( 'logged_in' )) {
                        redirect ( base_url () );
                    } else {
                        $comentId = $this->input->get_post('comentId');
                        $params = array (
                            'error' => 0
                        );
                        $mission_data = $this->skytrackermission_model->deletecomment($comentId);
                        if (! empty ( $mission_data ) && $mission_data != false){
                            echo json_encode($params);
                        }
                    }
                }
                
        }
        
        /* End of file mission_tracker.php */
        /* Location: ./application/con */