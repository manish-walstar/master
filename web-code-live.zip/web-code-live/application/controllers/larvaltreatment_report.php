<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Larvaltreatment_report extends CI_Controller {
	public $products;
	public $larval_treatment;
	public $product_list;
	public $startdate;
	public $starttime;
	public $enddate;
	public $endtime;
	public $inspector;
	public $currentdate;
	public $currenttime;
	public $endtimestamp;
	public $starttimestamp;
	public $userinfo;
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		$this->load->helper('language');
		$this->load->model ( 'larvaltreatment_report_model' );
		$this->load->model ( 'usermodel' );
		$this->currentdate = date ( 'm/d/Y' );
		$this->currenttime = date ( "H:i:s a" );
		$this->usermodel->set_access_session ();
		
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		if (! $this->usermodel->user_access ( 'reports' ) && ! $this->usermodel->user_access ( 'company_admin' ))
			redirect ( base_url () );
		$this->enddate = date ( 'm/d/Y' );
		$this->endtime = date ( 'H:i:s' );
		
		$this->startdate = date ( 'm/d/Y', strtotime ( "-30 day" ) );
		$this->starttime = date ( 'H:i:s' );
		
		$this->endtimestamp = strtotime ( date ( 'm/d/Y H:i:s' ) );
		
		$this->starttimestamp = strtotime ( date ( 'm/d/Y H:i:s', strtotime ( "-30 day" ) ) );
		
		if ($this->session->userdata ( 'id' )) {
			$this->larval_treatment = $this->larvaltreatment_report_model->getLarvalTreatment ( $this->startdate, $this->enddate );
			// print('<pre>');
			// print_r($this->larval_treatment);
			// die;
			$id = $this->session->userdata ( 'id' );
			$id_arr = explode ( "_", json_decode ( base64_decode ( $id ) ) );
			
			$id = json_decode ( base64_decode ( $id_arr [0] ) );
			
			$this->userinfo = $this->usermodel->getUserData ( $id );
			
			$middlename = " ";
			if (isset ( $this->userinfo ['middlename'] ))
				$middlename = ! empty ( $this->userinfo ['middlename'] ) ? " " . $this->userinfo ['middlename'] . " " : " ";
			
			if (isset ( $this->userinfo ['firstname'] ) || isset ( $this->userinfo ['lastname'] ))
				$this->inspector = $this->userinfo ['firstname'] . $middlename . $this->userinfo ['lastname'];
			
			$this->products = $this->larvaltreatment_report_model->getProducts ( $this->startdate, $this->enddate );
			$this->product_list = $this->larvaltreatment_report_model->getProducts_I ( $this->startdate, $this->enddate );
			// die;
			
			// print('<pre>');
			// print_r($this->larval_treatment);
			// die;
		}
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			redirect ( base_url () . "larvaltreatment_report/getlarvaltreatment" );
		}
	}
	
	/**
	 * Function to fetch All products
	 */
	public function getlarvaltreatment() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			
			$data_1 = array ();
			
			if (empty ( $startdate ) && empty ( $enddate )) {
				$data_1 = array (
						'username' => $this->session->userdata ( 'username' ),
						'logstatus' => "logout",
						'title' => $this->lang->line('lrvl_trtmnt_rprt_hdng'),
						'page' => "larvaltreatment",
						'startdate' => $this->startdate,
						'starttime' => date ( 'h:i:s A', strtotime ( $this->starttime ) ),
						'endtime' => date ( 'h:i:s A', strtotime ( $this->endtime ) ),
						'enddate' => $this->enddate,
						'inspector' => $this->inspector,
						'currentdate' => $this->currentdate,
						'currenttime' => date ( "h:i:s A", strtotime ( $this->currenttime ) ),
						'products' => $this->products,
						'product_list' => $this->product_list 
				);
			} else {
				$this->startdate = $startdate;
				$this->enddate = $enddate;
				
				$this->products = $this->larvaltreatment_report_model->getProducts ( $this->startdate, $this->enddate );
				$this->product_list = $this->larvaltreatment_report_model->getProducts_I ( $this->startdate, $this->enddate );
                //print'<pre>';
//                print_r($this->product_list);
//                die;
				
				$data_1 = array (
						'username' => $this->session->userdata ( 'username' ),
						'logstatus' => "logout",
						'title' => $this->lang->line('lrvl_trtmnt_rprt_hdng'),
						'page' => "larvaltreatment",
						'startdate' => $this->startdate,
						'starttime' => date ( 'h:i:s A', strtotime ( $this->starttime ) ),
						'endtime' => date ( 'h:i:s A', strtotime ( $this->endtime ) ),
						'enddate' => $this->enddate,
						'inspector' => $this->inspector,
						'currentdate' => $this->currentdate,
						'currenttime' => date ( "h:i:s A", strtotime ( $this->currenttime ) ),
						'products' => $this->products,
						'product_list' => $this->product_list 
				);
			}
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			$this->load->view ( 'larvaltreatment_reports/larvaltreatment_reports', $data_1 );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to fetch the data
	 * and format it in order to return
	 */
	public function exportView() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			$ctime = $this->input->post ( 'current_time' );
			$this->currenttime = ! empty ( $ctime ) ? $ctime : $this->currenttime;
			
			if (! empty ( $startdate ) && ! empty ( $enddate )) {
				$this->startdate = $startdate;
				
				$this->enddate = $enddate;
			}
			
			$this->products = $this->larvaltreatment_report_model->getProducts ( $this->startdate, $this->enddate );
			$this->product_list = $this->larvaltreatment_report_model->getProducts_I ( $this->startdate, $this->enddate );
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('lrvl_trtmnt_rprt_hdng'),
					'page' => "larvaltreatment",
					'startdate' => $this->startdate,
					'starttime' => date ( 'h:i:s A', strtotime ( $this->starttime ) ),
					'endtime' => date ( 'h:i:s A', strtotime ( $this->endtime ) ),
					'enddate' => $this->enddate,
					'inspector' => $this->inspector,
					'currentdate' => $this->currentdate,
					'currenttime' => date ( "h:i:s A", strtotime ( $this->currenttime ) ),
					'products' => $this->products,
					'product_list' => $this->product_list 
			);
			
			// print('<pre>');
			// print_r($data_1);
			// die;
			$data = $this->load->view ( 'larvaltreatment_reports/pdf_view', $data_1, TRUE );
			// print'<pre>';
			// print_r($data);
			// die;
			//
			return $data;
		}
	}
	
	/**
	 * Function to convert data into PDF
	 */
	public function toPDFAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->helper ( 'pdf_helper' );
			$data = $this->exportView ();
			// print'<pre>';
			// print_r($data);
			// die;
			//
			create_pdf ( $data, $this->lang->line('lrvl_trtmnt_excel_lbl') );
		}
	}
	
	/**
	 * Function to convert data into Excel
	 */
	public function toEXCELAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$data = $this->exportView ();
			// print'<pre>';
			// print_r($data);
			// die;
			//
			header ( "Content-type: application/octet-stream" );
			header ( "Content-Disposition: attachment; filename=" . $this->lang->line('lrvl_trtmnt_excel_lbl') .".xls" );
			header ( "Pragma: no-cache" );
			header ( "Expires: 0" );
			
			echo $data;
			exit ();
		}
	}
	
	/**
	 * Function to convert data into Word
	 */
	public function toWORDAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			// $query['data'] = $this->arbovirallab_model->listArbovirallabs();
			
			$data = $this->exportView ();
			
			header ( "Content-Type: application/vnd.ms-word" );
			header ( "Expires: 0" );
			header ( "Cache-Control:  must-revalidate, post-check=0, pre-check=0" );
			header ( "Content-disposition: attachment; filename=". $this->lang->line('lrvl_trtmnt_excel_lbl') .".doc" );
			echo $data;
			exit ();
		}
	}
	
	/**
	 * Function to return headers
	 */
	public function download_send_headers($filename) {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			header ( "Pragma: public" );
			header ( "Expires: 0" );
			header ( "Cache-Control: must-revalidate, post-check=0, pre-check=0" );
			header ( "Content-Type: application/force-download" );
			header ( "Content-Type: application/octet-stream" );
			header ( "Content-Type: application/download" );
			header ( "Content-Disposition: attachment;filename={$filename}" );
			header ( "Content-Transfer-Encoding: binary" );
		}
	}
	
	/**
	 * Function to convert Array into CSV
	 */
	public function array2csv(array &$array) {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			if (count ( $array ) == 0) {
				return null;
			}
			
			ob_start ();
			$df = fopen ( "php://output", 'w' );
			fputcsv ( $df, array_keys ( reset ( $array ) ) );
			foreach ( $array as $row ) {
				fputcsv ( $df, $row );
			}
			fclose ( $df );
			return ob_get_clean ();
		}
	}
	
	/**
	 * Function to convert data into XML
	 * Format
	 */
	public function toXMLAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->dbutil ();
			
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			$ctime = $this->input->post ( 'current_time' );
			$this->currenttime = ! empty ( $ctime ) ? $ctime : $this->currenttime;
			
			if (! empty ( $startdate ) && ! empty ( $enddate )) {
				$this->startdate = $startdate;
				$this->enddate = $enddate;
			}
			
			$query = $this->larvaltreatment_report_model->getXML ( $this->startdate, $this->enddate );
			
			$this->download_send_headers ( $this->lang->line('lrvl_trtmnt_excel_lbl') . ".xml" );
			echo $this->dbutil->xml_from_result ( $query );
		}
	}
	
	/**
	 * Function to convert data into CSV
	 */
	public function toCSVAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			$ctime = $this->input->post ( 'current_time' );
			$this->currenttime = ! empty ( $ctime ) ? $ctime : $this->currenttime;
			
			$id = $this->session->userdata ( 'id' );
			$id_arr = explode ( "_", json_decode ( base64_decode ( $id ) ) );
			
			$id = json_decode ( base64_decode ( $id_arr [0] ) );
			
			$this->userinfo = $this->usermodel->getUserData ( $id );
			
			$middlename = " ";
			if (isset ( $this->userinfo ['middlename'] ))
				$middlename = ! empty ( $this->userinfo ['middlename'] ) ? " " . $this->userinfo ['middlename'] . " " : " ";
			
			if (isset ( $this->userinfo ['firstname'] ) || isset ( $this->userinfo ['lastname'] ))
				$this->inspector = $this->userinfo ['firstname'] . $middlename . $this->userinfo ['lastname'];
			
			if (! empty ( $startdate ) && ! empty ( $enddate )) {
				$this->startdate = $startdate;
				$this->enddate = $enddate;
			}
			$this->products = $this->larvaltreatment_report_model->getProducts ( $this->startdate, $this->enddate );
			
			$temp_arr = array ();
			$i = 0;
			
			if (! empty ( $this->products ))
				foreach ( $this->products as $k => $v ) {
					$acres = 0.00;
					$sqft = 0.00;
					$basins = 0.00;
					$miles = 0.00;
					$treatment = 0;
					
					$temp_arr [$i] ['Product'] = $v ['productname'];
					$temp_arr [$i] ['Qty'] = $v ['qty'];
					$temp_arr [$i] ['UOM'] = $v ['uom'];
					
					if ($v ['units'] == "Acres") {
						$temp_arr [$i] ['Acres'] = $v ['area'];
						$temp_arr [$i] ['Sq. Ft'] = 0.00;
						$temp_arr [$i] ['Basins'] = 0.0;
						$temp_arr [$i] ['Miles'] = 0.00;
						$acres += floatval ( $v ['area'] );
					} else if ($v ['units'] == "Sq. Ft.") {
						$temp_arr [$i] ['Acres'] = 0.00;
						$temp_arr [$i] ['Sq. Ft'] = $v ['area'];
						$temp_arr [$i] ['Basins'] = 0.00;
						$temp_arr [$i] ['Miles'] = 0.00;
						$sqft += floatval ( $v ['area'] );
					} else if ($v ['units'] == "Basins") {
						$temp_arr [$i] ['Acres'] = 0.00;
						$temp_arr [$i] ['Sq. Ft'] = 0.00;
						$temp_arr [$i] ['Basins'] = $v ['area'];
						$temp_arr [$i] ['Miles'] = 0.00;
						$basins += floatval ( $v ['area'] );
					} else if ($v ['units'] == "Miles") {
						$temp_arr [$i] ['Acres'] = 0.00;
						$temp_arr [$i] ['Sq. Ft'] = 0.00;
						$temp_arr [$i] ['Basins'] = 0.00;
						$temp_arr [$i] ['Miles'] = $v ['area'];
						$miles += floatval ( $v ['area'] );
					}
					
					$temp_arr [$i] ['# of Trtmts'] = "";
					$i ++;
				}
			$this->download_send_headers ( $this->lang->line('lrvl_trtmnt_excel_lbl') . ".csv" );
			echo $this->array2csv ( $temp_arr );
		}
	}
	
	/**
	 * Function to convert data into Image
	 */
	public function toIMAGEAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->helper ( 'pdf_helper' );
			$data = $this->exportView ();
			// print'<pre>';
			// print_r($data);
			// die;
			
			return_pdf ( $data, $this->lang->line('lrvl_trtmnt_excel_lbl') ); // Create pdf
			
			exec ( "convert LarvalTreatmentpdf.pdf". $this->lang->line('lrvl_trtmnt_excel_lbl') . ".tif" );
			$this->download_send_headers ( $this->lang->line('lrvl_trtmnt_excel_lbl') . ".tif" );
			echo file_get_contents ( $this->lang->line('lrvl_trtmnt_excel_lbl') . ".tif" );
			unlink ( "temp/LarvalTreatmentpdf.pdf" );
			unlink ("temp/" . $this->lang->line('lrvl_trtmnt_excel_lbl') . ".tif" );
		}
	}
}

/* End of file larvaltreatment_report.php */
/* Location: ./application/controllers/larvaltreatment_report.php */