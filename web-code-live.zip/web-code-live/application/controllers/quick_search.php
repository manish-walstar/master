<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Quick_search extends CI_Controller {
	
	// public $input_data = "";
	// public $search_data = "";
	
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
        
		$this->load->helper('language');
        
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		if ($this->session->userdata ( 'idlocation' ))
			$this->idlocation = $this->session->userdata ( 'idlocation' );
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			redirect ( base_url () . "application/controllers/quick_search/" );
		}
	}
	
	/**
	 * Function to
	 */
	public function search() {
		// $input_data = "";
		// $search_data = "";
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$input_data = $this->input->post ( 'q' );
			
			if (($input_data == 'Search') || ($input_data == '')) {
				redirect ( base_url () );
			} else {
				$this->load->model ( 'quick_search_model' );
				$search_data = $this->quick_search_model->getData ( $input_data );
				$data_1 = array (
						'username' => $this->session->userdata ( 'username' ),
						'logstatus' => "logout",
						'title' => "Quick Search" 
				);
				$this->load->view ( 'header', $data_1 );
				
				$data_1 = array (
						'logstatus' => "logout",
						'page' => "search" 
				);
				
				$this->load->view ( 'left_sidebar', $data_1 );
				$this->load->view ( 'quick_search/search', $search_data );
			}
			$this->load->view ( 'footer' );
		}
	}
	
	/**
	 * Function to add a new adultsurveillance
	 */
	public function addadultsurveillance() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => "Quick Search" 
			);
			$this->load->view ( 'header', $data_1 );
			
			$data_1 = array (
					'logstatus' => "logout",
					'page' => "search" 
			);
			
			$this->load->view ( 'left_sidebar', $data_1 );
			
			$this->form_validation->set_rules ( 'idtrap', $this->lang->line('trap_mgmt_trap_nme'), 'trim|required' );
			$this->form_validation->set_rules ( 'idinspector', $this->lang->line('whthr_snsr_inspctr'), 'trim|required' );
			$this->form_validation->set_rules ( 'setdate', $this->lang->line('adlt_srvlnc_set_date'), 'trim|required' );
			$this->form_validation->set_rules ( 'settime', $this->lang->line('adlt_srvlnc_set_time'), 'trim|required' );
			$this->form_validation->set_rules ( 'pudate', 'Picked Date', 'trim|required' );
			$this->form_validation->set_rules ( 'putime', $this->lang->line('data_export_pckup_time'), 'trim|required' );
			
			$this->inspector = $this->adultsurveillance_model->getInspectors ();
			$this->trap_name = $this->adultsurveillance_model->getTrapname ();
			$this->temperature = $this->adultsurveillance_model->getTemprange ();
			$this->humidity = $this->adultsurveillance_model->getHumidityrange ();
			$this->windspeed = $this->adultsurveillance_model->getWindspeed ();
			$this->cloudcover = $this->adultsurveillance_model->getCloudcoverage ();
			$this->species = $this->adultsurveillance_model->getSpecies ( $this->idlocation );
			$service_req_id = $this->input->get_post ( 'service_req_id' );
			$service_req_id = ! empty ( $service_req_id ) ? $service_req_id : '';
			$data_1 = array (
					'trap_name' => $this->trap_name,
					'inspector' => $this->inspector,
					'temprange' => $this->temperature,
					'humidity' => $this->humidity,
					'windspeed' => $this->windspeed,
					'cloudcover' => $this->cloudcover,
					'species' => $this->species,
					'service_req_id' => $service_req_id 
			);
			
			if ($this->form_validation->run () == FALSE) {
				$this->load->view ( 'adultsurveillances/add_adultsurveillance', $data_1 );
			} else {
				
				$flag = $this->adultsurveillance_model->addAdultSurveillance ( $this->idlocation );
				
				if ($flag) {
					$service_req_id = $this->input->get_post ( 'service_req_id' );
					if (! empty ( $service_req_id )) {
						redirect ( base_url () . "service_request/getservice_request/?msg=success" );
					} else {
						redirect ( base_url () . "adultsurveillance/getadultsurveillance/?msg=success" );
					}
					
					// $this->load->view('adultsurveillances/add_adultsurveillance',$data_1);
				} else {
					// $data_1['unsuccess_msg'] = "Something Went Wrong";
					//
					// $this->load->view('adultsurveillances/add_adultsurveillance',$data_1);
					redirect ( base_url () . "adultsurveillance/getadultsurveillance/?del=error" );
				}
			}
		}
		
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to show edit adultsurveillance
	 */
	public function showeditadultsurveillance($Id = '', $msg = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			if (empty ( $Id ))
				$req = $this->input->get ( 'id', TRUE );
			else
				$req = $Id;
			$succ_msg = "";
			$error_msg = "";
			if (empty ( $req ))
				redirect ( base_url () . "adultsurveillance/getadultsurveillance" );
			
			$flag = $this->adultsurveillance_model->getAdultsurveillanceData ( $req );
			
			$id = base64_encode ( json_encode ( $flag ['idadultsurveillance'] ) );
			
			if ($msg == "updated") {
				$succ_msg = $this->lang->line('succ_msg_trap_updtd_scsflly');
			} else if ($msg == "error") {
				$error_msg = $this->lang->line('err_msg_smthng_went_wrng');
			}
			
			$data = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_data_entry_adlt_srvlnc'),
					'page' => "adultsurveillance" 
			);
			$this->load->view ( 'header', $data );
			
			$this->load->view ( 'left_sidebar', $data );
			
			if (! empty ( $flag )) {
				$this->inspector = $this->adultsurveillance_model->getSelectedInspectors ( $flag ['idinspector'] );
				$this->trap_name = $this->adultsurveillance_model->getSelectedTrapname ( $flag ['idtrap'] );
				$this->temperature = $this->adultsurveillance_model->getSelectedTemprange ( $flag ['idtemprange'] );
				$this->humidity = $this->adultsurveillance_model->getSelectedHumidityrange ( $flag ['idhumidityrange'] );
				$this->windspeed = $this->adultsurveillance_model->getSelectedWindspeed ( $flag ['idwindspeed'] );
				$this->cloudcover = $this->adultsurveillance_model->getSelectedCloudcoverage ( $flag ['idcloudcover'] );
				$this->species = $this->adultsurveillance_model->getSpeciesCount ( $this->idlocation, $flag ['idadultsurveillance'] );
			}
			// print'<pre>';
			// print_r($this->species);
			// die;
			$data_1 = array (
					'trap_name' => $this->trap_name,
					'inspector' => $this->inspector,
					'temprange' => $this->temperature,
					'humidity' => $this->humidity,
					'windspeed' => $this->windspeed,
					'cloudcover' => $this->cloudcover,
					'species' => $this->species,
					'id' => $id,
					'error_msg' => $error_msg,
					'succ_msg' => $succ_msg 
			);
			
			$data = array_merge ( $data_1, $flag );
			
			$this->load->view ( 'adultsurveillances/edit_adultsurveillance', $data );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to save edit Adult Surveillance Values
	 */
	public function editadultsurveillance() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->post ( 'x_s_' );
			
			if (empty ( $req ))
				redirect ( base_url () . "adultsurveillance/getadultsurveillance" );
			
			$req = json_decode ( base64_decode ( $req ) );
			
			$this->form_validation->set_rules ( 'idtrap', $this->lang->line('trap_mgmt_trap_nme'), 'trim|required' );
			$this->form_validation->set_rules ( 'idinspector', $this->lang->line('whthr_snsr_inspctr'), 'trim|required' );
			$this->form_validation->set_rules ( 'setdate', $this->lang->line('adlt_srvlnc_set_date'), 'trim|required' );
			$this->form_validation->set_rules ( 'settime', $this->lang->line('adlt_srvlnc_set_time'), 'trim|required' );
			$this->form_validation->set_rules ( 'pudate', 'Picked Date', 'trim|required' );
			$this->form_validation->set_rules ( 'putime', $this->lang->line('data_export_pckup_time'), 'trim|required' );
			
			if ($this->form_validation->run () == FALSE) {
				$this->showeditadultsurveillance ( $req );
			} else {
				$flag = $this->adultsurveillance_model->updateAdultsurveillance ( $req );
				
				if (! empty ( $flag )) {
					redirect ( base_url () . "adultsurveillance/getadultsurveillance/?msg=updated" );
				} else {
					redirect ( base_url () . "adultsurveillance/getadultsurveillance/?msg=error" );
				}
			}
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to delete adultsurveillance
	 */
	public function deleteadultsurveillance() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->adultsurveillance_model->deleteadultsurveillance ();
			
			$msg = "";
			
			if ($flag)
				$msg = "success";
			else
				$msg = "error";
			
			redirect ( base_url () . 'adultsurveillance/getadultsurveillance?del=' . $msg );
		}
	}
	
	/**
	 * Function to display List Of adultsurveillances
	 */
	public function getadultsurveillance($grid = '', $msg = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$filter_date = $this->input->post ( 'filter_date' );
			$columns = array (
					0 => array (
							'name' => $this->lang->line('trap_mgmt_trap_nme'),
							'db_name' => 'idtrap',
							'header' => $this->lang->line('trap_mgmt_trap_nme'),
							'group' => $this->lang->line('sidebar_data_entry_adlt_srvlnc'),
							'ref_table_id_name' => 'idtrap',
							'ref_table_db_name' => 'traps',
							'ref_field_db_name' => 'trap',
							'ref_field_type' => 'string',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-n' 
					),
					1 => array (
							'name' => $this->lang->line('trap_mgmt_trap_type'),
							'db_name' => 'idtrap',
							'header' => $this->lang->line('trap_mgmt_trap_type'),
							'group' => $this->lang->line('sidebar_data_entry_adlt_srvlnc'),
							'ref_table_id_name' => 'idtrap',
							'ref_table_db_name' => 'traps',
							'ref_field_db_name' => 'idtraptype',
							'ref_table_id2_name' => 'idtraptype',
							'ref_table_db2_name' => 'traptypes',
							'ref_field_db2_name' => 'traptype',
							'form_control' => 'dropdown',
							'type' => '1-1-1' 
					),
					2 => array (
							'name' => $this->lang->line('adlt_srvlnc_dt_tme_pckp'),
							'db_name_1' => 'pudate',
							'db_name_2' => 'putime',
							'header' => $this->lang->line('adlt_srvlnc_dt_tme_pckp'),
							'group' => $this->lang->line('sidebar_data_entry_adlt_srvlnc'),
							'form_control' => 'text_long',
							'type' => '1+2' 
					),
					3 => array (
							'name' => $this->lang->line('whthr_snsr_site_nm'),
							'db_name' => 'idtrap',
							'header' => $this->lang->line('whthr_snsr_site_nm'),
							'group' => $this->lang->line('sidebar_data_entry_adlt_srvlnc'),
							'ref_table_id_name' => 'idtrap',
							'ref_table_db_name' => 'traps',
							'ref_field_db_name' => 'idsite',
							'ref_table_id2_name' => 'idsite',
							'ref_table_db2_name' => 'sites',
							'ref_field_db2_name' => 'site',
							'ref_field_type' => 'string',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-1-1' 
					),
					4 => array (
							'name' => $this->lang->line('lnding_rte_cnt_cllctd'),
							'db_name' => 'idadultsurveillance',
							'header' => $this->lang->line('lnding_rte_cnt_cllctd'),
							'group' => $this->lang->line('sidebar_data_entry_adlt_srvlnc'),
							'ref_table_id_name' => 'idadultsurveillance',
							'ref_table_db_name' => 'adultsurveillancedetails',
							'ref_field_db_name' => 'count',
							'type' => '1-t' 
					),
					5 => array (
							'name' => $this->lang->line('whthr_snsr_inspctr'),
							'db_name' => 'idinspector',
							'header' => $this->lang->line('whthr_snsr_inspctr'),
							'group' => $this->lang->line('sidebar_data_entry_adlt_srvlnc'),
							'ref_table_id_name' => 'iduser',
							'ref_table_db_name' => 'users',
							'ref_field_db_name' => 'firstname',
							'ref_field_2_db_name' => 'lastname',
							'ref_field_type' => 'string',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-1+2' 
					) 
			);
			
			$commands ['delete'] ['toolbar'] = FALSE;
			// check url comes from service request or not
			// code for addtional request from service and larval
			$table1_rel = '';
			
			$service_req_id = '';
			$service_req_id = $this->input->get_post ( 'service_req_id' );
			
			if (! empty ( $service_req_id )) {
				$table1_rel = 'adultsurveillanceservice';
			}
			
			$count_view = $this->load->view ( 'adultsurveillances/allspecies_view', '', TRUE );
			$edit_view = $this->load->view ( 'adultsurveillances/history_view', '', TRUE );
			$params = array (
					'id' => 'idadultsurveillance',
					'table' => 'adultsurveillance',
					'url' => 'adultsurveillance/getadultsurveillance',
					'uri_param' => $grid,
					'columns' => $columns,
					'order' => array (
							0 => 'asc' 
					),
					'table1_rel' => $table1_rel,
					'filters' => array (
							0 => array (
									'value' => $this->idlocation 
							) 
					),
					'filter_date' => ! empty ( $filter_date ) ? $filter_date : '',
					// 'columns_visible' => array(0,1,2),
					'commands' => $commands,
					'ajax' => TRUE,
					'msc_url' => array (
							'excel_url' => base_url () . 'adultsurveillance/toExcelAll',
							'pdf_url' => base_url () . 'adultsurveillance/toPdfAll',
							'text' => $this->lang->line('sidebar_data_entry_adlt_srvlnc') 
					),
					'count_view' => $count_view,
					'add_view' => $count_view,
					'edit_view' => $edit_view 
			);
			
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_data_entry_adlt_srvlnc') 
			);
			$this->load->view ( 'header', $data_1 );
			
			$data_1 = array (
					'logstatus' => "logout",
					'page' => "adultsurveillance" 
			);
			
			$this->load->view ( 'left_sidebar', $data_1 );
			
			// Pass grid to the view
			$data->page = 'grid_single';
			
			$data->page_grid = $this->carbogrid->render ();
			$data->msg = $msg;
			// $data->mapdata = $this->showmap();
			$data->mapdata = base_url () . 'adultsurveillance/showmap';
			
			$this->load->view ( 'adultsurveillances/adultsurveillances', $data );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to display map
	 */
	public function showmap() {
		$query ['data'] = $this->adultsurveillance_model->getMapdata ();
		$query ['user_loc'] = $this->adultsurveillance_model->getUserLoc ();
		
		// $data = $this->load->view('adultsurveillances/map_view',$query,TRUE);
		$this->load->view ( 'adultsurveillances/map_view', $query );
		// return $data;
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function getadultsurveillancedata() {
		$id = $this->input->post ( 'idadultsurveillance' );
		
		if (empty ( $id )) {
			echo "error";
			exit ();
		}
		
		$data = $this->adultsurveillance_model->getAdultsurveillanceData ( $id );
		
		echo json_encode ( $data );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function history() {
		$req = $this->input->get_post ( 'id' );
		
		if (empty ( $req ))
			redirect ( base_url () . "adultsurveillance/getadultsurveillance" );
		
		$data1 = $this->adultsurveillance_model->getHistory ( $req );
		
		$mos = $this->adultsurveillance_model->getSpecies ( $this->idlocation );
		
		$str = "";
		
		$str = "<tr>
                <th><?php echo lang('trap_mgmt_trap_nme'); ?>:</th>
                <td>" . $data1 [0] ['trap'] . "</td>
                </tr>
                <tr>
                <th><?php echo lang('trap_mgmt_trap_type'); ?>:</th>
                <td>" . $data1 [0] ['traptype'] . "</td>
                </tr>
                <tr>
                <td colspan='2'>&nbsp;</td>
                </tr>
        ";
		$str .= "<tr>
                <th>".$this->lang->line('adlt_srvlnc_date_of_pckp')."</th>
                <th>' . $this->lang->line('adlt_srvlnc_ttl_count') . '</th>	
        ";
		$count = count ( $mos );
		foreach ( $mos as $key => $val ) {
			$str .= "<th style='text-align: left;'>" . $val . "</th>";
		}
		$str .= "</tr>";
		// echo $str;
		// die;
		if (! empty ( $data1 )) {
			foreach ( $data1 as $key => $val ) {
				$date = date ( 'd-m-Y', strtotime ( $val ['pudate'] ) );
				$date = ! empty ( $date ) ? $date : '00-00-0000';
				$str .= "<tr>
                        <td>" . $date . "</td>
                ";
				$i = 0;
				if (! empty ( $val ['species'] )) {
					$c = ! empty ( $val ['species'] [0] ['total_count'] ) ? $val ['species'] [0] ['total_count'] : '0';
					$str .= "<td>" . $c . "</td>";
					
					foreach ( $val ['species'] as $k => $v ) {
						if (! empty ( $v ['count'] ) && ! empty ( $mos [$v ['idmosquitospecies']] ) && $v ['mosquitospecies'] == $mos [$v ['idmosquitospecies']])
							$str .= "<td>" . $v ['count'] . "(" . number_format ( ( float ) $v ['count_percent'], 2, '.', '' ) . "%)</td>";
						else
							$str .= "<td>0(0%)</td>";
						
						$i ++;
					}
				} else {
					for($j = 0; $j < $count; $j ++) {
						$str .= "<th>0(0%)</th>";
					}
				}
				
				if ($i != $count) {
					for($j = $i; $j < $count; $j ++) {
						$str .= "<td>0(0%)</td>";
					}
				}
				$str .= "</tr>";
			}
		}
		// $str .= "</table>";
		$set = array (
				'data' => $str 
		);
		
		// echo $str;
		// print'<pre>';
		// print_r($mos);
		// print_r($data1);
		// die;
		$this->load->view ( 'adultsurveillances/history_view', $set );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function collectedSpecies() {
		$req = $this->input->get_post ( 'id' );
		
		if (empty ( $req )) {
			echo 'something went wrong';
			exit ();
		}
		$query = $this->adultsurveillance_model->getSpeciesCount ( $this->idlocation, $req );
		$str = '';
		
		if (! empty ( $query )) {
			foreach ( $query as $key => $val ) {
				$spc = ! empty ( $val ['species'] ) ? $val ['species'] : '0';
				$c = ! empty ( $val ['count'] ) ? $val ['count'] : '0';
				
				$str .= '<tr><td>' . $spc . '</td><td></td><td>' . $c . '</td></tr>';
			}
		}
		
		$data = array (
				'data' => $str 
		);
		// echo '<pre>';
		// print_r($str);
		// die;
		$this->load->view ( 'adultsurveillances/allspecies_view', $data );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function toExcelAll() {
		$query ['data'] = $this->adultsurveillance_model->listAdultsurveillances ();
		// print'<pre>';
		// print_r($query['data']);
		// die;
		$this->load->view ( 'adultsurveillances/excel_view', $query );
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
		$this->load->helper ( 'pdf_helper' ); // Load helper
		$query ['data'] = $this->adultsurveillance_model->listAdultsurveillances ();
		// print'<pre>';
		// print_r($query['data']);
		// die;
		$data = $this->load->view ( 'adultsurveillances/pdf_view', $query, true );
		// $data = file_get_contents(htmlentities($dd)); // Pass the url of html report
		
		create_pdf ( $data, $this->lang->line('adlt_srvlnc_hdng') ); // Create pdf
	}
}

/* End of file adultsurveillance.php */
/* Location: ./application/controllers/adultsurveillance.php */