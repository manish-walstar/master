<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Adultsurveillance extends CI_Controller {
	public $idlocation = "";
	public $trap_name = "";
	public $inspector = "";
	public $temperature = "";
	public $humidity = "";
	public $windspeed = "";
	public $cloudcover = "";
	public $species = "";
	public $s_species = "";
	public $date;
	public $settime;
	public $putime;
    public $app_lang;
    public $selected_species = "";
    public $columns;
    public $params;
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		
		$this->settime = date ( 'h:i A' );
		$this->putime = date ( 'h:i A' );
		$this->load->helper('language');
		$this->load->model ( 'adultsurveillance_model' );
		
		if ($this->session->userdata ( 'idlocation' ))
			$this->idlocation = $this->session->userdata ( 'idlocation' );
		
		$this->load->model ( 'usermodel' );
		$this->load->model ( 'zone_model' );
		$this->usermodel->set_access_session ();
		
		if ($this->usermodel->user_access ( 'surveillance' ) || $this->usermodel->user_access ( 'company_admin' )) {
		} else {
			redirect ( base_url () );
		}
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
        $this->inspector = $this->adultsurveillance_model->getInspectors ();
		$this->trap_name = $this->adultsurveillance_model->getTrapname ();
		$this->temperature = $this->adultsurveillance_model->getTemprange ();
		$this->humidity = $this->adultsurveillance_model->getHumidityrange ();
		$this->windspeed = $this->adultsurveillance_model->getWindspeed ();
		$this->cloudcover = $this->adultsurveillance_model->getCloudcoverage ();
		$this->species = $this->adultsurveillance_model->getSpecies ( $this->idlocation );
        $this->columns = array (
				0 => array (
						'name' => $this->lang->line('trap_mgmt_trap_nme'),
						'db_name' => 'idtrap',
						'header' => $this->lang->line('trap_mgmt_trap_nme'),
						'group' => $this->lang->line('sidebar_data_entry_adlt_srvlnc'),
						'ref_table_id_name' => 'idtrap',
						'ref_table_db_name' => 'traps',
						'ref_field_db_name' => 'trap',
						'ref_field_type' => 'string',
						'form_control' => 'text_long',
						'required' => TRUE,
						'type' => '1-n' 
				),
				1 => array (
						'name' => $this->lang->line('trap_mgmt_trap_type'),
						'db_name' => 'idtrap',
						'header' => $this->lang->line('trap_mgmt_trap_type'),
						'group' => $this->lang->line('sidebar_data_entry_adlt_srvlnc'),
						'ref_table_id_name' => 'idtrap',
						'ref_table_db_name' => 'traps',
						'ref_field_db_name' => 'idtraptype',
						'ref_table_id2_name' => 'idtraptype',
						'ref_table_db2_name' => 'traptypes',
						'ref_field_db2_name' => 'traptype',
						'form_control' => 'dropdown',
						'type' => '1-1-1' 
				),
				2 => array (
						'name' => $this->lang->line('adlt_srvlnc_dt_tme_pckp'),
						'db_name_1' => 'pudate',
						'db_name_2' => 'putime',
						'header' => $this->lang->line('adlt_srvlnc_dt_tme_pckp'),
						'group' => $this->lang->line('sidebar_data_entry_adlt_srvlnc'),
						'form_control' => 'text_long',
						'type' => '1+2' 
				),
				3 => array (
						'name' => $this->lang->line('whthr_snsr_site_nm'),
						'db_name' => 'idtrap',
						'header' => $this->lang->line('whthr_snsr_site_nm'),
						'group' => $this->lang->line('sidebar_data_entry_adlt_srvlnc'),
						'ref_table_id_name' => 'idtrap',
						'ref_table_db_name' => 'traps',
						'ref_field_db_name' => 'idsite',
						'ref_table_id2_name' => 'idsite',
						'ref_table_db2_name' => 'sites',
						'ref_field_db2_name' => 'site',
						'ref_field_type' => 'string',
						'form_control' => 'text_long',
						'required' => TRUE,
						'type' => '1-1-1' 
				),
				4 => array (
						'name' => $this->lang->line('lnding_rte_cnt_cllctd'),
						'db_name' => 'totalcount',
						'header' => $this->lang->line('lnding_rte_cnt_cllctd'),
						'group' => $this->lang->line('sidebar_data_entry_adlt_srvlnc') 
				),
				5 => array (
						'name' => $this->lang->line('whthr_snsr_inspctr'),
						'db_name' => 'idinspector',
						'header' => $this->lang->line('whthr_snsr_inspctr'),
						'group' => $this->lang->line('sidebar_data_entry_adlt_srvlnc'),
						'ref_table_id_name' => 'iduser',
						'ref_table_db_name' => 'users',
						'ref_field_db_name' => 'firstname',
						'ref_field_2_db_name' => 'middlename',
						'ref_field_3_db_name' => 'lastname',
						'ref_field_type' => 'string',
						'form_control' => 'text_long',
						'required' => TRUE,
						'type' => '1-1+2+3' 
				)
		);
        
        $this->params = array (
				'id' => 'idadultsurveillance',
				'table' => 'adultsurveillance',
				'columns' => $this->columns
		);
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			redirect ( base_url () . "adultsurveillance/getadultsurveillance" );
		}
	}
	
	/**
	 * Function to Show Add Member Form
	 */
	public function showaddadultsurveillance() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
            $service_req_id = $this->input->get_post ( 'service_req_id' );
			$service_req_id = ! empty ( $service_req_id ) ? $service_req_id : '';
            $mapFlag = $this->input->get_post ( 'mapFlag' );
            $idsite = $this->input->get('idsite');
            $eventData = $this->getAllEventsData($idsite);
            
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_data_entry_adlt_srvlnc'),
					'page' => "adultsurveillance",
                    'app_lang' => $this->app_lang,
                    'trap_name' => $this->trap_name,
					'inspector' => $this->inspector,
					'temprange' => $this->temperature,
					'humidity' => $this->humidity,
					'windspeed' => $this->windspeed,
					'cloudcover' => $this->cloudcover,
					'species' => $this->species,
					'service_req_id' => $service_req_id,
					'settime' => $this->settime,
					'putime' => $this->putime,
                    'mapFlag' => $mapFlag
			);
			
            $data_1 = array_merge($data_1, $eventData);
            if(empty($mapFlag)) {
                $this->load->view ( 'header', $data_1 );
                $this->load->view ( 'left_sidebar', $data_1 );   
            }
			// print'<pre>';
			// print_r($data_1);
			// die;
			$this->load->view ( 'adultsurveillances/add_adultsurveillance', $data_1 );
            
            if(empty($mapFlag)) {
                $this->load->view ( 'footer' );   
            }
		}
	}
	
	/**
	 * Function to add a new adultsurveillance
	 */
	public function addadultsurveillance() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$bttn_submit_back = $this->input->post ( 'submit_back' );
			$bttn_submit_1 = $this->input->post ( 'submit_1' );
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_data_entry_adlt_srvlnc'),
					'page' => "adultsurveillance",
                    'app_lang' => $this->app_lang 
			);
			$this->load->view ( 'header', $data_1 );
			
			$this->load->view ( 'left_sidebar', $data_1 );
			
			$this->form_validation->set_rules ( 'idtrap', $this->lang->line('trap_mgmt_trap_nme'), 'trim|required' );
			$this->form_validation->set_rules ( 'idinspector', $this->lang->line('whthr_snsr_inspctr'), 'trim|required' );
			$this->form_validation->set_rules ( 'setdate', $this->lang->line('adlt_srvlnc_set_date'), 'trim|required' );
			$this->form_validation->set_rules ( 'settime', $this->lang->line('adlt_srvlnc_set_time'), 'trim|required' );
			$this->form_validation->set_rules ( 'pudate', $this->lang->line('data_export_pckup_date'), 'trim|required' );
			$this->form_validation->set_rules ( 'putime', $this->lang->line('data_export_pckup_time'), 'trim|required' );
            
			$service_req_id = $this->input->get_post ( 'service_req_id' );
			$service_req_id = ! empty ( $service_req_id ) ? $service_req_id : '';
			$data_1 = array (
					'trap_name' => $this->trap_name,
					'inspector' => $this->inspector,
					'temprange' => $this->temperature,
					'humidity' => $this->humidity,
					'windspeed' => $this->windspeed,
					'cloudcover' => $this->cloudcover,
					'species' => $this->species,
					'service_req_id' => $service_req_id,
					'settime' => $this->settime,
					'putime' => $this->putime 
			);
			if ($this->form_validation->run () == FALSE) {
				$this->load->view ( 'adultsurveillances/add_adultsurveillance', $data_1 );
			} else {
				$flag = $this->adultsurveillance_model->addAdultSurveillance ( $this->session->userdata ( 'idlocation' ) );
				// print'<pre>';
				// print_r($flag);
				// die;
				$this->inspector = $this->adultsurveillance_model->getSelectedInspectors ( $flag ['idinspector'] );
				$this->trap_name = $this->adultsurveillance_model->getTrapname ();
				$this->temperature = $this->adultsurveillance_model->getSelectedTemprange ( $flag ['idtemprange'] );
				$this->humidity = $this->adultsurveillance_model->getSelectedHumidityrange ( $flag ['idhumidityrange'] );
				$this->windspeed = $this->adultsurveillance_model->getSelectedWindspeed ( $flag ['idwindspeed'] );
				$this->cloudcover = $this->adultsurveillance_model->getSelectedCloudcoverage ( $flag ['idcloudcover'] );
				$this->species = $this->adultsurveillance_model->getSpecies ();
				
				$data_1 = array (
						'trap_name' => $this->trap_name,
						'inspector' => $this->inspector,
						'temprange' => $this->temperature,
						'humidity' => $this->humidity,
						'windspeed' => $this->windspeed,
						'cloudcover' => $this->cloudcover,
						'species' => $this->species 
				);
				
				$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
				if ($flag ['message'] == 'success') {
					$service_req_id = $this->input->get_post ( 'service_req_id' );
					if (! empty ( $bttn_submit_1 )) {
						$data_1 ['message'] = 'success';
						$this->load->view ( 'adultsurveillances/add_adultsurveillance', $data_1 );
					} else if (! empty ( $bttn_submit_back )) {
						if (! empty ( $seturl [1] )) {
							$seturl2 = explode ( "=", $seturl [1] );
							if (! empty ( $seturl2 [1] ))
								redirect ( $seturl [0] . "?msg=success#" . $seturl [1] );
						}
						redirect ( $seturl [0] . "?msg=success" );
					}
					
					// its redirect to listing page
					// $seturl = explode("#",$this->session->userdata('url'));
					// redirect($seturl[0]."?msg=success#".$seturl[1]);
				} else if ($flag ['message'] == 'error') {
					if (! empty ( $bttn_submit_1 )) {
						$data_1 ['message'] = 'error';
						$this->load->view ( 'adultsurveillances/add_adultsurveillance', $data_1 );
					} else if (! empty ( $bttn_submit_back )) {
						if (! empty ( $seturl [1] )) {
							$seturl2 = explode ( "=", $seturl [1] );
							if (! empty ( $seturl2 [1] ))
								redirect ( $seturl [0] . "?msg=error#" . $seturl [1] );
						}
						redirect ( $seturl [0] . "?msg=error" );
					}
				}
			}
		}
		
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to show edit adultsurveillance
	 */
	public function showeditadultsurveillance($Id = '', $msg = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			if (empty ( $Id ))
				$req = $this->input->get ( 'id', TRUE );
			else
				$req = $Id;
            
            $mapFlag = $this->input->get_post ( 'mapFlag' );
            $mapSite = "";
			$succ_msg = "";
			$error_msg = "";
			if (empty ( $req ))
				redirect ( base_url () . "adultsurveillance/getadultsurveillance" );
			
			$flag = $this->adultsurveillance_model->getAdultsurveillanceData ( $req );
			$mapSite = $this->adultsurveillance_model->getIdSite ( $req );
			$id = base64_encode ( json_encode ( $flag ['idadultsurveillance'] ) );
			
			if ($msg == "updated") {
				$succ_msg = $this->lang->line('succ_msg_trap_updtd_scsflly');
			} else if ($msg == "error") {
				$error_msg = $this->lang->line('err_msg_smthng_went_wrng');
			}
            
			if (! empty ( $flag )) {
				$this->inspector = $this->adultsurveillance_model->getSelectedInspectors ( $flag ['idinspector'] );
				$this->trap_name = $this->adultsurveillance_model->getSelectedTrapname ( $flag ['idtrap'] );
				$this->temperature = $this->adultsurveillance_model->getSelectedTemprange ( $flag ['idtemprange'] );
				$this->humidity = $this->adultsurveillance_model->getSelectedHumidityrange ( $flag ['idhumidityrange'] );
				$this->windspeed = $this->adultsurveillance_model->getSelectedWindspeed ( $flag ['idwindspeed'] );
				$this->cloudcover = $this->adultsurveillance_model->getSelectedCloudcoverage ( $flag ['idcloudcover'] );
				$this->species = $this->adultsurveillance_model->getSpeciesCount ( $this->idlocation, $flag ['idadultsurveillance'] );
				$this->selected_species = $this->adultsurveillance_model->getSelectedSpecies ( $flag ['idadultsurveillance'] );
			}
			// print'<pre>';
			// print_r($this->species);
			// print_r($this->selected_species);
			// die;
			$data_1 = array (
                    'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_data_entry_adlt_srvlnc'),
					'page' => "adultsurveillance",
                    'app_lang' => $this->app_lang,
					'trap_name' => $this->trap_name,
					'inspector' => $this->inspector,
					'temprange' => $this->temperature,
					'humidity' => $this->humidity,
					'windspeed' => $this->windspeed,
					'cloudcover' => $this->cloudcover,
					'species' => $this->species,
					'selected_species' => $this->selected_species,
					'id' => $id,
					'error_msg' => $error_msg,
					'succ_msg' => $succ_msg 
			);
			
            $flag ['mapFlag'] = $mapFlag;
            $mapData = $this->getAllEventsData($mapSite);
            $flag = array_merge($flag, $mapData);
            
			$data = !empty($flag) ? array_merge ( $data_1, $flag ) : $data_1;
			// print'<pre>';
			// print_r($data);
			// die;
            if(empty($mapFlag)){
                $this->load->view ( 'header', $data );
                $this->load->view ( 'left_sidebar', $data );   
            }
            
			$this->load->view ( 'adultsurveillances/edit_adultsurveillance', $data );
		}
        if(empty($mapFlag)){
            $this->load->view ( 'footer' );   
        }
	}
	
	/**
	 * Function to show edit adultsurveillance
	 * This function is for Activity Report
	 */
	public function showEditAdultActive($Id = '', $msg = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			if (empty ( $Id ))
				$req = $this->input->get ( 'id', TRUE );
			else
				$req = $Id;
			$succ_msg = "";
			$error_msg = "";
			if (empty ( $req ))
				redirect ( base_url () . "adultsurveillance/getadultsurveillance" );
			
			$flag = $this->adultsurveillance_model->getAdultsurveillanceData ( $req );
			
			$id = base64_encode ( json_encode ( $flag ['idadultsurveillance'] ) );
			
			if ($msg == "updated") {
				$succ_msg = $this->lang->line('succ_msg_trap_updtd_scsflly');
			} else if ($msg == "error") {
				$error_msg = $this->lang->line('err_msg_smthng_went_wrng');
			}
			
			$data = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_data_entry_adlt_srvlnc'),
					'page' => "adultsurveillance",
                    'app_lang' => $this->app_lang
			);
			
			if (! empty ( $flag )) {
				$this->inspector = $this->adultsurveillance_model->getSelectedInspectors ( $flag ['idinspector'] );
				$this->trap_name = $this->adultsurveillance_model->getSelectedTrapname ( $flag ['idtrap'] );
				$this->temperature = $this->adultsurveillance_model->getSelectedTemprange ( $flag ['idtemprange'] );
				$this->humidity = $this->adultsurveillance_model->getSelectedHumidityrange ( $flag ['idhumidityrange'] );
				$this->windspeed = $this->adultsurveillance_model->getSelectedWindspeed ( $flag ['idwindspeed'] );
				$this->cloudcover = $this->adultsurveillance_model->getSelectedCloudcoverage ( $flag ['idcloudcover'] );
				$this->species = $this->adultsurveillance_model->getSpeciesCount ( $this->idlocation, $flag ['idadultsurveillance'] );
				$this->selected_species = $this->adultsurveillance_model->getSelectedSpecies ( $flag ['idadultsurveillance'] );
			}
			// print'<pre>';
			// print_r($this->species);
			// print_r($this->selected_species);
			// die;
			$data_1 = array (
					'trap_name' => $this->trap_name,
					'inspector' => $this->inspector,
					'temprange' => $this->temperature,
					'humidity' => $this->humidity,
					'windspeed' => $this->windspeed,
					'cloudcover' => $this->cloudcover,
					'species' => $this->species,
					'selected_species' => $this->selected_species,
					'id' => $id,
					'error_msg' => $error_msg,
					'succ_msg' => $succ_msg 
			);
			
			$data = array_merge ( $data_1, $flag );
			// print'<pre>';
			// print_r($data);
			// die;
			$this->load->view ( 'adultsurveillances/edit_adultactivity', $data );
		}
	}
	public function updateData() {
		$this->adultsurveillance_model->updateData ();
	}
	/**
	 * Function to save edit Adult Surveillance Values
	 */
	public function editadultsurveillance() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->post ( 'x_s_' );
			
			if (empty ( $req ))
				redirect ( base_url () . "adultsurveillance/getadultsurveillance" );
			
			$req = json_decode ( base64_decode ( $req ) );
			
			$this->form_validation->set_rules ( 'idtrap', $this->lang->line('trap_mgmt_trap_nme'), 'trim|required' );
			$this->form_validation->set_rules ( 'idinspector', $this->lang->line('whthr_snsr_inspctr'), 'trim|required' );
			$this->form_validation->set_rules ( 'setdate', $this->lang->line('adlt_srvlnc_set_date'), 'trim|required' );
			$this->form_validation->set_rules ( 'settime', $this->lang->line('adlt_srvlnc_set_time'), 'trim|required' );
			$this->form_validation->set_rules ( 'pudate', $this->lang->line('data_export_pckup_date'), 'trim|required' );
			$this->form_validation->set_rules ( 'putime', $this->lang->line('data_export_pckup_time'), 'trim|required' );
			
			if ($this->form_validation->run () == FALSE) {
				$this->showeditadultsurveillance ( $req );
			} else {
				$flag = $this->adultsurveillance_model->updateAdultsurveillance ( $req );
				
				if (! empty ( $flag )) {
					// redirect(base_url()."adultsurveillance/getadultsurveillance/?msg=updated');
					$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
					
					if (! empty ( $seturl [1] ))
						redirect ( $seturl [0] . "?msg=updated#" . $seturl [1] );
					else
						redirect ( $seturl [0] . "?msg=updated" );
				} else {
					// redirect(base_url()."adultsurveillance/getadultsurveillance/?msg=error');
					$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
					
					if (! empty ( $seturl [1] ))
						redirect ( $seturl [0] . "?msg=error#" . $seturl [1] );
					else
						redirect ( $seturl [0] . "?msg=error" );
				}
			}
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to delete adultsurveillance
	 */
	public function deleteadultsurveillance() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->adultsurveillance_model->deleteadultsurveillance ();
			
			$msg = "";
			
			if ($flag)
				$msg = "success";
			else
				$msg = "error";
			
			$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
			
			if (! empty ( $seturl [1] ))
				redirect ( $seturl [0] . "?del=" . $msg . "#" . $seturl [1] );
			else
				redirect ( $seturl [0] . "?del=" . $msg );
		}
	}
	
	/**
	 * Function to display List Of adultsurveillances
	 */
	public function getadultsurveillance($grid = '', $msg = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$filter_date = $this->input->post ( 'filter_date' );
			
			$commands ['delete'] ['toolbar'] = FALSE;
			// check url comes from service request or not
			// code for addtional request from service and larval
			$table1_rel = '';
			
			$service_req_id = '';
			$service_req_id = $this->input->get_post ( 'service_req_id' );
			
			if (! empty ( $service_req_id )) {
				$table1_rel = 'adultsurveillanceservice';
			}
			
			$count_view = $this->load->view ( 'adultsurveillances/allspecies_view', '', TRUE );
			$edit_view = $this->load->view ( 'adultsurveillances/history_view', '', TRUE );
			
			$this->params = array (
    				'id' => 'idadultsurveillance',
    				'table' => 'adultsurveillance',
    				'url' => 'adultsurveillance/getadultsurveillance',
    				'uri_param' => $grid,
    				'columns' => $this->columns,
    				'order' => array (
    						2 => 'desc' 
    				),
    				'table1_rel' => $table1_rel,
    				'filters' => array (
    						0 => array (
    								'value' => $this->idlocation 
    						) 
    				),
    				'filter_date' => ! empty ( $filter_date ) ? $filter_date : '2',

				// 'columns_visible' => array(0,1,2),
    				'commands' => $commands,
    				'ajax' => TRUE,
    				'msc_url' => array (
    						'excel_url' => base_url () . 'adultsurveillance/toExcelAll',
    						'pdf_url' => base_url () . 'adultsurveillance/toPdfAll',
    						'text' => $this->lang->line('sidebar_data_entry_adlt_srvlnc') 
    				),
    				'count_view' => $count_view,
    				'add_view' => $count_view,
    				'edit_view' => $edit_view 
    		);
            
			$newdata = array (
					'url' => base_url () . $this->params ['url'] . '#' . $this->params ['id'] . '=' . $grid 
			);
			
			$this->session->set_userdata ( $newdata );
			
			$this->load->library ( 'carbogrid', $this->params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_data_entry_adlt_srvlnc'),
					'page' => "adultsurveillance",
                    'app_lang' => $this->app_lang
			);
			$this->load->view ( 'header', $data_1 );
			
			$this->load->view ( 'left_sidebar', $data_1 );
			
			// Pass grid to the view
            $data = (object)array();
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			$data->msg = $msg;
			// $data->mapdata = $this->showmap();
			$data->mapdata = base_url () . 'adultsurveillance/showmap';
			
			$this->load->view ( 'adultsurveillances/adultsurveillances', $data );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to display map
	 */
	public function showmap() {
		$query ['data'] = $this->adultsurveillance_model->getMapdata($this->columns);
        $query ['user_loc'] = $this->adultsurveillance_model->getUserLoc ();
		$query ['zone_loc'] = $this->zone_model->getZoneCord ();
		$query ['googlezoom'] = $this->session->userdata ( 'googlezoom' );
        $this->load->view ( 'adultsurveillances/map_view', $query );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function getadultsurveillancedata($id = '') {
		if (empty ( $id ))
			$id = $this->input->post ( 'idadultsurveillance' );
		
		if (empty ( $id )) {
			echo "error";
			exit ();
		}
		
		$data = $this->adultsurveillance_model->getAdultsurveillanceData ( $id );
		
		echo json_encode ( $data );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function history() {
		$req = $this->input->get_post ( 'id' );
		
		if (empty ( $req ))
			redirect ( base_url () . "adultsurveillance/getadultsurveillance" );
		
		$data1 = $this->adultsurveillance_model->getHistory ( $req );
		
		$mos = $this->adultsurveillance_model->getSpecies ( $this->idlocation );
		// print'<pre>';
		// print_r($data1);
		// die;
		$str = "";
		
		$str = "<tr style='font:normal 14px Helvetica'>
                <th>" . $this->lang->line('trap_mgmt_trap_nme') . ":</th>
                <td>" . $data1 [0] ['trap'] . "</td>";
		
		$str .= "</tr>
                <tr>
                <th>" . $this->lang->line('trap_mgmt_trap_type') . ":</th>
                <td>" . $data1 [0] ['traptype'] . "</td>
                ";
		
		$str .= "</tr><tr>
                <td colspan='2'>&nbsp;</td>
                </tr>
        ";
		$str .= "<tr style='font:normal 14px Helvetica'>
                <th>" . $this->lang->line('adlt_srvlnc_date_of_pckp') . "</th>
                <th>" . $this->lang->line('adlt_srvlnc_ttl_count') . "</th>	
        ";
		$count = count ( $mos );
		foreach ( $mos as $key => $val ) {
			$str .= "<th style='text-align: left;'>" . $this->lang->line( 'drpdwn_' . removeSpecialChars($val['species']) ) . "</th>";
		}
		$str .= "</tr>";
		// echo $str;
		// die;
		if (! empty ( $data1 )) {
			foreach ( $data1 as $key => $val ) {
				$date = date ( 'm/d/Y', strtotime ( $val ['pudate'] ) );
				$date = ! empty ( $date ) ? $date : '00/00/0000';
				$str .= "<tr style='font:normal 14px Helvetica'>
                        <td>" . $date . "</td>
                ";
				$i = 0;
				if (! empty ( $val ['species'] )) {
					$c = ! empty ( $val ['species'] [0] ['total_count'] ) ? $val ['species'] [0] ['total_count'] : '0';
					$str .= "<td>" . $c . "</td>";
					
					foreach ( $mos as $k => $v ) {
						$chek = 1;
						foreach ( $val ['species'] as $k_1 => $v_1 ) {
							// echo $v_1['idmosquitospecies']." ".$v['idspecies']."<br>";
							if (! empty ( $v_1 ['count'] ) && ! empty ( $v ['idspecies'] ) && $v_1 ['idmosquitospecies'] == $v ['idspecies']) {
								$str .= "<td>" . $v_1 ['count'] . "(" . number_format ( ( float ) $v_1 ['count_percent'], 2, '.', '' ) . "%)</td>";
								$chek = 0;
								// echo " chek : ".$chek."<br>";
							}
						}
						
						if ($chek == 1) {
							$str .= "<td>0(0%)</td>";
						}
						
						$i ++;
					}
					
					// die;
				} else {
					for($j = 0; $j < $count; $j ++) {
						$str .= "<th>0(0%)</th>";
					}
				}
				
				$str .= "</tr>";
			}
		}

		$set = array (
				'data' => $str 
		);
		
		$this->load->view ( 'adultsurveillances/history_view', $set );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function collectedSpecies() {
		$req = $this->input->get_post ( 'id' );
		
		if (empty ( $req )) {
			echo 'something went wrong';
			exit ();
		}
		$query = $this->adultsurveillance_model->getSpeciesCount ( $this->idlocation, $req );
		$str = '';
		
		if (! empty ( $query )) {
			foreach ( $query as $key => $val ) {
				$spc = ! empty ( $val ['species'] ) ? $this->lang->line( 'drpdwn_' . removeSpecialChars($val['species']) ) : '0';
				$c = ! empty ( $val ['count'] ) ? $val ['count'] : '0';
				
				$str .= '<tr><td>' . $spc . '</td><td></td><td>' . $c . '</td></tr>';
			}
		}
		
		$data = array (
				'data' => $str 
		);
		
		$this->load->view ( 'adultsurveillances/allspecies_view', $data );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function toExcelAll() {
		$query ['data'] = $this->adultsurveillance_model->listAdultsurveillances ();
		
		$this->load->view ( 'adultsurveillances/excel_view', $query );
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
		$this->load->helper ( 'pdf_helper' ); // Load helper
		$query ['data'] = $this->adultsurveillance_model ();
		
		$data = $this->load->view ( 'adultsurveillances/pdf_view', $query, true );
		
		create_pdf_l ( $data, $this->lang->line('sidebar_data_entry_adlt_srvlnc') ); // Create pdf
	}
    
    /**
     * Function to fetch all site data based on module
     */
    public function getAllEventsData($idsite = "")
    {
        $params = array('idsite' => $idsite, 'idlocation' => $this->session->userdata('idlocation'));

        $this->load->library('common', $params);

        $response = $this->common->getAllEventsData();
        //print'<pre>';
        //        print_r($response);
        //        die;
        return $response;
    }
}

/* End of file adultsurveillance.php */
/* Location: ./application/controllers/adultsurveillance.php */
