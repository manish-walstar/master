<?php
//error_reporting ( 0 );
if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
date_default_timezone_set ( 'UTC' );
class Larvalsurveillance_report extends CI_Controller {
	public $products;
	public $larval_surveillance;
	public $product_list;
	public $startdate;
	public $starttime;
	public $enddate;
	public $endtime;
	public $inspector;
	public $currentdate;
	public $currenttime;
	public $zones;
	public $zone = "";
	public $sites;
	public $site = "";
	public $species;
	public $_species = "";
	public $_techs = "";
	public $techs;
	public $traptypes;
	public $_traptypes = "";
	public $endtimestamp;
	public $starttimestamp;
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		$this->load->helper('language');
		$this->load->model ( 'larvalsurveillance_report_model' );
		$this->load->model ( 'site_model' );
		$this->load->model ( 'trap_model' );
		$this->load->model ( 'arbovirallab_model' );
		$this->load->model ( 'usermodel' );
        $this->load->model ( 'treatment_model' );
        
		$this->usermodel->set_access_session ();
		
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		if (! $this->usermodel->user_access ( 'reports' ) && ! $this->usermodel->user_access ( 'company_admin' ))
			redirect ( base_url () );
		
		$id = $this->session->userdata ( 'id' );
		$id_arr = explode ( "_", json_decode ( base64_decode ( $id ) ) );
		
		$id = json_decode ( base64_decode ( $id_arr [0] ) );
		
		$this->userinfo = $this->usermodel->getUserData ( $id );
		
		$middlename = " ";
		if (isset ( $this->userinfo ['middlename'] ))
			$middlename = ! empty ( $this->userinfo ['middlename'] ) ? " " . $this->userinfo ['middlename'] . " " : " ";
		
		if (isset ( $this->userinfo ['firstname'] ) || isset ( $this->userinfo ['lastname'] ))
			$this->inspector = $this->userinfo ['firstname'] . $middlename . $this->userinfo ['lastname'];
		
		$this->currentdate = date ( 'm/d/Y' );
		$this->currenttime = date ( "h:i:s A" );
		
		$this->enddate = date ( 'm/d/Y' );
		$this->endtime = date ( 'h:i:s A' );
		
		$this->startdate = date ( 'm/d/Y', strtotime ( "-30 day" ) );
		$this->starttime = date ( 'h:i:s A' );
		
		$this->endtimestamp = strtotime ( date ( 'm/d/Y H:i:s' ) );
		
		$this->starttimestamp = strtotime ( date ( 'm/d/Y H:i:s', strtotime ( "-30 day" ) ) );
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			redirect ( base_url () . "larvalsurveillance_report/getlarvalsurveillance" );
		}
	}
	
	/**
	 * Function to fetch All products
	 */
	public function getlarvalsurveillance() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			// print'<pre>';
			// print_r($_POST);
			// die;
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			
			$this->zone = $this->input->post ( 'zone' );
			$this->site = $this->input->post ( 'site' );
			$this->_techs = $this->input->post ( 'techs' );
			$this->_species = $this->input->post ( 'species' );
			$this->_traptypes = $this->input->post ( 'traptypes' );
			
			$data_1 = array ();
			// echo $startdate." ".$enddate;
			// die;
			if (empty ( $startdate ) || empty ( $enddate )) {
				
				$this->zones = $this->site_model->getZones ();
				$this->sites = $this->site_model->getSelectedExistingSite ();
				$this->traptypes = $this->trap_model->getTraptypes ();
				$this->techs = $this->arbovirallab_model->getLabtechnician ();
				$this->species = $this->treatment_model->getSpecies ();
				
				$this->products = $this->larvalsurveillance_report_model->getLarvalSurveillance ( $this->startdate, $this->enddate, $this->zone, $this->site, $this->_species, $this->_traptypes, $this->_techs );
				
				// print('<pre>');
				// print_r($this->products);
				// die;
				$data_1 = array (
						'username' => $this->session->userdata ( 'username' ),
						'logstatus' => "logout",
						'title' => $this->lang->line('lrvl_srvlc_rprt_hdng'),
						'page' => "larvalsurveillance_report",
						'startdate' => date ( "m/d/Y", strtotime ( $this->startdate ) ),
						'starttime' => date ( 'h:i:s A', strtotime ( $this->starttime ) ),
						'endtime' => date ( 'h:i:s A', strtotime ( $this->endtime ) ),
						'enddate' => date ( "m/d/Y", strtotime ( $this->enddate ) ),
						'inspector' => $this->inspector,
						'currentdate' => $this->currentdate,
						'currenttime' => date ( "h:i:s A", strtotime ( $this->currenttime ) ),
						'products' => $this->products,
						'product_list' => $this->product_list,
						'zones' => $this->zones,
						'sites' => $this->sites,
						'traptypes' => $this->traptypes,
						'techs' => $this->techs,
						'species' => $this->species 
				);
			} else {
				
				$startdate_arr = explode ( " ", $startdate );
				
				$enddate_arr = explode ( " ", $enddate );
				
				$this->startdate = date ( 'm/d/Y', strtotime ( $startdate_arr [0] ) );
				
				$this->enddate = date ( 'm/d/Y', strtotime ( $enddate_arr [0] ) );
				
				// $id = $this->session->userdata('id');
				//
				// $id_arr = explode("_",json_decode(base64_decode($id)));
				//
				// $id = json_decode(base64_decode($id_arr[0]));
				//
				// $this->userinfo = $this->usermodel->getUserData($id);
				//
				// $middlename = " ";
				// if(isset($this->userinfo['middlename']))
				// $middlename = !empty($this->userinfo['middlename'])?" ".$this->userinfo['middlename']." ":" ";
				//
				// if(isset($this->userinfo['firstname']) || isset($this->userinfo['lastname']))
				// $this->inspector = $this->userinfo['firstname'].$middlename.$this->userinfo['lastname'];
				
				// echo "here";
				// echo $this->startdate." ".$this->enddate." ".$this->zone." ".$this->site." S".$this->_species." ".$this->_traptypes." ".$this->_techs."<br>";
				// die;
				$this->products = $this->larvalsurveillance_report_model->getLarvalSurveillance ( $this->startdate, $this->enddate, $this->zone, $this->site, $this->_species, $this->_techs );
				
				$this->zones = $this->site_model->getZones ( $this->zone );
				$this->sites = $this->site_model->getSelectedExistingSite ( $this->site );
				$this->traptypes = $this->trap_model->getTraptypes ();
				$this->techs = $this->arbovirallab_model->getLabtechnician ( $this->_techs );
				$this->species = $this->treatment_model->getSpecies ();
				
				$data_1 = array (
						'username' => $this->session->userdata ( 'username' ),
						'logstatus' => "logout",
						'title' => $this->lang->line('lrvl_srvlc_rprt_hdng'),
						'page' => "larvalsurveillance_report",
						'startdate' => date ( "m/d/Y", strtotime ( $this->startdate ) ),
						'starttime' => date ( 'h:i:s A', strtotime ( $this->starttime ) ),
						'endtime' => date ( 'h:i:s A', strtotime ( $this->endtime ) ),
						'enddate' => date ( "m/d/Y", strtotime ( $this->enddate ) ),
						'inspector' => $this->inspector,
						'currentdate' => $this->currentdate,
						'currenttime' => date ( "h:i:s A", strtotime ( $this->currenttime ) ),
						'products' => $this->products,
						'zones' => $this->zones,
						'sites' => $this->sites,
						'traptypes' => $this->traptypes,
						'techs' => $this->techs,
						'species' => $this->species,
                        'idmosquitospecies' => $this->_species,
                        'idtraptype' => $this->_traptypes
				);
			}
			
			// print('<pre>');
			// print_r($this->products);
			// print_r($data_1);
			// die;
			$this->load->view ( 'header', $data_1 );
			
			$this->load->view ( 'left_sidebar', $data_1 );
			
			$this->load->view ( 'larvalsurveillance_reports/larvalsurveillance_reports', $data_1 );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to fetch the data
	 * and format it in order to return
	 */
	public function exportView() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			$ctime = $this->input->post ( 'current_time' );
			$this->currenttime = ! empty ( $ctime ) ? $ctime : $this->currenttime;
			
			if (! empty ( $startdate ) && ! empty ( $enddate )) {
				$this->startdate = $startdate;
				
				$this->enddate = $enddate;
			}
			
			$this->products = $this->larvalsurveillance_report_model->getLarvalSurveillance ( $this->startdate, $this->enddate, $this->zone, $this->site, $this->_species, $this->_traptypes, $this->_techs );
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('lrvl_srvlc_rprt_hdng'),
					'page' => "larvalsurveillance_report",
					'startdate' => date ( "m/d/Y", strtotime ( $this->startdate ) ),
					'starttime' => date ( 'h:i:s A', strtotime ( $this->starttime ) ),
					'endtime' => date ( 'h:i:s A', strtotime ( $this->endtime ) ),
					'enddate' => date ( "m/d/Y", strtotime ( $this->enddate ) ),
					'inspector' => $this->inspector,
					'currentdate' => $this->currentdate,
					'currenttime' => date ( "h:i:s A", strtotime ( $this->currenttime ) ),
					'products' => $this->products 
			);
			
			// print('<pre>');
			// print_r($data_1);
			// die;
			$data = $this->load->view ( 'larvalsurveillance_reports/pdf_view', $data_1, TRUE );
			// print'<pre>';
			// print_r($data);
			// die;
			//
			return $data;
		}
	}
	
	/**
	 * Function to convert data into PDF
	 */
	public function toPDFAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->helper ( 'pdf_helper' );
			
			$data = $this->exportView ();
			// print'<pre>';
			// print_r($data);
			// die;
			
			create_pdf ( $data, $this->lang->line('lrvl_srvlnc_lrvl_srvlncs') );
		}
	}
	
	/**
	 * Function to convert data into Excel
	 */
	public function toEXCELAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$data = $this->exportView ();
			// print'<pre>';
			// print_r($data);
			// die;
			//
			header ( "Content-type: application/octet-stream" );
			header ( "Content-Disposition: attachment; filename=".$this->lang->line('lrvl_srvlnc_lrvl_srvlncs').".xls" );
			header ( "Pragma: no-cache" );
			header ( "Expires: 0" );
			
			echo $data;
			exit ();
		}
	}
	
	/**
	 * Function to convert data into Word
	 */
	public function toWORDAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			header ( "Content-Type: application/vnd.ms-word" );
			header ( "Expires: 0" );
			header ( "Cache-Control:  must-revalidate, post-check=0, pre-check=0" );
			header ( "Content-disposition: attachment; filename=". $this->lang->line('lrvl_srvlnc_lrvl_srvlncs') .".doc" );
			
			// $query['data'] = $this->arbovirallab_model->listArbovirallabs();
			
			$data = $this->exportView ();
			
			echo $data;
			exit ();
		}
	}
	
	/**
	 * Function to convert data into XML
	 * Format
	 */
	public function toXMLAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			$ctime = $this->input->post ( 'current_time' );
			$this->currenttime = ! empty ( $ctime ) ? $ctime : $this->currenttime;
			
			$this->zone = $this->input->post ( 'zone' );
			$this->site = $this->input->post ( 'site' );
			$this->_techs = $this->input->post ( 'techs' );
			$this->_species = $this->input->post ( 'species' );
			$this->_traptypes = $this->input->post ( 'traptypes' );
			
			$id = $this->session->userdata ( 'id' );
			$id_arr = explode ( "_", json_decode ( base64_decode ( $id ) ) );
			
			$id = json_decode ( base64_decode ( $id_arr [0] ) );
			
			$this->userinfo = $this->usermodel->getUserData ( $id );
			
			$middlename = " ";
			if (isset ( $this->userinfo ['middlename'] ))
				$middlename = ! empty ( $this->userinfo ['middlename'] ) ? " " . $this->userinfo ['middlename'] . " " : " ";
			
			if (isset ( $this->userinfo ['firstname'] ) || isset ( $this->userinfo ['lastname'] ))
				$this->inspector = $this->userinfo ['firstname'] . $middlename . $this->userinfo ['lastname'];
			
			if (! empty ( $startdate ) && ! empty ( $enddate )) {
				$startdate_arr = explode ( " ", $startdate );
				$enddate_arr = explode ( " ", $enddate );
				
				$this->startdate = date ( 'm/d/Y', strtotime ( $startdate_arr [0] ) );
				
				$this->enddate = date ( 'm/d/Y', strtotime ( $enddate_arr [0] ) );
			}
			
			$this->products = $this->larvalsurveillance_report_model->getLarvalSurveillance ( $this->startdate, $this->enddate, $this->zone, $this->site, $this->_species, $this->_traptypes, $this->_techs );
			
			$temp_arr = array ();
			$i = 0;
			$c = 0;
			$grndttl = 0.00;
			$count = count ( $this->products );
			$siteavg = 0.00;
			$sitettl = 0.00;
			// print'<pre>';
			// print_r($this->products);
			// die;
			$xml = new SimpleXMLElement ( '<xml/>' );
			
			if (! empty ( $this->products ))
				foreach ( $this->products as $key => $val ) {
					$entry = $xml->addChild ( 'entry' );
					$entry->addChild ( 'Zone', $val ['zone'] );
					
					if (! empty ( $val ['sitedata'] ))
						foreach ( $val ['sitedata'] as $k => $v ) {
							$sitettl = 0.00;
							if ($k != "0") {
								$entry->addChild ( 'Zone', '' );
							}
							
							$entry->addChild ( 'Site', $v ['site'] );
							//
							if (! empty ( $v ['larval'] )) {
								foreach ( $v ['larval'] as $k_1 => $v_1 ) {
									$diff = "";
									$trapttl = 0.00;
									$diff = floor ( date ( 'd', $v_1 ['date'] - $v_1 ['date'] ) );
									$middlename = ! empty ( $v_1 ['middlename'] ) ? " " . $v_1 ['middlename'] . " " : " ";
									
									if ($k_1 != "0") {
										$entry->addChild ( 'Zone', '' );
										$entry->addChild ( 'Site', '' );
									}
									
									$entry->addChild ( 'Date', date ( 'm/d/Y', strtotime ( $v_1 ['date'] ) ) );
									$entry->addChild ( 'Action', '' );
									
									if (! empty ( $v_1 ['species'] )) {
										foreach ( $v_1 ['species'] as $k_2 => $v_2 ) {
											
											if ($k_2 != "0") {
												$entry->addChild ( 'Zone', '' );
												$entry->addChild ( 'Site', '' );
												$entry->addChild ( 'Date', '' );
												$entry->addChild ( 'Action', '' );
											}
											
											$entry->addChild ( 'Species', substr ( $v_2 ['genus'], 0, 2 ) . ". " . $v_2 ['mosquitospecies'] );
											$entry->addChild ( 'Total_Collected', $v_1 ['larvaecountrange'] );
											$entry->addChild ( 'Temp_F', $v_1 ['watertemprange'] );
											$entry->addChild ( 'Tech_ID', $v_1 ['firstname'] . $middlename . $v_1 ['lastname'] );
											$entry->addChild ( 'Notes', 'NA' );
											
											$trapttl += floatval ( $v_1 ['watertemprange'] );
											
											$i ++;
										}
									} else {
										$entry->addChild ( 'Species', '' );
										$entry->addChild ( 'Total_Collected', '' );
										$entry->addChild ( 'Temp_F', '' );
										$entry->addChild ( 'Tech_ID', $v_1 ['firstname'] . $middlename . $v_1 ['lastname'] );
										$entry->addChild ( 'Notes', 'NA' );
										
										$i ++;
									}
									
									$sitettl = floatval ( $trapttl ) / 2;
									$sitettl = number_format ( $sitettl, '2', '.', '' );
									$sitettl = (empty ( $sitettl ) || $sitettl == "0.00" || $sitettl == 0.00) ? "NA" : $sitettl;
									
									$entry->addChild ( 'Zone', '' );
									$entry->addChild ( 'Site', '' );
									$entry->addChild ( 'Date', '' );
									$entry->addChild ( 'Action', '' );
									
									$entry->addChild ( 'Species', '' );
									$entry->addChild ( 'Total_Collected', '' );
									$entry->addChild ( 'Temp_F', '' );
									$entry->addChild ( 'Tech_ID', $v_1 ['firstname'] . $middlename . $v_1 ['lastname'] );
									$entry->addChild ( 'Notes', 'NA' );
									
									$i ++;
								}
							} else {
								$entry->addChild ( 'Date', '' );
								$entry->addChild ( 'Action', '' );
								
								$entry->addChild ( 'Species', '' );
								$entry->addChild ( 'Total_Collected', 'Date Average' );
								$entry->addChild ( 'Temp_F', $sitettl );
								$entry->addChild ( 'Tech_ID', '' );
								$entry->addChild ( 'Notes', 'NA' );
								
								$i ++;
							}
							
							$siteavg = $sitettl / 2;
							
							$entry->addChild ( 'Zone', '' );
							$entry->addChild ( 'Site', '' );
							$entry->addChild ( 'Date', '' );
							$entry->addChild ( 'Action', '' );
							
							$entry->addChild ( 'Species', '' );
							$entry->addChild ( 'Total_Collected', 'Site Average' );
							$entry->addChild ( 'Temp_F', number_format ( $siteavg, '2', '.', '' ) );
							$entry->addChild ( 'Tech_ID', '' );
							$entry->addChild ( 'Notes', '' );
							
							$i ++;
						}
					else {
						$entry->addChild ( 'Zone', $val ['zone'] );
						$entry->addChild ( 'Site', '' );
						$entry->addChild ( 'Date', '' );
						$entry->addChild ( 'Action', '' );
						
						$entry->addChild ( 'Species', '' );
						$entry->addChild ( 'Total_Collected', 'Date Average' );
						$entry->addChild ( 'Temp_F', $sitettl );
						$entry->addChild ( 'Tech_ID', '' );
						$entry->addChild ( 'Notes', 'NA' );
						
						$i ++;
						
						$entry->addChild ( 'Zone', $val ['zone'] );
						$entry->addChild ( 'Site', '' );
						$entry->addChild ( 'Date', '' );
						$entry->addChild ( 'Action', '' );
						
						$entry->addChild ( 'Species', '' );
						$entry->addChild ( 'Total_Collected', 'Site Average' );
						$entry->addChild ( 'Temp_F', number_format ( $siteavg, '2', '.', '' ) );
						$entry->addChild ( 'Tech_ID', '' );
						$entry->addChild ( 'Notes', 'NA' );
					}
					
					$i ++;
					
					$flag = $val ['idzone'];
				}
				// print($xml->asXML());
				// die;
			$this->download_send_headers ( $this->lang->line('lrvl_srvlnc_lrvl_srvlncs') . ".xml" );
			print ($xml->asXML ()) ;
		}
	}
	
	/**
	 * Function to return headers
	 */
	public function download_send_headers($filename) {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			header ( "Pragma: public" );
			header ( "Expires: 0" );
			header ( "Cache-Control: must-revalidate, post-check=0, pre-check=0" );
			header ( "Content-Type: application/force-download" );
			header ( "Content-Type: application/octet-stream" );
			header ( "Content-Type: application/download" );
			header ( "Content-Disposition: attachment;filename={$filename}" );
			header ( "Content-Transfer-Encoding: binary" );
		}
	}
	
	/**
	 * Function to convert Array into CSV
	 */
	public function array2csv(array &$array) {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			if (count ( $array ) == 0) {
				return null;
			}
			
			ob_start ();
			$df = fopen ( "php://output", 'w' );
			fputcsv ( $df, array_keys ( reset ( $array ) ) );
			foreach ( $array as $row ) {
				fputcsv ( $df, $row );
			}
			fclose ( $df );
			return ob_get_clean ();
		}
	}
	
	/**
	 * Function to convert data into CSV
	 */
	public function toCSVAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$startdate = $this->input->post ( 'startdate' );
			$enddate = $this->input->post ( 'enddate' );
			
			$this->zone = $this->input->post ( 'zone' );
			$this->site = $this->input->post ( 'site' );
			$this->_techs = $this->input->post ( 'techs' );
			$this->_species = $this->input->post ( 'species' );
			$this->_traptypes = $this->input->post ( 'traptypes' );
			
			$id = $this->session->userdata ( 'id' );
			$id_arr = explode ( "_", json_decode ( base64_decode ( $id ) ) );
			
			$id = json_decode ( base64_decode ( $id_arr [0] ) );
			
			$this->userinfo = $this->usermodel->getUserData ( $id );
			
			$middlename = " ";
			if (isset ( $this->userinfo ['middlename'] ))
				$middlename = ! empty ( $this->userinfo ['middlename'] ) ? " " . $this->userinfo ['middlename'] . " " : " ";
			
			if (isset ( $this->userinfo ['firstname'] ) || isset ( $this->userinfo ['lastname'] ))
				$this->inspector = $this->userinfo ['firstname'] . $middlename . $this->userinfo ['lastname'];
			
			if (! empty ( $startdate ) && ! empty ( $enddate )) {
				$startdate_arr = explode ( " ", $startdate );
				$enddate_arr = explode ( " ", $enddate );
				
				$this->startdate = date ( 'm/d/Y', strtotime ( $startdate_arr [0] ) );
				
				$this->enddate = date ( 'm/d/Y', strtotime ( $enddate_arr [0] ) );
			}
			
			$this->products = $this->larvalsurveillance_report_model->getLarvalSurveillance ( $this->startdate, $this->enddate, $this->zone, $this->site, $this->_species, $this->_traptypes, $this->_techs );
			
			$temp_arr = array ();
			$i = 0;
			$c = 0;
			$grndttl = 0.00;
			$count = count ( $this->products );
			$siteavg = 0.00;
			$sitettl = 0.00;
			// print'<pre>';
			// print_r($this->products);
			// die;
			
			if (! empty ( $this->products ))
				foreach ( $this->products as $key => $val ) {
					$temp_arr [$i] ['Zone'] = $val ['zone'];
					
					if (! empty ( $val ['sitedata'] ))
						foreach ( $val ['sitedata'] as $k => $v ) {
							$sitettl = 0.00;
							if ($k != "0") {
								$temp_arr [$i] ['Zone'] = '';
							}
							
							$temp_arr [$i] ['Site'] = $v ['site'];
							//
							if (! empty ( $v ['larval'] )) {
								foreach ( $v ['larval'] as $k_1 => $v_1 ) {
									$diff = "";
									$trapttl = 0.00;
									$diff = floor ( date ( 'd', $v_1 ['date'] - $v_1 ['date'] ) );
									$middlename = ! empty ( $v_1 ['middlename'] ) ? " " . $v_1 ['middlename'] . " " : " ";
									
									if ($k_1 != "0") {
										$temp_arr [$i] ['Zone'] = '';
										$temp_arr [$i] ['Site'] = '';
									}
									
									$temp_arr [$i] ['Date'] = date ( 'm/d/Y', strtotime ( $v_1 ['date'] ) );
									$temp_arr [$i] ['Action'] = '';
									
									if (! empty ( $v_1 ['species'] )) {
										foreach ( $v_1 ['species'] as $k_2 => $v_2 ) {
											
											if ($k_2 != "0") {
												$temp_arr [$i] ['Zone'] = '';
												$temp_arr [$i] ['Site'] = '';
												$temp_arr [$i] ['Date'] = '';
												$temp_arr [$i] ['Action'] = '';
											}
											
											$temp_arr [$i] ['Species'] = substr ( $v_2 ['genus'], 0, 2 ) . ". " . $v_2 ['mosquitospecies'];
											
											$temp_arr [$i] ['Total Collected'] = $v_1 ['larvaecountrange'];
											$temp_arr [$i] ['Temp (F)'] = $v_1 ['watertemprange'];
											$temp_arr [$i] ['Tech ID'] = $v_1 ['firstname'] . $middlename . $v_1 ['lastname'];
											$temp_arr [$i] ['Notes'] = 'NA';
											
											$trapttl += floatval ( $v_1 ['watertemprange'] );
											
											$i ++;
										}
									} else {
										$temp_arr [$i] ['Species'] = '';
										$temp_arr [$i] ['Total Collected'] = '';
										$temp_arr [$i] ['Temp (F)'] = '';
										$temp_arr [$i] ['Tech ID'] = $v_1 ['firstname'] . $middlename . $v_1 ['lastname'];
										$temp_arr [$i] ['Notes'] = 'NA';
										$i ++;
									}
									
									$sitettl = floatval ( $trapttl ) / 2;
									$sitettl = number_format ( $sitettl, '2', '.', '' );
									$sitettl = (empty ( $sitettl ) || $sitettl == "0.00" || $sitettl == 0.00) ? "NA" : $sitettl;
									
									$temp_arr [$i] ['Zone'] = $val ['zone'];
									$temp_arr [$i] ['Site'] = $v ['site'];
									$temp_arr [$i] ['Date'] = date ( 'm/d/Y', strtotime ( $v_1 ['date'] ) );
									$temp_arr [$i] ['Action'] = '';
									$temp_arr [$i] ['Species'] = '';
									$temp_arr [$i] ['Total Collected'] = 'Date Average';
									$temp_arr [$i] ['Temp (F)'] = $sitettl;
									$temp_arr [$i] ['Tech ID'] = '';
									$temp_arr [$i] ['Notes'] = '';
									
									$i ++;
								}
							} else {
								
								$temp_arr [$i] ['Date'] = '';
								$temp_arr [$i] ['Action'] = '';
								$temp_arr [$i] ['Species'] = '';
								$temp_arr [$i] ['Total Collected'] = 'Date Average';
								$temp_arr [$i] ['Temp (F)'] = $sitettl;
								$temp_arr [$i] ['Tech ID'] = '';
								$temp_arr [$i] ['Notes'] = 'NA';
								
								$i ++;
							}
							
							$siteavg = $sitettl / 2;
							
							$temp_arr [$i] ['Zone'] = '';
							$temp_arr [$i] ['Site'] = '';
							$temp_arr [$i] ['Date'] = '';
							$temp_arr [$i] ['Action'] = '';
							
							$temp_arr [$i] ['Species'] = '';
							$temp_arr [$i] ['Total Collected'] = 'Site Average';
							$temp_arr [$i] ['Temp (F)'] = number_format ( $siteavg, '2', '.', '' );
							$temp_arr [$i] ['Tech ID'] = '';
							$temp_arr [$i] ['Notes'] = '';
							
							$i ++;
						}
					else {
						$temp_arr [$i] ['Zone'] = $val ['zone'];
						$temp_arr [$i] ['Site'] = '';
						$temp_arr [$i] ['Date'] = '';
						$temp_arr [$i] ['Action'] = '';
						
						$temp_arr [$i] ['Species'] = '';
						$temp_arr [$i] ['Total Collected'] = 'Date Average';
						$temp_arr [$i] ['Temp (F)'] = $sitettl;
						$temp_arr [$i] ['Tech ID'] = '';
						$temp_arr [$i] ['Notes'] = 'NA';
						
						$i ++;
						
						$temp_arr [$i] ['Zone'] = $val ['zone'];
						$temp_arr [$i] ['Site'] = '';
						$temp_arr [$i] ['Date'] = '';
						$temp_arr [$i] ['Action'] = '';
						
						$temp_arr [$i] ['Species'] = '';
						$temp_arr [$i] ['Total Collected'] = 'Site Average';
						$temp_arr [$i] ['Temp (F)'] = number_format ( $siteavg, '2', '.', '' );
						$temp_arr [$i] ['Tech ID'] = '';
						$temp_arr [$i] ['Notes'] = '';
					}
					
					$i ++;
					
					$flag = $val ['idzone'];
				}
				
				// print'<pre>';
				// print_r($temp_arr);
				// die;
			$this->download_send_headers ( $this->lang->line('lrvl_srvlnc_lrvl_srvlncs') . ".csv" );
			echo $this->array2csv ( $temp_arr );
		}
	}
	
	/**
	 * Function to convert data into Image
	 */
	public function toIMAGEAll() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->load->helper ( 'pdf_helper' );
			$data = $this->exportView ();
			// print'<pre>';
			// print_r($data);
			// die;
			
			return_pdf ( $data, $this->lang->line('lrvl_srvlnc_lrvl_srvlncs') ); // Create pdf
			
			exec ( "convert LarvalSurveillancepdf.pdf LarvalSurveillance.tif" );
			$this->download_send_headers ( $this->lang->line('lrvl_srvlnc_lrvl_srvlncs') . ".tif" );
			echo file_get_contents ( $this->lang->line('lrvl_srvlnc_lrvl_srvlncs') . ".tif" );
			unlink ("temp/" . $this->lang->line('lrvl_srvlnc_hdng') ."pdf.pdf" );
			unlink ("temp/" . $this->lang->line('lrvl_srvlnc_hdng') . ".tif" );
		}
	}
}

/* End of file larvalsurveillance_report.php */
/* Location: ./application/controllers/larvalsurveillance_report.php */