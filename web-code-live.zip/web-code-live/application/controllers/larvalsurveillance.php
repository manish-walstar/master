<?php

if (! defined ( 'BASEPATH' ))
	exit ( 'No direct script access allowed' );
class Larvalsurveillance extends CI_Controller {
	public $idlocation;
	public $site_name = "";
	public $inspector = "";
	public $site_type = "";
	public $zone_name = "";
	public $postalcode = "";
	public $latitude = "";
	public $longitude = "";
	public $species = "";
	public $s_species = "";
	public $site_status = "";
	public $state_name = "";
	public $water_temprange = "";
	public $larvae_count = "";
	public $instar_name = "";
	public $date;
	public $time;
	public $iduomwatersize = "";
	public $sitegroup = "";
	public $exc_site = "";
    public $site_details = "";
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * http://example.com/user
	 * - or -
	 * http://example.com/user/index
	 * - or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * 
	 * @see http://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct() {
		parent::__construct ();
		
		if ($this->session->userdata ( 'idlocation' ))
			$this->idlocation = $this->session->userdata ( 'idlocation' );
		
        $this->load->helper('language');
        
		$this->load->model ( 'larvalsurveillance_model' );
		$this->load->model ( 'adultsurveillance_model' );
		$this->load->model ( 'service_requestmodel' );
		$this->load->model ( 'site_model' );
		$this->load->model ( 'usermodel' );
		$this->load->model ( 'treatment_model' );
		$this->load->model ( 'zone_model' );
		$this->iduomwatersize = $this->treatment_model->getTAreaTreated ();
		$this->usermodel->set_access_session ();
		$this->sitegroup = $this->site_model->getSiteGroup ();
		
		if ($this->usermodel->user_access ( 'surveillance' ) || $this->usermodel->user_access ( 'company_admin' )) {
		} else {
			redirect ( base_url () );
		}
		
        $this->app_lang = $this->session->userdata('app_lang');
        $this->lang->load("app",$this->app_lang);
        
		$this->date = date ( 'm/d/Y' );
		$this->time = date ( 'h:i A' );
	}
	public function index() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			redirect ( base_url () . "larvalsurveillance/getlarvalsurveillance" );
		}
	}
	/*
	 * ADD NEW SITE FORM VIEW
	 */
	public function addsiteview() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$this->site_type = $this->site_model->getSitetypes ();
			$this->zones = $this->site_model->getZones ();
			$this->states = $this->site_model->getStates ();
			$this->state_list = $this->site_model->getStatesList ();
			$this->statuses = $this->site_model->getStatuses ();
			$data = array (
					'site_type' => $this->site_type,
					'zones' => $this->zones,
					'states' => $this->states,
					'state_list' => $this->state_list,
					'iduomwatersize' => $this->iduomwatersize,
					'sitegroup' => $this->sitegroup,
					'googlezoom' => $this->session->userdata ( 'googlezoom' ),
					'user_loc' => $this->adultsurveillance_model->getUserLoc (),
                    'app_lang' => $this->app_lang 
			);
			
			$this->load->view ( 'traps/add_site', $data );
		}
	}
	/**
	 * Function to Show Add Member Form
	 */
	public function showaddlarvalsurveillance() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$this->inspector = $this->larvalsurveillance_model->getInspectors ();
			$this->site_name = $this->larvalsurveillance_model->getSitename ();
			$this->species = $this->adultsurveillance_model->getSpecies ( $this->idlocation );
			$this->site_type = $this->site_model->getSitetypes ();
			$this->zone_name = $this->larvalsurveillance_model->getZonename ();
			$this->state_name = $this->site_model->getStates ();
			$this->site_status = $this->larvalsurveillance_model->getSitestatus ();
			$this->water_temprange = $this->larvalsurveillance_model->getWatertemprange ();
			$this->larvae_count = $this->larvalsurveillance_model->getLarvaecount ();
			$this->instar_name = $this->larvalsurveillance_model->getInstar ();
			
            $mapFlag = $this->input->get_post ( 'mapFlag' );
            $idSite = $this->input->get('idsite');
            $this->initSiteRelatedData($idSite);
            
			$data = array (
                    'username' => $this->session->userdata ( 'username' ),
					'site_name' => $this->site_name,
					'site' => ! empty ( $this->site_details ['site'] ) ? $this->site_details ['site'] : '',
					'maplabel' => ! empty ( $this->site_details ['maplabel'] ) ? $this->site_details ['maplabel'] : '',
					'address1' => ! empty ( $this->site_details ['address1'] ) ? $this->site_details ['address1'] : '',
					'address2' => ! empty ( $this->site_details ['address2'] ) ? $this->site_details ['address2'] : '',
					'city' => ! empty ( $this->site_details ['city'] ) ? $this->site_details ['city'] : '',
					'postalcode' => ! empty ( $this->site_details ['postalcode'] ) ? $this->site_details ['postalcode'] : '',
					'latitude' => ! empty ( $this->site_details ['latitude'] ) ? $this->site_details ['latitude'] : '',
					'longitude' => ! empty ( $this->site_details ['longitude'] ) ? $this->site_details ['longitude'] : '',
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_data_entry_lrvl_srvlnc'),
					'page' => "larvalsurveillance",
                    'app_lang' => $this->app_lang,
					'inspector' => $this->inspector,
					'species' => $this->species,
					'site_type' => $this->site_type,
					'zone_name' => $this->zone_name,
					'state_name' => $this->state_name,
					'site_status' => $this->site_status,
					'sitegroup' => $this->sitegroup,
					'water_temprange' => $this->water_temprange,
					'larvae_count' => $this->larvae_count,
					'instar_name' => $this->instar_name,
					'date' => $this->date,
					'time' => $this->time,
                    'mapFlag' => $mapFlag
			);
			
			// add code for service request
			$service_req_id = $this->input->get_post ( 'service_req_id' );
            
			if (! empty ( $service_req_id )) {
				$id = $service_req_id;
				$this->flag = $this->service_requestmodel->getServiceRequestData ( $id );
				if (! empty ( $this->flag )) {
					$idSite = $this->flag['idsite'];
				}
			}
            
            $eventData = $this->getAllEventsData($idSite);
            $data = array_merge($data, $eventData);
            $siteData = !empty($idSite) ? $this->getSiteData($idSite) : array();
            //print'<pre>';
//            print_r($siteData);
//            die;
			if (! empty ($siteData)) {
				$data = array_merge ( $data, $siteData );
			}
            
            if(empty($mapFlag)) {
                $this->load->view ( 'header', $data );
                $this->load->view ( 'left_sidebar', $data );
            } else {
                $data['mapFlag'] = $mapFlag;
            }
			$this->load->view ( 'larvalsurveillances/add_larvalsurveillance', $data );
            
            if(empty($mapFlag)) {
                $this->load->view ( 'footer' );
            }
		}
	}
	
    /**
	 * Function to get Site Data based on idsite clicked by user on Map
	 */
    public function getSiteData($idsite = "") {
        if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
            $return = array();
            if(!empty($idsite)){
                $site_data = $this->site_model->getSiteData ( $idsite );
    			if (! empty ( $site_data )) {
                    $this->sites = $this->site_model->getSelectedExistingSite ( $idsite );
					$this->site_type = $this->site_model->getSitetypes ();
					$this->zone_name = $this->site_model->getSelectedZones ( $site_data ['idzone'] );
					$this->states = $this->site_model->getStates ();
                    
                    $return ['site_name'] = $this->sites;
                    $return ['site'] = ! empty ( $site_data ['site'] ) ? $site_data ['site'] : '';
    				$return ['site_type'] = $this->site_type;
                    $return ['idsitetype'] = ! empty ( $site_data ['idsitetype'] ) ? $site_data ['idsitetype'] : '';
    				$return ['zone_name'] = $this->zone_name;
                    $return ['maplabel'] = ! empty ( $site_data ['maplabel'] ) ? $site_data ['maplabel'] : '';;
    				$return ['address1'] = ! empty ( $site_data ['address1'] ) ? $site_data ['address1'] : '';
    				$return ['address2'] = ! empty ( $site_data ['address2'] ) ? $site_data ['address2'] : '';
    				$return ['city'] = ! empty ( $site_data ['city'] ) ? $site_data ['city'] : '';
    				$return ['state_name'] = $this->states;
                    $return ['idstate'] = ! empty ( $site_data ['idstate'] ) ? $site_data ['idstate'] : '';
    				$return ['postalcode'] = ! empty ( $site_data ['postalcode'] ) ? $site_data ['postalcode'] : '';
    				$return ['latitude'] = (! empty ( $site_data ['latitude'] ) && empty ( $return ['latitude'] )) ? $site_data ['latitude'] : '';
    				$return ['longitude'] = (! empty ( $site_data ['longitude'] ) && empty ( $return ['longitude'] )) ? $site_data ['longitude'] : '';
    			}
            }
            
            return $return;
        }
    }
    
	/**
	 * Function to add a new larvalsurveillance
	 */
	public function addlarvalsurveillance() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_data_entry_lrvl_srvlnc'),
					'page' => "larvalsurveillance",
                    'app_lang' => $this->app_lang 
			);
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			// add service request id
			$service_req_id = $this->input->get_post ( 'service_req_id' );
			$datas_1 = array ();
			$this->form_validation->set_rules ( 'idsite', $this->lang->line('whthr_snsr_site_nm'), 'trim' );
			$this->form_validation->set_rules ( 'idsitetype', $this->lang->line('trap_mgmt_site_type'), 'trim' );
			$this->form_validation->set_rules ( 'idinspector', $this->lang->line('whthr_snsr_inspctr'), 'trim|required' );
			$this->form_validation->set_rules ( 'date', $this->lang->line('adlt_srvlnc_set_date'), 'trim|required' );
			$this->form_validation->set_rules ( 'time', $this->lang->line('adlt_srvlnc_set_time'), 'trim|required' );
			$this->form_validation->set_rules ( 'longitude', $this->lang->line('site_mgmt_lng'), 'trim|required' );
			$this->form_validation->set_rules ( 'latitude', $this->lang->line('site_mgmt_lat'), 'trim|required' );
			$this->form_validation->set_rules ( 'postalcode', $this->lang->line('site_mgmt_postl_cde'), 'trim' );
			$this->form_validation->set_rules ( 'idzone', $this->lang->line('zone_mgmt_nme'), 'trim' );
			
			$this->inspector = $this->larvalsurveillance_model->getInspectors ();
			$this->site_name = $this->larvalsurveillance_model->getSitename ();
			$this->species = $this->larvalsurveillance_model->getSpecies ( $this->idlocation );
			$this->site_type = $this->site_model->getSitetypes ();
			$this->zone_name = $this->larvalsurveillance_model->getZonename ();
			$this->state_name = $this->site_model->getStates ();
			$this->site_status = $this->larvalsurveillance_model->getSitestatus ();
			$this->water_temprange = $this->larvalsurveillance_model->getWatertemprange ();
			$this->larvae_count = $this->larvalsurveillance_model->getLarvaecount ();
			$this->instar_name = $this->larvalsurveillance_model->getInstar ();
			$data_1 = array (
					'site_name' => $this->site_name,
					'inspector' => $this->inspector,
					'species' => $this->species,
					'site_type' => $this->site_type,
					'zone_name' => $this->zone_name,
					'state_name' => $this->state_name,
					'site_status' => $this->site_status,
					'sitegroup' => $this->sitegroup,
					'water_temprange' => $this->water_temprange,
					'larvae_count' => $this->larvae_count,
					'instar_name' => $this->instar_name,
                    'app_lang' => $this->app_lang 
			);
			// add service requesr id when error accure
			if (! empty ( $service_req_id )) {
				$datas_1 = array (
						'service_req_id' => $service_req_id 
				);
				$data_1 = array_merge ( $data_1, $datas_1 );
			}
			if ($this->form_validation->run () == FALSE) {
				$this->load->view ( 'larvalsurveillances/add_larvalsurveillance', $data_1 );
			} else {
				$flag = $this->larvalsurveillance_model->addLarvalsurveillance ();
				$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
				if ($flag) {
					$service_req_id = $this->input->get_post ( 'service_req_id' );
					
					if (! empty ( $seturl [1] ))
						redirect ( $seturl [0] . "?msg=success#" . $seturl [1] );
					else
						redirect ( $seturl [0] . "?msg=success" );
					
					// if(!empty($service_req_id))
					// {
					// redirect(base_url()."service_request/getservice_request?msg=success");
					// }
					// else
					// {
					// redirect(base_url()."larvalsurveillance/getlarvalsurveillance?msg=success");
					// }
					
					// $this->load->view('larvalsurveillances/add_larvalsurveillance',$data_1);
				} else {
					if (! empty ( $seturl [1] ))
						redirect ( $seturl [0] . "?del=error#" . $seturl [1] );
					else
						redirect ( $seturl [0] . "?del=error" );
					
					// redirect(base_url()."larvalsurveillance/getlarvalsurveillance?del=error");
				}
			}
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to show edit larvalsurveillance
	 */
	public function showeditlarvalsurveillance($Id = '', $msg = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$req = $this->input->get ( 'id', TRUE );
            $mapFlag = $this->input->get_post ( 'mapFlag' );
            $mapSite = "";
			$succ_msg = "";
			$error_msg = "";
			
			if (empty ( $req ))
				redirect ( base_url () . "larvalsurveillance/getlarvalsurveillance" );
			
			$flag = $this->larvalsurveillance_model->getLarvalsurveillanceData ( $req );
			
			// echo "<pre>";
			// print_r($flag);
			// echo $flag['zone1'];
			// die;
			//
			$id = base64_encode ( json_encode ( $flag ['idlarvalsurveillance'] ) );
			// echo '<pre>';print_r($id);die;
			
			if ($msg == "updated") {
				$succ_msg = "This Larval detail has been updated successfully";
			} else if ($msg == "error") {
				$error_msg = $this->lang->line('err_msg_smthng_went_wrng');
			}
			
			if (! empty ( $flag )) {
				$this->date_name = $this->larvalsurveillance_model->getSelectedDate ( $flag ['idlarvalsurveillance'] );
				$this->time_name = $this->larvalsurveillance_model->getSelectedTime ( $flag ['idlarvalsurveillance'] );
				
				$this->inspector = $this->larvalsurveillance_model->getSelectedInspectors ( $flag ['idinspector'] );
                $mapSite = $flag ['idsite'];
				
				$this->species = $this->adultsurveillance_model->getSpecies ( $this->idlocation );
				$this->selected_species = $this->larvalsurveillance_model->getSelectedSpecies ( $flag ['idlarvalsurveillance'] );
				$this->site_type = $this->site_model->getSitetypes ( );
				$this->state_name = $this->site_model->getStates ( );
				$this->site_status = $this->larvalsurveillance_model->getSitestatus ( );
				$this->water_temprange = $this->larvalsurveillance_model->getWatertemprange ( $flag ['idwatertemprange'] );
				$this->larvae_count = $this->larvalsurveillance_model->getLarvaecount ( $flag ['idlarvalsurveillance'] );
				$this->larvae_present = $flag ['larvaepresent'];
				$this->instar_name = $this->larvalsurveillance_model->getInstar (  );
				$this->comment_name = $this->larvalsurveillance_model->getComment ( $flag ['idlarvalsurveillance'] );
			}
			
            $this->initSiteRelatedData($mapSite);
            $mapData = $this->getAllEventsData($mapSite);
            $flag = array_merge($flag, $mapData);
            
			$data_1 = array (
					'exc_site' => $this->exc_site,
					'date_name' => $this->date_name,
					'time_name' => $this->time_name,
					'site_name' => $this->site_name,
					'site' => ! empty ( $this->site_details ['site'] ) ? $this->site_details ['site'] : '',
					'maplabel' => ! empty ( $this->site_details ['maplabel'] ) ? $this->site_details ['maplabel'] : '',
					'address1' => ! empty ( $this->site_details ['address1'] ) ? $this->site_details ['address1'] : '',
					'address2' => ! empty ( $this->site_details ['address2'] ) ? $this->site_details ['address2'] : '',
					'city' => ! empty ( $this->site_details ['city'] ) ? $this->site_details ['city'] : '',
					'postalcode' => ! empty ( $this->site_details ['postalcode'] ) ? $this->site_details ['postalcode'] : '',
					'latitude' => ! empty ( $this->site_details ['latitude'] ) ? $this->site_details ['latitude'] : '',
					'longitude' => ! empty ( $this->site_details ['longitude'] ) ? $this->site_details ['longitude'] : '',
					'pdop' => ! empty ( $this->site_details ['pdop'] ) ? $this->site_details ['pdop'] : '',
					// 'idsitegroup' => $this->site_details['idsitegroup'],
					'inspector' => $this->inspector,
					'species' => $this->species,
					'selected_species' => $this->selected_species,
					'site_type' => $this->site_type,
					'zone_name' => $this->zone_name,
					'state_name' => $this->state_name,
					'site_status' => $this->site_status,
					'water_temprange' => $this->water_temprange,
					'larvae_count' => $this->larvae_count,
					'larvae_present' => $this->larvae_present,
					'instar_name' => $this->instar_name,
					'comment_name' => $this->comment_name,
					'sitegroup' => $this->sitegroup,
					'id' => $id,
					'error_msg' => $error_msg,
					'succ_msg' => $succ_msg,
                    'app_lang' => $this->app_lang,
                    'idsitetype' => $this->site_details ['idsitetype'],
                    'idstate' => $this->site_details ['idstate'],
                    'mapFlag' => $mapFlag                        
			);
			
			 //echo "<pre>";
//			 print_r($data_1);
//			 die;
			$data = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_data_entry_lrvl_srvlnc'),
					'page' => "larvalsurveillance",
                    'app_lang' => $this->app_lang
			);
            
            if(empty($mapFlag)){
                $this->load->view ( 'header', $data );
                $this->load->view ( 'left_sidebar', $data );    
            }
			
			$data = array_merge ( $data_1, $flag );
			
			$this->load->view ( 'larvalsurveillances/edit_larvalsurveillance', $data );
		}
        if(empty($mapFlag)){
            $this->load->view ( 'footer' );    
        }
	}
	
	/**
	 * Function to save edit Larval Surveillance Values
	 */
	public function editlarvalsurveillance() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			
			$req = $this->input->post ( 'x_s_' );
			
			if (empty ( $req )) {
				redirect ( base_url () . "larvalsurveillance/getlarvalsurveillance" );
			}
			$req = json_decode ( base64_decode ( $req ) );
			
			$this->form_validation->set_rules ( 'idsite', $this->lang->line('whthr_snsr_site_nm'), 'trim' );
			$this->form_validation->set_rules ( 'idsitetype', $this->lang->line('trap_mgmt_site_type'), 'trim' );
			$this->form_validation->set_rules ( 'idinspector', $this->lang->line('whthr_snsr_inspctr'), 'trim|required' );
			$this->form_validation->set_rules ( 'date', $this->lang->line('adlt_srvlnc_set_date'), 'trim|required' );
			$this->form_validation->set_rules ( 'time', $this->lang->line('adlt_srvlnc_set_time'), 'trim|required' );
			$this->form_validation->set_rules ( 'longitude', $this->lang->line('site_mgmt_lng'), 'trim|required' );
			$this->form_validation->set_rules ( 'latitude', $this->lang->line('site_mgmt_lat'), 'trim|required' );
			$this->form_validation->set_rules ( 'postalcode', $this->lang->line('site_mgmt_postl_cde'), 'trim' );
			$this->form_validation->set_rules ( 'idzone', $this->lang->line('zone_mgmt_nme'), 'trim' );
			
			if ($this->form_validation->run () == FALSE) {
				$this->showeditlarvalsurveillance ( $req );
			} else {
				$flag = $this->larvalsurveillance_model->updateLarvalsurveillance ( $req );
				
				if (! empty ( $flag )) {
					$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
					
					if (! empty ( $seturl [1] ))
						redirect ( $seturl [0] . "?msg=updated#" . $seturl [1] );
					else
						redirect ( $seturl [0] . "?msg=updated" );
					// redirect(base_url()."larvalsurveillance/getlarvalsurveillance?msg=updated");
				} else {
					$this->showeditlarvalsurveillance ( $req );
				}
			}
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to delete larvalsurveillance
	 */
	public function deletelarvalsurveillance() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$flag = $this->larvalsurveillance_model->deletelarvalsurveillance ();
			
			$msg = "";
			
			if ($flag)
				$msg = "success";
			else
				$msg = "error";
			$seturl = explode ( "#", $this->session->userdata ( 'url' ) );
			if (! empty ( $seturl [1] ))
				redirect ( $seturl [0] . "?del=" . $msg . "#" . $seturl [1] );
			else
				redirect ( $seturl [0] . "?del=" . $msg );
			// redirect(base_url().'larvalsurveillance/getlarvalsurveillance?del='.$msg);
		}
	}
	
	/**
	 * Function to display List Of larvalsurveillances
	 */
	public function getlarvalsurveillance($grid = '', $msg = '') {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$filter_date = $this->input->post ( 'filter_date' );
			
			$columns = array (
					0 => array (
							'name' => $this->lang->line('whthr_snsr_site_nm'),
							'db_name' => 'idsite',
							'header' => $this->lang->line('whthr_snsr_site_nm'),
							'group' => $this->lang->line('sidebar_data_entry_lrvl_srvlnc'),
							'ref_table_id_name' => 'idsite',
							'ref_table_db_name' => 'sites',
							'ref_field_db_name' => 'site',
							'ref_field_type' => 'string',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-n' 
					),
					1 => array (
							'name' => $this->lang->line('advrs_impct_rprtng_dttm'),
							'db_name_1' => 'date',
							'db_name_2' => 'time',
							'header' => $this->lang->line('lrvl_srvlnc_schdle_date_time'),
							'group' => $this->lang->line('sidebar_data_entry_lrvl_srvlnc'),
							'form_control' => 'text_long',
							'type' => '1+2' 
					),
					2 => array (
							'name' => $this->lang->line('whthr_snsr_inspctr'),
							'db_name' => 'idinspector',
							'header' => $this->lang->line('whthr_snsr_inspctr'),
							'group' => $this->lang->line('sidebar_data_entry_lrvl_srvlnc'),
							'ref_table_id_name' => 'iduser',
							'ref_table_db_name' => 'users',
							'ref_field_db_name' => 'firstname',
							'ref_field_2_db_name' => 'middlename',
							'ref_field_3_db_name' => 'lastname',
							'ref_field_type' => 'string',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-1+2+3' 
					),
					3 => array (
							'name' => $this->lang->line('lrvl_srvlnc_larvae_cnt'),
							'db_name' => 'totalcount',
							'header' => $this->lang->line('lrvl_srvlnc_larvae_cnt'),
							'group' => $this->lang->line('sidebar_data_entry_lrvl_srvlnc') 
					),
					4 => array (
							'name' => $this->lang->line('lrvl_srvlnc_addrs'),
							'db_name' => 'idsite',
							'header' => $this->lang->line('lrvl_srvlnc_addrs'),
							'group' => $this->lang->line('sidebar_data_entry_lrvl_srvlnc'),
							'ref_table_id_name' => 'idsite',
							'ref_table_db_name' => 'sites',
							'ref_field_db_name' => 'address1',
							'ref_field_1_db_name' => 'address2',
							'ref_field_2_db_name' => 'city',
							'ref_table_1_id_name' => 'idstate',
							'ref_table_1_db_name' => 'states',
							'ref_field_1_1_db_name' => 'statename',
							'ref_field_type' => 'string',
							'form_control' => 'text_long',
							'required' => TRUE,
							'type' => '1-(1+2+3)-1-1' 
					) 
			)
			// ,
			// 4=> array(
			// 'name' => $this->lang->line('lrvl_srvlnc_addrs'),
			// 'db_name' => 'idsite',
			// 'header' => $this->lang->line('lrvl_srvlnc_addrs'),
			// 'group' => $this->lang->line('sidebar_data_entry_lrvl_srvlnc'),
			// 'ref_table_id_name' => 'idsite',
			// 'ref_table_db_name' => 'sites',
			// 'ref_field_db_name' => 'address1',
			// 'ref_field_db_name' => 'address1',
			// 'ref_field_type' => 'string',
			// 'form_control' => 'text_long',
			// 'required' => TRUE,
			// 'type' => '1-n'
			// )
			;
			
			$commands ['delete'] ['toolbar'] = FALSE;
			// check url comes from service request or not
			// code for addtional request from service and larval
			$table1_rel = '';
			
			// $service_req_id = '';
			$service_req_id = $this->input->get_post ( 'service_req_id' );
			
			if (! empty ( $service_req_id )) {
				$table1_rel = 'larvalsurveillanceservice';
			}
			
			$params = array (
					'id' => 'idlarvalsurveillance',
					'table' => 'larvalsurveillance',
					'url' => 'larvalsurveillance/getlarvalsurveillance',
					'uri_param' => $grid,
					'columns' => $columns,
					'order' => array (
							1 => 'desc' 
					),
					'table1_rel' => $table1_rel,
					'service_req_id' => $service_req_id,
					'filter_date' => ! empty ( $filter_date ) ? $filter_date : '2',
					'filters' => array (
							0 => array (
									'value' => $this->idlocation 
							) 
					),
					// 'columns_visible' => array(0,1,2),
					'commands' => $commands,
					'ajax' => TRUE,
					'msc_url' => array (
							'excel_url' => base_url () . 'larvalsurveillance/toExcelAll',
							'pdf_url' => base_url () . 'larvalsurveillance/toPdfAll',
							'text' => 'larvalsurveillance' 
					) 
			);
			
			$newdata = array (
					'url' => base_url () . $params ['url'] . '#' . $params ['id'] . '=' . $grid 
			);
			
			$this->session->set_userdata ( $newdata );
			
			$this->load->library ( 'carbogrid', $params );
			
			if ($this->carbogrid->is_ajax) {
				$this->carbogrid->render ();
				return FALSE;
			}
			
			$data_1 = array (
					'username' => $this->session->userdata ( 'username' ),
					'logstatus' => "logout",
					'title' => $this->lang->line('sidebar_data_entry_lrvl_srvlnc'),
					'page' => "larvalsurveillance",
                    'app_lang' => $this->app_lang 
			);
			$this->load->view ( 'header', $data_1 );
			$this->load->view ( 'left_sidebar', $data_1 );
			
			// $this->larvalsurveillance_model->showmap();
			// Pass grid to the view
            $data = (object)array();
			$data->page = 'grid_single';
			$data->page_grid = $this->carbogrid->render ();
			$data->msg = $msg;
			$data->mapdata = base_url () . "larvalsurveillance/showmap";
			
			$this->load->view ( 'larvalsurveillances/larvalsurveillances', $data );
		}
		$this->load->view ( 'footer' );
	}
	
	/**
	 * Function to display map
	 */
	public function showmap() {
		if (! $this->session->userdata ( 'logged_in' )) {
			redirect ( base_url () );
		} else {
			$query ['data'] = $this->larvalsurveillance_model->getMapdata ();
			$query ['user_loc'] = $this->adultsurveillance_model->getUserLoc ();
			$query ['zone_loc'] = $this->zone_model->getZoneCord ();
			$query ['googlezoom'] = $this->session->userdata ( 'googlezoom' );
			// print'<pre>';
			// print_r($query);
			// die;
			//
			// $data = $this->load->view('larvalsurveillances/map_view',$query,TRUE);
			
			// return $data;
			$this->load->view ( 'larvalsurveillances/map_view', $query );
		}
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function getlarvalsurveillancedata() {
		$id = $this->input->post ( 'idlarvalsurveillance' );
		
		if (empty ( $id )) {
			echo "error";
			exit ();
		}
		
		$data = $this->larvalsurveillance_model->getLarvalsurveillanceData ( $id );
		
		echo json_encode ( $data );
	}
	
	/**
	 * Function to get data from site to display site details
	 */
	public function showsitedetails() {
		$id = $this->input->get_post ( 'site_id' );
		
		if (empty ( $id )) {
			echo "error";
			exit ();
		}
		
		$data = $this->larvalsurveillance_model->getSiteNameData ( $id );
		
		echo json_encode ( $data );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function history() {
		$req = $this->input->get_post ( 'x_s_' );
		
		if (empty ( $req ))
			redirect ( base_url () . "larvalsurveillance/getlarvalsurveillance" );
		
		$data1 = $this->larvalsurveillance_model->getHistory ( $req );
		
		$id = $data1 [0] ['idlarvalsurveillance'];
		$total_count = 0;
		$i = 0;
		foreach ( $data1 as $key => $val ) {
			echo $val ['idlarvalsurveillance'] . " " . $id . "<br>";
			if ($val ['idlarvalsurveillance'] == $id) {
				$total_count += $val ['count'];
				$data [$i] [] = $val;
			} else {
				$data [$i] ['total'] = $total_count;
				$total_count = 0;
				$i ++;
				$data [$i] [] = $val;
				$id = $val ['idlarvalsurveillance'];
				$total_count += $val ['count'];
			}
			$data [$i] ['total'] = $total_count;
		}
		// $data2 = $this->larvalsurveillance_model->getSpeciesCountbydate($req);
		
		$this->load->view ( 'larvalsurveillances/history_view', $data );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function collectedSpecies() {
		$req = $this->input->get_post ( 'x_s_' );
		
		if (empty ( $req ))
			redirect ( base_url () . "larvalsurveillance/getlarvalsurveillance" );
		
		$query ['data'] = $this->larvalsurveillance_model->getSpeciesCount ( $req );
		
		$this->load->view ( 'larvalsurveillances/allspecies_view', $query );
	}
	
	/**
	 * Function to Convert Data into Excel Sheet
	 */
	public function toExcelAll() {
		$query ['data'] = $this->larvalsurveillance_model->listLarvalsurveillances ();
		// print'<pre>';
		// print_r($query['data']);
		// die;
		$this->load->view ( 'larvalsurveillances/excel_view', $query );
	}
	
	/**
	 * Function to Convert Data into PDF
	 */
	public function toPdfAll() {
		$this->load->helper ( 'pdf_helper' ); // Load helper
		$query ['data'] = $this->larvalsurveillance_model->listLarvalsurveillances ();
		
		$data = $this->load->view ( 'larvalsurveillances/pdf_view', $query, true );
		// $data = file_get_contents(htmlentities($dd)); // Pass the url of html report
		
		create_pdf_l ( $data, $this->lang->line('lrvl_srvlnc_lrvl_srvlncs') ); // Create pdf
	}
    
    /**
	 * Function to fetch all site data based on module
	 */
	public function getAllEventsData($idsite = "") {
        $params = array (
            'idsite' => $idsite,
            'idlocation' => $this->session->userdata('idlocation')
        );
        
        $this->load->library ( 'common', $params );
        
        $response = $this->common->getAllEventsData ();
        //print'<pre>';
//        print_r($response);
//        die;
        return $response;
    }
    
    /**
	 * Function to fetch all site data based on module
	 */
	public function initSiteRelatedData($idsite = "") {
        if(empty($idsite)){
            return;
        }
        $this->site_name = $this->larvalsurveillance_model->getSitename ( $idsite );
		$this->site_details = $this->larvalsurveillance_model->getSelectedSitedetails ( $idsite );
        $this->exc_site = $this->site_model->getSelectedExistingSite ( $idsite );
        $this->zone_name = $this->larvalsurveillance_model->getSelectedZonename ( $this->site_details ['idzone'] );
    }
}

/* End of file larvalsurveillance.php */
/* Location: ./application/controllers/larvalsurveillance.php */
