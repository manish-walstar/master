<?php

/**
 * @author Skysoft Incorporated
 * @copyright 2015
 */

class LanguageLoader
{
    function initialize() {
        $ci =& get_instance();
        $ci->load->helper('language');

        $app_lang = $ci->session->userdata('app_lang');
        if ($app_lang) {
            $ci->lang->load('app',$ci->session->userdata('app_lang'));
        } else {
            $ci->lang->load('app','en');
        }
    }
}

?>